/*
 * Change History:
 * 
 * No      Date          Description                                                        Changed By
 * ====    ==========    ===========                                                        ==========                     
   GA001   20/08/2019    MYS-2018-0658 : Unable to download 
                         "In-Forced Cases list" from Mass upload Dispatch Info tab           KGA                    
*/
import { Component, OnInit, OnDestroy, ViewChild, ViewContainerRef, ElementRef } from '@angular/core';
import { CordysSoapWService } from "../../../common/components/utility/cordys-soap-ws";
import { AlertMessagesService } from "../../../common/components/utility/alertmessage/alertmessages.service";
import { AlertMessage } from "../../../common/components/utility/alertmessage/alertmessages.model";
import { ApplicationUtilService } from "../../../common/services/application.util.service";
import { AppUtil } from "../../../common/components/utility/apputil/app.util";
import { ModalInput } from "../../../common/components/utility/modal/modal";
import { CustomDCLService } from "../../../common/services/customdcl.service";
import { DCLInput } from "../../../common/services/customdcl.service";
import { ProgressBarComponent } from '../../../common/components/utility/progressbar/progressbar.component';


declare var jQuery: any;

@Component({
    selector: 'dispatch-component',
    templateUrl: 'app/bms/components/dispatch/dispatch.template.html'
})
export class DispatchComponent implements OnInit {
    @ViewChild('fileselection') el: ElementRef;
    private application: string;
    private uploadedFiles = [];
    private navNextEnable: boolean = false;
    private navPrevEnable: boolean = false;
    private iteratorvalue = 20;
    private encodeFileContent: string;
    private fileName: string;
    private fileSize;
    private positionvalue = 0;
    private docType: string = "dispatchFile";
    private inputReqForList = {
        "application": "BMS",
        "cursor": { "@id": "0", "@position": "0", "@numRows": "20", "@maxRows": "25", "@sameConnection": "false" }
    }

    @ViewChild('dispatchModal', { read: ViewContainerRef }) contentArea: ViewContainerRef;
    constructor(private _elRef: ElementRef, private _cordysService: CordysSoapWService, private _appUtilService: ApplicationUtilService, public _alertMsgService: AlertMessagesService,
        public dcl: CustomDCLService) {
        this.application = this._appUtilService.getAppId();
    }

    ngOnInit() {
        this.getAllMassUploadFiles();
    }

    private getAllMassUploadFiles() {
        ProgressBarComponent.show('Loading', { dialogSize: 'm', progressType: 'success' });
        let responsePromise = this._cordysService.callCordysSoapService("GetMassUploadRecords", "http://schemas.opentext.com/msig/persistancedb/1.0", this.inputReqForList, null, null, true, this);
        responsePromise.success((data) => {
            this.uploadedFiles = [];
            if (data.tuple) {
                if (!Array.prototype.isPrototypeOf(data.tuple)) {
                    data.tuple = [data.tuple]
                }
                data.tuple.forEach(element => {
                    this.uploadedFiles.push(element.old.MSIG_MASS_UPLOAD)
                });
            }
            if (this.uploadedFiles) {
                if (this.uploadedFiles.length < this.iteratorvalue) {
                    this.navNextEnable = false;
                }
                else this.navNextEnable = true;
            }
            ProgressBarComponent.hide();
        });
        responsePromise.error((data) => {
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error while fetching the records.", 5000));
            ProgressBarComponent.hide();
        });
    }

    private triggerEvent() {
        this.el.nativeElement.value = null;
        this.el.nativeElement.click();
    }

    private onFileSelect(event) {
        ProgressBarComponent.show('File upload is in Progress', { dialogSize: 'm', progressType: 'primary' });
        let selectedFile = (<HTMLInputElement>document.getElementById("fileSelect")).files[0];
        let reader = new FileReader();
        this.fileName = event.currentTarget.files[0].name;
        this.fileSize = event.currentTarget.files[0].size;
        reader.onload = this.getFileContent(event, this);
        reader.readAsDataURL(selectedFile);
    }

    private getFileContent(e, scopeObject) {
        return function (event) {
            let temp = event.target.result;
            scopeObject.encodeFileContent = temp.substr(temp.indexOf(";base64,") + 8);
            let input = scopeObject.uploadFileRequestParams();
            let responsePromise = scopeObject._cordysService.callCordysSoapService("uploadFile", "http://schemas.cordys.com/default", input, null, null, true, scopeObject);
            responsePromise.success((data) => {
                ProgressBarComponent.hide();
                if (data.status.text == 'Success') {
                    scopeObject.getAllMassUploadFiles();
                    scopeObject._alertMsgService.add(new AlertMessage(AlertMessage.INFO, data.message.text, 5000));
                } else {
                    scopeObject._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, data.message.text, 5000));
                }
            });
            responsePromise.error((data) => {
                scopeObject._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, data.message.text, 5000));
                ProgressBarComponent.hide();
            });
        }
    }

    private uploadFileRequestParams() {
        return {
            "application": this.application,
            "data": this.encodeFileContent,
            "fileName": this.fileName,
            "fileSize": this.fileSize,
            "fileType": this.docType,
            "uploadType": "massupload"
        }
    }

    private navNext_Click() {
        this.positionvalue = this.positionvalue + this.iteratorvalue;
        this.navPrevEnable = true;
        this.inputReqForList.cursor["@position"] = (this.positionvalue).toString();
        var tempArray = this.uploadedFiles;
        this.getAllMassUploadFiles();
        if (this.uploadedFiles.length < this.iteratorvalue) {
            this.navNextEnable = false;
        }
        if (this.uploadedFiles.length == 0) {
            this.navNextEnable = false;
            this.navPrevEnable = true;
            this.positionvalue = this.positionvalue - this.iteratorvalue;
            this.inputReqForList.cursor["@position"] = (this.positionvalue).toString();
            this.uploadedFiles = tempArray;
        }
    }

    private navPrevious_Click() {
        this.positionvalue = this.positionvalue - this.iteratorvalue;
        this.inputReqForList.cursor["@position"] = (this.positionvalue).toString();
        this.navNextEnable = true;
        if (this.positionvalue >= 0) {
            if (this.positionvalue == 0) {
                this.navPrevEnable = false;
            }
            this.getAllMassUploadFiles();
        }
    }

    private startProcess(id) {
        let massUploadInput = {
            "id": id
        };
        let response = this._cordysService.callCordysSoapService("BMSMassUploadHandler", "http://schemas.cordys.com/default", massUploadInput, null, null, true, this);
        response.success((data) => {
            this.getAllMassUploadFiles();
            if (data.status.text == 'Success') {
                this._alertMsgService.add(new AlertMessage(AlertMessage.SUCCESS, data.message.text, 3000));
            }
            if (data.status.text == 'Failed') {
                this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, data.message.text, 3000));
            }
            if (data.status.text == 'Error') {
                this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, data.message.text, 3000));
            }
        });
        response.error((data) => {
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error while initiating Mass Upload Process. Please contact administrator or try after sometime ", 3000));
        });
    }


    private confirmUserAndDelete(uploadId) {
        let inputObj = {
            "Message": "Are you sure you want to delete the file?"
        };
        let input = inputObj;
        let lookup = new ModalInput().get("Confirm");
        lookup.datainput = input;
        lookup.outputCallback = this.deleteFile;
        lookup.parentCompPRMS = {
            comp: this,
            uploadId: uploadId
        };
        lookup.heading = "User Confirmation";
        lookup.icon = "fa fa-hand-paper-o";
        lookup.containerRef = this.contentArea;
        this.dcl.openLookup(lookup);
    }

    private deleteFile(data, prms) {
        if (data.value == 'Y') {
            let input = {
                "id": prms.uploadId,
                "type": "massupload"
            }
            let responsePromise = prms.comp._cordysService.callCordysSoapService("deleteFile", "http://schemas.cordys.com/default", input, null, null, true, prms.comp);
            responsePromise.success((data) => {
                let idx;
                if (data.status.text == 'Success') {
                    prms.comp.uploadedFiles.forEach(element => {
                        if (element.id == prms.uploadId) {
                            idx = prms.comp.uploadedFiles.indexOf(element)
                        }
                    });
                    prms.comp.uploadedFiles.splice(idx, 1);
                    prms.comp.disableStart = false;
                    prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.SUCCESS, data.message.text, 3000));
                } else {
                    prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, data.message.text, 3000));
                }
            });
            responsePromise.error((data) => {
                this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error occured while deleting the File. Please contact administrator or try after sometime.", 3000));
            });
        }
    }

    private downloadInForcedCases() {
        // GA001 START
        //let responsePromise = this._cordysService.callCordysSoapService("getDispatchReadyList", "http://schemas.cordys.com/default", "", null, null, true, null);
        this._cordysService.callCordysSoapService("DispatchExcelProcess", "http://schemas.cordys.com/default", "", this.successInForcedCasesHandler, this.errorInForcedCasesHandler, true, this);
        //GA001 END
    }

    private successInForcedCasesHandler(data, scopeObject){
        if (data.status.text == "Success") {//Fixed script error issues.
            if (AppUtil.isEmpty(data.filePath.text, false) == false) {
                let link = document.createElement("a");
                link.href = "http://" + location.host + data.filePath.text;
                link.click();
            }
        } else {
            scopeObject._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error occurred while getting in-forces cases list.", 5000));
        }
    }
    private errorInForcedCasesHandler(response, status, errorText, scopeObject){
        scopeObject._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error occurred while getting in-forces cases list.", 5000));
    }

    public formatDate(date) {
        return ApplicationUtilService.formatDateToCurrentTimezone(date, "DD/MM/YYYY")
    }

    private downloadReport(id) {
        let input = {
            "id": id,
            "type": "massupload"
        }
        let responsePromise = this._cordysService.callCordysSoapService("downloadFile", "http://schemas.cordys.com/default", input, null, null, true, this);
        responsePromise.success((data) => {
            if (data.link.text != null && data.link.text != undefined && data.link.text != '') {
                if (data.link.text.charAt(16) != "/") {
                    data.link.text = data.link.text.substring(0, 16) + "/" + data.link.text.substring(16);
                }
                let link = document.createElement("a");
                link.href = "http://" + location.host + data.link.text;
                link.download = data.link.text.substring(data.link.text.lastIndexOf("/") + 1, data.link.text.lastIndexOf(".")) + "_report" + data.link.text.substring(data.link.text.lastIndexOf("."), data.link.text.length);
                link.click();
            } else {
                this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, data.message.text, 5000));
            }
        });
        responsePromise.error((data) => {
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error while downloading the File", 5000));
        });
    }
}