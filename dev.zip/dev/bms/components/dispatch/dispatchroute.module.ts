import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { BasicUIModule } from '../../../common/components/utility/basicui.module';
import { LovModule } from '../../../common/services/lovdropdown/lov.module';
//import { MessageModule } from '../../../common/components/utility/alertmessage/message.module';

import { DispatchComponent } from './dispatch.component';

const routerConfig: Routes = [
    { path: "", component: DispatchComponent }
];

@NgModule({
    imports: [CommonModule, FormsModule, ReactiveFormsModule, RouterModule.forChild(routerConfig), BasicUIModule, LovModule],
    declarations: [DispatchComponent],
    exports: [RouterModule, DispatchComponent]
})
export class DispatchRouteModule { }