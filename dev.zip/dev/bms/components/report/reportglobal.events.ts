import { EventHandler } from '../../../common/services/eventhandler';

export var ReportEvents: any = {};

const eventList = [
    ["AfterReportInitializedTrigger", "onAfterReportInitialized"]
];

export class ReportGlobalEvents extends EventHandler {
    constructor() { super(ReportEvents, eventList) }
}