import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { ReportComponent } from './report.component';
import { ReportPipe } from './report.pipe';

const routerConfig: Routes = [
    { path: "", component: ReportComponent }
];

@NgModule({
    declarations: [ReportComponent, ReportPipe],
    imports: [CommonModule, RouterModule.forChild(routerConfig)],
    exports: [ReportComponent, RouterModule, ReportPipe]
})

export class ReportModule {

}