import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { CordysSoapWService } from "../../../common/components/utility/cordys-soap-ws";

declare var jQuery: any;

@Component({
    selector: 'report-component',
    templateUrl: 'app/bms/components/report/report.template.html',
})

export class ReportComponent implements OnInit {

    private routeComponent;
    private reportURL;
    private reportName;

    constructor(private _router: Router, private _routeParams: ActivatedRoute, private _soapService: CordysSoapWService) {

    }
    ngOnInit() {

        let thisRoute: any = this._router;
        let cur_route = thisRoute.currentRouterState.snapshot.url;
        let serverURL = "http://myvmsdevbpmapps.my.msig.com/home/Phase2/reports/bmsreports/";


        var responsePromise = this._soapService.callCordysSoapService("GetXMLObject", "http://schemas.cordys.com/1.0/xmlstore",
            { "key": "com/msig/bms/reports/ihub-server-details.xml" },
            null, null, false, null);
        responsePromise.done((data) => {
            if (data.tuple && data.tuple.old && data.tuple.old.Properties && data.tuple.old.Properties.bms_app_url) {
                serverURL = data.tuple.old.Properties.bms_app_url;
            }
        });


        if ("/Reports/RiskSummary/SummaryByRole" == cur_route) {
            this.reportName = "ReferredRiskSummaryByRole.htm";
        }
        else if ("/Reports/RiskSummary/SummaryByLOB" == cur_route) {
            this.reportName = "ReferredRiskSummaryByLOB.htm";
        }
        else if ("/Reports/RiskSummary/SummaryByLOBandRole" == cur_route) {
            this.reportName = "ReferredRiskSummaryByLOBandRole.htm";
        }
        else if ("/Reports/RiskSummary/SummaryDashboard" == cur_route) {
            this.reportName = "ReferredRiskSummaryDashboard.htm";
        }
        else if ("/Reports/RiskSummary/ConvertedDashboard" == cur_route) {
            this.reportName = "ConvertedDashboard.htm";
        }
        else if ("/Reports/RiskSummary/DeclinedDashboard" == cur_route) {
            this.reportName = "DeclinedDashboard.htm";
        }
        else if ("/Reports/RiskSummary/CoversionTrend" == cur_route) {
            this.reportName = "ConversionTrend.htm";
        }
        else if ("/Reports/PolicyServicingSummary/HigherManagementReport" == cur_route) {
            this.reportName = "MonthlyReportForHigherManagement.htm";
        }
        else if ("/Reports/PolicyServicingSummary/TurnAroundTimeReport" == cur_route) {
            this.reportName = "PolicyServicingTurnaroundTime.htm";
        }
        else if ("/Reports/PolicyServicingSummary/TurnAroundTimeReport-Renewal" == cur_route) {
            this.reportName = "PolicyServicingTurnaroundTime-Renewal.htm";
        }
        else if ("/Reports/PolicyServicingSummary/ProcessingTimeReport" == cur_route) {
            this.reportName = "AverageProcessingTimeDashboard.htm";
        }


        this.reportURL = serverURL + this.reportName;

        let chartHeight = 518;
        let iFrameHeight = (chartHeight * 2) + 200 + "px";
        let screenWidth = jQuery(window).innerWidth();

        //iFrameHeight = (screenWidth >= 1450) ? (chartHeight * 2 )+200+"px" : (chartHeight * 4 )+200+"px"; 
        iFrameHeight = 622 + "px";
        jQuery('#viewerpane1').css('height', iFrameHeight);

    }
}