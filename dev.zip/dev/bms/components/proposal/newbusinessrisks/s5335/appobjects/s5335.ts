/*
Change History	:

	No      Date          Description                               					  Changed By
	====    ==========    ===========                              						   ==========
	MD001   14/02/2017   MYS-2017-0920    -  ABC PA to be incorporated into BMS               MKU1		
    MD002   03/04/2018   mys-2018-0130	  -  Occupation code to be fetched from T9109 		  MKU1		 		   
	GA001   09/07/2018   MYS-2018-0443 - Age Checking for PA Products (T7253)    	KGA	

*/
import { Clause } from "../../appobjects/clause"
import { AppUtil } from '../../../../../../common/components/utility/apputil/app.util';
import { Nominee, NomineeDetails } from "../../appobjects/nomineeslist";
//import {PANPAItem} from "../../pa/appobjects/pa";
import { FinancialInterest } from '../../../../../../common/components/financialinterest/appobjects/financialInterest';
import { GSTDetails } from '../../appobjects/gstDetails';
import { FireRelatedCases } from '../../appobjects/relatedCase';
import { NBRisk } from '../../../appobjects/nbrisk';
import { PostedPrem } from '../../../proposalheader/appobjects/postedprem';
import { RiskHelper } from '../../../appobjects/riskhelper';
import { ReferredReason } from '../../../proposalheader/appobjects/referredreason';
import { S5335Validator } from '../../../validation/s5335.validator';
import { ReferralReasons } from '../../appobjects/referralReasons';//GA001

export class S5335 extends RiskHelper implements NBRisk {
    /**************************************************************
     *         Fields Used by proposal header
     **************************************************************/
    public sequenceNumber: string;
    public effectiveDate: string;
    public dateOfAttachment: string;
    public contractNumber: string = "";
    public contractType: string;
    public riskNumber: string;
    public riskType: string;
    public riskName: string;
    public terminationDate: string;

    /**************************************************************
     *              Fields Defaulted and Hidden
     **************************************************************/
    public RIRetentionCode: string;
    public ratingFlag: string;
    public SICurrency: string = "RM";
    public currencyRate: string = "1.0000000";
    public journey01: string = "";
    public journey02: string = "";
    public searchCode: string;
    public searchDescription: string;
    public RIMethod: string = "0";
    public RIRequired: string = "No";
    public hasClaimExperience: string = "N";
    public RIMethodSys: string = "0";
    public isRIOverWrittenByUW: string = "N";
    public identity: string = "";
    public minimumPremium: number = 0;
    public isSurveyNeeded: string = "N";

    /**************************************************************
     *              Fields used in UI
     **************************************************************/
    public insuredPerson: string;                //based on client name @ header only for Personal client
    public occupationCode: string;               //defaulted based on client
    public occupationDescription: string;        //defaulted based on client
    public insuredOccCode: string;               //Insured Occ Code - MD002
    public insuredOccDescription: string;        //Insured Occ Code - MD002
    public bigCapitalSumInsured: number = 0;
    public maxPerLifeLimit: number = 0;
    public maxPerConveyanceLimit: number = 0;
    public riskClassification: string = "Standard";
    public symRiskClassification: string = "";
    public conveyanceRiskClassification: string = "Standard";
    public riskClassificationReason: string = "";
    public occRiskClassification: string = "N";
    public noOfPersons: number = 0;
    public s5336Items: S5336Item;
    public rebate: number = 0;
    public rebateAmount: number = 0;
    public discountedPremium: number = 0;
    public GSTDetails: GSTDetails;
    public GST: number = 0; //6;//SAF MYS-2018-0629
    public gstAmount: number = 0;
    public totalPremium: number = 0;
    public clauses: Clause;
    public financialInterest: FinancialInterest;
    public relatedCases: FireRelatedCases;
    public relatedSumInsured: number = 0;
    //Hidden & Defaulted

    /**************************************************************
     *         Fields Used for calculation and showing in header
     **************************************************************/
    public capitalSumInsured: number = 0;
    public totalGrossCapacity: number = 0;
    public postingPremium: number = 0;
    public originalTotalPremium: number = 0;
    //for minimum premium calculations
    public basePostedPremiumAdj: number = 0;
    public isPOIConsidered: string = "N";
    public priority: string;
    public postedPremium: number = 0;
    public GT: string;
    public FI: string = "Y";
    public GP: string;
    public CL: string;
    public addRelatedCases: string = "Y";

    /**************************************************************
     *         Fields below are for handling posting related messages
     **************************************************************/
    public postingMessage: string = "";


    /**************************************************************
     *         Fields below are commented as not required
     **************************************************************/

    //public survey:Survey;
    public postedPremDetails: PostedPrem;
    public childRiskPath: string = "s5336Items.s5336Item";
    public childRiskIdentity: string;
    public riskClassificationReasons: ReferredReason;
    public gpText: string;
    public gpTextCount:string;//VK004
    //GA001 START
    public ageLimitFlag: string = "";
    public referralReasons: ReferralReasons;
    public ageMin: string = "";
    public ageMax: string = "";
    //GA001 END

    public SST: number = 0; //SST Code
    public sstAmount: number = 0;//SST Code
    public SSTLiveDate: string;//SST Code
    public GSTLiveDate: string;//SST Code
    public isGSTApplicable: boolean = true;//SST Code
    constructor() {
        super();
        this.s5336Items = new S5336Item();
        this.financialInterest = new FinancialInterest();
        this.GSTDetails = new GSTDetails();
        this.relatedCases = new FireRelatedCases();
        this.clauses = new Clause();
        this.riskClassificationReasons = new ReferredReason();
        this.referralReasons = new ReferralReasons();//GA001
    }

    public getInstance(valObj: S5335) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
            this.clauses = new Clause().getInstance(valObj.clauses);
            this.s5336Items = new S5336Item().getInstance(valObj.s5336Items);
            this.GSTDetails = new GSTDetails().getInstance(valObj.GSTDetails);
            this.riskClassificationReasons = new ReferredReason().getInstance(valObj.riskClassificationReasons);
            if (valObj.FI == "Y") {
                this.financialInterest = new FinancialInterest().getInstance(valObj.financialInterest);
            }
            if (valObj.addRelatedCases == "Y") {
                this.relatedCases = new FireRelatedCases().getInstance(valObj.relatedCases);
            }
            /*if(valObj.isSurveyNeeded == "Y"){
                this.survey = new Survey().getInstance(valObj.survey);
            }*/
            this.referralReasons = new ReferralReasons().getInstance(valObj.referralReasons);//GA001 
            if (valObj.isGSTApplicable != undefined && JSON.stringify(valObj.isGSTApplicable) != JSON.stringify("") && typeof (valObj.isGSTApplicable) == "string") {
                this.isGSTApplicable = Boolean(JSON.parse(valObj.isGSTApplicable));
            }

        }
        return this;
    }

    public getNewInstanceByCriteria(criteria: any) {
        let riskType = criteria.riskType;
        if (riskType == "PAC") {
            this.RIRetentionCode = "PA03";
            this.ratingFlag = "A";
            this.SICurrency = "RM";
            this.currencyRate = "1.0000000";
        }
        else if (riskType == "PAG") {
            this.RIRetentionCode = "PA03";
            this.ratingFlag = "A";
            this.SICurrency = "RM";
            this.currencyRate = "1.0000000";
        }
        else if (riskType == "PMA") {
            this.RIRetentionCode = "PA01";
            this.ratingFlag = "A";
            this.SICurrency = "RM";
            this.currencyRate = "1.0000000";
        }
        else if (riskType == "FPB") {//MD001
            this.RIRetentionCode = "PA01";
            this.ratingFlag = "A";
            this.SICurrency = "RM";
            this.currencyRate = "1.0000000";
        }
        else if (riskType == "PMB") {
            this.RIRetentionCode = "PA01";
            this.ratingFlag = "A";
            this.SICurrency = "RM";
            this.currencyRate = "1.0000000";
        }
        else if (riskType == "PMC") {
            this.RIRetentionCode = "PA01";
            this.ratingFlag = "A";
            this.SICurrency = "RM";
            this.currencyRate = "1.0000000";
        }
        else if (riskType == "PMP") {
            this.RIRetentionCode = "PA01";
            this.ratingFlag = "A";
            this.SICurrency = "RM";
            this.currencyRate = "1.0000000";
        }
        else if (riskType == "MSW") {
            this.RIRetentionCode = "PA01";
            this.ratingFlag = "A";
            this.SICurrency = "RM";
            this.currencyRate = "1.0000000";
        }
        else if (riskType == "MWP") {
            this.RIRetentionCode = "PA01";
            this.ratingFlag = "A";
            this.SICurrency = "RM";
            this.currencyRate = "1.0000000";
        }
        else if (riskType == "MWH") {
            this.RIRetentionCode = "PA01";
            this.ratingFlag = "A";
            this.SICurrency = "RM";
            this.currencyRate = "1.0000000";
        }
        else if (riskType == "MPA") {
            this.RIRetentionCode = "PA01";
            this.ratingFlag = "A";
            this.SICurrency = "RM";
            this.currencyRate = "1.0000000";
        }
        else if (riskType == "PAS") {
            this.RIRetentionCode = "PA03";
            this.ratingFlag = "A";
            this.SICurrency = "RM";
            this.currencyRate = "1.0000000";
            this.occupationCode = "7STU";
        }
        return this;
    }

    public getValidator() {
        return new S5335Validator(this);
    }
}

export class S5336Item {
    public s5336Item: S5336ItemDetails[] = [];
    public getInstance(valObj: S5336Item) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().handleArray(this, valObj, "s5336Item");
            for (let eachs5336Itm of this.s5336Item) {
                let s5336ItemObj = new S5336ItemDetails().getInstance(eachs5336Itm);
                this.s5336Item[this.s5336Item.indexOf(eachs5336Itm)] = s5336ItemObj;
            }
        }
        return this;
    }
}

export class S5336ItemDetails extends RiskHelper {
    /**************************************************************
     *         Fields Used by proposal header
     **************************************************************/
    public contractNumber: string = "";
    public riskType: string;
    public riskName: string = "";
    public dateStart: string;
    public effectiveDate: string;
    public lastDateEnd: string;
    public indicator: string;
    public inclusionDate: string;
    public endorsmentEndDate: string;
    public terminationDate: string;
    public GP: string;
    public NO: string;
    public FI: string;
    public CL: string;
    public DD: string;

    /**************************************************************
     *              Fields Defaulted and Hidden
     **************************************************************/
    //However there are no requirement about Referred risk in 5336, 
    //Date of Birth validation may convert the risk to referred risk.
    public noOfUnits: number = 1;
    public printCI: string = "N";

    /**************************************************************
     *              Fields used in UI
     **************************************************************/
    public itemNo: number;
    public riskClassification: string = "Standard";
    /******Insured Person Details section fields ****/
    public basis: string = "NAMED";
    public noOfPerson: string = "1";
    public seatNo: number = 0;
    public insuredPerson: string = "";
    public insuredSalutation: string;
    public occupationCode: string;
    public occupationDescription: string;
    public insuredOccCode: string;               //Insured Occ Code - MD002		
    public insuredOccDescription: string;        //Insured Occ Code - MD002
    public ratingClass: string = "";          //Label in UI shows as Occupation Class
    public planDescription: string;//MD001 Added by MKU1 to store plan description for FPB plans;MYS-2017-0920
    public IdProofNo: string = "";
    public NRIC: string = "";
    public dateOfBirth: string;
    public gender: string;
    public maritalStatus: string;
    public symRiskClassification: string = "";
    public riskClassificationReason: string = "";
    public insuredAge: number;
    public planAgeLimit: number;
    public occRiskClassification: string = 'N';
    public renewalBonusAmount: number;
    public renewalBonusPercentage: number;

    /******Renewal Bonus Plan (RBP) fields ****/
    public rbpCode: string = "";
    public rbpDesc: string = "";
    public rbpMethod: string = "";
    public rbpSIAdjustment: string = "";
    public rbpMaxYears: string = "";
    public rbpRestartRBPlan: string = "";

    /******Coverage Information section fields ****/
    public itemBenefits: Benefit;
    public additionalCoverDetails: AdditionalCoverageDetails;
    public plan: string;
    public additionalCode: string;

    public financialInterest: FinancialInterest;
    public nomineeDetails: NomineeDetails;
    public PADriverDetails: PADriverDetails;
    public S5336AddressDetails: S5336AddressDetails;
    public clauses: Clause;

    /**************************************************************
     *         Fields Used for calculation and showing in header
     **************************************************************/
    public entryBonusPercentage: number = 0;
    public entryBonusAmount: number = 0;
    public basicPremium: number = 0;
    public seatPremium: number = 0;     //Seat premium calculation is not required and is commented, However this field is used in calculations as 0
    public totalPremium: number = 0;
    public loadingDiscountPercentage: number = 0;
    public loadingDiscountAmount: number = 0;
    public postingPremium: number = 0;
    public totalAnnualPremium: number;
    public additionalLoading: string;
    public addditionalPremium: number = 0;
    public discountedPremium: number = 0;
    public rebate: number = 0;
    public rebateAmount: number = 0;
    public GST: number = 0;//6; //SAF MYS-2018-0629
    public gstAmount: number = 0;
    public originalTotalPremium: number = 0;
    public postedPremium: string;
    public sumInsured: number = 0;
    public rebatePercentage: number = 0;

    /**************************************************************
     *         Fields below are for handling posting related messages
     **************************************************************/
    public postingMessage: string = "";

    /**************************************************************
     *         Fields below are commented as not required
     **************************************************************/

    //public certificateNo:string;
    //public noOfCertificates:string;
    //public loanAmount:string;
    //public tenure:string;
    //public loanInterestRate:string;
    //public age:string;
    //public creditCardNumber:string;
    //public creditCardType:string;
    //public basicPremium:number=0;
    //public surChargeAmount:string;
    //public rebateAmount: number = 0;
    public childRiskPath: string;
    public childRiskIdentity: string = "itemNo";
    public riskClassificationReasons: ReferredReason;
    public gpText: string;
    //GA001 START
    public ageLimitFlag: string = "";
    public referralReasons: ReferralReasons;
    public ageMin: string = "";
    public ageMax: string = "";
    //GA001 END
    //VK007
    public insOccRiskClassification: string = "N";
    public SST: number = 0; //SST
    public sstAmount: number = 0;//SST
    constructor() {
        super();
        this.additionalCoverDetails = new AdditionalCoverageDetails();
        this.itemBenefits = new Benefit();
        this.financialInterest = new FinancialInterest();
        this.nomineeDetails = new NomineeDetails();
        this.PADriverDetails = new PADriverDetails();
        this.S5336AddressDetails = new S5336AddressDetails();
        this.clauses = new Clause();
        this.riskClassificationReasons = new ReferredReason();
        this.referralReasons = new ReferralReasons();//GA001
    }

    public getInstance(valObj: S5336ItemDetails) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
            this.itemBenefits = new Benefit().getInstance(valObj.itemBenefits);
            this.clauses = new Clause().getInstance(valObj.clauses);
            this.additionalCoverDetails = new AdditionalCoverageDetails().getInstance(valObj.additionalCoverDetails);
            this.nomineeDetails = new NomineeDetails().getInstance(valObj.nomineeDetails);
            this.PADriverDetails = new PADriverDetails().getInstance(valObj.PADriverDetails);
            this.S5336AddressDetails = new S5336AddressDetails().getInstance(valObj.S5336AddressDetails);
            this.riskClassificationReasons = new ReferredReason().getInstance(valObj.riskClassificationReasons);
            if (valObj.FI == "Y") {
                this.financialInterest = new FinancialInterest().getInstance(valObj.financialInterest);
            }
            this.referralReasons = new ReferralReasons().getInstance(valObj.referralReasons);//GA001			
        }
        return this;
    }
}

export class Benefit {
    public benefit: BenefitItem[] = [];

    public getInstance(valObj: Benefit) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().handleArray(this, valObj, "benefit");
        }
        return this;
    }
}
export class BenefitItem {
    public benefitIndex: number;
    public coverageCode: string;
    public coverageDescription: string;
    public benefits: string;
    public extraText: string;
    public newSI: string;
    public rate: string;
    public load: string;
    public premium: string;
}

export class PADriverDetails {
    public vehicalRegNumber: string;
    public modelCode: string = "";
    public makeCode: string;
    public description: string;
    public yearOfMake: string = "";
    public modelCodeNew: string = "";
    constructor() { }

    public getInstance(valObj: PADriverDetails) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
        }
        return this;
    }
}

export class S5336AddressDetails {
    public address1: string;
    public address2: string;
    public address3: string;
    public address4: string;
    public address5: string;
    public postCode: string;
    public addressType: string;
    public telephoneHome: string;
    public telephoneOffice: string;
    public faxNumber: string;
    constructor() { }

    public getInstance(valObj: S5336AddressDetails) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
        }
        return this;
    }
}

export class AdditionalCoverageDetails {

    public additionalCover: AdditionalCoverage[] = [];
    public additionalCoverTotal: number = 0;

    public getInstance(valObj: AdditionalCoverageDetails) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
            new AppUtil().handleArray(this, valObj, "additionalCover");
        }
        return this;
    }
}

export class AdditionalCoverage {

    public additionalCode: string;
    public additionalCover: string;
    public sumInsured: string;
    public rate: string;
    public additionalLoading: string;
    public addditionalPremium: string;
    constructor() { }
}
