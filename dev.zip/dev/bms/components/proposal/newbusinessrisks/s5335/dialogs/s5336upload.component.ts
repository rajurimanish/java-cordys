/* 
 *
 * Change History:		
 * 
 * No       Date            Description                                             Changed By
 * ====     ==========      ===========                                             ==========
 * VK007    21/05/2019 		MYS-2018-0993 NGA File Upload + Security Fixes          VKR
 */
import { LOV_Field, LOVDropDownService, SearchFilter } from "../../../../../../common/services/lovdropdown/lovdropdown.service";//VK007
import { GetLOVData, SearchAdvancedConfig, Filter } from '../../../../../../common/components/utility/search/search.requests';//VK007
import { Component, ElementRef, OnInit, NgZone } from "@angular/core";
import { CordysSoapWService } from '../../../../../../common/components/utility/cordys-soap-ws';
import { ApplicationUtilService } from "../../../../../../common/services/application.util.service";
import { AlertMessagesService } from '../../../../../../common/components/utility/alertmessage/alertmessages.service';
import { AlertMessage } from '../../../../../../common/components/utility/alertmessage/alertmessages.model';
import { S5335, S5336ItemDetails, S5336Item } from '../appObjects/s5335';
import { ProgressBarComponent } from '../../../../../../common/components/utility/progressbar/progressbar.component';
import { ReferralReasons, ReferralReason } from '../../appobjects/referralReasons';
import { ReferredReason, Reasons } from '../../../proposalheader/appobjects/referredreason';
declare var jQuery: any;
declare var moment: any;
@Component({
    selector: "s5336-upload-component",
    templateUrl: "app/bms/components/proposal/newbusinessrisks/s5335/dialogs/s5336upload.template.html",
    inputs: ['datainput', 'closeDialog', 'parentCompPRMS']
})
export class S5336UploadComponent implements OnInit {

    public datainput: any;
    public closeDialog: Function;
    public parentCompPRMS: any;

    private elementRef: ElementRef;
    private enableAttachmentError: boolean = false;
    private globalValidationMessage: string = "";
    private attachmentName;
    private attachmentSize: number;
    private type;
    private encodeFileContent: string;
    private fileName;
    public uploadedFiles = [];
    public uploadPath = "";
    public records: any;
    public disableButtons: boolean = false;
    public showRecordCountMessage: boolean = false;
    public recordCountMessage = "";
    //VK007
    //public uploadPath="";
    private _ageLimitRec : any;
    private application;
    private docType;
    private fileSize;
    private riskFlag : string = "Y";
    constructor(private _elRef: ElementRef, private _cordysService: CordysSoapWService, private _appUtilService: ApplicationUtilService, public _alertMsgService: AlertMessagesService, private lovDropDownService: LOVDropDownService) { }

    ngOnInit() {
        this.getUploadPath();
    }
    getUploadPath() {
        this._cordysService.callCordysSoapService("GetUploadConfig", "http://schemas.cordys.com/bmsintegrationapp", "", this.configSuccessHandler, this.writeErrorHandler, true, { comp: this });
    }
    configSuccessHandler(data, scopeObject) {
        if (data.tuple.old.GetUploadConfig.GetUploadConfig != "") {
            scopeObject.comp.uploadPath = data.tuple.old.GetUploadConfig.GetUploadConfig;
        }
    }
    private CloseDialog() {
        this.closeDialog(this.records, this.parentCompPRMS);
    }

    rowClick(idx) {

    }
    showErrorMessage(idx) {

    }
    expandOrCollapse(idx) {
        //alert(idx);
        this.records.s5336Items.s5336Item[idx].expandBenfitIndicator = this.records.s5336Items.s5336Item[idx].expandBenfitIndicator == true ? false : true;
    }
    private cleardata() {
        this.records = null;
        this.enableAttachmentError = false;
        this.globalValidationMessage = "";
        this.attachmentName = "";
        this.showRecordCountMessage = false;
        this.recordCountMessage = "";
    }
    private expandAll() {
        if (this.records != undefined) {
            for (let item of this.records.s5336Items.s5336Item) {
                item.expandBenfitIndicator = true;
            }
        }
    }
    private collapseAll() {
        if (this.records != undefined) {
            for (let item of this.records.s5336Items.s5336Item) {
                item.expandBenfitIndicator = false;
            }
        }
    }
    private confirmdata() {
        let isValidationFailed = "false";
        if (this.records == undefined) {
            this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "No Data to import.", 5000));
            return;
        }
        for (let item of this.records.s5336Items.s5336Item) {
            if (item.isValidationFailed == "true") {
                isValidationFailed = "true";
                break;
            } else {
                continue;
            }
        }
        if (isValidationFailed == "true") {
            this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Validation failed for 1 or more items. Please clear validations errors in excel file and upload again.", 5000));
        } else {
            //push records into main object
            //this.checkAgeReferredRisk(this.parentCompPRMS.comp);

            let riskFilter = (this.parentCompPRMS.comp.riskObj.riskType.length == 2) ? this.parentCompPRMS.comp.riskObj.riskType + ' ' : this.parentCompPRMS.comp.riskObj.riskType;//GA001
            let request: GetLOVData = new GetLOVData().getRequest("ALL", "MED", "ALL", "ALL", "ALL", "ALL", "Referral Age Limits", "LOV");
            request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
			request.ADVANCE_CONFIG_XML.FILTERS = new Filter();
            request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({ "@FIELD_NAME": 'DESCITEM', "@FIELD_VALUE": riskFilter, '@OPERATION': 'EQ', '@CONDITION': 'AND' });
            let responsePromise = this._cordysService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, null, null, false, this);
            responsePromise.success((data) => {
                if (data.tuple) {
					 this._ageLimitRec = data.tuple.old.T7253;
                } else {
                    this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, data.message.text, 5000));
                }
            });
            responsePromise.error((data) => {
                this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, data.message.text, 5000));
            });


            
            for (let item of this.records.s5336Items.s5336Item) {
                let news5336Item = new S5336ItemDetails();
                news5336Item.itemNo = this.parentCompPRMS.comp.riskObj.s5336Items.s5336Item.length + 1;
                news5336Item.dateStart = item.effectiveDate;
                news5336Item.lastDateEnd = item.lastDateEnd;
                news5336Item.riskType = item.riskType;
                news5336Item.riskName = item.riskName;
                news5336Item.insuredPerson = item.insuredPerson;
                news5336Item.NRIC = item.NRIC;
                news5336Item.IdProofNo = item.IdProofNo;
                news5336Item.dateOfBirth = item.dateOfBirth;
                news5336Item.insuredOccCode = item.insuredOccCode;
                news5336Item.insuredOccDescription = item.insuredOccDescription;
                news5336Item.gender = item.gender;
                news5336Item.maritalStatus = item.maritalStatus;
                news5336Item.plan = item.plan;
                news5336Item.ratingClass = item.ratingClass;
                news5336Item.sumInsured = item.sumInsured;
                news5336Item.ratingClass = item.ratingClass
                news5336Item.itemBenefits = item.itemBenefits;
                news5336Item.totalAnnualPremium = item.totalAnnualPremium;
                news5336Item.basicPremium = item.basicPremium;
                news5336Item.postingPremium = item.postingPremium;
                news5336Item.symRiskClassification = item.symRiskClassification;
                news5336Item.riskClassification = item.riskClassification;
                news5336Item.insOccRiskClassification = item.riskClassification;
                news5336Item.riskClassificationReason = item.riskClassificationReason;
                       
                this.parentCompPRMS.comp.riskObj.s5336Items.s5336Item.push(news5336Item);
                this.setAgeReferredRiskForInsured(this.parentCompPRMS.comp.riskObj.s5336Items.s5336Item[news5336Item.itemNo - 1],this._ageLimitRec,this.parentCompPRMS.comp);
            }
            this.parentCompPRMS.comp.riskObj.noOfPersons = this.parentCompPRMS.comp.riskObj.s5336Items.s5336Item.length;
            this.parentCompPRMS.comp.setTotalPremium();
            this.parentCompPRMS.comp.resetItmNumber();
            this.parentCompPRMS.comp.setTotalSI();
            this.parentCompPRMS.comp.riskObj.noOfPersons = this.parentCompPRMS.comp.riskObj.s5336Items.s5336Item.length;
            
            this.parentCompPRMS.comp.checkReferredRisk(this.parentCompPRMS.comp);
            this.CloseDialog();
        }

    }
    //VK007
    private checkAgeReferredRisk(comp) {
        let riskFilter = (comp.riskObj.riskType.length == 2) ? comp.riskObj.riskType + ' ' : comp.riskObj.riskType;//GA001
        let referralAgeLimitNodes = this.lovDropDownService.createFilter([new SearchFilter("DESCITEM", riskFilter, "EQ", "AND")]);//
        let lovFields = [
            new LOV_Field("ALL", "MED", "ALL", "ALL", "ALL", "ALL", "Referral Age Limits", "LOV", referralAgeLimitNodes, "T7253", "referralAgeLimits", "callbackReferralAgeLimits")
        ];

        this.lovDropDownService.util_populateLOV(lovFields, this);

    }

    callbackReferralAgeLimits(scopeObject) {
        this._ageLimitRec = this.lovDropDownService.lovDataList.referralAgeLimits.find((_data) => _data.DESCITEM == scopeObject.parentCompPRMS.comp.riskObj.riskType);

    }

    setAgeReferredRiskForInsured(riskObj,_ageLimitRec,scopeObject) {
        
        this.calculateAge(riskObj);
        riskObj.ageLimitFlag = "";
        let _reasons = new Reasons();
        if (_ageLimitRec && riskObj.dateOfBirth && riskObj.insuredOccCode) {
            let _minAgeLimit = 0;
            let _maxAgeLimit = 0;
            let _minAgeLimitInd = 'Y';
            let _maxAgeLimitInd = 'Y';

            let _adultMinAgeLimit = (_ageLimitRec.ZAGELMT03) ? parseInt("" + _ageLimitRec.ZAGELMT03) : 0;
            let _adultMaxAgeLimit = 0;
            if ("Renewal" == scopeObject.caseInfo.businessFunction) {
                _adultMaxAgeLimit = (_ageLimitRec.ZAGELMT07) ? parseInt("" + _ageLimitRec.ZAGELMT07) : 0;
            } else {
                _adultMaxAgeLimit = (_ageLimitRec.ZAGELMT05) ? parseInt("" + _ageLimitRec.ZAGELMT05) : 0;
            }

            let _chidldMinAgeLimit = (_ageLimitRec.ZAGELMT04) ? parseInt("" + _ageLimitRec.ZAGELMT04) : 0;
            let _chidldMaxAgeLimit = (_ageLimitRec.ZAGELMT06) ? parseInt("" + _ageLimitRec.ZAGELMT06) : 0;

            if (_chidldMinAgeLimit > 0 && _chidldMaxAgeLimit > 0 && (riskObj.insuredOccCode == '7STU' || riskObj.insuredOccCode == '7CLD')) {
                _minAgeLimit = _chidldMinAgeLimit;
                _maxAgeLimit = _chidldMaxAgeLimit;
                _minAgeLimitInd = (_ageLimitRec.ZAGEIND02) ? _ageLimitRec.ZAGEIND02 : "Y";
                _maxAgeLimitInd = (_ageLimitRec.ZAGEIND03) ? _ageLimitRec.ZAGEIND03 : "Y";
            }
            else {

                _minAgeLimit = _adultMinAgeLimit;
                _maxAgeLimit = _adultMaxAgeLimit;
                if (_chidldMinAgeLimit == 0 || _chidldMaxAgeLimit == 0) {
                    _minAgeLimitInd = (_ageLimitRec.ZAGEIND02) ? _ageLimitRec.ZAGEIND02 : "Y";
                    _maxAgeLimitInd = (_ageLimitRec.ZAGEIND03) ? _ageLimitRec.ZAGEIND03 : "Y";
                }
            }

            if (_maxAgeLimitInd == 'D') {
                if (riskObj && riskObj.dateStart && riskObj.dateOfBirth) {
                    let _inclusionDate = moment(riskObj.dateStart, "YYYY-MM-DD");
                    let _insuredDOB = moment(riskObj.dateOfBirth, "YYYY-MM-DD");

                    let _ageInDays = moment.duration(_inclusionDate.diff(_insuredDOB)).asDays();
                    if (_ageInDays > _maxAgeLimit) {
                        riskObj.ageLimitFlag = "G";
                    }
                }
            }
            else if (Number(riskObj.insuredAge) > _maxAgeLimit) {
                riskObj.ageLimitFlag = "G";
            }

            if (riskObj.ageLimitFlag != "G") {
                if (_minAgeLimitInd == 'D') {
                    if (riskObj && riskObj.dateStart && riskObj.dateOfBirth) {
                        let _inclusionDate = moment(riskObj.dateStart, "YYYY-MM-DD");
                        let _insuredDOB = moment(riskObj.dateOfBirth, "YYYY-MM-DD");

                        let _ageInDays = moment.duration(_inclusionDate.diff(_insuredDOB)).asDays();
                        if (_ageInDays < _minAgeLimit) {
                            riskObj.ageLimitFlag = "L";
                        }
                    }
                }
                else if (Number(riskObj.insuredAge) < _minAgeLimit) {
                    riskObj.ageLimitFlag = "L";
                }
            }

            riskObj.ageMin = _minAgeLimit;
            riskObj.ageMax = _maxAgeLimit;

            if(riskObj.riskClassificationReason) {
                _reasons.reason.push(riskObj.riskClassificationReason);
                riskObj.riskClassificationReasons.reasons = _reasons;

            }        
            if (riskObj.ageLimitFlag == "G") {
                riskObj.symRiskClassification = "Referred";
                riskObj.riskClassification = "Referred";
                if(!riskObj.riskClassificationReason) {
                    riskObj.riskClassificationReason = "Insured Age is exceeded maximum age";
                }
                _reasons.reason.push("Insured Age is exceeded maximum age");
                riskObj.riskClassificationReasons.reasons = _reasons;
            } else if (riskObj.ageLimitFlag == "L") {
                riskObj.symRiskClassification = "Referred";
                riskObj.riskClassification = "Referred";
                if(!riskObj.riskClassificationReason) {
                    riskObj.riskClassificationReason = "Insured Age is less than minimum age";
                } 
                _reasons.reason.push("Insured Age is less than minimum age");
                riskObj.riskClassificationReasons.reasons = _reasons;
           
            }
            else if (riskObj.ageLimitFlag == "") {
            riskObj.ageLimitFlag = "VALID";
            }
    
            if(riskObj.riskClassification == "Referred" || riskObj.riskClassification == "Declined") {
            if(this.riskFlag = 'Y') {
                if(scopeObject.riskObj.riskClassificationReasons && scopeObject.riskObj.riskClassificationReasons.reasons && scopeObject.riskObj.riskClassificationReasons.reasons.reason.length == 0) {
                let _reasons1 = new Reasons();                  
                _reasons1.reason.push("System marked as Referred");
                scopeObject.riskObj.riskClassificationReasons.reasons = _reasons1;
                this.riskFlag = 'N';
                }
            }
            
        }
        
        //Test1 End
    }
    

    }
    

    calculateAge(riskObj) {
        if (riskObj && riskObj.dateStart && riskObj.dateOfBirth) {
            let _inclusionDate = moment(riskObj.dateStart, "YYYY-MM-DD");
            let _insuredDOB = moment(riskObj.dateOfBirth, "YYYY-MM-DD");
            // let age = _inclusionDate.diff(_insuredDOB, 'years'); //Redmine#2633- Age should be calculate on Year (not on date) for all medical products.
            let dobYear = _insuredDOB.year();
            let inclDtYear = _inclusionDate.year();
            let age = inclDtYear - dobYear;

            riskObj.insuredAge = age;
        }
        else {
            riskObj.insuredAge = 0;
        }
    }

    //VK007 End

    private onFileSelect(event) {
        /*
        let i = 0;
        //this.type = document.getElementById("docType");
        //this.type =this.type.options[this.type.selectedIndex].value;
        let selectedFileName = event.currentTarget.files[0].name;
        let fileExtension = selectedFileName.substr(selectedFileName.lastIndexOf(".") + 1);

        if (fileExtension != "xls" && fileExtension != "xlsx") {
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Please upload only excel files", 3000));
            event = null;
            selectedFileName = null;
            return;
        }


        this.attachmentName = selectedFileName;
        this.attachmentSize = event.currentTarget.files[0].size;
        if (this.attachmentSize - 0 > 10485760) {
            this.enableAttachmentError = true;
            this.globalValidationMessage = "File Size should be less than 10MB";
        }
        else {
            this.records = null;
            this.enableAttachmentError = false;
            this.globalValidationMessage = "";
            //this.attachmentName="";
            this.showRecordCountMessage = false;
            this.recordCountMessage = "";
            this.uploadDocument();
        } */
        ProgressBarComponent.show('File upload is in Progress', { dialogSize: 'm', progressType: 'primary' });
        let selectedFile = (<HTMLInputElement>document.getElementById("fileSelect")).files[0];
        let reader = new FileReader();
        this.fileName = event.currentTarget.files[0].name;
        this.fileSize = event.currentTarget.files[0].size;
        this.docType = this.fileName.substr(this.fileName.lastIndexOf(".") + 1);
        reader.onload = this.getFileContent(event, this);
        reader.readAsDataURL(selectedFile);
    }

    private TriggerEvent() {
        jQuery(this._elRef.nativeElement).find("input[type='file']").val(null);
        jQuery(this._elRef.nativeElement).find("input[type='file']").click();
    }
    private showalert(t) {
        this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Uploading.Please wait", t));
    }
    uploadDocument() {
        this.disableButtons = true;
        var selectedFile = (<HTMLInputElement>document.getElementById("fileSelect")).files[0];
        let reader = new FileReader();
        this.showalert(3000);
        reader.onload = this.getFileContent(event, this);
        reader.readAsDataURL(selectedFile);
    }
    /* VK007
    private getFileContent(e, originalObject) {
        return function (event) {
            let temp = event.target.result
            originalObject.encodeFileContent = temp.substr(temp.indexOf(";base64,") + 8);
            //frame new attachment with properties

            var responsePromise = originalObject._cordysService.callCordysSoapService("WriteFile", "http://schemas.cordys.com/1.0/ac/FileConnector", originalObject.getUploadParameter(), originalObject.writeSuccessHandler, originalObject.writeErrorHandler, true, { comp: originalObject, callerObject: null });
            responsePromise.done((data) => {

            });


        }

    private getUploadParameter() {
        let date = new Date();
        //let folderPath = "../s5336uploads/";
        this.fileName = this.attachmentName.substring(0, this.attachmentName.lastIndexOf(".")) + " - " + date.getDate() + "-" + date.getMonth() + "-" + date.getFullYear() + "-" + date.getTime() + this.attachmentName.substring(this.attachmentName.lastIndexOf("."), this.attachmentName.length);
        if (this.uploadPath != undefined || this.uploadPath != "")
            return {
                "filename": this.uploadPath + this.fileName,
                "append": "false",
                "encoded": "true",
                "data": this.encodeFileContent
            }
    }
    }
    */
    //VK007
    private uploadFileRequestParams() {
        return {
            "application": "BMS",
            "data": this.encodeFileContent,
            "fileName": this.fileName,
            "fileSize": this.fileSize,
            "fileType": this.docType,
            "uploadType": "NGA"
        }
    }
    private getFileContent(e, scopeObject) {
        return function (event) {
            let temp = event.target.result;
            scopeObject.encodeFileContent = temp.substr(temp.indexOf(";base64,") + 8);
            let input = scopeObject.uploadFileRequestParams();
            //let responsePromise = scopeObject._cordysService.callCordysSoapService("uploadFile", "http://schemas.cordys.com/default",scopeObject.writeSuccessHandler,scopeObject.writeErrorHandler, true, {comp:scopeObject,callerObject:null});
            // responsePromise.done((data) =>{   }
            let responsePromise = scopeObject._cordysService.callCordysSoapService("uploadFile", "http://schemas.cordys.com/default", input, null, null, true, scopeObject);
            responsePromise.success((data) => {
                ProgressBarComponent.hide();
                if (data.status.text == 'Success') {
                    scopeObject.readDataFromUploadedFile("Uploaded", scopeObject, data.filePName.text);
                } else {
                    scopeObject._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, data.message.text, 5000));
                }
            });
            responsePromise.error((data) => {
                scopeObject._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, data.message.text, 5000));
                ProgressBarComponent.hide();
            });
        }
    }
    //VK007 End
    writeSuccessHandler(data, scopeObject) {
        scopeObject.comp.readDataFromUploadedFile("Uploaded", scopeObject);
    }
    writeErrorHandler(response, status, errorText, scopeObject) {
        scopeObject.comp.disableButtons = false;
        scopeObject.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, response.responseJSON.faultstring.text, 2000));

    }
    prepareInsuredDataForDuplicateValidation() {
        let insuredXMLData = "<insuredData>";
        for (let insuredItem of this.parentCompPRMS.comp.riskObj.s5336Items.s5336Item) {
            insuredXMLData = insuredXMLData + "<insured>" + insuredItem.insuredPerson + "#" + insuredItem.IdProofNo + "#" + insuredItem.NRIC + "</insured>";
        }
        insuredXMLData = insuredXMLData + "</insuredData>";
        return insuredXMLData;
    }
    private readDataFromUploadedFile(status: string, scopeObject, fileName: string) {
        let insuredData = this.prepareInsuredDataForDuplicateValidation();
        let UploadInput = {
            "FilePath": fileName,
            "TemplateName": "",
            "riskType": this.parentCompPRMS.comp.riskObj.riskType,
            "productType": this.parentCompPRMS.comp.headerInfo.contractType,
            "ItemFromDate": this.parentCompPRMS.comp.headerInfo.effectiveDate,
            "ItemToDate": this.parentCompPRMS.comp.headerInfo.endDate,
            "InsuredDataFromUI": insuredData,
            "Extra1": this.parentCompPRMS.comp.riskObj.riskName,
            "Extra2": "",
            "Extra3": "",
            "Extra4": ""
        };
        var responsePromise = this._cordysService.callCordysSoapService("UploadInsuredDetails_5336", "http://schemas.cordys.com/bmsintegrationapp", UploadInput, null, null, true, null);
        responsePromise.done((data) => {
            let ary = [];
            this.records = JSON.parse(data.tuple.old.UploadInsuredDetails_5336.UploadInsuredDetails_5336);
            if (this.records.s5336Items.s5336Item.length <= 0) {
                this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "No Data in uploaded file.", 2000));
            } else {
                this.showRecordCountMessage = true;
                let successCount = this.records.s5336Items.s5336Item.filter(function (el) { return el.isValidationFailed == "false"; }).length;
                let failedCount = this.records.s5336Items.s5336Item.filter(function (el) { return el.isValidationFailed == "true"; }).length
                this.recordCountMessage = "<span class='alert-info'>Total Records: <B>" + this.records.s5336Items.s5336Item.length + "</B></span><span class='alert-danger'> Failed Records : <B>" + failedCount + "</B>.</p></span>";
            }
            this.disableButtons = false;
        });
        responsePromise.fail((data) => {
            this.enableAttachmentError = true;
            this.disableButtons = false;
            this.globalValidationMessage = "Error occured while reading file. " + data.responseJSON.faultstring.text;
            this.showRecordCountMessage = false;
            this.recordCountMessage = "";

        });
    }

}