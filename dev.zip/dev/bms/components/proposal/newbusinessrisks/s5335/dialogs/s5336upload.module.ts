import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { S5336UploadComponent } from './s5336upload.component';

@NgModule({
    imports: [CommonModule, FormsModule, ReactiveFormsModule],
    declarations: [S5336UploadComponent],
    exports: [S5336UploadComponent]
})
export class S5336UploadModule { }