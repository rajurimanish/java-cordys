/*
Change History	:

	No      Date          Description                                        Changed By
	====    ==========    ===========                                         ==========
	    	
    MD002   14/03/2018    UAT issue raised during SAF MYS-2017-0920
                          where risk classification is NOT being set on           MKU1
                          loading the risk.                 
    VK007    21/05/2019   MYS-2018-0993 NGA File Upload + Security Fixes          VKR

    YPK001 23/09/2019     MYS-2019-0675 Document Validation for Co-outwards       PKU1
 *                         case before sending to PPHO		
 *  
 */
// import {Component,OnInit,DynamicComponentLoader,Injector,ElementRef, AfterViewInit,EventEmitter,ApplicationRef } from 'angular2/core';
import { Component, OnInit, ViewChild, ElementRef, EventEmitter, AfterViewInit, ViewContainerRef } from '@angular/core';
import { DCLInput, CustomDCLService } from '../../../../../common/services/customdcl.service';
import { S5335, S5336ItemDetails, S5336Item } from './appObjects/s5335';
import { S5336UploadComponent } from './dialogs/s5336upload.component';
import { LOV_Field, LOVDropDownService, SearchFilter } from "../../../../../common/services/lovdropdown/lovdropdown.service";
import { GetLOVData, SearchAdvancedConfig, Filter } from '../../../../../common/components/utility/search/search.requests';
// import {S5335RiskComponent} from "./s5335risk.component";
// import {DatePicker} from '../../../../../common/components/utility/date/datepicker.component';
// import {SelectBox} from "../../../../../common/components/utility/selectbox/select-box";
declare var Observer: any;
import { PaginationPipe } from '../../../../../common/components/utility/pagination/filtertable.pipe';
import { FilterTableContentPipe } from '../../../../../common/components/utility/pagination/filtercontent.pipe';
// import {PremiumPostingComponent} from '../uimodules/premiumposting.componet';
import { ProposalHeader } from '../../proposalheader/appobjects/proposalheader';
import { ClientDetails } from '../../../../../common/components/client/appobjects/client';
import { CordysSoapWService } from "../../../../../common/components/utility/cordys-soap-ws";
import { AlertMessagesService } from '../../../../../common/components/utility/alertmessage/alertmessages.service';
import { AlertMessage } from '../../../../../common/components/utility/alertmessage/alertmessages.model';
//import {Survey} from '../appobjects/survey';
import { ModalInput } from "../../../../../common/components/utility/modal/modal";
import { Clause } from "../appobjects/clause";
import { ClausesComponent } from "../uimodules/clauses.component";
import { RelatedCaseComponent } from "../uimodules/relatedcase.component";
import { FireRelatedCases, RelatedCases } from '../appobjects/relatedCase';
import { ApplicationUtilService } from "../../../../../common/services/application.util.service";
import { BMSUtilService } from "../../../../services/bms.util.service";
import { RIService } from '../services/ri.service';
import { RiskClassificationService } from "../services/riskcls.service";
import { BMSConstants } from '../../../common/constants/bms_constants';
import { ActivatedRoute } from '@angular/router';

declare var jQuery: any;
declare var numeral: any;
declare var moment: any;

@Component({
    selector: 'S5335-component',
    templateUrl: 'app/bms/components/proposal/newbusinessrisks/s5335/s5335.template.html',
    inputs: ['riskObj', 'clientDetails', 'headerInfo'],
    outputs: ["onPremiumChange", 'onSIChange', 'onRiskClsChange', 'onRtngFlgChange']
})
export class S5335Component implements OnInit {
    @ViewChild(ClausesComponent) private clausesComp: ClausesComponent;
    private collapseClausesInfo: boolean = true;
    private relatedCollapse: boolean = false;
    public defaultClauseCode: string = "";

    private surInfoCollapse: boolean = true;
    public driverDetailList: any[] = [];
    public riskObj: S5335;
    public clientDetails: ClientDetails;
    public headerInfo: ProposalHeader;
    public currentRiskObj: any;
    private el: HTMLElement;
    public selectedRiskComponent: any;
    onPremiumChange = new EventEmitter<any>();
    onRiskClsChange = new EventEmitter<any>();
    onSIChange = new EventEmitter<any>();
    onRtngFlgChange = new EventEmitter<any>();
    public search: String = "";
    public position = 1;
    public sizeObj = { length: 0, orglength: 0 };
    public contentSizeObs: any;
    public itemPerPage = 5;
    public maxPageCount = 5;
    public disableForm = 'N';
    public colspanVal = 4;
    public noRecordsColSpan = 8;

    public siFormat: string = "000";
    public premiumFormat: string = "000.00";
    public rateFormat: string = "0.00000";
    public percentFormat: string = "0.00";

    private isUnderWriter = "N";
    private isRIMethodEditable = "Y";

    public isAnyInsuredReferred: boolean = false;
    public isAnyInsuredDeclined: boolean = false;
    public collapsableObject = {
        "isCollapsedMode": false,
        "collapseClausesInfo": true
    }
    private isGeneralPageCollapsed: boolean = false;

    @ViewChild('S5336RisksModal', { read: ViewContainerRef }) contentArea: ViewContainerRef;


    constructor(private lovDropDownService: LOVDropDownService, private _soapService: CordysSoapWService, public _alertMsgService: AlertMessagesService, el: ElementRef, private _dcl: CustomDCLService, private _appUtilService: ApplicationUtilService, private _bmsUtilService: BMSUtilService, private _riService: RIService, public riskClassificationService: RiskClassificationService, private _activatedRoute: ActivatedRoute) {
        //	this.populateLovs();
        this.el = el.nativeElement;
    }

    ngAfterViewInit() {
        //this.setFormDisabled();
        if (this.headerInfo.asyncPostingStatus == "InProgress") {
            this.disableForm = "Y";
        } else if (this.riskObj.contractNumber != "") {
            this.disableForm = "Y";
        }
        else {
            this.disableForm = "N";
        }
        //START YPK001
        let rIndex = 0;
        if ((this.headerInfo.CoInsurance == 'Y' && this.riskObj.riskNumber == '1') && (["MyTasks", "MyDrafts"].indexOf(this._activatedRoute.snapshot.params['component']) >= 0 || Object.keys(this._activatedRoute.snapshot.params).length == 0)) {
            if (this.headerInfo.coInsuranceDetails.coInsurance.length == 1) {
                if (!(this.headerInfo.coInsuranceDetails.coInsurance[0].coInsuranceindicator == 'L' && this.headerInfo.coInsuranceDetails.coInsurance[0].sharePercentage == '100')) {
                    rIndex = this.riskObj.clauses.clause.map(function (item) { return item.clauseCode; }).indexOf("COIN");
                    if (rIndex == -1)
                        this.setClauses(["COIN"], false);
                }
            }
            else {
                rIndex = this.riskObj.clauses.clause.map(function (item) { return item.clauseCode; }).indexOf("COIN");
                if (rIndex == -1)
                    this.setClauses(["COIN"], false);
            }
        }
    }
    //END YPK001

    setFormDisabled() {
        if (jQuery("#bmsForm").prop("disabled") == true) {
            this.disableForm = "Y";
        }
    }

    ngOnInit() {
        this.populateLovs();
        this.defaultOccupationAndInsuredName();
        this.colspanVal = (["MSW", "MWP", "MWH", "MPA"].indexOf(this.riskObj.riskType)) ? 4 : 5;
        this.noRecordsColSpan = (["MSW", "MWP", "MWH", "MPA"].indexOf(this.riskObj.riskType)) ? 7 : 8;
        if (this.riskObj.contractNumber != "") {
            this.disableForm = "Y";
        }
        this._appUtilService.isUnderWriterUser().subscribe((data) => {
            this.isUnderWriter = data;
            this.setRIMethodEditableFlag();
        });

        //SST Code
        if (["MyTasks", "MyDrafts"].indexOf(this._activatedRoute.snapshot.params['component']) >= 0 || Object.keys(this._activatedRoute.snapshot.params).length == 0) {
            let respObj = this._bmsUtilService.getTAXDetails();
            if (respObj != undefined && respObj != "") {
                this.headerInfo.SSTTaxRate = Number(respObj[0].old.ITEMPF.GST);
                this.headerInfo.GSTTaxRate = Number(respObj[1].old.ITEMPF.GST);

                this.riskObj.SST = Number(this.headerInfo.SSTTaxRate);
                this.riskObj.GST = Number(this.headerInfo.GSTTaxRate);
            }

            this.headerInfo = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo;
            this.riskObj.SSTLiveDate = (this.riskObj.SSTLiveDate == undefined) ? this.headerInfo.SSTLiveDate : this.riskObj.SSTLiveDate;
            if (this.riskObj.SSTLiveDate == undefined || this.riskObj.SSTLiveDate == "") {
                let tempRespObj = this._bmsUtilService.getLiveDate();
                this.riskObj.GSTLiveDate = tempRespObj[0].old.ITEMPF.LIVEDATE;
                this.riskObj.SSTLiveDate = tempRespObj[1].old.ITEMPF.LIVEDATE;
                if (this.headerInfo.SSTLiveDate == undefined || this.headerInfo.SSTLiveDate == "") {
                    this.headerInfo.SSTLiveDate = this.riskObj.SSTLiveDate;
                }
                if (this.headerInfo.GSTLiveDate == undefined || this.headerInfo.GSTLiveDate == "") {
                    this.headerInfo.GSTLiveDate = this.riskObj.GSTLiveDate;
                }
            }
            if (moment(this.headerInfo.effectiveDate, "YYYY-MM-DD").format("YYYYMMDD") >= moment(this.riskObj.SSTLiveDate, "YYYY-MM-DD").format("YYYYMMDD")) {
                this.riskObj.isGSTApplicable = false;
            } else {
                this.riskObj.isGSTApplicable = true;
            }
        }
        //End
    }
    handleRiskClassification(comp) {
        this.riskClassificationService.setRiskClassification(comp.riskObj.riskNumber, "N", "-1", "").subscribe();
    }

    handleSubRiskClassification(comp, itemNo) {
        this.riskClassificationService.setRiskClassification(comp.riskObj.riskNumber, "N", itemNo, "").subscribe();
    }

    /************
    *Collapse and Expand related operations
    ************/
    private expandContent(part) {

        this.collapsableObject[part] = false;
        event.stopPropagation();
    }

    private collapseContent(part) {
        this.collapsableObject[part] = true;
        event.stopPropagation();
    }

    public expandOrCollapse(part) {
        if (this.collapsableObject[part] == false) {
            this.collapsableObject[part] = true;
        } else {
            this.collapsableObject[part] = false;
        }
    }

    defaultOccupationAndInsuredName() {
        if (this.riskObj.occupationCode == undefined || this.riskObj.occupationCode == "") {
            if (this.clientDetails.client.genericDetails.clienttype == 'P') {
                this.riskObj.insuredPerson = this.clientDetails.client.personalClientDetails.Name;
                this.riskObj.occupationCode = this.clientDetails.client.personalClientDetails.occupationCode;
                this.riskObj.occupationDescription = this.clientDetails.client.personalClientDetails.occupationDescription;
                if (this.riskObj.occupationDescription == undefined || this.riskObj.occupationDescription == "" || this.riskObj.riskClassification == "" ||
                    this.riskObj.riskClassification == undefined || this.riskObj.riskClassification == 'Standard') {//MD002: Added Standard by MKU1
                    this.pupulateOccupationDescription(this.riskObj.occupationCode);
                }
            }
            else {
                this.riskObj.insuredPerson = "";
                this.riskObj.occupationCode = "";
                this.riskObj.occupationDescription = "";
                //this.riskObj.insuredPerson = this.clientDetails.client.corporateClientDetails.corporation ;
                //this.riskObj.occupationCode=  this.clientDetails.client.corporateClientDetails.BusinessSec;
                //this.riskObj.occupationDescription = "";
            }
        } else {
            if (this.riskObj.riskType == "PAS" && (this.riskObj.occupationDescription == undefined || this.riskObj.occupationDescription == "")) {
                this.riskObj.occupationDescription = "STUDENT";
            }
            //if(this.riskObj.riskType=="PAS" && (this.riskObj.insuredPerson==undefined || this.riskObj.insuredPerson =="") && this.clientDetails.client.genericDetails.clienttype == 'P'){
            if ((this.riskObj.insuredPerson == undefined || this.riskObj.insuredPerson == "") && this.clientDetails.client.genericDetails.clienttype == 'P') {
                this.riskObj.insuredPerson = this.clientDetails.client.personalClientDetails.Name;
            }
        }
    }

    pupulateOccupationDescription(iOccCode) {
        let request: GetLOVData = new GetLOVData().getRequest('ALL', 'ALL', 'NEW BUSINESS', 'ALL', 'NEW', 'ALL', 'Occupation', 'LOV');
        request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        request.ADVANCE_CONFIG_XML.FILTERS = new Filter();

        request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push(
            { "@FIELD_NAME": 'DESCITEM', "@FIELD_VALUE": iOccCode, '@OPERATION': 'EQ', '@CONDITION': 'AND' });
        this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.OccDescSuccessHandler, this.handleError, true, { comp: this });

    }
    OccDescSuccessHandler(response, prms) {
        let ary = [];
        let occDesc = "";
        if (response.tuple != null && !Array.prototype.isPrototypeOf(response.tuple)) {
            ary = [response.tuple];
        }
        else if (response.tuple != null) {
            ary = response.tuple;
        }
        for (let item of ary) {
            prms.comp.riskObj.occupationDescription = item.old.T3644.DESCRIPTION;
        }
        prms.comp.occupationSuccessHandler(response, prms);
    }

    setRIMethod(val) {

        this.riskObj.RIMethod = (val == "Yes") ? "8" : this.riskObj.RIMethodSys;

        if (this.isUnderWriter == "Y" || val == "Yes")
            this.riskObj.isRIOverWrittenByUW = "Y";
        else if (val == "No") {
            this.riskObj.isRIOverWrittenByUW = "N";
            this.validateCapitalSumInsured();
        }
        this._riService.setRI().subscribe();
    }

    emitDuplicateCheck() {

    }

    changeRiskClassification(event) {
        this.riskObj.riskClassification = event.target.value;
        this.onRiskClsChange.emit('');
    }

    validateInsuredCount(e) {
        if (this.riskObj.s5336Items.s5336Item.length >= 1 && this.riskObj.riskType == "MPA") {
            return true;
        }
        return false;
    }
    setClauses(clausesList, flag) {
        if (this.clausesComp)
            this.clausesComp.addClause(clausesList, '', flag);
    }
    deleteClause(ary, clauseCode, prop) {
        let val = undefined;
        if (ary.length > 0) {
            for (var index = 0, assoLength = ary.length; index < assoLength; index++) {
                if (ary[index][prop] != null && ary[index][prop] != "" && ary[index][prop] == clauseCode) {
                    val = index;
                    break;
                }
            }
        }
        if (val != undefined)
            this.clausesComp.removeClause(val, clauseCode);
    }

    checkSingleRecord() {
        if (this.riskObj.s5336Items != null && this.riskObj.s5336Items.s5336Item != null) {
            if (!Array.prototype.isPrototypeOf(this.riskObj.s5336Items.s5336Item)) {
                let tempItem: any = this.riskObj.s5336Items.s5336Item;
                this.riskObj.s5336Items.s5336Item = [tempItem];
            }
        }
        else {
            this.riskObj.s5336Items = new S5336Item();
        }

    }
    onchangeMaxLifeLimit(e) {
        this.riskObj.maxPerLifeLimit = e.target.value;
        this.setTotalSI();
    }
    maxConveyanceChange(e) {
        this.handleRiskClassification(this);
        this.validateCapitalSumInsured();
    }
    uploadInsuredData() {
        let input = new ModalInput();
        input.component = ["S5336UploadComponent", "app/bms/components/proposal/newbusinessrisks/s5335/dialogs/s5336upload.module", "S5336UploadModule"];
        /*input.datainput = {
            ""
        };*/
        input.parentCompPRMS = { comp: this };
        input.heading = "Upload Data";
        input.icon = "fa fa-list";
        input.containerRef = this.contentArea;
        this._dcl.openLookup(input);

    }
    /*resetSurvey(value){
        if("Y" == value){
            this.riskObj.survey = new Survey();
        }
        else{
            this.riskObj.survey = null;
        }
    }*/
    validateInput(event, dType, allowedLength) {
        //console.log(dType + ", " + event.target.value);

        if ([46, 8, 9, 27, 13, 110].indexOf(event.keyCode) !== -1 ||
            // Allow: Ctrl+A, Command+A
            (event.keyCode === 65 && (event.ctrlKey === true || event.metaKey === true)) ||
            // Allow: home, end, left, right, down, up
            (event.keyCode >= 35 && event.keyCode <= 40)) {
            // let it happen, don't do anything
            return;
        }
        // Ensure that it is a number and stop the keypress
        if (dType = "integer") {
            let result = (event.target.value + "").match(/[^0-9]/g);
            if (event.key == ".") {
                // console.log("not allowed");
                return false;
            }
            if (event.target.value != undefined && event.target.value.length >= allowedLength) {
                //console.log("length failed");
                return false;
            }
        } else if (dType = "double") {
            let result = (event.target.value + "").match(/[^0-9]/g);
            if (result && event.key == ".") {
                //console.log("not allowed");
                return false;
            }
        }
        if ((event.shiftKey || (event.keyCode < 48 || event.keyCode > 57)) && (event.keyCode < 96 || event.keyCode > 105)) {
            event.preventDefault();
        }

    }

    addRisk() {
        if (this.clientDetails.client.genericDetails.clienttype == 'P' && !(this.riskObj.s5336Items != null && this.riskObj.s5336Items.s5336Item != null && this.riskObj.s5336Items.s5336Item.length > 0))
            this.setClientInfo();
        else {
            let news5336Item = new S5336ItemDetails();
            news5336Item.itemNo = this.riskObj.s5336Items.s5336Item.length + 1;
            news5336Item.dateStart = this.headerInfo.effectiveDate;
            news5336Item.lastDateEnd = this.headerInfo.endDate;
            news5336Item.riskType = this.riskObj.riskType;
            news5336Item.riskName = this.riskObj.riskName;
            if (this.riskObj.riskType == "PAS") {
                news5336Item.occupationCode = "7STU";
                //news5336Item.occupationDescription = "STUDENT";
            }
            this.riskObj.s5336Items.s5336Item.push(news5336Item);
        }
        this.riskObj.noOfPersons = this.riskObj.s5336Items.s5336Item.length;
    }

    removeAllInsured(e) {
        if (this.riskObj.s5336Items.s5336Item.length > 0)
            this.confirmAppChange("Are you sure want to remove all insured person from risk?", e);
    }
    private confirmAppChange(message: string, values) {
        let inputObj = {
            "Message": message
        };
        let lookup = new ModalInput();
        lookup.component = ["Confirm", "app/common/components/utility/confirmmessage/confirm.module", "ConfirmModule"];
        lookup.datainput = inputObj;
        lookup.outputCallback = this.removeAllInsuredDecision;
        lookup.parentCompPRMS = {
            comp: this,
            values: values
        };
        lookup.heading = "User Confirmation";
        lookup.icon = "fa fa-hand-paper-o";
        lookup.containerRef = this.contentArea;
        this._dcl.openLookup(lookup);

    }

    private removeAllInsuredDecision(data, prms) {
        if (data.value == 'Y') {
            prms.comp.riskObj.s5336Items.s5336Item.splice(0, prms.comp.riskObj.s5336Items.s5336Item.length);
            prms.comp.riskObj.noOfPersons = 0;
            prms.comp.removeRiskContent();
        }
        else {

        }
    }

    selectRisk(risk) {
        this.removeRiskContent();
        //VK007
        //this.handleSubRiskClassification(this,risk.itemNo);
        if (risk != null) {
            let idx = this.riskObj.s5336Items.s5336Item.indexOf(risk);
            this.currentRiskObj = risk;
            this.loadComponent(["S5335RiskComponent", "app/bms/components/proposal/newbusinessrisks/s5335/s5335risk.module", "S5335RiskModule"], null);
        }
    }

    removeRisk(risk) {
        if (this.currentRiskObj != null && this.currentRiskObj.itemNo == risk.itemNo) {
            this.removeRiskContent();
            this.currentRiskObj = null;
        }
        this.riskObj.s5336Items.s5336Item.splice(this.riskObj.s5336Items.s5336Item.indexOf(risk), 1);
        this.resetItmNumber();
        this.setTotalPremium();
        this.setTotalSI();
        this.riskObj.noOfPersons = this.riskObj.s5336Items.s5336Item.length;
        this.handleSubRiskClassification(this, risk.itemNo);
        //this.checkReferredRisk(this);

    }

    resetItmNumber() {
        for (let risk of this.riskObj.s5336Items.s5336Item) {
            let index = this.riskObj.s5336Items.s5336Item.indexOf(risk);
            risk.itemNo = (index + 1);
        }
    }

    populateLovs() {
        this.lovDropDownService.createLOVDataList(["Occupation"]);
        let lovFields = [
            new LOV_Field("ALL", "ALL", "NEW BUSINESS", "ALL", "NEW", "ALL", "Occupation", "LOV", [], "T3644", "Occupation", null)
        ];
        this.lovDropDownService.util_populateLOV(lovFields, this);
    }
    setOccDesc(occupation) {
        this.riskObj.occupationDescription = occupation.record.DESCRIPTION;
        let request: GetLOVData = new GetLOVData();
        request.BRANCH = 'ALL';
        request.LOB = 'ALL';
        request.BUSINESS_FUNCTION = 'NEW BUSINESS';
        request.PRODUCT = 'ALL';
        request.OPERATION = 'NEW';
        request.FORM_NAME = 'ALL';
        request.FORM_FIELD_NAME = 'Occupation';
        request.FIELD_TYPE = 'LOV';
        request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        request.ADVANCE_CONFIG_XML.FILTERS = new Filter();

        request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({ "@FIELD_NAME": 'DESCITEM', "@FIELD_VALUE": this.riskObj.occupationCode, '@OPERATION': 'EQ', '@CONDITION': 'AND' });
        this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.occupationSuccessHandler, this.handleError, true, { comp: this });
    }
    occupationSuccessHandler(response, prms) {
        if (response.tuple.old.T3644.REFERREDRISK == '' || response.tuple.old.T3644.REFERREDRISK == 'N') {
            prms.comp.riskObj.occRiskClassification = "Standard";
        }
        else if (response.tuple.old.T3644.REFERREDRISK == 'Y') {
            prms.comp.riskObj.occRiskClassification = "Referred";
        }
        else if (response.tuple.old.T3644.REFERREDRISK == 'D') {
            prms.comp.riskObj.occRiskClassification = "Declined";
        }
        prms.comp.checkReferredRisk(prms.comp);
        prms.comp.riskObj.occRiskClassification = response.tuple.old.T3644.REFERREDRISK;
        prms.comp.handleRiskClassification(prms.comp);
    }

    checkReferredRisk(comp) {
        //check if insured classification is referred
        comp.checkIfAnyofInsuredAreReferred(comp);
        if (comp.isAnyInsuredReferred) {
            comp.riskObj.symRiskClassification = "Referred";
            comp.riskObj.riskClassification = comp.riskObj.symRiskClassification;
        } else if (comp.isAnyInsuredDeclined) {
            comp.riskObj.symRiskClassification = "Declined";
            comp.riskObj.riskClassification = comp.riskObj.symRiskClassification;
        } else {
            if (comp.riskObj.occRiskClassification == "Referred") {
                comp.riskObj.symRiskClassification = "Referred";
            } else if (comp.riskObj.occRiskClassification == "Declined") {
                comp.riskObj.symRiskClassification = "Declined";
            } else {
                if (comp.riskObj.conveyanceRiskClassification == "Referred")
                    comp.riskObj.symRiskClassification = "Referred";
                else
                    comp.riskObj.symRiskClassification = "Standard";
            }
            comp.riskObj.riskClassification = comp.riskObj.symRiskClassification;
        }
        comp.setRiskClassification(comp);
    }

    checkIfAnyofInsuredAreReferred(comp) {
        if (comp.riskObj.s5336Items != null && comp.riskObj.s5336Items.s5336Item != null && comp.riskObj.s5336Items.s5336Item.length > 0) {
            for (let insured of comp.riskObj.s5336Items.s5336Item) {
                if (insured.riskClassification == 'Referred') {
                    comp.isAnyInsuredReferred = true;
                    comp.isAnyInsuredDeclined = false;
                    break;
                }
                else if (insured.riskClassification == 'Declined') {
                    comp.isAnyInsuredReferred = false;
                    comp.isAnyInsuredDeclined = true;
                    break;
                } else {
                    comp.isAnyInsuredReferred = false;
                    comp.isAnyInsuredDeclined = false;
                }
            }
        }

    }
    setReferredRisk() {
        this.handleRiskClassification(this);
        // this.checkReferredRisk(this);
        this.setRiskClassification(this);
        this.onRiskClsChange.emit('');
    }
    setRiskClassification(comp) {
        if (comp.riskObj.symRiskClassification != null && comp.riskObj.symRiskClassification != "" && (comp.riskObj.symRiskClassification == "Referred" || comp.riskObj.symRiskClassification == "Declined")) {
            let statusTxt = (comp.riskObj.symRiskClassification != null && comp.riskObj.symRiskClassification != "") ? comp.riskObj.symRiskClassification : comp.riskObj.riskClassification;
            if (comp.riskObj.riskClassificationReason == "") {
                comp.riskObj.riskClassificationReason = "System marked as " + statusTxt;
            }
        }
        else {
            if (comp.riskObj.riskClassificationReason != null && comp.riskObj.riskClassificationReason != "" && (comp.riskObj.riskClassificationReason != "System marked as Standard"
                && comp.riskObj.riskClassificationReason.indexOf("System marked as ") != -1)) {
                comp.riskObj.riskClassificationReason = "";
            }
        }
        comp.onRiskClsChange.emit('');
    }

    handleError(response, status, errorText, prms) {
        prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, response.responseJSON.faultstring.text, -1));
    }

    getTotalByProperty(prop, ary) {
        let total = numeral(0);
        let counter = 1;
        //console.log("before entering loop : "+prop + "--------------");
        for (let eachItem of ary) {
            if (eachItem[prop] != null && eachItem[prop] != "") {
                //console.log(">>>>> eachItem["+prop+"]: "+eachItem[prop]+ "");
                total = total.add(numeral().unformat(eachItem[prop]));
            }
        }
        if (total)
            total = numeral(total).format('0.00');
        else
            total = 0;
        return total;
    }
    getTotalByPropertyForSumInsured(prop, ary) {
        let total = numeral(0);
        let counter = 1;
        //console.log("before entering loop : "+prop + "--------------");
        for (let eachItem of ary) {
            if (eachItem[prop] != null && eachItem[prop] != "") {
                //console.log(">>>>> eachItem["+prop+"]: "+eachItem[prop]+ "");
                total = total.add(numeral().unformat(eachItem[prop]));
            }
        }
        if (total)
            total = numeral(total).format('0');
        else
            total = 0;
        return total;
    }

    setClientInfo() {
        let news5336Details = new S5336ItemDetails();
        if (this.clientDetails.client.personalClientDetails) {
            news5336Details.insuredPerson = this.clientDetails.client.personalClientDetails.Name;
            news5336Details.insuredSalutation = this.clientDetails.client.personalClientDetails.saluation;
            news5336Details.NRIC = this.clientDetails.client.personalClientDetails.NRICNo;
            news5336Details.IdProofNo = this.clientDetails.client.personalClientDetails.IdNumber;
            //news5336Details.dateOfBirth = this.clientDetails.client.personalClientDetails.dateOfBirth;
            news5336Details.dateOfBirth = moment(this.clientDetails.client.personalClientDetails.dateOfBirth, "YYYYMMDD").format("YYYY-MM-DD");
            news5336Details.maritalStatus = this.clientDetails.client.personalClientDetails.maritalStatus;
            news5336Details.gender = this.clientDetails.client.personalClientDetails.gender;
            if (this.riskObj.riskType == "PAS") {
                news5336Details.occupationCode = "7STU";
            } else {
                news5336Details.occupationCode = this.clientDetails.client.personalClientDetails.occupationCode;
                news5336Details.occupationDescription = this.clientDetails.client.personalClientDetails.occupationDescription;
            }
            news5336Details.terminationDate = this.clientDetails.client.personalClientDetails.terminationDate;
            news5336Details.itemNo = this.riskObj.s5336Items.s5336Item.length + 1;
            news5336Details.dateStart = this.headerInfo.effectiveDate;
            news5336Details.lastDateEnd = this.headerInfo.endDate;
            news5336Details.riskType = this.riskObj.riskType;
            news5336Details.riskName = this.riskObj.riskName;
            this.riskObj.s5336Items.s5336Item.push(news5336Details);
        }
    }



    setTotalPremium() {
        this.riskObj.originalTotalPremium = this.getTotalByProperty("totalAnnualPremium", this.riskObj.s5336Items.s5336Item);
        this.riskObj.rebate = this.headerInfo.rebate;
        this.riskObj.rebateAmount = Number(numeral().unformat(this.riskObj.originalTotalPremium) / 100 * numeral().unformat(this.riskObj.rebate));
        this.riskObj.discountedPremium = numeral().unformat(this.riskObj.originalTotalPremium) - numeral().unformat(this.riskObj.rebateAmount);
        //SST Code	
        //this.riskObj.gstAmount = 0;//Number(this.riskObj.discountedPremium / 100 * 6); //SAF MYS-2018-0629

        //SST Code
        let tempGSTAmount = (Number(this.riskObj.GST) > 0) ? numeral(numeral((this.riskObj.discountedPremium * Number(this.riskObj.GST)) / 100).format(this.premiumFormat)).value() : 0;
        this.riskObj.gstAmount = (tempGSTAmount > 0) ? numeral(numeral(BMSUtilService.calculatePremiumAmount(tempGSTAmount, "G")).format(this.premiumFormat)).value() : 0;

        let tempSSTAmount = (Number(this.riskObj.SST) > 0) ? numeral(numeral((this.riskObj.discountedPremium * Number(this.riskObj.SST)) / 100).format(this.premiumFormat)).value() : 0;
        this.riskObj.sstAmount = (tempSSTAmount > 0) ? numeral(numeral(BMSUtilService.calculatePremiumAmount(tempSSTAmount, "S")).format(this.premiumFormat)).value() : 0;


        //this.riskObj.totalPremium = numeral().unformat(this.riskObj.discountedPremium) + numeral().unformat(this.riskObj.gstAmount);
        this.riskObj.totalPremium = numeral().unformat(this.riskObj.discountedPremium) + numeral().unformat(this.riskObj.gstAmount) + numeral().unformat(this.riskObj.sstAmount);
        //End
        this.riskObj.gstAmount = numeral(this.riskObj.gstAmount).format('0.00');
        this.riskObj.totalPremium = numeral(this.riskObj.totalPremium).format('0.00');
        this.riskObj.rebateAmount = numeral(this.riskObj.rebateAmount).format('0.00');
        this.riskObj.discountedPremium = numeral(this.riskObj.discountedPremium).format('0.00');
        this.setTotalPP();
        this.onPremiumChange.emit(this.riskObj.totalPremium);
    }

    setTotalSI() {
        if (this.riskObj.riskType == 'PAC') {
            this.riskObj.capitalSumInsured = this.riskObj.maxPerLifeLimit;
            this.riskObj.bigCapitalSumInsured = this.riskObj.maxPerLifeLimit;
        } else {
            this.setBigSI();
            this.riskObj.capitalSumInsured = this.riskObj.bigCapitalSumInsured;
        }
        this.validateCapitalSumInsured();
        //this.onSIChange.emit(this.riskObj.capitalSumInsured);
    }

    setBigSI() {
        let bigSI = 0;
        for (let eachItem of this.riskObj.s5336Items.s5336Item) {
            if (eachItem.sumInsured != null && "" + eachItem.sumInsured != "") {
                bigSI = (parseFloat("" + eachItem.sumInsured) > bigSI) ? parseFloat("" + eachItem.sumInsured) : bigSI;
            }
        }
        this.riskObj.bigCapitalSumInsured = bigSI;
    }

	/*setTotalPP(){
		//this.riskObj.postingPremium = this.getTotalByProperty("postingPremium",this.riskObj.s5336Items.s5336Item);
		this.riskObj.postingPremium = ((this.riskObj.totalPremium)/365)*this.calcDays();
	}*/

    setTotalPP() {// Changed by MKU1 ie., Not divide totalpremium with 365
        //this.riskObj.postingPremium = this.getTotalByProperty("postingPremium",this.riskObj.s5336Items.s5336Item);
        let effectDate = moment(this.headerInfo.effectiveDate, "YYYY-MM-DD");
        let endDateMom = moment(this.headerInfo.endDate, "YYYY-MM-DD");
        let dateRange = moment.range(effectDate, endDateMom);
        let isLeapYear = this.dateRangeContainsLeapYear(dateRange);
        let noofdays = 365;
        if (isLeapYear)
            noofdays = 366;
        this.riskObj.postingPremium = ((this.riskObj.totalPremium) / noofdays) * this.calcDays();
    }
    dateRangeContainsLeapYear(dateRange: any) { //MD00_
        for (var year = dateRange.start.year(); year <= dateRange.end.year(); year++) {
            var date = moment(year + '-02-29');
            if (date.isLeapYear() && dateRange.contains(date)) return true;
        }
        return false;
    }

    calcDays() {
        let date1 = moment(this.headerInfo.effectiveDate, "YYYY-MM-DD");
        let date2 = moment(this.headerInfo.endDate, "YYYY-MM-DD");
        return date2.diff(date1, 'days') + 1;//added +1 to always include endDate for calculation
        //return Math.ceil(timeDiff / (1000 * 3600 * 24));
    }

    loadComponent(component, prms) {
        let input = new DCLInput();
        input.component = component;
        input.viewContainerRef = this.contentArea;
        input.inputs = { parentRiskObj: this.riskObj, riskObj: this.currentRiskObj, headerInfo: this.headerInfo, clientDetails: this.clientDetails };
        input.callback = this.setOutputHandle;
        input.prms = { comp: this, prms: prms };
        this._dcl.loadComponent(input);
    }

    setOutputHandle(compRef, prms) {
        prms.prms.comp.selectedRiskComponent = compRef;
        if (compRef.instance.onPremiumChange != null) {
            compRef.instance.onPremiumChange.subscribe(() => {
                prms.prms.comp.setTotalPremium();
            });
        }
        if (compRef.instance.onSIChange != null) {
            compRef.instance.onSIChange.subscribe(() => {
                prms.prms.comp.setTotalSI();
            });
        }
        if (compRef.instance.onRiskClsChange != null) {
            compRef.instance.onRiskClsChange.subscribe(() => {
                prms.prms.comp.setReferredRisk();
            });
        }
        if (compRef.instance.emitDuplicateCheck != null) {
            compRef.instance.emitDuplicateCheck.subscribe(() => {
                prms.prms.comp.duplicateCheck();
            });
        }
        if (compRef.instance.emitonPlanChangeHandler != null) {
            compRef.instance.emitonPlanChangeHandler.subscribe((plancode) => { prms.prms.comp.onPlanChangeHandler(plancode); });
        }

        if (compRef.instance.prms != null) {
            compRef.instance.prms = prms.prms.prms;
        }
    }
    duplicateCheck() {
        debugger;
    }
    onPlanChangeHandler(plancode1) {
        if (this.clausesComp)
            this.clausesComp.setDefaultClause(plancode1);
    }
    removeRiskContent() {
        if (this.selectedRiskComponent != null)
            this._dcl.unloadComponent(this.selectedRiskComponent);
        this.currentRiskObj = null;
        jQuery(this.el).find("#S5336RiskComponent").empty();
    }

    validateCapitalSumInsured() {
        if (this.riskObj.RIRetentionCode && this.riskObj.isRIOverWrittenByUW == 'N') {

            this._bmsUtilService.getTotalGrossCapacity(this.riskObj.RIRetentionCode).subscribe((data) => this.compareSIWithTotGrossCap(data));
        }
        else
            this.setRIMethodEditableFlag();
    }

    compareSIWithTotGrossCap(totGrossCap) {

        let _totalGrossCapacity = (!totGrossCap) ? 0 : parseFloat("" + totGrossCap);
        this.riskObj.totalGrossCapacity = _totalGrossCapacity;
        //let _capitalSumInsured = parseFloat(""+this.riskObj.capitalSumInsured);
        let _sumInsuredAmount = 0;
        if (this.riskObj.riskType == 'PAC') {
            _sumInsuredAmount = parseFloat("" + this.riskObj.maxPerConveyanceLimit);
        } else {
            _sumInsuredAmount = parseFloat("" + this.riskObj.capitalSumInsured);
        }

        if (_totalGrossCapacity > 0 && _sumInsuredAmount > _totalGrossCapacity && (this.riskObj.RIMethod == null || this.riskObj.RIMethod == "" || parseFloat("" + this.riskObj.RIMethod) != 8)) {
            if (this.riskObj.riskType == 'PAC')
                this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Max Per Conveyance Limit greater than Total Gross Capacity: " + _totalGrossCapacity + ",  RI is Required.", 10000));
            else
                this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Total Sum Insured is greater than Total Gross Capacity: " + _totalGrossCapacity + ",  RI is Required.", 10000));

            this.riskObj.RIRequired = "Yes";
            this.riskObj.RIMethod = "8";
        }
        else if (_sumInsuredAmount <= _totalGrossCapacity) {
            this.riskObj.RIRequired = "No";
            this.riskObj.RIMethod = this.riskObj.RIMethodSys;
        }
        this._riService.setRI().subscribe();
        this.setRIMethodEditableFlag();
    }

    setRIMethodEditableFlag() {
        let _sumInsuredAmount = 0;
        if (this.riskObj.riskType == 'PAC') {
            _sumInsuredAmount = parseFloat("" + this.riskObj.maxPerConveyanceLimit);
        } else {
            _sumInsuredAmount = parseFloat("" + this.riskObj.capitalSumInsured);
        }
        //let _capitalSumInsured = parseFloat(""+this.riskObj.capitalSumInsured);
        let _totalGrossCapacity = parseFloat("" + this.riskObj.totalGrossCapacity);
        if (_totalGrossCapacity > 0 && _sumInsuredAmount > _totalGrossCapacity && this.isUnderWriter == "N") {
            this.isRIMethodEditable = "N";
        }
        else {
            this.isRIMethodEditable = "Y";
        }
    }

    // Added below code for SAF MYS-2017-1108
    emitFlagChange() {
        this.onRtngFlgChange.emit("");
    }
}