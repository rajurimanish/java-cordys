/**
 * Change History	:

	No      Date          Description                                                       Changed By
	====    ==========    ===========                                                        ==========
 * MD002   06/04/2018    Incomplete List "Additional Coverage" for NGA product in BMS          MKU1 
   MD001   19/03/2018    UAT issue raised during SAF MYS-2017-0920                             MKU1
                          for FPB family plan, premium is only applied to the 1st insured
                          i.e. premium is not applicable for spouse & child(ren)  			
   E1001   17/09/2019    SAF# MYS-2019-0442	- To build Renewal Bonus logic in BMS as per 
                         current P400 setting.                                                  SRE1
                                                    		      
 */
import { Component, OnInit, EventEmitter, ViewChild, ViewContainerRef } from '@angular/core';
import { LOV_Field, LOVDropDownService, SearchFilter } from "../../../../../common/services/lovdropdown/lovdropdown.service";
import { SearchInput } from "../../../../../common/components/utility/search/genericsearch";
import { ModalInput } from "../../../../../common/components/utility/modal/modal";
import { GetLOVData, SearchAdvancedConfig, Filter } from '../../../../../common/components/utility/search/search.requests';
import { DCLInput, CustomDCLService } from '../../../../../common/services/customdcl.service';
import { CordysSoapWService } from "../../../../../common/components/utility/cordys-soap-ws";
declare var Observer: any;
import { AlertMessagesService } from '../../../../../common/components/utility/alertmessage/alertmessages.service';
import { AlertMessage } from '../../../../../common/components/utility/alertmessage/alertmessages.model';
import { BMSConstants } from '../../../common/constants/bms_constants';

declare var jQuery: any;
declare var numeral: any;
declare var moment: any;

@Component({
    selector: 's5336-coverage-comp',
    templateUrl: 'app/bms/components/proposal/newbusinessrisks/s5335/s5336coverage.template.html',
    inputs: ['coverageObj', 'coverageName', 'riskObj'],
    outputs: ['ontotalchange', 'onsichange', 'onplanchange', 'onagechange']
})
export class S5336CoverageComponent implements OnInit {
    isMobile: boolean = /Mobi/.test(navigator.userAgent);
    public coverageObj: any;
    public riskObj: any;
    public coverageName: string;
    public total: number = 0;
    ontotalchange = new EventEmitter<any>();
    onsichange = new EventEmitter<any>();
    onplanchange = new EventEmitter<any>();
    onagechange = new EventEmitter<any>();

    public search: String = "";
    public position = 1;
    public sizeObj = { length: 0, orglength: 0 };
    public contentSizeObs: any;
    public itemPerPage = 10;
    public maxPageCount = 5;
    public benefitFlag: boolean = false;
    public siFormat: string = "000";
    public premiumFormat: string = "000.00";
    public rateFormat: string = "0.0000";
    public loadFormat: string = "0.00";
    public percentFormat: string = "0.00";
    public isPASRisk: string = "N";
    public colspanValue = 6;
    public noRecordsColSpan = 8;
    public disableForm = 'N';
    public isApprovalCompleted: string = "N";

    @ViewChild('coverageModal', { read: ViewContainerRef }) contentArea: ViewContainerRef;
    constructor(public dcl: CustomDCLService, private lovDropDownService: LOVDropDownService, private _soapService: CordysSoapWService, public _alertMsgService: AlertMessagesService) { }

    ngOnInit() {
        this.populateLOVs();
        //this.checkSingleRecord();
        this.setBenefitFlag();
        if (this.riskObj.riskType == "PAS") {
            this.colspanValue = 4;
            this.noRecordsColSpan = 6;
        }
        this.setFormDisabled();
        if (this.riskObj.contractNumber != "") {
            this.disableForm = "Y";
        }
        this.isApprovalCompleted = BMSConstants.getApprovalStatus();
    }
    setFormDisabled() {
        if (jQuery("#bmsForm").prop("disabled") == true) {
            this.disableForm = "Y";
        }
    }

    checkSingleRecord() {
        if (this.coverageObj[this.coverageName] != null && !Array.prototype.isPrototypeOf(this.coverageObj[this.coverageName])) {
            this.coverageObj[this.coverageName] = [this.coverageObj[this.coverageName]];
        }
    }

    setBenefitFlag() {
        for (let coverage of this.coverageObj[this.coverageName]) {
            if (coverage.indicator == 'F' || coverage.indicator == 'A') {
                this.benefitFlag = true;
                return;
            }
        }
    }

    private populateLOVs(): void {
        this.lovDropDownService.createLOVDataList(["PlanCodes"]);
        let curDate = this.getDate();
        let riskType = this.getRiskType();
        let riTypeFilterDetails = [
            new SearchFilter("DESCITEM", riskType, "STARTSWITH", "AND"),
            new SearchFilter("ITMFRM", curDate, "LT", "AND"),
            new SearchFilter("ITMTO", curDate, "GT", "AND"),
            new SearchFilter("DESCITEM", "select distinct CONTITEM from T7072   where DESCITEM like '" + riskType + "%' and ITMFRM <'" + curDate + "' and ITMTO >'" + curDate + "' and CONTITEM!=''", "NOT IN", "AND")
        ];
        let riTypeSearchFilterNodes = this.lovDropDownService.createFilter(riTypeFilterDetails);
        let lovFields = [
            new LOV_Field("ALL", "ALL", "NEW BUSINESS", "ALL", "NEW", "S5336", "PlanCodes", "LOV", riTypeSearchFilterNodes, "T7072", "PlanCodes", null)
        ];
        this.lovDropDownService.util_populateLOV(lovFields, this);
    }

    removeCoverage(coverage) {
        this.coverageObj[this.coverageName].splice(this.coverageObj[this.coverageName].indexOf(coverage), 1);
        if (this.coverageObj.benefit.length > 0) {
            this.onsichange.emit(this.coverageObj.benefit[0].newSI);
            this.emitTotal();
        } else {
            this.onsichange.emit(0);
            this.emitTotal();

        }
    }

    getRiskType() {
        let riskType = this.riskObj.riskType;
        while (riskType != undefined && riskType.length < 3) {
            riskType = riskType + " ";
        }
        return riskType;
    }

    onChangePlan(data) {
        this.riskObj.planDescription = data.description;//MD001
        this.coverageObj[this.coverageName] = [];
        let request: GetLOVData = new GetLOVData();
        request.BRANCH = 'ALL';
        request.LOB = 'ALL';
        request.BUSINESS_FUNCTION = 'NEW BUSINESS';
        request.PRODUCT = 'ALL';
        request.OPERATION = 'ALL';
        request.FORM_NAME = 'ALL';
        request.FORM_FIELD_NAME = 'Coverage Information';
        request.FIELD_TYPE = 'LOOKUP';
        request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        request.ADVANCE_CONFIG_XML.FILTERS = new Filter();
        let dateString = this.getDate();
        request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({ "@FIELD_NAME": 'DESCITEM', "@FIELD_VALUE": this.getRiskType() + "" + data.value, '@OPERATION': 'EQ', '@CONDITION': 'AND' },
            { "@FIELD_NAME": 'ITMFRM', "@FIELD_VALUE": dateString, '@OPERATION': 'LT', '@CONDITION': 'AND' },
            { "@FIELD_NAME": 'ITMTO', "@FIELD_VALUE": dateString, '@OPERATION': 'GT', '@CONDITION': 'AND' });
        this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.successHandler, this.handleError, true, { comp: this });
        this.emitPlanChange(data.value);
        //this.emitTotal();
    }


    getDate() {
        return moment(new Date().toISOString(), "YYYY-MM-DD").format("YYYYMMDD");
    }

    handleError(response, status, errorText, prms) {
        prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, response.responseJSON.faultstring.text, -1));
    }

    successHandler(response, prms) {
        let ary = [];
        let contitem = '';

        if (response.tuple != null && !Array.prototype.isPrototypeOf(response.tuple)) {
            ary = [response.tuple];
        }
        else if (response.tuple != null) {
            ary = response.tuple;
        }
        prms.comp.benefitFlag = false;
        let capSI = 0;
        let planAge = 0;
        //let benefitIndex=1;
        for (let coverage of ary) {
            let coverageInfo: CoverageInfo = {
                "benefitIndex": 0,
                "coverageCode": coverage.old.T7072.ZCVCDE,
                "coverageDescription": coverage.old.T7072.COVER_DESC,
                //"benefits" : parseFloat(coverage.old.T7072.SUMIN) * parseInt(coverage.old.T7072.NOUNTS),
                //"newSI" : parseFloat(coverage.old.T7072.SUMIN) * parseInt(coverage.old.T7072.NOUNTS),
                "benefits": parseFloat(coverage.old.T7072.SUMIN),
                "newSI": parseFloat(coverage.old.T7072.SUMIN),
                "premium": parseFloat(coverage.old.T7072.GPDPREM),
                "rate": coverage.old.T7072.SRAT,
                "load": coverage.old.T7072.SLOA,
                "indicator": coverage.old.T7072.IND,
                "nounts": parseInt(coverage.old.T7072.NOUNTS),
                "optno": coverage.old.T7072.OPTNO,
                "optind": coverage.old.T7072.OPTIND,
                "contitem": coverage.old.T7072.CONTITEM
            };
            if ((coverage.old.T7072.IND == 'F' || coverage.old.T7072.IND == 'A') && parseFloat(coverage.old.T7072.ZSORIG) > 0) {
                prms.comp.benefitFlag = true;
            }

            if (prms.comp.benefitFlag == true) {
                if (coverage.old.T7072.OPTNO == "1") {
                    //E1001 Start 
                    if(prms.comp.riskObj.riskType == "PMC"){
                        capSI = parseFloat(coverage.old.T7072.SUMIN);
                    }
                    else {
                    capSI = parseFloat(coverage.old.T7072.ZSORIG);
                    }    
                    //E1001 END
                    planAge = coverage.old.T7072.AGE;
                    prms.comp.onagechange.emit(coverage.old.T7072.AGE);
                }
            } else {
                if (coverage.old.T7072.OPTNO == "1") {
                    capSI = parseFloat(coverage.old.T7072.ZSORIG);
                    if (capSI <= 0) {
                        capSI = parseFloat(coverage.old.T7072.SUMIN);
                    }
                    //E1001 Start
                    if(prms.comp.riskObj.riskType == "PMC"){
                        capSI = parseFloat(coverage.old.T7072.SUMIN);
                    }
                    //E1001 End
                    planAge = coverage.old.T7072.AGE;
                    prms.comp.onagechange.emit(coverage.old.T7072.AGE);
                }
            }
            if (prms.comp.riskObj.riskType == "PMB" || prms.comp.riskObj.riskType == "PMA") {
                if (prms.comp.riskObj.entryBonusPercentage > 0) {
                    if (coverage.old.T7072.OPTNO == "1") {
                        prms.comp.riskObj.entryBonusAmount = (parseFloat(coverage.old.T7072.SUMIN) * prms.comp.riskObj.entryBonusPercentage) / 100;
                        coverageInfo.newSI = parseFloat(coverage.old.T7072.SUMIN) + prms.comp.riskObj.entryBonusAmount;
                        if(parseFloat(coverage.old.T7072.ZSORIG) < parseFloat(coverage.old.T7072.SUMIN)) {
                            capSI = parseFloat(coverage.old.T7072.SUMIN) + prms.comp.riskObj.entryBonusAmount;
                        }
                        else {
                            capSI = parseFloat(coverage.old.T7072.ZSORIG) + prms.comp.riskObj.entryBonusAmount;
                        }
                    }
                    if (coverage.old.T7072.OPTNO == "2" || coverage.old.T7072.OPTNO == "3") {
                        prms.comp.riskObj.entryBonusAmount = (parseFloat(coverage.old.T7072.SUMIN) * prms.comp.riskObj.entryBonusPercentage) / 100;
                        coverageInfo.newSI = parseFloat(coverage.old.T7072.SUMIN) + prms.comp.riskObj.entryBonusAmount;
                    }
                }
            }

            if (coverage.old.T7072.CONTITEM != '' && contitem == '') {
                contitem = coverage.old.T7072.CONTITEM;
            }

            //			if(planAge >= 0 && coverage.old.T7072.OPTNO == "1") {
            //				planAge = coverage.old.T7072.AGE;
            //				prms.comp.onagechange.emit(coverage.old.T7072.AGE);
            //			}

            if (coverageInfo.optind != 'O')
                prms.comp.coverageObj[prms.comp.coverageName].push(coverageInfo);
        }

        if (contitem != '') {
            prms.comp.setContinuationItems(contitem);
        } else {
            prms.comp.resetBenefitIndex();
        }
        prms.comp.emitTotal();
        prms.comp.onsichange.emit(capSI);

    }

    setContinuationItems(data) {
        let request: GetLOVData = new GetLOVData();
        request.BRANCH = 'ALL';
        request.LOB = 'ALL';
        request.BUSINESS_FUNCTION = 'NEW BUSINESS';
        request.PRODUCT = 'ALL';
        request.OPERATION = 'ALL';
        request.FORM_NAME = 'ALL';
        request.FORM_FIELD_NAME = 'Coverage Information';
        request.FIELD_TYPE = 'LOOKUP';
        request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        request.ADVANCE_CONFIG_XML.FILTERS = new Filter();
        let dateString = this.getDate();
        request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({ "@FIELD_NAME": 'DESCITEM', "@FIELD_VALUE": data, '@OPERATION': 'EQ', '@CONDITION': 'AND' },
            { "@FIELD_NAME": 'ITMFRM', "@FIELD_VALUE": dateString, '@OPERATION': 'LT', '@CONDITION': 'AND' },
            { "@FIELD_NAME": 'ITMTO', "@FIELD_VALUE": dateString, '@OPERATION': 'GT', '@CONDITION': 'AND' });
        this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.continuationSuccessHandler, this.handleError, true, { comp: this });

    }

    continuationSuccessHandler(response, prms) {
        let ary = [];
        //let capSI = 0;

        if (response.tuple != null && !Array.prototype.isPrototypeOf(response.tuple)) {
            ary = [response.tuple];
        }
        else if (response.tuple != null) {
            ary = response.tuple;
        }

        for (let coverage of ary) {
            let coverageInfo: CoverageInfo = {
                "benefitIndex": 0,
                "coverageCode": coverage.old.T7072.ZCVCDE,
                "coverageDescription": coverage.old.T7072.COVER_DESC,
                //"benefits" : parseFloat(coverage.old.T7072.SUMIN) * parseInt(coverage.old.T7072.NOUNTS),
                //"newSI" : parseFloat(coverage.old.T7072.SUMIN) * parseInt(coverage.old.T7072.NOUNTS),
                "benefits": parseFloat(coverage.old.T7072.SUMIN),
                "newSI": parseFloat(coverage.old.T7072.SUMIN),
                "premium": parseFloat(coverage.old.T7072.GPDPREM),
                "rate": coverage.old.T7072.SRAT,
                "load": coverage.old.T7072.SLOA,
                "indicator": coverage.old.T7072.IND,
                "nounts": parseInt(coverage.old.T7072.NOUNTS),
                "optno": coverage.old.T7072.OPTNO,
                "optind": coverage.old.T7072.OPTIND,
                "contitem": coverage.old.T7072.CONTITEM
            };

            if ((coverage.old.T7072.IND == 'F' || coverage.old.T7072.IND == 'A') && parseFloat(coverage.old.T7072.ZSORIG) > 0)
                prms.comp.benefitFlag = true;
            if (coverageInfo.optind != 'O')
                prms.comp.coverageObj[prms.comp.coverageName].push(coverageInfo);
        }
        prms.comp.resetBenefitIndex();

        //prms.comp.emitTotal();
    }
    resetBenefitIndex() {
        let idx = 1;
        for (let coverage of this.coverageObj[this.coverageName]) {
            coverage.benefitIndex = idx;
            idx++;
        }
    }

    setPremiumForEach(event, coverage) {
        let rate = (coverage.rate == null || coverage.rate == "") ? 0 : coverage.rate;
        let load = (coverage.load == null || coverage.load == "") ? 0 : coverage.load;
        let newSI = (coverage.benefits == null || coverage.benefits == "") ? 0 : coverage.benefits;
        if (coverage.benefitIndex == 1) {
            this.riskObj.entryBonusAmount = (parseFloat(coverage.benefits) * this.riskObj.entryBonusPercentage) / 100;
            coverage.newSI = parseFloat(coverage.benefits) + this.riskObj.entryBonusAmount;
            if (this.coverageObj.benefit[1])
                this.coverageObj.benefit[1].newSI = parseFloat(this.coverageObj.benefit[1].benefits) + this.riskObj.entryBonusAmount;
            if (this.coverageObj.benefit[2])
                this.coverageObj.benefit[2].newSI = parseFloat(this.coverageObj.benefit[2].benefits) + this.riskObj.entryBonusAmount;
            this.onsichange.emit(coverage.newSI);
        } else if (coverage.benefitIndex == 2 || coverage.benefitIndex == 3) {
            //this.riskObj.entryBonusAmount=(parseFloat(coverage.benefits) * this.riskObj.entryBonusPercentage)/100;
            coverage.newSI = parseFloat(coverage.benefits) + this.riskObj.entryBonusAmount;
            //capSI = parseFloat(coverage.old.T7072.SUMIN) + prms.comp.riskObj.entryBonusAmount;
            //this.onsichange.emit(coverage.newSI);
        } else {
            coverage.newSI = parseFloat(coverage.benefits);
        }
        //coverage.newSI = Number(coverage.benefits) * Number(coverage.nounts);
        //coverage.newSI = Number(coverage.benefits);
        let premium = (parseFloat(newSI) * (parseFloat(rate) * 0.01));
        let loadPremium = (Number(premium) * (parseFloat(load) * 0.01));
		/*if(coverage.indicator == 'F'|| coverage.indicator == 'A')
			coverage.premium = Number(coverage.premium) + Number(premium) + Number(loadPremium);
		else*/
        coverage.premium = Number(premium) + Number(loadPremium);
        loadPremium = numeral(loadPremium).format('0.00');
        coverage.premium = numeral(coverage.premium).format('0.00');
        this.emitTotal();
    }

    getTotalByProperty(prop, ary) {
        let total = numeral(0);
        for (let eachItem of ary) {
            if (eachItem[prop] != null && eachItem[prop] != "")
                total = total.add(numeral().unformat(eachItem[prop]));
        }
        total = numeral(total).format('0.00');
        return total;
    }
    changePremiumByUser(event, cover, index) {
        cover.rate = "0.0000";
        cover.load = "0.00";
        cover.premium = numeral(cover.premium).format('0.00');
        if (index == 0)
            this.onsichange.emit(cover.newSI);
        this.emitTotal();
    }

    emitTotal() {
        let total = this.getTotalByProperty("premium", this.coverageObj[this.coverageName])
        this.ontotalchange.emit(total);
    }

    emitPlanChange(plan) {
        let emitVal = this.getRiskType() + "" + plan;
        this.onplanchange.emit(emitVal);
    }

    openAddBenefit(coverage) {
        if (this.riskObj.plan == undefined || this.riskObj.plan == "") {
            this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Please select plan.", 5000));
            return false;
        }
        let searchInput = new SearchInput();
        searchInput.isSingleSelect = false;
        searchInput.BRANCH = 'ALL';
        searchInput.BUSINESS_FUNCTION = 'NEW BUSINESS';
        searchInput.FIELD_TYPE = 'LOOKUP';
        searchInput.FORM_FIELD_NAME = 'Add Coverage Benefit';
        searchInput.FORM_NAME = 'S5336';
        searchInput.LOB = 'PA';
        searchInput.OPERATION = 'NEW';
        searchInput.PRODUCT = 'ALL';
        let benefitCode = "''";

        if (this.coverageObj[this.coverageName].length > 0) {
            let newArr = [];
            for (let item of this.coverageObj[this.coverageName]) {
                newArr = newArr.concat(item["coverageCode"]);
            }
            benefitCode = "'" + newArr.toString().replace(/,/g, "\',\'") + "'";
        }

        let descItem = "'" + this.getRiskType() + "" + this.riskObj.plan + "'";//MD002
        if (this.coverageObj[this.coverageName][0] != undefined && this.coverageObj[this.coverageName][0]["contitem"])
            descItem += "," + "'" + this.coverageObj[this.coverageName][0]["contitem"] + "'";

        searchInput.condition = { "DESCITEM": descItem, "ITMFRM": this.getDate(), "ITMTO": this.getDate(), "ZCVCDE": benefitCode };

        let input = new ModalInput();
        input = input.get("GenericSearchComponent");
        input.datainput = searchInput;
        input.outputCallback = this.addBenefit;
        input.parentCompPRMS = { comp: this };
        input.heading = "Add Coverage Items";
        input.icon = "fa fa-file-pdf-o";
        input.containerRef = this.contentArea;
        this.dcl.openLookup(input);
    }

    addBenefit(response, prms) {
        let ary = [];
        let contitem = '';

        if (response != null && !Array.prototype.isPrototypeOf(response)) {
            ary = [response];
        }
        else if (response != null) {
            ary = response;
        }
        prms.comp.benefitFlag = false;
        let capSI = 0;
        let planAge = 0;
        for (let coverage of ary) {
            let coverageInfo: CoverageInfo = {
                "benefitIndex": 0,
                "coverageCode": coverage.old.T7072.ZCVCDE,
                "coverageDescription": coverage.old.T7072.COVER_DESC,
                //"benefits" : parseFloat(coverage.old.T7072.SUMIN) * parseInt(coverage.old.T7072.NOUNTS),
                //"newSI" : parseFloat(coverage.old.T7072.SUMIN) * parseInt(coverage.old.T7072.NOUNTS),
                "benefits": parseFloat(coverage.old.T7072.SUMIN),
                "newSI": parseFloat(coverage.old.T7072.SUMIN),
                "premium": parseFloat(coverage.old.T7072.GPDPREM),
                "rate": coverage.old.T7072.SRAT,
                "load": coverage.old.T7072.SLOA,
                "indicator": coverage.old.T7072.IND,
                "nounts": parseInt(coverage.old.T7072.NOUNTS),
                "optno": coverage.old.T7072.OPTNO,
                "optind": coverage.old.T7072.OPTIND,
                "contitem": coverage.old.T7072.CONTITEM
            };
            if (coverage.old.T7072.OPTNO == "1") {
                //capSI = (parseFloat(coverage.old.T7072.ZSORIG) > 0)? parseFloat(coverage.old.T7072.ZSORIG) * parseInt(coverage.old.T7072.NOUNTS):parseFloat(coverage.old.T7072.SUMIN) * parseInt(coverage.old.T7072.NOUNTS);
                if (prms.comp.coverageObj && prms.comp.coverageObj.benefit && prms.comp.coverageObj.benefit.length <= 0)
                    capSI = parseFloat(coverage.old.T7072.SUMIN);
            }
            if ((coverage.old.T7072.IND == 'F' || coverage.old.T7072.IND == 'A') && parseFloat(coverage.old.T7072.ZSORIG) > 0)
                prms.comp.benefitFlag = true;

            if (coverage.old.T7072.CONTITEM != '' && contitem == '') {
                contitem = coverage.old.T7072.CONTITEM;
            }

            if (planAge == 0) {
                planAge = coverage.old.T7072.AGE;
                prms.comp.onagechange.emit(coverage.old.T7072.AGE);
            }

            prms.comp.coverageObj[prms.comp.coverageName].push(coverageInfo);
        }

        prms.comp.emitTotal();
        if (prms.comp.coverageObj.benefit.length <= 0)
            prms.comp.onsichange.emit(capSI);
    }
}

export class CoverageInfo {
    public benefitIndex: number;
    public coverageCode: string;
    public coverageDescription: string;
    public benefits: number = 0;
    public newSI: number = 0;
    public premium: number = 0;
    public rate: number = 0;
    public load: number = 0;
    public indicator: string;
    public nounts: number = 0;
    public optno: string;
    public optind: string;
    public contitem: string;
}
