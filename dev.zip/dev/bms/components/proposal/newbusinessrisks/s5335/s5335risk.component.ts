/*
Change History	:

	No      Date          Description                                 Changed By
	====    ==========    ===========                                 ==========
	MD001   14/03/2018      MYS-2018-0130 - Occupation Code to be Read 
	                        from T9109 - for All Personal Lines Products            MKU1	
    MD002   14/03/2018      UAT issue raised during SAF MYS-2017-0920
                            where risk classification is NOT being set on           MKU1
                            loading the risk.                 
 *  KA0001  12/06/2018      MYS-2018-0555   To aupopulate DOB,age & gender          Divek 
    GA001   09/07/2018      MYS-2018-0443 - Age Checking for PA Products (T7253)    KGA
 *  MO001	09/10/2018      MYS-2018-0904:  HD Log: Incorrect Occupation 
 *                          Description populates for PA and Motor products         RMO
 *                          in BMS 
 *  VK007   21/05/2019      MYS-2018-0993 NGA File Upload + Security Fixes          VKR
 * 
 *  VK014   20/09/2019      MYS-2019-1005   Incorrect premium when plan change      VKR
 *                          after Renewal Enquiry for PA product in BMS
 * 
 */
import { Component, OnInit, ViewChild, ElementRef, EventEmitter, AfterViewInit, ViewContainerRef } from '@angular/core';
import { DCLInput, CustomDCLService } from '../../../../../common/services/customdcl.service';
import { LOV_Field, LOVDropDownService, SearchFilter } from "../../../../../common/services/lovdropdown/lovdropdown.service";
import { S5335, S5336ItemDetails, Benefit, PADriverDetails, AdditionalCoverageDetails, AdditionalCoverage } from './appobjects/s5335';
import { ModalInput } from '../../../../../common/components/utility/modal/modal';
import { SearchInput } from "../../../../../common/components/utility/search/genericsearch";
import { Clause } from "../appobjects/clause";
import { ClausesComponent } from "../uimodules/clauses.component";
import { NomineeDetails } from "../appobjects/nomineeslist";
import { GetLOVData, SearchAdvancedConfig, Filter } from '../../../../../common/components/utility/search/search.requests';
import { CordysSoapWService } from "../../../../../common/components/utility/cordys-soap-ws";
import { ProposalHeader } from '../../proposalheader/appobjects/proposalheader';
import { ClientDetails } from '../../../../../common/components/client/appobjects/client';
import { AlertMessagesService } from '../../../../../common/components/utility/alertmessage/alertmessages.service';
import { AlertMessage } from '../../../../../common/components/utility/alertmessage/alertmessages.model';
import { BMSConstants } from '../../../common/constants/bms_constants';
import { RiskClassificationService } from "../services/riskcls.service";
import { ReferralReasons, ReferralReason } from '../appobjects/referralReasons';//GA001
import { S5335Service } from "./services/s5335.service";//GA001

declare var moment: any;
declare var jQuery: any;
declare var numeral: any;

@Component({
    selector: 's5335-risk-component',
    templateUrl: 'app/bms/components/proposal/newbusinessrisks/s5335/s5335risk.template.html',
    inputs: ["parentRiskObj", "riskObj", 'clientDetails', 'headerInfo'],
    outputs: ['onPremiumChange', 'onSIChange', 'onpostedpremiumchange', 'onRiskClsChange', 'emitDuplicateCheck', 'emitonPlanChangeHandler'],
    providers: [S5335Service]
})
//GA001 - ADDED ( providers:[S5335Service] )
export class S5335RiskComponent implements OnInit {
    @ViewChild(ClausesComponent) private clausesComp: ClausesComponent;
    @ViewChild('paCompModal', { read: ViewContainerRef }) contentArea: ViewContainerRef;

    private el: HTMLElement;
    private isCollapsedMode: boolean = false;
    private collapseDriverInfo: boolean = false;
    //private collapseBasisInfo:boolean=false;
    private collapseInsuredInfo: boolean = false;
    private collapseVehiclelInfo: boolean = false;
    private isNomineeInfoCollapsed: boolean = false;
    private isCoverInfoCollapsed: boolean = false;
    private collapseClausesInfo: boolean = false;
    private isAddressDetailsCollapsed: boolean = false;
    private isRenewalBonusPlanCollapsed: boolean = false;

    private modelDesc: string = "";
    private DOBCtrl: any;
    public defaultClauseCode: string = "";

    public riskObj: S5336ItemDetails;
    public parentRiskObj: S5335;
    public yearOfManfactureList: Object[] = [];
    public seatNumList: Object[] = [];
    public seatPremList: SeatPremInfo[] = [];
    public disableForm = 'N';
    public clientDetails: ClientDetails;
    public headerInfo: ProposalHeader;
    onPremiumChange = new EventEmitter<any>();
    onSIChange = new EventEmitter<any>();
    onpostedpremiumchange = new EventEmitter<any>();
    onRiskClsChange = new EventEmitter<any>();
    emitDuplicateCheck = new EventEmitter<any>();
    emitonPlanChangeHandler = new EventEmitter<any>();

    public siFormat: string = "0,00";
    public bonusFormat: String = "0.00";
    public premiumFormat: string = "0,00.00";
    public rateFormat: string = "0.00000";
    public loadFormat: string = "0.00";
    public percentFormat: string = "0.00";
    public longNumberFormat: string = "0000";
    public yearFormat: string = "0000";
    private renewalBonusAmountCtrl: any;
    private renewalBonusPercentageCtrl: any;
    private disableRenewalBonusAmount = "N";
    private disableRenewalBonusPercentage = "N";
    public minimumAge = 16;
    public isPassportFilled = "Y";
    public isNRICFilled = "Y";
    public passportFieldStyleClass = "mandatory";
    public nricFieldStyleClass = "mandatory";
    private isGeneralPageCollapsed: boolean = false;
    private referralReasons = [];//GA001
    // MO001: Added this variable to identify the Onchange Event of Occupation code
    // in the Success Call back Function.
    private isOccupationCodeChanged: boolean = false;

    //GA001 ADDED (S5335Service)
    constructor(public dcl: CustomDCLService, private lovDropDownService: LOVDropDownService, private _soapService: CordysSoapWService, public _alertMsgService: AlertMessagesService, public riskClassificationService: RiskClassificationService, private _s5335Service: S5335Service) {

    }

    ngAfterViewInit() {
        //this.setRiskClassification(this);
        //this.setFormDisabled();
        if (this.headerInfo.asyncPostingStatus == "InProgress") {
            this.disableForm = "Y";
        } else if (this.riskObj.contractNumber != "") {
            this.disableForm = "Y";
        }
        else {
            this.disableForm = "N";
        }
    }

    setFormDisabled() {
        if (jQuery("#bmsForm").prop("disabled") == true) {
            this.disableForm = "Y";
        }
    }
    /**********************************************************************************
     *                                         Initializations
     **********************************************************************************/
    ngOnInit() {
        //this.correctDOB();
        this.populateLOVs();
        this.listForYearofManfacture(20);
        //this.initChilds();
        if (this.clientDetails)
            this.setClientInfo();
        this.checkDuplicates("");
        if (this.riskObj.rbpCode == "")
            this.getRenewalBonusPlanDetails();
        //Logic hidden to fetch the seat number validation.
        if ((this.riskObj.riskType == "MSW" || this.riskObj.riskType == "MWP" || this.riskObj.riskType == "MWH") && this.riskObj.plan)
            this.populateSeatsLOV(this.riskObj.riskType + this.riskObj.plan);
        if (this.riskObj.contractNumber != "") {
            this.disableForm = "Y";
        }
        //if(!(this.riskObj.renewalBonusPercentage == undefined || this.riskObj.renewalBonusPercentage == '')){
        if (parseFloat("" + this.riskObj.renewalBonusPercentage) > 0) {
            this.disableRenewalBonusAmount = "Y";
        }
        //if(!(this.riskObj.renewalBonusAmount == undefined || this.riskObj.renewalBonusAmount == '')){
        if (parseFloat("" + this.riskObj.renewalBonusAmount) > 0) {
            this.disableRenewalBonusPercentage = "Y";
        }
        this.getEntryBonusPercentage();
        if (this.riskObj.insuredAge == 0 && this.riskObj.dateOfBirth) {
            this.setInsuredAge();
            this.checkReferredRisk(this);
        }
        //VK007 Added Code to get The default clauses
        if (!(this.riskObj.plan == undefined)) {
            this.emitonPlanChangeHandler.emit(this.riskObj.riskType + this.riskObj.plan);
        }
    }
    getEntryBonusPercentage() {
        if ((this.riskObj.riskType == 'PMA' || this.riskObj.riskType == 'PMB') && this.riskObj.entryBonusPercentage <= 0) {
            let request: GetLOVData = new GetLOVData().getRequest('ALL', 'ALL', 'NEW BUSINESS', 'ALL', 'NEW', 'S5336', 'EntryBonus', 'LOV');
            request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
            request.ADVANCE_CONFIG_XML.FILTERS = new Filter();
            request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({ "@FIELD_NAME": 'DESCITEM', "@FIELD_VALUE": this.riskObj.riskType, '@OPERATION': 'EQ', '@CONDITION': 'AND' },
                { "@FIELD_NAME": 'ITMFRM', "@FIELD_VALUE": moment(this.headerInfo.effectiveDate, "YYYY-MM-DD").format("YYYYMMDD"), '@OPERATION': 'LT', '@CONDITION': 'AND' },
                { "@FIELD_NAME": 'ITMTO', "@FIELD_VALUE": moment(this.headerInfo.effectiveDate, "YYYY-MM-DD").format("YYYYMMDD"), '@OPERATION': 'GT', '@CONDITION': 'AND' });
            this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.entryBonusSuccessHandler, this.handleError, true, { comp: this });
        }
    }
    entryBonusSuccessHandler(response, prms) {
        if (response && response.tuple) {
            prms.comp.riskObj.entryBonusPercentage = parseFloat(response.tuple.old.T9043.ENTRY_BONUS);
        }
    }
    onRenewalBonusPercentageChange(evt) {
        if (parseFloat("" + evt.target.value) > 0) {
            if (this.renewalBonusAmountCtrl != null)
                this.renewalBonusAmountCtrl.setDisable("Y", this.renewalBonusAmountCtrl.comp);
        } else {
            if (this.renewalBonusAmountCtrl != null)
                this.renewalBonusAmountCtrl.setDisable("N", this.renewalBonusAmountCtrl.comp);
        }
    }

    onRenewalBonusAmountChange(evt) {
        if (parseFloat("" + evt.target.value) > 0) {
            if (this.renewalBonusPercentageCtrl != null)
                this.renewalBonusPercentageCtrl.setDisable("Y", this.renewalBonusPercentageCtrl.comp);
        } else {
            if (this.renewalBonusPercentageCtrl != null)
                this.renewalBonusPercentageCtrl.setDisable("N", this.renewalBonusPercentageCtrl.comp);
        }
    }

    onChangeBasis(evt) {
        if (evt.value != 'NAMED') {
            this.riskObj.noOfPerson = "1";
            this.setTotalPremium();
            this.riskObj.insuredSalutation = "";
            this.riskObj.insuredPerson = "";
            this.riskObj.insuredOccCode = ""; // MD001
            this.riskObj.insuredOccDescription = "";//MD001
            this.riskObj.IdProofNo = "";
            this.riskObj.NRIC = "";
            this.riskObj.dateOfBirth = "";
            this.riskObj.gender = "";
            this.riskObj.maritalStatus = "";
        } else {
            this.riskObj.noOfPerson = "1";
            this.setTotalPremium();
        }
    }



    private populateLOVs(): void {
        //GA001 ADDED ("referralReasons", "referralAgeLimits")
        this.lovDropDownService.createLOVDataList(["Salutation", "InsuredOccupation", "ratingClass", "Gender", "MaritalStatus", "make", "addressType", "referralReasons", "referralAgeLimits"]);//MD001 changed occupation to Insured Occ
        let occNewSearchFilterNodes: any[];
        let lob = "ALL";
        let occTable = 'T3644';
        if (this.headerInfo.lineOfBusiness == 'PA') {
            let occCodeFilter = (this.riskObj.riskType.length == 2) ? this.riskObj.riskType + ' ' : this.riskObj.riskType;
            let occNewSearchFilter = [new SearchFilter("DESCITEM", occCodeFilter, "STARTSWITH", "AND")];
            occNewSearchFilterNodes = this.lovDropDownService.createFilter(occNewSearchFilter);
            lob = 'PA';
            occTable = 'T9109';
        }

        let riskFilter = (this.riskObj.riskType.length == 2) ? this.riskObj.riskType + ' ' : this.riskObj.riskType;//GA001
        let referralAgeLimitNodes = this.lovDropDownService.createFilter([new SearchFilter("DESCITEM", riskFilter, "EQ", "AND")]);//GA001
        let lovFields = [
            new LOV_Field("ALL", "CLIENT", "ALL", "ALL", "NEW", "CLIENT_DETAILS", "Salutation", "LOV", [], "DESCPF", "Salutation", null),
            new LOV_Field("ALL", lob, "NEW BUSINESS", "ALL", "NEW", "ALL", "Occupation", "LOV", occNewSearchFilterNodes, occTable, "InsuredOccupation", null),//MD001 
            new LOV_Field("ALL", "PERSONAL ACCIDENT", "NEW BUSINESS", "ALL", "NEW", "PERSONAL ACCIDENT", "RatingClass", "LOV", [], "DESCPF", "ratingClass", null),
            new LOV_Field("ALL", "MOTOR", "NEW BUSINESS", "ALL", "NEW", "NAMED_DRIVER", "Sex", "LOV", [], "DESCPF", "Gender", null),
            new LOV_Field("ALL", "CLIENT", "ALL", "ALL", "NEW", "CLIENT_DETAILS", "Marital Status", "LOV", [], "DESCPF", "MaritalStatus", null),
            new LOV_Field("ALL", "MED", "ALL", "ALL", "ALL", "ALL", "Referral Reasons", "LOV", [], "DESCPF", "referralReasons", "callbackForReferralReasons"),
            new LOV_Field("ALL", "MED", "ALL", "ALL", "ALL", "ALL", "Referral Age Limits", "LOV", referralAgeLimitNodes, "T7253", "referralAgeLimits", "callbackReferralAgeLimits")
        ];//GA001 ADDED ("referralReasons", "referralAgeLimits")
        this.lovDropDownService.util_populateLOV(lovFields, this);
        //  this.riskObj.insuredOccCode = this.riskObj.occupationCode;// Commented by MKU1

        if (this.riskObj.riskType == 'MSW' || this.riskObj.riskType == 'MWP' || this.riskObj.riskType == 'MWH' || this.riskObj.riskType == 'MPA') {
            this.populateLOVForMotorProducts();
        }
    }
    private populateLOVForMotorProducts(): void {

        this.lovDropDownService.createLOVDataList(["postCode", "make", "addressType"]);

        let lovFields = [
            new LOV_Field("ALL", "FIRE", "NEW BUSINESS", "ALL", "NEW", "FIRE_IDC", "PostCode", "LOV", [], "DESCPF", "postCode", null),
            new LOV_Field("ALL", "MOTOR", "NEW BUSINESS", "ALL", "NEW", "PRIVATE_MOTOR", "Make", "LOV", [], "DESCPF", "make", null),
            new LOV_Field("ALL", "CLIENT", "ALL", "ALL", "NEW", "CLIENT_DETAILS", "Bus/Res", "LOV", [], "DESCPF", "addressType", null)
        ];
        this.lovDropDownService.util_populateLOV(lovFields, this);
    }
    correctDOB() {
        if (this.riskObj.dateOfBirth != null && this.riskObj.dateOfBirth == '99999999')
            this.riskObj.dateOfBirth = "";
    }
    setFocusToNext(elmnt) {
        let sutuationElmnts = jQuery(this.el).find("input");
        jQuery(sutuationElmnts[sutuationElmnts.index(elmnt) + 1]).focus();
    }
    listForYearofManfacture(number) {
        var year = Number(new Date().getFullYear());
        for (var index = number; index > 0; --index) {
            this.yearOfManfactureList.push(year);
            year--;
        }
    }
    filterModel(make) {
        this.riskObj.PADriverDetails.modelCode = "";
        this.modelDesc = make.description;
        this.riskObj.PADriverDetails.description = "";
        this.fillModel(make.value);
    }

    fillModel(makeCode) {
        this.lovDropDownService.createLOVDataList(["model"]);
        let filterDetails = [new SearchFilter("DESCITEM", makeCode + " ", "STARTSWITH", "AND")];
        let searchFilterNodes = this.lovDropDownService.createFilter(filterDetails);

        let lovFields = [new LOV_Field("ALL", "MOTOR", "NEW BUSINESS", "ALL", "NEW", "PRIVATE_MOTOR", "Model", "LOV", searchFilterNodes, "DESCPF", "model", null)];
        this.lovDropDownService.util_populateLOV(lovFields, this);
    }

    onChangeModel(event) {
        let value = event.target.value;
        let selectedModel = this.lovDropDownService.lovDataList.model.filter((model) => model.VALUE == value);
        this.riskObj.PADriverDetails.modelCode = selectedModel[0].VALUE1;
        this.riskObj.PADriverDetails.modelCodeNew = selectedModel[0].VALUE;

        let textValue = event.target.selectedOptions[0].innerText;
        this.riskObj.PADriverDetails.description = this.modelDesc + " " + textValue;
    }

    /**********************************************************************************
     *                                         Validations
     **********************************************************************************/

    addressDetailsKeyDown(event, addNumber) {
        if (addNumber == 1)
            this.riskObj.S5336AddressDetails.address1 = event.target.value.trim();
        else if (addNumber == 2)
            this.riskObj.S5336AddressDetails.address2 = event.target.value.trim();
        else if (addNumber == 3)
            this.riskObj.S5336AddressDetails.address3 = event.target.value.trim();
        else if (addNumber == 4)
            this.riskObj.S5336AddressDetails.address4 = event.target.value.trim();
        else if (addNumber == 5)
            this.riskObj.S5336AddressDetails.address5 = event.target.value.trim();
    }


    validateInput(event, dType, allowedLength) {
        if ([46, 8, 9, 27, 13, 110].indexOf(event.keyCode) !== -1 ||
            // Allow: Ctrl+A, Command+A
            (event.keyCode === 65 && (event.ctrlKey === true || event.metaKey === true)) ||
            // Allow: home, end, left, right, down, up
            (event.keyCode >= 35 && event.keyCode <= 40)) {
            // let it happen, don't do anything
            return;
        }
        // Ensure that it is a number and stop the keypress
        if (dType = "integer") {
            let result = (event.target.value + "").match(/[^0-9]/g);
            if (event.key == ".") {
                //console.log("not allowed");
                return false;
            }
            if (event.target.value != undefined && event.target.value.length >= allowedLength) {
                //console.log("length failed");
                return false;
            }
        } else if (dType = "double") {
            let result = (event.target.value + "").match(/[^0-9.]/g);
            if (result) {
                //console.log("not allowed");
                return false;
            }
        }
        if ((event.shiftKey || (event.keyCode < 48 || event.keyCode > 57)) && (event.keyCode < 96 || event.keyCode > 105)) {
            event.preventDefault();
        }

    }
    onChangeAdditionalLoading(event, cover, index) {
        //cover.additionalLoading = event.target.value.trim(); 
        cover.additionalLoading = event;
        this.setAdditionalPremiumForEach(cover);
        this.getAdditionalPremiumTotal();
        this.setTotalPremium();
    }
    checkDuplicates(fieldName) {
        if (this.riskObj.NRIC != undefined && this.riskObj.NRIC != "") {
            this.isNRICFilled = "Y";
        } else {
            this.isNRICFilled = "N";
        }
        if (this.riskObj.IdProofNo != undefined && this.riskObj.IdProofNo != "") {
            this.isPassportFilled = "Y";
        } else {
            this.isPassportFilled = "N";
        }
        let insuredUniqueStr = (this.riskObj.insuredPerson == undefined ? "" : this.riskObj.insuredPerson.toLowerCase()) + "#" + (this.riskObj.IdProofNo == undefined ? "" : this.riskObj.IdProofNo.toLowerCase()) + "#" + (this.riskObj.NRIC == undefined ? "" : this.riskObj.NRIC.toLowerCase());
        for (let insuredItem of this.parentRiskObj.s5336Items.s5336Item) {
            if (insuredItem.itemNo != this.riskObj.itemNo) {
                let _insuredUniqueStr = (insuredItem.insuredPerson == undefined ? "" : insuredItem.insuredPerson.toLowerCase()) + "#" + (insuredItem.IdProofNo == undefined ? "" : insuredItem.IdProofNo.toLowerCase()) + "#" + (insuredItem.NRIC == undefined ? "" : insuredItem.NRIC.toLowerCase());
                if (_insuredUniqueStr == insuredUniqueStr) {
                    this.riskObj.insuredPerson = '';
                    this.riskObj.IdProofNo = '';
                    this.riskObj.NRIC = '';
                    this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Duplicate insured is not allowed.", 6000));

                    break;
                }
            }
        }

    }
    setClientInfo() {
        this.setInsuredAge();
        if (this.riskObj.riskType == "PAS") {
            if (this.riskObj.insuredOccCode != undefined && this.riskObj.insuredOccCode != "") {
                if (this.riskObj.insuredOccDescription == undefined || this.riskObj.insuredOccDescription == "") {
                    this.setOccDesForClient(this.riskObj.insuredOccCode);
                    //this.riskObj.occupationDescription = "STUDENT";
                    //this.riskObj.occRiskClassification = "Standard";
                    //this.setOccDesc(this.riskObj.occupationCode);
                } else {
                    if (this.riskObj.insOccRiskClassification == undefined || this.riskObj.insOccRiskClassification == "") {
                        this.setOccDesForClient(this.riskObj.insuredOccCode);
                    } else {
                        this.checkReferredRisk(this);
                    }
                }
            }
        } else {
            if (this.riskObj.insuredOccCode != undefined && this.riskObj.insuredOccCode != "") {
                this.setOccDesForClient(this.riskObj.insuredOccCode);
            }
        }
    }
    setPostCodeDesc(postCode) {

    }
    setOccDesc(occupation) {
        // MO001 - Set the below flag true to identify the Occupation Code Change from UI in the Success Call back function.
        this.isOccupationCodeChanged = true;
        if (occupation != undefined || occupation != "") {
            let lob = "ALL";
            let occFieldValue = this.riskObj.insuredOccCode;
            if (this.headerInfo.lineOfBusiness == 'PA') { //MD001
                lob = "PA";
                occFieldValue = (this.riskObj.riskType.length == 2) ? this.riskObj.riskType + ' ' : this.riskObj.riskType + "" + this.riskObj.insuredOccCode;
            }
            let request: GetLOVData = new GetLOVData().getRequest('ALL', lob, 'NEW BUSINESS', 'ALL', 'NEW', 'ALL', 'Occupation', 'LOV');//MD001                
            request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
            request.ADVANCE_CONFIG_XML.FILTERS = new Filter();
            request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({ "@FIELD_NAME": 'DESCITEM', "@FIELD_VALUE": occFieldValue, '@OPERATION': 'EQ', '@CONDITION': 'AND' });
            this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.occupationSuccessHandler, this.handleError, true, { comp: this });
        }
        //this.riskObj.occupationDescription = occupation.description;
    }
    setOccDesForClient(occupation) {
        this.isOccupationCodeChanged = false;
        if (occupation != undefined || occupation != "") {
            let lob = "ALL";
            let occFieldValue = this.riskObj.insuredOccCode;
            if (this.headerInfo.lineOfBusiness == 'PA') { //MD001
                occFieldValue = (this.riskObj.riskType.length == 2) ? this.riskObj.riskType + ' ' : this.riskObj.riskType + "" + this.riskObj.insuredOccCode;
                lob = "PA";
            }
            if (this.riskObj.insuredOccDescription == undefined || this.riskObj.insuredOccDescription == "" || this.riskObj.riskClassification == undefined || this.riskObj.riskClassification == "" || this.riskObj.riskClassification == 'Standard') {// MD002 Added Standard by MKU1 to display risk classification  , 
                let request: GetLOVData = new GetLOVData().getRequest('ALL', lob, 'NEW BUSINESS', 'ALL', 'NEW', 'ALL', 'Occupation', 'LOV');
                request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
                request.ADVANCE_CONFIG_XML.FILTERS = new Filter();
                request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({ "@FIELD_NAME": 'DESCITEM', "@FIELD_VALUE": occFieldValue, '@OPERATION': 'EQ', '@CONDITION': 'AND' });
                this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.occupationSuccessHandler, this.handleError, true, { comp: this });
            }
        }
        //this.riskObj.occupationDescription = occupation.description;
    }
    validateRebatePctg() {
        if (Number(this.riskObj.rebatePercentage) > 25) {
            this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Max. Allowed Value for Rebate is 25% only", 5000));
            this.riskObj.rebatePercentage = 0;
        }
    }

    occupationSuccessHandler(response, prms) {
        let referedRisk: string = "";
        if (response.tuple) {
            referedRisk = prms.comp.headerInfo.lineOfBusiness == 'PA' ? response.tuple.old.T9109.REFERREDRISK : response.tuple.old.T3644.REFERREDRISK;
            // MO001 - Setting the occupation description value only when the Occupation Code is changed from UI 
            // or Occupation Description is empty and Occupation code is not empty.
            if (prms.comp.isOccupationCodeChanged == true || prms.comp.riskObj.insuredOccDescription == undefined
                || prms.comp.riskObj.insuredOccDescription == null || prms.comp.riskObj.insuredOccDescription == "") {
                prms.comp.riskObj.insuredOccDescription = prms.comp.headerInfo.lineOfBusiness == 'PA' ? response.tuple.old.T9109.DESCRIPTION : response.tuple.old.T3644.DESCRIPTION;// MD001 changed occ to insured occ
            }

            if (referedRisk == '' || referedRisk == 'N') {
                prms.comp.riskObj.insOccRiskClassification = "Standard";
            }
            else if (referedRisk == 'Y') {
                prms.comp.riskObj.insOccRiskClassification = "Referred";
            }
            else if (referedRisk == 'D') {
                prms.comp.riskObj.insOccRiskClassification = "Declined";
            }
        }
        //prms.comp.riskObj.occRiskClassification = prms.comp.riskObj.symRiskClassification;
        //prms.comp.checkReferredRisk(prms.comp); -- commented
        //VK007
        prms.comp._s5335Service.checkOccupationReferredRiskConditions(prms.comp.riskObj, prms.comp.lovDropDownService.lovDataList.InsuredOccupation, prms.comp.lovDropDownService.lovDataList.referralReasons, prms.comp.referralReasons,prms.comp);

        if (referedRisk == 'Y' ) {
            prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Selected occupation code is referred.", 6000));

        }

        // MO001 - Resetting the Occupation Code Change flag after the success call back function is executed.
        prms.comp.isOccupationCodeChanged = false;
    }

    checkReferredRisk(comp) {
        this.riskClassificationService.setRiskClassification(comp.parentRiskObj.riskNumber, "N", comp.riskObj.itemNo, "").subscribe();
    }

    setRiskClassification(comp) {
        if (comp.riskObj.symRiskClassification != null && comp.riskObj.symRiskClassification != "" && (comp.riskObj.symRiskClassification == "Referred" || comp.riskObj.symRiskClassification == "Declined")) {
            let statusTxt = (comp.riskObj.symRiskClassification != null && comp.riskObj.symRiskClassification != "") ? comp.riskObj.symRiskClassification : comp.riskObj.riskClassification;
            comp.riskObj.riskClassificationReason = "System marked as " + statusTxt;
        }
        else {
            if (comp.riskObj.riskClassificationReason != null && comp.riskObj.riskClassificationReason != "" && (comp.riskObj.riskClassificationReason != "System marked as Standard"
                && comp.riskObj.riskClassificationReason.indexOf("System marked as ") != -1)) {
                comp.riskObj.riskClassificationReason = "";
            }
        }
        comp.onRiskClsChange.emit('');
    }

    changeRiskClassification(event) {
        this.riskObj.riskClassification = event.target.value;
        this.riskObj.symRiskClassification = event.target.value;
        //this.onRiskClsChange.emit('');
        this._s5335Service.handleRiskClassification(this);
    }

    onChangeNRIC(value) {
        if (value != null && value != "") {
            let isValidFormat = new RegExp("[0-9]{6}-[0-9]{2}-[0-9]{4}$").test(value);
            if (isValidFormat == false) {
                this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Invalid NRIC format. Correct format is YYMMDD-XX-XXXX.", 5000));
                this.riskObj.NRIC = "";
            }
            else {
                let givenDate = value.substr(0, 6);
                let finalDate = givenDate;
                let century = value.substring(0, 2);

                if (Number(century) > 29)
                    givenDate = '19' + givenDate;
                else
                    givenDate = '20' + givenDate;

                let dob = moment(givenDate, "YYYYMMDD");
                let curDate = moment(new Date().toISOString(), "YYYYMMDD");
                if (curDate.diff(dob, 'days') < 0)
                    givenDate = '19' + givenDate.substring(2, 6);
                finalDate = givenDate;

                if (moment(givenDate, "YYYYMMDD").toDate() == "Invalid Date") {
                    finalDate = "";
                    this.riskObj.NRIC = "";
                    this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Invalid date in NRIC.", 5000));
                } /* else {
                    finalDate = moment(givenDate, "YYMMDD").format("YYYYMMDD");
                } */

                if (this.DOBCtrl != null && finalDate != "")
                    this.DOBCtrl.setter(moment(finalDate, "YYYYMMDD").format("YYYY-MM-DD"), "YYYY-MM-DD", this.DOBCtrl.comp);
                else if (this.DOBCtrl != null && finalDate == "")
                    this.DOBCtrl.setter("EMPTY", "YYYY-MM-DD", this.DOBCtrl.comp);
                // Divek Added for -0555 START
                let gender = value.substr(13, 13);
                if ((gender % 2) == 0) {
                    this.riskObj.gender = "F";
                }
                else {
                    this.riskObj.gender = "M";
                }
                //END
            }
        }
    }
    validateDOB(value) {
        if (value != null && value != "") {
            let curDate = moment().format("YYYYMMDD");
            if (Number(curDate) < Number(moment(value, "YYYY-MM-DD").format("YYYYMMDD"))) {
                this.DOBCtrl.setter("EMPTY", "YYYY-MM-DD", this.DOBCtrl.comp);
                this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "DOB can not be future date.", 5000));
            }
            else {
                this.DOBCtrl.setter(value, "YYYY-MM-DD", this.DOBCtrl.comp);
                //this.checkReferredRisk(this);
            }
        }
    }
    planChangeHandler(value) {
        if (this.riskObj.riskType == "MSW" || this.riskObj.riskType == "MWP" || this.riskObj.riskType == "MWH") {
            this.populateSeatsLOV(this.riskObj.riskType + this.riskObj.plan);
        }
        this.calculateDefaultClauseCode(value);
        this.checkReferredRisk(this);
        this.emitonPlanChangeHandler.emit(value);
    }
    checkAgeValidation(value) {
        this.riskObj.planAgeLimit = Number(value);
        this.setInsuredAge();
        this.checkReferredRisk(this);
    }

    //Divek MYS-2018-0555 changes Start
    setInsuredAge() {
        if (this.riskObj.dateOfBirth != null && this.riskObj.dateOfBirth != "") {
            let curDate = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.effectiveDate
            let date = moment(this.riskObj.dateOfBirth, "YYYY-MM-DD").format("YYYY-MM-DD");
            let dobYear = date.substring(0, 4);
            let inclDtYear = curDate.substring(0, 4);
            let age = inclDtYear - dobYear;
            this.riskObj.insuredAge = age;

        }
        else {
            this.riskObj.insuredAge = 0;
            //this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "DOB can not be empty.", 5000));            
        }
    }
    //Divek MYS-2018-0555 changes END

    isItInAgeRange() {
        // PAS Risk Min=2 && Max 18
        if (this.riskObj.riskType == 'PAS') {
            if (!(Number(this.riskObj.insuredAge) >= 2 && Number(this.riskObj.insuredAge) <= 18))
                return false;
            else
                return true;
        } else {
            //Other products Age above 70 to be treated as Referred
            if (Number(this.riskObj.insuredAge) > 70) {
                return false;
            }
            else {
                return true;
            }
        }
    }
    calcDays() {
        let date1 = moment(this.riskObj.dateStart, "YYYY-MM-DD");
        let date2 = moment(this.riskObj.lastDateEnd, "YYYY-MM-DD");
        return date2.diff(date1, 'days') + 1;//added +1 to always include endDate for calculation
        //return Math.ceil(timeDiff / (1000 * 3600 * 24));
    }
    validateYearManfacture(value) {
        if ((value == "" || isNaN(value) || value.length != 4) || value > new Date().getFullYear() || value < 1900) {
            this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Please fill Valid Value for field Year Manfacture in YYYY and should be between 1900 and current year(" + new Date().getFullYear() + ").", 5000));
            this.riskObj.PADriverDetails.yearOfMake = "";
        }
    }

	/**********************************************************************************
	 *                                         Renewal Bonus Plan services
	 **********************************************************************************/
    getRenewalBonusPlanDetails() {
        let request: GetLOVData = new GetLOVData().getRequest('ALL', 'ALL', 'NEW BUSINESS', 'ALL', 'NEW', 'S5336', 'RenewalBonusPlanDetails', 'LOV');
        request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        request.ADVANCE_CONFIG_XML.FILTERS = new Filter();

        request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push(
            { "@FIELD_NAME": 'A.DESCITEM', "@FIELD_VALUE": this.headerInfo.contractType + '' + this.riskObj.riskType, '@OPERATION': 'EQ', '@CONDITION': 'AND' },
            { "@FIELD_NAME": 'A.ITMFRM', "@FIELD_VALUE": moment(this.headerInfo.effectiveDate, "YYYY-MM-DD").format("YYYYMMDD"), '@OPERATION': 'LT', '@CONDITION': 'AND' },
            { "@FIELD_NAME": 'A.ITMTO', "@FIELD_VALUE": moment(this.headerInfo.effectiveDate, "YYYY-MM-DD").format("YYYYMMDD"), '@OPERATION': 'GT', '@CONDITION': 'AND' });
        this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.handleRenewalBonusPlanDetails, this.handleError, true, { comp: this });

    }
    handleRenewalBonusPlanDetails(response, prms) {
        let ary = [];
        if (response.tuple != null && !Array.prototype.isPrototypeOf(response.tuple)) {
            ary = [response.tuple];
            prms.comp.riskObj.rbpCode = ary[0].old.T7494.ZRBONUSPLN;
            prms.comp.riskObj.rbpDesc = ary[0].old.T7494.LONGDESC;
            prms.comp.riskObj.rbpMethod = ary[0].old.T7494.METHOD;
            prms.comp.riskObj.rbpSIAdjustment = ary[0].old.T7494.ZRNBONUS;
            prms.comp.riskObj.rbpMaxYears = ary[0].old.T7494.ZMAXYR;
            prms.comp.riskObj.rbpRestartRBPlan = ary[0].old.T7494.ZRBRESET;
        }
        else if (response.tuple != null) {
            ary = response.tuple;
        }
    }
	/**********************************************************************************
	 *                                         Premium Calculations
	 **********************************************************************************/
    getTotalByProperty(prop, ary) {
        let total = numeral(0);
        for (let eachItem of ary) {
            if (eachItem[prop] != null && eachItem[prop] != "")
                total = total.add(numeral().unformat(eachItem[prop]));
        }
        total = numeral(total).format('0.00');
        return total;
    }
    setSI(siValue) {
        let si = parseInt(siValue);
        this.riskObj.sumInsured = si;
        this.onSIChange.emit(si);
        this.riskObj.sumInsured = numeral(this.riskObj.sumInsured).format('000');
    }
    resetAdditionalPremiumForEach() {
        for (let adCover of this.riskObj.additionalCoverDetails.additionalCover) {
            this.setAdditionalPremiumForEach(adCover);
        }
        this.getAdditionalPremiumTotal();
        //this.setLoadAndPremium();
        this.setTotalPremium();
    }
    setAdditionalPremiumForEach(coverage) {
        let rate = (coverage.additionalLoading == null || coverage.additionalLoading == "") ? 0 : coverage.additionalLoading;
        coverage.addditionalPremium = (numeral().unformat(this.riskObj.basicPremium) * (numeral().unformat(rate) * 0.01));
        coverage.addditionalPremium = numeral(coverage.addditionalPremium).format('0.00');
    }

    getAdditionalPremiumTotal() {
        let total = this.getTotalByProperty("addditionalPremium", this.riskObj.additionalCoverDetails.additionalCover);
        this.riskObj.addditionalPremium = total;
        return total;
    }
    setTotalPremium() {
      
        this.riskObj.totalPremium = (numeral().unformat(this.riskObj.basicPremium) + numeral().unformat(this.riskObj.addditionalPremium));
        this.riskObj.originalTotalPremium = this.riskObj.totalPremium;
        this.riskObj.discountedPremium = this.riskObj.totalPremium;
        this.setLoadAndPremium();
        this.onPremiumChange.emit(this.riskObj.totalPremium);
    }
    setLoadAndPremium() {
        let loadingPercent = 0;
        if (this.riskObj.loadingDiscountPercentage != undefined)
            loadingPercent = numeral().unformat(this.riskObj.loadingDiscountPercentage);

        //VK014
        //this.riskObj.rebate = this.headerInfo.rebate;
        //this.riskObj.rebateAmount = Number(numeral().unformat(this.riskObj.originalTotalPremium) / 100 * numeral().unformat(this.riskObj.rebate));
        
        if(this.headerInfo.caseId.substr(0,2) == "RN")
        this.riskObj.rebateAmount = 0;

        //VK014

        let tempAmount = numeral().unformat(this.riskObj.totalPremium) + numeral().unformat(this.riskObj.seatPremium);
        this.riskObj.loadingDiscountAmount = Number(tempAmount * (loadingPercent / 100));
        this.riskObj.totalAnnualPremium = Number(this.riskObj.totalPremium) + Number(this.riskObj.loadingDiscountAmount) + Number(numeral().unformat(this.riskObj.seatPremium)) - Number(this.riskObj.rebateAmount);
        this.riskObj.totalAnnualPremium = Number(this.riskObj.totalAnnualPremium) * Number(this.riskObj.noOfPerson);
        this.riskObj.loadingDiscountAmount = numeral(this.riskObj.loadingDiscountAmount).format('0.00');

        this.setPostingPremium();
    }

    

    calculateDefaultClauseCode(value) {
        this.defaultClauseCode = value;
    }
    
    setPostingPremium() { // Changed by MKU1 ie., Not divide totalpremium with 365
        let startDate = moment(this.riskObj.dateStart, "YYYY-MM-DD");
        let endDate = moment(this.riskObj.lastDateEnd, "YYYY-MM-DD");
        let dateRange = moment.range(startDate, endDate);
        let isLeapYear = this.dateRangeContainsLeapYear(dateRange);
        let noofdays = 365;
        if (isLeapYear)
            noofdays = 366;

        this.riskObj.postingPremium = ((this.riskObj.totalAnnualPremium) / noofdays) * this.calcDays();
        this.riskObj.totalAnnualPremium = numeral(this.riskObj.totalAnnualPremium).format('0.00');
        this.riskObj.postingPremium = numeral(this.riskObj.postingPremium).format('0.00');
        //this.onpostedpremiumchange.emit("");
    }
    dateRangeContainsLeapYear(dateRange: any) {//MD00_
        for (var year = dateRange.start.year(); year <= dateRange.end.year(); year++) {
            var date = moment(year + '-02-29');
            if (date.isLeapYear() && dateRange.contains(date)) return true;
        }
        return false;
    }

    /**********************************************************************************
     *                                      Additional Coverage handling
     **********************************************************************************/
    openAdditionalCoverageDetailsDialog() {
        if (this.riskObj.plan == undefined || this.riskObj.plan == "") {
            this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Please select plan.", 5000));
            return false;
        }
        let searchInput = new SearchInput();
        searchInput.isSingleSelect = false;
        searchInput.BRANCH = 'ALL';
        searchInput.BUSINESS_FUNCTION = 'NEW BUSINESS';
        searchInput.FIELD_TYPE = 'LOOKUP';
        searchInput.FORM_FIELD_NAME = 'Additional Coverage';
        searchInput.FORM_NAME = 'ALL';
        searchInput.LOB = 'ALL';
        searchInput.OPERATION = 'NEW';
        searchInput.PRODUCT = 'ALL';

        if (this.riskObj.additionalCoverDetails.additionalCover.length > 0) {
            let newArr = [];
            for (let item of this.riskObj.additionalCoverDetails.additionalCover) {
                newArr = newArr.concat(item["additionalCode"]);
            }
            let additionalCoverCodes = "'" + newArr.toString().replace(/,/g, "\',\'") + "'";
            searchInput.condition = { "A.DESCITEM": additionalCoverCodes };
        }
        else
            searchInput.condition = { "A.DESCITEM": "''" };

        let input = new ModalInput().get("GenericSearchComponent");
        input.datainput = searchInput;
        input.outputCallback = this.addAdditionalCoverage;
        input.containerRef = this.contentArea;
        input.parentCompPRMS = { comp: this };
        input.heading = "Additional Cover Details";
        input.icon = "fa fa-file-pdf-o";
        this.dcl.openLookup(input);
    }
    addAdditionalCoverage(listOfAdditionalCoverage, prms) {
        for (let eachCover of listOfAdditionalCoverage) {
            let adcover = new AdditionalCoverage();
            adcover.additionalCode = eachCover.old.DESCPF.VALUE;
            adcover.additionalCover = eachCover.old.DESCPF.LONGDESC;
            prms.comp.riskObj.additionalCoverDetails.additionalCover.push(adcover);
            prms.comp.setClauses([eachCover.old.DESCPF.VALUE], false);
        }
    }
    removeAdditionalCover(idx: number) {
        let addnlCover = this.riskObj.additionalCoverDetails.additionalCover[idx];
        this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Deleted Benefit Successfully : " + addnlCover.additionalCode, 5000));
        this.riskObj.additionalCoverDetails.additionalCover.splice(idx, 1);
        this.deleteClause(this.riskObj.clauses.clause, addnlCover.additionalCode, "clauseCode");
        this.resetAdditionalPremiumForEach();
    }
    setClauses(clausesList, flag) {
        if (this.clausesComp)
            this.clausesComp.addClause(clausesList, '', flag);
    }
    deleteClause(ary, clauseCode, prop) {
        let val = undefined;
        if (ary.length > 0) {
            for (var index = 0, assoLength = ary.length; index < assoLength; index++) {
                if (ary[index][prop] != null && ary[index][prop] != "" && ary[index][prop] == clauseCode) {
                    val = index;
                    break;
                }
            }
        }
        if (val != undefined)
            this.clausesComp.removeClause(val, clauseCode);
    }

    /**********************************************************************************
     *                                      Generic Code
     **********************************************************************************/
    handleError(response, status, errorText, prms) {
        prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, response.responseJSON.faultstring.text, 5000));
    }

    /**********************************************************************************
     *                                      Commented Code
     **********************************************************************************/
    /* validateSeatNoChange(e){
         let vSeatNo = numeral().unformat(e.value);
         if(this.riskObj.riskType=="MPA" &&  vSeatNo>4){
             this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Maximum Seat# allowed is 4 only", 5000));
         }
         this.setSeatPremium(e);
     }*/
    populateSeatsLOV(value) {
        if (this.riskObj.plan != undefined && this.riskObj.plan != "") {
            let request: GetLOVData = new GetLOVData().getRequest('ALL', 'ALL', 'NEW BUSINESS', 'ALL', 'NEW', 'S5336', 'SeatPremium', 'LOV');
            request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
            request.ADVANCE_CONFIG_XML.FILTERS = new Filter();

            request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push(
                { "@FIELD_NAME": 'DESCITEM', "@FIELD_VALUE": value, '@OPERATION': 'EQ', '@CONDITION': 'AND' },
                { "@FIELD_NAME": 'ITMFRM', "@FIELD_VALUE": moment(this.headerInfo.effectiveDate, "YYYY-MM-DD").format("YYYYMMDD"), '@OPERATION': 'LT', '@CONDITION': 'AND' },
                { "@FIELD_NAME": 'ITMTO', "@FIELD_VALUE": moment(this.headerInfo.effectiveDate, "YYYY-MM-DD").format("YYYYMMDD"), '@OPERATION': 'GT', '@CONDITION': 'AND' });
            this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.populateSeatsLOVSuccessHandler, this.handleError, true, { comp: this });
        }
    }

    populateSeatsLOVSuccessHandler(response, prms) {
        let ary = [];
        prms.comp.riskObj.seatPremium = 0;
        if (response.tuple != null && !Array.prototype.isPrototypeOf(response.tuple)) {
            ary = [response.tuple];
        }
        else if (response.tuple != null) {
            ary = response.tuple;
        }

        prms.comp.seatPremList = [];
        prms.comp.seatNumList = [];
        for (let item of ary) {
            let dpaSeatPrem: SeatPremInfo = {
                "PREM_PER_SEAT": item.old.T7277.PREM_PER_SEAT,
                "MIN_SEAT_ALLOWED": item.old.T7277.MIN_SEAT_ALLOWED,
                "MAX_SEAT_ALLOWED": item.old.T7277.MAX_SEAT_ALLOWED,
                "NOSEAT": item.old.T7277.NOSEAT,
                "TOTPRE": item.old.T7277.TOTPRE
            };
            prms.comp.seatPremList.push(dpaSeatPrem);
        }

        if (prms.comp.seatPremList != null && prms.comp.seatPremList.length > 0) {
            var index = prms.comp.seatPremList[0].MIN_SEAT_ALLOWED;
            while (Number(index) <= Number(prms.comp.seatPremList[0].MAX_SEAT_ALLOWED)) {
                prms.comp.seatNumList.push(index);
                index++;
            }
        }

        if (prms.comp.riskObj.seatNo)
            prms.comp.calculateSeatPremium(prms.comp.riskObj.seatNo, prms.comp.seatPremList);
    }

    calculateSeatPremium(seatNo, ary) {
        this.riskObj.seatPremium = 0;
        if (ary != null && ary.length > 0) {
            for (let item of ary) {
                if (this.riskObj.seatNo < Number(item.MIN_SEAT_ALLOWED) || this.riskObj.seatNo > Number(item.MAX_SEAT_ALLOWED)) {
                    this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Please provide Seats value between " + item.MIN_SEAT_ALLOWED + " and " + item.MAX_SEAT_ALLOWED, 1000));
                    this.riskObj.seatNo = 0;
                    return;
                }
                else {
                    if (this.riskObj.seatNo < Number(item.MAX_SEAT_ALLOWED) && Number(this.riskObj.seatNo) == Number(item.NOSEAT)) {
                        this.riskObj.seatPremium = numeral(item.TOTPRE).format('0.00');
                        this.riskObj.totalAnnualPremium = Number(this.riskObj.totalPremium) + Number(this.riskObj.seatPremium);
                    }
                }
            }

            if (this.riskObj.seatPremium != undefined && this.riskObj.seatPremium == Number(0)) {
                let item = ary[ary.length - 1];
                let total = 0;
                let diff = Number(this.riskObj.seatNo) - Number(item.NOSEAT);
                total = Number(item.TOTPRE) + Number(Number(item.PREM_PER_SEAT) * diff);
                this.riskObj.totalAnnualPremium = Number(this.riskObj.totalPremium) + Number(total);
                this.riskObj.seatPremium = numeral(total).format('0.00');
            }
            this.setLoadAndPremium();
            //this.setRebateAmount();
            this.onPremiumChange.emit("");
            //this.setPostingPremium();
        }
        else {
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Unable to fetch Seats Minimum and Maximum Allowed Information", 1000));
        }
    }

    setSeatPremium(event) {
        this.riskObj.seatNo = event.target.value;
        if (this.riskObj.plan != undefined && this.riskObj.plan != "") {
            this.calculateSeatPremium(this.riskObj.seatNo, this.seatPremList);
        }
        else {
            this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Please select plan before changing Seats Information.", 5000));
            this.riskObj.seatNo = 0;
            return;
        }
        if (this.riskObj.seatNo == 0) {
            this.riskObj.seatPremium = 0;
            this.setLoadAndPremium();
            this.onPremiumChange.emit("");
        }
    }

	
    //GA001 START
    onDOBChange(ev) {
        this.riskObj.dateOfBirth = ev;

        if (this.riskObj.dateOfBirth) {
            let dobDate = moment(this.riskObj.dateOfBirth, "YYYY-MM-DD");
            // var _endDate = moment(this.headerInfo.endDate, "YYYY-MM-DD");
            var _inclusionDate = moment(this.riskObj.inclusionDate, "YYYY-MM-DD");

            if (dobDate._i != _inclusionDate._i && dobDate > _inclusionDate) {
                this.riskObj.dateOfBirth = '';
                if (this.DOBCtrl != null) {
                    this.DOBCtrl.setter("EMPTY", "YYYY-MM-DD", this.DOBCtrl.comp);
                }
                this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Date of Birth must be before the policy Expiry date.", 3000));
            } else {
                if (this.riskObj.plan && this.riskObj.dateOfBirth) {
                    this.setPremium();
                }
            }
        }

        this._s5335Service.calculateAge(this.riskObj);
        let flag = this.checkReferredRiskConditions();
        if ("L" == flag) {
            return;
        }
    }

    checkReferredRiskConditions() {
        let caseInfo = BMSConstants.getBMSCaseInfo();
        let _ageLimitRec = this.lovDropDownService.lovDataList.referralAgeLimits.find((_data) => _data.DESCITEM == this.riskObj.riskType);

        if (["MSW", "MWP", "MWH", "MPA"].indexOf(this.headerInfo.contractType) == -1) {
            this._s5335Service.checkReferredRiskConditions(this.riskObj, this.headerInfo.contractType, _ageLimitRec, this.lovDropDownService.lovDataList.InsuredOccupation, this.lovDropDownService.lovDataList.referralReasons, this.referralReasons, caseInfo);
        } else {
            this.riskObj.ageLimitFlag = "";
        }

        if (this.riskObj.ageLimitFlag == "G") {
            this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Insured Age is exceeded maximum age.", 6000));
        }
        else if (this.riskObj.ageLimitFlag == "L") {
            this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Insured Age is less than minimum age.", 6000));
            //return this.riskObj.ageLimitFlag;
        }

        this._s5335Service.handleRiskClassification(this);
        return this.riskObj.ageLimitFlag;
    }

    setPremium() {
        this._s5335Service.calculatePremium(this.riskObj, this.parentRiskObj, this.headerInfo.effectiveDate);

        this.onSIChange.emit("");
        this.onPremiumChange.emit("");
    }

    callbackForReferralReasons(scopeObject) {
        //VK007 Added Code to Create referralReasons Object 
        if (scopeObject.riskObj.referralReasons == undefined) {
            scopeObject.riskObj.referralReasons = new ReferralReasons().getInstance(scopeObject.referralReasons);
        }
        for (let _refReason of scopeObject.lovDropDownService.lovDataList.referralReasons) {
            // let hasRefReason = scopeObject.referralReasons.some( _data => _data.code === _refReason.code );
            let hasRefReason = scopeObject.riskObj.referralReasons.referralReason.some(_data => _data.code == _refReason.code);
            if (!hasRefReason) {
                scopeObject.referralReasons.push(_refReason);
            }
        }
    }

    callbackReferralAgeLimits(scopeObject) {
        if (this.riskObj.insuredAge == 0 || (!this.riskObj.ageLimitFlag && this.riskObj.dateOfBirth && this.riskObj.insuredOccCode)) {
            let flag = this.checkReferredRiskConditions();
            if ("L" == flag) {
                return;
            }
        }
    }
    //GA001 END
}

export class SeatPremInfo {
    constructor(public PREM_PER_SEAT: string,
        public MIN_SEAT_ALLOWED: string,
        public MAX_SEAT_ALLOWED: string,
        public NOSEAT: string,
        public TOTPRE: string) { }
}