import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BasicUIModule } from '../../../../../common/components/utility/basicui.module';
import { FIModule } from '../../../../../common/components/financialinterest/fi.module';
import { LovModule } from "../../../../../common/services/lovdropdown/lov.module";
import { S5336CoverageModule } from "./s5336coverage.module";
import { ClausesModule } from '../uimodules/clauses.module';
import { NomineeModule } from "../uimodules/nominee.module";
import { GSTModule } from '../uimodules/gst.module';
import { S5335RiskComponent } from './s5335risk.component';
import { GeneralPageModule } from '../uimodules/generalpage.module'; //VK004

@NgModule({
    imports: [CommonModule, FormsModule, ReactiveFormsModule, BasicUIModule, FIModule, LovModule, ClausesModule, GSTModule, NomineeModule, S5336CoverageModule, GeneralPageModule],
    declarations: [S5335RiskComponent],
    exports: [S5335RiskComponent]
})
export class S5335RiskModule { }