import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BasicUIModule } from '../../../../../common/components/utility/basicui.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { PaginationModule } from '../../../../../common/components/utility/pagination/pagination.module';
import { SelectBoxModule } from "../../../../../common/components/utility/selectbox/selectbox.module";

import { S5336CoverageComponent } from './s5336coverage.component';

@NgModule({
    imports: [CommonModule, BasicUIModule, FormsModule, ReactiveFormsModule, PaginationModule, SelectBoxModule],
    declarations: [S5336CoverageComponent],
    exports: [S5336CoverageComponent]
})
export class S5336CoverageModule { }