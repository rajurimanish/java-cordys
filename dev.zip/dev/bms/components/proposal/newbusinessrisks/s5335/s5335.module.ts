import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RelatedCaseModule } from '../uimodules/relatedcase.module';
import { BasicUIModule } from '../../../../../common/components/utility/basicui.module';
import { FIModule } from '../../../../../common/components/financialinterest/fi.module';
import { LovModule } from "../../../../../common/services/lovdropdown/lov.module";
import { ClausesModule } from '../uimodules/clauses.module';
import { GSTModule } from '../uimodules/gst.module';
import { S5335RiskModule } from './s5335risk.module';
import { PaginationModule } from '../../../../../common/components/utility/pagination/pagination.module';
import { S5335Component } from './s5335.component';
import { GeneralPageModule } from '../uimodules/generalpage.module'; //VK004

@NgModule({
    imports: [ CommonModule, FormsModule, ReactiveFormsModule, BasicUIModule, FIModule, LovModule, ClausesModule, GSTModule, S5335RiskModule, PaginationModule, RelatedCaseModule, GeneralPageModule],
    declarations: [S5335Component],
    exports: [S5335Component]
})
export class S5335Module { }