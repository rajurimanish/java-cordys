import { Clause } from '../../appobjects/clause';
// import {FinancialInterest} from '../../../../../../common/components/financialinterest/appobjects/financialInterest';
import { GSTDetails } from '../../appobjects/gstDetails';
import { NBRisk } from '../../../appobjects/nbrisk';
import { RiskHelper } from '../../../appobjects/riskhelper';
import { PostedPrem } from '../../../proposalheader/appobjects/postedprem';
import { GenericValidator } from '../../../validation/generic.validator';
import { AppUtil } from '../../../../../../common/components/utility/apputil/app.util';
import { ReferredReason } from '../../../proposalheader/appobjects/referredreason';
import { ReferralReasons } from '../../appobjects/referralReasons';


export class Generic extends RiskHelper implements NBRisk {
    public sequenceNumber: string;
    public effectiveDate: string;
    public dateOfAttachment: string;
    public contractNumber: string;
    public contractType: string;
    public riskNumber: string;
    public riskType: string;
    public riskName: string;

    // public occupationCode: string;
    public occupationDesc: string;
    // public situation: string;
    public subjectivities: string;
    // public accumulationRegister: string;	

    public minimumPremium: number = 0;
    public originalTotalPremium: number = 0;
    public postedPremium: number = 0;
    public basePostedPremiumAdj: number = 0;
    public discountedPremium: number = 0;
    public grossPremium: number = 0;
    public totalPremium: number = 0;
    public capitalSumInsured: number = 0;
    public relatedSumInsured: number = 0;
    public totalGrossCapacity: number = 0;
    public totalSI: number = 0;
    public GST: number = 0;//6; //SAF MYS-2018-0629
    public gstAmount: number = 0;
    public rebate: number = 0;
    public rebateAmount: number = 0;
    public terminationDate: string;

    public riskCoverageDetails: RiskCoverageDetails;
    public customFields: CustomFields;
    public customClauses: CustomClauses;

    public clauses: Clause;
    // public financialInterest: FinancialInterest;
    public GSTDetails: GSTDetails;
    public defaultClauses: Clause;

    public riskClassification: string = "Standard";
    public riskClassificationReason: string = '';
    public symRiskClassification: string = "";
    public riRiskClassification: string = "Standard";
    public RIMethod: string = "0";
    public RIMethodSys: string = "0";
    public RIRequired: string = "No";
    public hasClaimExperience: string = "N";
    public FI: string = 'N';
    public isLeastPreferred: string = "N";
    // public identity: string="";
    // public identityFiller: string="";
    public isPOIConsidered: string = "N";
    public priority: string;
    public postedPremDetails: PostedPrem;

    public childRiskPath: string;
    public childRiskIdentity: string;
    public riskClassificationReasons: ReferredReason;
    public referralReasons: ReferralReasons;
    public isSurveyNeeded: string = 'N';

    public SST: number = 0; //SST
    public sstAmount: number = 0;//SST

    public RIRetentionCode: string;//Endorsements Code
    public construction: string;//Endorsements Code
    public constructionName: string;//Endorsements Code
    public isReferredToUW: string = "N";//Endorsements Code

    constructor() {
        super();
        this.riskCoverageDetails = new RiskCoverageDetails();
        this.customFields = new CustomFields();
        this.customClauses = new CustomClauses();
        this.clauses = new Clause();
        // this.financialInterest = new FinancialInterest();
        this.GSTDetails = new GSTDetails();
        this.riskClassificationReasons = new ReferredReason();
        this.referralReasons = new ReferralReasons();
    }

    public getInstance(valObj: Generic) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
            this.riskCoverageDetails = new RiskCoverageDetails().getInstance(valObj.riskCoverageDetails);
            this.customFields = new CustomFields().getInstance(valObj.customFields);
            this.customClauses = new CustomClauses().getInstance(valObj.customClauses);
            this.clauses = new Clause().getInstance(valObj.clauses);
            // if(valObj.FI == "Y"){
            // this.financialInterest = new FinancialInterest().getInstance(valObj.financialInterest);
            // }
            this.GSTDetails = new GSTDetails().getInstance(valObj.GSTDetails);
            this.riskClassificationReasons = new ReferredReason().getInstance(valObj.riskClassificationReasons);
            this.referralReasons = new ReferralReasons().getInstance(valObj.referralReasons);
        }
        return this;
    }

    public getNewInstanceByCriteria(criteria: any) {
        let riskType = criteria.riskType;
        let contractType = criteria.contractType;

        return this;
    }

    public getValidator() {
        return new GenericValidator(this);
    }
}

export class RiskCoverageDetails {

    public riskCoverage: RiskCoverage[] = [];

    public getInstance(valObj: RiskCoverageDetails) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
            new AppUtil().handleArray(this, valObj, "riskCoverage");
        }
        return this;
    }
}

export class RiskCoverage {
    public seqNumber: number;
    public interestInsured: string;
    public sumInsured: number;
    public rate: number;
    public load: number = 0;
    public premium: number;
    public premiumClass: string;
    public extraText: string = "";
    public existingSumInsured: number;//Endorsements Code

    constructor() {
    }

    public getInstance(valObj: RiskCoverage) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
        }
        return this;
    }
}


export class CustomFields {

    public customField: CustomField[] = [];

    public getInstance(valObj: CustomFields) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
            new AppUtil().handleArray(this, valObj, "customField");
        }
        return this;
    }
}

export class CustomField {
    public seqNumber: number;
    public label: string;
    public type: string;
    public value: string;
    public comments: string;

    constructor() {
    }

    public getInstance(valObj: CustomField) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
        }
        return this;
    }
}

export class CustomClauses {

    public customClause: CustomClause[] = [];

    public getInstance(valObj: CustomClauses) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
            new AppUtil().handleArray(this, valObj, "customClause");
        }
        return this;
    }
}

export class CustomClause {
    public seqNumber: number;
    public code: string;
    public description: string;

    constructor() {
    }

    public getInstance(valObj: CustomClause) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
        }
        return this;
    }
}




