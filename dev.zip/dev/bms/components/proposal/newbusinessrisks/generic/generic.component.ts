import { Component, OnInit, ViewChild, ElementRef, EventEmitter, AfterViewInit, ViewContainerRef } from '@angular/core';
declare var Observer: any;
import { DCLInput, CustomDCLService } from '../../../../../common/services/customdcl.service';
import { LOV_Field, LOVDropDownService, SearchFilter } from "../../../../../common/services/lovdropdown/lovdropdown.service";
import { CordysSoapWService } from "../../../../../common/components/utility/cordys-soap-ws";
import { GetLOVData, SearchAdvancedConfig, Filter } from '../../../../../common/components/utility/search/search.requests';
import { ProposalHeader } from '../../proposalheader/appobjects/proposalheader';
import { AlertMessagesService } from '../../../../../common/components/utility/alertmessage/alertmessages.service';
import { AlertMessage } from '../../../../../common/components/utility/alertmessage/alertmessages.model';
import { Generic, RiskCoverage, CustomField, CustomClause } from './appobjects/generic';
import { Clause } from "../appobjects/clause";
import { FinancialInterest } from '../../../../../common/components/financialinterest/appobjects/financialInterest';
import { ExtraTextDialogData } from "../dialogs/extratext.dialog.data";
import { ModalInput } from "../../../../../common/components/utility/modal/modal";
import { SearchInput } from "../../../../../common/components/utility/search/genericsearch";
import { BMSConstants } from '../../../common/constants/bms_constants';
import { CaseInfo } from '../../../../../common/components/appobjects/caseinfo';
import { PaginationModule } from '../../../../../common/components/utility/pagination/pagination.module';
import { PaginationPipe } from '../../../../../common/components/utility/pagination/filtertable.pipe';
import { FilterTableContentPipe } from '../../../../../common/components/utility/pagination/filtercontent.pipe';
import { ApplicationUtilService } from "../../../../../common/services/application.util.service";
import { BMSUtilService } from "../../../../services/bms.util.service";
import { AppUtil } from '../../../../../common/components/utility/apputil/app.util';
import { RiskClassificationService } from "../services/riskcls.service"; // added code for AccRegister
import { BMSAppObjService } from '../../../../services/bmsappobj.service';
import { RIService } from '../services/ri.service';
import { ReferredReason, Reasons } from '../../proposalheader/appobjects/referredreason';
import { ReferralReasons, ReferralReason } from '../appobjects/referralReasons';

declare var jQuery: any;
declare var moment: any;
declare var numeral: any;

@Component({
    selector: 'generic-risk-component',
    templateUrl: 'app/bms/components/proposal/newbusinessrisks/generic/generic.template.html',
    inputs: ['riskObj', 'clientDetails', "headerInfo", "caseInfo"],
    outputs: ["onPremiumChange", "onRiskClsChange", "onRtngFlgChange"],
    providers: [RiskClassificationService]// added code for AccRegister
})

export class GenericComponent implements OnInit {
    private el: HTMLElement;

    private coverageInfoCollapse: boolean = false;
    private customFieldsCollapse: boolean = true;
    private refrlReasonsCollapse: boolean = true;
    private customClausesCollapse: boolean = false;
    private clCBIInfoCollapse: boolean = false;
    private isLocationSectionCollapsed: boolean = false;
    private isImpNotesCollapsed: boolean = false;

    public riskObj: Generic;
    public headerInfo: ProposalHeader;
    public caseInfo: CaseInfo;

    public siFormat: string = "0,00";
    public premiumFormat: string = "0,00.00";
    public rateFormat: string = "0.00000";
    public percentFormat: string = "0.00";
    private isExcessPercentMandatory: string = 'N';
    private isExcessAmountMandatory: string = 'N';

    public position = 1;
    public sizeObj = { length: 0, orglength: 0 };
    public contentSizeObs: any;
    public itemPerPage = 3;
    public maxPageCount = 10;

    private referralReasons = [];

    @ViewChild('xtModal', { read: ViewContainerRef }) contentArea: ViewContainerRef;
    onPremiumChange = new EventEmitter<any>();
    onRiskClsChange = new EventEmitter<any>();
    onRtngFlgChange = new EventEmitter<any>();

    constructor(private lovDropDownService: LOVDropDownService, private _soapService: CordysSoapWService, public _alertMsgService: AlertMessagesService, el: ElementRef, public dcl: CustomDCLService, private _appUtilService: ApplicationUtilService, private _bmsUtilService: BMSUtilService, public riskClassificationService: RiskClassificationService, private _appObjService: BMSAppObjService, private _riService: RIService) {
        this.el = el.nativeElement;
    }

    ngOnInit() {
        this.populateLOVs();
        this.handleReferredProduct();
    }
    handleReferredProduct() {
        if (this.headerInfo.isReferredProduct == 'Y') {
            let _referralReason = new ReferralReason();
            _referralReason.seqNumber = this.riskObj.referralReasons.referralReason.length + 1;
            _referralReason.code = '';
            _referralReason.description = "Selected product is referred risk product";
            this.riskObj.riskClassification = 'Referred';
            this.riskObj.riskClassificationReason = "Selected product is referred risk product";
            if (this.riskObj.referralReasons.referralReason.length == 0)
                this.riskObj.referralReasons.referralReason.push(_referralReason);
        }
    }
    populateLOVs() {
        this.lovDropDownService.createLOVDataList(["Occupation", "referralReasons"]);
        let lovFields = [
            new LOV_Field("ALL", this.headerInfo.lineOfBusiness, "ALL", "ALL", "ALL", "ALL", "Referral Reasons", "LOV", [], "DESCPF", "referralReasons", "callbackForReferralReasons")
        ];
        // new LOV_Field("ALL", "ALL", "NEW BUSINESS", "ALL", "NEW", "ALL", "Occupation", "LOV", [] , "T3644", "Occupation", null),

        this.lovDropDownService.util_populateLOV(lovFields, this);
    }

    callbackForReferralReasons(scopeObject) {
        for (let _refReason of scopeObject.lovDropDownService.lovDataList.referralReasons) {
            let hasRefReason = scopeObject.riskObj.referralReasons.referralReason.some(_data => _data.code == _refReason.code);
            if (!hasRefReason) {
                scopeObject.referralReasons.push(_refReason);
            }
        }
    }

    populateRiskCoverageDetails(scopeObject) {
        let _grossPremium = 0;
        for (let _planItem of scopeObject.lovDropDownService.lovDataList.planDetails) {
            if (_planItem.VALUE == scopeObject.riskObj.plan) {
                let coverageItem = new RiskCoverage();
                coverageItem.seqNumber = scopeObject.riskObj.riskCoverageDetails.riskCoverage.length + 1;
                coverageItem.interestInsured = _planItem.COVER_DESC;
                coverageItem.sumInsured = _planItem.SUMIN;
                coverageItem.rate = _planItem.SRAT;
                coverageItem.load = _planItem.SLOA;
                coverageItem.premium = _planItem.GPDPREM;
                coverageItem.premiumClass = _planItem.SPRC;

                scopeObject.riskObj.riskCoverageDetails.riskCoverage.push(coverageItem);
                if (coverageItem.seqNumber == 1) {
                    scopeObject.riskObj.capitalSumInsured = _planItem.ZSORIG;
                }
                _grossPremium = _grossPremium + parseFloat("" + _planItem.GPDPREM);
            }
        }
        scopeObject.riskObj.grossPremium = numeral(numeral(_grossPremium).format(scopeObject.premiumFormat)).value();

        // scopeObject.riskObj.totalPremium = _grossPremium + parseFloat(""+scopeObject.riskObj.ncdAmount);
        scopeObject.setTotalPremium();
    }

    addReferralReason() {

        let refCode = jQuery("#referralReason").val();

        let refReasonRecord = this.lovDropDownService.lovDataList.referralReasons.find(_data => (_data.code === refCode));
        if (refReasonRecord) {
            if (this.riskObj.referralReasons.referralReason && (this.riskObj.referralReasons.referralReason.length == 0 || !this.riskObj.referralReasons.referralReason.find((_data1) => _data1.code == refCode))) {
                let _referralReason = new ReferralReason();
                _referralReason.seqNumber = this.riskObj.referralReasons.referralReason.length + 1;
                _referralReason.code = refReasonRecord.code;
                _referralReason.description = refReasonRecord.description;

                this.riskObj.referralReasons.referralReason.push(_referralReason);

                this.removeRefrlReasonFromSelectionList(refCode);
            }
            else if (this.riskObj.referralReasons.referralReason && this.riskObj.referralReasons.referralReason.find((_data1) => _data1.code == refCode)) {
                let _refReason = this.riskObj.referralReasons.referralReason.find((_data1) => _data1.code == refCode);

                this.removeRefrlReasonFromSelectionList(refCode);
            }
        }
    }

    removeRefrlReasonFromSelectionList(refCode) {
        let _selectedRefReason = this.referralReasons.find(item => item.code == refCode);
        if (_selectedRefReason) {
            this.referralReasons.splice(this.referralReasons.indexOf(_selectedRefReason), 1);
        }
        jQuery("#referralReason").val('');
    }

    removeReferralReason(refItem) {
        let _idx = this.riskObj.referralReasons.referralReason.indexOf(refItem);
        let _refCode = refItem.code;
        this.riskObj.referralReasons.referralReason.splice(_idx, 1);
        this.resetRefReasonsItemNumber();

        let _refReasonRecord = this.lovDropDownService.lovDataList.referralReasons.find(_data => (_data.code === _refCode));
        if (_refReasonRecord)
            this.referralReasons.push(_refReasonRecord);

    }

    resetRefReasonsItemNumber() {
        for (let _refItem of this.riskObj.referralReasons.referralReason) {
            let index = this.riskObj.referralReasons.referralReason.indexOf(_refItem);
            _refItem.seqNumber = (index + 1);
        }
    }

    addCustomField() {
        let customField = new CustomField();
        customField.seqNumber = this.riskObj.customFields.customField.length + 1;

        this.riskObj.customFields.customField.push(customField);
    }

    removeCustomField(customField) {
        let _idx = this.riskObj.customFields.customField.indexOf(customField);
        this.riskObj.customFields.customField.splice(_idx, 1);
        this.resetCustomFieldsItemNumber();
    }

    resetCustomFieldsItemNumber() {
        for (let _customField of this.riskObj.customFields.customField) {
            let index = this.riskObj.customFields.customField.indexOf(_customField);
            _customField.seqNumber = (index + 1);
        }
    }

    addCustomClause() {
        let customClause = new CustomClause();
        customClause.seqNumber = this.riskObj.customClauses.customClause.length + 1;

        this.riskObj.customClauses.customClause.push(customClause);
    }

    removeCustomClause(obj) {
        let _idx = this.riskObj.customClauses.customClause.indexOf(obj);
        this.riskObj.customClauses.customClause.splice(_idx, 1);
        this.resetCustomClauseItemNumber();
    }

    resetCustomClauseItemNumber() {
        for (let _clause of this.riskObj.customClauses.customClause) {
            let index = this.riskObj.customClauses.customClause.indexOf(_clause);
            _clause.seqNumber = (index + 1);
        }
    }

    setPremium(coverItem) {
        let si: any = coverItem.sumInsured;
        let rate: any = coverItem.rate;
        let iLoad: any = coverItem.load;

        si = (si == null || si == "") ? 0 : si;
        rate = (rate == null || rate == "") ? 0 : parseFloat(rate);
        // iLoad  = (iLoad == null || iLoad == "") ? 0 : parseFloat(iLoad);
        if (si != 0 && rate != 0) {
            let cpremium = (si * (rate)) / 100;
            coverItem.premium = numeral(numeral(cpremium).format(this.premiumFormat)).value();
            // coverItem.premium = ((coverItem.premium * iLoad)/100) + coverItem.premium; 			
        } else {
            coverItem.premium = 0.00;
        }

        this.setTotalPremium();
    }

    setTotalPremium() {
        this.riskObj.totalSI = this.getTotalByProperty("sumInsured", this.riskObj.riskCoverageDetails.riskCoverage, this.siFormat);
        this.riskObj.grossPremium = this.getTotalByProperty("premium", this.riskObj.riskCoverageDetails.riskCoverage, this.premiumFormat);

        this.riskObj.originalTotalPremium = numeral(numeral(this.riskObj.grossPremium).format(this.premiumFormat)).value();

        this.riskObj.rebateAmount = numeral(numeral((parseFloat("" + numeral(this.riskObj.grossPremium).value()) * parseFloat("" + this.riskObj.rebate)) / 100).format(this.premiumFormat)).value();

        let discountedPrem = numeral(numeral(parseFloat("" + numeral(this.riskObj.grossPremium).value()) - parseFloat("" + numeral(this.riskObj.rebateAmount).value())).format(this.premiumFormat)).value();
        this.riskObj.discountedPremium = discountedPrem;

        //SST Code
        //this.riskObj.gstAmount = (parseInt(""+this.riskObj.GST) > 0)?numeral(numeral((discountedPrem * parseInt(""+this.riskObj.GST))/100).format(this.premiumFormat)).value():0; //SAF MYS-2018-0629	 	
        let tempGSTAmount = (parseInt("" + this.riskObj.GST) > 0) ? numeral(numeral((discountedPrem * parseInt("" + this.riskObj.GST)) / 100).format(this.premiumFormat)).value() : 0;
        this.riskObj.gstAmount = (tempGSTAmount > 0) ? numeral(numeral(BMSUtilService.calculatePremiumAmount(tempGSTAmount, "G")).format(this.premiumFormat)).value() : 0;

        let tempSSTAmount = (parseInt("" + this.riskObj.SST) > 0) ? numeral(numeral((discountedPrem * parseInt("" + this.riskObj.SST)) / 100).format(this.premiumFormat)).value() : 0;
        this.riskObj.sstAmount = (tempSSTAmount > 0) ? numeral(numeral(BMSUtilService.calculatePremiumAmount(tempSSTAmount, "S")).format(this.premiumFormat)).value() : 0;

        let _totalPremium = parseFloat("" + numeral(discountedPrem).value()) + parseFloat("" + numeral(this.riskObj.gstAmount).value() + parseFloat("" + numeral(this.riskObj.sstAmount).value()));

        //End
        this.riskObj.totalPremium = numeral(numeral(_totalPremium).format(this.premiumFormat)).value();

        this.riskObj.capitalSumInsured = this.riskObj.totalSI;

        this.onPremiumChange.emit(this.riskObj.totalPremium);

    }

	/*validateSumInsured(){
		if(this.riskObj.RIRetentionCode && this.riskObj.isRIOverWrittenByUW=='N'){
			this._bmsUtilService.getTotalGrossCapacity(this.riskObj.RIRetentionCode).subscribe((data)=> this.compareSIWithTotGrossCap(data));
			
		}
		else
			this.setRIMethodEditableFlag();
	}
	
	compareSIWithTotGrossCap(totGrossCap){
		
		let _totalGrossCapacity = (!totGrossCap) ? 0 : parseFloat(""+totGrossCap);
		this.riskObj.totalGrossCapacity = _totalGrossCapacity;
		
		let _capitalSumInsured = parseFloat(""+this.riskObj.capitalSumInsured);
		
		if( _totalGrossCapacity > 0 && _capitalSumInsured > _totalGrossCapacity && (this.riskObj.RIMethod == null || this.riskObj.RIMethod == "" || parseFloat(""+this.riskObj.RIMethod) != 8) ){
			this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Capital Sum Insured is greater than Total Gross Capacity: "+_totalGrossCapacity+",  RI is Required." , 10000));
			
			this.riskObj.RIRequired = "Yes";
			this.riskObj.RIMethod = "8";
		} 
		else if(_capitalSumInsured <= _totalGrossCapacity){
			this.riskObj.RIRequired = "No";
			this.riskObj.RIMethod = this.riskObj.RIMethodSys;
		}
		this._riService.setRI().subscribe();
		this.setRIMethodEditableFlag();
	}
	*/

    getTotalByProperty(prop, ary, format: string) {
        let total = 0;
        for (let eachItem of ary) {
            if (eachItem[prop] != null && eachItem[prop] != "")
                total = total + parseFloat(numeral(eachItem[prop]).value());
        }
        if (format != null)
            return numeral(numeral(total).format(format)).value();
        else
            return total;
    }

    handleError(response, status, errorText, prms) {
        prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, response.responseJSON.faultstring.text, -1));
    }

    addRiskCoverage() {
        let riskCoverageItem = new RiskCoverage();
        riskCoverageItem.seqNumber = this.riskObj.riskCoverageDetails.riskCoverage.length + 1;

        this.riskObj.riskCoverageDetails.riskCoverage.push(riskCoverageItem);
    }

    removeRiskCover(coverItem) {
        let _idx = this.riskObj.riskCoverageDetails.riskCoverage.indexOf(coverItem);
        this.riskObj.riskCoverageDetails.riskCoverage.splice(_idx, 1);
        this.resetCoverageItemNumber();
        this.setTotalPremium();
    }

    resetCoverageItemNumber() {
        for (let _riskCoverage of this.riskObj.riskCoverageDetails.riskCoverage) {
            let index = this.riskObj.riskCoverageDetails.riskCoverage.indexOf(_riskCoverage);
            _riskCoverage.seqNumber = (index + 1);
        }
    }


    setReferredFromUI() {
        if (event.target != null) {
            let riskClass = jQuery(event.target).find("option:selected").text();
            this.riskObj.riskClassification = riskClass;
            this.setReferredByRiskClass(this, riskClass);
        }
    }

    setReferredByRiskClass(comp, riskClass) {
        if (riskClass != null && riskClass == "Referred") {
            comp.setReferred(comp, true);
        }
        else {
            comp.setReferredByRI(comp, comp.riskObj.RIRetentionCode);
        }
    }

    setReferred(comp, toRefer) {
        comp.onRiskClsChange.emit("");
    }

    setReferredByRI(comp, riCode) {
        // if(this.leastPreferredRI.indexOf(riCode) != -1){
        // comp.riskObj.riskClassification = "Referred";
        // comp.riskObj.symRiskClassification = "Referred";
        // comp.setReferred(comp,true);
        // }
        // else{
        comp.setReferred(comp, false);
        // }
    }

    setReferredByRIFromUI() {
        if (event.target != null) {
            let riCode = jQuery(event.target).find("option:selected").text();
            this.setReferredByRI(this, riCode);
        }
    }

    emitRiskClass(comp) {
        comp.onRiskClsChange.emit("");
    }

	/*resetFI(value){
		if(value == "Y")
			this.riskObj.financialInterest = new FinancialInterest();
		else
			this.riskObj.financialInterest = null;
	}*/

    setIdentity(isIdentityChange) {
		/*if(isIdentityChange == true && (this.riskObj.identityFiller == null || this.riskObj.identityFiller == "")){
			if(this.riskObj.situation1 != null){
				this.riskObj.identity = this.riskObj.situation1.slice(0, 15);
				this.riskObj.identityFiller = this.riskObj.situation1.slice(0, 15);
			}
		}
		else{
			if(isIdentityChange == false && this.riskObj.situation1 != null){
				this.riskObj.identity = this.riskObj.situation1.slice(0, 15);
				this.riskObj.identityFiller = this.riskObj.situation1.slice(0, 15);
			}
			else if(this.riskObj.identityFiller != null)
				this.riskObj.identity = this.riskObj.identityFiller.slice(0, 15);
		}*/
    }

    private onTextChange(ev) {
        if (ev.target.value == ' ') {
            ev.target.value = '';
        }
    }

    validateTextInput(ev) {
        let eVal = ev.target.value;
        ev.target.value = eVal.replace(/\s\s+/g, ' ');
    }

    setRIMethod(val) {

        this.riskObj.RIMethod = (val == "Yes") ? "8" : this.riskObj.RIMethodSys;

        this._riService.setRI().subscribe();
    }

    handleRiskClassification() {
        if (this.riskObj.symRiskClassification == "Declined")
            this.riskObj.riskClassification = "Declined";
        else if (this.riskObj.symRiskClassification == "Referred" || this.riskObj.riRiskClassification == "Referred")
            this.riskObj.riskClassification = "Referred";
        else
            this.riskObj.riskClassification = "Standard";
        this.setRiskClassification();
        this.emitRiskClass(this);
    }

    setRiskClassification() {
        if (this.riskObj.symRiskClassification != null && this.riskObj.symRiskClassification != "" && (this.riskObj.symRiskClassification == "Referred" || this.riskObj.symRiskClassification == "Declined")) {
            this.riskObj.riskClassificationReason = "System marked as " + this.riskObj.symRiskClassification;
        }
        else if (this.riskObj.riRiskClassification != null && this.riskObj.riRiskClassification != "" && this.riskObj.riRiskClassification == "Referred") {
            this.riskObj.riskClassificationReason = "System marked as " + this.riskObj.riRiskClassification;
        }
        else {
            if (this.riskObj.riskClassificationReason != null && this.riskObj.riskClassificationReason != "" && (this.riskObj.riskClassificationReason != "System marked as Standard" && this.riskObj.riskClassificationReason.indexOf("System marked as ") != -1)) {
                this.riskObj.riskClassificationReason = "";
            }
        }
    }

	/*onOccCodeChange(ev){
		this.riskObj.occupationCode = ev.value;
		this.riskObj.occupationDesc = ev.record.DESCRIPTION;
	}*/

    addXT(coverItem) {
        var dialogData = new ExtraTextDialogData("ExtraTextDialogComponent", "app/bms/components/proposal/newbusinessrisks/dialogs/extratext.dialog.module", "ExtraTextDialogModule", "Extra Text", "ExtraText", "fa fa-comment", coverItem, this.extraTextCallBack);
        this.openExtraTextCommentsDialog(dialogData);
    }

    public openExtraTextCommentsDialog(dialogData: ExtraTextDialogData, response?: any) {
        let lookup = new ModalInput();
        lookup.component = [dialogData.component, dialogData.moduleAbsPath, dialogData.moduleName];
        lookup.datainput = {
            dialogName: dialogData.dialogName,
            areCommentsMandatory: false,
            coverageItem: dialogData.coverageItem
        };
        lookup.outputCallback = dialogData.callBackHandler;
        lookup.parentCompPRMS = {
            comp: this,
            response: response
        };
        lookup.heading = dialogData.dialogTitle;
        lookup.icon = dialogData.icon;
        lookup.containerRef = this.contentArea;
        this.dcl.openLookup(lookup);
    }

    private extraTextCallBack(data, prms) {
        if (data.isDialogCancelled) {
            return;
        } else if (!data.isDialogCancelled && data.coverageItem && data.coverageItem.extraText) {
        }
    }

}
