import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BasicUIModule } from '../../../../../common/components/utility/basicui.module';
import { LovModule } from "../../../../../common/services/lovdropdown/lov.module";
import { ClausesModule } from '../uimodules/clauses.module';
import { GSTModule } from '../uimodules/gst.module';
import { PaginationModule } from '../../../../../common/components/utility/pagination/pagination.module';
// import { FIModule } from '../../../../../common/components/financialinterest/fi.module';
// import { RelatedCaseModule } from '../uimodules/relatedcase.module';
import { S4811Component } from './s4811.component';
import { GeneralPageModule } from '../uimodules/generalpage.module'; //VK004

@NgModule({
    imports: [CommonModule, FormsModule, ReactiveFormsModule, BasicUIModule, LovModule, ClausesModule, GSTModule, PaginationModule, GeneralPageModule],
    declarations: [S4811Component],
    exports: [S4811Component]
})
export class S4811Module { }