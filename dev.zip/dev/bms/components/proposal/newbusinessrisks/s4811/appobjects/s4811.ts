import { Clause } from '../../appobjects/clause';
import { GSTDetails } from '../../appobjects/gstDetails';
import { AppUtil } from '../../../../../../common/components/utility/apputil/app.util';
import { NBRisk } from '../../../appobjects/nbrisk';
import { PostedPrem } from '../../../proposalheader/appobjects/postedprem';
import { S4811Validator } from '../../../validation/s4811.validator';
import { RiskHelper } from '../../../appobjects/riskhelper';
import { ReferredReason } from '../../../proposalheader/appobjects/referredreason';

export class S4811 extends RiskHelper implements NBRisk {
    public sequenceNumber: string;
    public effectiveDate: string;
    public dateOfAttachment: string;
    public contractNumber: string;
    public contractType: string;
    public riskNumber: string;
    public riskType: string;
    public riskName: string;
    public ratingFlag: string = "A";
    public RIRetentionCode: string;
    public businessCode: string;
    public businessCodeDesc: string;
    public placeOfEmp1: string;
    public placeOfEmp2: string;
    public situationLine1: string;
    public situationLine2: string;
    public situationLine3: string;
    public situationLine4: string;
    public situationLine5: string;
    public situationLine6: string;
    public situationLine7: string;
    public situationLine8: string;
    public aow: number = 0;
    public aoa: number = 0;
    public law: string = "";
    public tLimit: string = '';
    public totalAnnualEarnings: number = 0;
    public totalBasePremium: number = 0;
    public totalPremium: number = 0;
    public capitalSumInsured: number = 0;
    public totalGrossCapacity: number = 0;
    public comLawInd: string = 'N';
    public comLawPrcnt: number;
    public comLawAmount: number;
    public wagerollDiscInd: string = 'N';
    public wagerollDiscPrcnt: number;
    public wagerollDiscAmount: number;
    public postedPremium: number = 0;
    public basePostedPremiumAdj: number = 0;
    public discountedPremium: number = 0;
    public minimumPremium: number = 0;
    public originalTotalPremium: number = 0;
    public rebate: number = 0;
    public rebateAmount: number = 0;
    public GST: number = 0;//6; //SAF MYS-2018-0629
    public gstAmount: number = 0;
    public FI: string = 'N';
    public addRelatedCases: string = "N";
    public hasClaimExperience: string = "N";
    public isSurveyNeeded: string = "N";
    public RIRequired: string = "No";
    public RIMethod: string = "1";
    public RIMethodSys: string = "0";
    public isRIOverWrittenByUW: string = "N";
    public terminationDate: string;
    public riskClassification: string = "Standard";
    public riskClassificationReason: string = '';
    public symRiskClassification: string = "";
    public riRiskClassification: string = "Standard";
    public isPOIConsidered: string = "N";
    public priority: string;
    public clauses: Clause;
    public riskCoverageDetails: RiskCoverageDetails;
    // public financialInterest: FinancialInterest;
    // public declarationDetails: DeclarationDetails;
    public GSTDetails: GSTDetails;
    public contractDetails: ContractDetails;
    // public relatedCases:FireRelatedCases;	
    // public identity: string="";
    // public identityFiller: string="";
    public postedPremDetails: PostedPrem;

    public childRiskPath: string;
    public childRiskIdentity: string;
    public riskClassificationReasons: ReferredReason;
    public gpTextCount:string;//VK004
    public occRiskClassification: string;
    public contractPeriodRC: string;
    public MaintenancePeriodRC: string;
    public gpText: string;

    public SST: number = 0; //SST Code
    public sstAmount: number = 0;//SST Code
    public GSTLiveDate: string;//SST Code
    public SSTLiveDate: string;//SST Code
    public isGSTApplicable: boolean = true;//SST Code
    constructor() {
        super();
        this.clauses = new Clause();
        this.riskCoverageDetails = new RiskCoverageDetails();
        this.GSTDetails = new GSTDetails();
        this.contractDetails = new ContractDetails();
        this.riskClassificationReasons = new ReferredReason();
        // this.financialInterest = new FinancialInterest();
        // this.declarationDetails = new DeclarationDetails();
        // this.relatedCases = new FireRelatedCases();
    }

    public getInstance(valObj: S4811) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
            this.riskCoverageDetails = new RiskCoverageDetails().getInstance(valObj.riskCoverageDetails);
            this.clauses = new Clause().getInstance(valObj.clauses);
            // if(valObj.FI == "Y"){
            // this.financialInterest = new FinancialInterest().getInstance(valObj.financialInterest);
            // }
            this.GSTDetails = new GSTDetails().getInstance(valObj.GSTDetails);
            this.contractDetails = new ContractDetails().getInstance(valObj.contractDetails);
            this.riskClassificationReasons = new ReferredReason().getInstance(valObj.riskClassificationReasons);
            // this.declarationDetails = new DeclarationDetails();			
            // if(valObj.addRelatedCases == "Y"){
            // this.relatedCases = new FireRelatedCases().getInstance(valObj.relatedCases);
            // }
            if (valObj.isGSTApplicable != undefined && JSON.stringify(valObj.isGSTApplicable) != JSON.stringify("") && typeof (valObj.isGSTApplicable) == "string") {
                this.isGSTApplicable = Boolean(JSON.parse(valObj.isGSTApplicable));
            }
        }
        return this;
    }

    public getNewInstanceByCriteria(criteria: any) {
        let riskType = criteria.riskType;
        if (riskType == "EL") {
            this.RIRetentionCode = "EL";
            this.comLawInd = "Y";
            this.wagerollDiscInd = "N";
            this.aoa = 3000000;
            this.law = "MAL";
        }
        else if (riskType == "WC") {
            this.RIRetentionCode = "WC";
            this.comLawInd = "Y";
            this.wagerollDiscInd = "N";
            this.aoa = 3000000;
            this.law = "MAL";
        }
        else if (riskType == "WPA") {
            this.RIRetentionCode = "PA03";
            this.wagerollDiscInd = "N";
            this.law = "";
            this.comLawInd = "N";
        }
        return this;
    }

    public getValidator() {
        return new S4811Validator(this);
    }
}

export class RiskCoverageDetails {

    public riskCoverage: RiskCoverage[] = [];

    public getInstance(valObj: RiskCoverageDetails) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
            new AppUtil().handleArray(this, valObj, "riskCoverage");
        }
        return this;
    }
}

export class RiskCoverage {
    public seqNumber: number;
    public tariff: string;
    public occupationDesc: string;
    public annualEarnings: number;
    public rate: string;
    public premium: string;
    public premiumClass: string;
    public extraText: string = "";
    public etPostingStatus = "N";
    // public xtComments:XTComments;

    constructor() {
        // this.xtComments = new XTComments();
    }

    public getInstance(valObj: RiskCoverage) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
            // //this.xtComments = new XTComments().getInstance(valObj.xtComments);
        }
        return this;
    }
}

export class ContractDetails {
    public contractTitle1: string;
    public contractTitle2: string;
    public contractTitle3: string;
    public contractTitle4: string;
    public contractTitle5: string;
    public contractSite1: string;
    public contractSite2: string;
    public contractSite3: string;
    public contractPeriodFrom: string;
    public contractPeriodTo: string;
    public maintenancePeriodFrom: string;
    public maintenancePeriodTo: string;
    public postingStatus: string = 'N';

    public getInstance(valObj: ContractDetails) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
        }

        return this;
    }
}