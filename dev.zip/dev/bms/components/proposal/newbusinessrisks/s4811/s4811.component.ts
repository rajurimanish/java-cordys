/*
 * Change History:
 * 
 * No      Date          Description                                         Changed By
 * ====    ==========    ===========                                         ==========	
 * YPK001 23/09/2019       MYS-2019-0675 Document Validation for Co-outwards            PKU1
 *                         case before sending to PPHO			   
*/
import { Component, OnInit, ViewChild, ElementRef, EventEmitter, AfterViewInit, ViewContainerRef } from '@angular/core';
declare var Observer: any;
import { DCLInput, CustomDCLService } from '../../../../../common/services/customdcl.service';
import { LOV_Field, LOVDropDownService, SearchFilter } from "../../../../../common/services/lovdropdown/lovdropdown.service";
import { CordysSoapWService } from "../../../../../common/components/utility/cordys-soap-ws";
import { GetLOVData, SearchAdvancedConfig, Filter } from '../../../../../common/components/utility/search/search.requests';
import { AlertMessagesService } from '../../../../../common/components/utility/alertmessage/alertmessages.service';
import { AlertMessage } from '../../../../../common/components/utility/alertmessage/alertmessages.model';
import { S4811 } from './appobjects/s4811';
import { Clause } from "../appobjects/clause";
import { RiskCoverage } from "./appobjects/s4811";
import { PaginationModule } from '../../../../../common/components/utility/pagination/pagination.module';
import { PaginationPipe } from '../../../../../common/components/utility/pagination/filtertable.pipe';
import { FilterTableContentPipe } from '../../../../../common/components/utility/pagination/filtercontent.pipe';
import { ExtraTextDialogData } from "../dialogs/extratext.dialog.data";
import { ModalInput } from "../../../../../common/components/utility/modal/modal";
import { SearchInput } from "../../../../../common/components/utility/search/genericsearch";
import { ApplicationUtilService } from "../../../../../common/services/application.util.service";
import { BMSUtilService } from "../../../../services/bms.util.service";
import { RIService } from '../services/ri.service';
import { RiskClassificationService } from "../services/riskcls.service";
import { ProposalHeader } from '../../proposalheader/appobjects/proposalheader';
import { BMSConstants } from '../../../common/constants/bms_constants';
import { ActivatedRoute } from '@angular/router';
import { ClausesComponent } from '../uimodules/clauses.component';

declare var jQuery: any;
declare var moment: any;
declare var numeral: any;

@Component({
    selector: 's4811-risk-component',
    templateUrl: 'app/bms/components/proposal/newbusinessrisks/s4811/s4811.template.html',
    inputs: ['riskObj', 'clientDetails', "headerInfo"],
    outputs: ["onPremiumChange", "onRiskClsChange", "onRtngFlgChange"],

    providers: [RiskClassificationService]
})

export class S4811Component implements OnInit {
    private el: HTMLElement;
    private isCoverInfoCollapsed: boolean = false;
    private clCBIInfoCollapse: boolean = true;
    private relatedCollapse: boolean = false;
    private isContractDetailsCollapse: boolean = false;
    public riskObj: S4811;
    public accRegCtrl: any;
    public contractPeriodFromCtrl: any;
    public contractPeriodToCtrl: any;
    public maintenancePeriodFromCtrl: any;
    public maintenancePeriodToCtrl: any;
    public siFormat: string = "0,00";
    public premiumFormat: string = "0,00.00";
    public rateFormat: string = "0.00000";
    public percentFormat: string = "0.00";

    public position = 1;
    public sizeObj = { length: 0, orglength: 0 };
    public contentSizeObs: any;
    public itemPerPage = 6;
    public maxPageCount = 10;
    private isUnderWriter = "N";
    private isRIMethodEditable = "Y";
    private isReferredContractPeriod = "N";
    private isReferredMaintncePeriod = "N";
    private isGeneralPageCollapsed: boolean = false;

    @ViewChild(ClausesComponent) private clausesComp: ClausesComponent;
    @ViewChild('xtModal', { read: ViewContainerRef }) contentArea: ViewContainerRef;



    onPremiumChange = new EventEmitter<any>();
    onRiskClsChange = new EventEmitter<any>();
    onRtngFlgChange = new EventEmitter<any>();

    public headerInfo: ProposalHeader;//SST Code

    constructor(private lovDropDownService: LOVDropDownService, private _soapService: CordysSoapWService, public _alertMsgService: AlertMessagesService, el: ElementRef, public dcl: CustomDCLService, private _appUtilService: ApplicationUtilService, private _bmsUtilService: BMSUtilService, private _riService: RIService, public riskClassificationService: RiskClassificationService, private _activatedRoute: ActivatedRoute) {
        this.el = el.nativeElement;
    }

    ngOnInit() {
        this.populateLOVs();
        this._appUtilService.isUnderWriterUser().subscribe((data) => {
            this.isUnderWriter = data;
            this.setRIMethodEditableFlag();
        });
        if (this.riskObj.riskType == "WC") {
            this.setContractPeriodDefaults(true);
            this.setMaintcePeriodDefaults(true);
        }
        //SST Code
        if (["MyTasks", "MyDrafts"].indexOf(this._activatedRoute.snapshot.params['component']) >= 0 || Object.keys(this._activatedRoute.snapshot.params).length == 0) {
            let respObj = this._bmsUtilService.getTAXDetails();
            if (respObj != undefined && respObj != "") {
                this.headerInfo.SSTTaxRate = Number(respObj[0].old.ITEMPF.GST);
                this.headerInfo.GSTTaxRate = Number(respObj[1].old.ITEMPF.GST);

                this.riskObj.SST = Number(this.headerInfo.SSTTaxRate);
                this.riskObj.GST = Number(this.headerInfo.GSTTaxRate);
            }

            this.headerInfo = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo;
            this.riskObj.SSTLiveDate = (this.riskObj.SSTLiveDate == undefined) ? this.headerInfo.SSTLiveDate : this.riskObj.SSTLiveDate;
            if (this.riskObj.SSTLiveDate == undefined || this.riskObj.SSTLiveDate == "") {
                let tempRespObj = this._bmsUtilService.getLiveDate();
                this.riskObj.GSTLiveDate = tempRespObj[0].old.ITEMPF.LIVEDATE;
                this.riskObj.SSTLiveDate = tempRespObj[1].old.ITEMPF.LIVEDATE;
                if (this.headerInfo.SSTLiveDate == undefined || this.headerInfo.SSTLiveDate == "") {
                    this.headerInfo.SSTLiveDate = this.riskObj.SSTLiveDate;
                }
                if (this.headerInfo.GSTLiveDate == undefined || this.headerInfo.GSTLiveDate == "") {
                    this.headerInfo.GSTLiveDate = this.riskObj.GSTLiveDate;
                }
            }
            if (moment(this.headerInfo.effectiveDate, "YYYY-MM-DD").format("YYYYMMDD") >= moment(this.riskObj.SSTLiveDate, "YYYY-MM-DD").format("YYYYMMDD")) {
                this.riskObj.isGSTApplicable = false;
            } else {
                this.riskObj.isGSTApplicable = true;
            }
        }
        //End
    }
    //START YPK001
    ngAfterViewInit() {
        let rIndex = 0;
        if ((this.headerInfo.CoInsurance == 'Y' && this.riskObj.riskNumber == '1') && (["MyTasks", "MyDrafts"].indexOf(this._activatedRoute.snapshot.params['component']) >= 0 || Object.keys(this._activatedRoute.snapshot.params).length == 0)) {
            if (this.headerInfo.coInsuranceDetails.coInsurance.length == 1) {
                if (!(this.headerInfo.coInsuranceDetails.coInsurance[0].coInsuranceindicator == 'L' && this.headerInfo.coInsuranceDetails.coInsurance[0].sharePercentage == '100')) {
                    rIndex = this.riskObj.clauses.clause.map(function (item) { return item.clauseCode; }).indexOf("COIN");
                    if (rIndex == -1)
                        this.setClauses(["COIN"], false);
                }
            }
            else {
                rIndex = this.riskObj.clauses.clause.map(function (item) { return item.clauseCode; }).indexOf("COIN");
                if (rIndex == -1)
                    this.setClauses(["COIN"], false);
            }
        }
    }
    setClauses(clausesList, flag) {
        if (this.clausesComp)
            this.clausesComp.addClause(clausesList, '', flag);
    }
    //END YPK001
    populateLOVs() {
        this.lovDropDownService.createLOVDataList(["postCode", "Occupation", "piamcode", "construction", "laws", "tLimit"]);

        let riTypeFilterDetails = [new SearchFilter("DESCITEM", this.riskObj.riskType, "STARTSWITH", "AND")];
        let riTypeSearchFilterNodes = this.lovDropDownService.createFilter(riTypeFilterDetails);

        let lovFields = [
            new LOV_Field("ALL", "FIRE", "NEW BUSINESS", "ALL", "NEW", "FIRE_IDC", "PostCode", "LOV", [], "DESCPF", "postCode", null),
            new LOV_Field("ALL", "ALL", "ALL", "ALL", "ALL", "ALL", "PIAM Code", "LOOKUP", [], "DESCPF", "piamcode", null),
            new LOV_Field("ALL", "FIRE", "CLAIMS", "ALL", "NEW", "CLAIMS_FIRE", "Construction Code", "LOV", [], "DESCPF", "construction", null),
            new LOV_Field("ALL", "ALL", "CLAIMS", "ALL", "ALL", "CLAIMS", "WC Tariff Code", "LOV", [], "DESCPF", "WCTariffCode", null),
            new LOV_Field("ALL", "ALL", "NEW BUSINESS", "ALL", "ALL", "ALL", "Laws", "LOV", [], "ITEMPF", "laws", null),
            new LOV_Field("ALL", "ALL", "NEW BUSINESS", "ALL", "ALL", "ALL", "Territorial Limit", "LOV", [], "T9116", "tLimit", null)
        ];
        // new LOV_Field("ALL", "MOTOR", "NEW BUSINESS", "ALL", "NEW", "PRIVATE_MOTOR", "RI Retention Code", "LOV", [], "DESCPF", "riCode",null),
        // new LOV_Field("ALL", "FIRE", "NEW BUSINESS", "ALL", "NEW", "FIRE_IDC", "PremiumClass", "LOV", riTypeSearchFilterNodes, "T4688", "premiumclass",null),
        // new LOV_Field("ALL", "MOTOR", "NEW BUSINESS", "ALL", "NEW", "NAMED_DRIVER", "Occupation", "LOV", [], "DESCPF", "Occupation",null),

        if (this.riskObj.riskType == 'EL' || this.riskObj.riskType == 'WC') {
            let occCodeFilter = (this.riskObj.riskType.length == 2) ? this.riskObj.riskType + ' ' : this.riskObj.riskType;
            let occCodeFilterDetails = [new SearchFilter("DESCITEM", occCodeFilter, "STARTSWITH", "AND")];
            let occCodeFilterNodes = this.lovDropDownService.createFilter(occCodeFilterDetails);

            lovFields.push(new LOV_Field("ALL", "MIS", "ALL", "ALL", "ALL", "ALL", "Occupation", "LOV", occCodeFilterNodes, "T9109", "Occupation", null));
        } else {
            lovFields.push(new LOV_Field("ALL", "MOTOR", "NEW BUSINESS", "ALL", "NEW", "NAMED_DRIVER", "Occupation", "LOV", [], "DESCPF", "Occupation", null));
        }

        this.lovDropDownService.util_populateLOV(lovFields, this);

    }

    addRiskCoverage() {
        let riskCoverageItem = new RiskCoverage();
        if (this.riskObj.riskType == 'EL') {
            riskCoverageItem.premiumClass = '44';
        }
        else if (this.riskObj.riskType == 'WC') {
            riskCoverageItem.premiumClass = '41';
        }
        else if (this.riskObj.riskType == 'WPA') {
            riskCoverageItem.premiumClass = '43';
        }
        riskCoverageItem.seqNumber = this.riskObj.riskCoverageDetails.riskCoverage.length + 1;
        this.riskObj.riskCoverageDetails.riskCoverage.push(riskCoverageItem);

    }

    removeRiskCover(coverItem) {
        let _idx = this.riskObj.riskCoverageDetails.riskCoverage.indexOf(coverItem);
        this.riskObj.riskCoverageDetails.riskCoverage.splice(_idx, 1);
        this.resetItemNumber();
        this.resetTotal();
    }

    resetItemNumber() {
        for (let _riskCoverage of this.riskObj.riskCoverageDetails.riskCoverage) {
            let index = this.riskObj.riskCoverageDetails.riskCoverage.indexOf(_riskCoverage);
            _riskCoverage.seqNumber = (index + 1);
        }
    }

    private onTextChange(ev) {
        if (ev.target.value == ' ') {
            ev.target.value = '';
        }
    }

    onOccChange(ev) {
        if (ev.record.DESCRIPTION) {
            this.riskObj.businessCodeDesc = ev.record.DESCRIPTION; //ev.record.DESCRIPTION.slice(0, 40);
        } else {
            this.riskObj.businessCodeDesc = '';
        }
    }

    onTariffChange(ev, cover) {
        cover.tariff = ev.value;
        cover.occupationDesc = (ev.record.LONGDESC) ? ev.record.LONGDESC.slice(0, 30) : "";
    }

    private onKeyPressHandler(ev, maxLen) {
        if (ev.keyCode == 13 || ev.target.value.length == maxLen) {
            this.setFocusToNext(ev.target);
        } else if (ev.keyCode == 32) {
            ev.target.value = ev.target.value.trim();
        }
    }

    setFocusToNext(elmnt) {
        let sutuationElmnts = jQuery(this.el).find("input");
        jQuery(sutuationElmnts[sutuationElmnts.index(elmnt) + 1]).focus();
    }

    setCoverPremium(coverItem) {
        let ae: any = coverItem.annualEarnings;
        let rate: any = coverItem.rate;
        ae = (ae == null || ae == "") ? 0 : ae;
        rate = (rate == null || rate == "") ? 0 : parseFloat(rate);
        let premium = ae * (rate / 100);
        coverItem.premium = numeral(numeral(premium).format(this.premiumFormat)).value();
    }

    resetTotal() {
        for (let coverItem of this.riskObj.riskCoverageDetails.riskCoverage) {
            this.setCoverPremium(coverItem);
        }
        this.riskObj.totalAnnualEarnings = this.getTotalByProperty("annualEarnings", this.riskObj.riskCoverageDetails.riskCoverage, null);
        this.riskObj.totalBasePremium = this.getTotalByProperty("premium", this.riskObj.riskCoverageDetails.riskCoverage, this.premiumFormat);

        let totalAmount = this.riskObj.totalBasePremium;
        if (this.riskObj.comLawInd == 'Y' && this.riskObj.comLawPrcnt > 0) {
            let _comLawAmount = this.riskObj.totalBasePremium * (this.riskObj.comLawPrcnt / 100);
            this.riskObj.comLawAmount = numeral(numeral(_comLawAmount).format(this.premiumFormat)).value();
            totalAmount = totalAmount + this.riskObj.comLawAmount;
        } else {
            this.riskObj.comLawPrcnt = 0;
            this.riskObj.comLawAmount = 0;
        }
        if (this.riskObj.wagerollDiscInd == 'Y' && this.riskObj.wagerollDiscPrcnt > 0) {
            let _wagerollDiscAmount = totalAmount * (this.riskObj.wagerollDiscPrcnt / 100);
            this.riskObj.wagerollDiscAmount = numeral(numeral(_wagerollDiscAmount).format(this.premiumFormat)).value();
            totalAmount = totalAmount - this.riskObj.wagerollDiscAmount;
        }
        this.riskObj.originalTotalPremium = numeral(numeral(totalAmount).format(this.premiumFormat)).value();

        this.riskObj.rebateAmount = numeral(numeral((parseFloat("" + numeral(totalAmount).value()) * parseFloat("" + this.riskObj.rebate)) / 100).format(this.premiumFormat)).value();
        let discountedPrem = numeral(numeral(parseFloat("" + numeral(totalAmount).value()) - parseFloat("" + numeral(this.riskObj.rebateAmount).value())).format(this.premiumFormat)).value();
        this.riskObj.discountedPremium = discountedPrem;
        //this.riskObj.gstAmount = (parseInt(""+this.riskObj.GST) > 0 && discountedPrem > 0)?numeral(numeral((discountedPrem*parseInt(""+this.riskObj.GST))/100).format(this.premiumFormat)).value():0; //SAF MYS-2018-0629;

        //SST Code
        let tempGSTAmount = (parseInt("" + this.riskObj.GST) > 0 && discountedPrem > 0) ? numeral(numeral((discountedPrem * parseInt("" + this.riskObj.GST)) / 100).format(this.premiumFormat)).value() : 0;
        this.riskObj.gstAmount = (tempGSTAmount > 0) ? numeral(numeral(BMSUtilService.calculatePremiumAmount(tempGSTAmount, "G")).format(this.premiumFormat)).value() : 0;

        if ((this.headerInfo.contractType == 'WC' || this.headerInfo.contractType == 'EL') && this.riskObj.contractDetails.contractPeriodFrom != undefined && this.riskObj.contractDetails.contractPeriodFrom != "" && this.riskObj.contractDetails.contractPeriodTo != undefined && this.riskObj.contractDetails.contractPeriodTo != "") {
            let respObj = this._bmsUtilService.getTAXDetailsInfo(moment(this.riskObj.contractDetails.contractPeriodFrom, "YYYY-MM-DD").format("YYYYMMDD"), moment(this.riskObj.contractDetails.contractPeriodTo, "YYYY-MM-DD").format("YYYYMMDD"));

            if (respObj != undefined && respObj != "") {
                this.headerInfo.SSTTaxRate = Number(respObj[0].old.ITEMPF.GST);
                this.headerInfo.GSTTaxRate = Number(respObj[1].old.ITEMPF.GST);

                this.riskObj.SST = Number(this.headerInfo.SSTTaxRate);
                this.riskObj.GST = Number(this.headerInfo.GSTTaxRate);
            }
            let tempSSTAmount = (Number(this.riskObj.SST) > 0) ? numeral(numeral((this.riskObj.originalTotalPremium * Number(this.riskObj.SST)) / 100).format(this.premiumFormat)).value() : 0;
            this.riskObj.sstAmount = (tempSSTAmount > 0) ? numeral(numeral(BMSUtilService.calculatePremiumAmt(tempSSTAmount, "S", moment(this.riskObj.contractDetails.contractPeriodFrom, "YYYY-MM-DD").format("YYYYMMDD"), moment(this.riskObj.contractDetails.contractPeriodTo, "YYYY-MM-DD").format("YYYYMMDD"))).format(this.premiumFormat)).value() : 0;
        }
        else {
			/* let tempGSTAmount = (parseInt(""+this.riskObj.GST) > 0 && discountedPrem > 0)?numeral(numeral((discountedPrem*parseInt(""+this.riskObj.GST))/100).format(this.premiumFormat)).value():0;
			this.riskObj.gstAmount = (tempGSTAmount > 0)?numeral(numeral(BMSUtilService.calculatePremiumAmount(tempGSTAmount,"G")).format(this.premiumFormat)).value():0; */

            let tempSSTAmount = (parseInt("" + this.riskObj.SST) > 0 && discountedPrem > 0) ? numeral(numeral((discountedPrem * parseInt("" + this.riskObj.SST)) / 100).format(this.premiumFormat)).value() : 0;
            this.riskObj.sstAmount = (tempSSTAmount > 0) ? numeral(numeral(BMSUtilService.calculatePremiumAmount(tempSSTAmount, "S")).format(this.premiumFormat)).value() : 0;
        }
        //let _totalPremium = parseFloat(""+numeral(discountedPrem).value()) + parseFloat(""+numeral(this.riskObj.gstAmount).value());
        let _totalPremium = parseFloat("" + numeral(discountedPrem).value()) + parseFloat("" + numeral(this.riskObj.sstAmount).value());
        //End
        this.riskObj.totalPremium = numeral(numeral(_totalPremium).format(this.premiumFormat)).value();

        if (this.riskObj.riskType == 'EL' || this.riskObj.riskType == 'WC') {
            this.riskObj.capitalSumInsured = this.riskObj.aow;
        } else if (this.riskObj.riskType == 'WPA') {
            this.riskObj.capitalSumInsured = this.riskObj.totalAnnualEarnings;
        }

        this.onPremiumChange.emit(this.riskObj.totalPremium);
        this.validateSumInsured();
    }

    validateSumInsured() {
        if (this.riskObj.RIRetentionCode && this.riskObj.isRIOverWrittenByUW == 'N') {

            this._bmsUtilService.getTotalGrossCapacity(this.riskObj.RIRetentionCode).subscribe((data) => this.compareSIWithTotGrossCap(data));

			/*let _totalGrossCapacity = this._bmsUtilService.getNetRetentionAmountDetails(this.riskObj.RIRetentionCode);
			_totalGrossCapacity = (!_totalGrossCapacity) ? 0 : parseFloat(""+_totalGrossCapacity);
			this.riskObj.totalGrossCapacity = _totalGrossCapacity;
			let _capitalSumInsured = parseFloat(""+this.riskObj.capitalSumInsured);
			
			if( _totalGrossCapacity > 0 && _capitalSumInsured > _totalGrossCapacity && (this.riskObj.RIMethod == null || this.riskObj.RIMethod == "" || parseFloat(""+this.riskObj.RIMethod) != 8) ){
				if(this.riskObj.riskType == 'WPA')
					this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Total Annual Earnings greater than Total Gross Capacity: "+_totalGrossCapacity+",  RI is Required." , 10000));
				else
					this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Common Law Liability greater than Total Gross Capacity: "+_totalGrossCapacity+",  RI is Required." , 10000));
				
				this.riskObj.RIRequired = "Yes";
				this.riskObj.RIMethod = "8";
			} 
			else if(_capitalSumInsured <= _totalGrossCapacity){
				this.riskObj.RIRequired = "No";
				this.riskObj.RIMethod = this.riskObj.RIMethodSys;
			}*/
        }
        else
            this.setRIMethodEditableFlag();
    }

    compareSIWithTotGrossCap(totGrossCap) {

        let _totalGrossCapacity = (!totGrossCap) ? 0 : parseFloat("" + totGrossCap);
        this.riskObj.totalGrossCapacity = _totalGrossCapacity;
        let _capitalSumInsured = parseFloat("" + this.riskObj.capitalSumInsured);

        if (_totalGrossCapacity > 0 && _capitalSumInsured > _totalGrossCapacity && (this.riskObj.RIMethod == null || this.riskObj.RIMethod == "" || parseFloat("" + this.riskObj.RIMethod) != 8)) {
            if (this.riskObj.riskType == 'WPA')
                this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Total Annual Earnings greater than Total Gross Capacity: " + _totalGrossCapacity + ",  RI is Required.", 10000));
            else
                this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Common Law Liability greater than Total Gross Capacity: " + _totalGrossCapacity + ",  RI is Required.", 10000));

            this.riskObj.RIRequired = "Yes";
            this.riskObj.RIMethod = "8";
        }
        else if (_capitalSumInsured <= _totalGrossCapacity) {
            this.riskObj.RIRequired = "No";
            this.riskObj.RIMethod = this.riskObj.RIMethodSys;
        }
        this._riService.setRI().subscribe();
        this.setRIMethodEditableFlag();
    }

    getTotalByProperty(prop, ary, format: string) {
        let total = 0;
        for (let eachItem of ary) {
            if (eachItem[prop] != null && eachItem[prop] != "")
                total = total + parseFloat(numeral(eachItem[prop]).value());
        }
        if (format != null)
            return numeral(numeral(total).format(format)).value();
        else
            return total;
    }

	/*resetFI(value){
		if(value == "Y")
			this.riskObj.financialInterest = new FinancialInterest();
		else
			this.riskObj.financialInterest = null;
	}
	
	resetRelatedCase(value){
		if("Y" == value){
			this.riskObj.relatedCases = new FireRelatedCases();
		}
		else{
			this.riskObj.relatedCases = null;			
		}
	}*/

    setReferredFromUI(riskClass) {
        this.riskObj.riskClassification = riskClass;
        this.emitRiskClass(this);
    }

    emitRiskClass(comp) {
        comp.onRiskClsChange.emit("");
    }

    handleRiskClassification(comp) {
        this.riskClassificationService.setRiskClassification(comp.riskObj.riskNumber, "N", "", "").subscribe();
		/*if(this.riskObj.symRiskClassification == "Declined")
			this.riskObj.riskClassification = "Declined";
		else if(this.riskObj.symRiskClassification == "Referred" || this.riskObj.riRiskClassification == "Referred")
			this.riskObj.riskClassification = "Referred";
		else if(this.isReferredContractPeriod == 'N' && this.isReferredMaintncePeriod == 'N')
			this.riskObj.riskClassification = "Standard";
		this.setRiskClassification();
		this.emitRiskClass(this);*/
    }

    setRiskClassification() {
        if (this.riskObj.symRiskClassification != null && this.riskObj.symRiskClassification != "" && (this.riskObj.symRiskClassification == "Referred" || this.riskObj.symRiskClassification == "Declined")) {
            this.riskObj.riskClassificationReason = "System marked as " + this.riskObj.symRiskClassification;
        }
        else if (this.riskObj.riRiskClassification != null && this.riskObj.riRiskClassification != "" && this.riskObj.riRiskClassification == "Referred") {
            this.riskObj.riskClassificationReason = "System marked as " + this.riskObj.riRiskClassification;
        }
        else if (this.isReferredContractPeriod == 'N' && this.isReferredMaintncePeriod == 'N') {
            if (this.riskObj.riskClassificationReason != null && this.riskObj.riskClassificationReason != "" && (this.riskObj.riskClassificationReason != "System marked as Standard" && this.riskObj.riskClassificationReason.indexOf("System marked as ") != -1)) {
                this.riskObj.riskClassificationReason = "";
            }
        }
    }

    onBusinessCodeChange(ev) {
        this.riskObj.businessCode = ev.value;
        this.riskObj.businessCodeDesc = ev.record.DESCRIPTION; //ev.record.DESCRIPTION.slice(0, 40);
        this.riskObj.occRiskClassification = ev.record.REFERREDRISK;
		/*if(this.riskObj.riskType == 'EL' || this.riskObj.riskType == 'WC' ){
			if(!ev.record.REFERREDRISK || ev.record.REFERREDRISK == 'N'){
				this.riskObj.symRiskClassification = "Standard";
			}
			else if(ev.record.REFERREDRISK && ev.record.REFERREDRISK == 'Y'){
				this.riskObj.symRiskClassification = "Referred";
			}
			else if(ev.record.REFERREDRISK && ev.record.REFERREDRISK == 'D'){
				this.riskObj.symRiskClassification = "Declined";
			}*/

        this.handleRiskClassification(this);
        //}
    }

    setRIMethod(val) {

        this.riskObj.RIMethod = (val == "Yes") ? "8" : this.riskObj.RIMethodSys;

        if (this.isUnderWriter == "Y" || val == "Yes")
            this.riskObj.isRIOverWrittenByUW = "Y";
        else if (val == "No") {
            this.riskObj.isRIOverWrittenByUW = "N";
            this.validateSumInsured();
        }
        this._riService.setRI().subscribe();
    }

    validateContractDate(dateCtrlName) {

        if ((this.riskObj.contractDetails.contractPeriodFrom != null || this.riskObj.contractDetails.contractPeriodFrom != "") && (this.riskObj.contractDetails.contractPeriodTo != null || this.riskObj.contractDetails.contractPeriodTo != "")) {
            let _contractPeriodFrom = moment(this.riskObj.contractDetails.contractPeriodFrom, "YYYY-MM-DD");
            let _contractPeriodTo = moment(this.riskObj.contractDetails.contractPeriodTo, "YYYY-MM-DD");

            if (_contractPeriodFrom > _contractPeriodTo) {
                if (dateCtrlName == 'contractPeriodFrom') {
                    if (this.contractPeriodFromCtrl != null)
                        this.contractPeriodFromCtrl.setter('EMPTY', "YYYY-MM-DD", this.contractPeriodFromCtrl.comp);
                    this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Contract Period: From can not be greater than Contract Period:To", 2000));
                } else if (dateCtrlName == 'contractPeriodTo') {
                    if (this.contractPeriodToCtrl != null)
                        this.contractPeriodToCtrl.setter('EMPTY', "YYYY-MM-DD", this.contractPeriodToCtrl.comp);
                    this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Contract Period: TO can not be less than Contract Period:From", 2000));
                }
            }
        }
        if (this.riskObj.riskType == "WC")
            this.setContractPeriodDefaults(false);
    }

    validateMaintenaceDate(dateCtrlName) {
        if (this.riskObj.contractDetails.maintenancePeriodFrom && this.riskObj.contractDetails.maintenancePeriodTo) {
            let _maintenancePeriodFrom = moment(this.riskObj.contractDetails.maintenancePeriodFrom, "YYYY-MM-DD");
            let _maintenancePeriodTo = moment(this.riskObj.contractDetails.maintenancePeriodTo, "YYYY-MM-DD");

            if (_maintenancePeriodFrom > _maintenancePeriodTo) {
                if (dateCtrlName == 'maintenancePeriodFrom') {
                    if (this.maintenancePeriodFromCtrl != null)
                        this.maintenancePeriodFromCtrl.setter('EMPTY', "YYYY-MM-DD", this.maintenancePeriodFromCtrl.comp);
                    this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Maintenance Period: From can not be greater than Maintenance Period:To", 2000));
                } else if (dateCtrlName == 'maintenancePeriodTo') {
                    if (this.maintenancePeriodToCtrl != null)
                        this.maintenancePeriodToCtrl.setter('EMPTY', "YYYY-MM-DD", this.maintenancePeriodToCtrl.comp);
                    this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Maintenance Period: TO can not be less than Maintenance Period:From", 2000));
                }
            }
        }

        if (this.riskObj.riskType == "WC")
            this.setMaintcePeriodDefaults(false);
    }

    validateTextInput(ev) {
        let eVal = ev.target.value;
        ev.target.value = eVal.replace(/\s\s+/g, ' ');
    }

    onTLimitChange(ev) {
        this.riskObj.tLimit = ev.value;
		/*for(let _tLimitItem of this.lovDropDownService.lovDataList.tLimit){
			if(_tLimitItem.LONGDESC == ev.value){
				if(_tLimitItem.REFERRED &&  _tLimitItem.REFERRED == 'Y'){
					this.riskObj.riskClassification = "Referred";
					this.riskObj.symRiskClassification = "Referred"; 				
					this.riskObj.riskClassificationReason = "System marked as Referred";
				}
				else {
					this.riskObj.riskClassification = "Standard";
					this.riskObj.symRiskClassification = "Standard";
					this.riskObj.riskClassificationReason ="";
				}
				this.emitRiskClass(this);
				break;
			}
		}*/
    }

    onAOWChange(ev) {
        if (this.riskObj.riskType == 'EL' || this.riskObj.riskType == 'WC') {
            this.riskObj.aoa = this.riskObj.aow;
        }
        this.riskObj.capitalSumInsured = this.riskObj.aow;
        this.resetTotal();
    }

    addXT(coverItem) {
        var dialogData = new ExtraTextDialogData("ExtraTextDialogComponent", "app/bms/components/proposal/newbusinessrisks/dialogs/extratext.dialog.module", "ExtraTextDialogModule", "Extra Text", "ExtraText", "fa fa-comment", coverItem, this.extraTextCallBack);
        this.openExtraTextCommentsDialog(dialogData);
    }

    public openExtraTextCommentsDialog(dialogData: ExtraTextDialogData, response?: any) {
        let lookup = new ModalInput();
        lookup.component = [dialogData.component, dialogData.moduleAbsPath, dialogData.moduleName];
        lookup.datainput = {
            dialogName: dialogData.dialogName,
            areCommentsMandatory: false,
            coverageItem: dialogData.coverageItem
        };
        lookup.outputCallback = dialogData.callBackHandler;
        lookup.parentCompPRMS = {
            comp: this,
            response: response
        };
        lookup.heading = dialogData.dialogTitle;
        lookup.icon = dialogData.icon;
        lookup.containerRef = this.contentArea;
        this.dcl.openLookup(lookup);
    }

    private extraTextCallBack(data, prms) {
        if (data.isDialogCancelled) {
            return;
        } else if (!data.isDialogCancelled && data.coverageItem && data.coverageItem.extraText) {
        }
    }

    setRIMethodEditableFlag() {
        let _capitalSumInsured = parseFloat("" + this.riskObj.capitalSumInsured);
        let _totalGrossCapacity = parseFloat("" + this.riskObj.totalGrossCapacity);
        if (_totalGrossCapacity > 0 && _capitalSumInsured > _totalGrossCapacity && this.isUnderWriter == "N") {
            this.isRIMethodEditable = "N";
        }
        else {
            this.isRIMethodEditable = "Y";
        }
    }

    setContractPeriodDefaults(isOnLoad) {
        if (!isOnLoad)
            this.handleRiskClassification(this);
        /*	let shouldRefer = false;
            if( this.riskObj.contractDetails.contractPeriodFrom && this.riskObj.contractDetails.contractPeriodTo ){
                let _contractPeriodFrom = moment(this.riskObj.contractDetails.contractPeriodFrom,"YYYY-MM-DD");
                let _contractPeriodTo = moment(this.riskObj.contractDetails.contractPeriodTo,"YYYY-MM-DD");					
            	
                let difference  = moment(_contractPeriodTo).diff(_contractPeriodFrom);
                let _m = moment.duration(difference).asMonths();
                let _d = moment.duration(difference).asDays();
                let _y = moment.duration(difference).asYears();
            	
                if( _m >=60 || (_m > 59 && _d >= 1825) ){
                    shouldRefer = true;
                }
            	
                // let _months = _contractPeriodTo.diff(_contractPeriodFrom, 'months');
                // if(_months >= 60){
                    // shouldRefer = true;
                // }
            }
            if(shouldRefer){
                if(!isOnLoad && this.riskObj.riskClassification != "Referred" && this.riskObj.riskClassification !="Declined" && this.riskObj.symRiskClassification != "Referred" && this.riskObj.symRiskClassification != "Declined" && this.isReferredMaintncePeriod=='N'){
                    this.setReferredFromUI("Referred");
                    this.riskObj.riskClassificationReason = "System marked as Referred";
                }
            	
                this.isReferredContractPeriod = 'Y';
            	
            } else if(this.isReferredContractPeriod == 'Y'){
            	
                this.isReferredContractPeriod = 'N';
                if(!isOnLoad && this.riskObj.riskClassification !="Declined" && this.riskObj.symRiskClassification != "Referred" && this.riskObj.symRiskClassification != "Declined" && this.isReferredMaintncePeriod=='N'){
                    this.riskObj.riskClassificationReason = "";
                    this.setReferredFromUI("Standard");
                }
            }*/
    }

    setMaintcePeriodDefaults(isOnLoad) {
        if (!isOnLoad)
            this.handleRiskClassification(this);
		/*let shouldRefer = false;
		if(this.riskObj.contractDetails.maintenancePeriodFrom && this.riskObj.contractDetails.maintenancePeriodTo){
			let _maintenancePeriodFrom = moment(this.riskObj.contractDetails.maintenancePeriodFrom, "YYYY-MM-DD");
			let _maintenancePeriodTo = moment(this.riskObj.contractDetails.maintenancePeriodTo, "YYYY-MM-DD");
			
			let difference  = moment(_maintenancePeriodTo).diff(_maintenancePeriodFrom);
			let _m = moment.duration(difference).asMonths();
			let _d = moment.duration(difference).asDays();
			let _y = moment.duration(difference).asYears();
			
			if( _m >=24 || (_m > 23 && _d >= 729) ){
				shouldRefer = true;
			}*/

        // let _months = _maintenancePeriodTo.diff(_maintenancePeriodFrom, 'months');
        // let _limitEndDate = moment(_maintenancePeriodFrom, "YYYY-MM-DD").add(729, 'days').format("YYYY-MM-DD");			
        // if( _months >= 24 || (this.riskObj.contractDetails.maintenancePeriodTo == _limitEndDate) ){
        // shouldRefer = true;
        // }
        //}
		/*if(shouldRefer){
			if(!isOnLoad && this.riskObj.riskClassification != "Referred" && this.riskObj.riskClassification !="Declined" && this.riskObj.symRiskClassification != "Referred" && this.riskObj.symRiskClassification != "Declined" && this.isReferredContractPeriod=='N'){
				this.setReferredFromUI("Referred");
				this.riskObj.riskClassificationReason = "System marked as Referred";
			}
			
			this.isReferredMaintncePeriod = 'Y';
			
		} else if(this.isReferredMaintncePeriod == 'Y'){
			
			this.isReferredMaintncePeriod = 'N';
			if(!isOnLoad && this.riskObj.riskClassification !="Declined" && this.riskObj.symRiskClassification != "Referred" && this.riskObj.symRiskClassification != "Declined" && this.isReferredContractPeriod=='N'){
				this.riskObj.riskClassificationReason = "";
				this.setReferredFromUI("Standard");
			}
		}*/
    }

    emitFlagChange() {
        this.onRtngFlgChange.emit("");
    }
}
