import { Injectable } from '@angular/core';
import { CordysSoapWService } from "../../../../../common/components/utility/cordys-soap-ws";
import { BMSConstants } from '../../../common/constants/bms_constants';
import { AlertMessagesService } from '../../../../../common/components/utility/alertmessage/alertmessages.service';
import { AlertMessage } from '../../../../../common/components/utility/alertmessage/alertmessages.model';
declare var Rx: any;
declare var Observer: any;
import { ActivatedRoute, Router } from '@angular/router';
import { BMSType } from '../../../common/constants/bms_types';
import { AppUtil } from '../../../../../common/components/utility/apputil/app.util';
import { ApplicationUtilService } from '../../../../../common/services/application.util.service';

@Injectable()
export class RIService {
    constructor(private _aus: ApplicationUtilService) { }

    public setRI() {
        return Rx.Observable.create((observer) => {
            this.refreshRI(observer);
        });
    }

    refreshRI(observer) {
        let caseInfo = BMSConstants.getBMSCaseInfo();
        let header = BMSConstants.getBMSHeaderInfo();
        this._aus.isUnderWriterUser().subscribe((isUW) => {
            if (isUW == "Y" || ((caseInfo.status == 'Draft' || caseInfo.status == 'Assessment' || caseInfo.status == 'Assessment Approval' || caseInfo.status == 'Referral Approval') && (BMSConstants.getBMSType() == BMSType.NewBusiness || BMSConstants.getBMSType() == BMSType.CoverNote || BMSConstants.getBMSType() == BMSType.Renewal))) {
                let allRisks = BMSConstants.getRisks().getRisksByPriority();
                header.RIRequiredHeader = "No";
                for (let risk of allRisks) {
                    if (risk.RIRequired == "Yes") {
                        header.RIRequiredHeader = "Yes";
                    }
                }

                if (header.RIRequiredHeader == "No") {
                    header.RIType = "";
                    header.RIReason = "";
                }
            }
            header.setRIMethod();
            header.handleFlags();
            observer.next("");
        });
    }
}