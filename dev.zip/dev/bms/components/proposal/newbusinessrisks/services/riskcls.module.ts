import { NgModule } from '@angular/core';
import { RiskClassificationService } from './riskcls.service';

@NgModule({
    providers: [RiskClassificationService]
})

export class RiskClassificationServiceModule { }