import { NgModule } from '@angular/core';
import { RIService } from './ri.service';

@NgModule({
    providers: [RIService]
})

export class RIServiceModule { }