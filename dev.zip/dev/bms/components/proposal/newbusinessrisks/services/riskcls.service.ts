import { Injectable } from '@angular/core';
import { CordysSoapWService } from "../../../../../common/components/utility/cordys-soap-ws";
import { BMSConstants } from '../../../common/constants/bms_constants';
import { AlertMessagesService } from '../../../../../common/components/utility/alertmessage/alertmessages.service';
import { AlertMessage } from '../../../../../common/components/utility/alertmessage/alertmessages.model';
declare var Rx: any;
declare var Observer: any;
import { ActivatedRoute, Router } from '@angular/router';
import { BMSType } from '../../../common/constants/bms_types';
import { AppUtil } from '../../../../../common/components/utility/apputil/app.util';
import { ProgressBarComponent } from '../../../../../common/components/utility/progressbar/progressbar.component';
import { NewBusiness } from '../../appobjects/proposal';
import { BMSObject } from '../../../common/appobjects/bmsobject';

declare var numeral: any;

@Injectable()
export class RiskClassificationService {
    public RCL_PRODUCTS;
    constructor(private _cordysService: CordysSoapWService, public _alertMsgService: AlertMessagesService) { }

    public setRiskClassification(riskNumber, forHeader, subRiskId, refresh) {
        return Rx.Observable.create((observer) => {
            if (refresh != "Y") {
                this.isRCLReasonSupported().subscribe((isSupported) => {
                    if (forHeader == "Y" || isSupported == "Y") {
                        ProgressBarComponent.show('Checking risk classification...', { dialogSize: 'm', progressType: 'primary' });
                        let request = { RiskClassificationRequest: new Object() };
                        let rclRq: any = request.RiskClassificationRequest;
                        rclRq.riskNumber = riskNumber;
                        rclRq.ApplicationBusinessObject = BMSConstants.getBMSObj();
                        rclRq.forHeader = forHeader;
                        rclRq.subRiskId = subRiskId;
                        let promise = this._cordysService.callCordysSoapService("getRiskClassification", "http://schemas.insurance.com/businessobject/1.0/", request, null, null, true, null);
                        promise.success((data) => {
                            this.refreshRiskClassification(data, observer);
                        });
                        promise.error((error) => this.handleError(error, observer));
                    }
                    else {
                        BMSConstants.getBMSHeaderInfo().setReferred();
                        observer.next("NS");
                    }
                });
            }
            else {
                BMSConstants.getBMSHeaderInfo().setReferred();
                observer.next("");
            }
        });
    }

    handleError(data, observer) {
        ProgressBarComponent.hide();
        this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, data.responseJSON.faultstring.text, -1));
        observer.error("");
    }

    refreshRiskClassification( data, observer ) {
        let nbs: BMSObject = new BMSObject();        
        let nb = data.RiskClassificationResponse.success.ApplicationBusinessObject.businessObject.bms.newBusiness;
        //let nb = nbs.refreshInstance( data.RiskClassificationResponse.success.ApplicationBusinessObject.businessObject.bms );
        let newBusiness = BMSConstants.getNewBusinessInfo();
        newBusiness.refreshClassification( nb );
        BMSConstants.getBMSHeaderInfo().isReferredProduct = nb.headerInfo.isReferredProduct;
        if (BMSConstants.TEMPOBJ.ISSIMPLIFIEDPROCESS == 'Y') {
            BMSConstants.getBMSHeaderInfo().setReferred();
        }
        ProgressBarComponent.hide();
        observer.next("");
    }
    // added code for AccRegister - start
    sendMailtoTreaty(riskObj, caseId, emailType) {
        let reason = "";
        let risk = riskObj;
        if (risk.situation1 && risk.situation1.trim() != "") {
            reason += risk.situation1 + "\r\n|\r\n";
        }
        if (risk.situation2 && risk.situation2.trim() != "") {
            reason += risk.situation2 + "\r\n|\r\n";
        }
        if (risk.situationLine1 && risk.situationLine1.trim() != "") {
            reason += risk.situationLine1 + "\r\n|\r\n";
        }
        if (risk.situationLine2 && risk.situationLine2.trim() != "") {
            reason += risk.situationLine2 + "\r\n|\r\n";
        }
        if (risk.situationLine3 && risk.situationLine3.trim() != "") {
            reason += risk.situationLine3 + "\r\n|\r\n";
        }
        if (risk.situationLine4 && risk.situationLine4.trim() != "") {
            reason += risk.situationLine4 + "\r\n|\r\n";
        }
        if (risk.situationLine5 && risk.situationLine5.trim() != "") {
            reason += risk.situationLine5 + "\r\n|\r\n";
        }
        if (risk.situationLine6 && risk.situationLine6.trim() != "") {
            reason += risk.situationLine6 + "\r\n|\r\n";
        }
        if (risk.situationLine7 && risk.situationLine7.trim() != "") {
            reason += risk.situationLine7 + "\r\n|\r\n";
        }
        if (risk.situationLine8 && risk.situationLine8.trim() != "") {
            reason += risk.situationLine8;
        }
        var formatedSuminsured = numeral(riskObj.totalSI).format("0,0");
        let promise = this._cordysService.callCordysSoapService("SendAutoEmailNotAccuRegister", "http://schemas.insurance.com/businessobject/1.0/", {
            caseId: caseId, emailType: emailType, riskNo: riskObj.riskNumber,
            SituationDetails: reason, totalSI: formatedSuminsured
        }, null, null, true, null);
        promise.success((data) => {
            this._alertMsgService.add(new AlertMessage(AlertMessage.SUCCESS, "Email Notification sent Successfully.", 5000));
        });
        promise.error((error) => this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error while sending Email. Please contact Administrator", 6000)));

    } // End


    public isRCLReasonSupported() {
        return Rx.Observable.create((observer) => {
            let product = BMSConstants.getBMSHeaderInfo().contractType;
            if (this.RCL_PRODUCTS == null) {
                let promise = this._cordysService.httpget("config/bms/rcl/supportedprods.txt");
                promise.subscribe((data) => {
                    this.RCL_PRODUCTS = data.products;
                    if (this.RCL_PRODUCTS.indexOf(product) != -1)
                        observer.next("Y");
                    else
                        observer.next("N");

                },
                    (err) => {
                        observer.next("N");
                    });
            }
            else {
                if (this.RCL_PRODUCTS.indexOf(product) != -1)
                    observer.next("Y");
                else
                    observer.next("N");
            }
        });
    }
}