/*
 * Change History:
 * 
 * No      Date          Description                                         Changed By
 * ====    ==========    ===========                                         ==========	
 * YPK001 23/09/2019       MYS-2019-0675 Document Validation for Co-outwards            PKU1
 *                         case before sending to PPHO			   
*/
import { Component, OnInit, ViewChild, ElementRef, EventEmitter, AfterViewInit, ViewContainerRef } from '@angular/core';
import { DCLInput, CustomDCLService } from "../../../../../common/services/customdcl.service";
import { LOV_Field, LOVDropDownService, SearchFilter } from "../../../../../common/services/lovdropdown/lovdropdown.service";
import { CordysSoapWService } from "../../../../../common/components/utility/cordys-soap-ws";
import { GetLOVData, SearchAdvancedConfig, Filter } from '../../../../../common/components/utility/search/search.requests';
import { AlertMessagesService } from '../../../../../common/components/utility/alertmessage/alertmessages.service';
import { AlertMessage } from '../../../../../common/components/utility/alertmessage/alertmessages.model';
import { ClausesComponent } from "../uimodules/clauses.component";
import { S4808, RiskCoverage } from './appobjects/s4808';
import { Clause } from "../appobjects/clause";
import { Survey } from '../appobjects/survey';
import { ExtraTextDialogData } from "../dialogs/extratext.dialog.data";
import { ModalInput } from "../../../../../common/components/utility/modal/modal";
import { SearchInput } from "../../../../../common/components/utility/search/genericsearch";
import { BMSConstants } from '../../../common/constants/bms_constants';
import { CaseInfo } from '../../../../../common/components/appobjects/caseinfo';
import { ApplicationUtilService } from "../../../../../common/services/application.util.service";
import { BMSUtilService } from "../../../../services/bms.util.service";
import { RIService } from '../services/ri.service';
import { RiskClassificationService } from "../services/riskcls.service";
import { ProposalHeader } from '../../proposalheader/appobjects/proposalheader';//SST Code
import { ActivatedRoute } from '@angular/router';

declare var jQuery: any;
declare var moment: any;
declare var numeral: any;

@Component({
    selector: 's4808-component',
    templateUrl: 'app/bms/components/proposal/newbusinessrisks/s4808/s4808.template.html',
    inputs: ['riskObj', 'clientDetails', "headerInfo", "caseInfo"],
    outputs: ["onPremiumChange", "onRiskClsChange", "onRtngFlgChange"],
    providers: [RiskClassificationService]
})

export class S4808Component implements OnInit {
    private el: HTMLElement;
    private isCoverInfoCollapsed: boolean = false;
    private clCBIInfoCollapse: boolean = true;
    private relatedCollapse: boolean = false;
    private surInfoCollapse: boolean = false;

    public riskObj: S4808;
    public caseInfo: CaseInfo;
    public siFormat: string = "0,00";
    public premiumFormat: string = "0,00.00";
    public rateFormat: string = "0.00000";
    public percentFormat: string = "0.00";
    public accRegCtrl: any;
    private isExcessPercentMandatory: string = 'N';
    private isExcessAmountMandatory: string = 'N';
    private isUnderWriter = "N";
    private isRIMethodEditable = "Y";
    onPremiumChange = new EventEmitter<any>();
    onRiskClsChange = new EventEmitter<any>();
    onRtngFlgChange = new EventEmitter<any>();
    @ViewChild('xtModal', { read: ViewContainerRef }) contentArea: ViewContainerRef;
    @ViewChild(ClausesComponent) private clausesComp: ClausesComponent;
    private isGeneralPageCollapsed: boolean = false;

    public headerInfo: ProposalHeader;//SST Code

    constructor(private lovDropDownService: LOVDropDownService, private _soapService: CordysSoapWService, public _alertMsgService: AlertMessagesService, el: ElementRef, public dcl: CustomDCLService, private _appUtilService: ApplicationUtilService, private _bmsUtilService: BMSUtilService, private _riService: RIService, public riskClassificationService: RiskClassificationService, private _activatedRoute: ActivatedRoute) {
        this.el = el.nativeElement;
    }

    ngOnInit() {
        this.populateLOVs();

        this._appUtilService.isUnderWriterUser().subscribe((data) => {
            this.isUnderWriter = data;
            this.setRIMethodEditableFlag();
        });
        //SST Code
        //if(this.riskObj.GST == 0 || this.riskObj.SST == 0) {
        if (["MyTasks", "MyDrafts"].indexOf(this._activatedRoute.snapshot.params['component']) >= 0 || Object.keys(this._activatedRoute.snapshot.params).length == 0) {
            let respObj = this._bmsUtilService.getTAXDetails();
            if (respObj != undefined && respObj != "") {
                this.headerInfo.SSTTaxRate = Number(respObj[0].old.ITEMPF.GST);
                this.headerInfo.GSTTaxRate = Number(respObj[1].old.ITEMPF.GST);

                this.riskObj.SST = Number(this.headerInfo.SSTTaxRate);
                this.riskObj.GST = Number(this.headerInfo.GSTTaxRate);
            }

            this.headerInfo = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo;
            this.riskObj.SSTLiveDate = (this.riskObj.SSTLiveDate == undefined) ? this.headerInfo.SSTLiveDate : this.riskObj.SSTLiveDate;
            if (this.riskObj.SSTLiveDate == undefined || this.riskObj.SSTLiveDate == "") {
                let tempRespObj = this._bmsUtilService.getLiveDate();
                this.riskObj.GSTLiveDate = tempRespObj[0].old.ITEMPF.LIVEDATE;
                this.riskObj.SSTLiveDate = tempRespObj[1].old.ITEMPF.LIVEDATE;
                if (this.headerInfo.SSTLiveDate == undefined || this.headerInfo.SSTLiveDate == "") {
                    this.headerInfo.SSTLiveDate = this.riskObj.SSTLiveDate;
                }
                if (this.headerInfo.GSTLiveDate == undefined || this.headerInfo.GSTLiveDate == "") {
                    this.headerInfo.GSTLiveDate = this.riskObj.GSTLiveDate;
                }
            }
            if (moment(this.headerInfo.effectiveDate, "YYYY-MM-DD").format("YYYYMMDD") >= moment(this.riskObj.SSTLiveDate, "YYYY-MM-DD").format("YYYYMMDD")) {
                this.riskObj.isGSTApplicable = false;
            } else {
                this.riskObj.isGSTApplicable = true;
            }
        }
        //End
    }
    //START YPK001
    ngAfterViewInit() {
        let rIndex = 0;
        if ((this.headerInfo.CoInsurance == 'Y' && this.riskObj.riskNumber == '1') && (["MyTasks", "MyDrafts"].indexOf(this._activatedRoute.snapshot.params['component']) >= 0 || Object.keys(this._activatedRoute.snapshot.params).length == 0)) {
            if (this.headerInfo.coInsuranceDetails.coInsurance.length == 1) {
                if (!(this.headerInfo.coInsuranceDetails.coInsurance[0].coInsuranceindicator == 'L' && this.headerInfo.coInsuranceDetails.coInsurance[0].sharePercentage == '100')) {
                    rIndex = this.riskObj.clauses.clause.map(function (item) { return item.clauseCode; }).indexOf("COIN");
                    if (rIndex == -1)
                        this.setClauses(["COIN"], false);
                }
            }
            else {
                rIndex = this.riskObj.clauses.clause.map(function (item) { return item.clauseCode; }).indexOf("COIN");
                if (rIndex == -1)
                    this.setClauses(["COIN"], false);
            }
        }
    }
    //END YPK001

    ngAfterViewChecked() {
        this.setHoverForAllCover();
    }

    populateLOVs() {
        this.lovDropDownService.createLOVDataList(["postCode", "Occupation", "piamcode", "construction", "section", "PAExtUnits"]);

        let excessTypeFilter = (this.riskObj.riskType.length == 2) ? this.riskObj.riskType + ' ' : this.riskObj.riskType;
        let excessTypeFilterDetails = [new SearchFilter("DESCITEM", excessTypeFilter, "STARTSWITH", "AND")];
        let excessTypeFilterNodes = this.lovDropDownService.createFilter(excessTypeFilterDetails);

        let lovFields = [
            new LOV_Field("ALL", "FIRE", "NEW BUSINESS", "ALL", "NEW", "FIRE_IDC", "PostCode", "LOV", [], "DESCPF", "postCode", null),
            new LOV_Field("ALL", "MIS", "ALL", "ALL", "ALL", "ALL", "Occupation", "LOV", excessTypeFilterNodes, "T9109", "Occupation", null),
            new LOV_Field("ALL", "FIRE", "NEW BUSINESS", "ALL", "NEW", "FIRE_IDC", "RiskOccupationCode", "LOV", [], "DESCPF", "piamcode", null),
            new LOV_Field("ALL", "MIS", "NEW BUSINESS", "ALL", "ALL", "ALL", "Excess Type", "LOV", excessTypeFilterNodes, "T9107", "excessType", "callbackForExcessTypesLoad"),
            new LOV_Field("ALL", "ALL", "NEW BUSINESS", "ALL", "NEW", "ALL", "MIT Section", "LOV", [], "DESCPF", "section", null),
            new LOV_Field("ALL", "MIS", "NEW BUSINESS", "ALL", "ALL", "ALL", "PAExt Units", "LOV", [], "DESCPF", "PAExtUnits", null)
        ];
        // new LOV_Field("ALL", "MOTOR", "NEW BUSINESS", "ALL", "NEW", "PRIVATE_MOTOR", "RI Retention Code", "LOV", [], "DESCPF", "riCode",null),
        // new LOV_Field("ALL", "ALL", "NEW BUSINESS", "ALL", "NEW", "S4805", "Excess Type", "LOV", [], "DESCPF", "excessType",null),
        // new LOV_Field("ALL", "MOTOR", "NEW BUSINESS", "ALL", "NEW", "NAMED_DRIVER", "Occupation", "LOV", [], "DESCPF", "Occupation",null),
        this.lovDropDownService.util_populateLOV(lovFields, this);

    }

    addRiskCover() {
        if (this.riskObj.riskCoverageDetails.riskCoverage.length >= 4) {
            this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Only 4 cover items allowed", 3000));
        } else {
            // if(this.riskObj.noEmpsTransit > 0){
            let coverageItem = new RiskCoverage();
            coverageItem.seqNumber = this.riskObj.riskCoverageDetails.riskCoverage.length + 1;
            coverageItem.premiumClass = "67";
            // if(this.riskObj.noEmpsTransit > 1 ){
            // coverageItem.rate=0.075;
            // } else if(this.riskObj.noEmpsTransit == 1 ){
            // coverageItem.rate=0.075 + (0.075 * 50/100);
            // } else {
            // coverageItem.rate=0.075;
            // }
            // coverageItem.ratingFactor='L';
            this.riskObj.riskCoverageDetails.riskCoverage.push(coverageItem);
            // } else {
            // this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Please enter 'No of Employess accompanying in Transit.'" , 3000));
            // }
        }
    }

    removeRiskCover(coverItem) {
        let idx = this.riskObj.riskCoverageDetails.riskCoverage.indexOf(coverItem);
        this.riskObj.riskCoverageDetails.riskCoverage.splice(idx, 1);
        this.resetItemNumber();
        this.resetTotal();
    }

    resetItemNumber() {
        for (let _riskCoverage of this.riskObj.riskCoverageDetails.riskCoverage) {
            let index = this.riskObj.riskCoverageDetails.riskCoverage.indexOf(_riskCoverage);
            _riskCoverage.seqNumber = (index + 1);
        }
    }

    onExcessTypeChange(ev) {
        this.riskObj.excessType = ev.value;
        this.setExcessValidationFiels();
    }

    setExcessValidationFiels() {
        if (this.riskObj.excessType && this.riskObj.excessType != '') {
            for (let _etItem of this.lovDropDownService.lovDataList.excessType) {
                if (_etItem.VALUE == this.riskObj.excessType) {
                    this.isExcessPercentMandatory = (_etItem.ACTN02 == 'Y') ? 'Y' : 'N';
                    this.isExcessAmountMandatory = (_etItem.ACTN01 == 'Y') ? 'Y' : 'N';
                    BMSConstants.setExcessTypeRecord(this.riskObj.riskType + this.riskObj.excessType, _etItem);
                }
            }
        }
        else {
            this.isExcessPercentMandatory = 'N';
            this.isExcessAmountMandatory = 'N';
            this.riskObj.excessPercentage = 0;
            this.riskObj.excessAmount = 0;
        }
    }

    callbackForExcessTypesLoad(scopeObject) {
        if (scopeObject.excessType && scopeObject.excessType != '') {
            scopeObject.setExcessValidationFiels();
        }
    }

    onSectionChange(ev, cover, idx) {
        cover.section = ev.value;
        cover.specification = ev.record.LONGDESC;
        cover.ratingFactor = (cover.section == 'A') ? "C" : "L";
        if (cover.ratingFactor == "L")
            cover.eac = 0;

        this.setRate();
        this.setHoverForCover(idx, cover.specification);
    }

    setRate() {
        for (let coverItem of this.riskObj.riskCoverageDetails.riskCoverage) {
			/*
			//GenLink logic
			if(coverItem.section=='A'){
				if(this.riskObj.noEmpsTransit > 1 ){
					coverItem.rate=0.075;
				} else if(this.riskObj.noEmpsTransit == 1 ){
					coverItem.rate=0.075 + (0.075 * 50/100);
				} else {
					coverItem.rate=0.075;
				}
				if(this.riskObj.isSecurityServ=='Y'){
					// coverItem.rate = coverItem.rate - (0.075 * 33/100);
					coverItem.rate = 0.075 - (0.075 * 33.3333/100);
				}
			} else if(coverItem.section=='B'){
				coverItem.rate=0.75;
				if(this.riskObj.isProtected=='Y'){
					// coverItem.rate = coverItem.rate - (0.075 * 25/100);
					coverItem.rate = 0.075 - (0.075 * 25/100);
				}
			} else if(coverItem.section=='C'){
				coverItem.rate=1.0;
			}*/

            this.setCoverPremium(coverItem);
        }
        this.resetTotal();
    }

    setCoverPremium(cover) {
        let liability: any = cover.liability;
        let eac: any = cover.eac;
        let rate: any = cover.rate;
        liability = (liability == null || liability == "") ? 0 : liability;
        eac = (eac == null || eac == "") ? 0 : eac;
        rate = (rate == null || rate == "") ? 0 : parseFloat(rate);

        if (cover.ratingFactor == "C" && eac > 0) {
            let premium = eac * (rate / 100);
            cover.premium = numeral(numeral(premium).format(this.premiumFormat)).value();
        }
        else if (cover.ratingFactor == "L" && liability > 0) {
            let premium = liability * (rate / 100);
            cover.premium = numeral(numeral(premium).format(this.premiumFormat)).value();
        }
        else cover.premium = 0;

        if (cover.premium > 9999999.99) {
            this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Coverage Information: Premium of each cover item must be less than 10,000,000.00", 5000));
        }

        // if(liability > 0 && eac > 0) {
        // // cover.ratingFactor = "C";
        // let premium = eac * (rate/100);
        // cover.premium = numeral(numeral(premium).format(this.premiumFormat)).value();
        // }
        // else if(liability > 0){
        // // cover.ratingFactor = "L";
        // let premium = liability * (rate/100);
        // cover.premium = numeral(numeral(premium).format(this.premiumFormat)).value();
        // }
        // else {
        // // cover.ratingFactor = "";
        // cover.premium = 0;
        // }
    }

    getTotalByProperty(prop, ary, format: string) {
        let total = 0;
        for (let eachItem of ary) {
            if (eachItem[prop] != null && eachItem[prop] != "")
                total = total + parseFloat(numeral(eachItem[prop]).value());
        }
        if (format != null)
            return numeral(numeral(total).format(format)).value();
        else
            return total;
    }

    resetTotal() {

        this.riskObj.totalBasePremium = this.getTotalByProperty("premium", this.riskObj.riskCoverageDetails.riskCoverage, this.premiumFormat);
        this.riskObj.totalSI = this.getTotalByProperty("liability", this.riskObj.riskCoverageDetails.riskCoverage, null);

        this.riskObj.capitalSumInsured = this.riskObj.totalSI;

        let _totalBasePremium = parseFloat("" + this.riskObj.totalBasePremium) + parseFloat("" + this.riskObj.paExtPremium);
        this.riskObj.originalTotalPremium = numeral(numeral(_totalBasePremium).format(this.premiumFormat)).value();

        this.riskObj.rebateAmount = numeral(numeral((parseFloat("" + numeral(_totalBasePremium).value()) * parseFloat("" + this.riskObj.rebate)) / 100).format(this.premiumFormat)).value();
        let discountedPrem = numeral(numeral(parseFloat("" + numeral(_totalBasePremium).value()) - parseFloat("" + numeral(this.riskObj.rebateAmount).value())).format(this.premiumFormat)).value();
        this.riskObj.discountedPremium = discountedPrem;
        //this.riskObj.gstAmount = (parseInt(""+this.riskObj.GST) > 0 && discountedPrem > 0)?numeral(numeral((discountedPrem*parseInt(""+this.riskObj.GST))/100).format(this.premiumFormat)).value():0; //SAF MYS-2018-0629		
        //SST Code
        let tempGSTAmount = (parseInt("" + this.riskObj.GST) > 0 && discountedPrem > 0) ? numeral(numeral((discountedPrem * parseInt("" + this.riskObj.GST)) / 100).format(this.premiumFormat)).value() : 0;
        this.riskObj.gstAmount = (tempGSTAmount > 0) ? numeral(numeral(BMSUtilService.calculatePremiumAmount(tempGSTAmount, "G")).format(this.premiumFormat)).value() : 0;

        let tempSSTAmount = (parseInt("" + this.riskObj.SST) > 0 && discountedPrem > 0) ? numeral(numeral((discountedPrem * parseInt("" + this.riskObj.SST)) / 100).format(this.premiumFormat)).value() : 0;
        this.riskObj.sstAmount = (tempSSTAmount > 0) ? numeral(numeral(BMSUtilService.calculatePremiumAmount(tempSSTAmount, "S")).format(this.premiumFormat)).value() : 0;

        //let _totalPremium = parseFloat(""+numeral(discountedPrem).value()) + parseFloat(""+numeral(this.riskObj.gstAmount).value());
        let _totalPremium = parseFloat("" + numeral(discountedPrem).value()) + parseFloat("" + numeral(this.riskObj.gstAmount).value()) + parseFloat("" + numeral(this.riskObj.sstAmount).value());
        //End
        this.riskObj.totalPremium = numeral(numeral(_totalPremium).format(this.premiumFormat)).value();

        this.onPremiumChange.emit(this.riskObj.totalPremium);

        this.validateSumInsured();

    }

    validateSumInsured() {
        if (this.riskObj.RIRetentionCode && this.riskObj.isRIOverWrittenByUW == 'N') {

            this._bmsUtilService.getTotalGrossCapacity(this.riskObj.RIRetentionCode).subscribe((data) => this.compareSIWithTotGrossCap(data));

			/*let _totalGrossCapacity = this._bmsUtilService.getNetRetentionAmountDetails(this.riskObj.RIRetentionCode);
			_totalGrossCapacity = (!_totalGrossCapacity) ? 0 : parseFloat(""+_totalGrossCapacity);
			this.riskObj.totalGrossCapacity = _totalGrossCapacity;
			let _totalSI = parseFloat(""+this.riskObj.totalSI);
			
			if( _totalGrossCapacity > 0 && _totalSI > _totalGrossCapacity && (this.riskObj.RIMethod == null || this.riskObj.RIMethod == "" || parseFloat(""+this.riskObj.RIMethod) != 8) ){
				this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Total Sum Insured is greater than Total Gross Capacity: "+_totalGrossCapacity+",  RI is Required." , 5000));
				
				this.riskObj.RIRequired = "Yes";
				this.riskObj.RIMethod = "8";
			} 
			else if(_totalSI <= _totalGrossCapacity){
				this.riskObj.RIRequired = "No";
				this.riskObj.RIMethod = this.riskObj.RIMethodSys;
			}*/
        }
        else
            this.setRIMethodEditableFlag();
    }

    compareSIWithTotGrossCap(totGrossCap) {
        let _totalGrossCapacity = (!totGrossCap) ? 0 : parseFloat("" + totGrossCap);
        this.riskObj.totalGrossCapacity = _totalGrossCapacity;
        let _totalSI = parseFloat("" + this.riskObj.totalSI);

        if (_totalGrossCapacity > 0 && _totalSI > _totalGrossCapacity && (this.riskObj.RIMethod == null || this.riskObj.RIMethod == "" || parseFloat("" + this.riskObj.RIMethod) != 8)) {
            this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Total Sum Insured is greater than Total Gross Capacity: " + _totalGrossCapacity + ",  RI is Required.", 5000));

            this.riskObj.RIRequired = "Yes";
            this.riskObj.RIMethod = "8";
        }
        else if (_totalSI <= _totalGrossCapacity) {
            this.riskObj.RIRequired = "No";
            this.riskObj.RIMethod = this.riskObj.RIMethodSys;
        }
        this._riService.setRI().subscribe();
        this.setRIMethodEditableFlag();
    }

    // validateUnits(){
    // if(this.riskObj.units < 0 || this.riskObj.units > 1){
    // this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Units should be 1 or 1" , 5000));
    // } else this.setPAExtensionAmount();
    // }

    onPAExtUnitsChange(eVal) {
        let _noOfUnits = parseFloat("" + this.riskObj.paExtUnits);
        if (_noOfUnits == 1) {
            this.addClause("PER1");
            this.removeClause("PER2");
        } else if (_noOfUnits == 2) {
            this.addClause("PER2");
            this.removeClause("PER1");
        } else {
            this.removeClause("PER2");
            this.removeClause("PER1");
        }

        this.setPAExtensionPremium();
    }

    setPAExtensionPremium() {
        let _paExtUnits = (this.riskObj.paExtUnits == null) ? 0 : parseInt("" + this.riskObj.paExtUnits);
        let _totalNoEmps = parseInt("" + this.riskObj.totalNoEmps);
        let _paExtPremPerUnit: any = (this.riskObj.paExtPremPerUnit) ? this.riskObj.paExtPremPerUnit : 0;
        let _paExtPremium = 0;
        if (_totalNoEmps > 0 && _paExtPremPerUnit > 0) {
            _paExtPremium = _totalNoEmps * _paExtPremPerUnit;
            if (_paExtUnits > 0)
                _paExtPremium = _paExtUnits * _paExtPremium;
        }

        // if(this.riskObj.totalBasePremium > 0)
        // _paExtPremium = _paExtPremium + this.riskObj.totalBasePremium;
        this.riskObj.paExtPremium = _paExtPremium;

        this.resetTotal();
    }

    resetSurvey(value) {
        if ("Y" == value) {
            this.riskObj.survey = new Survey();
        }
        else {
            this.riskObj.survey = null;
        }
    }

    getPostCodeInfo(postcode) {
        let request: GetLOVData = new GetLOVData().getRequest('ALL', 'FIRE', 'NEW BUSINESS', 'ALL', 'NEW', 'FIRE_IDC', 'PostCode', 'LOV');
        request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        request.ADVANCE_CONFIG_XML.FILTERS = new Filter();

        request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({ "@FIELD_NAME": 'DESCITEM', "@FIELD_VALUE": postcode, '@OPERATION': 'EQ', '@CONDITION': 'AND' });
        this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.setPostCodeInfo, this.handleError, true, { comp: this, postCode: postcode });
    }

    handleError(response, status, errorText, prms) {
        prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, response.responseJSON.faultstring.text, -1));
    }

    setPostCodeInfo(response, prms) {
        if (response.tuple != null) {
            prms.comp.riskObj.city = response.tuple.old.DESCPF.SHORTDESC;
            prms.comp.riskObj.cityName = response.tuple.old.DESCPF.LONGDESC;
            // prms.comp.setAccRegInfo();
            // prms.comp.setGSTInfo();
        }
        else {
            prms.comp.riskObj.city = "";
            prms.comp.riskObj.cityName = "";
            // prms.comp.clearAccReg();
        }
    }

    onRIRtnChange(value) {
        this.riskObj.RIRetentionCode = value;
        // this.setSurveyNeed();
    }

    addClause(clauseCode) {
        let isClausePresent = false;

        if (this.riskObj.clauses && this.riskObj.clauses.clause && this.riskObj.clauses.clause.length > 0) {
            for (let clause of this.riskObj.clauses.clause) {
                if (clause.clauseCode == clauseCode) {
                    isClausePresent = true;
                }
            }
        }

        if (!isClausePresent) {
            // this.addClausesInfo(clauseCode);
            this.setClauses([clauseCode], false);
        }

    }

    setClauses(clausesList, flag) {
        if (this.clausesComp)
            this.clausesComp.addClause(clausesList, '', flag);
    }

    deleteClause(ary, clauseCode, prop) {
        let val = undefined;
        if (ary && ary.length > 0) {
            for (var index = 0, assoLength = ary.length; index < assoLength; index++) {
                if (ary[index][prop] != null && ary[index][prop] != "" && ary[index][prop] == clauseCode) {
                    val = index;
                    break;
                }
            }
        }
        if (val != undefined)
            this.clausesComp.removeClause(val, clauseCode);
    }

    removeClause(clauseCode) {

        this.deleteClause(this.riskObj.clauses.clause, clauseCode, "clauseCode");
    }

    private onTextChange(ev) {
        if (ev.target.value == ' ') {
            ev.target.value = '';
        }
    }

    private onKeyPressHandler(ev) {
        if (ev.keyCode == 13 || ev.target.value.length == 47) {
            this.setFocusToNext(ev.target);
        } else if (ev.keyCode == 32) {
            ev.target.value = ev.target.value.trim();
        }
    }

    setFocusToNext(elmnt) {
        let locationElmnts = jQuery(this.el).find("input");
        jQuery(locationElmnts[locationElmnts.index(elmnt) + 1]).focus();
    }

	/*resetFI(value){
		if(value == "Y")
			this.riskObj.financialInterest = new FinancialInterest();
		else
			this.riskObj.financialInterest = null;
	}*/

    setIdentity(isIdentityChange) {
        if (isIdentityChange == true && (this.riskObj.identityFiller == null || this.riskObj.identityFiller == "")) {
            if (this.riskObj.situation1 != null) {
                this.riskObj.identity = this.riskObj.situation1.slice(0, 15);
                this.riskObj.identityFiller = this.riskObj.situation1.slice(0, 15);
            }
        }
        else {
            if (isIdentityChange == false && this.riskObj.situation1 != null) {
                this.riskObj.identity = this.riskObj.situation1.slice(0, 15);
                this.riskObj.identityFiller = this.riskObj.situation1.slice(0, 15);
            }
            else if (this.riskObj.identityFiller != null)
                this.riskObj.identity = this.riskObj.identityFiller.slice(0, 15);
        }
    }

    setRIMethod(val) {

        this.riskObj.RIMethod = (val == "Yes") ? "8" : this.riskObj.RIMethodSys;

        if (this.isUnderWriter == "Y" || val == "Yes")
            this.riskObj.isRIOverWrittenByUW = "Y";
        else if (val == "No") {
            this.riskObj.isRIOverWrittenByUW = "N";
            this.validateSumInsured();
        }
        this._riService.setRI().subscribe();
    }

    setReferredFromUI(event) {
        if (event.target != null) {
            let riskClass = jQuery(event.target).find("option:selected").text();
            this.riskObj.riskClassification = riskClass;
            this.setReferredByRiskClass(this, riskClass);
        }
    }

    setReferredByRiskClass(comp, riskClass) {
        if (riskClass != null && riskClass == "Referred") {
            comp.setReferred(comp, true);
        }
        else {
            comp.setReferredByRI(comp, comp.riskObj.RIRetentionCode);
        }
    }

    setReferred(comp, toRefer) {
        comp.onRiskClsChange.emit("");
    }

    setReferredByRI(comp, riCode) {
        // if(this.leastPreferredRI.indexOf(riCode) != -1){
        // comp.riskObj.riskClassification = "Referred";
        // comp.riskObj.symRiskClassification = "Referred";
        // comp.setReferred(comp,true);
        // }
        // else{
        comp.setReferred(comp, false);
        // }
    }

    setReferredByRIFromUI() {
        if (event.target != null) {
            let riCode = jQuery(event.target).find("option:selected").text();
            this.setReferredByRI(this, riCode);
        }
    }

    emitRiskClass(comp) {
        comp.onRiskClsChange.emit("");
    }

    handleRiskClassification(comp) {
        this.riskClassificationService.setRiskClassification(comp.riskObj.riskNumber, "N", "", "").subscribe();
		/*if(this.riskObj.symRiskClassification == "Declined")
			this.riskObj.riskClassification = "Declined";
		else if(this.riskObj.symRiskClassification == "Referred" || this.riskObj.riRiskClassification == "Referred")
			this.riskObj.riskClassification = "Referred";
		else
			this.riskObj.riskClassification = "Standard";
		this.setRiskClassification();
		this.emitRiskClass(this);*/
    }

    setRiskClassification() {
        if (this.riskObj.symRiskClassification != null && this.riskObj.symRiskClassification != "" && (this.riskObj.symRiskClassification == "Referred" || this.riskObj.symRiskClassification == "Declined")) {
            this.riskObj.riskClassificationReason = "System marked as " + this.riskObj.symRiskClassification;
        }
        else if (this.riskObj.riRiskClassification != null && this.riskObj.riRiskClassification != "" && this.riskObj.riRiskClassification == "Referred") {
            this.riskObj.riskClassificationReason = "System marked as " + this.riskObj.riRiskClassification;
        }
        else {
            if (this.riskObj.riskClassificationReason != null && this.riskObj.riskClassificationReason != "" && (this.riskObj.riskClassificationReason != "System marked as Standard" && this.riskObj.riskClassificationReason.indexOf("System marked as ") != -1)) {
                this.riskObj.riskClassificationReason = "";
            }
        }
    }

    onBusinessCodeChange(ev) {
        this.riskObj.businessCode = ev.value;
        this.riskObj.businessCodeDesc = ev.record.DESCRIPTION; //ev.record.DESCRIPTION.slice(0, 40);
        this.riskObj.occRiskClassification = ev.record.REFERREDRISK;
		/*if(!ev.record.REFERREDRISK || ev.record.REFERREDRISK == 'N'){
			this.riskObj.symRiskClassification = "Standard";
		}
		else if(ev.record.REFERREDRISK && ev.record.REFERREDRISK == 'Y'){
			this.riskObj.symRiskClassification = "Referred";
		}
		else if(ev.record.REFERREDRISK && ev.record.REFERREDRISK == 'D'){
			this.riskObj.symRiskClassification = "Declined";
		}*/

        this.handleRiskClassification(this);

    }

    validateTextInput(ev) {
        let eVal = ev.target.value;
        ev.target.value = eVal.replace(/\s\s+/g, ' ');
    }

    addXT(coverItem) {
        var dialogData = new ExtraTextDialogData("ExtraTextDialogComponent", "app/bms/components/proposal/newbusinessrisks/dialogs/extratext.dialog.module", "ExtraTextDialogModule", "Extra Text", "ExtraText", "fa fa-comment", coverItem, this.extraTextCallBack);
        this.openExtraTextCommentsDialog(dialogData);
    }

    public openExtraTextCommentsDialog(dialogData: ExtraTextDialogData, response?: any) {
        let lookup = new ModalInput();
        lookup.component = [dialogData.component, dialogData.moduleAbsPath, dialogData.moduleName];
        lookup.datainput = {
            dialogName: dialogData.dialogName,
            areCommentsMandatory: false,
            coverageItem: dialogData.coverageItem
        };
        lookup.outputCallback = dialogData.callBackHandler;
        lookup.parentCompPRMS = {
            comp: this,
            response: response
        };
        lookup.heading = dialogData.dialogTitle;
        lookup.icon = dialogData.icon;
        lookup.containerRef = this.contentArea;
        this.dcl.openLookup(lookup);
    }

    private extraTextCallBack(data, prms) {
        if (data.isDialogCancelled) {
            return;
        } else if (!data.isDialogCancelled && data.coverageItem && data.coverageItem.extraText) {
        }
    }

    setHoverForAllCover() {
        let _elIdx = 0;
        for (let _coverItem of this.riskObj.riskCoverageDetails.riskCoverage) {
            this.setHoverForCover(_elIdx, _coverItem.specification);
            _elIdx++;
        }
    }

    setHoverForCover(elIdx, coverVal) {
        let _el = jQuery("input[id='mitCoverItem" + elIdx + "']");
        if (_el) {
            _el.popover();
            _el.attr("data-content", coverVal);
        }
    }

    setRIMethodEditableFlag() {

        let _totalSI = parseFloat("" + this.riskObj.totalSI);
        let _totalGrossCapacity = parseFloat("" + this.riskObj.totalGrossCapacity);
        if (_totalGrossCapacity > 0 && _totalSI > _totalGrossCapacity && this.isUnderWriter == "N") {
            this.isRIMethodEditable = "N";
        }
        else {
            this.isRIMethodEditable = "Y";
        }
    }

    emitFlagChange() {
        this.onRtngFlgChange.emit("");
    }
}
