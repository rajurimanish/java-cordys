import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BasicUIModule } from '../../../../../common/components/utility/basicui.module';
// import { FIModule } from '../../../../../common/components/financialinterest/fi.module';
import { LovModule } from "../../../../../common/services/lovdropdown/lov.module";
import { ClausesModule } from '../uimodules/clauses.module';
import { GSTModule } from '../uimodules/gst.module';
import { SurveyModule } from '../uimodules/survey.module';
import { S4808Component } from './s4808.component';
import { GeneralPageModule } from '../uimodules/generalpage.module'; //VK004

@NgModule({
    imports: [CommonModule, FormsModule, ReactiveFormsModule, BasicUIModule, LovModule, ClausesModule, GSTModule, SurveyModule, GeneralPageModule],
    declarations: [S4808Component],
    exports: [S4808Component]
})
export class S4808Module { }