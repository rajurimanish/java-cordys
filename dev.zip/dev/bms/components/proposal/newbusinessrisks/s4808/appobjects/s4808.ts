import { Clause } from '../../appobjects/clause';
// import {FinancialInterest} from '../../../../../../common/components/financialinterest/appobjects/financialInterest';
import { GSTDetails } from '../../appobjects/gstDetails';
import { Survey } from '../../appobjects/survey';
import { AppUtil } from '../../../../../../common/components/utility/apputil/app.util';
import { NBRisk } from '../../../appobjects/nbrisk';
import { PostedPrem } from '../../../proposalheader/appobjects/postedprem';
import { S4808Validator } from '../../../validation/s4808.validator';
import { RiskHelper } from '../../../appobjects/riskhelper';
import { ReferredReason } from '../../../proposalheader/appobjects/referredreason';

export class S4808 extends RiskHelper implements NBRisk {
    public sequenceNumber: string;
    public effectiveDate: string;
    public dateOfAttachment: string;
    public contractNumber: string;
    public contractType: string;
    public riskNumber: string;
    public riskType: string;
    public riskName: string;
    public ratingFlag: string = "A";
    public businessCode: string;
    public businessCodeDesc: string;
    public occupancyCode: string;
    public occupancyCodeDesc: string;
    public postCode: string;
    public city: string;
    public cityName: string;
    public situation1: string;
    public situation2: string;
    public situationLine1: string;
    public situationLine2: string;
    public situationLine3: string;
    public situationLine4: string;
    public situationLine5: string;
    public situationLine6: string;
    public situationLine7: string;
    public situationLine8: string;
    public RIRetentionCode: string = 'MIT';
    public tLimit: string = "Within Malaysia";
    public excessType: string = "";
    public excessPercentage: number = 0;
    public excessAmount: number = 0;
    public noEmpsTransit: number = 0;
    public isSecurityServ: string = 'N';
    public isProtected: string = 'N';
    public totalNoEmps: number;
    public totalSI: number = 0;
    public capitalSumInsured: number = 0;
    public totalBasePremium: number = 0;
    public totalGrossCapacity: number = 0;
    public numOfInsured: number = 0;
    public paExtUnits: number;
    public paExtPremPerUnit: number;
    public paExtPremium: number = 0;
    public totalPremium: number = 0;
    public originalTotalPremium: number = 0;
    public postedPremium: number = 0;
    public basePostedPremiumAdj: number = 0;
    public discountedPremium: number = 0;
    public minimumPremium: number = 0;
    public rebate: number = 0;
    public rebateAmount: number = 0;
    public GST: number = 0;//6; //SAF MYS-2018-0629
    public gstAmount: number = 0;
    public FI: string = 'N';
    public isSurveyNeeded: string = "N";
    public addRelatedCases: string = "N";
    public hasClaimExperience: string = "N";
    public riskClassification: string = "Standard";
    public riskClassificationReason: string = '';
    public symRiskClassification: string = "";
    public riRiskClassification: string = "Standard";
    public RIMethod: string = "1";
    public RIRequired: string = "No";
    public RIMethodSys: string = "0";
    public isRIOverWrittenByUW: string = "N";
    public identity: string = "";
    public identityFiller: string = "";
    public isPOIConsidered: string = "N";
    public priority: string;
    public riskCoverageDetails: RiskCoverageDetails;
    public clauses: Clause;
    // public financialInterest: FinancialInterest;
    public GSTDetails: GSTDetails;
    public survey: Survey;
    public postedPremDetails: PostedPrem;

    public childRiskPath: string;
    public childRiskIdentity: string;
    public riskClassificationReasons: ReferredReason;

    public occRiskClassification: string;
    public gpText: string;
	public gpTextCount:string; //VK004

    public SST: number = 0; //SST Code
    public sstAmount: number = 0;//SST Code
    public SSTLiveDate: string;//SST Code
    public GSTLiveDate: string;//SST Code
    public isGSTApplicable: boolean = true;//SST Code
    constructor() {
        super();
        this.riskCoverageDetails = new RiskCoverageDetails();
        this.clauses = new Clause();
        // this.financialInterest = new FinancialInterest();		
        this.GSTDetails = new GSTDetails();
        this.survey = new Survey();
        this.riskClassificationReasons = new ReferredReason();
    }

    public getInstance(valObj: S4808) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
            this.riskCoverageDetails = new RiskCoverageDetails().getInstance(valObj.riskCoverageDetails);
            this.clauses = new Clause().getInstance(valObj.clauses);
            // if(valObj.FI == "Y"){
            // this.financialInterest = new FinancialInterest().getInstance(valObj.financialInterest);
            // }
            this.GSTDetails = new GSTDetails().getInstance(valObj.GSTDetails);
            if (valObj.isSurveyNeeded == "Y") {
                this.survey = new Survey().getInstance(valObj.survey);
            }
            this.riskClassificationReasons = new ReferredReason().getInstance(valObj.riskClassificationReasons);
            if (valObj.isGSTApplicable != undefined && JSON.stringify(valObj.isGSTApplicable) != JSON.stringify("") && typeof (valObj.isGSTApplicable) == "string") {
                this.isGSTApplicable = Boolean(JSON.parse(valObj.isGSTApplicable));
            }
        }
        return this;
    }

    public getNewInstanceByCriteria(criteria: any) {
        return this;
    }

    public getValidator() {
        return new S4808Validator(this);
    }

}

export class RiskCoverageDetails {

    public riskCoverage: RiskCoverage[] = [];

    public getInstance(valObj: RiskCoverageDetails) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
            new AppUtil().handleArray(this, valObj, "riskCoverage");
        }
        return this;
    }
}

export class RiskCoverage {
    public seqNumber: number;
    public section: string;
    public specification: string;
    public liability: number = 0;
    public eac: number = 0;
    public rate: number;
    public ratingFactor: string;
    public premium: number;
    public premiumClass: string;
    public extraText: string = "";
    public etPostingStatus = "N";
    // public xtComments:XTComments;

    constructor() {
        // this.xtComments = new XTComments();
    }

    public getInstance(valObj: RiskCoverage) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
            // //this.xtComments = new XTComments().getInstance(valObj.xtComments);
        }
        return this;
    }
}
