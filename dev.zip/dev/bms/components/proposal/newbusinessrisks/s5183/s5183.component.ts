/* 
 *
 * Change History:		
 * 
 * No      Date				Description												Changed By
 * ====    ==========		===========												==========
 *  YPK001 23/09/2019       MYS-2019-0675 Document Validation for Co-outwards            PKU1
 *                         case before sending to PPHO
 */

import { Component, OnInit, ViewChild, ElementRef, EventEmitter, AfterViewInit, ViewContainerRef } from '@angular/core';
import { Observer } from 'rxjs/Observer';
import { DCLInput, CustomDCLService } from '../../../../../common/services/customdcl.service';
import { LOV_Field, LOVDropDownService, SearchFilter } from "../../../../../common/services/lovdropdown/lovdropdown.service";
import { CordysSoapWService } from "../../../../../common/components/utility/cordys-soap-ws";
import { GetLOVData, SearchAdvancedConfig, Filter } from '../../../../../common/components/utility/search/search.requests';
import { AlertMessagesService } from '../../../../../common/components/utility/alertmessage/alertmessages.service';
import { AlertMessage } from '../../../../../common/components/utility/alertmessage/alertmessages.model';
import { S5183, AdditionalCoverageDetails, AdditionalCoverage, BenefitItem } from './appobjects/s5183';
import { Clause } from "../appobjects/clause";
import { ClausesComponent } from "../uimodules/clauses.component";
import { ProposalHeader } from '../../proposalheader/appobjects/proposalheader';
import { ModalInput } from '../../../../../common/components/utility/modal/modal';
import { SearchInput } from "../../../../../common/components/utility/search/genericsearch";
import { ClientDetails } from '../../../../../common/components/client/appobjects/client';
import { RelatedCaseComponent } from "../uimodules/relatedcase.component";
import { FireRelatedCases, RelatedCases } from '../appobjects/relatedCase';
import { NomineeDetails } from "../appobjects/nomineeslist";
import { ApplicationUtilService } from "../../../../../common/services/application.util.service";
import { BMSUtilService } from "../../../../services/bms.util.service";
import { RIService } from '../services/ri.service';
import { ReferredReason, Reasons } from '../../proposalheader/appobjects/referredreason';
import { ReferralReasons, ReferralReason } from '../appobjects/referralReasons';
import { CaseInfo } from '../../../../../common/components/appobjects/caseinfo';
import { BMSConstants } from '../../../common/constants/bms_constants';
import { RiskClassificationService } from "../services/riskcls.service";
import { ActivatedRoute } from '@angular/router';

declare var jQuery: any;
declare var moment: any;
declare var numeral: any;

@Component({
    selector: 's5183-component',
    templateUrl: 'app/bms/components/proposal/newbusinessrisks/s5183/s5183.template.html',
    inputs: ['riskObj', 'clientDetails', "headerInfo"],
    outputs: ["onPremiumChange", 'onRiskClsChange']
})

export class S5183Component implements OnInit {
    @ViewChild(ClausesComponent) private clausesComp: ClausesComponent;
    @ViewChild('paCompModal', { read: ViewContainerRef }) contentArea: ViewContainerRef;
    public leastPreferredRI = ['D1E1', 'D1E2', 'D1E3', 'D2E1', 'D2E2', 'D2E3', 'D3E1', 'D3E2', 'D3E3'];
    onPremiumChange = new EventEmitter<any>();
    onRiskClsChange = new EventEmitter<any>();
    public clientDetails: ClientDetails;
    private caseInfo: CaseInfo;
    private el: HTMLElement;
    public headerInfo: ProposalHeader;

    public riskObj: S5183;
    public accRegCtrl: any;
    public siFormat: string = "0,00";
    public premiumFormat: string = "000.00";
    public rateFormat: string = "00.0000";
    public percentFormat: string = "0.00";
    public bonusFormat: String = "0.00";


    private isCollapsedMode: boolean = true;
    private collapseInsuredInfo: boolean = false;
    private isCoverInfoCollapsed: boolean = false;
    private collapseClausesInfo: boolean = true;
    private isNomineeInfoCollapsed: boolean = false;
    private isGeneralPageCollapsed: boolean = false;
    private DOBCtrl: any;
    private renewalBonusAmountCtrl: any;
    private renewalBonusPercentageCtrl: any;
    private disableRenewalBonusAmount = "N";
    private disableRenewalBonusPercentage = "N";

    public search: String = "";
    public position = 1;
    public sizeObj = { length: 0, orglength: 0 };
    public contentSizeObs: Observer<String>;
    public itemPerPage = 10;
    public maxPageCount = 10;

    private isUnderWriter = "N";
    private isRIMethodEditable = "Y";
    public defaultClauseCode: string = "";

    constructor(public dcl: CustomDCLService, private lovDropDownService: LOVDropDownService, private _soapService: CordysSoapWService, public _alertMsgService: AlertMessagesService, el: ElementRef, private _appUtilService: ApplicationUtilService, private _bmsUtilService: BMSUtilService, private _riService: RIService, private riskClassificationService: RiskClassificationService, private _activatedRoute: ActivatedRoute) {
        this.el = el.nativeElement;
    }

    ngOnInit() {

        if (this.riskObj.riskNumber == "1" && (this.riskObj.insuredName == undefined || this.riskObj.insuredName == ""))
            this.setClientInfo();

        //if(!(this.riskObj.renewalBonusPercentage == undefined || this.riskObj.renewalBonusPercentage == '')){
        if (parseFloat("" + this.riskObj.renewalBonusPercentage) > 0) {
            this.disableRenewalBonusAmount = "Y";
        }
        //if(!(this.riskObj.renewalBonusAmount == undefined || this.riskObj.renewalBonusAmount == '')){
        if (parseFloat("" + this.riskObj.renewalBonusAmount) > 0) {
            this.disableRenewalBonusPercentage = "Y";
        }

        this._appUtilService.isUnderWriterUser().subscribe((data) => {
            this.isUnderWriter = data;
            this.setRIMethodEditableFlag();
        });

        this.caseInfo = BMSConstants.getBMSObj().ApplicationBusinessObject.caseInfo;

        this.populateLOVs();
        //SST Code
        if (["MyTasks", "MyDrafts"].indexOf(this._activatedRoute.snapshot.params['component']) >= 0 || Object.keys(this._activatedRoute.snapshot.params).length == 0) {
            let respObj = this._bmsUtilService.getTAXDetails();
            if (respObj != undefined && respObj != "") {
                this.headerInfo.SSTTaxRate = Number(respObj[0].old.ITEMPF.GST);
                this.headerInfo.GSTTaxRate = Number(respObj[1].old.ITEMPF.GST);

                this.riskObj.SST = Number(this.headerInfo.SSTTaxRate);
                this.riskObj.GST = Number(this.headerInfo.GSTTaxRate);
            }

            this.headerInfo = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo;
            this.riskObj.SSTLiveDate = (this.riskObj.SSTLiveDate == undefined) ? this.headerInfo.SSTLiveDate : this.riskObj.SSTLiveDate;
            if (this.riskObj.SSTLiveDate == undefined || this.riskObj.SSTLiveDate == "") {
                let tempRespObj = this._bmsUtilService.getLiveDate();
                this.riskObj.GSTLiveDate = tempRespObj[0].old.ITEMPF.LIVEDATE;
                this.riskObj.SSTLiveDate = tempRespObj[1].old.ITEMPF.LIVEDATE;
                if (this.headerInfo.SSTLiveDate == undefined || this.headerInfo.SSTLiveDate == "") {
                    this.headerInfo.SSTLiveDate = this.riskObj.SSTLiveDate;
                }
                if (this.headerInfo.GSTLiveDate == undefined || this.headerInfo.GSTLiveDate == "") {
                    this.headerInfo.GSTLiveDate = this.riskObj.GSTLiveDate;
                }
            }
            if (moment(this.headerInfo.effectiveDate, "YYYY-MM-DD").format("YYYYMMDD") >= moment(this.riskObj.SSTLiveDate, "YYYY-MM-DD").format("YYYYMMDD")) {
                this.riskObj.isGSTApplicable = false;
            } else {
                this.riskObj.isGSTApplicable = true;
            }
        }
        //End
    }
    //START YPK001
    ngAfterViewInit() {
        let rIndex = 0;
        if ((this.headerInfo.CoInsurance == 'Y' && this.riskObj.riskNumber == '1') && (["MyTasks", "MyDrafts"].indexOf(this._activatedRoute.snapshot.params['component']) >= 0 || Object.keys(this._activatedRoute.snapshot.params).length == 0)) {
            if (this.headerInfo.coInsuranceDetails.coInsurance.length == 1) {
                if (!(this.headerInfo.coInsuranceDetails.coInsurance[0].coInsuranceindicator == 'L' && this.headerInfo.coInsuranceDetails.coInsurance[0].sharePercentage == '100')) {
                    rIndex = this.riskObj.clauses.clause.map(function (item) { return item.clauseCode; }).indexOf("COIN");
                    if (rIndex == -1)
                        this.setClauses(["COIN"], false);
                }
            }
            else {
                rIndex = this.riskObj.clauses.clause.map(function (item) { return item.clauseCode; }).indexOf("COIN");
                if (rIndex == -1)
                    this.setClauses(["COIN"], false);
            }
        }
    }
    //END YPK001
    onRenewalBonusPercentageChange(evt) {
        if (parseFloat("" + evt.target.value) > 0) {
            if (this.renewalBonusAmountCtrl != null)
                this.renewalBonusAmountCtrl.setDisable("Y", this.renewalBonusAmountCtrl.comp);
        } else {
            if (this.renewalBonusAmountCtrl != null)
                this.renewalBonusAmountCtrl.setDisable("N", this.renewalBonusAmountCtrl.comp);
        }
    }

    onRenewalBonusAmountChange(evt) {
        if (parseFloat("" + evt.target.value) > 0) {
            if (this.renewalBonusPercentageCtrl != null)
                this.renewalBonusPercentageCtrl.setDisable("Y", this.renewalBonusPercentageCtrl.comp);
        } else {
            if (this.renewalBonusPercentageCtrl != null)
                this.renewalBonusPercentageCtrl.setDisable("N", this.renewalBonusPercentageCtrl.comp);
        }
    }


    /****  Generic Handlers *****/
    handleError(response, status, errorText, prms) {
        prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, response.responseJSON.faultstring.text, 5000));
    }

    getRiskType() {
        let riskType = this.riskObj.riskType;
        while (riskType != undefined && riskType.length < 3) {
            riskType = riskType + " ";
        }
        return riskType;
    }

    populateLOVs() {
        this.lovDropDownService.createLOVDataList(["Occupation", "ratingClass", "Plans", "referralAgeLimits"]);

        let riskFilter = (this.riskObj.riskType.length == 2) ? this.riskObj.riskType + ' ' : this.riskObj.riskType;

        if (this.caseInfo.businessFunction == 'NewBusiness') riskFilter = riskFilter + "0";
        // let riskType = this.getRiskType();

        let riskTypeFilterDetails = [
            new SearchFilter("DESCITEM", riskFilter, "STARTSWITH", "AND"),
            new SearchFilter("ITMFRM", moment(this.headerInfo.effectiveDate, "YYYY-MM-DD").format("YYYYMMDD"), "LT", "AND"),
            new SearchFilter("ITMTO", moment(this.headerInfo.effectiveDate, "YYYY-MM-DD").format("YYYYMMDD"), "GT", "AND")
        ];
        let riskTypeSearchFilterNodes = this.lovDropDownService.createFilter(riskTypeFilterDetails);

        riskFilter = (this.riskObj.riskType.length == 2) ? this.riskObj.riskType + ' ' : this.riskObj.riskType;
        let referralAgeLimitNodes = this.lovDropDownService.createFilter([new SearchFilter("DESCITEM", riskFilter, "EQ", "AND")]);

        let _riskFilter1 = (this.riskObj.riskType.length == 2) ? this.riskObj.riskType + ' ' : this.riskObj.riskType;
        let _riskFilterforOccDetails = [new SearchFilter("DESCITEM", _riskFilter1, "STARTSWITH", "AND")];
        let _riskFilterforOccNodes = this.lovDropDownService.createFilter(_riskFilterforOccDetails);

        let lovFields = [
            new LOV_Field("ALL", "MIS", "ALL", "ALL", "ALL", "ALL", "Occupation", "LOV", _riskFilterforOccNodes, "T9109", "Occupation", "occupationLOVCallBack"),
            new LOV_Field("ALL", "PERSONAL ACCIDENT", "NEW BUSINESS", "ALL", "NEW", "PERSONAL ACCIDENT", "RatingClass", "LOV", [], "DESCPF", "ratingClass", "occupationClassLOVCallBack"),
            new LOV_Field("ALL", "ALL", "ALL", "ALL", "ALL", "S5183", "Plans", "LOV", riskTypeSearchFilterNodes, "T5185", "Plans", null),
            new LOV_Field("ALL", "MED", "ALL", "ALL", "ALL", "ALL", "Referral Age Limits", "LOV", referralAgeLimitNodes, "T7253", "referralAgeLimits", "callbackReferralAgeLimits")
        ];
        this.lovDropDownService.util_populateLOV(lovFields, this);
    }

    occupationLOVCallBack(scopeObject) {
        /*let temp1 = scopeObject.lovDropDownService.lovDataList.Occupation;
        let temp2 = [{"VALUE": "","DESCRIPTION": "","REFERREDRISK": "", "COMB_DESCRIPTION":"--Select Value--"}];
        scopeObject.lovDropDownService.lovDataList.Occupation = [].concat(temp2,temp1);*/

        if (scopeObject.riskObj.occupationCode && !scopeObject.riskObj.occupationDescription) {
            let _occRec = scopeObject.lovDropDownService.lovDataList.Occupation.find((_item) => _item.VALUE == scopeObject.riskObj.occupationCode);
            if (_occRec) {
                if (!scopeObject.riskObj.occupationDescription)
                    scopeObject.riskObj.occupationDescription = _occRec.LONG_DESC;
            }
            else {
                scopeObject.riskObj.occupationCode = '';
                scopeObject.riskObj.occupationDescription = '';
            }
        }

    }

    occupationClassLOVCallBack(scopeObj) {
        /*let temp1 = scopeObj.lovDropDownService.lovDataList.Occupation;
        let temp2 = [{"VALUE": "","DESCRIPTION": "","REFERREDRISK": "", "COMB_DESCRIPTION":"--Select Value--"}];
        scopeObj.lovDropDownService.lovDataList.Occupation = [].concat(temp2,temp1);*/
    }

    callbackReferralAgeLimits(scopeObject) {
        if (this.riskObj.insuredAge == 0 || (!this.riskObj.ageLimitFlag && this.riskObj.dateOfBirth && this.riskObj.occupationCode)) {
            this.checkReferredRiskConditions();
        }
    }

    setClientInfo() {
        if (this.clientDetails.client.genericDetails.clienttype == 'P') {
            if (this.clientDetails.client.personalClientDetails) {
                this.riskObj.insuredName = this.clientDetails.client.personalClientDetails.Name;
                let _dob = this.clientDetails.client.personalClientDetails.dateOfBirth;
                this.riskObj.dateOfBirth = (_dob && _dob != '99999999') ? moment(_dob, "YYYYMMDD").format("YYYY-MM-DD") : '';
                this.riskObj.occupationCode = this.clientDetails.client.personalClientDetails.occupationCode;
            }
        }
    }

    onOccupationChange(ev) {
        this.riskObj.occupationCode = ev.value;
        this.riskObj.occupationDescription = ev.record.LONG_DESC;

        this.checkReferredRiskConditions();
    }

    /**** Data Validations ****/
    rateMinMaxValidation(cover) {
        if (cover.additionalLoading >= 0 && cover.additionalLoading <= 100) {
            this.setAdditionalPremiumForEach(cover);
            this.getAdditionalPremiumTotal();
            this.setTotalPremium();
        } else {
            cover.additionalLoading = 0;
            this.setAdditionalPremiumForEach(cover);
            this.getAdditionalPremiumTotal();
            this.setTotalPremium();
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Rate Should be between 0 and 100 only", 5000));
        }
    }

    calculateAge(dob) {
        let calAge: number = 0;
        if (dob != null && dob != "") {
            let curDate = moment(new Date().toISOString(), "YYYY-MM-DD");
            let date = moment(dob, "YYYYMMDD").format("YYYY-MM-DD");
            calAge = curDate.diff(date, 'year');
        }
        else
            calAge = 0;
        return calAge;
    }

    setInsuredAge() {
        this.calculateInsuredAge();
        // this.riskObj.insuredAge = this.calculateAge(this.riskObj.dateOfBirth);
    }

    validateDOB(value) {
        if (value != null && value != "") {
            let curDate = moment().format("YYYYMMDD");
            if (Number(curDate) <= Number(moment(value, "YYYY-MM-DD").format("YYYYMMDD"))) {
                this.DOBCtrl.setter("EMPTY", "YYYY-MM-DD", this.DOBCtrl.comp);
                this.riskObj.dateOfBirth = "";
                this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Insured Date of Birth can not be future date.", 5000));
            }
        }
        // this.checkReferredRisk(this);
        this.checkReferredRiskConditions();
    }


    /**** Premium Calculations ****/
    onPlanChange() {
        this.riskObj.planBenefits.benefit = [];
        let request: GetLOVData = new GetLOVData().getRequest('ALL', 'ALL', 'ALL', 'ALL', 'ALL', 'S5183', 'PlanDetails', 'LOV');
        request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        request.ADVANCE_CONFIG_XML.FILTERS = new Filter();
        request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push(
            { "@FIELD_NAME": "DESCITEM", "@FIELD_VALUE": this.riskObj.riskType + this.riskObj.plan, "@OPERATION": "EQ", "@CONDITION": "AND" },
            { "@FIELD_NAME": "ITMFRM", "@FIELD_VALUE": moment(this.headerInfo.effectiveDate, "YYYY-MM-DD").format("YYYYMMDD"), "@OPERATION": "LT", "@CONDITION": "AND" },
            { "@FIELD_NAME": "ITMTO", "@FIELD_VALUE": moment(this.headerInfo.effectiveDate, "YYYY-MM-DD").format("YYYYMMDD"), "@OPERATION": "GT", "@CONDITION": "AND" }
        );
        this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, null, null, false, null).success((data) => {
            if (data.tuple) {
                let ary = [];
                let seq = 0;
                if (data.tuple != null && !Array.prototype.isPrototypeOf(data.tuple)) {
                    ary = [data.tuple];
                }
                else if (data.tuple != null) {
                    ary = data.tuple;
                }
                for (let coverage of ary) {
                    let _cover = new BenefitItem();
                    _cover.seqNumber = ++seq;
                    let _rate = (coverage.old.T5185.RATE) ? parseFloat("" + coverage.old.T5185.RATE) : 0;
                    if (_rate > 0) _rate = _rate * 0.0001;

                    _cover.coverageDescription = coverage.old.T5185.COVERS;
                    _cover.planA = numeral(Number(coverage.old.T5185.PLAN_A)).format('0');
                    _cover.planB = numeral(Number(coverage.old.T5185.PLAN_B)).format('0');
                    _cover.planC = numeral(Number(coverage.old.T5185.PLAN_C)).format('0');
                    _cover.planD = numeral(Number(coverage.old.T5185.PLAN_D)).format('0');
                    _cover.planE = numeral(Number(coverage.old.T5185.PLAN_E)).format('0');
                    _cover.rate = numeral(Number(_rate)).format('0.0000');
                    this.riskObj.planBenefits.benefit.push(_cover);
                }
            }
            this.setSIAndPremium();
        }).error((response, status, errorText) => {
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error while getting basic premium for Plan - " + this.riskObj.plan, 5000));
        });
    }

    setSIAndPremium() {
        let _planSubStr = Number(this.riskObj.plan.substr(1));
        let _SI = 0;
        let _premium = 0.00;

        if (this.riskObj.planBenefits.benefit[0]) {
            if (Number(this.riskObj.plan.substr(1)) == 1) {
                _SI = Number(this.riskObj.planBenefits.benefit[0].planA);
            } else if (Number(this.riskObj.plan.substr(1)) == 2) {
                _SI = Number(this.riskObj.planBenefits.benefit[0].planB);
            } else if (Number(this.riskObj.plan.substr(1)) == 3) {
                _SI = Number(this.riskObj.planBenefits.benefit[0].planC);
            } else if (Number(this.riskObj.plan.substr(1)) == 4) {
                _SI = Number(this.riskObj.planBenefits.benefit[0].planD);
            } else if (Number(this.riskObj.plan.substr(1)) == 5) {
                _SI = Number(this.riskObj.planBenefits.benefit[0].planE);
            }
        }
        if (this.riskObj.planBenefits.benefit[5]) {
            if (Number(this.riskObj.plan.substr(1)) == 1) {
                _premium = Number(this.riskObj.planBenefits.benefit[5].planA);
            } else if (Number(this.riskObj.plan.substr(1)) == 2) {
                _premium = Number(this.riskObj.planBenefits.benefit[5].planB);
            } else if (Number(this.riskObj.plan.substr(1)) == 3) {
                _premium = Number(this.riskObj.planBenefits.benefit[5].planC);
            } else if (Number(this.riskObj.plan.substr(1)) == 4) {
                _premium = Number(this.riskObj.planBenefits.benefit[5].planD);
            } else if (Number(this.riskObj.plan.substr(1)) == 5) {
                _premium = Number(this.riskObj.planBenefits.benefit[5].planE);
            }
        }
        this.riskObj.capitalSumInsured = _SI;
        this.riskObj.basicPremium = _premium;

        // this.getAdditionalPremiumTotal();
        this.setTotalPremium();
        this.validateCapitalSumInsured();
    }

    setFinalSI() {
        if (this.isLeastPreferredRI()) {
            this.riskObj.isLeastPreferred = "Y";
        }
        else {
            this.riskObj.isLeastPreferred = "N";
        }
        this.riskObj.capitalSumInsured = this.riskObj.totalSI;

        this.validateCapitalSumInsured();
    }

    setRoutingSI() {
        let _businessObject = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject;
        if (_businessObject && _businessObject.bms && _businessObject.bms.newBusiness && _businessObject.bms.newBusiness.risks) {
            if (_businessObject.bms.newBusiness.risks.s5183 && _businessObject.bms.newBusiness.risks.s5183.length > 0) {

                let _referredRoutingSI = 0;
                let _standardRoutingSI = 0;
                for (let _rsk of _businessObject.bms.newBusiness.risks.s5183) {
                    let _si: any = (_rsk.capitalSumInsured == null || _rsk.capitalSumInsured == "") ? 0 : parseFloat("" + _rsk.capitalSumInsured);

                    if (_rsk.riskClassification == 'Referred') {
                        _referredRoutingSI = (_si > _referredRoutingSI) ? _si : _referredRoutingSI;
                    }
                    else {
                        _standardRoutingSI = (_si > _standardRoutingSI) ? _si : _standardRoutingSI;
                    }
                }

                for (let _rsk of _businessObject.bms.newBusiness.risks.s5183) {
                    if (_referredRoutingSI > 0) {
                        _rsk.bigCapitalSumInsured = _referredRoutingSI;
                    }
                    else
                        _rsk.bigCapitalSumInsured = _standardRoutingSI;

                }
            }
        }
    }

    isLeastPreferredRI() {
        if (this.riskObj.RIRetentionCode != null) {
            if (this.leastPreferredRI.indexOf(this.riskObj.RIRetentionCode) != -1) {
                return true;
            }
        }
        return false;
    }

    setRebateAmount() {
        let rebatePercent = 0;
        if (this.riskObj.rebate != undefined && Number(this.riskObj.rebate) <= 25) {
            rebatePercent = numeral().unformat(this.riskObj.rebate);
            let tempAmount = numeral().unformat(this.riskObj.totalPremium);
            this.riskObj.rebateAmount = Number(tempAmount * (rebatePercent / 100));
            this.riskObj.rebateAmount = numeral(this.riskObj.rebateAmount).format('0.00');
        }
    }

    setTotalPremium() {
        let _additionalCoverTotalPremium = 0;
        let _additionalPremium = 0;
        let _rebateAmount = 0;
        let _gstAmount = 0;
        let _totalPremium = 0;
        let _loadingAmount = 0;
        let _discountAmount = 0;
        let _totalBasicPremium = 0;

        let _basicPremium: any = this.riskObj.basicPremium;
        let _loadingPercent: any = this.riskObj.loadingPercentage;
        let _discountPercent: any = this.riskObj.discountPercentage;

        _basicPremium = (_basicPremium == null || _basicPremium == "") ? 0 : parseFloat("" + _basicPremium);
        _loadingPercent = (_loadingPercent == null || _loadingPercent == "") ? 0 : _loadingPercent;
        _discountPercent = (_discountPercent == null || _discountPercent == "") ? 0 : _discountPercent;

        _totalBasicPremium = parseFloat("" + _basicPremium);

        if (this.riskObj.additionalCoverDetails.additionalCover && this.riskObj.additionalCoverDetails.additionalCover.length > 0) {
            for (let _addCover of this.riskObj.additionalCoverDetails.additionalCover) {
                let _rate: any = _addCover.additionalLoading;
                _rate = (_rate == null || _rate == "") ? 0 : _rate;
                let _addCoverPrem = 0;
                if (_basicPremium > 0 && _rate > 0) {
                    _addCoverPrem = _basicPremium * _rate * 0.01;
                }

                _addCover.addditionalPremium = numeral(_addCoverPrem).format('0.00');
            }
        }

        let _addlCoverTotal = this.getTotalByProperty("addditionalPremium", this.riskObj.additionalCoverDetails.additionalCover);
        this.riskObj.additionalCoverDetails.additionalCoverTotal = numeral(_addlCoverTotal).format('0.00');

        if (_basicPremium > 0 || parseFloat("" + this.riskObj.additionalCoverDetails.additionalCoverTotal) > 0) {
            _totalBasicPremium = _basicPremium + parseFloat("" + this.riskObj.additionalCoverDetails.additionalCoverTotal);
        }

        this.riskObj.totalBasicPremium = numeral(Number(_totalBasicPremium)).format('0.00');
        _totalPremium = _totalBasicPremium;

        if (_basicPremium > 0 && _loadingPercent > 0) {
            _loadingAmount = _basicPremium * _loadingPercent * 0.01;
            _loadingAmount = this.formatPremiumAmount(_loadingAmount);
        }
        this.riskObj.loadingAmount = numeral(Number(_loadingAmount)).format('0.00');

        if (_loadingAmount > 0) {
            _totalPremium = _totalBasicPremium + _loadingAmount;
        }

        if (_basicPremium > 0 && _loadingAmount > 0 && _discountPercent > 0) {
            _discountAmount = (_basicPremium + _loadingAmount) * _discountPercent * 0.01;
            _discountAmount = this.formatPremiumAmount(_discountAmount);
        }
        else if (_basicPremium > 0 && _discountPercent > 0) {
            _discountAmount = _basicPremium * _discountPercent * 0.01;
            _discountAmount = this.formatPremiumAmount(_discountAmount);
        }
        this.riskObj.discountAmount = numeral(Number(_discountAmount)).format('0.00');

        _totalPremium = _totalBasicPremium + _loadingAmount - _discountAmount;


        this.riskObj.originalTotalPremium = numeral(Number(_totalPremium)).format('0.00');
        this.riskObj.totalPremium = this.riskObj.originalTotalPremium;

        if (_totalPremium > 0) {
            let _rebateRate: any = this.riskObj.rebate;
            _rebateRate = (_rebateRate == null || _rebateRate == "") ? 0 : parseFloat("" + _rebateRate);
            let _rebateAmount = (_rebateRate > 0) ? (_totalPremium * _rebateRate * 0.01) : 0;
            this.riskObj.rebateAmount = numeral(Number(_rebateAmount)).format('0.00');
            _totalPremium = _totalPremium - _rebateAmount;
        } else
            this.riskObj.rebateAmount = 0;

        // this.riskObj.gstAmount = (parseInt(""+this.riskObj.GST) > 0 && _totalPremium > 0) ? numeral(numeral((_totalPremium * parseInt(""+this.riskObj.GST))/100).format(this.premiumFormat)).value() : 0;

        this.riskObj.totalPremium = numeral(Number(_totalPremium)).format('0.00');

        // this.riskObj.totalAnnualPremium = this.riskObj.totalPremium;

		/*
        _gstAmount = (_totalPremium / 100 * 6);
        _totalPremium = _totalPremium+_gstAmount;
		
        this.riskObj.gstAmount = numeral(Number(_gstAmount)).format('0.00');    
        this.riskObj.loadingAmount = numeral(Number(_loadingAmount)).format('0.00');
        this.riskObj.discountAmount = numeral(Number(_discountAmount)).format('0.00');
        this.riskObj.totalPremium = numeral(Number(_totalPremium)).format('0.00');
		
		_totalPremium = this.riskObj.totalBasicPremium + this.riskObj.loadingAmount + this.riskObj.discountAmount;
		this.riskObj.totalPremium = numeral(Number(_totalPremium)).format('0.00');
		this.riskObj.originalTotalPremium = this.riskObj.totalPremium;
        this.riskObj.totalAnnualPremium = this.riskObj.totalPremium; 
		*/

        // this.setRebateAmount();
        // this.setPostingPremium();

        //_rebateAmount = numeral().unformat(this.riskObj.rebateAmount);
        this.setRoutingSI();
        this.onPremiumChange.emit(this.riskObj.totalPremium);
    }

    setPostingPremium() {
        this.riskObj.postingPremium = ((this.riskObj.totalAnnualPremium) / 365) * this.calcDays();
        //this.riskObj.totalAnnualPremium = numeral(this.riskObj.totalAnnualPremium).format('0.00');
        this.riskObj.postingPremium = numeral(this.riskObj.postingPremium).format('0.00');
        //this.onpostedpremiumchange.emit("");
    }

    calcDays() {
        let date1 = moment(this.headerInfo.effectiveDate, "YYYY-MM-DD");
        let date2 = moment(this.headerInfo.endDate, "YYYY-MM-DD");
        return date2.diff(date1, 'days') + 1;//added +1 to always include endDate for calculation
        //return Math.ceil(timeDiff / (1000 * 3600 * 24));
    }

    checkReferredRisk(comp) {
        //validate date of birth and age range to identify referred risk. if not check on occupation
        if (comp.riskObj.dateOfBirth && comp.isItInAgeRange() == false) {
            comp.riskObj.symRiskClassification = "Referred";
            comp.riskObj.riskClassification = comp.riskObj.symRiskClassification;
        } else {
            if (comp.riskObj.occRiskClassification != null && comp.riskObj.occRiskClassification == "Referred") {
                comp.riskObj.symRiskClassification = "Referred";
                comp.riskObj.riskClassification = comp.riskObj.symRiskClassification;
            } else {//if(comp.riskObj.occRiskClassification != null && comp.riskObj.occRiskClassification != ""){
                if (comp.riskObj.dateOfBirth && comp.isItInAgeRange() == false) {
                    comp.riskObj.symRiskClassification = "Referred";
                    comp.riskObj.riskClassification = comp.riskObj.symRiskClassification;
                } else {
                    comp.riskObj.symRiskClassification = comp.riskObj.occRiskClassification;
                    comp.riskObj.riskClassification = comp.riskObj.symRiskClassification;
                }
            }
        }
        comp.setRiskClassification(comp);
    }

    setRiskClassification(comp) {
        if (comp.riskObj.symRiskClassification != null && comp.riskObj.symRiskClassification != "" && (comp.riskObj.symRiskClassification == "Referred" || comp.riskObj.symRiskClassification == "Declined")) {
            let statusTxt = (comp.riskObj.symRiskClassification != null && comp.riskObj.symRiskClassification != "") ? comp.riskObj.symRiskClassification : comp.riskObj.riskClassification;
            comp.riskObj.riskClassificationReason = "System marked as " + statusTxt;
        }
        else {
            if (comp.riskObj.riskClassificationReason != null && comp.riskObj.riskClassificationReason != "" && (comp.riskObj.riskClassificationReason != "System marked as Standard"
                && comp.riskObj.riskClassificationReason.indexOf("System marked as ") != -1)) {
                comp.riskObj.riskClassificationReason = "";
            }
        }
        comp.onRiskClsChange.emit('');
    }

    changeRiskClassification(event) {
        this.riskObj.riskClassification = event.target.value;
        this.onRiskClsChange.emit('');
    }
    isItInAgeRange() {
        //Age above 70 to be treated as Referred
        if (Number(this.riskObj.insuredAge) > 70) {
            return false;
        }
        else {
            return true;
        }
    }


    /*****Handling Risk Classification based on Occupation Ends here****/


    openAdditionalCoverageDetailsDialog() {

        let searchInput = new SearchInput();
        searchInput.isSingleSelect = false;
        searchInput.BRANCH = 'ALL';
        searchInput.BUSINESS_FUNCTION = 'NEW BUSINESS';
        searchInput.FIELD_TYPE = 'LOOKUP';
        searchInput.FORM_FIELD_NAME = 'Additional Coverage';
        searchInput.FORM_NAME = 'ALL';
        searchInput.LOB = 'ALL';
        searchInput.OPERATION = 'NEW';
        searchInput.PRODUCT = 'ALL';

        if (this.riskObj.additionalCoverDetails.additionalCover.length > 0) {
            let newArr = [];
            for (let item of this.riskObj.additionalCoverDetails.additionalCover) {
                newArr = newArr.concat(item["additionalCode"]);
            }
            let additionalCoverCodes = "'" + newArr.toString().replace(/,/g, "\',\'") + "'";
            searchInput.condition = { "A.DESCITEM": additionalCoverCodes };
        }
        else
            searchInput.condition = { "A.DESCITEM": "''" };

        let input = new ModalInput().get("GenericSearchComponent");
        input.datainput = searchInput;
        input.outputCallback = this.addAdditionalCoverage;
        input.containerRef = this.contentArea;
        input.parentCompPRMS = { comp: this };
        input.heading = "Additional Cover Details";
        input.icon = "fa fa-file-pdf-o";
        this.dcl.openLookup(input);
    }

    setClauses(clausesList, flag) {
        if (this.clausesComp)
            this.clausesComp.addClause(clausesList, '', flag);
    }

    setLoadAndPremium() {
        /*let rebatePercent = 0;
        if(this.riskObj.rebate != undefined && Number(this.riskObj.rebate) <= 25) {
            rebatePercent = numeral().unformat(this.riskObj.rebate);
            let tempAmount = numeral().unformat(this.riskObj.basicPremium) + numeral().unformat(this.riskObj.addditionalPremium);
            this.riskObj.rebateAmount = Number(tempAmount * (rebatePercent/100));
            this.riskObj.rebateAmount = numeral(this.riskObj.rebateAmount).format('0.00');
        }*/

        this.setTotalPremium();
    }

    deleteClause(ary, clauseCode, prop) {
        let val = undefined;
        if (ary.length > 0) {
            for (var index = 0, assoLength = ary.length; index < assoLength; index++) {
                if (ary[index][prop] != null && ary[index][prop] != "" && ary[index][prop] == clauseCode) {
                    val = index;
                    break;
                }
            }
        }
        if (val != undefined)
            this.clausesComp.removeClause(val, clauseCode);
    }

    getTotalByProperty(prop, ary) {
        let total = numeral(0);
        for (let eachItem of ary) {
            if (eachItem[prop] != null && eachItem[prop] != "")
                total = total.add(numeral().unformat(eachItem[prop]));
        }
        total = numeral(total).format('0.00');
        return total;
    }

    addAdditionalCoverage(listOfAdditionalCoverage, prms) {
        for (let eachCover of listOfAdditionalCoverage) {
            let adcover = new AdditionalCoverage();
            adcover.additionalCode = eachCover.old.DESCPF.VALUE;
            adcover.additionalCover = eachCover.old.DESCPF.LONGDESC;
            prms.comp.riskObj.additionalCoverDetails.additionalCover.push(adcover);

            prms.comp.setClauses([eachCover.old.DESCPF.VALUE], false);
        }

        prms.comp.setTotalPremium();
    }

    getAdditionalPremiumTotal() {
        let total = this.getTotalByProperty("addditionalPremium", this.riskObj.additionalCoverDetails.additionalCover);
        this.riskObj.addditionalPremium = total;

        return total;
    }

    setAdditionalPremiumForEach(coverage) {
        let _rate: any = (coverage.additionalLoading == null || coverage.additionalLoading == "") ? 0 : parseFloat("" + coverage.additionalLoading);
        //let rate = (coverage.additionalLoading == null || coverage.additionalLoading == "") ? 0: coverage.additionalLoading;
        //coverage.addditionalPremium = (numeral().unformat(this.riskObj.basicPremium)*(numeral().unformat(rate) * 0.01));
        //coverage.addditionalPremium = numeral(coverage.addditionalPremium).format('0.00');
        if (_rate > 0) {
            let _addPremium = numeral().unformat(this.riskObj.basicPremium) * _rate * 0.01;
            coverage.addditionalPremium = numeral(_addPremium).format('0.00');
        }
        else {
            coverage.addditionalPremium = 0;
        }
    }

    resetAdditionalPremiumForEach() {
        for (let adCover of this.riskObj.additionalCoverDetails.additionalCover) {
            this.setAdditionalPremiumForEach(adCover);
        }
        this.getAdditionalPremiumTotal();
        this.setLoadAndPremium();
        this.setTotalPremium();
    }

    removeAdditionalCover(idx: number) {
        let addnlCover = this.riskObj.additionalCoverDetails.additionalCover[idx];
        this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Deleted Benefit Successfully : " + addnlCover.additionalCode, 5000));
        this.riskObj.additionalCoverDetails.additionalCover.splice(idx, 1);
        //this.deleteClause(this.riskObj.clauses.clause, addnlCover.additionalCode, "clauseCode");
        // this.resetAdditionalPremiumForEach();

        this.setTotalPremium();
    }

    setRIMethod(val) {

        this.riskObj.RIMethod = (val == "Yes") ? "8" : this.riskObj.RIMethodSys;

        if (this.isUnderWriter == "Y" || val == "Yes")
            this.riskObj.isRIOverWrittenByUW = "Y";
        else if (val == "No") {
            this.riskObj.isRIOverWrittenByUW = "N";
            this.validateCapitalSumInsured();
        }
        this._riService.setRI().subscribe();
    }

    validateCapitalSumInsured() {
        if (this.riskObj.RIRetentionCode && this.riskObj.isRIOverWrittenByUW == 'N') {
            this._bmsUtilService.getTotalGrossCapacity(this.riskObj.RIRetentionCode).subscribe((data) => this.compareSIWithTotGrossCap(data));
        }
        else
            this.setRIMethodEditableFlag();
    }

    compareSIWithTotGrossCap(totGrossCap) {

        let _totalGrossCapacity = (!totGrossCap) ? 0 : parseFloat("" + totGrossCap);
        this.riskObj.totalGrossCapacity = _totalGrossCapacity;
        let _capitalSumInsured = parseFloat("" + this.riskObj.capitalSumInsured);

        if (_totalGrossCapacity > 0 && _capitalSumInsured > _totalGrossCapacity && (this.riskObj.RIMethod == null || this.riskObj.RIMethod == "" || parseFloat("" + this.riskObj.RIMethod) != 8)) {
            this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Capital Sum Insured greater than Total Gross Capacity: " + _totalGrossCapacity + ",  RI is Required.", 10000));

            this.riskObj.RIRequired = "Yes";
            this.riskObj.RIMethod = "8";
        }
        else if (_capitalSumInsured <= _totalGrossCapacity) {
            this.riskObj.RIRequired = "No";
            this.riskObj.RIMethod = this.riskObj.RIMethodSys;
        }
        this._riService.setRI().subscribe();
        this.setRIMethodEditableFlag();
    }

    setRIMethodEditableFlag() {
        let _capitalSumInsured = parseFloat("" + this.riskObj.capitalSumInsured);
        let _totalGrossCapacity = parseFloat("" + this.riskObj.totalGrossCapacity);
        if (_totalGrossCapacity > 0 && _capitalSumInsured > _totalGrossCapacity && this.isUnderWriter == "N") {
            this.isRIMethodEditable = "N";
        }
        else {
            this.isRIMethodEditable = "Y";
        }
    }

    checkReferredRiskConditions() {

        let _ageLimitRec = this.lovDropDownService.lovDataList.referralAgeLimits.find((_data) => _data.DESCITEM == this.riskObj.riskType);

        let _reasons = new Reasons();
        let isReferredRisk = false;
        let isDeclinedRisk = false;

        if (this.riskObj.hasClaimExperience == 'Y') {
            isReferredRisk = true;
            //_reasons.reason.push("With Claim Experience.");
            // //this.addReferralReason('11', true);
        }
        else {
            // //this.deleteReferralReason('11', true);
        }

        this.calculateInsuredAge();

        this.riskObj.ageLimitFlag = "";
        if (_ageLimitRec && this.riskObj.dateOfBirth) {
            let _minAgeLimit = 0;
            let _maxAgeLimit = 0;
            let _minAgeLimitInd = 'Y';
            let _maxAgeLimitInd = 'Y';

            let _adultMinAgeLimit = (_ageLimitRec.ZAGELMT03) ? parseInt("" + _ageLimitRec.ZAGELMT03) : 0;
            let _adultMaxAgeLimit = (_ageLimitRec.ZAGELMT05) ? parseInt("" + _ageLimitRec.ZAGELMT05) : 0;

            let _chidldMinAgeLimit = (_ageLimitRec.ZAGELMT04) ? parseInt("" + _ageLimitRec.ZAGELMT04) : 0;
            let _chidldMaxAgeLimit = (_ageLimitRec.ZAGELMT06) ? parseInt("" + _ageLimitRec.ZAGELMT06) : 0;


            if (_chidldMinAgeLimit > 0 && _chidldMaxAgeLimit > 0 && this.riskObj.occupationCode && (this.riskObj.occupationCode == '7STU' || this.riskObj.occupationCode == '7CLD')) {
                _minAgeLimit = _chidldMinAgeLimit;
                _maxAgeLimit = _chidldMaxAgeLimit;
                _minAgeLimitInd = (_ageLimitRec.ZAGEIND02) ? _ageLimitRec.ZAGEIND02 : "Y";
                _maxAgeLimitInd = (_ageLimitRec.ZAGEIND03) ? _ageLimitRec.ZAGEIND03 : "Y";
            }
            else {

                _minAgeLimit = _adultMinAgeLimit;
                _maxAgeLimit = _adultMaxAgeLimit;
                if (_chidldMinAgeLimit == 0 || _chidldMaxAgeLimit == 0) {
                    _minAgeLimitInd = (_ageLimitRec.ZAGEIND02) ? _ageLimitRec.ZAGEIND02 : "Y";
                    _maxAgeLimitInd = (_ageLimitRec.ZAGEIND03) ? _ageLimitRec.ZAGEIND03 : "Y";
                }
            }

            if (_maxAgeLimitInd == 'D') {
                if (this.headerInfo.effectiveDate && this.riskObj.dateOfBirth) {
                    let _effectiveDate = moment(this.headerInfo.effectiveDate, "YYYY-MM-DD");
                    let _insuredDOB = moment(this.riskObj.dateOfBirth, "YYYY-MM-DD");

                    let _ageInDays = moment.duration(_effectiveDate.diff(_insuredDOB)).asDays();
                    if (_ageInDays > _maxAgeLimit) {
                        this.riskObj.ageLimitFlag = "G";
                    }
                }
            }
            else if (Number(this.riskObj.insuredAge) > _maxAgeLimit) {
                this.riskObj.ageLimitFlag = "G";
            }

            if (this.riskObj.ageLimitFlag != "G") {
                if (_minAgeLimitInd == 'D') {
                    if (this.headerInfo.effectiveDate && this.riskObj.dateOfBirth) {
                        let _effectiveDate = moment(this.headerInfo.effectiveDate, "YYYY-MM-DD");
                        let _insuredDOB = moment(this.riskObj.dateOfBirth, "YYYY-MM-DD");

                        let _ageInDays = moment.duration(_effectiveDate.diff(_insuredDOB)).asDays();
                        if (_ageInDays < _minAgeLimit) {
                            this.riskObj.ageLimitFlag = "L";
                        }
                    }
                }
                else if (Number(this.riskObj.insuredAge) < _minAgeLimit) {
                    this.riskObj.ageLimitFlag = "L";
                }
            }

            if (this.riskObj.ageLimitFlag == "G") {
                isReferredRisk = true;
                // //_reasons.reason.push("Insured Age greater than maximum allowed age "+_maxAgeLimit);
                //_reasons.reason.push("Referred due to Age");
                // //this.addReferralReason('01', true);
            }
            else if (this.riskObj.ageLimitFlag == "L") {
                isReferredRisk = true;
                // //_reasons.reason.push("Insured Age Less than minimum allowed age "+_minAgeLimit);
                //_reasons.reason.push("Referred due to Age");
                // //this.addReferralReason('01', true);
            }
            else if (this.riskObj.ageLimitFlag == "") {
                this.riskObj.ageLimitFlag = "VALID";
            }
        }

		/*if( this.riskObj.ageLimitFlag != 'G' ){
			this.deleteReferralReason('01', true);
		}*/

        if (this.riskObj.occupationCode) {
            let _rec = this.lovDropDownService.lovDataList.Occupation.find((_data) => _data.VALUE == this.riskObj.occupationCode);

            if (_rec && _rec.REFERREDRISK && _rec.REFERREDRISK == 'Y') {
                isReferredRisk = true;
                this.riskObj.occRiskClassification = "Referred";
                //_reasons.reason.push("Referred due to Occupation");
                // this.addReferralReason('05', true);
            }
            else if (_rec && _rec.REFERREDRISK && _rec.REFERREDRISK == 'D') {
                isDeclinedRisk = true;
                this.riskObj.occRiskClassification = "Declined";
                //_reasons.reason.push("Declined due to Occupation");
            }
            else {
                this.riskObj.occRiskClassification = "Standard";
            }

			/*if(this.riskObj.occRiskClassification != 'Referred'){
				this.deleteReferralReason('05', true);
			}*/
        }

        //if(this.riskObj.referralReasons.referralReason && this.riskObj.referralReasons.referralReason.length >0 && this.riskObj.referralReasons.referralReason.find((_data1)=> _data1.isSysReferred!='Y') ){
        //	isReferredRisk = true;				
        //	_reasons.reason.push("Referral Reason added");
        //}

		/*
		this.riskObj.riskClassificationReasons.reasons = _reasons;
		
		if(isDeclinedRisk == true){
			this.riskObj.symRiskClassification = "Declined";		
		}
		else if(isReferredRisk == true){
			this.riskObj.symRiskClassification = "Referred";
		}
		else this.riskObj.symRiskClassification = "Standard";
		// this.setRoutingSI();		
		this.handleRiskClassification();
		*/
        this.riskClassificationService.setRiskClassification(this.riskObj.riskNumber, "N", "", "").subscribe();
    }

    onClaimExpChange() {
        this.checkReferredRiskConditions();
    }

    handleRiskClassification() {
        if (this.riskObj.symRiskClassification == "Declined")
            this.riskObj.riskClassification = "Declined";
        else if (this.riskObj.symRiskClassification == "Referred" || this.riskObj.riRiskClassification == "Referred")
            this.riskObj.riskClassification = "Referred";
        else
            this.riskObj.riskClassification = "Standard";

        this.setRoutingSI();
        this.setRiskClassification(this);
    }

    calculateInsuredAge() {
        if (this.riskObj && this.headerInfo.effectiveDate && this.riskObj.dateOfBirth) {
            let _effectiveDate = moment(this.headerInfo.effectiveDate, "YYYY-MM-DD");
            let _insuredDOB = moment(this.riskObj.dateOfBirth, "YYYY-MM-DD");

            let dobYear = _insuredDOB.year();
            let effDtYear = _effectiveDate.year();
            let age = effDtYear - dobYear;

            this.riskObj.insuredAge = age;
        }
        else {
            this.riskObj.insuredAge = 0;
        }
    }

    addReferralReason(refCode, isSysRef) {

        if (!refCode) {
            refCode = jQuery("#referralReason").val();
        }

        if (!isSysRef && this.lovDropDownService.lovDataList.referralReasons && this.lovDropDownService.lovDataList.referralReasons.length > 0 && this.riskObj.referralReasons.referralReason.find((_data1) => _data1.code == refCode)) {
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Referral Reason is added already.", 3000));
        }
        else {
            let refReasonRecord = this.lovDropDownService.lovDataList.referralReasons.find(_data => (_data.code === refCode));

            if (refReasonRecord) {
                if (this.riskObj.referralReasons.referralReason && (this.riskObj.referralReasons.referralReason.length == 0 || !this.riskObj.referralReasons.referralReason.find((_data1) => _data1.code == refCode))) {
                    let _referralReason = new ReferralReason();
                    _referralReason.seqNumber = this.riskObj.referralReasons.referralReason.length + 1;
                    _referralReason.code = refReasonRecord.code;
                    _referralReason.description = refReasonRecord.description;
                    _referralReason.isSysReferred = (isSysRef) ? 'Y' : 'N';

                    this.riskObj.referralReasons.referralReason.push(_referralReason);
                }
                else if (this.riskObj.referralReasons.referralReason && this.riskObj.referralReasons.referralReason.find((_data1) => _data1.code == refCode)) {
                    let _refReason = this.riskObj.referralReasons.referralReason.find((_data1) => _data1.code == refCode);
                    _refReason.isSysReferred = (isSysRef) ? 'Y' : 'N';
                }
            }
        }

        if (!isSysRef && this.riskObj.referralReasons.referralReason.length == 1) {
            this.checkReferredRiskConditions();
        }

        jQuery("#referralReason").val('');
    }

    formatPremiumAmount(_amount) {
        let _numStr = "" + _amount;
        if (_numStr.indexOf('.') != -1) {
            let _numStrArr = _numStr.split('.');
            if (_numStrArr[1].length > 2) {
                _numStr = _numStrArr[0] + "." + _numStrArr[1].slice(0, 2);
            }
        }
        return parseFloat("" + _numStr);
    }
}
