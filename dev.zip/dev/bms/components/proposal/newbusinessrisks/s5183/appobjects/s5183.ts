import { Clause } from '../../appobjects/clause';
import { DeclarationDetails } from '../../appobjects/declarationDetails';
import { GSTDetails } from '../../appobjects/gstDetails';
import { AppUtil } from '../../../../../../common/components/utility/apputil/app.util';
import { FireRelatedCases } from '../../appobjects/relatedCase';
import { Nominee, NomineeDetails } from "../../appobjects/nomineeslist";
import { NBRisk } from '../../../appobjects/nbrisk';
import { PostedPrem } from '../../../proposalheader/appobjects/postedprem';
import { RiskHelper } from '../../../appobjects/riskhelper';
import { ReferredReason } from '../../../proposalheader/appobjects/referredreason';
import { ReferralReasons } from '../../appobjects/referralReasons';
import { S5183Validator } from '../../../validation/s5183.validator';

export class S5183 extends RiskHelper implements NBRisk {

    public sequenceNumber: string;
    public effectiveDate: string;
    public dateOfAttachment: string;
    public contractNumber: string;
    public contractType: string;
    public riskNumber: string;
    public riskType: string;
    public riskName: string;
    public ratingFlag: string = "A";
    public benefitCode: string = "";
    public benefitDescription: string = "";
    public RIRetentionCode: string;
    public hasClaimExperience: string = "N";
    /****
     *      Policy Holder Details
     ***/
    public insuredName: string = "";
    public occupationCode: string = "";
    public occupationDescription: string = "";
    public insuredAge: number = 0;
    public dateOfBirth: string = "";
    /**** Risk Classification related Fields****/
    public symRiskClassification: string = "";
    public riskClassificationReason: string = "";
    public occRiskClassification: string = "";

    public riskClassification: string = "Standard";
    public riRiskClassification: string = "Standard";

    public planBenefits: Benefit;
    public plan: string;
    /**** Nonimee Details ***/
    public nomineeDetails: NomineeDetails;

    public renewalBonusAmount: number = 0;
    public renewalBonusPercentage: number = 0;
    public loadingPercentage: number = 0;
    public loadingAmount: number = 0;
    public discountPercentage: number = 0;
    public discountAmount: number = 0;

    public additionalCoverDetails: AdditionalCoverageDetails;
    public additionalCode: string;
    public additionalLoading: string;
    public addditionalPremium: number = 0;
    public discountedPremium: number = 0;
    public rebate: number = 0;
    public rebateAmount: number = 0;
    public GST: number = 0;
    public gstAmount: number = 0;
    public basicPremium: number = 0;
    public totalBasicPremium: number = 0;
    public originalTotalPremium: number = 0;
    //for minimum premium calculations
    public basePostedPremiumAdj: number = 0;
    public isPOIConsidered: string = "N";
    public priority: string;
    public accumulationRegister: string;

    public relatedCases: FireRelatedCases;
    public capitalSumInsured: number = 0;
    public bigCapitalSumInsured: number = 0;
    public totalGrossCapacity: number = 0;
    public grossPremium: number = 0;
    public ncdPercentage: number = 0;
    public ncdAmount: number = 0;
    public totalPremium: number = 0;
    public totalAnnualPremium: number = 0;
    public postingPremium: number = 0;
    public clauses: Clause;
    public terminationDate: string;
    //public financialInterest: FinancialInterest;
    public GSTDetails: GSTDetails;

    public GT: string;
    public GP: string;
    public FI: string = 'Y';
    public DS: string;
    public CL: string;
    public MI: string;
    public addRelatedCases: string = "N";
    public defaultClauses: Clause;

    public relatedSumInsured: number = 0;

    public postedPremium: number = 0;
    public minimumPremium: number = 0;

    public totalSI: number = 0;
    public identity: string = "";
    public identityFiller: string = "";

    //public isSurveyNeeded:string="N";
    public isLeastPreferred: string = "N";
    public ratingClass: string = "";
    public premiumClass: string = "";
    //public survey:Survey;

    public RIRequired: string = "No";
    public RIMethod: string = "1";
    public RIMethodSys: string = "0";
    public isRIOverWrittenByUW: string = "N";
    public postedPremDetails: PostedPrem;

    public childRiskPath: string;
    public childRiskIdentity: string = "";
    public ageLimitFlag: string = "";
    public riskClassificationReasons: ReferredReason;
    public referralReasons: ReferralReasons;
    public gpText: string;
    public gpTextCount:string;//VK004

    public SST: number = 0; //SST Code
    public sstAmount: number = 0;//SST Code
    public SSTLiveDate: string;//SST Code
    public GSTLiveDate: string;//SST Code
    public isGSTApplicable: boolean = true;//SST Code
    constructor() {
        super();
        this.planBenefits = new Benefit();
        this.additionalCoverDetails = new AdditionalCoverageDetails();
        this.clauses = new Clause();
        this.GSTDetails = new GSTDetails();
        this.relatedCases = new FireRelatedCases();
        this.nomineeDetails = new NomineeDetails();
        this.riskClassificationReasons = new ReferredReason();
        this.referralReasons = new ReferralReasons();
    }

    public getInstance(valObj: S5183) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
            this.planBenefits = new Benefit().getInstance(valObj.planBenefits);
            this.clauses = new Clause().getInstance(valObj.clauses);
            this.additionalCoverDetails = new AdditionalCoverageDetails().getInstance(valObj.additionalCoverDetails);
            this.nomineeDetails = new NomineeDetails().getInstance(valObj.nomineeDetails);
            this.GSTDetails = new GSTDetails().getInstance(valObj.GSTDetails);
            if (valObj.addRelatedCases == "Y") {
                this.relatedCases = new FireRelatedCases().getInstance(valObj.relatedCases);
            }
            this.riskClassificationReasons = new ReferredReason().getInstance(valObj.riskClassificationReasons);
            this.referralReasons = new ReferralReasons().getInstance(valObj.referralReasons);
            if (valObj.isGSTApplicable != undefined && JSON.stringify(valObj.isGSTApplicable) != JSON.stringify("") && typeof (valObj.isGSTApplicable) == "string") {
                this.isGSTApplicable = Boolean(JSON.parse(valObj.isGSTApplicable));
            }
        }
        return this;
    }

    public getNewInstanceByCriteria(criteria: any) {
        let riskType = criteria.riskType;
        this.RIRetentionCode = "PA01";
        this.premiumClass = "83";
        // this.ratingClass="01";

        return this;
    }

    public getValidator() {
        return new S5183Validator(this);
    }
}
export class Benefit {
    public benefit: BenefitItem[] = [];

    public getInstance(valObj: Benefit) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().handleArray(this, valObj, "benefit");
        }
        return this;
    }
}

export class BenefitItem {
    public seqNumber: number;
    public coverageCode: string;
    public coverageDescription: string;
    public extraText: string = "";
    public etPostingStatus: string = "N";
    public planA: number = 0;
    public planB: number = 0;
    public planC: number = 0;
    public planD: number = 0;
    public planE: number = 0;
    public rate: number = 0.00;
}

export class AdditionalCoverageDetails {

    public additionalCover: AdditionalCoverage[] = [];
    public additionalCoverTotal: number = 0;

    public getInstance(valObj: AdditionalCoverageDetails) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
            new AppUtil().handleArray(this, valObj, "additionalCover");
        }
        return this;
    }
}

export class AdditionalCoverage {

    public additionalCode: string;
    public additionalCover: string;
    public sumInsured: string;
    public rate: string = "0.00";
    public additionalLoading: number = 0;
    public addditionalPremium: number = 0;
    constructor() { }
}

