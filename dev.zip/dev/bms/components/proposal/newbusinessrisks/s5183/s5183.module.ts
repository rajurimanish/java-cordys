import { NgModule } from '@angular/core';
import { PaginationModule } from '../../../../../common/components/utility/pagination/pagination.module';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BasicUIModule } from '../../../../../common/components/utility/basicui.module';
import { LovModule } from "../../../../../common/services/lovdropdown/lov.module";
import { ClausesModule } from "../uimodules/clauses.module";
import { GSTModule } from '../uimodules/gst.module';
import { InsuredModule } from '../uimodules/insured.module';
import { RelatedCaseModule } from '../uimodules/relatedcase.module';
import { NomineeModule } from "../uimodules/nominee.module";
import { GeneralPageModule } from '../uimodules/generalpage.module'; //VK004
import { S5183Component } from './s5183.component';

@NgModule({
    imports: [ CommonModule, FormsModule, ReactiveFormsModule, BasicUIModule, LovModule, ClausesModule, GSTModule,InsuredModule,RelatedCaseModule,NomineeModule,PaginationModule,  GeneralPageModule],
    declarations: [S5183Component],
    exports: [S5183Component]
})
export class S5183Module { }