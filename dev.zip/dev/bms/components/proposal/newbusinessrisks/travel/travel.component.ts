/*
 * Change History:
 * 
 * No      Date          Description                                              Changed By
 * ====    ==========    ===========                                              ==========
 * KA0001  14/03/2018    MYS-2018-0026 : Changed the logic
 *                       in onGroupChange function                                    DKA
 * GA001   15/03/2018  	 MYS-2018-0266 : Enhancement on
 *					     Travelright Plus (TAA & TDA)	               		 	      KGA
 * GA002   09/07/2018    MYS-2018-0443 - Age Checking for PA Products (T7253)    	  KGA	
 * GA003   12/04/2019    MYS-2018-1352 - TAA – Update Group Validation Checking       KGA	
 * YPK001 23/09/2019     MYS-2019-0675 Document Validation for Co-outwards            PKU1
 *                         case before sending to PPHO			   
*/

import { Component, OnInit, ViewChild, ElementRef, EventEmitter, AfterViewInit, ViewContainerRef } from '@angular/core';
declare var Observer: any;
import { DCLInput, CustomDCLService } from "../../../../../common/services/customdcl.service";
import { LOV_Field, LOVDropDownService, SearchFilter } from "../../../../../common/services/lovdropdown/lovdropdown.service";
import { SearchInput } from "../../../../../common/components/utility/search/genericsearch";
import { ModalInput } from "../../../../../common/components/utility/modal/modal";
import { CordysSoapWService } from "../../../../../common/components/utility/cordys-soap-ws";
import { GetLOVData, SearchAdvancedConfig, Filter } from "../../../../../common/components/utility/search/search.requests";
import { ProposalHeader } from "../../proposalheader/appobjects/proposalheader";
import { AlertMessagesService } from "../../../../../common/components/utility/alertmessage/alertmessages.service";
import { AlertMessage } from "../../../../../common/components/utility/alertmessage/alertmessages.model";
import { FireRelatedCases, RelatedCases } from "../appobjects/relatedCase";
import { NomineeDetails } from "../appobjects/nomineeslist";
import { Insured, InsuredDetails } from "../appobjects/insuredlist";
import { Travel, Benefit, AdditionalCoverage } from "./appobjects/travel";
import { ClientDetails } from "../../../../../common/components/client/appobjects/client";
import { Clause } from "../appobjects/clause";
import { ClausesComponent } from "../uimodules/clauses.component";
import { PaginationModule } from '../../../../../common/components/utility/pagination/pagination.module';
import { PaginationPipe } from '../../../../../common/components/utility/pagination/filtertable.pipe';
import { FilterTableContentPipe } from '../../../../../common/components/utility/pagination/filtercontent.pipe';
import { ApplicationUtilService } from "../../../../../common/services/application.util.service";
import { BMSConstants } from '../../../common/constants/bms_constants';
import { BMSUtilService } from "../../../../services/bms.util.service";
import { RIService } from '../services/ri.service';
import { RiskClassificationService } from "../services/riskcls.service";
import { ActivatedRoute } from '@angular/router';
import { ReferralReasons, ReferralReason } from '../appobjects/referralReasons';//GA002
import { ReferredReason, Reasons } from '../../proposalheader/appobjects/referredreason';//GA002

declare var jQuery: any;
declare var moment: any;
declare var numeral: any;

@Component({
    selector: "travel-component",
    templateUrl: "app/bms/components/proposal/newbusinessrisks/travel/travel.template.html",
    inputs: ["riskObj", "clientDetails", "headerInfo"],
    outputs: ["onPremiumChange", "onRiskClsChange", "onRtngFlgChange"]
})

export class TravelComponent implements OnInit {
    private el: HTMLElement;
    private clCBIInfoCollapse: boolean = true;
    private isNomineeInfoCollapsed: boolean = false;
    private isInsuredInfoCollapsed: boolean = true;
    // private relatedCollapse:boolean = false;
    public riskObj: Travel;
    public headerInfo: ProposalHeader;
    public clientDetails: ClientDetails;
    private plans = [];
    private planBenefits = [];

    public siFormat: string = "0,00";
    public premiumFormat: string = "0,00.00";
    public rateFormat: string = "0.00000";
    public percentFormat: string = "0.00";

    public position = 1;
    public sizeObj = { length: 0, orglength: 0 };
    public contentSizeObs: any;
    public itemPerPage = 7;
    public maxPageCount = 10;
    private travelFrmDateCtrl: any;
    private travelToDateCtrl: any;
    private capitalSICtrl: any;
    private basicPrmCtrl: any;
    private disableNoOfAdults: string = 'N';
    private disableNoOfChildren: string = 'N';
    private disableTravelDate: string = 'N';
    private disableRateField: string = 'Y';
    private adultsNotAllowed: string = 'N';
    private childrenNotAllowed: string = 'N';
    private isUnderWriter = "N";
    private isRIMethodEditable = "Y";

    onPremiumChange = new EventEmitter<any>();
    onRiskClsChange = new EventEmitter<any>();
    onRtngFlgChange = new EventEmitter<any>();
    private isGeneralPageCollapsed: boolean = false;
    private referralReasons = [];//GA002

    @ViewChild(ClausesComponent) private clausesComp: ClausesComponent;
    @ViewChild('travelCompModal', { read: ViewContainerRef }) contentArea: ViewContainerRef;

    constructor(private lovDropDownService: LOVDropDownService, private _soapService: CordysSoapWService, public _alertMsgService: AlertMessagesService, el: ElementRef, public dcl: CustomDCLService, private _appUtilService: ApplicationUtilService, private _bmsUtilService: BMSUtilService, private _riService: RIService, public riskClassificationService: RiskClassificationService, private _activatedRoute: ActivatedRoute) {
        this.el = el.nativeElement;
    }

    ngOnInit() {
        this.populateLOVs();
        this.initializeChildComp();
        this._appUtilService.isUnderWriterUser().subscribe((data) => {
            this.isUnderWriter = data;
            this.setRIMethodEditableFlag();
        });
        //SST Code
        if (["MyTasks", "MyDrafts"].indexOf(this._activatedRoute.snapshot.params['component']) >= 0 || Object.keys(this._activatedRoute.snapshot.params).length == 0) {
            let respObj = this._bmsUtilService.getTAXDetails();
            if (respObj != undefined && respObj != "") {
                this.headerInfo.SSTTaxRate = respObj[0].old.ITEMPF.GST;
                this.headerInfo.GSTTaxRate = respObj[1].old.ITEMPF.GST;

                this.riskObj.SST = Number(this.headerInfo.SSTTaxRate);
                this.riskObj.GST = Number(this.headerInfo.GSTTaxRate);
            }

            this.headerInfo = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo;
            this.riskObj.SSTLiveDate = (this.riskObj.SSTLiveDate == undefined) ? this.headerInfo.SSTLiveDate : this.riskObj.SSTLiveDate;
            if (this.riskObj.SSTLiveDate == undefined || this.riskObj.SSTLiveDate == "") {
                let tempRespObj = this._bmsUtilService.getLiveDate();
                this.riskObj.GSTLiveDate = tempRespObj[0].old.ITEMPF.LIVEDATE;
                this.riskObj.SSTLiveDate = tempRespObj[1].old.ITEMPF.LIVEDATE;
                if (this.headerInfo.SSTLiveDate == undefined || this.headerInfo.SSTLiveDate == "") {
                    this.headerInfo.SSTLiveDate = this.riskObj.SSTLiveDate;
                }
                if (this.headerInfo.GSTLiveDate == undefined || this.headerInfo.GSTLiveDate == "") {
                    this.headerInfo.GSTLiveDate = this.riskObj.GSTLiveDate;
                }
            }
            if (moment(this.headerInfo.effectiveDate, "YYYY-MM-DD").format("YYYYMMDD") >= moment(this.riskObj.SSTLiveDate, "YYYY-MM-DD").format("YYYYMMDD")) {
                this.riskObj.isGSTApplicable = false;
            } else {
                this.riskObj.isGSTApplicable = true;
            }

            if (this.riskObj.riskType == 'TAA' && this.riskObj.destinationArea != 'L') {
                this.riskObj.GST = 0;
                this.riskObj.SST = 0;
                this.headerInfo.SSTTaxRate = Number(this.riskObj.SST);
                this.headerInfo.GSTTaxRate = Number(this.riskObj.GST);
            }
        }
        //End
    }
    //START YPK001
    ngAfterViewInit() {
        let rIndex = 0;
        if ((this.headerInfo.CoInsurance == 'Y' && this.riskObj.riskNumber == '1') && (["MyTasks", "MyDrafts"].indexOf(this._activatedRoute.snapshot.params['component']) >= 0 || Object.keys(this._activatedRoute.snapshot.params).length == 0)) {
            if (this.headerInfo.coInsuranceDetails.coInsurance.length == 1) {
                if (!(this.headerInfo.coInsuranceDetails.coInsurance[0].coInsuranceindicator == 'L' && this.headerInfo.coInsuranceDetails.coInsurance[0].sharePercentage == '100')) {
                    rIndex = this.riskObj.clauses.clause.map(function (item) { return item.clauseCode; }).indexOf("COIN");
                    if (rIndex == -1)
                        this.setClauses(["COIN"], false);
                }
            }
            else {
                rIndex = this.riskObj.clauses.clause.map(function (item) { return item.clauseCode; }).indexOf("COIN");
                if (rIndex == -1)
                    this.setClauses(["COIN"], false);
            }
        }
    }
    //END YPK001
    populateLOVs() {
        this.lovDropDownService.createLOVDataList(["riCode", "coverageType", "destinationArea", "coverageRequired", "planDetails", "Gender", "validationsConfig", "travelPeriodValidations", "referralReasons", "referralAgeLimits"]);//GA002 ADDED ("referralReasons", "referralAgeLimits")
        let planFilterDetails = [new SearchFilter("DESCITEM", this.riskObj.plan, "STARTSWITH", "AND")];
        let planFilterNodes = this.lovDropDownService.createFilter(planFilterDetails);
        //GA002 START
        let riskFilter = (this.riskObj.riskType.length == 2) ? this.riskObj.riskType + ' ' : this.riskObj.riskType;
        let referralAgeLimitNodes = this.lovDropDownService.createFilter([new SearchFilter("DESCITEM", riskFilter, "EQ", "AND")]);
        //GA002 END
        //GA001 START - ADDED effectiveDate TO ITMFRM & ITMTO
        //let polEndDate = ApplicationUtilService.getFormattedDate(this.headerInfo.endDate,"YYYY-MM-DD","YYYYMMDD");
        let effectiveDate = ApplicationUtilService.getFormattedDate(this.headerInfo.effectiveDate, "YYYY-MM-DD", "YYYYMMDD");
        let planDetFilterDetails = [new SearchFilter("DESCITEM", this.riskObj.riskType, "STARTSWITH", "AND"),
        new SearchFilter("ITMFRM", effectiveDate, "LTEQ", "AND"),
        new SearchFilter("ITMTO", effectiveDate, "GTEQ", "AND")];
        //GA001 END
        let planDetFilterNodes = this.lovDropDownService.createFilter(planDetFilterDetails);

        let lovFields = [
            new LOV_Field("ALL", "PA", "NEW BUSINESS", "ALL", "NEW", "Travel", "Coverage Type", "LOV", planFilterNodes, "DESCPF", "coverageType", "callbackCoverageTypeDataLoad"),
            new LOV_Field("ALL", "PA", "NEW BUSINESS", "ALL", "NEW", "Travel", "Destination Area", "LOV", planFilterNodes, "DESCPF", "destinationArea", "callbackDestinationAreaDataLoad"),
            new LOV_Field("ALL", "PA", "NEW BUSINESS", "ALL", "NEW", "Travel", "Coverage Required", "LOV", planFilterNodes, "DESCPF", "coverageRequired", null),
            new LOV_Field("ALL", "PA", "NEW BUSINESS", "ALL", "NEW", "Travel", "Travel Plan Details", "LOV", planDetFilterNodes, "T7107", "planDetails", "callbackForPlanDataLoad"),
            new LOV_Field("ALL", "ALL", "CLAIMS", "ALL", "ALL", "ALL", "Gender", "LOV", [], "DESCPF", "Gender", null),
            new LOV_Field("ALL", "MED", "ALL", "ALL", "ALL", "ALL", "Referral Reasons", "LOV", [], "DESCPF", "referralReasons", "callbackForReferralReasons"),
            new LOV_Field("ALL", "MED", "ALL", "ALL", "ALL", "ALL", "Referral Age Limits", "LOV", referralAgeLimitNodes, "T7253", "referralAgeLimits", "callbackReferralAgeLimits")
        ];//GA002 ADDED ("referralReasons", "referralAgeLimits")
        this.lovDropDownService.util_populateLOV(lovFields, this);
        //new LOV_Field("ALL", "MOTOR", "NEW BUSINESS", "ALL", "NEW", "PRIVATE_MOTOR", "RI Retention Code", "LOV", [], "DESCPF", "riCode",null),		
        //new LOV_Field("ALL", "ALL", "NEW BUSINESS", "ALL", "NEW", "Travel", "Additional Coverage", "LOV", [], "DESCPF", "additionalCoverage",null)
        //new LOV_Field("ALL", "PA", "NEW BUSINESS", "ALL", "ALL", "Travel", "Travel Validations", "LOV", planDetFilterNodes, "T7302", "validationsConfig","callbackTravelValidationsConfig"),
    }

    resetPlanDependentFields(plan: string) {

        this.lovDropDownService.createLOVDataList(["coverageType", "destinationArea", "coverageRequired"]);
        let planFilterDetails = [new SearchFilter("DESCITEM", plan, "STARTSWITH", "AND")];
        let planFilterNodes = this.lovDropDownService.createFilter(planFilterDetails);
        let lovFields = [
            new LOV_Field("ALL", "PA", "NEW BUSINESS", "ALL", "NEW", "Travel", "Coverage Type", "LOV", planFilterNodes, "DESCPF", "coverageType", null),
            new LOV_Field("ALL", "PA", "NEW BUSINESS", "ALL", "NEW", "Travel", "Destination Area", "LOV", planFilterNodes, "DESCPF", "destinationArea", null),
            new LOV_Field("ALL", "PA", "NEW BUSINESS", "ALL", "NEW", "Travel", "Coverage Required", "LOV", planFilterNodes, "DESCPF", "coverageRequired", null)
        ];

        this.lovDropDownService.util_populateLOV(lovFields, this);
    }

    callbackForPlanDataLoad(scopeObject) {

        for (let planItem of scopeObject.lovDropDownService.lovDataList.planDetails) {
            let hasPlan = scopeObject.plans.some(plan => plan['PLANCODE'] === planItem.PLANCODE);
            if (!hasPlan) {
                scopeObject.plans.push(planItem);
            }
        }

        if (scopeObject.riskObj.plan && (!scopeObject.riskObj.benefitDetails || !scopeObject.riskObj.benefitDetails.benefit || scopeObject.riskObj.benefitDetails.benefit.length == 0)) {
            scopeObject.resetPremiumAmounts();
            scopeObject.populateBenfitDetails(scopeObject);
        }

        if (scopeObject.riskObj.isCustomizedPlan == 'Y' && scopeObject.riskObj.plan && (!scopeObject.riskObj.benefitDetails || !scopeObject.riskObj.benefitDetails.benefit || scopeObject.riskObj.benefitDetails.benefit.length > 0)) {

            let _planBenefits = scopeObject.lovDropDownService.lovDataList.planDetails.filter(plan => plan['PLANCODE'] === scopeObject.riskObj.plan);
            for (let _planBenefit of _planBenefits) {
                let hasBenefitAdded = scopeObject.riskObj.benefitDetails.benefit.some(_benefit => _benefit.coverageCode === _planBenefit.ZCVRCDE);
                if (!hasBenefitAdded)
                    scopeObject.planBenefits.push(_planBenefit);
            }
        }
    }

    callbackCoverageTypeDataLoad(scopeObject) {
        if (scopeObject.riskObj.coverageType != '' && !scopeObject.riskObj.coverageTypeDesc) {
            for (let coverageTypeItem of scopeObject.lovDropDownService.lovDataList.coverageType) {
                if (coverageTypeItem.VALUE == scopeObject.riskObj.coverageType)
                    scopeObject.riskObj.coverageTypeDesc = coverageTypeItem.DESCRIPTION;
            }
        }
    }

    callbackDestinationAreaDataLoad(scopeObject) {
        if (scopeObject.riskObj.destinationArea != '' && !scopeObject.riskObj.destinationAreaDesc) {
            for (let destinationAreaItem of scopeObject.lovDropDownService.lovDataList.coverageType) {
                if (destinationAreaItem.VALUE == scopeObject.riskObj.destinationArea)
                    scopeObject.riskObj.destinationAreaDesc = destinationAreaItem.DESCRIPTION;
            }
        }
    }

    addBenefit() {
        let _benefitCoverCode = jQuery("#benefitCoverCode").val();
        if (_benefitCoverCode) {
            let _addedPlanBenefit = this.lovDropDownService.lovDataList.planDetails.filter(plan => (plan['PLANCODE'] === this.riskObj.plan && plan['ZCVRCDE'] === _benefitCoverCode));
            if (_addedPlanBenefit && _addedPlanBenefit.length > 0) {
                let benefit = new Benefit();
                benefit.seqNumber = this.riskObj.benefitDetails.benefit.length + 1;
                benefit.coverageCode = _addedPlanBenefit[0].ZCVRCDE;
                benefit.scheduleOfBenefit = _addedPlanBenefit[0].ZCVRDESC;
                benefit.sumInsured = _addedPlanBenefit[0].ZCVRSUMIN;
                this.riskObj.benefitDetails.benefit.push(benefit);

                let selectedPlanBenefitItem = this.planBenefits.filter(item => item.ZCVRCDE == _benefitCoverCode);
                if (selectedPlanBenefitItem && selectedPlanBenefitItem.length > 0) {
                    this.planBenefits.splice(this.planBenefits.indexOf(selectedPlanBenefitItem[0]), 1);
                }
                jQuery("#benefitCoverCode").val('');
            }
        }
    }

    removeBenefit(benefitItem) {
        let _idx = this.riskObj.benefitDetails.benefit.indexOf(benefitItem);
        let _coverCode = benefitItem.coverageCode;
        this.riskObj.benefitDetails.benefit.splice(_idx, 1);
        this.resetItemNumber();

        let _deletedBenefit = this.lovDropDownService.lovDataList.planDetails.filter(plan => (plan['PLANCODE'] === this.riskObj.plan && plan['ZCVRCDE'] === _coverCode));
        if (_deletedBenefit && _deletedBenefit.length > 0)
            this.planBenefits.push(_deletedBenefit[0]);
    }

    resetItemNumber() {
        for (let _benefitItem of this.riskObj.benefitDetails.benefit) {
            let index = this.riskObj.benefitDetails.benefit.indexOf(_benefitItem);
            _benefitItem.seqNumber = (index + 1);
        }
    }

    openAdditionalCoverageDetailsDialog() {
        let searchInput = new SearchInput();
        searchInput.isSingleSelect = false;
        searchInput.BRANCH = 'ALL';
        searchInput.BUSINESS_FUNCTION = 'NEW BUSINESS';
        searchInput.FIELD_TYPE = 'LOOKUP';
        searchInput.FORM_FIELD_NAME = 'Additional Coverage';
        searchInput.FORM_NAME = 'ALL';
        searchInput.LOB = 'ALL';
        searchInput.OPERATION = 'NEW';
        searchInput.PRODUCT = 'ALL';

        if (this.riskObj.additionalCoverDetails.additionalCover.length > 0) {
            let newArr = [];
            for (let item of this.riskObj.additionalCoverDetails.additionalCover) {
                newArr = newArr.concat(item["additionalCode"]);
            }
            let additionalCoverCodes = "'" + newArr.toString().replace(/,/g, "\',\'") + "'";
            searchInput.condition = { "A.DESCITEM": additionalCoverCodes };
        }
        else
            searchInput.condition = { "A.DESCITEM": "''" };

        let input = new ModalInput().get("GenericSearchComponent");
        input.datainput = searchInput;
        input.outputCallback = this.addAdditionalCoverage;
        input.containerRef = this.contentArea;
        input.parentCompPRMS = { comp: this };
        input.heading = "Additional Cover Details";
        input.icon = "fa fa-file-pdf-o";
        this.dcl.openLookup(input);
    }

    addAdditionalCoverage(listOfAdditionalCoverage, prms) {
        for (let eachCover of listOfAdditionalCoverage) {
            let adcover = new AdditionalCoverage();
            adcover.addlCoverCode = eachCover.old.DESCPF.VALUE;
            adcover.addlCoverCodeDesc = eachCover.old.DESCPF.LONGDESC;
            prms.comp.riskObj.additionalCoverDetails.additionalCover.push(adcover);
            prms.comp.setClauses([eachCover.old.DESCPF.VALUE], false);
        }
    }

    setAdditionalPremiumForEach(coverage) {
        let load = (coverage.addlCoverLoad == null || coverage.addlCoverLoad == "") ? 0 : coverage.addlCoverLoad;
        let _addlCoverPremium = (numeral().unformat(this.riskObj.basicPremium) * (numeral().unformat(load) * 0.01));
        coverage.addlCoverPremium = numeral(_addlCoverPremium).format('0.00');
        this.setBasicPremium(false);
    }

    removeAdditionalCover(idx: number) {
        let addnlCover = this.riskObj.additionalCoverDetails.additionalCover[idx];
        // this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Deleted Benefit Successfully : " + addnlCover.addlCoverCode, 3000));
        this.riskObj.additionalCoverDetails.additionalCover.splice(idx, 1);
        this.deleteClause(this.riskObj.clauses.clause, addnlCover.addlCoverCode, "clauseCode");
        this.setBasicPremium(false);
    }

    deleteClause(ary, clauseCode, prop) {
        let val = undefined;
        if (ary.length > 0) {
            for (var index = 0, assoLength = ary.length; index < assoLength; index++) {
                if (ary[index][prop] != null && ary[index][prop] != "" && ary[index][prop] == clauseCode) {
                    val = index;
                    break;
                }
            }
        }
        if (val != undefined)
            this.clausesComp.removeClause(val, clauseCode);
    }

    setClauses(clausesList, flag) {
        if (this.clausesComp)
            this.clausesComp.addClause(clausesList, '', flag);
    }

    initializeChildComp() {
        if (!this.riskObj.nomineeDetails)
            this.riskObj.nomineeDetails = new NomineeDetails();

        if (!this.riskObj.insuredDetails) {
            this.riskObj.insuredDetails = new InsuredDetails();
            this.defaultInsuredDetails();
        } else if (this.riskObj.insuredDetails.insured.length == 0) {
            this.defaultInsuredDetails();
        }

        if (this.riskObj.clauses != null && this.riskObj.clauses.clause != null && !Array.prototype.isPrototypeOf(this.riskObj.clauses.clause)) {
            let temp: any = this.riskObj.clauses.clause;
            this.riskObj.clauses.clause = [temp];
        }
        else if (this.riskObj.clauses == null || this.riskObj.clauses.clause == null) {
            this.riskObj.clauses = new Clause();
        }

		/*if(this.riskObj.relatedCases == null || (this.riskObj.relatedCases != null && typeof(this.riskObj.relatedCases) === "string")){
			this.riskObj.relatedCases = new FireRelatedCases();
		}
		else if(this.riskObj.relatedCases != null && this.riskObj.relatedCases.relatedCases != null && typeof(this.riskObj.relatedCases.relatedCases) === "string"){
			this.riskObj.relatedCases.relatedCases = new RelatedCases();
		}
		else if(this.riskObj.relatedCases.relatedCases != null && this.riskObj.relatedCases.relatedCases.relatedCase != null && !Array.prototype.isPrototypeOf(this.riskObj.relatedCases.relatedCases.relatedCase)){
			let tempAry:any = this.riskObj.relatedCases.relatedCases.relatedCase;
			this.riskObj.relatedCases.relatedCases.relatedCase = [tempAry];
		}
		else if(this.riskObj.relatedCases.relatedCases.relatedCase == null){
			this.riskObj.relatedCases.relatedCases.relatedCase = [];
		}*/

        this.onGroupChange(this.riskObj.groupInd, true);

        if (this.riskObj.riskType == 'TDA') {
            this.disableTravelDate = 'Y';
            this.checkReferredRisk(this);
			/*if(this.riskObj.plan =='TDA6' && this.riskObj.riskClassification != 'Referred' && this.headerInfo.insuredType=='Personal'){
				
				// let _serverdate = this._appUtilService.getServerDate();				
				let dobDate = moment(this.clientDetails.client.personalClientDetails.dateOfBirth, "YYYY-MM-DD");
				var _effectiveDate = moment(this.headerInfo.effectiveDate, "YYYY-MM-DD");
				let age = _effectiveDate.diff(dobDate, 'years');
				if(age >69 || age < 18){
					this.riskObj.riskClassification = "Referred";
					this.riskObj.riskClassificationReason = "System marked as Referred";
					this.riskObj.symRiskClassification = "Referred";
					
					this.emitRiskClass(this);
				}
			}*/
        }

        if (this.riskObj.isCustomizedPlan == 'Y') this.disableRateField = 'N';

        if (this.riskObj.travelDays <= 0)
            this.setTravelDays();

        // if(this.riskObj.basicPremium <=0){
        // this.setBasicPremium();
        // }

        // this.initDisableFlags();

        // if(this.riskObj.plan && this.riskObj.groupInd=='N') this.adultsNotAllowed='N';

        this.initValidationsConfig();

        // if( (this.riskObj.riskType =='TAA' || this.riskObj.riskType =='TDI' || this.riskObj.riskType =='TPI')&& this.headerInfo.masterPolicy){
        // this.headerInfo.stampDuty = 0;
        // } 
        // else {
        // this.headerInfo.stampDuty = 10;
        // }
    }
    checkReferredRisk(comp) {
        this.riskClassificationService.setRiskClassification(comp.riskObj.riskNumber, "N", "", "").subscribe();
    }

    setBasicPremium(prmEditflg) {
        if (this.riskObj.isCustomizedPlan == 'Y' || (this.riskObj.plan && this.riskObj.coverRequired && this.riskObj.coverageType && this.riskObj.destinationArea && this.riskObj.travelDays > 0)) {
            if (this.riskObj.riskType == 'TAA' && this.riskObj.destinationArea != 'L') {
                this.riskObj.GST = 0;
                this.riskObj.SST = 0;
                this.headerInfo.SSTTaxRate = Number(this.riskObj.SST);
                this.headerInfo.GSTTaxRate = Number(this.riskObj.GST);
            }
            // else if(this.riskObj.riskType=='TPI' && this.riskObj.plan=='DOMS' &&  this.riskObj.destinationArea!='D'){
            else if (this.riskObj.riskType == 'TPI' && this.riskObj.destinationArea != 'D') {
                this.riskObj.GST = 0;
                this.riskObj.SST = 0;
                this.headerInfo.SSTTaxRate = Number(this.riskObj.SST);
                this.headerInfo.GSTTaxRate = Number(this.riskObj.GST);
            }
			/*else if(this.riskObj.riskType=='TDA'){
				this.riskObj.GST=0;
			}*/
            else {
                //this.riskObj.GST= 0;// 6; //SAF MYS-2018-0629
                //SST Code
                this.riskObj.SST = Number(this.headerInfo.SSTTaxRate);
                this.riskObj.GST = Number(this.headerInfo.GSTTaxRate);//End
                if (this.riskObj.GST == 0 || this.riskObj.SST == 0) {
                    let respObj = this._bmsUtilService.getTAXDetails();
                    if (respObj != undefined && respObj != "") {
                        this.headerInfo.SSTTaxRate = Number(respObj[0].old.ITEMPF.GST);
                        this.headerInfo.GSTTaxRate = Number(respObj[1].old.ITEMPF.GST);

                        this.riskObj.SST = Number(this.headerInfo.SSTTaxRate);
                        this.riskObj.GST = Number(this.headerInfo.GSTTaxRate);
                    }
                }

            }
            //need to check the stamp duty... -for TDA, TDI, TPI -	If agent have the master policy then do not apply stamp duty.

            if (this.riskObj.isCustomizedPlan == 'Y') {
                if (!prmEditflg) {
                    this.riskObj.basicPremium = this.getTotalByProperty("premium", this.riskObj.benefitDetails.benefit, this.premiumFormat);
                } else {
                    this.riskObj.basicPremium = numeral().unformat(this.riskObj.basicPremium);
                }

				/*
				if(this.riskObj.riskType=='TAA' || this.riskObj.riskType=='TDA')
					this.riskObj.basicPremium = this.riskObj.basicPremium * parseInt(""+this.riskObj.noOfAdults);
				*/
            } else {
                let descItem = this.riskObj.plan + this.riskObj.coverageType + this.riskObj.destinationArea;
                let request: GetLOVData = new GetLOVData().getRequest('ALL', 'PA', 'NEW BUSINESS', 'ALL', 'NEW', 'Travel', 'Travel Right Premium', 'LOV');
                request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
                request.ADVANCE_CONFIG_XML.FILTERS = new Filter();

                request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push(
                    { "@FIELD_NAME": 'DESCITEM', "@FIELD_VALUE": descItem, '@OPERATION': 'EQ', '@CONDITION': 'AND' },
                    { "@FIELD_NAME": 'COVERREQD', "@FIELD_VALUE": this.riskObj.coverRequired, '@OPERATION': 'EQ', '@CONDITION': 'AND' },
                    { "@FIELD_NAME": 'ITMFRM', "@FIELD_VALUE": moment(this.headerInfo.endDate, "YYYY-MM-DD").format("YYYYMMDD"), '@OPERATION': 'LT', '@CONDITION': 'AND' },
                    { "@FIELD_NAME": 'ITMTO', "@FIELD_VALUE": moment(this.headerInfo.endDate, "YYYY-MM-DD").format("YYYYMMDD"), '@OPERATION': 'GT', '@CONDITION': 'AND' });
                this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.getBasicPremiumDataSuccessHandler, this.handleError, false, { comp: this });

            }

            if (this.riskObj.isCustomizedPlan == 'Y') {
                if (this.riskObj.benefitDetails.benefit.length > 0 && !prmEditflg) {
                    for (let benefitItem of this.riskObj.benefitDetails.benefit) {
                        let si: any = benefitItem.sumInsured;
                        let rate: any = benefitItem.rate;
                        let load: any = benefitItem.load;

                        si = (si == null || si == "") ? 0 : si;
                        rate = (rate == null || rate == "") ? 0 : parseFloat(rate);
                        load = (load == null || load == "") ? 0 : parseFloat(load);

                        let premium = (parseFloat(si) * (parseFloat(rate) * 0.01));
                        let loadPremium = (Number(premium) * (parseFloat(load) * 0.01));

                        benefitItem.premium = Number(premium) + Number(loadPremium);

                        benefitItem.premium = numeral(benefitItem.premium).format('0.00');
                    }
                    this.riskObj.basicPremium = this.getTotalByProperty("premium", this.riskObj.benefitDetails.benefit, this.premiumFormat);

                }
                if (this.riskObj.basicPremium > 99999999999) {
                    this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Basic Premium cannot be more than 99999999999", 5000));
                }
            }

            if (this.riskObj.additionalCoverDetails.additionalCover.length > 0) {
                for (let _coverage of this.riskObj.additionalCoverDetails.additionalCover) {
                    let load: any = _coverage.addlCoverLoad;
                    load = (load == null || load == "") ? 0 : parseFloat(load);

                    _coverage.addlCoverPremium = (numeral().unformat(this.riskObj.basicPremium) * (numeral().unformat(load) * 0.01));
                    _coverage.addlCoverPremium = numeral(_coverage.addlCoverPremium).format('0.00');
                }
            }

            this.riskObj.additionalCoverDetails.additionalCoverTotal = this.getTotalByProperty("addlCoverPremium", this.riskObj.additionalCoverDetails.additionalCover, this.premiumFormat);

            let _totalBasicPremium = parseFloat("" + numeral(this.riskObj.basicPremium).value()) + parseFloat("" + numeral(this.riskObj.additionalCoverDetails.additionalCoverTotal).value());

            this.riskObj.originalTotalPremium = numeral(numeral(_totalBasicPremium).format(this.premiumFormat)).value();

            // this.riskObj.rebateAmount = numeral(numeral(( (parseFloat(""+numeral(this.riskObj.basicPremium).value()) + parseFloat(""+numeral(this.riskObj.additionalCoverDetails.additionalCoverTotal).value()) ) * parseFloat(""+this.riskObj.rebate))/100).format(this.premiumFormat)).value();
            this.riskObj.rebateAmount = numeral(numeral((_totalBasicPremium * parseFloat("" + this.riskObj.rebate)) / 100).format(this.premiumFormat)).value();

            let discountedPrem = numeral(numeral(_totalBasicPremium - parseFloat("" + numeral(this.riskObj.rebateAmount).value())).format(this.premiumFormat)).value();
            this.riskObj.discountedPremium = discountedPrem;

            //this.riskObj.gstAmount = (parseInt(""+this.riskObj.GST) > 0)?numeral(numeral((discountedPrem*parseInt(""+this.riskObj.GST))/100).format(this.premiumFormat)).value():0;		 //SAF MYS-2018-0629
            //SST Code
            let tempGSTAmount = (parseInt("" + this.riskObj.GST) > 0) ? numeral(numeral((discountedPrem * parseInt("" + this.riskObj.GST)) / 100).format(this.premiumFormat)).value() : 0;
            this.riskObj.gstAmount = (tempGSTAmount > 0) ? numeral(numeral(BMSUtilService.calculatePremiumAmount(tempGSTAmount, "G")).format(this.premiumFormat)).value() : 0;

            let tempSSTAmount = (parseInt("" + this.riskObj.SST) > 0) ? numeral(numeral((discountedPrem * parseInt("" + this.riskObj.SST)) / 100).format(this.premiumFormat)).value() : 0;
            this.riskObj.sstAmount = (tempSSTAmount > 0) ? numeral(numeral(BMSUtilService.calculatePremiumAmount(tempSSTAmount, "S")).format(this.premiumFormat)).value() : 0;
            //let _totalPremium = parseFloat(""+numeral(discountedPrem).value()) + parseFloat(""+numeral(this.riskObj.gstAmount).value());
            let _totalPremium = parseFloat("" + numeral(discountedPrem).value()) + parseFloat("" + numeral(this.riskObj.gstAmount).value()) + parseFloat("" + numeral(this.riskObj.sstAmount).value());
            //End
            this.riskObj.totalPremium = numeral(numeral(_totalPremium).format(this.premiumFormat)).value();
            this.riskObj.sstAmount = numeral(numeral(this.riskObj.sstAmount).format(this.premiumFormat)).value();

            this.riskObj.postedPremium = this.riskObj.totalPremium;

            if (this.riskObj.totalPremium > 99999999999) {
                this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Total Premium cannot be more than 99999999999", 5000));
            }

            this.onPremiumChange.emit(this.riskObj.totalPremium);
            this.validateSumInsured();

        } else {
            // this.riskObj.GST = 6;			
            this.resetPremiumAmounts();
        }
    }

    validateSumInsured() {
        if (this.riskObj.RIRetentionCode && this.riskObj.isRIOverWrittenByUW == 'N') {

            this._bmsUtilService.getTotalGrossCapacity(this.riskObj.RIRetentionCode).subscribe((data) => this.compareSIWithTotGrossCap(data));
			/*let _totalGrossCapacity = this._bmsUtilService.getNetRetentionAmountDetails(this.riskObj.RIRetentionCode);
			_totalGrossCapacity = (!_totalGrossCapacity) ? 0 : parseFloat(""+_totalGrossCapacity);
			this.riskObj.totalGrossCapacity = _totalGrossCapacity;
			let _capitalSumInsured = parseFloat(""+this.riskObj.capitalSumInsured);
			
			if( _totalGrossCapacity > 0 && _capitalSumInsured > _totalGrossCapacity && (this.riskObj.RIMethod == null || this.riskObj.RIMethod == "" || parseFloat(""+this.riskObj.RIMethod) != 8) ){
				this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Capital Sum Insured is greater than Total Gross Capacity: "+_totalGrossCapacity+",  RI is Required." , 10000));
				
				this.riskObj.RIRequired = "Yes";
				this.riskObj.RIMethod = "8";
			} 
			else if(_capitalSumInsured <= _totalGrossCapacity){
				this.riskObj.RIRequired = "No";
				this.riskObj.RIMethod = this.riskObj.RIMethodSys;
			}*/
        }
        else
            this.setRIMethodEditableFlag();
    }

    compareSIWithTotGrossCap(totGrossCap) {

        let _totalGrossCapacity = (!totGrossCap) ? 0 : parseFloat("" + totGrossCap);
        this.riskObj.totalGrossCapacity = _totalGrossCapacity;
        let _capitalSumInsured = parseFloat("" + this.riskObj.capitalSumInsured);

        if (_totalGrossCapacity > 0 && _capitalSumInsured > _totalGrossCapacity && (this.riskObj.RIMethod == null || this.riskObj.RIMethod == "" || parseFloat("" + this.riskObj.RIMethod) != 8)) {
            this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Capital Sum Insured is greater than Total Gross Capacity: " + _totalGrossCapacity + ",  RI is Required.", 10000));

            this.riskObj.RIRequired = "Yes";
            this.riskObj.RIMethod = "8";
        }
        else if (_capitalSumInsured <= _totalGrossCapacity) {
            this.riskObj.RIRequired = "No";
            this.riskObj.RIMethod = this.riskObj.RIMethodSys;
        }
        this._riService.setRI().subscribe();
        this.setRIMethodEditableFlag();
    }

    getTotalByProperty(prop, ary, format: string) {
        let total = 0;
        for (let eachItem of ary) {
            if (eachItem[prop] != null && eachItem[prop] != "")
                total = total + parseFloat(numeral(eachItem[prop]).value());
        }
        if (format != null)
            return numeral(numeral(total).format(format)).value();
        else
            return total;
    }

    setPremiumForEach(benefitItem, index) {

        let si: any = benefitItem.sumInsured;
        let rate: any = benefitItem.rate;
        let load: any = benefitItem.load;

        si = (si == null || si == "") ? 0 : si;
        rate = (rate == null || rate == "") ? 0 : parseFloat(rate);
        load = (load == null || load == "") ? 0 : parseFloat(load);

        let premium = (parseFloat(si) * (parseFloat(rate) * 0.01));
        let loadPremium = (Number(premium) * (parseFloat(load) * 0.01));

        benefitItem.premium = Number(premium) + Number(loadPremium);

        benefitItem.premium = numeral(benefitItem.premium).format('0.00');

        this.setBasicPremium(false);
    }

    getBasicPremiumDataSuccessHandler(response, prms) {
        if (response.tuple) {
            let _basicPrem = 0;
            let _weeklyPrem = 0;
            let _toSeqNo = 0;
            let _maxConfigBasicPrem = 0;
            if (Array.prototype.isPrototypeOf(response.tuple)) {
                for (let _premData of response.tuple) {
                    if (prms.comp.riskObj.travelDays >= parseInt(_premData.old.T7201.FROMSEQNO) && prms.comp.riskObj.travelDays <= parseInt(_premData.old.T7201.TOSEQNO)) {
                        _basicPrem = parseFloat(_premData.old.T7201.BASICPREM);
                    }
                    _toSeqNo = parseInt(_premData.old.T7201.TOSEQNO);
                    _weeklyPrem = parseFloat(_premData.old.T7201.ADDWEEKLYPREM);
                    _maxConfigBasicPrem = parseFloat(_premData.old.T7201.BASICPREM);
                }
            }
            else if (response.tuple.old && response.tuple.old.T7201) {
                if (prms.comp.riskObj.travelDays >= parseInt(response.tuple.old.T7201.FROMSEQNO) && prms.comp.riskObj.travelDays <= parseInt(response.tuple.old.T7201.TOSEQNO)) {
                    _basicPrem = parseFloat(response.tuple.old.T7201.BASICPREM);
                }
                _toSeqNo = parseInt(response.tuple.old.T7201.TOSEQNO);
                _weeklyPrem = parseFloat(response.tuple.old.T7201.ADDWEEKLYPREM);
                _maxConfigBasicPrem = parseFloat(response.tuple.old.T7201.BASICPREM);
            }
            else {
                // prms.comp.riskObj.basicPremium = 0;
                prms.comp.resetPremiumAmounts();
            }

            if (_basicPrem == 0 && _toSeqNo > 0) {
                let noOfWeeks = 0;
                let extraDays = prms.comp.riskObj.travelDays - _toSeqNo;
                if (extraDays > 0) {
                    noOfWeeks = Math.ceil(extraDays / 7);
                }

                // if(prms.comp.riskObj.riskType=='TDI')
                prms.comp.riskObj.basicPremium = _maxConfigBasicPrem + (noOfWeeks * _weeklyPrem);
                // else 
                // prms.comp.riskObj.basicPremium = (_maxConfigBasicPrem + (noOfWeeks *_weeklyPrem) )* parseInt(""+prms.comp.riskObj.noOfAdults);
            } else if (_basicPrem > 0) {
                // if(prms.comp.riskObj.riskType=='TPI' || prms.comp.riskObj.riskType=='TDI')
                prms.comp.riskObj.basicPremium = _basicPrem;
                // else
                // prms.comp.riskObj.basicPremium = _basicPrem * parseInt(""+prms.comp.riskObj.noOfAdults);

            }

            // prms.comp.riskObj.postedPremium = prms.comp.riskObj.basicPremium;
            // prms.comp.riskObj.totalPremium = prms.comp.riskObj.basicPremium;
        }
    }

    handleError(response, status, errorText, prms) {
        prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, response.responseJSON.faultstring.text, 5000));
    }

    onPlanChange(ev) {
        this.riskObj.plan = ev.value;
        this.resetPlanDependentFields(this.riskObj.plan);
        this.riskObj.coverRequired = "";
        this.riskObj.coverageType = "";
        this.riskObj.coverageTypeDesc = "";
        this.riskObj.destinationArea = "";
        this.riskObj.destinationAreaDesc = "";
        if (this.riskObj.riskType == 'TDA' || this.riskObj.riskType == 'TDI') {
            //this.riskObj.GST = 0;// 6; //SAF MYS-2018-0629
            //SST Code
            this.riskObj.SST = Number(this.headerInfo.SSTTaxRate);
            this.riskObj.GST = Number(this.headerInfo.GSTTaxRate);//End
        } else {
            this.riskObj.GST = 0;
        }
        this.resetPremiumAmounts();
        this.initValidationsConfig();
        this.populateBenfitDetails(this);

        if (this.riskObj.isCustomizedPlan == 'Y') {
            if (this.capitalSICtrl != null) this.capitalSICtrl.setDisable('N', this.capitalSICtrl.comp);
            if (this.basicPrmCtrl != null) this.basicPrmCtrl.setDisable('N', this.basicPrmCtrl.comp);

        }
        else if (this.riskObj.isCustomizedPlan == 'N') {
            if (this.capitalSICtrl != null) this.capitalSICtrl.setDisable('Y', this.capitalSICtrl.comp);
            if (this.basicPrmCtrl != null) this.basicPrmCtrl.setDisable('Y', this.basicPrmCtrl.comp);
        }
    }

    populateBenfitDetails(scopeObject) {

        if (scopeObject.riskObj.benefitDetails.benefit.length > 0) {
            scopeObject.position = 1;
            scopeObject.riskObj.benefitDetails.benefit.length = 0;
            scopeObject.planBenefits.length = 0;
        }

        for (let _planItem of scopeObject.lovDropDownService.lovDataList.planDetails) {
            if (_planItem.PLANCODE == scopeObject.riskObj.plan) {
                let benefit = new Benefit();
                benefit.seqNumber = scopeObject.riskObj.benefitDetails.benefit.length + 1;
                benefit.coverageCode = _planItem.ZCVRCDE;
                benefit.scheduleOfBenefit = _planItem.ZCVRDESC;
                benefit.sumInsured = _planItem.ZCVRSUMIN;

                scopeObject.riskObj.benefitDetails.benefit.push(benefit);
                if (benefit.seqNumber == 1) {
                    scopeObject.riskObj.capitalSumInsured = _planItem.ZSORIG;
                    scopeObject.riskObj.isCustomizedPlan = (_planItem.ZINDIC) ? _planItem.ZINDIC : 'N';
                    scopeObject.disableRateField = (scopeObject.riskObj.isCustomizedPlan && scopeObject.riskObj.isCustomizedPlan == 'Y') ? 'N' : 'Y';
                }
            }
        }

        scopeObject.setBasicPremium(false);
    }

    defaultInsuredDetails() {

        if (this.headerInfo && this.headerInfo.insuredType == 'Personal') {
            let insured = new Insured();
            insured.itemNo = this.riskObj.insuredDetails.insured.length + 1;
            insured.name = this.clientDetails.client.personalClientDetails.Name;
            insured.nric = this.clientDetails.client.personalClientDetails.NRICNo;
            insured.ICPassport = this.clientDetails.client.personalClientDetails.IdNumber;
            let insuredDOB = ApplicationUtilService.getFormattedDate(this.clientDetails.client.personalClientDetails.dateOfBirth, "YYYY-MM-DD", "YYYYMMDD");
            insured.DOB = (insuredDOB) ? insuredDOB : '';
            insured.gender = this.clientDetails.client.personalClientDetails.gender;
            insured.address = this.clientDetails.client.personalClientDetails.address.address1;
            insured.occupationCode = this.clientDetails.client.personalClientDetails.occupationCode;
            this.riskObj.insuredDetails.insured.push(insured);
        }
        else if (this.headerInfo && this.headerInfo.insuredType == 'Corporate') {
            // let insured = new Insured();
            // insured.itemNo = this.riskObj.insuredDetails.insured.length + 1;
            // insured.name = this.clientDetails.client.personalClientDetails.Name;
            // insured.nric = this.clientDetails.client.personalClientDetails.NRICNo;
            // insured.ICPassport = this.clientDetails.client.personalClientDetails.IdNumber;
            // insured.DOB = this.clientDetails.client.personalClientDetails.dateOfBirth;
            // insured.gender = this.clientDetails.client.personalClientDetails.gender;
            // insured.address = this.clientDetails.client.personalClientDetails.address.address1;
            // insured.occupationCode = this.clientDetails.client.personalClientDetails.occupationCode;
            // this.riskObj.insuredDetails.insured.push(insured);
        }

    }

    onCoverReqChange(ev) {
        if (this.riskObj.groupInd == 'N') {
            if (this.riskObj.riskType == 'TAA') {
                //GA003 START
                jQuery(this.el).find("input[id='noOfAdults']").prop("disabled", false);
                jQuery(this.el).find("input[id='noOfChildren']").prop("disabled", false);
                //GA003 END
                // this.riskObj.noOfAdults = (this.riskObj.coverRequired == '2') ? 2 : 1;
                if (this.riskObj.coverRequired == '1') {
                    this.riskObj.noOfAdults = 1;
                    //jQuery(this.el).find("input[id='noOfAdults']").prop( "disabled", true );
                    if (this.childrenNotAllowed == 'N')
                        jQuery(this.el).find("input[id='noOfChildren']").prop("disabled", false);
                }
                else if (this.riskObj.coverRequired == '2') {
                    this.riskObj.noOfAdults = 2;
                    this.riskObj.noOfChildren = 0;
                    jQuery(this.el).find("input[id='noOfAdults']").prop("disabled", true);
                    jQuery(this.el).find("input[id='noOfChildren']").prop("disabled", true);
                }
                else {
                    this.riskObj.noOfAdults = 0;
                    this.riskObj.noOfChildren = 0;
                    jQuery(this.el).find("input[id='noOfAdults']").prop("disabled", false);
                    jQuery(this.el).find("input[id='noOfChildren']").prop("disabled", false);
                }
            }
            else if (this.riskObj.riskType == 'TDI') {
                if (this.riskObj.coverRequired == '1') {
                    this.riskObj.noOfAdults = 1;
                    this.riskObj.noOfChildren = 0;
                    jQuery(this.el).find("input[id='noOfAdults']").prop("disabled", true);
                    jQuery(this.el).find("input[id='noOfChildren']").prop("disabled", false);
                }
                else if (this.riskObj.coverRequired == '4') {
                    this.riskObj.noOfAdults = 1;
                    jQuery(this.el).find("input[id='noOfAdults']").prop("disabled", false);
                    jQuery(this.el).find("input[id='noOfChildren']").prop("disabled", false);
                }
            }
        }
        else if (this.riskObj.groupInd == 'Y') {
            jQuery(this.el).find("input[id='noOfAdults']").prop("disabled", false);
            jQuery(this.el).find("input[id='noOfChildren']").prop("disabled", false);
        }
        this.setBasicPremium(false);
    }

    onAdultsChange(eVal) {
		/*let noOfAdults = parseInt(""+this.riskObj.noOfAdults);
		let noOfChildren = parseInt(""+this.riskObj.noOfChildren);
		
		//cover required = 1
		if(this.riskObj.coverRequired == '1' && noOfAdults > 1){
			this.riskObj.noOfAdults = 1;
			this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "No of Adults Exceeded." , 3000));
		} else if(this.riskObj.coverRequired == '1' && noOfAdults <= 0){
			this.riskObj.noOfAdults = 1;
			this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "At least one Adult must be entered." , 3000));
		}
		
		if(this.riskObj.coverRequired == '1' && this.childrenNotAllowed=='Y' && noOfChildren >= 1){
			this.riskObj.noOfChildren = 0;
			this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Child Not Covered Plan." , 3000));
		}
		if(this.riskObj.coverRequired == '1' && this.childrenNotAllowed=='N' && noOfChildren <= 0){
			this.riskObj.noOfChildren = 0;
			this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "At least one Child must be entered" , 3000));
		}
		
		//cover required = 2
		if(this.riskObj.coverRequired == '2' && noOfAdults > 2){
			this.riskObj.noOfAdults = 2;
			this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "No of Adults Exceeded." , 3000));
		} else if(this.riskObj.coverRequired == '2' && noOfAdults <2){
			this.riskObj.noOfAdults = 2;
			this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Two Adults must be entered." , 3000));
		}
		
		if(this.riskObj.coverRequired == '2' && noOfChildren !=0){
			this.riskObj.noOfChildren = 0;
			this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Children not covered plan." , 3000));
		}
		
		//cover required = 3
		if(this.riskObj.coverRequired == '3' && noOfAdults > 1){
			this.riskObj.noOfAdults = 1;
			this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "No of Adults Exceeded." , 3000));
		} else if(this.riskObj.coverRequired == '3' && noOfAdults !=1){
			this.riskObj.noOfAdults = 1;
			this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "One Adult must be entered." , 3000));
		}
		
		if(this.riskObj.coverRequired == '3' && noOfChildren <=0){
			this.riskObj.noOfChildren = 1;
			this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "At least one Child must be entered." , 3000));
		}
		
		this.setBasicPremium();*/
    }

    onChildrenChange(eVal) {
		/*let noOfChildren = parseInt(""+this.riskObj.noOfChildren);
		
		//cover required = 1
		if(this.riskObj.coverRequired == '1' && noOfChildren > 1){
			this.riskObj.noOfChildren = 1;
			this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "No of Children Exceeded." , 3000));
		}
		else if(this.riskObj.coverRequired == '1' && noOfChildren <= 0){
			this.riskObj.noOfChildren = 1;
			this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "At least one Child must be entered" , 3000));
		}
		
		//cover required = 2
		if(this.riskObj.coverRequired == '2' && noOfChildren !=0){
			this.riskObj.noOfChildren = 0;
			this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Children not covered plan." , 3000));
		}
		
		//cover required = 3
		if(this.riskObj.coverRequired == '3' && noOfChildren <=0){
			this.riskObj.noOfChildren = 1;
			this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "At least one Child must be entered." , 3000));
		}
		this.setBasicPremium();*/
    }

    initValidationsConfig() {
        if (this.riskObj.groupInd == 'N') {
            let descItem = this.riskObj.riskType + this.riskObj.plan;
            let request: GetLOVData = new GetLOVData().getRequest('ALL', 'PA', 'NEW BUSINESS', 'ALL', 'ALL', 'Travel', 'Travel Validations', 'LOV');

            request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
            request.ADVANCE_CONFIG_XML.FILTERS = new Filter();

            request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push(
                { "@FIELD_NAME": 'DESCITEM', "@FIELD_VALUE": descItem, '@OPERATION': 'EQ', '@CONDITION': 'AND' },
                { "@FIELD_NAME": 'ITMFRM', "@FIELD_VALUE": moment(this.headerInfo.endDate, "YYYY-MM-DD").format("YYYYMMDD"), '@OPERATION': 'LT', '@CONDITION': 'AND' },
                { "@FIELD_NAME": 'ITMTO', "@FIELD_VALUE": moment(this.headerInfo.endDate, "YYYY-MM-DD").format("YYYYMMDD"), '@OPERATION': 'GT', '@CONDITION': 'AND' });
            this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.getTravelValidationsConfigSuccessHandler, this.handleError, false, { comp: this });
        }

        let request2: GetLOVData = new GetLOVData().getRequest('ALL', 'PA', 'NEW BUSINESS', 'ALL', 'ALL', 'Travel', 'Travel Period Validation', 'LOV');
        request2.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        request2.ADVANCE_CONFIG_XML.FILTERS = new Filter();

        request2.ADVANCE_CONFIG_XML.FILTERS.FILTER.push(
            { "@FIELD_NAME": 'DESCITEM', "@FIELD_VALUE": this.riskObj.riskType, '@OPERATION': 'EQ', '@CONDITION': 'AND' }
        );
        this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request2, this.getTravelPeriodValidationsConfigHandler, this.handleError, false, { comp: this });

    }

    getTravelValidationsConfigSuccessHandler(response, prms) {
        if (response.tuple) {
            if (Array.prototype.isPrototypeOf(response.tuple)) {
                prms.comp.childrenNotAllowed = 'Y';
            }
            else if (response.tuple.old && response.tuple.old.T7302) {
                prms.comp.childrenNotAllowed = 'Y';
            }
        }
        BMSConstants.setTravelInsuredConfig(response);
    }

    getTravelPeriodValidationsConfigHandler(response, prms) {

        BMSConstants.setTravelPeriodValidationsConfig(response);
    }

    validateNoOfAdults(eVal) {

        if (eVal) {
            this.setBasicPremium(false);
        }

        if (!eVal) {
            // this.riskObj.noOfAdults = 0;			
        } else {
			/*let noOfAdults = parseInt(""+this.riskObj.noOfAdults);
		
			if(this.riskObj.coverRequired=='1'){
				if(noOfAdults > 1){
					this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Total Adult exceeded" , 3000));
				}
				if( noOfAdults <=0 ){
					this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Enter atleast one Adult" , 3000));
				}
			}
			
			if(this.riskObj.coverRequired=='2'){
				if(noOfAdults > 2){
					this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Total Adult exceeded" , 3000));
				} 
				else if( noOfAdults < 2 ){
					this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Two adults are only allowed" , 3000));
				}
			}		
			
			if(this.riskObj.coverRequired=='3'){
				if(noOfAdults > 1){
					this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Total Adult exceeded" , 3000));
				} 
				else if( noOfAdults < 1 ){
					this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Enter atleast one Adult" , 3000));
				}
			}
			
			if(this.riskObj.coverRequired=='4'){
				if(noOfAdults > 2){
					this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Total Adult exceeded" , 3000));
				} 
				if(noOfAdults < 1){
					this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Enter atleast one Adult" , 3000));
				}
			}*/

			/*if(this.riskObj.riskType=='TAA'){
				if(this.riskObj.coverRequired == '1' && noOfAdults != 1)
					this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "No of Adults should be 1" , 5000));
				else if(this.riskObj.coverRequired == '2' && noOfAdults != 2)
					this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "No of Adults must be 2" , 5000));
				else if(this.riskObj.coverRequired == '4' && (noOfAdults < 1 || noOfAdults >2) )
					this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "No of Adults must be 1 or 2" , 5000));
			}
			else if(this.riskObj.riskType=='TDI'){			
				if(this.riskObj.coverRequired == '4' && (noOfAdults < 1 || noOfAdults >2) )
					this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "No of Adults must be 1 or 2" , 5000));			
			}*/

            this.setBasicPremium(false);
        }
    }

    validateNoOfChildren(eVal) {


        if (!eVal) {
            // this.riskObj.noOfChildren = 0;
        } else {

			/*let noOfChildren = parseInt(""+this.riskObj.noOfChildren);
			
			if(this.riskObj.coverRequired =='1'){
				if(this.childrenNotAllowed == 'Y' && noOfChildren > 1){
					this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Total Children exceeded" , 3000));
				}
				if(this.childrenNotAllowed == 'Y' && noOfChildren <=0){
					this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Enter atleast one Child." , 3000));
				}
				
				if(this.childrenNotAllowed == 'N' && noOfChildren !=0){
					this.riskObj.noOfChildren =0;
					this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Children not covered plan" , 3000));
				}
			}
			
			if(this.riskObj.coverRequired=='2' && noOfChildren !=0 ){
				this.riskObj.noOfChildren =0;
				this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Children not covered plan" , 3000));
			}
			
			if(this.riskObj.coverRequired=='3'){
				if(this.childrenNotAllowed == 'Y' && noOfChildren <=0){
					this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Enter atleast one Child." , 3000));
				}
				// if(this.childrenNotAllowed == 'N' && noOfChildren !=0){
				if(noOfChildren !=0){
					this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Children not covered plan" , 3000));
				}
			}
			
			if(this.riskObj.coverRequired=='4' && noOfChildren <=0){
				this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Enter atlease on Child" , 3000));
			}			
			*/


			/*
			if(this.riskObj.riskType=='TAA'){
				if(this.riskObj.coverRequired == '2' && noOfChildren > 0)
					this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Children can not be covered, should be 0" , 5000));
				else if(this.riskObj.coverRequired == '4' && noOfChildren < 1)
					this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "No of Children must be entered" , 5000));
			}
			else if(this.riskObj.riskType=='TDI'){
				if(this.riskObj.coverRequired == '1' && (noOfChildren < 0 || noOfChildren >1) )
					this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "No of Children must be 0 or 1" , 5000));
				if(this.riskObj.coverRequired == '4' && noOfChildren < 1 )
					this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "No of Children must greater than 0" , 5000));
			}*/
        }
    }

    setTravelDays() {
        if (this.riskObj.travelFromDate && this.riskObj.travelToDate) {
            let fromDate = moment(this.riskObj.travelFromDate, "YYYY-MM-DD");
            let toDate = moment(this.riskObj.travelToDate, "YYYY-MM-DD");
            this.riskObj.travelDays = toDate.diff(fromDate, 'days');
            if (this.riskObj.travelDays >= 0)
                this.riskObj.travelDays = this.riskObj.travelDays + 1;
        }
        else this.riskObj.travelDays = 0;
    }

    validateContractDate(dateCtrlName) {
        let isTravelPeriodValid: boolean = true;
        let _fromDate = moment(this.riskObj.travelFromDate, "YYYY-MM-DD");
        let _toDate = moment(this.riskObj.travelToDate, "YYYY-MM-DD");

        if (this.riskObj.travelFromDate != null && this.riskObj.travelFromDate != "" && this.riskObj.travelToDate != null && this.riskObj.travelToDate != "") {

            if (_fromDate > _toDate) {
                if (dateCtrlName == 'travelFromDate') {
                    if (this.travelFrmDateCtrl != null)
                        this.travelFrmDateCtrl.setter('EMPTY', "YYYY-MM-DD", this.travelFrmDateCtrl.comp);
                    this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Travel Period: From can not be greater than Travel Period:To", 3000));
                    isTravelPeriodValid = false;
                } else if (dateCtrlName == 'travelToDate') {
                    if (this.travelToDateCtrl != null)
                        this.travelToDateCtrl.setter('EMPTY', "YYYY-MM-DD", this.travelToDateCtrl.comp);
                    this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Travel Period: TO can not be less than Travel Period:From", 3000));
                    isTravelPeriodValid = false;
                }
            }
        }

        if (isTravelPeriodValid) {
            let _effectiveDate = moment(this.headerInfo.effectiveDate, "YYYY-MM-DD");
            let _endDate = moment(this.headerInfo.endDate, "YYYY-MM-DD");

            if (dateCtrlName == 'travelFromDate' && this.riskObj.travelFromDate != null && this.riskObj.travelFromDate != "") {

                if (_fromDate < _effectiveDate || _fromDate > _endDate) {
                    if (this.travelFrmDateCtrl != null)
                        this.travelFrmDateCtrl.setter('EMPTY', "YYYY-MM-DD", this.travelFrmDateCtrl.comp);
                    this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Travel Period: From Date should be with in Policy period date range", 3000));
                }
            }
            else if (dateCtrlName == 'travelToDate' && this.riskObj.travelToDate != null && this.riskObj.travelToDate != "") {

                if (_toDate < _effectiveDate || _toDate > _endDate) {
                    if (this.travelToDateCtrl != null)
                        this.travelToDateCtrl.setter('EMPTY', "YYYY-MM-DD", this.travelToDateCtrl.comp);
                    this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Travel Period: To Date should be with in Policy period date range", 3000));
                }
            }
        }
    }

    onTravelPeriodChange(dateCtrlName) {
        this.validateContractDate(dateCtrlName);
        this.setTravelDays();
        this.setBasicPremium(false);
    }

    setReferredFromUI(riskClass) {
        this.riskObj.riskClassification = riskClass;
        this.emitRiskClass(this);
    }

    emitRiskClass(comp) {
        comp.onRiskClsChange.emit("");
    }

    resetPremiumAmounts() {
        this.riskObj.basicPremium = 0;
        this.riskObj.discountedPremium = 0;
        this.riskObj.totalPremium = 0;
        this.riskObj.postedPremium = 0;
        this.riskObj.rebateAmount = 0;
        this.riskObj.gstAmount = 0;

        if (this.riskObj.benefitDetails.benefit.length == 0)
            this.riskObj.capitalSumInsured = 0;

        this.onPremiumChange.emit(this.riskObj.totalPremium);
    }
    // KA0001  START Added new logic for Risk Classification
    onGroupChange(event, person) {
        if (this.riskObj.riskType == 'TAA') {
            this.checkReferredRisk(this);
			/*if(!isNaN(parseInt(""+this.riskObj.noOfAdults))){
				let noOfChildren = (isNaN(parseInt(""+this.riskObj.noOfChildren))?0:parseInt(""+this.riskObj.noOfChildren));
				if(((noOfChildren + parseInt(""+this.riskObj.noOfAdults))<60)
					&& ((this.headerInfo.insuredAge >= 22 && this.headerInfo.insuredAge <= 70) || isNaN(this.headerInfo.insuredAge))){
					this.riskObj.riskClassification = "Standard";
					this.riskObj.symRiskClassification = "Standard";
					this.riskObj.riskClassificationReason ="";
				} else {
					this.riskObj.riskClassification = "Referred";
					this.riskObj.symRiskClassification = "Referred"; 				
					this.riskObj.riskClassificationReason = "System marked as Referred";
				}
				this.emitRiskClass(this); 
			}*/
        }
    }
    // KA0001  END

    initDisableFlags(isOnLoad) {
        if (this.riskObj.groupInd == 'N') {
            if (this.riskObj.riskType == 'TAA') {
                if (this.riskObj.coverRequired == '1' || this.riskObj.coverRequired == '2')
                    this.disableNoOfAdults = 'Y';
                if (this.riskObj.coverRequired == '2')
                    this.disableNoOfChildren = 'Y';
            }
            else if (this.riskObj.riskType == 'TDA') {
                this.disableNoOfAdults = 'Y';
                this.disableNoOfChildren = 'Y';
            }
            else if (this.riskObj.riskType == 'TDI') {
                if (this.riskObj.coverRequired == '1') {
                    this.disableNoOfAdults = 'Y';
                    this.disableNoOfChildren = 'N';
                }
                else if (this.riskObj.coverRequired == '4') {
                    this.disableNoOfAdults = 'N';
                    this.disableNoOfChildren = 'N';
                }
            }
        }
        else if (this.riskObj.groupInd == 'Y') {
            this.disableNoOfAdults = 'N';
            this.disableNoOfChildren = 'N';
        }

        if (!isOnLoad) {
            if (this.disableNoOfAdults == 'N')
                jQuery(this.el).find("input[id='noOfAdults']").prop("disabled", false);
            else if (this.disableNoOfAdults == 'Y')
                jQuery(this.el).find("input[id='noOfAdults']").prop("disabled", true);

            if (this.disableNoOfChildren == 'N')
                jQuery(this.el).find("input[id='noOfChildren']").prop("disabled", false);
            if (this.disableNoOfChildren == 'Y')
                jQuery(this.el).find("input[id='noOfChildren']").prop("disabled", true);
        }
    }

    getDateFormat() {
        let dtFormat = ApplicationUtilService.DATE_TIME_FORMAT;
        return dtFormat.split(" ")[0];
    }

    setRIMethod(val) {

        this.riskObj.RIMethod = (val == "Yes") ? "8" : this.riskObj.RIMethodSys;

        if (this.isUnderWriter == "Y" || val == "Yes")
            this.riskObj.isRIOverWrittenByUW = "Y";
        else if (val == "No") {
            this.riskObj.isRIOverWrittenByUW = "N";
            this.validateSumInsured();
        }
        this._riService.setRI().subscribe();
    }

    validateTextInput(ev) {
        let eVal = ev.target.value;
        ev.target.value = eVal.replace(/\s\s+/g, ' ');
    }

    validateCertNo(ev) {
        let eVal = ev.target.value;
        // if( !(eVal.match(/^[A-Z]{1}\d{7}/g) || eVal.match(/^[A-Z]{2}\d{6}/g)) ){ //Redmine-2068
        // ev.target.value = '';
        // this.riskObj.certNo = '';
        // this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Invalid Cert Number entered." , 3000));
        // }
    }

    setRIMethodEditableFlag() {
        let _capitalSumInsured = parseFloat("" + this.riskObj.capitalSumInsured);
        let _totalGrossCapacity = parseFloat("" + this.riskObj.totalGrossCapacity);
        if (_totalGrossCapacity > 0 && _capitalSumInsured > _totalGrossCapacity && this.isUnderWriter == "N") {
            this.isRIMethodEditable = "N";
        }
        else {
            this.isRIMethodEditable = "Y";
        }
    }

    emitFlagChange() {
        this.onRtngFlgChange.emit("");
    }

    //GA002 START
    callbackForReferralReasons(scopeObject) {
        for (let _refReason of scopeObject.lovDropDownService.lovDataList.referralReasons) {
            // let hasRefReason = scopeObject.referralReasons.some( _data => _data.code === _refReason.code );
            let hasRefReason = scopeObject.riskObj.referralReasons.referralReason.some(_data => _data.code == _refReason.code);
            if (!hasRefReason) {
                scopeObject.referralReasons.push(_refReason);
            }
        }
    }

    callbackReferralAgeLimits(scopeObject) {
		/*if(this.riskObj.polHolderAge == 0 || (!this.riskObj.ageLimitFlag && this.riskObj.polHolderDOB && this.riskObj.polHolderOccupationCode) ){
			this.checkRefferedRisksConditions("");
		}*/
    }
    //GA002 END

}
