/*
 * Change History	:
 *
 * 	No      Date         Description                                 			  Changed By
 *	====    ==========   ===========                                 			  ==========
 *	GA001   09/07/2018   MYS-2018-0443 - Age Checking for PA Products (T7253)    	KGA				 								   
*/
import { Clause } from '../../appobjects/clause';
import { Nominee, NomineeDetails } from "../../appobjects/nomineeslist";
import { Insured, InsuredDetails } from "../../appobjects/insuredlist";
import { GSTDetails } from '../../appobjects/gstDetails';
import { AppUtil } from '../../../../../../common/components/utility/apputil/app.util';
import { BMSConstants } from '../../../../common/constants/bms_constants';
import { NBRisk } from '../../../appobjects/nbrisk';
import { PostedPrem } from '../../../proposalheader/appobjects/postedprem';
import { TravelValidator } from '../../../validation/travel.validator';
import { RiskHelper } from '../../../appobjects/riskhelper';
import { ReferredReason } from '../../../proposalheader/appobjects/referredreason';
import { ReferralReasons } from '../../appobjects/referralReasons';//GA001

export class Travel extends RiskHelper implements NBRisk {
    public sequenceNumber: string;
    public effectiveDate: string;
    public dateOfAttachment: string;
    public contractNumber: string;
    public contractType: string;
    public riskNumber: string;
    public riskType: string;
    public riskName: string;
    public ratingFlag: string = "A";
    // public basisOfCover: string;
    public plan: string;
    public certNo: string;
    public ticketNumber: string;
    public coverRequired: string;
    public noOfAdults: number = 1;
    public noOfChildren: number = 0;
    public RIRetentionCode: string = "PA05";
    public coverageType: string;
    public coverageTypeDesc: string;
    public destinationArea: string;
    public destinationAreaDesc: string;
    public travelFromDate: string;
    public travelToDate: string;
    public travelDays: number = 0;
    public groupInd: string = "N";
    public basicPremium: number = 0;
    public grossPremium: number = 0;
    public capitalSumInsured: number = 0;
    public totalGrossCapacity: number = 0;
    public totalPremium: number = 0;
    public postedPremium: number = 0;
    public basePostedPremiumAdj: number = 0;
    public minimumPremium: number = 0;
    public originalTotalPremium: number = 0;
    public discountedPremium: number = 0;
    public rebate: number = 0;
    public rebateAmount: number = 0;
    public GST: number = 0;//6; //SAF MYS-2018-0629
    public gstAmount: number = 0;

    public additionalCoverDetails: AdditionalCoverageDetails;
    public insuredDetails: InsuredDetails;
    public benefitDetails: BenefitDetails;
    public clauses: Clause;
    public nomineeDetails: NomineeDetails;
    public GSTDetails: GSTDetails;
    public terminationDate: string;

    public RIMethod: string = "1";
    public RIMethodSys: string = "0";
    public RIRequired: string = "No";
    public isRIOverWrittenByUW: string = "N";
    public riskClassification: string = "Standard";
    public riskClassificationReason: string = "";
    public symRiskClassification: string = "";
    public riRiskClassification: string = "Standard";
    public FI: string = "N";
    public isSurveyNeeded: string = "N";
    public addRelatedCases: string = "N";
    public hasClaimExperience: string = "N";
    public isCustomizedPlan: string = "N";
    public isPOIConsidered: string = "Y";
    public priority: string;
    public postedPremDetails: PostedPrem;

    public childRiskPath: string;
    public childRiskIdentity: string;
    public riskClassificationReasons: ReferredReason;
    public gpText: string;
	public gpTextCount:string;//VK004
    public SST: number = 0; //SST Code
    public sstAmount: number = 0;//SST Code
    public SSTLiveDate: string;//SST Code
    public GSTLiveDate: string;//SST Code
    public isGSTApplicable: boolean = true;//SST Code

    //GA001 START
    public ageLimitFlag: string = "";
    public referralReasons: ReferralReasons;
    public ageMin: string = "";
    public ageMax: string = "";
    public spouseAgeLimitFlag: string = "";
    //GA001 END

    constructor() {
        super();
        this.additionalCoverDetails = new AdditionalCoverageDetails();
        this.insuredDetails = new InsuredDetails();
        this.benefitDetails = new BenefitDetails();
        this.clauses = new Clause();
        this.nomineeDetails = new NomineeDetails();
        this.GSTDetails = new GSTDetails();
        this.riskClassificationReasons = new ReferredReason();
        this.referralReasons = new ReferralReasons();//GA001
    }

    public getInstance(valObj: Travel) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
            this.additionalCoverDetails = new AdditionalCoverageDetails().getInstance(valObj.additionalCoverDetails);
            this.insuredDetails = new InsuredDetails().getInstance(valObj.insuredDetails);
            this.benefitDetails = new BenefitDetails().getInstance(valObj.benefitDetails);
            this.clauses = new Clause().getInstance(valObj.clauses);
            this.nomineeDetails = new NomineeDetails().getInstance(valObj.nomineeDetails);
            this.GSTDetails = new GSTDetails().getInstance(valObj.GSTDetails);
            this.riskClassificationReasons.refresh(valObj.riskClassificationReasons);
            this.referralReasons = new ReferralReasons().getInstance(valObj.referralReasons);//GA001	
            if (valObj.isGSTApplicable != undefined && JSON.stringify(valObj.isGSTApplicable) != JSON.stringify("") && typeof (valObj.isGSTApplicable) == "string") {
                this.isGSTApplicable = Boolean(JSON.parse(valObj.isGSTApplicable));
            }
        }
        return this;
    }

    public getNewInstanceByCriteria(criteria: any) {
        let riskType = criteria.riskType;
        let headerInfo = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo;
        if (riskType == "TAA") {
            this.plan = "TAA6";
            this.coverRequired = "1";
            this.coverageType = "S";
            // this.coverageDesc="Overseas 2-way (Outbound)";
            this.destinationArea = "I";
            this.travelFromDate = headerInfo.effectiveDate;
            this.travelToDate = headerInfo.endDate;
        }
        else if (riskType == "TDA") {
            this.plan = "TDA6";
            this.coverRequired = "1";
            this.coverageType = "A";
            this.destinationArea = "L";
            this.travelFromDate = headerInfo.effectiveDate;
            this.travelToDate = headerInfo.endDate;
        }
        else if (riskType == "TDI") {
            this.plan = "DOMC";
            this.coverRequired = "1";
            this.coverageType = "D";
            this.destinationArea = "D";
            this.travelFromDate = headerInfo.effectiveDate;
            this.travelToDate = headerInfo.endDate;
        }
        else if (riskType == "TPI") {
            this.plan = "INTL";
            this.coverRequired = "1";
            this.coverageType = "O";
            this.destinationArea = "C";
            this.travelFromDate = headerInfo.effectiveDate;
            this.travelToDate = headerInfo.endDate;
        }
        return this;
    }

    public getValidator() {
        return new TravelValidator(this);
    }
}

export class BenefitDetails {
    public benefit: Benefit[] = [];

    public getInstance(valObj: BenefitDetails) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
            new AppUtil().handleArray(this, valObj, "benefit");
        }
        return this;
    }
}

export class Benefit {
    public seqNumber: number;
    public coverageCode: string;
    public scheduleOfBenefit: string;
    public sumInsured: number;
    public rate: number;
    public load: number;
    public premium: number;
    constructor() { }
}

export class AdditionalCoverageDetails {

    public additionalCover: AdditionalCoverage[] = [];
    public additionalCoverTotal: number = 0;

    public getInstance(valObj: AdditionalCoverageDetails) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
            new AppUtil().handleArray(this, valObj, "additionalCover");
        }
        return this;
    }
}

export class AdditionalCoverage {

    public addlCoverCode: string;
    public addlCoverCodeDesc: string;
    public addlCoverLoad: number;
    public addlCoverPremium: number;

    constructor() { }
}
