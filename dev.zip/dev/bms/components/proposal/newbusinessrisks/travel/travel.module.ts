import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BasicUIModule } from '../../../../../common/components/utility/basicui.module';
import { LovModule } from "../../../../../common/services/lovdropdown/lov.module";
import { ClausesModule } from '../uimodules/clauses.module';
import { GSTModule } from '../uimodules/gst.module';
import { PaginationModule } from '../../../../../common/components/utility/pagination/pagination.module';
import { NomineeModule } from "../uimodules/nominee.module";
import { InsuredModule } from '../uimodules/insured.module';
import { TravelComponent } from './travel.component';
import { GeneralPageModule } from '../uimodules/generalpage.module'; //VK004

@NgModule({
    imports: [ CommonModule, FormsModule, ReactiveFormsModule, BasicUIModule, LovModule, ClausesModule, GSTModule , PaginationModule, NomineeModule, InsuredModule, GeneralPageModule],
    declarations: [TravelComponent],
    exports: [TravelComponent]
})
export class TravelModule { }