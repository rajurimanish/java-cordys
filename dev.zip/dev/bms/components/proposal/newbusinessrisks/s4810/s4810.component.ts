/*
 * Change History:
 * 
 * No      Date          Description                                         Changed By
 * ====    ==========    ===========                                         ==========	
 * YPK001 23/09/2019       MYS-2019-0675 Document Validation for Co-outwards            PKU1
 *                         case before sending to PPHO			   
*/
import { Component, OnInit, ViewChild, ElementRef, EventEmitter, AfterViewInit, ViewContainerRef } from '@angular/core';
declare var Observer: any;
import { DCLInput, CustomDCLService } from '../../../../../common/services/customdcl.service';
import { LOV_Field, LOVDropDownService, SearchFilter } from "../../../../../common/services/lovdropdown/lovdropdown.service";
import { CordysSoapWService } from "../../../../../common/components/utility/cordys-soap-ws";
import { GetLOVData, SearchAdvancedConfig, Filter } from '../../../../../common/components/utility/search/search.requests';
import { ProposalHeader } from '../../proposalheader/appobjects/proposalheader';
import { AlertMessagesService } from '../../../../../common/components/utility/alertmessage/alertmessages.service';
import { AlertMessage } from '../../../../../common/components/utility/alertmessage/alertmessages.model';
import { S4810, MadatoryPolicy, AdditionalLocation } from './appobjects/s4810';
import { Survey } from '../appobjects/survey';
import { Clause } from "../appobjects/clause";
import { FinancialInterest } from '../../../../../common/components/financialinterest/appobjects/financialInterest';
import { ModalInput } from "../../../../../common/components/utility/modal/modal";
import { SearchInput } from "../../../../../common/components/utility/search/genericsearch";
import { BMSConstants } from '../../../common/constants/bms_constants';
import { CaseInfo } from '../../../../../common/components/appobjects/caseinfo';
import { ApplicationUtilService } from "../../../../../common/services/application.util.service";
import { BMSUtilService } from "../../../../services/bms.util.service";
import { AppUtil } from '../../../../../common/components/utility/apputil/app.util';
import { RIService } from '../services/ri.service';
import { ReferredReason, Reasons } from '../../proposalheader/appobjects/referredreason';
import { RiskClassificationService } from "../services/riskcls.service";
import { ActivatedRoute } from '@angular/router';
import { ClausesComponent } from '../uimodules/clauses.component';

declare var jQuery: any;
declare var moment: any;
declare var numeral: any;

@Component({
    selector: 's4810-risk-component',
    templateUrl: 'app/bms/components/proposal/newbusinessrisks/s4810/s4810.template.html',
    inputs: ['riskObj', 'clientDetails', "headerInfo", "caseInfo"],
    outputs: ["onPremiumChange", "onRiskClsChange", "onRtngFlgChange"],
    providers: [RiskClassificationService]
})

export class S4810Component implements OnInit {
    private el: HTMLElement;
    public riskObj: S4810;
    public headerInfo: ProposalHeader;
    public caseInfo: CaseInfo;
    private situationInfoCollapse: boolean = false;
    private clCBIInfoCollapse: boolean = true;
    private coverageInfoCollapse: boolean = false;
    private mandPolDetCollapse: boolean = false;
    private addLocationCollapse: boolean = false;
    private surInfoCollapse: boolean = false;
    private isGeneralPageCollapsed: boolean = false;

    public siFormat: string = "0,00";
    public premiumFormat: string = "0,00.00";
    public rateFormat: string = "0.00000";
    public percentFormat: string = "0.00";
    public loadFormat: string = "0.00";
    private isExcessPercentMandatory: string = 'N';
    private isExcessAmountMandatory: string = 'N';
    private disableBasicPrem: string = 'N';

    // private rateCtrl:any;
    private basicPremiumCtrl: any;
    private piamCodes = [];

    private isUnderWriter = "N";
    private isRIMethodEditable = "Y";
    // private disablePremium:string="N";
    private isUsedMandatoryPolicy = false;

    onPremiumChange = new EventEmitter<any>();
    onRiskClsChange = new EventEmitter<any>();
    onRtngFlgChange = new EventEmitter<any>();
    @ViewChild(ClausesComponent) private clausesComp: ClausesComponent;
    @ViewChild('mandPolicies', { read: ViewContainerRef }) mandatoryPolicyArea: ViewContainerRef;

    constructor(private lovDropDownService: LOVDropDownService, private _soapService: CordysSoapWService, public _alertMsgService: AlertMessagesService, el: ElementRef, public dcl: CustomDCLService, private _appUtilService: ApplicationUtilService, private _bmsUtilService: BMSUtilService, private _riService: RIService, public riskClassificationService: RiskClassificationService, private _activatedRoute: ActivatedRoute) {
        this.el = el.nativeElement;
    }

    ngOnInit() {
        this.populateLOVs();

        if (this.riskObj.ratingFlag == "A") this.disableBasicPrem = "Y";

        this._appUtilService.isUnderWriterUser().subscribe((data) => {
            this.isUnderWriter = data;
            this.setRIMethodEditableFlag();
        });

        if ((this.headerInfo.contractType == "CAR" || this.headerInfo.contractType == "EAR") && (this.riskObj.riskType == "PL" || this.riskObj.riskType == "IPL") && this.riskObj.ratingFlag == 'M' && (!this.riskObj.basicPremium || !parseFloat("" + this.riskObj.basicPremium))) {
            this.populateBasicPremium();
        }

        //SST Code
        if (["MyTasks", "MyDrafts"].indexOf(this._activatedRoute.snapshot.params['component']) >= 0 || Object.keys(this._activatedRoute.snapshot.params).length == 0) {
            let respObj = this._bmsUtilService.getTAXDetails();
            if (respObj != undefined && respObj != "") {
                this.headerInfo.SSTTaxRate = Number(respObj[0].old.ITEMPF.GST);
                this.headerInfo.GSTTaxRate = Number(respObj[1].old.ITEMPF.GST);

                this.riskObj.SST = Number(this.headerInfo.SSTTaxRate);
                this.riskObj.GST = Number(this.headerInfo.GSTTaxRate);
            }

            this.headerInfo = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo;
            this.riskObj.SSTLiveDate = (this.riskObj.SSTLiveDate == undefined) ? this.headerInfo.SSTLiveDate : this.riskObj.SSTLiveDate;
            if (this.riskObj.SSTLiveDate == undefined || this.riskObj.SSTLiveDate == "") {
                let tempRespObj = this._bmsUtilService.getLiveDate();
                this.riskObj.GSTLiveDate = tempRespObj[0].old.ITEMPF.LIVEDATE;
                this.riskObj.SSTLiveDate = tempRespObj[1].old.ITEMPF.LIVEDATE;
                if (this.headerInfo.SSTLiveDate == undefined || this.headerInfo.SSTLiveDate == "") {
                    this.headerInfo.SSTLiveDate = this.riskObj.SSTLiveDate;
                }
                if (this.headerInfo.GSTLiveDate == undefined || this.headerInfo.GSTLiveDate == "") {
                    this.headerInfo.GSTLiveDate = this.riskObj.GSTLiveDate;
                }
            }
            if (moment(this.headerInfo.effectiveDate, "YYYY-MM-DD").format("YYYYMMDD") >= moment(this.riskObj.SSTLiveDate, "YYYY-MM-DD").format("YYYYMMDD")) {
                this.riskObj.isGSTApplicable = false;
            } else {
                this.riskObj.isGSTApplicable = true;
            }
        }
        //End
        if (this.caseInfo.businessFunction == 'Renewal') { // LIA Renewals - MYS-2018-0877
            this.calculateTotalPremium();
        }
    }

    ngAfterViewInit() {
        this.initRatingFlagChange();

        //check POI
        if (!this.riskObj.occupationCode) {
            this.checkReferredRiskConditions();
        }
        //START YPK001
        let rIndex = 0;
        if ((this.headerInfo.CoInsurance == 'Y' && this.riskObj.riskNumber == '1') && (["MyTasks", "MyDrafts"].indexOf(this._activatedRoute.snapshot.params['component']) >= 0 || Object.keys(this._activatedRoute.snapshot.params).length == 0)) {
            if (this.headerInfo.coInsuranceDetails.coInsurance.length == 1) {
                if (!(this.headerInfo.coInsuranceDetails.coInsurance[0].coInsuranceindicator == 'L' && this.headerInfo.coInsuranceDetails.coInsurance[0].sharePercentage == '100')) {
                    rIndex = this.riskObj.clauses.clause.map(function (item) { return item.clauseCode; }).indexOf("COIN");
                    if (rIndex == -1)
                        this.setClauses(["COIN"], false);
                }
            }
            else {
                rIndex = this.riskObj.clauses.clause.map(function (item) { return item.clauseCode; }).indexOf("COIN");
                if (rIndex == -1)
                    this.setClauses(["COIN"], false);
            }
        }
        //END YPK001
    }
    //START YPK001
    setClauses(clausesList, flag) {
        if (this.clausesComp)
            this.clausesComp.addClause(clausesList, '', flag);
    }
    //END YPK001
    populateLOVs() {
        this.lovDropDownService.createLOVDataList(["Occupation", "turnoverType", "riCode", "excessType", "NCDPercentage", "riskCode", "postCode", "piamCodesList"]);

        let riskFilter = (this.riskObj.riskType.length == 2) ? this.riskObj.riskType + ' ' : this.riskObj.riskType;
        let excessTypeFilterDetails = [new SearchFilter("DESCITEM", riskFilter, "STARTSWITH", "AND")];
        let excessTypeFilterNodes = this.lovDropDownService.createFilter(excessTypeFilterDetails);
        let lovFields = [
            new LOV_Field("ALL", "ALL", "ALL", "ALL", "ALL", "S4810", "TurnoverCode", "LOV", [], "DESCPF", "turnoverType", null),
            new LOV_Field("ALL", "LIA", "ALL", "ALL", "ALL", "ALL", "Risk Code", "LOV", [], "DESCPF", "riskCode", null),
            new LOV_Field("ALL", "MIS", "NEW BUSINESS", "ALL", "ALL", "ALL", "Excess Type", "LOV", excessTypeFilterNodes, "T9107", "excessType", "callbackForExcessTypesLoad"),
            new LOV_Field("ALL", "FIRE", "NEW BUSINESS", "ALL", "NEW", "FIRE_IDC", "PostCode", "LOV", [], "DESCPF", "postCode", null)
        ];

        if (this.riskObj.riskType == 'PP3') {
            let _polEndDate = ApplicationUtilService.getFormattedDate(this.headerInfo.endDate, "YYYY-MM-DD", "YYYYMMDD");
            let planFilterDetails = [new SearchFilter("DESCITEM", this.riskObj.riskType, "STARTSWITH", "AND")];
            let planFilterNodes = this.lovDropDownService.createFilter(planFilterDetails);

            let piamCodesFilterDetails = [new SearchFilter("A.DESCITEM", this.riskObj.riskType, "STARTSWITH", "AND"),
            new SearchFilter("A.ITMFRM", _polEndDate, "LTEQ", "AND"),
            new SearchFilter("A.ITMTO", _polEndDate, "GTEQ", "AND")];
            let piamCodesFilterNodes = this.lovDropDownService.createFilter(piamCodesFilterDetails);

            lovFields.push(new LOV_Field("ALL", "MIS", "NEW BUSINESS", "ALL", "ALL", "ALL", "NCD Percentage", "LOV", planFilterNodes, "DESCPF", "NCDPercentage", null));
            lovFields.push(new LOV_Field("ALL", "FIRE", "NEW BUSINESS", "ALL", "ALL", "ALL", "PIAM Codes List", "LOV", piamCodesFilterNodes, "T9115", "piamCodesList", "callbackForPIAMCodesList"));
        }
        else {
            lovFields.push(new LOV_Field("ALL", "MIS", "ALL", "ALL", "ALL", "ALL", "Occupation", "LOV", excessTypeFilterNodes, "T9109", "Occupation", null));
        }

        // new LOV_Field("ALL", "ALL", "ALL", "ALL", "ALL", "ALL", "Currency", "LOV", currencyDateFilterNodes, "T3629", "currency", null)
        this.lovDropDownService.util_populateLOV(lovFields, this);
    }

    callbackForPIAMCodesList(scopeObject) {
        for (let _rec of scopeObject.lovDropDownService.lovDataList.piamCodesList) {
            let hasPiamCode = scopeObject.piamCodes.some(_item => _item.VALUE === _rec.VALUE);
            if (!hasPiamCode) {
                scopeObject.piamCodes.push(_rec);
            }
        }

        if (scopeObject.piamCodes.length > 0) {
            ApplicationUtilService.sortArray(scopeObject.piamCodes, 'VALUE');
        }
    }

    populateBasicPremium() {

        if (this.riskObj.basicPremium == 0) {
            let _bmsRisks = BMSConstants.getRisks();
            if (_bmsRisks && _bmsRisks['s4851'] && _bmsRisks['s4851'].length > 0) {

                let _premiumAllocPercentage = _bmsRisks['s4851'][0].premAllocPercentage;
                let _rsk_basicPremium = _bmsRisks['s4851'][0].premium * _premiumAllocPercentage * 0.01;
                this.riskObj.basicPremium = numeral(numeral(_rsk_basicPremium).format(this.premiumFormat)).value();
            }
        }

        /*let polEffDate = ApplicationUtilService.getFormattedDate(this.headerInfo.effectiveDate,"YYYY-MM-DD","YYYYMMDD");
    	
        let request:GetLOVData = new GetLOVData().getRequest('ALL','ENG','ALL','ALL','ALL','ALL','Personal Premium Allocation','LOV');
        request.ADVANCE_CONFIG_XML= new SearchAdvancedConfig();
        request.ADVANCE_CONFIG_XML.FILTERS = new Filter();
        	
        request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({"@FIELD_NAME":"DESCITEM", "@FIELD_VALUE":this.headerInfo.contractType, "@OPERATION":"EQ", "@CONDITION":"AND"},
                                                       {"@FIELD_NAME":"ITMFRM", "@FIELD_VALUE":polEffDate, "@OPERATION":"LTEQ", "@CONDITION":"AND"},
                                                       {"@FIELD_NAME":"ITMTO",  "@FIELD_VALUE":polEffDate, "@OPERATION":"GTEQ", "@CONDITION":"AND"});
    	
        this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request , null, null, false, null).success((data)=> {
        	
            if(data.tuple){
                let _ZNCBLPER:any;
                if(Array.prototype.isPrototypeOf(data.tuple)){
                    _ZNCBLPER = data.tuple[0].old.T4949.ZNCBLPER;
                }
                else if(data.tuple.old && data.tuple.old.T4949) {
                    _ZNCBLPER = data.tuple.old.T4949.ZNCBLPER;
                }
                if(_ZNCBLPER){
                    _ZNCBLPER = (_ZNCBLPER == null || _ZNCBLPER == "") ? 0 : _ZNCBLPER;
                    let _bmsRisks = BMSConstants.getRisks();
                    if(_bmsRisks && _bmsRisks['s4851'] && _bmsRisks['s4851'].length > 0 && _ZNCBLPER > 0){
                        let _premium = _bmsRisks['s4851'][0].premium;
                        let _basicPremium = _premium * (_ZNCBLPER * 0.01) * 0.01;
                        this.riskObj.basicPremium = numeral(numeral(_basicPremium).format(this.premiumFormat)).value();
                    }
                }
            }	
        }).error((response, status, errorText)=> {
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR,"Error while getting Personal Premium Allocation", 5000));			
        });*/

    }

    turnoverCodeChange(evt) {
        this.riskObj.turnoverCode = evt.value;
    }

    onPIAMCodeChange(ev) {
        this.riskObj.occupationCode = ev.value;
        this.riskObj.occupationDesc = ev.record.DESCRIPTION;

        this.checkReferredRiskConditions();
    }

    calculateTotalPremium() {
        this.riskObj.capitalSumInsured = numeral().unformat(this.riskObj.limitAOA);
        this.riskObj.convertedSI = this.riskObj.capitalSumInsured;

        if (this.riskObj.ratingFlag == "A") {
            this.riskObj.basicPremium = this.riskObj.capitalSumInsured * (this.riskObj.rate / 100);
        }
        this.riskObj.loadingDiscountAmount = this.riskObj.basicPremium * (this.riskObj.load / 100);

        // let ncdPerct = (this.riskObj.ncdPercentage == null || this.riskObj.ncdPercentage == "") ? 0 : parseFloat(""+this.riskObj.ncdPercentage);
        // this.riskObj.ncdAmount = (ncdPerct > 0) ?(this.riskObj.basicPremium * ncdPerct/100) : 0;		
        // this.riskObj.basicPremium = this.riskObj.basicPremium + this.riskObj.ncdAmount;

        if (this.riskObj.ratingFlag == "A") {
            let _totalOrgPremium = parseFloat("" + numeral(this.riskObj.basicPremium).value()) + parseFloat("" + numeral(this.riskObj.loadingDiscountAmount).value());
            this.riskObj.originalTotalPremium = _totalOrgPremium;
        }
        else
            this.riskObj.originalTotalPremium = this.riskObj.basicPremium;

        this.riskObj.rebateAmount = numeral(numeral((this.riskObj.originalTotalPremium * parseFloat("" + this.riskObj.rebate)) / 100).format(this.premiumFormat)).value();

        let discountedPrem = numeral(numeral(this.riskObj.originalTotalPremium - parseFloat("" + numeral(this.riskObj.rebateAmount).value())).format(this.premiumFormat)).value();
        this.riskObj.discountedPremium = discountedPrem;

        //SST Code
        if (parseFloat("" + this.riskObj.GST) > 0 && discountedPrem > 0) {
            //this.riskObj.gstAmount = numeral(numeral( (discountedPrem * parseFloat(""+this.riskObj.GST)) * 0.01).format(this.premiumFormat)).value();
            let tempGSTAmount = numeral(numeral((discountedPrem * parseFloat("" + this.riskObj.GST)) * 0.01).format(this.premiumFormat)).value();
            this.riskObj.gstAmount = numeral(numeral(BMSUtilService.calculatePremiumAmount(tempGSTAmount, "G")).format(this.premiumFormat)).value();
        }
        else {
            this.riskObj.gstAmount = 0;
        }

        if (parseFloat("" + this.riskObj.SST) > 0 && discountedPrem > 0) {
            let tempSSTAmount = numeral(numeral((discountedPrem * parseFloat("" + this.riskObj.SST)) * 0.01).format(this.premiumFormat)).value();
            this.riskObj.sstAmount = (tempSSTAmount > 0) ? numeral(numeral(BMSUtilService.calculatePremiumAmount(tempSSTAmount, "S")).format(this.premiumFormat)).value() : 0;
        }
        else {
            this.riskObj.sstAmount = 0;
        }

        //let _totalPremium = parseFloat(""+numeral(discountedPrem).value()) + parseFloat(""+numeral(this.riskObj.gstAmount).value());
        let _totalPremium = parseFloat("" + numeral(discountedPrem).value()) + parseFloat("" + numeral(this.riskObj.gstAmount).value()) + parseFloat("" + numeral(this.riskObj.sstAmount).value());
        //End
        this.riskObj.totalPremium = numeral(numeral(_totalPremium).format(this.premiumFormat)).value();

        this.riskObj.originalTotalPremium = numeral(numeral(this.riskObj.originalTotalPremium).format(this.premiumFormat)).value();
        this.riskObj.basicPremium = numeral(numeral(this.riskObj.basicPremium).format(this.premiumFormat)).value();

        this.riskObj.postedPremium = this.riskObj.totalPremium;

        this.validateSumInsured();
    }

    validateSumInsured() {
        if (this.riskObj.riRetentionCode && this.riskObj.isRIOverWrittenByUW == 'N') {
            this._bmsUtilService.getTotalGrossCapacity(this.riskObj.riRetentionCode).subscribe((data) => this.compareSIWithTotGrossCap(data));

        }
        else
            this.setRIMethodEditableFlag();
    }

    compareSIWithTotGrossCap(totGrossCap) {

        let _totalGrossCapacity = (!totGrossCap) ? 0 : parseFloat("" + totGrossCap);
        this.riskObj.totalGrossCapacity = _totalGrossCapacity;

        let _capitalSumInsured = parseFloat("" + this.riskObj.capitalSumInsured);

        if (_totalGrossCapacity > 0 && _capitalSumInsured > _totalGrossCapacity && (this.riskObj.RIMethod == null || this.riskObj.RIMethod == "" || parseFloat("" + this.riskObj.RIMethod) != 8)) {
            this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Capital Sum Insured is greater than Total Gross Capacity: " + _totalGrossCapacity + ",  RI is Required.", 10000));

            this.riskObj.RIRequired = "Yes";
            this.riskObj.RIMethod = "8";
        }
        else if (_capitalSumInsured <= _totalGrossCapacity) {
            this.riskObj.RIRequired = "No";
            this.riskObj.RIMethod = this.riskObj.RIMethodSys;
        }
        this._riService.setRI().subscribe();
        this.setRIMethodEditableFlag();
    }

    getTotalByProperty(prop, ary, format: string) {
        let total = 0;
        for (let eachItem of ary) {
            if (eachItem[prop] != null && eachItem[prop] != "")
                total = total + parseFloat(numeral(eachItem[prop]).value());
        }
        if (format != null)
            return numeral(numeral(total).format(format)).value();
        else
            return total;
    }

    handleError(response, status, errorText, prms) {
        prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, response.responseJSON.faultstring.text, -1));
    }

    setReferredFromUI() {
        if (event.target != null) {
            let riskClass = jQuery(event.target).find("option:selected").text();
            this.riskObj.riskClassification = riskClass;
            this.setReferredByRiskClass(this, riskClass);
        }
    }

    setReferredByRiskClass(comp, riskClass) {
        if (riskClass != null && riskClass == "Referred") {
            comp.setReferred(comp, true);
        }
        else {
            comp.setReferredByRI(comp, comp.riskObj.riRetentionCode);
        }
    }

    setReferred(comp, toRefer) {
        comp.onRiskClsChange.emit("");
    }

    setReferredByRI(comp, riCode) {
        // if(this.leastPreferredRI.indexOf(riCode) != -1){
        // comp.riskObj.riskClassification = "Referred";
        // comp.riskObj.symRiskClassification = "Referred";
        // comp.setReferred(comp,true);
        // }
        // else{
        comp.setReferred(comp, false);
        // }
    }

    setReferredByRIFromUI() {
        if (event.target != null) {
            let riCode = jQuery(event.target).find("option:selected").text();
            this.setReferredByRI(this, riCode);
        }
    }

    emitRiskClass(comp) {
        comp.onRiskClsChange.emit("");
    }

    resetFI(value) {
        if (value == "Y")
            this.riskObj.financialInterest = new FinancialInterest();
        else
            this.riskObj.financialInterest = null;
    }

    onRIRtnChange(value) {
        this.riskObj.riRetentionCode = value;
        // this.setSurveyNeed();
    }

    /*onExcessTypeChange(ev){
        this.riskObj.excessType=ev.value;
        this.setExcessValidationFiels();
    }*/

    onExcessTypeChange() {
        this.setExcessValidationFiels();
    }

    setExcessValidationFiels() {
        if (this.riskObj.excessType && this.riskObj.excessType != '') {
            for (let _etItem of this.lovDropDownService.lovDataList.excessType) {
                if (_etItem.VALUE == this.riskObj.excessType) {
                    this.isExcessPercentMandatory = (_etItem.ACTN02 == 'Y') ? 'Y' : 'N';
                    this.isExcessAmountMandatory = (_etItem.ACTN01 == 'Y') ? 'Y' : 'N';
                    BMSConstants.setExcessTypeRecord(this.riskObj.riskType + this.riskObj.excessType, _etItem);
                }
            }
        }
        else {
            this.isExcessPercentMandatory = 'N';
            this.isExcessAmountMandatory = 'N';
            this.riskObj.excessPercentage = 0;
            this.riskObj.excessAmount = 0;
        }
    }

    callbackForExcessTypesLoad(scopeObject) {
        if (scopeObject.riskObj.excessType && scopeObject.riskObj.excessType != '') {
            scopeObject.setExcessValidationFiels();
        }
    }

    private onTextChange(ev) {
        if (ev.target.value == ' ') {
            ev.target.value = '';
        }
    }

    validateTextInput(ev) {
        let eVal = ev.target.value;
        ev.target.value = eVal.replace(/\s\s+/g, ' ');
        ev.target.value = ev.target.value.trim();
    }

    private onKeyPressHandler(ev) {
        if (ev.keyCode == 13 || ev.target.value.length == 74) {
            this.setFocusToNext(ev.target);
        } else if (ev.keyCode == 32) {
            ev.target.value = ev.target.value.trim();
        }
    }

    setFocusToNext(elmnt) {
        let locationElmnts = jQuery(this.el).find("input");
        jQuery(locationElmnts[locationElmnts.index(elmnt) + 1]).focus();
    }

    validateAOP(ev) {
        let eVal = ev.target.value;
        if (eVal.match(/[^a-zA-Z0-9,.]/g)) {
            ev.target.value = '';
            this.riskObj.limitAOP = '';
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Only Alpha numeric, (,) and (.) are allowed.", 3000));
        }
    }

    setRIMethod(val) {

        this.riskObj.RIMethod = (val == "Yes") ? "8" : this.riskObj.RIMethodSys;

        if (this.isUnderWriter == "Y" || val == "Yes")
            this.riskObj.isRIOverWrittenByUW = "Y";
        else if (val == "No") {
            this.riskObj.isRIOverWrittenByUW = "N";
            this.validateSumInsured();
        }

        this._riService.setRI().subscribe();
    }

    handleRiskClassification() {
        if (this.riskObj.symRiskClassification == "Declined")
            this.riskObj.riskClassification = "Declined";
        else if (this.riskObj.symRiskClassification == "Referred" || this.riskObj.riRiskClassification == "Referred")
            this.riskObj.riskClassification = "Referred";
        else
            this.riskObj.riskClassification = "Standard";
        this.setRiskClassification();
        this.emitRiskClass(this);
    }

    setRiskClassification() {
        if (this.riskObj.symRiskClassification != null && this.riskObj.symRiskClassification != "" && (this.riskObj.symRiskClassification == "Referred" || this.riskObj.symRiskClassification == "Declined")) {
            this.riskObj.riskClassificationReason = "System marked as " + this.riskObj.symRiskClassification;
        }
        else if (this.riskObj.riRiskClassification != null && this.riskObj.riRiskClassification != "" && this.riskObj.riRiskClassification == "Referred") {
            this.riskObj.riskClassificationReason = "System marked as " + this.riskObj.riRiskClassification;
        }
        else {
            if (this.riskObj.riskClassificationReason != null && this.riskObj.riskClassificationReason != "" && (this.riskObj.riskClassificationReason != "System marked as Standard" && this.riskObj.riskClassificationReason.indexOf("System marked as ") != -1)) {
                this.riskObj.riskClassificationReason = "";
            }
        }
    }

    openMandatoryPolicyDetailsDialog() {

        let _polEffDate = ApplicationUtilService.getFormattedDate(this.headerInfo.effectiveDate, "YYYY-MM-DD", "YYYYMMDD");
        let _polEndDate = ApplicationUtilService.getFormattedDate(this.headerInfo.endDate, "YYYY-MM-DD", "YYYYMMDD");
        let _statusCodes = "'CA','LA','PN','PR'";

        let searchInput = new SearchInput();
        searchInput.isSingleSelect = true;
        searchInput.BRANCH = 'ALL';
        searchInput.BUSINESS_FUNCTION = 'NEW BUSINESS';
        searchInput.FIELD_TYPE = 'LOOKUP';
        searchInput.FORM_FIELD_NAME = 'POLICY_NUMBER';
        searchInput.FORM_NAME = 'POLICY_DETAILS';
        searchInput.LOB = 'ALL';
        searchInput.OPERATION = 'NEW';
        searchInput.PRODUCT = 'ALL';
        searchInput.condition = { "CHD.CNTTYPE": "PP1", "CHD.COWNNUM": this.headerInfo.insuredNumber, "CHD.CCDATE": _polEffDate, "CHD.CRDATE": _polEndDate, "CHD.STATCODE": _statusCodes };
        // searchInput.condition = {"CCDATE": this.splitedLossDate, "CRDATE": this.splitedLossDate,"CNTBRANCH":this.caseInfo.servicingBranches};

        if (this.riskObj.mandatoryPolicies.mandatoryPolicy.length > 0) {
            let newArr = [];
            for (let item of this.riskObj.mandatoryPolicies.mandatoryPolicy) {
                newArr = newArr.concat(item["policyNumber"]);
            }
            let policyNumbers = "'" + newArr.toString().replace(/,/g, "\',\'") + "'";
            // searchInput.condition = {"CHD.CHDRNUM":policyNumbers};
        }

        let input = new ModalInput();
        input.component = ["GenericSearchComponent", "app/common/components/utility/search/genericsearch.module", "GenericSearchModule"];
        input.datainput = searchInput;
        input.outputCallback = this.setDataFromMandatoryPolicyDialog;
        input.parentCompPRMS = { comp: this };
        input.heading = "Mandatory Policy Details";
        input.icon = "fa fa-file-pdf-o";
        input.containerRef = this.mandatoryPolicyArea;
        this.dcl.openLookup(input);
    }

    setDataFromMandatoryPolicyDialog(policyData, prms) {
        if (policyData.length !== 0) {
            for (let _policyItem of policyData) {
                let _policyNum = _policyItem.old.CHDRPF.CHDRNUM;
                if (prms.comp.checkMandatoryPolicy(_policyNum)) {
                    prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Policy Number " + _policyNum + " is already used for another PP2 policy.", 4000));
                }
                else {
                    let _mandPolicy = new MadatoryPolicy();
                    _mandPolicy.seqNumber = prms.comp.riskObj.mandatoryPolicies.mandatoryPolicy.length + 1;
                    _mandPolicy.policyNumber = _policyItem.old.CHDRPF.CHDRNUM;
                    _mandPolicy.effectiveDate = _policyItem.old.CHDRPF.CCDATE;
                    prms.comp.riskObj.mandatoryPolicies.mandatoryPolicy.push(_mandPolicy);
                }

            }
        }
    }

    removePolicy(idx) {
        this.riskObj.mandatoryPolicies.mandatoryPolicy.splice(idx, 1);
        for (let _mandPolicy of this.riskObj.mandatoryPolicies.mandatoryPolicy) {
            let index = this.riskObj.mandatoryPolicies.mandatoryPolicy.indexOf(_mandPolicy);
            _mandPolicy.seqNumber = (index + 1);
        }
    }

    checkMandatoryPolicy(pp1PolicyNum) {
        let request: GetLOVData = new GetLOVData();
        request.BRANCH = 'ALL';
        request.LOB = 'ALL';
        request.BUSINESS_FUNCTION = 'NEW BUSINESS';
        request.PRODUCT = 'ALL';
        request.OPERATION = 'ALL';
        request.FORM_NAME = 'ALL';
        request.FORM_FIELD_NAME = 'Mandatory Policy';
        request.FIELD_TYPE = 'LOV';
        request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        request.ADVANCE_CONFIG_XML.FILTERS = new Filter();

        request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({ "@FIELD_NAME": "CNTTYPE", "@FIELD_VALUE": "PP3", '@OPERATION': 'EQ', '@CONDITION': 'AND' });
        request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({ "@FIELD_NAME": "ZMDCHDR", "@FIELD_VALUE": pp1PolicyNum, '@OPERATION': 'EQ', '@CONDITION': 'AND' });
        request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({ "@FIELD_NAME": "ZMDRISK", "@FIELD_VALUE": "0", '@OPERATION': 'EQ', '@CONDITION': 'AND' });
        request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({ "@FIELD_NAME": "DTETER", "@FIELD_VALUE": "99999999", '@OPERATION': 'EQ', '@CONDITION': 'AND' });

        this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.getMandatoryPoliciesHandler, this.handleError, false, { comp: this });

        return this.isUsedMandatoryPolicy;
    }

    getMandatoryPoliciesHandler(response, prms) {
        prms.comp.isUsedMandatoryPolicy = false;
        if (response.tuple) {
            let _ary = new AppUtil().getArray(response.tuple);
            if (_ary && _ary.length > 0) {
                prms.comp.isUsedMandatoryPolicy = true;
            }
        }
    }

    addAdditionalLocation() {
        let _additionalLocationItem = new AdditionalLocation();
        _additionalLocationItem.seqNumber = this.riskObj.additionalLocationDetails.additionalLocation.length + 1;

        this.riskObj.additionalLocationDetails.additionalLocation.push(_additionalLocationItem);
    }

    removeAdditionalLocation(item) {
        let _idx = this.riskObj.additionalLocationDetails.additionalLocation.indexOf(item);
        this.riskObj.additionalLocationDetails.additionalLocation.splice(_idx, 1);
        this.resetALItemNumber();
    }

    resetALItemNumber() {
        for (let _al of this.riskObj.additionalLocationDetails.additionalLocation) {
            let index = this.riskObj.additionalLocationDetails.additionalLocation.indexOf(_al);
            _al.seqNumber = (index + 1);
        }
    }

    setRIMethodEditableFlag() {
        let _capitalSumInsured = parseFloat("" + this.riskObj.capitalSumInsured);
        let _totalGrossCapacity = parseFloat("" + this.riskObj.totalGrossCapacity);
        if (_totalGrossCapacity > 0 && _capitalSumInsured > _totalGrossCapacity && this.isUnderWriter == "N") {
            this.isRIMethodEditable = "N";
        }
        else {
            this.isRIMethodEditable = "Y";
        }
    }

    emitFlagChange() {
        this.initRatingFlagChange();

        this.calculateTotalPremium();
        this.onRtngFlgChange.emit("");
    }

    initRatingFlagChange() {

        if (this.riskObj.ratingFlag == 'A') {
            // this.disablePremium ='Y';
            if (this.basicPremiumCtrl != null) this.basicPremiumCtrl.setDisable('Y', this.basicPremiumCtrl.comp);
        } else {
            // this.disablePremium ='N';
            if (this.basicPremiumCtrl != null) this.basicPremiumCtrl.setDisable('N', this.basicPremiumCtrl.comp);
        }
    }

    resetSurvey(value) {
        if ("Y" == value) {
            this.riskObj.survey = new Survey();
        }
        else {
            this.riskObj.survey = null;
        }
    }

    setIdentity(isIdentityChange) {
        if (isIdentityChange == true && (this.riskObj.identityFiller == null || this.riskObj.identityFiller == "")) {
            // if(this.riskObj.situation1 != null){
            // this.riskObj.identity = this.riskObj.situation1.slice(0, 15);
            // this.riskObj.identityFiller = this.riskObj.situation1.slice(0, 15);
            // }
        }
        else {
            // if(isIdentityChange == false && this.riskObj.situation1 != null){
            if (isIdentityChange == false) {
                // this.riskObj.identity = this.riskObj.situation1.slice(0, 15);
                // this.riskObj.identityFiller = this.riskObj.situation1.slice(0, 15);
            }
            else if (this.riskObj.identityFiller != null)
                this.riskObj.identity = this.riskObj.identityFiller.slice(0, 15);
        }
    }

    checkReferredRiskConditions() {
        //let _reasons = new Reasons();

        //let isReferredRisk = false;
        //let isDeclinedRisk = false;

        //POI is greater than year		
        /* let _polEffDate = moment(this.headerInfo.effectiveDate, "YYYY-MM-DD");
        let _polEndDate = moment(this.headerInfo.endDate, "YYYY-MM-DD");
        let _diffMnths = _polEndDate.diff(_polEffDate,'months');
        if(_diffMnths >= 12){
            isReferredRisk = true;
            _reasons.reason.push("POI is greater than 1 year");
        }*/

        if (this.riskObj.occupationCode) {
            this.riskObj.occRiskClassification = "Standard";
            if (this.riskObj.riskType == 'PP3') {
                // let _rec = this.lovDropDownService.lovDataList.piamCodesList.find((_data)=> _data.VALUE == this.riskObj.occupationCode);
                let _rec = this.piamCodes.find((_data) => _data.VALUE == this.riskObj.occupationCode);

                if (_rec.REFERRED && _rec.REFERRED == 'Y') {

                    this.riskObj.occRiskClassification = "Referred";
                    //isReferredRisk = true;
                    //_reasons.reason.push("Occupation code of type Referred selected");
                }
                else if (_rec.REFERRED && _rec.REFERRED == 'D') {
                    this.riskObj.occRiskClassification = "Declined";
                    //isDeclinedRisk = true;
                    //_reasons.reason.push("Declined : Occupation code of type Declined selected");
                }
            }
            else {
                let _rec = this.lovDropDownService.lovDataList.Occupation.find((_data) => _data.VALUE == this.riskObj.occupationCode);

                if (_rec.REFERREDRISK && _rec.REFERREDRISK == 'Y') {
                    this.riskObj.occRiskClassification = "Referred";
                    //isReferredRisk = true;
                    //_reasons.reason.push("Occupation code of type Referred selected");
                }
                else if (_rec.REFERREDRISK && _rec.REFERREDRISK == 'D') {
                    this.riskObj.occRiskClassification = "Declined";
                    //isDeclinedRisk = true;
                    //_reasons.reason.push("Declined : Occupation code of type Declined selected");
                }
            }
        }
        /*
        this.riskObj.riskClassificationReasons.reasons = _reasons;
    	
        if(isDeclinedRisk == true){
            this.riskObj.symRiskClassification = "Declined";			
        }
        else if(isReferredRisk == true){
            this.riskObj.symRiskClassification = "Referred";			
        }
        else this.riskObj.symRiskClassification = "Standard";
    	
        this.handleRiskClassification();
        */
        this.riskClassificationService.setRiskClassification(this.riskObj.riskNumber, "N", "", "").subscribe();
    }
}
