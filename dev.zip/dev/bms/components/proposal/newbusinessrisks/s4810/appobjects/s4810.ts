import { Clause } from '../../appobjects/clause';
import { DeclarationDetails } from '../../appobjects/declarationDetails';
import { FinancialInterest } from '../../../../../../common/components/financialinterest/appobjects/financialInterest';
import { GSTDetails } from '../../appobjects/gstDetails';
import { Survey } from '../../appobjects/survey';
import { AppUtil } from '../../../../../../common/components/utility/apputil/app.util';
import { NBRisk } from '../../../appobjects/nbrisk';
import { PostedPrem } from '../../../proposalheader/appobjects/postedprem';
import { RiskHelper } from '../../../appobjects/riskhelper';
import { ReferredReason } from '../../../proposalheader/appobjects/referredreason';
import { S4810Validator } from '../../../validation/s4810.validator';

export class S4810 extends RiskHelper implements NBRisk {
    public sequenceNumber: string;
    public effectiveDate: string;
    public dateOfAttachment: string;
    public contractNumber: string;
    public contractType: string;
    public riskNumber: string;
    public riskType: string;
    public riskName: string;
    public ratingFlag: string;

    public occupationCode: string;
    public occupationDesc: string;
    public plant: string;
    public tLimit: string;
    public siCurrency: string = "RM";
    public siRate: string = "1.0000000";
    public excessType: string = "";
    public excessPercentage: number;
    public excessAmount: number;
    public limitAOA: number = 0;
    public limitAOP: string;
    public turnoverCode: string;
    // public turnoverDesc:string;	
    public turnoverAmount: number = 0;
    public riRetentionCode: string;
    public premiumClass: string;
    public situationLine1: string;
    public situationLine2: string;
    public situationLine3: string;
    public situationLine4: string;
    public situationLine5: string;
    public situationLine6: string;
    public situationLine7: string;
    public jurisdiction: string;
    public reference: string;
    public retroactiveDate: string;
    public schemeBusiness: string;

    public convertedSI: number;
    public ncdPercentage: string = "00";
    public ncdAmount: number = 0;
    public load: number = 0.00;
    public loadingDiscountAmount: number = 0.00;
    public rate: number = 0.00;

    public minimumPremium: number = 0;
    public originalTotalPremium: number = 0;
    public postedPremium: number = 0;
    public basePostedPremiumAdj: number = 0;
    public discountedPremium: number = 0;
    public grossPremium: number = 0;
    public basicPremium: number = 0;
    public totalPremium: number = 0;
    public capitalSumInsured: number = 0;
    public relatedSumInsured: number = 0;
    public totalGrossCapacity: number = 0;
    public totalSI: number = 0;
    public GST: number = 0;
    public gstAmount: number = 0;
    public rebate: number = 0;
    public rebateAmount: number = 0;

    public clauses: Clause;
    public GSTDetails: GSTDetails;
    public mandatoryPolicies: MandatoryPolicyDetails;
    public additionalLocationDetails: AdditionalLocationDetails;
    public financialInterest: FinancialInterest;
    public survey: Survey;

    public riskClassification: string = "Standard";
    public riskClassificationReason: string = "";
    public symRiskClassification: string = "";
    public occRiskClassification: string = "Standard";
    public riRiskClassification: string = "Standard";
    public RIMethod: string = "0";
    public RIMethodSys: string = "0";
    public RIRequired: string = "No";
    public isRIOverWrittenByUW: string = "N";
    public isSurveyNeeded: string = "N";
    public addRelatedCases: string = "N";
    public hasClaimExperience: string = "";
    public GT: string;
    public GP: string;
    public FI: string = 'N';
    public DS: string;
    public CL: string;
    public MI: string;
    public isLeastPreferred: string = "N";
    public isPOIConsidered: string = "N";
    public priority: string;
    public postedPremDetails: PostedPrem;

    public identity: string = "";
    public identityFiller: string = "";
    public gpText: string;
    public gpTextCount:string;//VK004

    public childRiskPath: string;
    public childRiskIdentity: string;
    public riskClassificationReasons: ReferredReason;

    public SST: number = 0; //SST Code
    public sstAmount: number = 0;//SST Code
    public SSTLiveDate: string;//SST Code
    public GSTLiveDate: string;//SST Code
    public isGSTApplicable: boolean = true;//SST Code
    constructor() {
        super();
        this.clauses = new Clause();
        this.GSTDetails = new GSTDetails();
        this.mandatoryPolicies = new MandatoryPolicyDetails();
        this.additionalLocationDetails = new AdditionalLocationDetails();
        this.financialInterest = new FinancialInterest();
        this.riskClassificationReasons = new ReferredReason();
    }

    public getInstance(valObj: S4810) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
            this.clauses = new Clause().getInstance(valObj.clauses);
            this.GSTDetails = new GSTDetails().getInstance(valObj.GSTDetails);
            this.mandatoryPolicies = new MandatoryPolicyDetails().getInstance(valObj.mandatoryPolicies);
            this.additionalLocationDetails = new AdditionalLocationDetails().getInstance(valObj.additionalLocationDetails);
            if (valObj.FI == "Y") {
                this.financialInterest = new FinancialInterest().getInstance(valObj.financialInterest);
            }
            if (valObj.isSurveyNeeded == "Y") {
                this.survey = new Survey().getInstance(valObj.survey);
            }
            this.riskClassificationReasons.refresh(valObj.riskClassificationReasons);
            if (valObj.isGSTApplicable != undefined && JSON.stringify(valObj.isGSTApplicable) != JSON.stringify("") && typeof (valObj.isGSTApplicable) == "string") {
                this.isGSTApplicable = Boolean(JSON.parse(valObj.isGSTApplicable));
            }
        }
        return this;
    }

    public getNewInstanceByCriteria(criteria: any) {
        let riskType = criteria.riskType;
        let contractType = criteria.contractType;
        if (contractType == "PL" && riskType == "PL") {
            this.ratingFlag = "M";
            this.premiumClass = "53";
            this.riRetentionCode = "PLA";
        }
        else if (contractType == "PPL" && riskType == "PPL") {
            this.ratingFlag = "M";
            this.premiumClass = "54";
            this.riRetentionCode = "PPL";
            this.tLimit = "worldwide excluding USA/Canada";
        }
        else if (contractType == "PP3" && riskType == "PP3") {
            this.ratingFlag = "M";
            this.premiumClass = "76";
            this.riRetentionCode = "PP3";
            this.tLimit = "Malaysia";
            this.jurisdiction = "Malaysia";
        }
        else if (contractType == "CAR" && riskType == "PL") {
            this.ratingFlag = "M";
            this.premiumClass = "53";
            this.riRetentionCode = "PLA";
        }
        else if (contractType == "CAR" && riskType == "IPL") {
            this.ratingFlag = "M";
            this.premiumClass = "53P";
            this.riRetentionCode = "PLA";
        }
        else if (contractType == "EAR" && riskType == "PL") {
            this.ratingFlag = "M";
            this.premiumClass = "53";
            this.riRetentionCode = "PLA";
        }
        else if (contractType == "EAR" && riskType == "IPL") {
            this.ratingFlag = "M";
            this.premiumClass = "53P";
            this.riRetentionCode = "PLA";
        }

        return this;
    }

    public getValidator() {
        return new S4810Validator(this);
    }

}

export class MandatoryPolicyDetails {
    public mandatoryPolicy: MadatoryPolicy[] = [];

    public getInstance(valObj: MandatoryPolicyDetails) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
            new AppUtil().handleArray(this, valObj, "mandatoryPolicy");
        }
        return this;
    }
}

export class MadatoryPolicy {
    public seqNumber: number;
    public policyNumber: string;
    public effectiveDate: string;

    public getInstance(valObj: MadatoryPolicy) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
        }
        return this;
    }

}

export class AdditionalLocationDetails {
    public additionalLocation: AdditionalLocation[] = [];

    public getInstance(valObj: AdditionalLocationDetails) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
            new AppUtil().handleArray(this, valObj, "additionalLocation");
        }
        return this;
    }
}

export class AdditionalLocation {
    public seqNumber: number;
    public riskCode: string;
    public situation: string;
    public postCode: string;

    public getInstance(valObj: AdditionalLocation) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
        }
        return this;
    }

}
