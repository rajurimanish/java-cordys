import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BasicUIModule } from '../../../../../common/components/utility/basicui.module';
//import { FIModule } from '../../../../../common/components/financialinterest/fi.module';
import { LovModule } from "../../../../../common/services/lovdropdown/lov.module";
//import { ClausesModule } from '../uimodules/clauses.module';
import { GSTModule } from '../uimodules/gst.module';
import { InsuredModule } from '../uimodules/insured.module';
import { RelatedCaseModule } from '../uimodules/relatedcase.module';
//import { SurveyModule } from '../uimodules/survey.module';
import { NomineeModule } from "../uimodules/nominee.module";
import { GeneralPageModule } from '../uimodules/generalpage.module'; //VK004
import { S4857Component } from './s4857.component';

@NgModule({
    //imports: [ CommonModule, FormsModule, ReactiveFormsModule, BasicUIModule, FIModule, LovModule, ClausesModule, GSTModule,InsuredModule,RelatedCaseModule,SurveyModule ],
    imports: [CommonModule, FormsModule, ReactiveFormsModule, BasicUIModule, LovModule, GSTModule, InsuredModule, RelatedCaseModule, NomineeModule, GeneralPageModule],
    declarations: [S4857Component],
    exports: [S4857Component]
})
export class S4857Module { }