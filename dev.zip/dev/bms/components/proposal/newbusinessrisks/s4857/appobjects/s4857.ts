/*
 * Change History	:
 *
 * 	No      Date         Description                                 			  Changed By
 *	====    ==========   ===========                                 			  ==========
 *	GA001   09/07/2018   MYS-2018-0443 - Age Checking for PA Products (T7253)    	KGA				 								   
*/
import { Clause } from '../../appobjects/clause';
import { DeclarationDetails } from '../../appobjects/declarationDetails';
//import {FinancialInterest} from '../../../../../../common/components/financialinterest/appobjects/financialInterest';
import { GSTDetails } from '../../appobjects/gstDetails';
import { AppUtil } from '../../../../../../common/components/utility/apputil/app.util';
import { FireRelatedCases } from '../../appobjects/relatedCase';
//import {Survey} from '../../appobjects/survey';
import { Nominee, NomineeDetails } from "../../appobjects/nomineeslist";
import { NBRisk } from '../../../appobjects/nbrisk';
import { PostedPrem } from '../../../proposalheader/appobjects/postedprem';
import { S4857Validator } from '../../../validation/s4857.validator';
import { RiskHelper } from '../../../appobjects/riskhelper';
import { ReferredReason } from '../../../proposalheader/appobjects/referredreason';
import { ReferralReasons } from '../../appobjects/referralReasons';//GA001

export class S4857 extends RiskHelper implements NBRisk {
    public sequenceNumber: string;
    public effectiveDate: string;
    public dateOfAttachment: string;
    public contractNumber: string;
    public contractType: string;
    public riskNumber: string;
    public riskType: string;
    public riskName: string;
    public ratingFlag: string = "A";
    public benefitCode: string = "";
    public benefitDescription: string = "";
    public RIRetentionCode: string;
    public hasClaimExperience: string = "N";
    /****
     *      Policy Holder Details
     ***/
    public polHolderName: string = "";
    public polHolderOccupationCode: string = "";
    public polHolderOccupationDesc: string = "";
    public polHolderSex: string = "";
    public polHolderDOB: string = "";
    public polHolderAge: number = 0;
    public polHolderICBirthCert: string = "";
    /****
     *      Spouse Details
     ***/
    public spouseName: string = "";
    public spouseOccupationCode: string = "";
    public spouseOccupationDesc: string = "";
    public spouseSex: string = "";
    public spouseDOB: string = "";
    public spouseAge: number = 0;
    public spouseICBirthCert: string = "";
    /****
     *      Children Array of ChildrenDetails Object: refer below
     ***/
    public childrenDetails: S4857ChildrenDetails;
    public noOfChildren: number = 0;

    /**** Risk Classification related Fields****/
    public symRiskClassification: string = "";
    public riskClassificationReason: string = '';
    public occRiskClassification: string;
    public insuredOccRiskClassification: string;
    public spouseOccRiskClassification: string;

    public riskClassification: string = "Standard";

    /**** Nonimee Details ***/
    public nomineeDetails: NomineeDetails;

    public renewalBonusAmount: number;
    public renewalBonusPercentage: number;

    public additionalCoverDetails: AdditionalCoverageDetails;
    public additionalCode: string;
    public additionalLoading: string;
    public addditionalPremium: number = 0;
    public discountedPremium: number = 0;
    public rebate: number = 0;
    public rebateAmount: number = 0;
    public GST: number = 0;//6; //SAF MYS-2018-0629
    public gstAmount: number = 0;
    public basicPremium: number = 0;
    public originalTotalPremium: number = 0;
    //for minimum premium calculations
    public basePostedPremiumAdj: number = 0;
    public isPOIConsidered: string = "N";
    public priority: string;
    public accumulationRegister: string;

    public relatedCases: FireRelatedCases;
    public capitalSumInsured: number = 0;
    public totalGrossCapacity: number = 0;
    public grossPremium: number = 0;
    public ncdPercentage: number = 0;
    public ncdAmount: number = 0;
    public totalPremium: number = 0;
    public clauses: Clause;
    public terminationDate: string;
    //public financialInterest: FinancialInterest;
    public GSTDetails: GSTDetails;

    public GT: string;
    public GP: string;
    public FI: string = 'Y';
    public DS: string;
    public CL: string;
    public MI: string;
    public addRelatedCases: string = "N";
    public defaultClauses: Clause;

    public relatedSumInsured: number = 0;

    public postedPremium: number = 0;

    public totalSI: number = 0;
    public identity: string = "";
    public identityFiller: string = "";

    //public isSurveyNeeded:string="N";
    public isLeastPreferred: string = "N";
    public ratingClass: string = "";
    //public survey:Survey;

    public RIRequired: string = "No";
    public RIMethod: string = "1";
    public RIMethodSys: string = "0";
    public isRIOverWrittenByUW: string = "N";
    public postedPremDetails: PostedPrem;

    public childRiskPath: string;
    public childRiskIdentity: string;
    public riskClassificationReasons: ReferredReason;
    public gpText: string;
    public gpTextCount:string;
    //GA001 START
    public ageLimitFlag: string = "";
    public referralReasons: ReferralReasons;
    public ageMin: string = "";
    public ageMax: string = "";
    public spouseAgeLimitFlag: string = "";
    //GA001 END
    public SST: number = 0; //SST Code
    public sstAmount: number = 0;//SST Code
    public SSTLiveDate: string;//SST Code
    public GSTLiveDate: string;//SST Code
    public isGSTApplicable: boolean = true;//SST Code
    constructor() {
        super();
        this.additionalCoverDetails = new AdditionalCoverageDetails();
        //this.clauses = new Clause();		
        //this.financialInterest = new FinancialInterest();
        this.GSTDetails = new GSTDetails();
        this.relatedCases = new FireRelatedCases();
        this.childrenDetails = new S4857ChildrenDetails();
        this.nomineeDetails = new NomineeDetails();
        this.riskClassificationReasons = new ReferredReason();
        this.referralReasons = new ReferralReasons();//GA001
    }

    public getInstance(valObj: S4857) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
            this.clauses = new Clause().getInstance(valObj.clauses);
            this.additionalCoverDetails = new AdditionalCoverageDetails().getInstance(valObj.additionalCoverDetails);
            this.nomineeDetails = new NomineeDetails().getInstance(valObj.nomineeDetails);

			/*if(valObj.FI == "Y"){
				this.financialInterest = new FinancialInterest().getInstance(valObj.financialInterest);
			}*/
            this.GSTDetails = new GSTDetails().getInstance(valObj.GSTDetails);
            this.childrenDetails = new S4857ChildrenDetails().getInstance(valObj.childrenDetails);
			/*if(valObj.isSurveyNeeded == "Y"){
				this.survey = new Survey().getInstance(valObj.survey);
			}*/
            if (valObj.addRelatedCases == "Y") {
                this.relatedCases = new FireRelatedCases().getInstance(valObj.relatedCases);
            }
            this.riskClassificationReasons = new ReferredReason().getInstance(valObj.riskClassificationReasons);
            this.referralReasons = new ReferralReasons().getInstance(valObj.referralReasons);//GA001
            if (valObj.isGSTApplicable != undefined && JSON.stringify(valObj.isGSTApplicable) != JSON.stringify("") && typeof (valObj.isGSTApplicable) == "string") {
                this.isGSTApplicable = Boolean(JSON.parse(valObj.isGSTApplicable));
            }	
        }
        return this;
    }

    public getNewInstanceByCriteria(criteria: any) {
        let riskType = criteria.riskType;
        if (riskType == "FPA") {
            this.RIRetentionCode = "PA01";
            this.ratingClass = "01";
        }
        return this;
    }

    public getValidator() {
        return new S4857Validator(this);
    }
}

export class AdditionalCoverageDetails {

    public additionalCover: AdditionalCoverage[] = [];
    public additionalCoverTotal: number = 0;

    public getInstance(valObj: AdditionalCoverageDetails) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
            new AppUtil().handleArray(this, valObj, "additionalCover");
        }
        return this;
    }
}

export class AdditionalCoverage {

    public additionalCode: string;
    public additionalCover: string;
    public sumInsured: string;
    public rate: string = "0.00";
    public additionalLoading: string;
    public addditionalPremium: string = "0.00";
    constructor() { }
}

export class S4857ChildrenDetails {
    public children: S4857Children[] = [];
    public getInstance(valObj: S4857ChildrenDetails) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().handleArray(this, valObj, "children");
        }
        return this;
    }
}

export class S4857Children {
    public itemNo: number;
    public name: string;
    public nric: string;
    public ICPassport: string;
    public DOB: string;
    public insuredAge: number = 0;
    public gender: string;
    public address: string;
    public occupationCode: string;
    public occupationDescription: string;
    public terminationDate: string;
    public childOccRiskClassification: string;
    constructor() { }
}
