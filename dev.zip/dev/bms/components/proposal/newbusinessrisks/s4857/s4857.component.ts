/*
Change History	:

	No      Date          Description                                 Changed By
	====    ==========    ===========                                 ==========
	MD001   14/03/2018   MYS-2018-0130 - Occupation Code to be Read 
	                    from T9109 - for All Personal Lines Products      MKU1
	GA001   09/07/2018   MYS-2018-0443 - Age Checking for PA Products (T7253)    	KGA		 
 */
import { Component, OnInit, ViewChild, ElementRef, EventEmitter, AfterViewInit, ViewContainerRef } from '@angular/core';
import { DCLInput, CustomDCLService } from '../../../../../common/services/customdcl.service';
import { LOV_Field, LOVDropDownService, SearchFilter } from "../../../../../common/services/lovdropdown/lovdropdown.service";
import { CordysSoapWService } from "../../../../../common/components/utility/cordys-soap-ws";
import { GetLOVData, SearchAdvancedConfig, Filter } from '../../../../../common/components/utility/search/search.requests';
import { AlertMessagesService } from '../../../../../common/components/utility/alertmessage/alertmessages.service';
import { AlertMessage } from '../../../../../common/components/utility/alertmessage/alertmessages.model';
import { S4857, S4857ChildrenDetails, S4857Children, AdditionalCoverageDetails, AdditionalCoverage } from './appobjects/s4857';
import { Clause } from "../appobjects/clause";
import { ClausesComponent } from "../uimodules/clauses.component";
import { ProposalHeader } from '../../proposalheader/appobjects/proposalheader';
import { ModalInput } from '../../../../../common/components/utility/modal/modal';
import { SearchInput } from "../../../../../common/components/utility/search/genericsearch";
import { ClientDetails } from '../../../../../common/components/client/appobjects/client';
import { RelatedCaseComponent } from "../uimodules/relatedcase.component";
import { FireRelatedCases, RelatedCases } from '../appobjects/relatedCase';
import { NomineeDetails } from "../appobjects/nomineeslist";
import { ApplicationUtilService } from "../../../../../common/services/application.util.service";
import { BMSUtilService } from "../../../../services/bms.util.service";
import { RIService } from '../services/ri.service';
import { RiskClassificationService } from "../services/riskcls.service";
import { ReferralReasons, ReferralReason } from '../appobjects/referralReasons';//GA001
import { ReferredReason, Reasons } from '../../proposalheader/appobjects/referredreason';//GA001
import { BMSConstants } from '../../../common/constants/bms_constants';
import { ActivatedRoute } from '@angular/router';

declare var jQuery: any;
declare var moment: any;
declare var numeral: any;

@Component({
    selector: 's4857-component',
    templateUrl: 'app/bms/components/proposal/newbusinessrisks/s4857/s4857.template.html',
    inputs: ['riskObj', 'clientDetails', "headerInfo"],
    outputs: ["onPremiumChange", 'onRiskClsChange', 'onRtngFlgChange'],
    providers: [RiskClassificationService]
})

export class S4857Component implements OnInit {
    @ViewChild(ClausesComponent) private clausesComp: ClausesComponent;
    @ViewChild('paCompModal', { read: ViewContainerRef }) contentArea: ViewContainerRef;
    public leastPreferredRI = ['D1E1', 'D1E2', 'D1E3', 'D2E1', 'D2E2', 'D2E3', 'D3E1', 'D3E2', 'D3E3'];
    onPremiumChange = new EventEmitter<any>();
    onRiskClsChange = new EventEmitter<any>();
    onRtngFlgChange = new EventEmitter<any>();

    public clientDetails: ClientDetails;

    private el: HTMLElement;
    public headerInfo: ProposalHeader;

    public riskObj: S4857;
    public accRegCtrl: any;
    public siFormat: string = "0,00";
    public premiumFormat: string = "000.00";
    public rateFormat: string = "00.0000";
    public percentFormat: string = "0.00";
    public bonusFormat: String = "0.00";


    private collapseInsuredInfo: boolean = false;
    private isCoverInfoCollapsed: boolean = false;
    private collapseClausesInfo: boolean = false;
    private isNomineeInfoCollapsed: boolean = false;
    private PolHolderDOBCtrl: any;
    private SpouseDOBCtrl: any;
    private ChildDOBCtrl: any = [];
    private renewalBonusAmountCtrl: any;
    private renewalBonusPercentageCtrl: any;
    private disableRenewalBonusAmount = "N";
    private disableRenewalBonusPercentage = "N";

    public benefitsList: LocalBenefits[];
    public selectedBenefit: LocalBenefits;

    private isUnderWriter = "N";
    private isRIMethodEditable = "Y";
    private isGeneralPageCollapsed: boolean = false;
    private referralReasons = [];//GA001
    constructor(public dcl: CustomDCLService, private lovDropDownService: LOVDropDownService, private _soapService: CordysSoapWService, public _alertMsgService: AlertMessagesService, el: ElementRef, private _appUtilService: ApplicationUtilService, private _bmsUtilService: BMSUtilService, private _riService: RIService, public riskClassificationService: RiskClassificationService, private _activatedRoute: ActivatedRoute) {
        this.el = el.nativeElement;
    }

    ngOnInit() {
        this.populateLOVs();
        this.populateBenefitCodes();
        if ((this.riskObj.polHolderName == undefined || this.riskObj.polHolderName == ""))
            this.setClientInfo();
        if (this.riskObj.polHolderOccupationDesc == "" || this.riskObj.polHolderOccupationDesc == undefined) {
            this.pupulateOccupationDescription(this.riskObj.polHolderOccupationCode);
        }
        //if(!(this.riskObj.renewalBonusPercentage == undefined || this.riskObj.renewalBonusPercentage == '')){
        if (parseFloat("" + this.riskObj.renewalBonusPercentage) > 0) {
            this.disableRenewalBonusAmount = "Y";
        }
        //if(!(this.riskObj.renewalBonusAmount == undefined || this.riskObj.renewalBonusAmount == '')){
        if (parseFloat("" + this.riskObj.renewalBonusAmount) > 0) {
            this.disableRenewalBonusPercentage = "Y";
        }

        this._appUtilService.isUnderWriterUser().subscribe((data) => {
            this.isUnderWriter = data;
            this.setRIMethodEditableFlag();
        });

        //SST Code
        if (["MyTasks", "MyDrafts"].indexOf(this._activatedRoute.snapshot.params['component']) >= 0 || Object.keys(this._activatedRoute.snapshot.params).length == 0) {
            let respObj = this._bmsUtilService.getTAXDetails();
            if (respObj != undefined && respObj != "") {
                this.headerInfo.SSTTaxRate = Number(respObj[0].old.ITEMPF.GST);
                this.headerInfo.GSTTaxRate = Number(respObj[1].old.ITEMPF.GST);

                this.riskObj.SST = Number(this.headerInfo.SSTTaxRate);
                this.riskObj.GST = Number(this.headerInfo.GSTTaxRate);
            }

            this.headerInfo = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo;
            this.riskObj.SSTLiveDate = (this.riskObj.SSTLiveDate == undefined) ? this.headerInfo.SSTLiveDate : this.riskObj.SSTLiveDate;
            if (this.riskObj.SSTLiveDate == undefined || this.riskObj.SSTLiveDate == "") {
                let tempRespObj = this._bmsUtilService.getLiveDate();
                this.riskObj.GSTLiveDate = tempRespObj[0].old.ITEMPF.LIVEDATE;
                this.riskObj.SSTLiveDate = tempRespObj[1].old.ITEMPF.LIVEDATE;
                if (this.headerInfo.SSTLiveDate == undefined || this.headerInfo.SSTLiveDate == "") {
                    this.headerInfo.SSTLiveDate = this.riskObj.SSTLiveDate;
                }
                if (this.headerInfo.GSTLiveDate == undefined || this.headerInfo.GSTLiveDate == "") {
                    this.headerInfo.GSTLiveDate = this.riskObj.GSTLiveDate;
                }
            }
            if (moment(this.headerInfo.effectiveDate, "YYYY-MM-DD").format("YYYYMMDD") >= moment(this.riskObj.SSTLiveDate, "YYYY-MM-DD").format("YYYYMMDD")) {
                this.riskObj.isGSTApplicable = false;
            } else {
                this.riskObj.isGSTApplicable = true;
            }
        }
        //End
    }
    onRenewalBonusPercentageChange(evt) {
        if (parseFloat("" + evt.target.value) > 0) {
            if (this.renewalBonusAmountCtrl != null)
                this.renewalBonusAmountCtrl.setDisable("Y", this.renewalBonusAmountCtrl.comp);
        } else {
            if (this.renewalBonusAmountCtrl != null)
                this.renewalBonusAmountCtrl.setDisable("N", this.renewalBonusAmountCtrl.comp);
        }
    }

    onRenewalBonusAmountChange(evt) {
        if (parseFloat("" + evt.target.value) > 0) {
            if (this.renewalBonusPercentageCtrl != null)
                this.renewalBonusPercentageCtrl.setDisable("Y", this.renewalBonusPercentageCtrl.comp);
        } else {
            if (this.renewalBonusPercentageCtrl != null)
                this.renewalBonusPercentageCtrl.setDisable("N", this.renewalBonusPercentageCtrl.comp);
        }
    }


    /****  Generic Handlers *****/
    handleError(response, status, errorText, prms) {
        prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, response.responseJSON.faultstring.text, 5000));
    }

    /**** Populate LOV's and other defaults ****/
    populateLOVs() {
        this.lovDropDownService.createLOVDataList(["Occupation", "Gender", "referralReasons", "referralAgeLimits"]);//GA001 ADDED ("referralReasons", "referralAgeLimits")
        /**MD001 */
        let occLOB = "ALL";
        let occTable = "T3644";
        let occNewSearchFilterNodes: any[];

        if (this.headerInfo.lineOfBusiness == 'PA') {
            occLOB = 'PA';
            occTable = 'T9109';
            let occCodeFilter = (this.riskObj.riskType.length == 2) ? this.riskObj.riskType + ' ' : this.riskObj.riskType;
            let occCodeFilterDetails = [new SearchFilter("DESCITEM", occCodeFilter, "STARTSWITH", "AND")];
            occNewSearchFilterNodes = this.lovDropDownService.createFilter(occCodeFilterDetails);
        }
        //GA001 START
        let riskFilter = (this.riskObj.riskType.length == 2) ? this.riskObj.riskType + ' ' : this.riskObj.riskType;
        let referralAgeLimitNodes = this.lovDropDownService.createFilter([new SearchFilter("DESCITEM", riskFilter, "EQ", "AND")]);
        //GA001 END
        /**MD001 End Here */
        let lovFields = [
            new LOV_Field("ALL", "MOTOR", "NEW BUSINESS", "ALL", "NEW", "NAMED_DRIVER", "Sex", "LOV", [], "DESCPF", "Gender", null),
            new LOV_Field("ALL", "MED", "ALL", "ALL", "ALL", "ALL", "Referral Reasons", "LOV", [], "DESCPF", "referralReasons", "callbackForReferralReasons"),
            new LOV_Field("ALL", "MED", "ALL", "ALL", "ALL", "ALL", "Referral Age Limits", "LOV", referralAgeLimitNodes, "T7253", "referralAgeLimits", "callbackReferralAgeLimits")
        ];//GA001 ADDED ("referralReasons", "referralAgeLimits")
        lovFields.push(new LOV_Field("ALL", occLOB, "NEW BUSINESS", "ALL", "NEW", "ALL", "Occupation", "LOV", occNewSearchFilterNodes, occTable, "Occupation", "occupationLOVCallBack"));
        this.lovDropDownService.util_populateLOV(lovFields, this);
    }
    occupationLOVCallBack(scopeObj) {
        let temp1 = scopeObj.lovDropDownService.lovDataList.Occupation;
        let temp2 = [{ "VALUE": "", "DESCRIPTION": "", "REFERREDRISK": "", "COMB_DESCRIPTION": "--Select Value--" }];
        scopeObj.lovDropDownService.lovDataList.Occupation = [].concat(temp2, temp1);
    }
    setClientInfo() {
        if (this.clientDetails.client.genericDetails.clienttype == 'P') {
            if (this.clientDetails.client.personalClientDetails) {
                this.riskObj.polHolderName = this.clientDetails.client.personalClientDetails.Name;
                this.riskObj.polHolderICBirthCert = this.clientDetails.client.personalClientDetails.NRICNo;
                //news5336Details.IdProofNo = this.clientDetails.client.personalClientDetails.IdNumber;
                //this.riskObj.polHolderDOB = this.clientDetails.client.personalClientDetails.dateOfBirth;
                this.riskObj.polHolderDOB = moment(this.clientDetails.client.personalClientDetails.dateOfBirth, "YYYYMMDD").format("YYYY-MM-DD");
                //news5336Details.maritalStatus = this.clientDetails.client.personalClientDetails.maritalStatus;
                this.riskObj.polHolderSex = this.clientDetails.client.personalClientDetails.gender;
                this.riskObj.polHolderOccupationCode = this.clientDetails.client.personalClientDetails.occupationCode;
                this.riskObj.polHolderOccupationDesc = this.clientDetails.client.personalClientDetails.occupationDescription == undefined ? this.clientDetails.client.personalClientDetails.occupationDescription : "";
                if (this.riskObj.polHolderOccupationDesc == "" || this.riskObj.polHolderOccupationDesc == undefined) {
                    this.pupulateOccupationDescription(this.riskObj.polHolderOccupationCode);
                    this.setOccDescForInsured(this.riskObj.polHolderOccupationCode);
                }
            }
        }
    }
    pupulateOccupationDescription(iOccCode) {
        let lob = "MOTOR";
        let occFieldValue = iOccCode;
        if (this.headerInfo.lineOfBusiness == 'PA') { //MD001
            lob = "PA";
            occFieldValue = (this.riskObj.riskType.length == 2) ? this.riskObj.riskType + ' ' : this.riskObj.riskType + "" + iOccCode;
        }
        let request: GetLOVData = new GetLOVData().getRequest('ALL', lob, 'NEW BUSINESS', 'ALL', 'NEW', 'NAMED_DRIVER', 'Occupation', 'LOV');
        request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        request.ADVANCE_CONFIG_XML.FILTERS = new Filter();

        request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push(
            { "@FIELD_NAME": 'DESCITEM', "@FIELD_VALUE": occFieldValue, '@OPERATION': 'EQ', '@CONDITION': 'AND' });
        this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.OccDescSuccessHandler, this.handleError, true, { comp: this });

    }
    OccDescSuccessHandler(response, prms) {
        let ary = [];
        let occDesc = "";
        if (response.tuple != null && !Array.prototype.isPrototypeOf(response.tuple)) {
            ary = [response.tuple];
        }
        else if (response.tuple != null) {
            ary = response.tuple;
        }
        for (let item of ary) {
            prms.comp.riskObj.polHolderOccupationDesc = (item.old.DESCPF.DESCRIPTION.length > 30) ? item.old.DESCPF.DESCRIPTION.substring(0, 30) : item.old.DESCPF.DESCRIPTION;
        }
    }
    populateBenefitCodes() {
        let request: GetLOVData = new GetLOVData().getRequest('ALL', 'ALL', 'NEW BUSINESS', 'ALL', 'NEW', 'S4857', 'BenefitCode', 'LOV');
        request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        request.ADVANCE_CONFIG_XML.FILTERS = new Filter();

        request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push(
            { "@FIELD_NAME": 'ITMFRM', "@FIELD_VALUE": moment(this.headerInfo.effectiveDate, "YYYY-MM-DD").format("YYYYMMDD"), '@OPERATION': 'LT', '@CONDITION': 'AND' },
            { "@FIELD_NAME": 'ITMTO', "@FIELD_VALUE": moment(this.headerInfo.effectiveDate, "YYYY-MM-DD").format("YYYYMMDD"), '@OPERATION': 'GT', '@CONDITION': 'AND' });
        this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.BenefitCodeSuccessHandler, this.handleError, true, { comp: this });
    }

    BenefitCodeSuccessHandler(response, prms) {
        let ary = [];

        if (response.tuple != null && !Array.prototype.isPrototypeOf(response.tuple)) {
            ary = [response.tuple];
        }
        else if (response.tuple != null) {
            ary = response.tuple;
        }
        prms.comp.benefitsList = [];
        for (let item of ary) {
            let vBenefit: LocalBenefits = {
                "VALUE": item.old.T4947.VALUE,
                "DESCRIPTION": item.old.T4947.DESCRIPTION,
                "ZCACCDTH": item.old.T4947.ZCACCDTH,
                "ZDOUIND": item.old.T4947.ZDOUIND,
                "ZEDUFND": item.old.T4947.ZEDUFND,
                "ZMEDIEXP": item.old.T4947.ZMEDIEXP,
                "ZPACCDTH": item.old.T4947.ZPACCDTH,
                "ZPHOSFND": item.old.T4947.ZPHOSFND,
                "ZPRE": item.old.T4947.ZPRE,
                "ZPRECHILD": item.old.T4947.ZPRECHILD,
                "ZREPEXP": item.old.T4947.ZREPEXP,
                "ZSACCDTH": item.old.T4947.ZSACCDTH,
                "ZSHOSFND": item.old.T4947.ZSHOSFND
            };
            prms.comp.benefitsList.push(vBenefit);
            if (prms.comp.riskObj.benefitCode == item.old.T4947.VALUE) {
                prms.comp.selectedBenefit = vBenefit;
            }
        }
    }
    /**** Data Validations ****/
    testFunction(e) {
        debugger;
    }
    rateMinMaxValidation(cover) {
        if (cover.additionalLoading >= 0 && cover.additionalLoading <= 100) {
            this.setAdditionalPremiumForEach(cover);
            this.getAdditionalPremiumTotal();
            this.setTotalPremium();
        } else {
            cover.additionalLoading = 0;
            this.setAdditionalPremiumForEach(cover);
            this.getAdditionalPremiumTotal();
            this.setTotalPremium();
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Rate Should be between 0 and 100 only", 5000));
        }
    }
    calculateAge(dob) {
        let calAge: number = 0;
        if (dob != null && dob != "") {
            //let curDate = moment(new Date().toISOString(), "YYYY-MM-DD"); old code
            //let curDate=moment(BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.effectiveDate, "YYYY-MM-DD");
            //let date = moment(dob,"YYYYMMDD").format("YYYY-MM-DD");
            let dobYear = moment(dob, "YYYYMMDD").format("YYYY");
            let POIYear = moment(BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.effectiveDate, "YYYYMMDD").format("YYYY");
            calAge = POIYear - dobYear;
            //calAge = curDate.diff(date, 'year');
        }
        else
            calAge = 0;
        return calAge;
    }

    setPolHolderAge() {
        this.riskObj.polHolderAge = this.calculateAge(this.riskObj.polHolderDOB);
        this.checkRefferedRisksConditions("");//GA001     
    }
    validatePolHolderDOB(value) {
        if (value != null && value != "") {
            let curDate = moment().format("YYYYMMDD");
            if (Number(curDate) <= Number(moment(value, "YYYY-MM-DD").format("YYYYMMDD"))) {
                this.PolHolderDOBCtrl.setter("EMPTY", "YYYY-MM-DD", this.PolHolderDOBCtrl.comp);
                this.riskObj.polHolderDOB = "";
                this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Insured Date of Birth can not be future date.", 5000));
            }
            else {
                this.PolHolderDOBCtrl.setter(value, "YYYY-MM-DD", this.PolHolderDOBCtrl.comp);
                this.checkReferredRisk(this);
            }
        }

    }
    setSpouseAge() {
        this.riskObj.spouseAge = this.calculateAge(this.riskObj.spouseDOB);
        if (this.riskObj.spouseAge > 0) { //GA001 START
            this.checkRefferedRisksConditions("");
        }//End
    }
    validateSpouseDOB(value) {
        if (value != null && value != "") {
            let curDate = moment().format("YYYYMMDD");
            if (Number(curDate) <= Number(moment(value, "YYYY-MM-DD").format("YYYYMMDD"))) {
                this.SpouseDOBCtrl.setter("EMPTY", "YYYY-MM-DD", this.SpouseDOBCtrl.comp);
                this.riskObj.spouseDOB = "";
                this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Spouse Date of Birth can not be future date.", 5000));
            } else {
                this.riskObj.spouseDOB = value;
                this.SpouseDOBCtrl.setter(value, "YYYY-MM-DD", this.SpouseDOBCtrl.comp);
                this.checkReferredRisk(this);
            }
        }

    }

    setChildAge(idx) {
        this.riskObj.childrenDetails.children[idx].insuredAge = this.calculateAge(this.riskObj.childrenDetails.children[idx].DOB);
        if (this.riskObj.childrenDetails.children[idx].DOB != null && this.riskObj.childrenDetails.children[idx].DOB != "" && this.riskObj.childrenDetails.children[idx].insuredAge > 24) {
            this.riskObj.childrenDetails.children[idx].DOB = "";
            this.ChildDOBCtrl[idx].setter("EMPTY", "YYYY-MM-DD", this.ChildDOBCtrl[idx].comp);
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Child Age Cannot be more than 24 for child-" + (idx = 1) + ".", 5000));
        }
    }

    validateChildDOB(value, idx) {
        if (value != null && value != "") {
            let curDate = moment().format("YYYYMMDD");
            this.riskObj.childrenDetails.children[idx].insuredAge = this.calculateAge(this.riskObj.childrenDetails.children[idx].DOB);
            if (Number(curDate) <= Number(moment(value, "YYYY-MM-DD").format("YYYYMMDD"))) {
                this.riskObj.childrenDetails.children[idx].DOB = "";
                this.ChildDOBCtrl[idx].setter("EMPTY", "YYYY-MM-DD", this.ChildDOBCtrl[idx].comp);
                this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Child Date of Birth can not be future date for Child No-" + (idx + 1) + ".", 5000));
                return;
            } else if (this.riskObj.childrenDetails.children[idx].DOB != null && this.riskObj.childrenDetails.children[idx].DOB != "" && this.riskObj.childrenDetails.children[idx].insuredAge > 24) {
                this.riskObj.childrenDetails.children[idx].DOB = "";
                this.ChildDOBCtrl[idx].setter("EMPTY", "YYYY-MM-DD", this.ChildDOBCtrl[idx].comp);
                this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Child Age Cannot be more than 24 for child-" + (idx + 1) + ".", 5000));
                return;
            }
            else {
                this.ChildDOBCtrl[idx].setter(value, "YYYY-MM-DD", this.ChildDOBCtrl[idx].comp);
                //this.checkReferredRisk(this);
                this.checkRefferedRisksConditions(idx);//GA001   
            }
        }

    }


    /**** Premium Calculations ****/
    setFinalSI() {
        if (this.isLeastPreferredRI()) {
            this.riskObj.isLeastPreferred = "Y";
        }
        else {
            this.riskObj.isLeastPreferred = "N";
        }
        this.riskObj.capitalSumInsured = this.riskObj.totalSI;

        this.validateCapitalSumInsured();
    }
    isLeastPreferredRI() {
        if (this.riskObj.RIRetentionCode != null) {
            if (this.leastPreferredRI.indexOf(this.riskObj.RIRetentionCode) != -1) {
                return true;
            }
        }
        return false;
    }
    getCapitalSumInsured(e) {
        this.selectedBenefit = e.record;
        this.riskObj.capitalSumInsured = e.record.ZPACCDTH;
        //this.setAdditionalPremiumForEach(cover);
        this.calculateBsicPremium();
        this.resetAdditionalPremiumForEach();
    }
    calculateBsicPremium() {
        if (this.riskObj.childrenDetails.children.length > 3) {
            this.riskObj.basicPremium = numeral().unformat((numeral().unformat(this.selectedBenefit.ZPRECHILD) * numeral().unformat(this.riskObj.childrenDetails.children.length - 3)) + numeral().unformat(this.selectedBenefit.ZPRE));
        } else {
            this.riskObj.basicPremium = numeral().unformat(this.selectedBenefit.ZPRE);
        }
        this.getAdditionalPremiumTotal();
        this.setTotalPremium();
    }
    setRebateAmount() {
        let rebatePercent = 0;
        if (this.riskObj.rebate != undefined && Number(this.riskObj.rebate) <= 25) {
            rebatePercent = numeral().unformat(this.riskObj.rebate);
            let tempAmount = numeral().unformat(this.riskObj.totalPremium);
            this.riskObj.rebateAmount = Number(tempAmount * (rebatePercent / 100));
            this.riskObj.rebateAmount = numeral(this.riskObj.rebateAmount).format('0.00');
        }
    }

    setTotalPremium() {
        this.riskObj.totalPremium = numeral().unformat(this.riskObj.basicPremium) + numeral().unformat(this.riskObj.addditionalPremium);
        this.riskObj.originalTotalPremium = numeral().unformat(this.riskObj.basicPremium) + numeral().unformat(this.riskObj.addditionalPremium);
        this.setRebateAmount();
        this.riskObj.discountedPremium = numeral().unformat(this.riskObj.totalPremium) - numeral().unformat(this.riskObj.rebateAmount);
        //this.riskObj.discountedPremium = numeral().unformat(this.riskObj.basicPremium) + numeral().unformat(this.riskObj.addditionalPremium);       
        //this.riskObj.gstAmount = 0;//Number(this.riskObj.discountedPremium / 100 * 6); //SAF MYS-2018-0629
        //SST Code
        let tempGSTAmount = (Number(this.riskObj.GST) > 0) ? numeral(numeral((this.riskObj.discountedPremium * Number(this.riskObj.GST)) / 100).format(this.premiumFormat)).value() : 0;
        this.riskObj.gstAmount = (tempGSTAmount > 0) ? numeral(numeral(BMSUtilService.calculatePremiumAmount(tempGSTAmount, "G")).format(this.premiumFormat)).value() : 0;

        let tempSSTAmount = (Number(this.riskObj.SST) > 0) ? numeral(numeral((this.riskObj.discountedPremium * Number(this.riskObj.SST)) / 100).format(this.premiumFormat)).value() : 0;
        this.riskObj.sstAmount = (tempSSTAmount > 0) ? numeral(numeral(BMSUtilService.calculatePremiumAmount(tempSSTAmount, "S")).format(this.premiumFormat)).value() : 0;

        //this.riskObj.totalPremium = numeral().unformat(this.riskObj.discountedPremium) + numeral().unformat(this.riskObj.gstAmount);
        this.riskObj.totalPremium = numeral().unformat(this.riskObj.discountedPremium) + numeral().unformat(this.riskObj.gstAmount) + + numeral().unformat(this.riskObj.sstAmount);
        this.riskObj.sstAmount = numeral(this.riskObj.sstAmount).format('0.00');
        //End
        this.riskObj.gstAmount = numeral(this.riskObj.gstAmount).format('0.00');
        this.riskObj.totalPremium = numeral(this.riskObj.totalPremium).format('0.00');
        this.onPremiumChange.emit(this.riskObj.totalPremium);
    }

    /*** Handle Children (Insured) addition and removal ****/
    removeInsured(idx: number) {
        this.riskObj.childrenDetails.children.splice(idx, 1);
        this.resetItemNumber();
        this.calculateBsicPremium();
        this.ChildDOBCtrl.splice(idx, 1);
        this.checkRefferedRisksConditions(idx);//GA001   
    }
    //Add Child
    addNewChild() {
        if (this.riskObj.benefitCode == undefined || this.riskObj.benefitCode == "") {
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Select Benefit before adding child", 5000));
            return false;
        }

        if (this.riskObj.childrenDetails.children.length < 15) {
            let vInsured = new S4857Children();
            this.riskObj.childrenDetails.children.push(vInsured);
            this.resetItemNumber();
            this.calculateBsicPremium()
        } else {
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Maximum of 15 children only allowed.", 5000));
        }
    }
    resetItemNumber() {
        for (let _insured of this.riskObj.childrenDetails.children) {
            let index = this.riskObj.childrenDetails.children.indexOf(_insured);
            _insured.itemNo = (index + 1);
        }
        this.riskObj.noOfChildren = this.riskObj.childrenDetails.children.length;
    }

    /*****Handling Risk Classification based on Occupation ****/
    setOccDescForInsured(vOccupationCode) {
        let lob = "ALL";
        let occFieldValue = vOccupationCode;
        if (this.headerInfo.lineOfBusiness == 'PA') { //MD001
            lob = "PA";
            occFieldValue = (this.riskObj.riskType.length == 2) ? this.riskObj.riskType + ' ' : this.riskObj.riskType + "" + vOccupationCode;
        }
        let request: GetLOVData = new GetLOVData().getRequest('ALL', lob, 'NEW BUSINESS', 'ALL', 'NEW', 'ALL', 'Occupation', 'LOV');
        request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        request.ADVANCE_CONFIG_XML.FILTERS = new Filter();

        request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({ "@FIELD_NAME": 'DESCITEM', "@FIELD_VALUE": occFieldValue, '@OPERATION': 'EQ', '@CONDITION': 'AND' });
        this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.occupationSuccessHandlerForInsured, this.handleError, true, { comp: this });
    }

    occupationSuccessHandlerForInsured(response, prms) {
        //prms.comp.riskObj.occupationDescription = response.tuple.old.T3644.DESCRIPTION;
        //prms.comp.riskObj.occRiskClassification = "";
        if (response.tuple) {
            let referedRisk = '';
            if (prms.comp.headerInfo.lineOfBusiness == 'PA')// MD001: Occupations of all PA products are read from T9109
                referedRisk = response.tuple.old.T9109.REFERREDRISK;
            else
                referedRisk = response.tuple.old.T3644.REFERREDRISK;

            if (referedRisk == '' || referedRisk == 'N') {
                prms.comp.riskObj.insuredOccRiskClassification = "Standard";
            }
            else if (referedRisk == 'Y') {
                prms.comp.riskObj.insuredOccRiskClassification = "Referred";
            }
            else if (referedRisk == 'D') {
                prms.comp.riskObj.insuredOccRiskClassification = "Declined";
            }
        }
        //prms.comp.riskObj.riskClassification = prms.comp.riskObj.symRiskClassification;
        //prms.comp.riskObj.occRiskClassification = prms.comp.riskObj.symRiskClassification;
        prms.comp.checkReferredRisk(prms.comp);
    }
    setOccDescForSpouse(evt, vOccupationCode) {
        if (evt.record)
            this.riskObj.spouseOccupationDesc = (evt.record.DESCRIPTION.length > 30) ? evt.record.DESCRIPTION.substring(0, 29) : evt.record.DESCRIPTION;
        else
            this.riskObj.spouseOccupationDesc = "";
        if (vOccupationCode == undefined || vOccupationCode == "") {
            this.riskObj.spouseOccRiskClassification = "Standard";
            this.checkReferredRisk(this);
        } else {
            let lob = "ALL";
            let occFieldValue = vOccupationCode;
            if (this.headerInfo.lineOfBusiness == 'PA') { //MD001
                lob = "PA";
                occFieldValue = (this.riskObj.riskType.length == 2) ? this.riskObj.riskType + ' ' : this.riskObj.riskType + "" + vOccupationCode;
            }
            let request: GetLOVData = new GetLOVData().getRequest('ALL', lob, 'NEW BUSINESS', 'ALL', 'NEW', 'ALL', 'Occupation', 'LOV');
            request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
            request.ADVANCE_CONFIG_XML.FILTERS = new Filter();
            request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({ "@FIELD_NAME": 'DESCITEM', "@FIELD_VALUE": occFieldValue, '@OPERATION': 'EQ', '@CONDITION': 'AND' });
            this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.occupationSuccessHandlerForSpouse, this.handleError, true, { comp: this });
        }
    }

    occupationSuccessHandlerForSpouse(response, prms) {
        //prms.comp.riskObj.occupationDescription = response.tuple.old.T3644.DESCRIPTION;
        //prms.comp.riskObj.occRiskClassification = "";
        if (response.tuple) {
            let referedRisk = '';
            if (prms.comp.headerInfo.lineOfBusiness == 'PA')// MD001: Occupations of all PA products are read from T9109
                referedRisk = response.tuple.old.T9109.REFERREDRISK;
            else
                referedRisk = response.tuple.old.T3644.REFERREDRISK;

            if (referedRisk == '' || referedRisk == 'N') {
                prms.comp.riskObj.spouseOccRiskClassification = "Standard";
            }
            else if (referedRisk == 'Y') {
                prms.comp.riskObj.spouseOccRiskClassification = "Referred";
            }
            else if (referedRisk == 'D') {
                prms.comp.riskObj.spouseOccRiskClassification = "Declined";
            }
        } else {
            prms.comp.riskObj.spouseOccRiskClassification = "Standard";
        }
        //prms.comp.riskObj.riskClassification = prms.comp.riskObj.symRiskClassification;
        //prms.comp.riskObj.occRiskClassification = prms.comp.riskObj.symRiskClassification;
        prms.comp.checkReferredRisk(prms.comp);
    }

    setOccDescForChild(evt, vOccupationCode, childIndex) {
        if (evt.record)
            this.riskObj.childrenDetails.children[childIndex].occupationDescription = (evt.record.DESCRIPTION.length > 30) ? evt.record.DESCRIPTION.substring(0, 29) : evt.record.DESCRIPTION;
        else
            this.riskObj.childrenDetails.children[childIndex].occupationDescription = "";

        if (vOccupationCode == undefined || vOccupationCode == "") {
            this.riskObj.childrenDetails.children[childIndex].childOccRiskClassification = "Standard";
            this.checkReferredRisk(this);
        } else {
            let lob = "ALL";
            let occFieldValue = vOccupationCode;
            if (this.headerInfo.lineOfBusiness == 'PA') { //MD001
                lob = "PA";
                occFieldValue = (this.riskObj.riskType.length == 2) ? this.riskObj.riskType + ' ' : this.riskObj.riskType + "" + vOccupationCode;
            }
            let request: GetLOVData = new GetLOVData().getRequest('ALL', lob, 'NEW BUSINESS', 'ALL', 'NEW', 'ALL', 'Occupation', 'LOV');
            request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
            request.ADVANCE_CONFIG_XML.FILTERS = new Filter();
            request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({ "@FIELD_NAME": 'DESCITEM', "@FIELD_VALUE": occFieldValue, '@OPERATION': 'EQ', '@CONDITION': 'AND' });
            this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.occupationSuccessHandlerForSpecificChild, this.handleError, true, { comp: this, childIndex: childIndex });

        }

    }
    occupationSuccessHandlerForSpecificChild(response, prms) {
        //prms.comp.riskObj.childrenDetails.children[prms.childIndex].occupationDescription=response.tuple.old.T3644.DESCRIPTION;
        if (response.tuple) {
            let referedRisk = '';
            if (prms.comp.headerInfo.lineOfBusiness == 'PA')// MD001: Occupations of all PA products are read from T9109
                referedRisk = response.tuple.old.T9109.REFERREDRISK;
            else
                referedRisk = response.tuple.old.T3644.REFERREDRISK;

            if (referedRisk == '' || referedRisk == 'N') {
                prms.comp.riskObj.childrenDetails.children[prms.childIndex].childOccRiskClassification = "Standard";
            }
            else if (referedRisk == 'Y') {
                prms.comp.riskObj.childrenDetails.children[prms.childIndex].childOccRiskClassification = "Referred";
            }
            else if (referedRisk == 'D') {
                prms.comp.riskObj.childrenDetails.children[prms.childIndex].childOccRiskClassification = "Declined";
            }

        }
        prms.comp.checkReferredRisk(prms.comp);

    }

    checkReferredRisk(comp) {
        this.riskClassificationService.setRiskClassification(comp.riskObj.riskNumber, "N", "", "").subscribe();
        /* if (comp.isItInAgeRange() == true) {
             comp.riskObj.symRiskClassification = "Referred"
             comp.riskObj.riskClassification = comp.riskObj.symRiskClassification;
 
         } else {
             let isAnyChildReferred = false;
             let isAnyChildDeclined = false;
             for (let child of comp.riskObj.childrenDetails.children) {
                 if (child.childOccRiskClassification == "Referred") {
                     isAnyChildReferred = true;
                     break;
                 }
                 if (child.childOccRiskClassification == "Declined") {
                     isAnyChildDeclined = true;
                     break;
                 }
             }
             //check if insured classification is referred
             if (isAnyChildReferred || comp.riskObj.insuredOccRiskClassification == "Referred" ||
                 comp.riskObj.spouseOccRiskClassification == "Referred") {
 
                 comp.riskObj.symRiskClassification = "Referred";
 
             } else if (isAnyChildDeclined || comp.riskObj.insuredOccRiskClassification == "Declined" ||
                 comp.riskObj.spouseOccRiskClassification == "Declined") {
 
                 comp.riskObj.symRiskClassification = "Declined";
 
             } else {
                 comp.riskObj.symRiskClassification = "Standard";
 
             }
         }
         comp.riskObj.riskClassification = comp.riskObj.symRiskClassification;
         comp.setRiskClassification(comp);*/
    }

    setRiskClassification(comp) {
        comp.riskClassificationService.setRiskClassification(comp.riskObj.riskNumber, "N", "", "").subscribe((support) => {
            if (support == "NS") {
                if (comp.riskObj.symRiskClassification != null && comp.riskObj.symRiskClassification != "" && (comp.riskObj.symRiskClassification == "Referred" || comp.riskObj.symRiskClassification == "Declined")) {
                    let statusTxt = (comp.riskObj.symRiskClassification != null && comp.riskObj.symRiskClassification != "") ? comp.riskObj.symRiskClassification : comp.riskObj.riskClassification;
                    comp.riskObj.riskClassificationReason = "System marked as " + statusTxt;
                }
                else {
                    if (comp.riskObj.riskClassificationReason != null && comp.riskObj.riskClassificationReason != "" && (comp.riskObj.riskClassificationReason != "System marked as Standard"
                        && comp.riskObj.riskClassificationReason.indexOf("System marked as ") != -1)) {
                        comp.riskObj.riskClassificationReason = "";
                    }
                }
                comp.onRiskClsChange.emit('');
            }

            if (comp.riskObj.symRiskClassification == null || comp.riskObj.symRiskClassification == '' || comp.riskObj.symRiskClassification == 'Standard') {
                comp.riskObj.riskClassificationReason = "";
            }
        });
    }

    changeRiskClassification(event) {
        this.riskObj.riskClassification = event.target.value;
        this.onRiskClsChange.emit('');
    }
    isItInAgeRange() {
        //Age above 70 to be treated as Referred
        if (Number(this.riskObj.polHolderAge) > 70 || Number(this.riskObj.spouseAge) > 70) {
            return true;
        }
        else {
            return false;
        }
    }


    /*****Handling Risk Classification based on Occupation Ends here****/


    openAdditionalCoverageDetailsDialog() {
        if (this.riskObj.benefitCode == undefined || this.riskObj.benefitCode == "") {
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Select Benefit before adding additional cover.", 5000));
            return false;
        }
        let searchInput = new SearchInput();
        searchInput.isSingleSelect = false;
        searchInput.BRANCH = 'ALL';
        searchInput.BUSINESS_FUNCTION = 'NEW BUSINESS';
        searchInput.FIELD_TYPE = 'LOOKUP';
        searchInput.FORM_FIELD_NAME = 'Additional Coverage';
        searchInput.FORM_NAME = 'ALL';
        searchInput.LOB = 'ALL';
        searchInput.OPERATION = 'NEW';
        searchInput.PRODUCT = 'ALL';

        if (this.riskObj.additionalCoverDetails.additionalCover.length > 0) {
            let newArr = [];
            for (let item of this.riskObj.additionalCoverDetails.additionalCover) {
                newArr = newArr.concat(item["additionalCode"]);
            }
            let additionalCoverCodes = "'" + newArr.toString().replace(/,/g, "\',\'") + "'";
            searchInput.condition = { "A.DESCITEM": additionalCoverCodes };
        }
        else
            searchInput.condition = { "A.DESCITEM": "''" };

        let input = new ModalInput().get("GenericSearchComponent");
        input.datainput = searchInput;
        input.outputCallback = this.addAdditionalCoverage;
        input.containerRef = this.contentArea;
        input.parentCompPRMS = { comp: this };
        input.heading = "Additional Cover Details";
        input.icon = "fa fa-file-pdf-o";
        this.dcl.openLookup(input);
    }
    setClauses(clausesList, flag) {
        if (this.clausesComp)
            this.clausesComp.addClause(clausesList, '', flag);
    }
    setLoadAndPremium() {
        /*let rebatePercent = 0;
        if(this.riskObj.rebate != undefined && Number(this.riskObj.rebate) <= 25) {
            rebatePercent = numeral().unformat(this.riskObj.rebate);
            let tempAmount = numeral().unformat(this.riskObj.basicPremium) + numeral().unformat(this.riskObj.addditionalPremium);
            this.riskObj.rebateAmount = Number(tempAmount * (rebatePercent/100));
            this.riskObj.rebateAmount = numeral(this.riskObj.rebateAmount).format('0.00');
        }*/
        this.setTotalPremium();
    }

    deleteClause(ary, clauseCode, prop) {
        let val = undefined;
        if (ary.length > 0) {
            for (var index = 0, assoLength = ary.length; index < assoLength; index++) {
                if (ary[index][prop] != null && ary[index][prop] != "" && ary[index][prop] == clauseCode) {
                    val = index;
                    break;
                }
            }
        }
        if (val != undefined)
            this.clausesComp.removeClause(val, clauseCode);
    }
    getTotalByProperty(prop, ary) {
        let total = numeral(0);
        for (let eachItem of ary) {
            if (eachItem[prop] != null && eachItem[prop] != "")
                total = total.add(numeral().unformat(eachItem[prop]));
        }
        total = numeral(total).format('0.00');
        return total;
    }

    addAdditionalCoverage(listOfAdditionalCoverage, prms) {
        for (let eachCover of listOfAdditionalCoverage) {
            let adcover = new AdditionalCoverage();
            adcover.additionalCode = eachCover.old.DESCPF.VALUE;
            adcover.additionalCover = eachCover.old.DESCPF.LONGDESC;
            prms.comp.riskObj.additionalCoverDetails.additionalCover.push(adcover);
            prms.comp.setClauses([eachCover.old.DESCPF.VALUE], false);
        }
    }
    getAdditionalPremiumTotal() {
        let total = this.getTotalByProperty("addditionalPremium", this.riskObj.additionalCoverDetails.additionalCover);
        this.riskObj.addditionalPremium = total;
        return total;
    }
    setAdditionalPremiumForEach(coverage) {
        let rate = (coverage.additionalLoading == null || coverage.additionalLoading == "") ? 0 : coverage.additionalLoading;
        coverage.addditionalPremium = (numeral().unformat(this.riskObj.basicPremium) * (numeral().unformat(rate) * 0.01));
        coverage.addditionalPremium = numeral(coverage.addditionalPremium).format('0.00');
    }

    resetAdditionalPremiumForEach() {
        for (let adCover of this.riskObj.additionalCoverDetails.additionalCover) {
            this.setAdditionalPremiumForEach(adCover);
        }
        this.getAdditionalPremiumTotal();
        this.setLoadAndPremium();
        this.setTotalPremium();
    }
    removeAdditionalCover(idx: number) {
        let addnlCover = this.riskObj.additionalCoverDetails.additionalCover[idx];
        this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Deleted Benefit Successfully : " + addnlCover.additionalCode, 5000));
        this.riskObj.additionalCoverDetails.additionalCover.splice(idx, 1);
        //this.deleteClause(this.riskObj.clauses.clause, addnlCover.additionalCode, "clauseCode");
        this.resetAdditionalPremiumForEach();
    }

    setRIMethod(val) {

        this.riskObj.RIMethod = (val == "Yes") ? "8" : this.riskObj.RIMethodSys;

        if (this.isUnderWriter == "Y" || val == "Yes")
            this.riskObj.isRIOverWrittenByUW = "Y";
        else if (val == "No") {
            this.riskObj.isRIOverWrittenByUW = "N";
            this.validateCapitalSumInsured();
        }
        this._riService.setRI().subscribe();
    }

    validateCapitalSumInsured() {
        if (this.riskObj.RIRetentionCode && this.riskObj.isRIOverWrittenByUW == 'N') {
            this._bmsUtilService.getTotalGrossCapacity(this.riskObj.RIRetentionCode).subscribe((data) => this.compareSIWithTotGrossCap(data));
        }
        else
            this.setRIMethodEditableFlag();
    }

    compareSIWithTotGrossCap(totGrossCap) {

        let _totalGrossCapacity = (!totGrossCap) ? 0 : parseFloat("" + totGrossCap);
        this.riskObj.totalGrossCapacity = _totalGrossCapacity;
        let _capitalSumInsured = parseFloat("" + this.riskObj.capitalSumInsured);

        if (_totalGrossCapacity > 0 && _capitalSumInsured > _totalGrossCapacity && (this.riskObj.RIMethod == null || this.riskObj.RIMethod == "" || parseFloat("" + this.riskObj.RIMethod) != 8)) {
            this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Capital Sum Insured greater than Total Gross Capacity: " + _totalGrossCapacity + ",  RI is Required.", 10000));

            this.riskObj.RIRequired = "Yes";
            this.riskObj.RIMethod = "8";
        }
        else if (_capitalSumInsured <= _totalGrossCapacity) {
            this.riskObj.RIRequired = "No";
            this.riskObj.RIMethod = this.riskObj.RIMethodSys;
        }
        this._riService.setRI().subscribe();
        this.setRIMethodEditableFlag();
    }

    setRIMethodEditableFlag() {
        let _capitalSumInsured = parseFloat("" + this.riskObj.capitalSumInsured);
        let _totalGrossCapacity = parseFloat("" + this.riskObj.totalGrossCapacity);
        if (_totalGrossCapacity > 0 && _capitalSumInsured > _totalGrossCapacity && this.isUnderWriter == "N") {
            this.isRIMethodEditable = "N";
        }
        else {
            this.isRIMethodEditable = "Y";
        }
    }

    // Added below code for SAF MYS-2017-1108
    emitFlagChange() {
        this.onRtngFlgChange.emit("");
    }
    //GA001 START
    handleRiskClassification(comp) {

        if (comp.riskObj.symRiskClassification == "Declined")
            comp.riskObj.riskClassification = "Declined";
        else if (comp.riskObj.symRiskClassification == "Referred" || comp.riskObj.riRiskClassification == "Referred")
            comp.riskObj.riskClassification = "Referred";
        else if (comp.isManuallyReferred)
            comp.riskObj.riskClassification = "Referred";
        else
            comp.riskObj.riskClassification = "Standard";

        comp.setRiskClassification(comp);
    }

    checkRefferedRisksConditions(idx) {
        let caseInfo = BMSConstants.getBMSCaseInfo();
        let _ageLimitRec = this.lovDropDownService.lovDataList.referralAgeLimits.find((_data) => _data.DESCITEM == this.riskObj.riskType);
        let _childRec = this.riskObj.childrenDetails.children[idx];
        this.checkReferredRiskConditions(this.riskObj, this.headerInfo.contractType, _ageLimitRec, this.lovDropDownService.lovDataList.Occupation, this.lovDropDownService.lovDataList.referralReasons, this.referralReasons, _childRec, caseInfo);

        if (this.riskObj.ageLimitFlag == "G" || this.riskObj.ageLimitFlag == "L") {
            this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Policyholder's age made this risk Referred.", 6000));
        }
        if (this.riskObj.spouseAgeLimitFlag == "G" || this.riskObj.spouseAgeLimitFlag == "L") {
            this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Spouse's age made this risk Referred.", 6000));
        }
        this.handleRiskClassification(this);
    }

    checkReferredRiskConditions(riskObj, contractType, _ageLimitRec, occCodeList, referralReasonList, selectableReasonsList, _childRec, caseInfo) {
        let _reasons = new Reasons();
        let isReferredRisk = false;
        let isDeclinedRisk: any = "false";

        // if(contractType=='HIG'){
        // isReferredRisk = true;
        // _reasons.reason.push("Referred Product.");
        // }

        if (riskObj.hasClaimExperience == 'Y') {
            isReferredRisk = true;
            _reasons.reason.push("With Claim Experience.");
            this.addReferralReason(riskObj, '11', true, referralReasonList, selectableReasonsList);
        }
        else {
            this.deleteReferralReason(riskObj, '11', true);
        }

        this.calculateAge(riskObj);

        riskObj.ageLimitFlag = "";
        riskObj.spouseAgeLimitFlag = "";
        if (_childRec) {
            _childRec.ageLimitFlag = "";
        }
        if (_ageLimitRec && (riskObj.polHolderDOB || riskObj.spouseDOB) && (riskObj.polHolderOccupationCode || riskObj.spouseOccupationCode)) {
            let _minAgeLimit = 0;
            let _maxAgeLimit = 0;
            let _childMinAgeLimit = 0;
            let _childMaxAgeLimit = 0;
            let _minAgeLimitInd = 'Y';
            let _maxAgeLimitInd = 'Y';
            let _childMinAgeLimitInd = 'Y';
            let _childMaxAgeLimitInd = 'Y';

            let _adultMinAgeLimit = (_ageLimitRec.ZAGELMT03) ? parseInt("" + _ageLimitRec.ZAGELMT03) : 0;
            let _adultMaxAgeLimit = 0;
            if ("Renewal" == caseInfo.businessFunction) {
                _adultMaxAgeLimit = (_ageLimitRec.ZAGELMT07) ? parseInt("" + _ageLimitRec.ZAGELMT07) : 0;
            } else {
                _adultMaxAgeLimit = (_ageLimitRec.ZAGELMT05) ? parseInt("" + _ageLimitRec.ZAGELMT05) : 0;
            }

            let _chidldMinAgeLimit = (_ageLimitRec.ZAGELMT04) ? parseInt("" + _ageLimitRec.ZAGELMT04) : 0;
            let _chidldMaxAgeLimit = (_ageLimitRec.ZAGELMT06) ? parseInt("" + _ageLimitRec.ZAGELMT06) : 0;


            if (_chidldMinAgeLimit > 0 && _chidldMaxAgeLimit > 0 && (_childRec && (_childRec.occupationCode == '7STU' || _childRec.occupationCode == '7CLD'))) {
                _childMinAgeLimit = _chidldMinAgeLimit;
                _childMaxAgeLimit = _chidldMaxAgeLimit;
                _childMinAgeLimitInd = (_ageLimitRec.ZAGEIND02) ? _ageLimitRec.ZAGEIND02 : "Y";
                _childMaxAgeLimitInd = (_ageLimitRec.ZAGEIND03) ? _ageLimitRec.ZAGEIND03 : "Y";
            }
            if (_adultMinAgeLimit > 0 && _adultMaxAgeLimit > 0) {

                _minAgeLimit = _adultMinAgeLimit;
                _maxAgeLimit = _adultMaxAgeLimit;
                if (_chidldMinAgeLimit == 0 || _chidldMaxAgeLimit == 0) {
                    _minAgeLimitInd = (_ageLimitRec.ZAGEIND02) ? _ageLimitRec.ZAGEIND02 : "Y";
                    _maxAgeLimitInd = (_ageLimitRec.ZAGEIND03) ? _ageLimitRec.ZAGEIND03 : "Y";
                }
            }

            if (_maxAgeLimitInd == 'D') {
                if (riskObj && riskObj.dateOfAttachment && riskObj.polHolderDOB) {
                    let _inclusionDate = moment(riskObj.dateOfAttachment, "YYYY-MM-DD");
                    let _insuredDOB = moment(riskObj.polHolderDOB, "YYYY-MM-DD");

                    let _ageInDays = moment.duration(_inclusionDate.diff(_insuredDOB)).asDays();
                    if (_ageInDays > 0 && _ageInDays > _maxAgeLimit) {
                        riskObj.ageLimitFlag = "G";
                    }
                }
                if (riskObj && riskObj.dateOfAttachment && riskObj.spouseDOB) {
                    let _inclusionDate = moment(riskObj.dateOfAttachment, "YYYY-MM-DD");
                    let _insuredDOB = moment(riskObj.spouseDOB, "YYYY-MM-DD");

                    let _ageInDays = moment.duration(_inclusionDate.diff(_insuredDOB)).asDays();
                    if (_ageInDays > 0 && _ageInDays > _maxAgeLimit) {
                        riskObj.spouseAgeLimitFlag = "G";
                    }
                }
            }
            else if (Number(riskObj.polHolderAge) > 0 && Number(riskObj.polHolderAge) > _maxAgeLimit) {
                riskObj.ageLimitFlag = "G";
            }
            if (Number(riskObj.spouseAge) > 0 && Number(riskObj.spouseAge) > _maxAgeLimit) {
                riskObj.spouseAgeLimitFlag = "G";
            }
            if (_childRec && Number(_childRec.insuredAge) > _childMaxAgeLimit) {
                _childRec.ageLimitFlag = "G";
            }

            if (riskObj.ageLimitFlag != "G" || riskObj.spouseAgeLimitFlag != "G" || (_childRec && _childRec.ageLimitFlag != "G")) {
                if (_minAgeLimitInd == 'D') {
                    if (riskObj && riskObj.dateOfAttachment && riskObj.polHolderDOB) {
                        let _inclusionDate = moment(riskObj.dateOfAttachment, "YYYY-MM-DD");
                        let _insuredDOB = moment(riskObj.polHolderDOB, "YYYY-MM-DD");

                        let _ageInDays = moment.duration(_inclusionDate.diff(_insuredDOB)).asDays();
                        if (_ageInDays > 0 && _ageInDays < _minAgeLimit) {
                            riskObj.ageLimitFlag = "L";
                        }
                    }
                    if (riskObj && riskObj.dateOfAttachment && riskObj.spouseDOB) {
                        let _inclusionDate = moment(riskObj.dateOfAttachment, "YYYY-MM-DD");
                        let _insuredDOB = moment(riskObj.spouseDOB, "YYYY-MM-DD");

                        let _ageInDays = moment.duration(_inclusionDate.diff(_insuredDOB)).asDays();
                        if (_ageInDays > 0 && _ageInDays < _minAgeLimit) {
                            riskObj.spouseAgeLimitFlag = "L";
                        }
                    }
                }
                if (_childMinAgeLimitInd == "D") { //GA001
                    if (_childRec && _childRec.DOB) {
                        let _inclusionDate = moment(riskObj.dateOfAttachment, "YYYY-MM-DD");
                        let _insuredDOB = moment(_childRec.DOB, "YYYY-MM-DD");
                        let _ageInDays = moment.duration(_inclusionDate.diff(_insuredDOB)).asDays();
                        if (_ageInDays > 0 && _ageInDays < _childMinAgeLimit) {
                            _childRec.ageLimitFlag = "L";
                        }
                    }
                }
                if (_minAgeLimitInd == "Y") {
                    if (Number(riskObj.polHolderAge) > 0 && Number(riskObj.polHolderAge) < _minAgeLimit) {
                        riskObj.ageLimitFlag = "L";
                    }
                    if (Number(riskObj.spouseAge) > 0 && Number(riskObj.spouseAge) < _minAgeLimit) {
                        riskObj.spouseAgeLimitFlag = "L";
                    }
                }
                if (_childMinAgeLimitInd == "Y" && _childRec && Number(_childRec.insuredAge) < _childMinAgeLimit) {
                    _childRec.ageLimitFlag = "L";
                }
            }

			/*if(Number(riskObj.insuredAge) > _maxAgeLimit) {
				isReferredRisk = true;
				riskObj.ageLimitFlag = "G";
				_reasons.reason.push("Insured Age greater than maximum allowed age "+_maxAgeLimit);
				
				this.addReferralReason(riskObj, '01', true, referralReasonList, selectableReasonsList);
			}
			else if(Number(riskObj.insuredAge) < _minAgeLimit) {
				
				riskObj.ageLimitFlag = "L";
			}
			else {
				riskObj.ageLimitFlag = "VALID";
			}*/

            if (riskObj.ageLimitFlag == "G") {
                isReferredRisk = true;
                _reasons.reason.push("Insured (" + riskObj.riskNumber + ") Age greater than maximum allowed age " + _maxAgeLimit);
                this.addReferralReason(riskObj, '01', true, referralReasonList, selectableReasonsList);
            }
            else if (riskObj.ageLimitFlag == "L") {
                isReferredRisk = true;
                _reasons.reason.push("Insured (" + riskObj.riskNumber + ") Age Less than minimum allowed age " + _minAgeLimit);
                this.addReferralReason(riskObj, '01', true, referralReasonList, selectableReasonsList);
            }
            else if (riskObj.ageLimitFlag == "") {
                riskObj.ageLimitFlag = "VALID";
            }

            if (riskObj.spouseAgeLimitFlag == "G") {
                isReferredRisk = true;
                _reasons.reason.push("Spouse's (" + riskObj.riskNumber + ") Age greater than maximum allowed age " + _maxAgeLimit);
                this.addReferralReason(riskObj, '01', true, referralReasonList, selectableReasonsList);
            }
            else if (riskObj.spouseAgeLimitFlag == "L") {
                isReferredRisk = true;
                _reasons.reason.push("Spouse's (" + riskObj.riskNumber + ") Age Less than minimum allowed age " + _minAgeLimit);
                this.addReferralReason(riskObj, '01', true, referralReasonList, selectableReasonsList);
            }
            else if (riskObj.spouseAgeLimitFlag == "") {
                riskObj.spouseAgeLimitFlag = "VALID";
            }
        }

        //if( riskObj.ageLimitFlag != 'G' ){
        //this.deleteReferralReason(riskObj, '01', true);
        /*let _ageRefReason = riskObj.referralReasons.referralReason.find((_data1)=> _data1.code=='01');
        if(_ageRefReason && _ageRefReason.isSysReferred == 'Y'){
            _ageRefReason.isSysReferred = 'N';
        }*/
        //}

		/* if(riskObj.polHolderOccupationCode){
			let _rec = occCodeList.find((_data)=> _data.VALUE == riskObj.polHolderOccupationCode);
						
			if(_rec && _rec.REFERREDRISK && _rec.REFERREDRISK=='Y'){
				isReferredRisk = true;
				riskObj.occRiskClassification="Referred";
				_reasons.reason.push("Occupation code of type Referred selected");
				this.addReferralReason(riskObj, '05', true, referralReasonList, selectableReasonsList);
			}
			else if(_rec && _rec.REFERREDRISK && _rec.REFERREDRISK=='D'){
				isDeclinedRisk = true;
				riskObj.occRiskClassification="Declined";
				_reasons.reason.push("Declined : Occupation code of type Declined selected");
			}
			else {
				riskObj.occRiskClassification="Standard";
			}
			
			if(riskObj.occRiskClassification != 'Referred'){
				this.deleteReferralReason(riskObj, '05', true);
				/*let _occRefReason = riskObj.referralReasons.referralReason.find((_data1)=> _data1.code=='05');
				if(_occRefReason && _occRefReason.isSysReferred == 'Y'){
					_occRefReason.isSysReferred = 'N';
				}*
			}			
		} */

        if (riskObj.referralReasons.referralReason && riskObj.referralReasons.referralReason.length > 0 && riskObj.referralReasons.referralReason.find((_data1) => _data1.isSysReferred != 'Y')) {
            isReferredRisk = true;
            _reasons.reason.push("Referral Reason added");
        }

        riskObj.riskClassificationReasons.reasons = _reasons;

        if (isDeclinedRisk == "true") {
            riskObj.symRiskClassification = "Declined";
        }
        else if (isReferredRisk == true) {
            riskObj.symRiskClassification = "Referred";
        }
        else riskObj.symRiskClassification = "Standard";

        // this.handleRiskClassification();
    }

    addReferralReason(riskObj, refCode, isSysRef, refrlReasonsList, selectableReflReasonsList) {

        let refReasonRecord = refrlReasonsList.find(_data => (_data.code === refCode));

        if (!refReasonRecord) {
            let _refReasons = [];
            let request: GetLOVData = new GetLOVData().getRequest('ALL', 'MED', 'ALL', 'ALL', 'ALL', 'ALL', 'Referral Reasons', 'LOV');
            request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
            request.ADVANCE_CONFIG_XML.FILTERS = new Filter();

            this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, null, null, false, null).success((data) => {
                if (data.tuple) {
                    if (Array.prototype.isPrototypeOf(data.tuple)) {
                        for (let _rec of data.tuple) {
                            _refReasons.push(_rec.old.DESCPF);
                        }
                    }
                    else if (data.tuple && data.tuple.old && data.tuple.old.DESCPF) {
                        _refReasons.push(data.tuple.old.DESCPF);
                    }
                }
            }).error((response, status, errorText) => {
                this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error while getting Referral Reasons ", 5000));
            });

            if (_refReasons && _refReasons.length > 0) {
                refReasonRecord = _refReasons.find(_data => (_data.code === refCode));
            }
        }

        if (refReasonRecord) {
            if (riskObj.referralReasons.referralReason && (riskObj.referralReasons.referralReason.length == 0 || !riskObj.referralReasons.referralReason.find((_data1) => _data1.code == refCode))) {
                let _referralReason = new ReferralReason();
                _referralReason.seqNumber = riskObj.referralReasons.referralReason.length + 1;
                _referralReason.code = refReasonRecord.code;
                _referralReason.description = refReasonRecord.description;
                _referralReason.isSysReferred = (isSysRef) ? 'Y' : 'N';

                riskObj.referralReasons.referralReason.push(_referralReason);

                // this.removeRefrlReasonFromSelectionList(refCode, selectableReflReasonsList);
            }
            else if (riskObj.referralReasons.referralReason && riskObj.referralReasons.referralReason.find((_data1) => _data1.code == refCode)) {
                let _refReason = riskObj.referralReasons.referralReason.find((_data1) => _data1.code == refCode);
                _refReason.isSysReferred = (isSysRef) ? 'Y' : 'N';

                // this.removeRefrlReasonFromSelectionList(refCode, selectableReflReasonsList);
            }
        }
    }

    removeRefrlReasonFromSelectionList(refCode, selectableReflReasonsList) {
        if (selectableReflReasonsList) {
            let _selectedRefReason = selectableReflReasonsList.find(item => item.code == refCode);
            if (_selectedRefReason) {
                selectableReflReasonsList.splice(selectableReflReasonsList.indexOf(_selectedRefReason), 1);
            }
        }
    }

    deleteReferralReason(riskObj, refCode, sysRef) {
        let refReasonRecord = riskObj.referralReasons.referralReason.find((_data1) => _data1.code == refCode);
        if (refReasonRecord && (!sysRef || (sysRef && refReasonRecord.isSysReferred == 'Y'))) {
            riskObj.referralReasons.referralReason.splice(riskObj.referralReasons.referralReason.indexOf(refReasonRecord), 1);
        }
    }

    callbackForReferralReasons(scopeObject) {
        for (let _refReason of scopeObject.lovDropDownService.lovDataList.referralReasons) {
            // let hasRefReason = scopeObject.referralReasons.some( _data => _data.code === _refReason.code );
            let hasRefReason = scopeObject.riskObj.referralReasons.referralReason.some(_data => _data.code == _refReason.code);
            if (!hasRefReason) {
                scopeObject.referralReasons.push(_refReason);
            }
        }
    }

    callbackReferralAgeLimits(scopeObject) {
        if (this.riskObj.polHolderAge == 0 || (!this.riskObj.ageLimitFlag && this.riskObj.polHolderDOB && this.riskObj.polHolderOccupationCode)) {
            this.checkRefferedRisksConditions("");
        }
    }
    //GA001 END
}

export class LocalBenefits {
    constructor(
        public VALUE: string,
        public DESCRIPTION: string,
        public ZCACCDTH: string,
        public ZDOUIND: string,
        public ZEDUFND: string,
        public ZMEDIEXP: string,
        public ZPACCDTH: string,
        public ZPHOSFND: string,
        public ZPRE: string,
        public ZPRECHILD: string,
        public ZREPEXP: string,
        public ZSACCDTH: string,
        public ZSHOSFND: string
    ) { }
}