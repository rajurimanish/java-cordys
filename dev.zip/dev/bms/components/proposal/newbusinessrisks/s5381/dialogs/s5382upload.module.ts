import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { S5382ServiceModule } from "../services/s5382.service.module";
import { S5382UploadComponent } from './s5382upload.component';

@NgModule({
    imports: [CommonModule, FormsModule, ReactiveFormsModule, S5382ServiceModule],
    declarations: [S5382UploadComponent],
    exports: [S5382UploadComponent]
})
export class S5382UploadModule { }