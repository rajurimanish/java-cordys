import { Component, ElementRef, OnInit, NgZone } from "@angular/core";
import { CordysSoapWService } from '../../../../../../common/components/utility/cordys-soap-ws';
import { LOV_Field, LOVDropDownService, SearchFilter } from "../../../../../../common/services/lovdropdown/lovdropdown.service";
import { ApplicationUtilService } from "../../../../../../common/services/application.util.service";
import { AlertMessagesService } from '../../../../../../common/components/utility/alertmessage/alertmessages.service';
import { AlertMessage } from '../../../../../../common/components/utility/alertmessage/alertmessages.model';
import { S5381, S5382ItemDetails, S5382Item, Benefit, BenefitItem } from '../appObjects/s5381';
import { S5382Service } from "../services/s5382.service";

declare var jQuery: any;
declare var moment: any;
declare var numeral: any;

@Component({
    selector: "s5382-upload-component",
    templateUrl: "app/bms/components/proposal/newbusinessrisks/s5381/dialogs/s5382upload.template.html",
    inputs: ['datainput', 'closeDialog', 'parentCompPRMS']
})
export class S5382UploadComponent implements OnInit {

    public datainput: any;
    public closeDialog: Function;
    public parentCompPRMS: any;

    private elementRef: ElementRef;
    private enableAttachmentError: boolean = false;
    private globalValidationMessage: string = "";
    private attachmentName;
    private attachmentSize: number;
    private type;
    private encodeFileContent: string;
    private fileName;
    public uploadedFiles = [];
    public uploadPath = "";
    public records: any;
    public disableButtons: boolean = false;
    public showRecordCountMessage: boolean = false;
    public recordCountMessage = "";
    public planCodeFilterStr = "";
    public areaCodeFilterStr = "";
    public occClassCodeFilterStr = "";
    public isValidationFailed: boolean = false;

    constructor(private _elRef: ElementRef, private lovDropDownService: LOVDropDownService, private _cordysService: CordysSoapWService, private _appUtilService: ApplicationUtilService, private _s5382Service: S5382Service, public _alertMsgService: AlertMessagesService) { }

    ngOnInit() {
        this.populateLOV();
        this.getUploadPath();
    }

    populateLOV() {
        this.lovDropDownService.createLOVDataList(["Salutation", "Occupation", "ratingClass", "Gender", "MaritalStatus", "nationality", "residence", "areaCode", "coverageCodes", "plans", "referralReasons", "referralAgeLimits"]);

        let riskType = this.parentCompPRMS.comp.riskObj.riskType;
        let effectiveDate = this.parentCompPRMS.comp.headerInfo.effectiveDate;

        let riskFilter = (riskType.length == 2) ? riskType + ' ' : riskType;

        let polEffectiveDate = ApplicationUtilService.getFormattedDate(effectiveDate, "YYYY-MM-DD", "YYYYMMDD");
        let planCodesFilterDetails = [new SearchFilter("DESCITEM", riskFilter, "STARTSWITH", "AND"),
        new SearchFilter("ITMFRM", polEffectiveDate, "LTEQ", "AND"),
        new SearchFilter("ITMTO", polEffectiveDate, "GTEQ", "AND")];
        let planCodesFilterNodes = this.lovDropDownService.createFilter(planCodesFilterDetails);

        let referralAgeLimitNodes = this.lovDropDownService.createFilter([new SearchFilter("DESCITEM", riskFilter, "EQ", "AND")]);

        let riskTypeFilterDetails = [new SearchFilter("DESCITEM", riskFilter, "STARTSWITH", "AND")];
        let riskTypeFilterNodes = this.lovDropDownService.createFilter(riskTypeFilterDetails);

        let lovFields = [
            new LOV_Field("ALL", "ALL", "ALL", "ALL", "ALL", "ALL", "Nationality", "LOV", [], "DESCPF", "nationality", null),
            new LOV_Field("ALL", "ALL", "ALL", "ALL", "ALL", "ALL", "AreaCode", "LOV", [], "DESCPF", "areaCode", null),
            new LOV_Field("ALL", "ALL", "ALL", "ALL", "ALL", "ALL", "Residence", "LOV", [], "DESCPF", "residence", null),
            new LOV_Field("ALL", "MED", "ALL", "ALL", "ALL", "ALL", "Coverage Codes", "LOV", [], "T7087", "coverageCodes", null),
            new LOV_Field("ALL", "MED", "ALL", "ALL", "ALL", "S5382", "Plans", "LOV", planCodesFilterNodes, "T7088", "plans", null),
            // new LOV_Field("ALL", "ALL", "NEW BUSINESS", "ALL", "NEW", "ALL", "Occupation", "LOV", [], "T3644", "Occupation", null),
            new LOV_Field("ALL", "MIS", "ALL", "ALL", "ALL", "ALL", "Occupation", "LOV", riskTypeFilterNodes, "T9109", "Occupation", null),
            new LOV_Field("ALL", "CLIENT", "ALL", "ALL", "NEW", "CLIENT_DETAILS", "Salutation", "LOV", [], "DESCPF", "Salutation", null),
            new LOV_Field("ALL", "PERSONAL ACCIDENT", "NEW BUSINESS", "ALL", "NEW", "PERSONAL ACCIDENT", "RatingClass", "LOV", [], "DESCPF", "ratingClass", null),
            new LOV_Field("ALL", "MOTOR", "NEW BUSINESS", "ALL", "NEW", "NAMED_DRIVER", "Sex", "LOV", [], "DESCPF", "Gender", null),
            new LOV_Field("ALL", "CLIENT", "ALL", "ALL", "NEW", "CLIENT_DETAILS", "Marital Status", "LOV", [], "DESCPF", "MaritalStatus", null),
            new LOV_Field("ALL", "MED", "ALL", "ALL", "ALL", "ALL", "Referral Reasons", "LOV", [], "DESCPF", "referralReasons", null),
            new LOV_Field("ALL", "MED", "ALL", "ALL", "ALL", "ALL", "Referral Age Limits", "LOV", referralAgeLimitNodes, "T7253", "referralAgeLimits", null)
        ];
        this.lovDropDownService.util_populateLOV(lovFields, this);
    }

    getUploadPath() {
        this._cordysService.callCordysSoapService("GetUploadConfig", "http://schemas.cordys.com/bmsintegrationapp", "", this.configSuccessHandler, this.writeErrorHandler, true, { comp: this });
    }

    configSuccessHandler(data, scopeObject) {
        if (data.tuple.old.GetUploadConfig.GetUploadConfig != "") {
            scopeObject.comp.uploadPath = data.tuple.old.GetUploadConfig.GetUploadConfig;
        }
    }

    private CloseDialog() {
        this.closeDialog(this.records, this.parentCompPRMS);
    }

    rowClick(idx) {
    }

    showErrorMessage(idx) {
    }

    expandOrCollapse(rec) {
        rec.expandBenfitIndicator = rec.expandBenfitIndicator == "true" ? "false" : "true";
    }

    private cleardata() {
        this.records = null;
        this.enableAttachmentError = false;
        this.globalValidationMessage = "";
        this.attachmentName = "";
        this.showRecordCountMessage = false;
        this.recordCountMessage = "";
    }

    private expandAll() {
        if (this.records != undefined) {
            for (let item of this.records) {
                item.expandBenfitIndicator = "true";
            }
        }
    }
    private collapseAll() {
        if (this.records != undefined) {
            for (let item of this.records) {
                item.expandBenfitIndicator = "false";
            }
        }
    }

    private confirmdata() {

        if (this.records == undefined) {
            this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "No Data to import.", 5000));
            return;
        }

        if (this.isValidationFailed) {
            this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Validation failed for 1 or more items. Please clear validations errors in excel file and upload again.", 5000));
        } else {

            this.addInsured();

            this.parentCompPRMS.comp.riskObj.noOfPersons = this.parentCompPRMS.comp.riskObj.s5382Items.s5382Item.length;
            this.parentCompPRMS.comp.setTotalPremium();
            this.parentCompPRMS.comp.resetItmNumber();
            this.parentCompPRMS.comp.setCapitalSI();
            this.parentCompPRMS.comp.checkReferredRisk(this.parentCompPRMS.comp);
            this.CloseDialog();
        }

    }

    private onFileSelect(event) {

        let i = 0;
        let selectedFileName = event.currentTarget.files[0].name;
        let fileExtension = selectedFileName.substr(selectedFileName.lastIndexOf(".") + 1);

        if (fileExtension != "xls" && fileExtension != "xlsx") {
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Please upload only excel files", 3000));
            event = null;
            selectedFileName = null;
            return;
        }

        this.attachmentName = selectedFileName;
        this.attachmentSize = event.currentTarget.files[0].size;
        if (this.attachmentSize - 0 > 10485760) {
            this.enableAttachmentError = true;
            this.globalValidationMessage = "File Size should be less than 10MB";
        }
        else {
            this.records = null;
            this.enableAttachmentError = false;
            this.globalValidationMessage = "";
            //this.attachmentName="";
            this.showRecordCountMessage = false;
            this.recordCountMessage = "";
            this.uploadDocument();
        }
    }

    private TriggerEvent() {
        jQuery(this._elRef.nativeElement).find("input[type='file']").val(null);
        jQuery(this._elRef.nativeElement).find("input[type='file']").click();
    }

    private showalert(t) {
        this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Uploading.Please wait", t));
    }

    uploadDocument() {
        this.disableButtons = true;
        var selectedFile = (<HTMLInputElement>document.getElementById("fileSelect")).files[0];
        let reader = new FileReader();
        this.showalert(3000);
        reader.onload = this.getFileContent(event, this);
        reader.readAsDataURL(selectedFile);
    }

    private getFileContent(e, originalObject) {
        return function (event) {
            let temp = event.target.result;
            originalObject.encodeFileContent = temp.substr(temp.indexOf(";base64,") + 8);

            var responsePromise = originalObject._cordysService.callCordysSoapService("WriteFile", "http://schemas.cordys.com/1.0/ac/FileConnector", originalObject.getUploadParameter(), originalObject.writeSuccessHandler, originalObject.writeErrorHandler, true, { comp: originalObject, callerObject: null });
            responsePromise.done((data) => {
            });
        }
    }
    private getUploadParameter() {
        let date = new Date();
        this.fileName = this.attachmentName.substring(0, this.attachmentName.lastIndexOf(".")) + " - " + date.getDate() + "-" + date.getMonth() + "-" + date.getFullYear() + "-" + date.getTime() + this.attachmentName.substring(this.attachmentName.lastIndexOf("."), this.attachmentName.length);

        if (this.uploadPath != undefined || this.uploadPath != "") {
            return {
                "filename": this.uploadPath + this.fileName,
                "append": "false",
                "encoded": "true",
                "data": this.encodeFileContent
            }
        }
    }

    writeSuccessHandler(data, scopeObject) {
        scopeObject.comp.readDataFromUploadedFile("Uploaded", scopeObject);
    }

    writeErrorHandler(response, status, errorText, scopeObject) {
        scopeObject.comp.disableButtons = false;
        scopeObject.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, response.responseJSON.faultstring.text, 2000));

    }

	/*
    prepareInsuredDataForDuplicateValidation(){
        let insuredXMLData="<insuredData>";
        for(let insuredItem of this.parentCompPRMS.comp.riskObj.s5382Items.s5382Item){
            insuredXMLData=insuredXMLData+"<insured>"+insuredItem.insuredPerson+"#"+insuredItem.IdProofNo+"#"+insuredItem.NRIC +"</insured>";
        }
        insuredXMLData=insuredXMLData+"</insuredData>";
        return insuredXMLData;
    }
	*/
    private readDataFromUploadedFile(status: string, scopeObject) {
        // let insuredData=this.prepareInsuredDataForDuplicateValidation();
        let UploadInput = {
            "filePath": scopeObject.comp.uploadPath + scopeObject.comp.fileName,
            "riskType": this.parentCompPRMS.comp.riskObj.riskType,
            "param1": ""
        };
        var responsePromise = this._cordysService.callCordysSoapService("UploadInsuredDetails_5382", "http://schemas.cordys.com/bmsintegrationapp", UploadInput, null, null, true, null);
        responsePromise.done((data) => {
            let ary = [];

            if (data.tuple && data.tuple.old && data.tuple.old.uploadInsuredDetails_5382.uploadInsuredDetails_5382) {
                let respData = JSON.parse(data.tuple.old.uploadInsuredDetails_5382.uploadInsuredDetails_5382);

                if (respData.excelData && respData.excelData.length > 0) {

                    this.showRecordCountMessage = true;
                    this.records = respData.excelData;
                    this.recordCountMessage = "<span class='alert-info'>Total Records: <B>" + this.records.length + "</B></span>";

                    this.validateRecords();
                }
                else {
                    this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "No Data in uploaded file.", 2000));
                }
            }

            /*
            if(this.records.s5382Items.s5382Item.length<=0){
                this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "No Data in uploaded file.", 2000));
            }else{
                this.showRecordCountMessage=true;
                let successCount = this.records.s5382Items.s5382Item.filter( function (el){ return el.isValidationFailed=="false";}).length;
                let failedCount = this.records.s5382Items.s5382Item.filter( function (el){ return el.isValidationFailed=="true";}).length
                this.recordCountMessage="<span class='alert-info'>Total Records: <B>"+this.records.s5382Items.s5382Item.length+"</B></span><span class='alert-danger'> Failed Records : <B>"+failedCount+"</B>.</p></span>";
            }
            */

            this.disableButtons = false;

        });

        responsePromise.fail((data) => {
            this.enableAttachmentError = true;
            this.disableButtons = false;
            this.globalValidationMessage = "Error occured while reading file. " + data.responseJSON.faultstring.text;
            this.showRecordCountMessage = false;
            this.recordCountMessage = "";

        });
    }

    validateRecords() {

        let insuredItemsAdded = this.parentCompPRMS.comp.riskObj.s5382Items.s5382Item;
        this.planCodeFilterStr = "";
        this.areaCodeFilterStr = "";
        this.occClassCodeFilterStr = "";
        let riskType = this.parentCompPRMS.comp.riskObj.riskType;
        let headerInfo = this.parentCompPRMS.comp.headerInfo;
        this.isValidationFailed = false;

        for (let _record of this.records) {

            let salutation = _record.salutation;
            let insuredName = _record.insuredName;
            let idProofNo = _record.idProofNo;
            let plan = _record.planCode;
            let maternityDate = _record.maternityDate;
            let occupationCode = _record.occupationCode;
            let occupatoinDesc = _record.occupatoinDesc;
            let occupationClass = _record.occupationClass;
            let areaCode = _record.areaCode;
            let dob = _record.dob;
            let gender = _record.gender;
            let maritalStatus = _record.maritalStatus;
            let nationality = _record.nationality;
            let homeCity = _record.homeCity;
            let residence = _record.residence;
            let isValidationFailed = _record.isValidationFailed;
            let validationMessage = _record.validationMessage;

            let insuredUniqueStr = insuredName + idProofNo;
            if (insuredUniqueStr && insuredItemsAdded && insuredItemsAdded.length > 0) {
                let insuredMatched = insuredItemsAdded.find((_data) => (_data.insuredPerson + _data.IdProofNo) == insuredUniqueStr);
                if (insuredMatched) {
                    _record.isValidationFailed = "true";
                    _record.validationMessage = _record.validationMessage + "<p>Duplicate Entry. Insured Already added in risk screen.</p>";
                }
            }

            this.fieldsValidation(_record, insuredName, 'Insured Name', 54);

			/*this.fieldsValidation(_record, salutation, 'Salutation', 8);
			if(salutation){
				let salutationData = this.lovDropDownService.lovDataList.Salutation.find((_item)=> _item.VALUE == salutation);
				if(salutationData){
					
				} else {
					_record.isValidationFailed = "true";
					_record.validationMessage = _record.validationMessage + "<p>Invalid Salutation.</p>";
				}
			}*/

            this.fieldsValidation(_record, occupationCode, 'Occupation Code', 4);
            if (occupationCode) {
                let occupationCodeData = this.lovDropDownService.lovDataList.Occupation.find((_item) => _item.VALUE == occupationCode);
                if (occupationCodeData) {
                    if (!occupatoinDesc)
                        _record.occupatoinDesc = occupationCodeData.DESCRIPTION;
                } else {
                    _record.isValidationFailed = "true";
                    _record.validationMessage = _record.validationMessage + "<p>Invalid Occupation Code.</p>";
                }
            }

            if (occupatoinDesc)
                this.fieldsValidation(_record, occupatoinDesc, 'Occupation Description', 40);

            this.fieldsValidation(_record, plan, 'Plan Code', 5);
            let planData = this.lovDropDownService.lovDataList.plans.find((_item) => _item.PLANCODE == plan);
            if (planData) {

                this.planCodeFilterStr = (this.planCodeFilterStr) ? this.planCodeFilterStr + ",'" + riskType + plan + "'" : "'" + riskType + plan + "'";
            } else {
                _record.isValidationFailed = "true";
                _record.validationMessage = _record.validationMessage + "<p>Invalid Plan Code.</p>";
            }

            this.fieldsValidation(_record, areaCode, 'Area Code', 2);
            let areaCodeData = this.lovDropDownService.lovDataList.areaCode.find((_item) => _item.VALUE == areaCode);
            if (areaCodeData) {
                this.areaCodeFilterStr = (this.areaCodeFilterStr) ? this.areaCodeFilterStr + ",'" + plan + areaCode + "'" : "'" + plan + areaCode + "'";

            } else {
                _record.isValidationFailed = "true";
                _record.validationMessage = _record.validationMessage + "<p>Invalid Area Code.</p>";
            }

            this.fieldsValidation(_record, occupationClass, 'Occupation Class Code', 2);
            let occClassCodeData = this.lovDropDownService.lovDataList.ratingClass.find((_item) => _item.VALUE == occupationClass);
            if (occClassCodeData) {
                this.occClassCodeFilterStr = (this.occClassCodeFilterStr) ? this.occClassCodeFilterStr + ",'" + plan + occupationClass + "'" : "'" + plan + occupationClass + "'";
            } else {
                _record.isValidationFailed = "true";
                _record.validationMessage = _record.validationMessage + "<p>Invalid Occupation Class Code.</p>";
            }

            this.fieldsValidation(_record, dob, 'Date of Birth', -1);
            if (dob) {
                let dobDate = moment(dob, "DD/MM/YYYY");
                var _effectiveDate = moment(headerInfo.effectiveDate, "YYYY-MM-DD");
                let age = _effectiveDate.diff(dobDate, 'years');
                if (age > 70) {
                    _record.isValidationFailed = "true";
                    _record.validationMessage = _record.validationMessage + "<p>Insured Person age is greater than 70 years.</p>";
                }
            }

            this.fieldsValidation(_record, gender, 'Gender', 1);
            if (gender) {
                let genderData = this.lovDropDownService.lovDataList.Gender.find((_item) => _item.VALUE == gender);
                if (genderData) {
                } else {
                    _record.isValidationFailed = "true";
                    _record.validationMessage = _record.validationMessage + "<p>Invalid Gender value.</p>";
                }
            }
            this.fieldsValidation(_record, idProofNo, 'ID/Passport', 15);
            this.fieldsValidation(_record, maritalStatus, 'Marital Status', 1);
            if (maritalStatus) {
                let maritalStatusData = this.lovDropDownService.lovDataList.MaritalStatus.find((_item) => _item.VALUE == maritalStatus);
                if (!(maritalStatusData)) {
                    _record.isValidationFailed = "true";
                    _record.validationMessage = _record.validationMessage + "<p>Invalid Marital Status.</p>";
                }
            }

            this.fieldsValidation(_record, nationality, 'Nationality', 3);
            if (nationality) {
                let nationalityData = this.lovDropDownService.lovDataList.nationality.find((_item) => _item.VALUE == nationality);
                if (!(nationalityData)) {
                    _record.isValidationFailed = "true";
                    _record.validationMessage = _record.validationMessage + "<p>Invalid Nationality Code.</p>";
                }
            }

            this.fieldsValidation(_record, homeCity, 'Home City', 3);
            if (homeCity) {
                let homeCityData = this.lovDropDownService.lovDataList.residence.find((_item) => _item.VALUE == homeCity);
                if (!(homeCityData)) {
                    _record.isValidationFailed = "true";
                    _record.validationMessage = _record.validationMessage + "<p>Invalid Home City Code.</p>";
                }
            }

            this.fieldsValidation(_record, residence, 'Residence', 3);
            if (residence) {
                let residenceData = this.lovDropDownService.lovDataList.residence.find((_item) => _item.VALUE == residence);
                if (!(residenceData)) {
                    _record.isValidationFailed = "true";
                    _record.validationMessage = _record.validationMessage + "<p>Invalid Residence Code.</p>";
                }
            }

            // rowData.put("rowNumber", rowCounter);
            // rowData.put("salutation", salutation);
            // rowData.put("insuredName", insuredName);
            // rowData.put("occupationCode", occupationCode);
            // rowData.put("occupatoinDesc", occupatoinDesc);
            // rowData.put("occupationClass", occupationClass);
            // rowData.put("idProofNo", idProofNo);
            // rowData.put("dob", dob);
            // rowData.put("gender", gender);
            // rowData.put("maritalStatus", maritalStatus);
            // rowData.put("nationality", nationality);
            // rowData.put("homeCity", homeCity);
            // rowData.put("residence", residence);
            // rowData.put("areaCode", areaCode);
            // rowData.put("planCode", planCode);
            // rowData.put("sumInsured", sumInsured);
            // rowData.put("flatPremium", flatPremium);
            // rowData.put("isValidationFailed", false);
            // rowData.put("validationMessage", "");
            // rowData.put("expandBenfitIndicator", false);

            // this.isValidationFailed = (_record.isValidationFailed == "true") ? true : false;
            if (_record.isValidationFailed == "true") this.isValidationFailed = true;
        }

        if (this.planCodeFilterStr) {
            let _planCodesList: any = this._s5382Service.getPlanCodesRecords(this.planCodeFilterStr, headerInfo.effectiveDate);
            for (let _record of this.records) {
                _record["benefits"] = [];

                if (_planCodesList && _planCodesList.length) {
                    let _planRecords: any = _planCodesList.filter((_data) => _data.old.T7088.DESCITEM == (riskType + _record.planCode));
                    for (let _rec of _planRecords) {
                        if (_rec.old.T7088.ZGMCDE) {
                            let _benefit = {
                                "coverageCode": _rec.old.T7088.ZGMCDE,
                                "coverageDescription": _rec.old.T7088.ZGMDSC,
                                "sumInsured": _rec.old.T7088.SUMI,
                                "siWorldWide": _rec.old.T7088.ZTPAID
                            }
                            _record.benefits.push(_benefit);
                        }
                    }
                }
            }
        }

    }

    fieldsValidation(record, fieldVal, fieldTitle, maxLength) {
        if (fieldVal) {
            if (maxLength > 0 && fieldVal.length > maxLength) {
                record.isValidationFailed = "true";
                record.validationMessage = record.validationMessage + "<p><b>" + fieldTitle + "</b> value exceeding maximum length. </p>";
            }
        } else {
            record.isValidationFailed = "true";
            record.validationMessage = record.validationMessage + "<p>Mandatory field <b>" + fieldTitle + "</b> value is missing </p>";
        }
    }

    addInsured() {

        let riskObj = this.parentCompPRMS.comp.riskObj;
        let headerInfo = this.parentCompPRMS.comp.headerInfo;

        let _planCodesList: any = this._s5382Service.getPlanCodesRecords(this.planCodeFilterStr, headerInfo.effectiveDate);
        let _areaCodesList: any = this._s5382Service.getAreaCodeMultiplierRate(this.areaCodeFilterStr, headerInfo.effectiveDate, true);
        let _occClsCodesList: any = this._s5382Service.getOccClassRate(this.occClassCodeFilterStr, headerInfo.effectiveDate, true);

        let _ageLimitRec = this.lovDropDownService.lovDataList.referralAgeLimits.find((_data) => _data.DESCITEM == riskObj.riskType);

        for (let _record of this.records) {

            let news5382Item = new S5382ItemDetails();
            news5382Item.itemNo = riskObj.s5382Items.s5382Item.length + 1;
            news5382Item.effectiveDate = headerInfo.effectiveDate;
            news5382Item.inclusionDate = headerInfo.effectiveDate;
            news5382Item.riskType = riskObj.riskType;
            news5382Item.riskName = riskObj.riskName;
            news5382Item.insuredPerson = _record.insuredName;
            news5382Item.insuredSalutation = _record.salutation;
            news5382Item.occupationCode = _record.occupationCode;
            news5382Item.occupationDescription = _record.occupatoinDesc;
            news5382Item.IdProofNo = _record.idProofNo;
            news5382Item.dateOfBirth = moment(_record.dob, "DD/MM/YYYY").format("YYYY-MM-DD");
            news5382Item.maritalStatus = _record.maritalStatus;
            news5382Item.gender = _record.gender;
            news5382Item.nationality = _record.nationality;
            news5382Item.homeCity = _record.homeCity;
            news5382Item.residence = _record.residence;

            news5382Item.dateStart = headerInfo.effectiveDate;
            news5382Item.lastDateEnd = headerInfo.endDate;

            news5382Item.plan = _record.planCode;
            news5382Item.maternityDate = (_record.maternityDate) ? moment(_record.maternityDate, "DD/MM/YYYY").format("YYYY-MM-DD") : "";

            //let _planRecords:any = this.lovDropDownService.lovDataList.plans.find((_data)=> _data.PLANCODE == _record.planCode);
            if (_planCodesList && _planCodesList.length) {
                let _planRecords: any = _planCodesList.filter((_data) => _data.old.T7088.DESCITEM == (riskObj.riskType + _record.planCode));
                this._s5382Service.addBenefitsFromPlanRecord(_planRecords, news5382Item, riskObj);
            }

            news5382Item.areaCode = _record.areaCode;
            if (_areaCodesList && _areaCodesList.length > 0) {
                let _areaCodeRec = _areaCodesList.find((_data) => _data.old.T7090.DESCITEM == (_record.planCode + _record.areaCode));
                if (_areaCodeRec) {
                    let _areaCodeRate = _areaCodeRec.old.T7090.ZCRYLOAD;
                    news5382Item.load = numeral(numeral(_areaCodeRate).format(this._s5382Service.loadFormat)).value();
                }
                else {
                    news5382Item.load = 0;
                }
            }

            news5382Item.occupationClass = _record.occupationClass;
            if (_occClsCodesList && _occClsCodesList.length > 0) {
                let _occClsCodeRec = _occClsCodesList.find((_data) => _data.old.T7091.DESCITEM == (_record.planCode + _record.occupationClass));
                if (_occClsCodeRec) {
                    let _occClsCodeRate = _occClsCodeRec.old.T7091.ZCRYLOAD;
                    news5382Item.occupationClassRate = numeral(numeral(_occClsCodeRate).format(this._s5382Service.loadFormat)).value();
                }
                else {
                    news5382Item.occupationClassRate = 0;
                }
            }

            this._s5382Service.calculatePremium(news5382Item, riskObj, headerInfo.effectiveDate);

            this._s5382Service.checkReferredRiskConditions(news5382Item, headerInfo.contractType, _ageLimitRec, this.lovDropDownService.lovDataList.Occupation, this.lovDropDownService.lovDataList.referralReasons, null);
            this.handleRiskClassification(news5382Item);

            riskObj.s5382Items.s5382Item.push(news5382Item);
        }
    }

    handleRiskClassification(riskObj) {
        if (riskObj.symRiskClassification == "Declined")
            riskObj.riskClassification = "Declined";
        else if (riskObj.symRiskClassification == "Referred" || riskObj.riRiskClassification == "Referred")
            riskObj.riskClassification = "Referred";
        else
            riskObj.riskClassification = "Standard";

        this.setRiskClassification(riskObj);
        // this.emitRiskClass(this);

    }

    setRiskClassification(riskObj) {
        if (riskObj.symRiskClassification != null && riskObj.symRiskClassification != "" && (riskObj.symRiskClassification == "Referred" || riskObj.symRiskClassification == "Declined")) {
            let statusTxt = (riskObj.symRiskClassification != null && riskObj.symRiskClassification != "") ? riskObj.symRiskClassification : riskObj.riskClassification;
            riskObj.riskClassificationReason = "System marked as " + statusTxt;
        }
        else {
            if (riskObj.riskClassificationReason != null && riskObj.riskClassificationReason != "" && (riskObj.riskClassificationReason != "System marked as Standard"
                && riskObj.riskClassificationReason.indexOf("System marked as ") != -1)) {
                riskObj.riskClassificationReason = "";
            }
        }
    }


}