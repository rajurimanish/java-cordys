/*
 * Change History:
 * 
 * No      Date          Description                                         Changed By
 * ====    ==========    ===========                                         ==========	
 * YPK001 23/09/2019       MYS-2019-0675 Document Validation for Co-outwards            PKU1
 *                         case before sending to PPHO			   
*/
import { Component, OnInit, ViewChild, ElementRef, EventEmitter, AfterViewInit, ViewContainerRef } from '@angular/core';
declare var Observer: any;
import { DCLInput, CustomDCLService } from '../../../../../common/services/customdcl.service';
import { CordysSoapWService } from "../../../../../common/components/utility/cordys-soap-ws";
import { ModalInput } from "../../../../../common/components/utility/modal/modal";
import { LOV_Field, LOVDropDownService, SearchFilter } from "../../../../../common/services/lovdropdown/lovdropdown.service";
import { GetLOVData, SearchAdvancedConfig, Filter } from '../../../../../common/components/utility/search/search.requests';
import { ProposalHeader } from '../../proposalheader/appobjects/proposalheader';
import { ClientDetails } from '../../../../../common/components/client/appobjects/client';
import { S5381, S5382ItemDetails, S5382Item } from './appObjects/s5381';
import { S5382Service } from "./services/s5382.service";
import { Clause } from "../appobjects/clause";
import { ClausesComponent } from "../uimodules/clauses.component";
import { ApplicationUtilService } from "../../../../../common/services/application.util.service";
import { BMSUtilService } from "../../../../services/bms.util.service";
import { AlertMessagesService } from '../../../../../common/components/utility/alertmessage/alertmessages.service';
import { AlertMessage } from '../../../../../common/components/utility/alertmessage/alertmessages.model';
import { RIService } from '../services/ri.service';
import { RiskClassificationService } from '../services/riskcls.service';
import { ReferredReason, Reasons } from '../../proposalheader/appobjects/referredreason';
import { BMSConstants } from '../../../common/constants/bms_constants';
import { ActivatedRoute } from '@angular/router';

declare var jQuery: any;
declare var numeral: any;
declare var moment: any;

@Component({
    selector: "s5381-component",
    templateUrl: "app/bms/components/proposal/newbusinessrisks/s5381/s5381.template.html",
    inputs: ["riskObj", "clientDetails", "headerInfo"],
    outputs: ["onPremiumChange", "onSIChange", "onRiskClsChange", "onRtngFlgChange"]
})
export class S5381Component implements OnInit {

    private isCollapsedMode: boolean = true;
    private collapseClausesInfo: boolean = true;
    private relatedCollapse: boolean = false;
    private isGeneralPageCollapsed: boolean = false;
    // public defaultClauseCode:string = "";

    private surInfoCollapse: boolean = true;

    public riskObj: S5381;
    public clientDetails: ClientDetails;
    public headerInfo: ProposalHeader;
    public currentRiskObj: any;
    private el: HTMLElement;
    public selectedRiskComponent: any;
    onPremiumChange = new EventEmitter<any>();
    onRiskClsChange = new EventEmitter<any>();
    onRtngFlgChange = new EventEmitter<any>();
    onSIChange = new EventEmitter<any>();

    public position = 1;
    public sizeObj = { length: 0, orglength: 0 };
    public contentSizeObs: any;
    public itemPerPage = 5;
    public maxPageCount = 5;

    public disableForm = 'N';

    public siFormat: string = "000";
    public premiumFormat: string = "000.00";
    public rateFormat: string = "0.00000";
    public percentFormat: string = "0.00";

    private isUnderWriter = "N";
    private isRIMethodEditable = "Y";

    public isAnyInsuredReferred: boolean = false;
    public isAnyInsuredDeclined: boolean = false;
    public isManuallyReferred: boolean = false;

    public collapsableObject = {
        "isCollapsedMode": false,
        "collapseClausesInfo": true
    }

    private inclusionDateCtrl: any = [];
    private effectiveDateCtrl: any = [];
    @ViewChild(ClausesComponent) private clausesComp: ClausesComponent;
    @ViewChild('S5382RisksModal', { read: ViewContainerRef }) contentArea: ViewContainerRef;

    constructor(private lovDropDownService: LOVDropDownService, private _soapService: CordysSoapWService, public _alertMsgService: AlertMessagesService, el: ElementRef, private _dcl: CustomDCLService, private _appUtilService: ApplicationUtilService, private _bmsUtilService: BMSUtilService, private _rcls: RiskClassificationService, private _riService: RIService, private _s5382Service: S5382Service, private _activatedRoute: ActivatedRoute) {

        this.el = el.nativeElement;
    }

    ngOnInit() {

        if (this.riskObj.contractNumber != "") {
            this.disableForm = "Y";
        }

        this.initClientDetails();
        this.populateLovs();

        if (this.headerInfo.contractType == 'HIG') {
            this._appUtilService.isUnderWriterUser().subscribe((data) => {
                this.isUnderWriter = data;
                this.setRIMethodEditableFlag();
            });
        }
        //SST Code
        if (["MyTasks", "MyDrafts"].indexOf(this._activatedRoute.snapshot.params['component']) >= 0 || Object.keys(this._activatedRoute.snapshot.params).length == 0) {
            let respObj = this._bmsUtilService.getTAXDetails();
            if (respObj != undefined && respObj != "") {
                this.headerInfo.SSTTaxRate = Number(respObj[0].old.ITEMPF.GST);
                this.headerInfo.GSTTaxRate = Number(respObj[1].old.ITEMPF.GST);

                this.riskObj.SST = Number(this.headerInfo.SSTTaxRate);
                this.riskObj.GST = Number(this.headerInfo.GSTTaxRate);
            }

            this.headerInfo = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo;
            this.riskObj.SSTLiveDate = (this.riskObj.SSTLiveDate == undefined) ? this.headerInfo.SSTLiveDate : this.riskObj.SSTLiveDate;
            if (this.riskObj.SSTLiveDate == undefined || this.riskObj.SSTLiveDate == "") {
                let tempRespObj = this._bmsUtilService.getLiveDate();
                this.riskObj.GSTLiveDate = tempRespObj[0].old.ITEMPF.LIVEDATE;
                this.riskObj.SSTLiveDate = tempRespObj[1].old.ITEMPF.LIVEDATE;
                if (this.headerInfo.SSTLiveDate == undefined || this.headerInfo.SSTLiveDate == "") {
                    this.headerInfo.SSTLiveDate = this.riskObj.SSTLiveDate;
                }
                if (this.headerInfo.GSTLiveDate == undefined || this.headerInfo.GSTLiveDate == "") {
                    this.headerInfo.GSTLiveDate = this.riskObj.GSTLiveDate;
                }
            }
            if (moment(this.headerInfo.effectiveDate, "YYYY-MM-DD").format("YYYYMMDD") >= moment(this.riskObj.SSTLiveDate, "YYYY-MM-DD").format("YYYYMMDD")) {
                this.riskObj.isGSTApplicable = false;
            } else {
                this.riskObj.isGSTApplicable = true;
            }
            let clientObj = BMSConstants.getClientObj();
            if (clientObj.client.genericDetails.clienttype == "P") {
                this.riskObj.SST = Number(0);
                this.riskObj.sstAmount = 0;
                this.headerInfo.SSTTaxRate = this.riskObj.SST;
            } else {
                this.riskObj.SST = Number(this.headerInfo.SSTTaxRate);
            }
        }
        //End
    }

    ngAfterViewInit() {
        //this.setFormDisabled();
        if (this.headerInfo.asyncPostingStatus == "InProgress") {
            this.disableForm = "Y";
        } else if (this.riskObj.contractNumber != "") {
            this.disableForm = "Y";
        }
        else {
            this.disableForm = "N";
        }

        if (this.headerInfo.contractType == 'HIG' && this.riskObj.riskClassificationReasons.reasons && this.riskObj.riskClassificationReasons.reasons.reason && this.riskObj.riskClassificationReasons.reasons.reason.length == 0) {
            this.checkReferredRiskConditions();
        }
        //START YPK001
        let rIndex = 0;
        if ((this.headerInfo.CoInsurance == 'Y' && this.riskObj.riskNumber == '1') && (["MyTasks", "MyDrafts"].indexOf(this._activatedRoute.snapshot.params['component']) >= 0 || Object.keys(this._activatedRoute.snapshot.params).length == 0)) {
            if (this.headerInfo.coInsuranceDetails.coInsurance.length == 1) {
                if (!(this.headerInfo.coInsuranceDetails.coInsurance[0].coInsuranceindicator == 'L' && this.headerInfo.coInsuranceDetails.coInsurance[0].sharePercentage == '100')) {
                    rIndex = this.riskObj.clauses.clause.map(function (item) { return item.clauseCode; }).indexOf("COIN");
                    if (rIndex == -1)
                        this.setClauses(["COIN"], false);
                }
            }
            else {
                rIndex = this.riskObj.clauses.clause.map(function (item) { return item.clauseCode; }).indexOf("COIN");
                if (rIndex == -1)
                    this.setClauses(["COIN"], false);
            }
        }
    }
    //END YPK001

    populateLovs() {

        let riskFilter = (this.riskObj.riskType.length == 2) ? this.riskObj.riskType + ' ' : this.riskObj.riskType;
        let riskTypeFilterDetails = [new SearchFilter("DESCITEM", riskFilter, "STARTSWITH", "AND")];
        let riskTypeFilterNodes = this.lovDropDownService.createFilter(riskTypeFilterDetails);

        this.lovDropDownService.createLOVDataList(["Occupation"]);
        let lovFields = [
            new LOV_Field("ALL", "ALL", "NEW BUSINESS", "ALL", "NEW", "ALL", "Occupation", "LOV", [], "T3644", "Occupation", "callbackForOccListLoad")
        ];
        this.lovDropDownService.util_populateLOV(lovFields, this);
    }

    callbackForOccListLoad(scopeObject) {
        if (scopeObject.riskObj.occupationCode && !scopeObject.riskObj.occupationDescription) {
            let _occRec = scopeObject.lovDropDownService.lovDataList.Occupation.find((_item) => _item.VALUE == scopeObject.riskObj.occupationCode);
            if (_occRec) {
                if (!scopeObject.riskObj.occupationDescription)
                    scopeObject.riskObj.occupationDescription = _occRec.DESCRIPTION;
            }
            else {
                scopeObject.riskObj.occupationCode = '';
                scopeObject.riskObj.occupationDescription = '';
            }
        }
    }

    onOccChange(ev) {
        this.riskObj.occupationCode = ev.value;
        this.riskObj.occupationDescription = (ev.record.DESCRIPTION) ? ev.record.DESCRIPTION.slice(0, 40) : "";
    }

    setFormDisabled() {
        if (jQuery("#bmsForm").prop("disabled") == true) {
            this.disableForm = "Y";
        }
    }

    initClientDetails() {
        this.riskObj.insuredPersonNo = this.clientDetails.client.clientNumber;
        if (this.clientDetails.client.genericDetails.clienttype == 'P') {
            this.riskObj.insuredPerson = this.clientDetails.client.personalClientDetails.Name;
            this.riskObj.occupationCode = this.clientDetails.client.personalClientDetails.occupationCode;
            this.riskObj.dateOfBirth = moment(this.clientDetails.client.personalClientDetails.dateOfBirth, "YYYYMMDD").format("YYYY-MM-DD");
        }
        else if (this.clientDetails.client.genericDetails.clienttype == 'C') {
            this.riskObj.insuredPerson = (this.clientDetails.client.corporateClientDetails.corporation) ? this.clientDetails.client.corporateClientDetails.corporation : "";
            this.riskObj.occupationCode = (this.clientDetails.client.corporateClientDetails.BusinessSec) ? this.clientDetails.client.corporateClientDetails.BusinessSec : "";
        }
        else {
            this.riskObj.insuredPerson = "";
            this.riskObj.occupationCode = "";
            this.riskObj.occupationDescription = "";
        }
    }

    onInclusionDateChange(riskItem, evt, idx) {
        if (!riskItem.inclusionDate) {
            this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Date Inclusion cannot be Empty", 5000));
            this.inclusionDateCtrl[idx].setter(this.headerInfo.effectiveDate, "YYYY-MM-DD", this.inclusionDateCtrl[idx].comp);
            this.effectiveDateCtrl[idx].setter(riskItem.inclusionDate, "YYYY-MM-DD", this.effectiveDateCtrl[idx].comp);
            return;
        }
        let _dateDiff = moment(riskItem.inclusionDate, "YYYY-MM-DD").diff(moment(this.headerInfo.effectiveDate, "YYYY-MM-DD").format("YYYY-MM-DD"), "days");
        if (_dateDiff < 0) {
            this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Date Inclusion cannot be less than Policy Effective Date", 5000));
            this.inclusionDateCtrl[idx].setter(this.headerInfo.effectiveDate, "YYYY-MM-DD", this.inclusionDateCtrl[idx].comp);
            this.effectiveDateCtrl[idx].setter(riskItem.inclusionDate, "YYYY-MM-DD", this.effectiveDateCtrl[idx].comp);
            return;
        }
        _dateDiff = moment(this.headerInfo.endDate, "YYYY-MM-DD").diff(moment(riskItem.inclusionDate, "YYYY-MM-DD").format("YYYY-MM-DD"), "days");
        if (_dateDiff < 0) {
            this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Date Inclusion cannot be more than Policy End Date", 5000));
            this.inclusionDateCtrl[idx].setter(this.headerInfo.effectiveDate, "YYYY-MM-DD", this.inclusionDateCtrl[idx].comp);
            this.effectiveDateCtrl[idx].setter(riskItem.inclusionDate, "YYYY-MM-DD", this.effectiveDateCtrl[idx].comp);
            return;
        }
        this.effectiveDateCtrl[idx].setter(riskItem.inclusionDate, "YYYY-MM-DD", this.effectiveDateCtrl[idx].comp);

    }

    addInsured() {

        let s5382Item = new S5382ItemDetails();
        s5382Item.itemNo = this.riskObj.s5382Items.s5382Item.length + 1;
        s5382Item.effectiveDate = this.headerInfo.effectiveDate;
        s5382Item.inclusionDate = this.headerInfo.effectiveDate;

        if (this.clientDetails.client.genericDetails.clienttype == 'P' && this.clientDetails.client.personalClientDetails && this.riskObj.s5382Items.s5382Item.length == 0) {

            s5382Item.riskType = this.riskObj.riskType;
            s5382Item.riskName = this.riskObj.riskName;
            s5382Item.insuredPerson = this.clientDetails.client.personalClientDetails.Name;
            s5382Item.insuredSalutation = this.clientDetails.client.personalClientDetails.saluation;
            s5382Item.IdProofNo = (this.clientDetails.client.personalClientDetails.NRICNo) ? this.clientDetails.client.personalClientDetails.NRICNo : this.clientDetails.client.personalClientDetails.IdNumber;
            s5382Item.dateOfBirth = moment(this.clientDetails.client.personalClientDetails.dateOfBirth, "YYYYMMDD").format("YYYY-MM-DD");
            s5382Item.maritalStatus = this.clientDetails.client.personalClientDetails.maritalStatus;
            s5382Item.gender = this.clientDetails.client.personalClientDetails.gender;
            s5382Item.occupationCode = this.clientDetails.client.personalClientDetails.occupationCode;
            // s5382Item.occupationDescription = this.clientDetails.client.personalClientDetails.occupationDescription;
            s5382Item.terminationDate = this.clientDetails.client.personalClientDetails.terminationDate;
            s5382Item.dateStart = this.headerInfo.effectiveDate;
            s5382Item.lastDateEnd = this.headerInfo.endDate;
            s5382Item.insuredAge = 0;
            this._s5382Service.setInsuredGenderFromNRIC(s5382Item);

			/*if(s5382Item.occupationCode){
				let _occRec = this.lovDropDownService.lovDataList.Occupation.find((_item)=> _item.VALUE==s5382Item.occupationCode);
				if(_occRec){
					s5382Item.occupationDescription = _occRec.DESCRIPTION;
				}
				else {
					s5382Item.occupationCode='';
					s5382Item.occupationDescription='';
				}
			}*/

			/*if (s5382Item.dateOfBirth != null && s5382Item.dateOfBirth != "") {
				let curDate = moment(new Date().toISOString(), "YYYY-MM-DD");
				let date = moment(s5382Item.dateOfBirth, "YYYY-MM-DD").format("YYYY-MM-DD");
				s5382Item.insuredAge = curDate.diff(date, 'year');
			}*/
        } else {

            s5382Item.riskType = this.riskObj.riskType;
            s5382Item.riskName = this.riskObj.riskName;
            s5382Item.dateStart = this.headerInfo.effectiveDate;
            s5382Item.lastDateEnd = this.headerInfo.endDate;
        }

        if (this.headerInfo.contractType == "EMC") {
            s5382Item.occupationClass = "01";
            if (!s5382Item.occupationCode)
                s5382Item.occupationCode = "7STU";
        }

        if (this.headerInfo.contractType == 'HII' || this.headerInfo.contractType == 'HIG') {
            s5382Item.nationality = "MAL";
            s5382Item.homeCity = "MAL";
            s5382Item.residence = "MAL";
            s5382Item.areaCode = "01";
        }

        this.riskObj.s5382Items.s5382Item.push(s5382Item);

        this.riskObj.noOfPersons = this.riskObj.s5382Items.s5382Item.length;
    }

    removeAllInsured(e) {
        if (this.riskObj.s5382Items.s5382Item.length > 0)
            this.confirmAppChange("Are you sure want to remove all insured person from risk?", e);
    }

    private expandContent(part) {

        this.collapsableObject[part] = false;
        event.stopPropagation();
    }

    private collapseContent(part) {
        this.collapsableObject[part] = true;
        event.stopPropagation();
    }

    public expandOrCollapse(part) {
        if (this.collapsableObject[part] == false) {
            this.collapsableObject[part] = true;
        } else {
            this.collapsableObject[part] = false;
        }
    }

    setRIMethod(val) {

        this.riskObj.RIMethod = (val == "Yes") ? "8" : this.riskObj.RIMethodSys;

        if (this.isUnderWriter == "Y" || val == "Yes")
            this.riskObj.isRIOverWrittenByUW = "Y";
        else if (val == "No") {
            this.riskObj.isRIOverWrittenByUW = "N";
            this.validateCapitalSumInsured();
        }
        this._riService.setRI().subscribe();
    }

    emitDuplicateCheck() {

    }

    changeRiskClassification(event) {
        this.riskObj.riskClassification = event.target.value;
        this.onRiskClsChange.emit('');
    }

    validateInsuredCount(e) {
        if (this.riskObj.s5382Items.s5382Item.length >= 1 && this.riskObj.riskType == "MPA") {
            return true;
        }
        return false;
    }

    setClauses(clausesList, flag) {
        if (this.clausesComp)
            this.clausesComp.addClause(clausesList, '', flag);
    }

    deleteClause(ary, clauseCode, prop) {
        let val = undefined;
        if (ary.length > 0) {
            for (var index = 0, assoLength = ary.length; index < assoLength; index++) {
                if (ary[index][prop] != null && ary[index][prop] != "" && ary[index][prop] == clauseCode) {
                    val = index;
                    break;
                }
            }
        }
        if (val != undefined)
            this.clausesComp.removeClause(val, clauseCode);
    }

    checkSingleRecord() {
        if (this.riskObj.s5382Items != null && this.riskObj.s5382Items.s5382Item != null) {
            if (!Array.prototype.isPrototypeOf(this.riskObj.s5382Items.s5382Item)) {
                let tempItem: any = this.riskObj.s5382Items.s5382Item;
                this.riskObj.s5382Items.s5382Item = [tempItem];
            }
        }
        else {
            this.riskObj.s5382Items = new S5382Item();
        }

    }

    uploadInsuredData() {
        let input = new ModalInput();
        input.component = ["S5382UploadComponent", "app/bms/components/proposal/newbusinessrisks/s5381/dialogs/s5382upload.module", "S5382UploadModule"];
        /*input.datainput = {
            ""
        };*/
        input.parentCompPRMS = { comp: this };
        input.heading = "Upload Insured Data";
        input.icon = "fa fa-list";
        input.containerRef = this.contentArea;
        this._dcl.openLookup(input);

    }

    validateInput(event, dType, allowedLength) {
        //console.log(dType + ", " + event.target.value);

        if ([46, 8, 9, 27, 13, 110].indexOf(event.keyCode) !== -1 ||
            // Allow: Ctrl+A, Command+A
            (event.keyCode === 65 && (event.ctrlKey === true || event.metaKey === true)) ||
            // Allow: home, end, left, right, down, up
            (event.keyCode >= 35 && event.keyCode <= 40)) {
            // let it happen, don't do anything
            return;
        }
        // Ensure that it is a number and stop the keypress
        if (dType = "integer") {
            let result = (event.target.value + "").match(/[^0-9]/g);
            if (event.key == ".") {
                // console.log("not allowed");
                return false;
            }
            if (event.target.value != undefined && event.target.value.length >= allowedLength) {
                // console.log("length failed");
                return false;
            }
        } else if (dType = "double") {
            let result = (event.target.value + "").match(/[^0-9]/g);
            if (result && event.key == ".") {
                //console.log("not allowed");
                return false;
            }
        }
        if ((event.shiftKey || (event.keyCode < 48 || event.keyCode > 57)) && (event.keyCode < 96 || event.keyCode > 105)) {
            event.preventDefault();
        }

    }

    private confirmAppChange(message: string, values) {
        let inputObj = {
            "Message": message
        };
        let lookup = new ModalInput();
        lookup.component = ["Confirm", "app/common/components/utility/confirmmessage/confirm.module", "ConfirmModule"];
        lookup.datainput = inputObj;
        lookup.outputCallback = this.removeAllInsuredDecision;
        lookup.parentCompPRMS = {
            comp: this,
            values: values
        };
        lookup.heading = "User Confirmation";
        lookup.icon = "fa fa-hand-paper-o";
        lookup.containerRef = this.contentArea;
        this._dcl.openLookup(lookup);

    }

    private removeAllInsuredDecision(data, prms) {
        if (data.value == 'Y') {
            prms.comp.riskObj.s5382Items.s5382Item.splice(0, prms.comp.riskObj.s5382Items.s5382Item.length);
            prms.comp.riskObj.noOfPersons = 0;
            prms.comp.removeRiskContent();
        }
        else {

        }
    }

    selectRisk(risk) {
        this.removeRiskContent();

        if (risk != null) {
            let idx = this.riskObj.s5382Items.s5382Item.indexOf(risk);
            this.currentRiskObj = risk;
            this.loadComponent(["S5382Component", "app/bms/components/proposal/newbusinessrisks/s5381/s5382.module", "S5382Module"], null);
        }
    }

    removeInsured(risk) {
        if (this.currentRiskObj != null && this.currentRiskObj.itemNo == risk.itemNo) {
            this.removeRiskContent();
            this.currentRiskObj = null;
        }
        this.riskObj.s5382Items.s5382Item.splice(this.riskObj.s5382Items.s5382Item.indexOf(risk), 1);
        this.resetItmNumber();
        this.setTotalPremium();
        this.setCapitalSI();
        this.riskObj.noOfPersons = this.riskObj.s5382Items.s5382Item.length;

        this.isManuallyReferred = (this.riskObj.symRiskClassification != "Referred" && this.riskObj.riskClassification == "Referred") ? true : false;
        this.checkReferredRisk(this);

    }

    resetItmNumber() {
        for (let insured of this.riskObj.s5382Items.s5382Item) {
            let index = this.riskObj.s5382Items.s5382Item.indexOf(insured);
            insured.itemNo = (index + 1);
        }
    }

    checkReferredRisk(comp) {
        //check if insured classification is referred
        comp.checkIfAnyofInsuredAreReferred(comp);

        if (comp.isAnyInsuredDeclined) {
            comp.riskObj.symRiskClassification = "Declined";
        }
        else if (comp.riskObj.occRiskClassification == "Declined") {
            comp.riskObj.symRiskClassification = "Declined";
        }
        else if (comp.riskObj.occRiskClassification == "Referred" || comp.riskObj.ageLimitFlag == "G" || comp.riskObj.hasClaimExperience == "Y") {
            comp.riskObj.symRiskClassification = "Referred";
        }
        else if (comp.isAnyInsuredReferred) {
            comp.riskObj.symRiskClassification = "Referred";
        }
        else {
            comp.riskObj.symRiskClassification = "Standard";
        }

        comp._s5382Service.handleRiskClassification(comp);
    }

    checkIfAnyofInsuredAreReferred(comp) {
        comp.isAnyInsuredReferred = false;
        comp.isAnyInsuredDeclined = false;
        if (comp.riskObj.s5382Items != null && comp.riskObj.s5382Items.s5382Item != null && comp.riskObj.s5382Items.s5382Item.length > 0) {
            for (let insured of comp.riskObj.s5382Items.s5382Item) {
                if (insured.riskClassification == 'Referred') {
                    comp.isAnyInsuredReferred = true;
                }
                else if (insured.riskClassification == 'Declined') {
                    comp.isAnyInsuredDeclined = true;
                }
            }

            if (comp.isAnyInsuredDeclined) {
                comp.isAnyInsuredReferred = false;
            }
        }
    }

    setReferredRisk(itemNo) {
        this.isManuallyReferred = (this.riskObj.symRiskClassification != "Referred" && this.riskObj.riskClassification == "Referred") ? true : false;
        this.checkReferredRisk(this);

        // this._rcls.setRiskClassification(this.riskObj.riskNumber, "N", itemNo,"").subscribe();
    }

    setRiskClassification(comp) {
        if (comp.riskObj.symRiskClassification != null && comp.riskObj.symRiskClassification != "" && (comp.riskObj.symRiskClassification == "Referred" || comp.riskObj.symRiskClassification == "Declined")) {
            let statusTxt = (comp.riskObj.symRiskClassification != null && comp.riskObj.symRiskClassification != "") ? comp.riskObj.symRiskClassification : comp.riskObj.riskClassification;
            comp.riskObj.riskClassificationReason = "System marked as " + statusTxt;
        }
        else {
            if (comp.riskObj.riskClassificationReason != null && comp.riskObj.riskClassificationReason != "" && (comp.riskObj.riskClassificationReason != "System marked as Standard"
                && comp.riskObj.riskClassificationReason.indexOf("System marked as ") != -1)) {
                comp.riskObj.riskClassificationReason = "";
            }
        }

        comp.onRiskClsChange.emit('');
    }

    handleError(response, status, errorText, prms) {
        prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, response.responseJSON.faultstring.text, -1));
    }

    getTotalByProperty(prop, ary) {
        let total = numeral(0);
        let counter = 1;
        for (let eachItem of ary) {
            if (eachItem[prop] != null && eachItem[prop] != "") {
                total = total.add(numeral().unformat(eachItem[prop]));
            }
        }
        if (total)
            total = numeral(total).format('0.00');
        else
            total = 0;
        return total;
    }

    getTotalByPropertyForSumInsured(prop, ary) {
        let total = numeral(0);
        let counter = 1;
        for (let eachItem of ary) {
            if (eachItem[prop] != null && eachItem[prop] != "") {
                total = total.add(numeral().unformat(eachItem[prop]));
            }
        }
        if (total)
            total = numeral(total).format('0');
        else
            total = 0;
        return total;
    }

    setTotalPremium() {
        this.riskObj.originalTotalPremium = this.getTotalByProperty("totalAnnualPremium", this.riskObj.s5382Items.s5382Item);
        this.riskObj.rebate = this.headerInfo.rebate;
        this.riskObj.rebateAmount = Number(numeral().unformat(this.riskObj.originalTotalPremium) / 100 * numeral().unformat(this.riskObj.rebate));
        this.riskObj.discountedPremium = numeral().unformat(this.riskObj.originalTotalPremium) - numeral().unformat(this.riskObj.rebateAmount);
        if (parseFloat("" + this.riskObj.GST) > 0 && this.riskObj.discountedPremium > 0) {
            //this.riskObj.gstAmount = Number(this.riskObj.discountedPremium * parseFloat(""+this.riskObj.GST) * 0.01);
            let tempGSTAmount = Number(this.riskObj.discountedPremium * parseFloat("" + this.riskObj.GST) * 0.01);
            this.riskObj.gstAmount = numeral(numeral(BMSUtilService.calculatePremiumAmount(tempGSTAmount, "G")).format(this.premiumFormat)).value();
        }
        else {
            this.riskObj.gstAmount = 0;
        }

        //SST Code
        let clientObj = BMSConstants.getClientObj();
        if (clientObj.client.genericDetails.clienttype != "P" && parseFloat("" + this.riskObj.SST) > 0 && this.riskObj.discountedPremium > 0) {
            let tempSSTAmount = Number(this.riskObj.discountedPremium * parseFloat("" + this.riskObj.SST) * 0.01);
            this.riskObj.sstAmount = (tempSSTAmount > 0) ? numeral(numeral(BMSUtilService.calculatePremiumAmount(tempSSTAmount, "S")).format(this.premiumFormat)).value() : 0;
        }
        else {
            this.riskObj.sstAmount = 0;
            this.riskObj.SST = Number(0);
        }

        //this.riskObj.totalPremium = numeral().unformat(this.riskObj.discountedPremium) + numeral().unformat(this.riskObj.gstAmount);
        this.riskObj.totalPremium = numeral().unformat(this.riskObj.discountedPremium) + numeral().unformat(this.riskObj.gstAmount) + numeral().unformat(this.riskObj.sstAmount);
        this.riskObj.sstAmount = numeral(this.riskObj.sstAmount).format('0.00');
        //End
        this.riskObj.gstAmount = numeral(this.riskObj.gstAmount).format('0.00');
        this.riskObj.totalPremium = numeral(this.riskObj.totalPremium).format('0.00');
        this.riskObj.rebateAmount = numeral(this.riskObj.rebateAmount).format('0.00');
        this.riskObj.discountedPremium = numeral(this.riskObj.discountedPremium).format('0.00');
        this.setTotalPP();
        this.onPremiumChange.emit(this.riskObj.totalPremium);
    }

    setCapitalSI() {
        let bigSI = 0;
        let bigEMESI = 0;
        let bigRoutingSI = 0;

        let _referredRoutingSI = 0;
        let _standardRoutingSI = 0;

        for (let _eachItem of this.riskObj.s5382Items.s5382Item) {

            if (_eachItem.capitalSumInsured != null && "" + _eachItem.capitalSumInsured != "") {
                bigSI = (parseFloat("" + _eachItem.capitalSumInsured) > bigSI) ? parseFloat("" + _eachItem.capitalSumInsured) : bigSI;
            }
            if (_eachItem.emeSumInsured != null && "" + _eachItem.emeSumInsured != "") {
                bigEMESI = (parseFloat("" + _eachItem.emeSumInsured) > bigEMESI) ? parseFloat("" + _eachItem.emeSumInsured) : bigEMESI;
            }
            if (_eachItem.routingSumInsured != null && "" + _eachItem.routingSumInsured != "") {
                bigRoutingSI = (parseFloat("" + _eachItem.routingSumInsured) > bigRoutingSI) ? parseFloat("" + _eachItem.routingSumInsured) : bigRoutingSI;
                if (_eachItem.riskClassification == 'Referred') {
                    _referredRoutingSI = (parseFloat("" + _eachItem.routingSumInsured) > _referredRoutingSI) ? parseFloat("" + _eachItem.routingSumInsured) : _referredRoutingSI;
                }
                else {
                    _standardRoutingSI = (parseFloat("" + _eachItem.routingSumInsured) > _standardRoutingSI) ? parseFloat("" + _eachItem.routingSumInsured) : _standardRoutingSI;
                }
            }
        }

        this.riskObj.capitalSumInsured = bigSI;
        this.riskObj.emeSumInsured = bigEMESI;

        if (this.headerInfo.contractType == 'HIG' || this.headerInfo.contractType == 'HII') {
            if (this.riskObj.riskClassification == 'Referred') {
                this.riskObj.routingSumInsured = (_referredRoutingSI > 0) ? _referredRoutingSI : bigRoutingSI;
                this.riskObj.bigCapitalSumInsured = (_referredRoutingSI > 0) ? _referredRoutingSI : bigRoutingSI;
            }
            else {
                this.riskObj.routingSumInsured = (_standardRoutingSI > 0) ? _standardRoutingSI : bigRoutingSI;
                this.riskObj.bigCapitalSumInsured = (_standardRoutingSI > 0) ? _standardRoutingSI : bigRoutingSI;
            }
        }
        else {
            this.riskObj.routingSumInsured = this.riskObj.capitalSumInsured;
            this.riskObj.bigCapitalSumInsured = this.riskObj.capitalSumInsured;
        }

        if (this.headerInfo.contractType == 'HIG') {
            this.validateCapitalSumInsured();
        }

    }

    setTotalPP() {
        this.riskObj.postingPremium = ((this.riskObj.totalPremium) / 365) * this.calcDays();
    }

    calcDays() {
        let date1 = moment(this.headerInfo.effectiveDate, "YYYY-MM-DD");
        let date2 = moment(this.headerInfo.endDate, "YYYY-MM-DD");
        return date2.diff(date1, 'days') + 1;//added +1 to always include endDate for calculation
        //return Math.ceil(timeDiff / (1000 * 3600 * 24));
    }

    loadComponent(component, prms) {
        let input = new DCLInput();
        input.component = component;
        input.viewContainerRef = this.contentArea;
        input.inputs = { parentRiskObj: this.riskObj, riskObj: this.currentRiskObj, headerInfo: this.headerInfo, clientDetails: this.clientDetails };
        input.callback = this.setOutputHandle;
        input.prms = { comp: this, prms: prms };
        this._dcl.loadComponent(input);
    }

    setOutputHandle(compRef, prms) {
        prms.prms.comp.selectedRiskComponent = compRef;

        if (compRef.instance.onSIChange != null) {
            compRef.instance.onSIChange.subscribe(() => {
                prms.prms.comp.setCapitalSI();
            });
        }
        if (compRef.instance.onPremiumChange != null) {
            compRef.instance.onPremiumChange.subscribe(() => {
                prms.prms.comp.setTotalPremium();
            });
        }
        if (compRef.instance.onRiskClsChange != null) {
            compRef.instance.onRiskClsChange.subscribe((data) => {
                prms.prms.comp.setReferredRisk(data);
                prms.prms.comp.setCapitalSI(); // this is to check big SI based on Risk Classification. Redmine#2660
            });
        }

        if (compRef.instance.onRtngFlgChange != null) {
            compRef.instance.onRtngFlgChange.subscribe((data) => {
                if (data) {
                    if (prms.prms.comp.riskObj.s5382Items.s5382Item && prms.prms.comp.riskObj.s5382Items.s5382Item.length > 0) {
                        let _ratginFlag = 'A';
                        for (let _item of prms.prms.comp.riskObj.s5382Items.s5382Item) {
                            if (_item.ratingFlag && _item.ratingFlag == 'M')
                                _ratginFlag = 'M';
                        }
                        prms.prms.comp.riskObj.ratingFlag = _ratginFlag;
                    }
                }
                prms.prms.comp.emitFlagChange();
            });
        }

        if (compRef.instance.emitDuplicateCheck != null) {
            compRef.instance.emitDuplicateCheck.subscribe(() => {
                prms.prms.comp.duplicateCheck();
            });
        }
        if (compRef.instance.emitonPlanChangeHandler != null) {
            compRef.instance.emitonPlanChangeHandler.subscribe((plancode) => { prms.prms.comp.onPlanChangeHandler(plancode); });
        }

        if (compRef.instance.prms != null) {
            compRef.instance.prms = prms.prms.prms;
        }
    }

    duplicateCheck() {
        debugger;
    }

    onPlanChangeHandler(plancode1) {
        if (this.clausesComp)
            this.clausesComp.setDefaultClause(plancode1);
    }

    removeRiskContent() {
        if (this.selectedRiskComponent != null)
            this._dcl.unloadComponent(this.selectedRiskComponent);
        this.currentRiskObj = null;
        jQuery(this.el).find("#S5382RiskComponent").empty();
    }

    validateCapitalSumInsured() {
        if (this.riskObj.RIRetentionCode && this.riskObj.isRIOverWrittenByUW == 'N') {

            this._bmsUtilService.getTotalGrossCapacity(this.riskObj.RIRetentionCode).subscribe((data) => this.compareSIWithTotGrossCap(data));
        }
        else
            this.setRIMethodEditableFlag();
    }

    compareSIWithTotGrossCap(totGrossCap) {

        let _totalGrossCapacity = (!totGrossCap) ? 0 : parseFloat("" + totGrossCap);
        this.riskObj.totalGrossCapacity = _totalGrossCapacity;
        let _sumInsuredAmount = parseFloat("" + this.riskObj.capitalSumInsured);

        if (_totalGrossCapacity > 0 && _sumInsuredAmount > _totalGrossCapacity && (this.riskObj.RIMethod == null || this.riskObj.RIMethod == "" || parseFloat("" + this.riskObj.RIMethod) != 8)) {
            this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Total Sum Insured is greater than Total Gross Capacity: " + _totalGrossCapacity + ",  RI is Required.", 10000));

            this.riskObj.RIRequired = "Yes";
            this.riskObj.RIMethod = "8";
        }
        else if (_sumInsuredAmount <= _totalGrossCapacity) {
            this.riskObj.RIRequired = "No";
            this.riskObj.RIMethod = this.riskObj.RIMethodSys;
        }
        this._riService.setRI().subscribe();
        this.setRIMethodEditableFlag();
    }

    setRIMethodEditableFlag() {
        let _sumInsuredAmount = parseFloat("" + this.riskObj.capitalSumInsured);

        let _totalGrossCapacity = parseFloat("" + this.riskObj.totalGrossCapacity);
        if (_sumInsuredAmount > _totalGrossCapacity && this.isUnderWriter == "N") {
            this.isRIMethodEditable = "N";
        }
        else {
            this.isRIMethodEditable = "Y";
        }
    }

    emitFlagChange() {
        this.onRtngFlgChange.emit("");
    }

    checkReferredRiskConditions() {
        this.isManuallyReferred = (this.riskObj.symRiskClassification != "Referred" && this.riskObj.riskClassification == "Referred") ? true : false;

        let _reasons = new Reasons();
        let isReferredRisk = false;
        let isDeclinedRisk = false;

        // if(this.headerInfo.contractType == 'HIG'){
        // isReferredRisk = true;
        // _reasons.reason.push("Referred Product.");
        // }

        if (this.riskObj.hasClaimExperience == 'Y') {
            isReferredRisk = true;
            _reasons.reason.push("With Claim Experience.");
        }

        this.riskObj.riskClassificationReasons.reasons = _reasons;

        if (isDeclinedRisk) {
            this.riskObj.symRiskClassification = "Declined";
        }
        else if (isReferredRisk) {
            this.riskObj.symRiskClassification = "Referred";
        }
        else this.riskObj.symRiskClassification = "Standard";

        // this._s5382Service.handleRiskClassification(this);
        this.checkReferredRisk(this);
    }
}