import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BasicUIModule } from '../../../../../common/components/utility/basicui.module';
import { LovModule } from "../../../../../common/services/lovdropdown/lov.module";
import { ClausesModule } from '../uimodules/clauses.module';
import { NomineeModule } from "../uimodules/nominee.module";
// import { DoctorDetailsModule } from '../uimodules/doctorDetails.module';
import { PaginationModule } from '../../../../../common/components/utility/pagination/pagination.module';
import { MultiSelectModule } from '../../../../../common/components/utility/selectbox/multi-selectbox.module';

import { S5382ServiceModule } from "./services/s5382.service.module";
import { S5382Component } from './s5382.component';
import { GeneralPageModule } from '../uimodules/generalpage.module'; //VK004

@NgModule({
    imports: [CommonModule, FormsModule, ReactiveFormsModule, BasicUIModule, LovModule, ClausesModule, NomineeModule, PaginationModule, MultiSelectModule, S5382ServiceModule, GeneralPageModule],
    declarations: [S5382Component],
    exports: [S5382Component]
})
export class S5382Module { }