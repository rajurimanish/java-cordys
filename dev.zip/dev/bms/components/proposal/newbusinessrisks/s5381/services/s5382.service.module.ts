import { NgModule } from '@angular/core';
import { S5382Service } from './s5382.service';

@NgModule({
    providers: [S5382Service]
})
export class S5382ServiceModule { }