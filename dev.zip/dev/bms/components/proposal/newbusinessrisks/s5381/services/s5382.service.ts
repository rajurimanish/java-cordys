import { Injectable } from '@angular/core';
declare var Rx: any;
declare var Observer: any;
import { CordysSoapWService } from "../../../../../../common/components/utility/cordys-soap-ws";
import { GetLOVData, SearchAdvancedConfig, Filter } from '../../../../../../common/components/utility/search/search.requests';
import { BMSConstants } from '../../../../../components/common/constants/bms_constants';
import { AlertMessagesService } from '../../../../../../common/components/utility/alertmessage/alertmessages.service';
import { AlertMessage } from '../../../../../../common/components/utility/alertmessage/alertmessages.model';
import { S5381, S5382ItemDetails, S5382Item, Benefit, BenefitItem } from '../appObjects/s5381';
import { ProgressBarComponent } from '../../../../../../common/components/utility/progressbar/progressbar.component';
import { ReferredReason, Reasons } from '../../../proposalheader/appobjects/referredreason';
import { ReferralReasons, ReferralReason } from '../../appobjects/referralReasons';

declare var moment: any;
declare var numeral: any;

@Injectable()
export class S5382Service {

    constructor(private _soapService: CordysSoapWService, public _alertMsgService: AlertMessagesService) {
    }

    public siFormat: string = "0,00";
    public bonusFormat: string = "0.00";
    public premiumFormat: string = "0,00.00";
    public rateFormat: string = "0.00000";
    public loadFormat: string = "0.00";
    public percentFormat: string = "0.00";

    getAreaCodeMultiplierRate(areaCodeDescItemsStr, effectiveDate, returnResults) {
        let load = 0;
        let results = [];
        if (areaCodeDescItemsStr) {
            // let descItem = planCode + areaCode;
            let request: GetLOVData = new GetLOVData().getRequest('ALL', 'ALL', 'ALL', 'ALL', 'ALL', 'ALL', 'AreaCodeRate', 'LOV');
            request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
            request.ADVANCE_CONFIG_XML.FILTERS = new Filter();

            request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push(
                { "@FIELD_NAME": "DESCITEM", "@FIELD_VALUE": areaCodeDescItemsStr, "@OPERATION": "IN", "@CONDITION": "AND" },
                { "@FIELD_NAME": "ITMFRM", "@FIELD_VALUE": moment(effectiveDate, "YYYY-MM-DD").format("YYYYMMDD"), "@OPERATION": "LT", "@CONDITION": "AND" },
                { "@FIELD_NAME": "ITMTO", "@FIELD_VALUE": moment(effectiveDate, "YYYY-MM-DD").format("YYYYMMDD"), "@OPERATION": "GT", "@CONDITION": "AND" });
            // this._soapService.callCordysSoapService("GetLOVData","http://schemas.opentext.com/lovhandler/v1.0", request , this.getAreaCodeMultiplierRateSuccessHandler, this.handleError, false, {comp:this});

            this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, null, null, false, null).success((data) => {

                if (data.tuple) {
                    if (Array.prototype.isPrototypeOf(data.tuple)) {
                        // load = numeral(numeral(data.tuple[0].old.T7090.ZCRYLOAD).format(rateformat)).value();
                        load = data.tuple[0].old.T7090.ZCRYLOAD;
                        results = data.tuple;
                    }
                    else if (data.tuple.old && data.tuple.old.T7090) {
                        // load =  numeral(data.tuple.old.T7090.ZCRYLOAD).format(prms.comp.loadFormat);
                        load = data.tuple.old.T7090.ZCRYLOAD;
                        results = [data.tuple];
                    }
                }

            }).error((response, status, errorText) => {
                this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error while getting multiplier rate for Area Codes - " + areaCodeDescItemsStr, 5000));
            });
        }

        if (returnResults)
            return results;
        else
            return load;
    }

    getOccClassRate(occClassCodeDescItemStr, effectiveDate, returnResults) {

        let occupationClassRate = 0;
        let results = [];
        if (occClassCodeDescItemStr) {
            // let descItem = planCode + occupationClassCode;
            let request: GetLOVData = new GetLOVData().getRequest('ALL', 'MED', 'ALL', 'ALL', 'ALL', 'ALL', 'Occupation Class Rate', 'LOV');
            request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
            request.ADVANCE_CONFIG_XML.FILTERS = new Filter();

            request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push(
                { "@FIELD_NAME": "DESCITEM", "@FIELD_VALUE": occClassCodeDescItemStr, "@OPERATION": "IN", "@CONDITION": "AND" },
                { "@FIELD_NAME": "ITMFRM", "@FIELD_VALUE": moment(effectiveDate, "YYYY-MM-DD").format("YYYYMMDD"), "@OPERATION": "LT", "@CONDITION": "AND" },
                { "@FIELD_NAME": "ITMTO", "@FIELD_VALUE": moment(effectiveDate, "YYYY-MM-DD").format("YYYYMMDD"), "@OPERATION": "GT", "@CONDITION": "AND" });

            this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, null, null, false, null).success((data) => {

                if (data.tuple) {
                    if (Array.prototype.isPrototypeOf(data.tuple)) {
                        occupationClassRate = data.tuple[0].old.T7091.ZCRYLOAD;
                        results = data.tuple;
                    }
                    else if (data.tuple.old && data.tuple.old.T7091) {
                        occupationClassRate = data.tuple.old.T7091.ZCRYLOAD;
                        results = [data.tuple];
                    }
                }

            }).error((response, status, errorText) => {
                this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error while getting rate for Occupation Class Codes - " + occClassCodeDescItemStr, 5000));
            });
        }

        if (returnResults)
            return results;
        else
            return occupationClassRate;
    }

    getPremiumChargesData(effectiveDate) {

        let _premiumCharges = BMSConstants.getS5382PremiumCharges();
        if (_premiumCharges) {
            return _premiumCharges;
        }
        else {

            let _records: any;

            let request: GetLOVData = new GetLOVData().getRequest('ALL', 'MED', 'ALL', 'ALL', 'ALL', 'S5382', 'S5382PremiumCharges', 'LOV');
            request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
            request.ADVANCE_CONFIG_XML.FILTERS = new Filter();
            request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push(
                { "@FIELD_NAME": "ITMFRM", "@FIELD_VALUE": moment(effectiveDate, "YYYY-MM-DD").format("YYYYMMDD"), "@OPERATION": "LT", "@CONDITION": "AND" },
                { "@FIELD_NAME": "ITMTO", "@FIELD_VALUE": moment(effectiveDate, "YYYY-MM-DD").format("YYYYMMDD"), "@OPERATION": "GT", "@CONDITION": "AND" });

            this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, null, null, false, null).success((data) => {
                if (data.tuple) {

                    if (Array.prototype.isPrototypeOf(data.tuple)) {
                        _records = data.tuple;
                    }
                    else if (data.tuple.old && data.tuple.old.T7089) {
                        _records = [data.tuple];
                    }

                    BMSConstants.setS5382PremiumCharges(_records);
                }
            }).error((response, status, errorText) => {
                ProgressBarComponent.hide();
                this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error while getting Premium Charges", 5000));
            });

            return _records;
        }
    }

    getPremiumCharges(planCode, age, effectiveDate) {
        let _record: any;
        if (planCode && age >= 0) {
            let request: GetLOVData = new GetLOVData().getRequest('ALL', 'MED', 'ALL', 'ALL', 'ALL', 'S5382', 'Premium Charges', 'LOV');
            request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
            request.ADVANCE_CONFIG_XML.FILTERS = new Filter();
            request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push(
                { "@FIELD_NAME": "DESCITEM", "@FIELD_VALUE": planCode, "@OPERATION": "STARTSWITH", "@CONDITION": "AND" },
                { "@FIELD_NAME": "ITMFRM", "@FIELD_VALUE": moment(effectiveDate, "YYYY-MM-DD").format("YYYYMMDD"), "@OPERATION": "LT", "@CONDITION": "AND" },
                { "@FIELD_NAME": "ITMTO", "@FIELD_VALUE": moment(effectiveDate, "YYYY-MM-DD").format("YYYYMMDD"), "@OPERATION": "GT", "@CONDITION": "AND" },
                { "@FIELD_NAME": "SUBSTRING(DESCITEM,4,3)", "@FIELD_VALUE": age, "@OPERATION": "GTEQ", "@CONDITION": "AND" });

            this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, null, null, false, null).success((data) => {
                if (data.tuple) {

                    if (Array.prototype.isPrototypeOf(data.tuple)) {
                        _record = data.tuple[0].old.T7089;
                    }
                    else if (data.tuple.old && data.tuple.old.T7089) {
                        _record = data.tuple.old.T7089;
                    }
                }
            }).error((response, status, errorText) => {
                this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error while getting Premium Charges data object for Plan Code - " + planCode, 5000));
            });
        }

        return _record;
    }

    calculateAge(riskObj) {
        if (riskObj && riskObj.inclusionDate && riskObj.dateOfBirth) {
            let _inclusionDate = moment(riskObj.inclusionDate, "YYYY-MM-DD");
            let _insuredDOB = moment(riskObj.dateOfBirth, "YYYY-MM-DD");
            // let age = _inclusionDate.diff(_insuredDOB, 'years'); //Redmine#2633- Age should be calculate on Year (not on date) for all medical products.
            let dobYear = _insuredDOB.year();
            let inclDtYear = _inclusionDate.year();
            let age = inclDtYear - dobYear;

            riskObj.insuredAge = age;
        }
        else {
            riskObj.insuredAge = 0;
        }
    }

    calculatePremium(riskObj, parentRiskObj, effectiveDate) {

        riskObj.basicPremium = 0;
        riskObj.ibrPremium = 0;
        riskObj.maternityPremium = 0;
        riskObj.emeRlb = 0;
        riskObj.emeRlbZERTTY = 0;
        let _premiumCharges = 0;
        let _maternityPremiumCharges = 0;
        let _IBRPremiumCharges = 0;

        if (riskObj.plan) {
            ProgressBarComponent.show('Calculating premium...', { dialogSize: 'm', progressType: 'primary' });
			/*
			let _inclusionDate = moment(riskObj.inclusionDate, "YYYY-MM-DD");
			let _insuredDOB = moment(riskObj.dateOfBirth, "YYYY-MM-DD");
			let age = _inclusionDate.diff(_insuredDOB, 'years');*/
            this.calculateAge(riskObj);
            let age = riskObj.insuredAge;

            // let _premiumChargesData = this.getPremiumCharges(riskObj.plan, age, effectiveDate);
            let _premiumChargesData: any;
            let _premiumChargesDataRecords = this.getPremiumChargesData(effectiveDate); //filter results by passing planDescItemsStr
            if (_premiumChargesDataRecords && _premiumChargesDataRecords.length > 0) {
                let _planPremCharges = _premiumChargesDataRecords.filter((_data) => _data.old.T7089.DESCITEM.indexOf(riskObj.plan) == 0);
                if (_planPremCharges && _planPremCharges.length > 0) {

                    for (let _planPremRec of _planPremCharges) {
                        let _planAge = _planPremRec.old.T7089.DESCITEM.substring(riskObj.plan.length);
                        if (age <= _planAge) {
                            _premiumChargesData = _planPremRec;
                            break;
                        }
                    }
                }
            }
            else {
                _premiumChargesData = this.getPremiumCharges(riskObj.plan, age, effectiveDate);
            }


            if (_premiumChargesData) {

                _premiumCharges = numeral(_premiumChargesData.old.T7089.AMTA01).value();
                _maternityPremiumCharges = numeral(_premiumChargesData.old.T7089.AMTA02).value();
                _IBRPremiumCharges = numeral(_premiumChargesData.old.T7089.AMTA03).value();

                _premiumCharges = (_premiumCharges > 0) ? (_premiumCharges * 0.01) : _premiumCharges;
                _maternityPremiumCharges = (_maternityPremiumCharges > 0) ? (_maternityPremiumCharges * 0.01) : _maternityPremiumCharges;
                _IBRPremiumCharges = (_IBRPremiumCharges > 0) ? (_IBRPremiumCharges * 0.01) : _IBRPremiumCharges;

                if (riskObj.ZOFLG01 == 'N' && riskObj.ZOFLG02 == 'N') {
                    riskObj.emeRlb = 0;
                }

                if (riskObj.ZOFLG01 == 'Y') {
                    if (parentRiskObj.familyEmeOrRlb == 'N') {
                        if (age > 17) {
                            let _amtb02 = numeral(_premiumChargesData.old.T7089.AMTB02).value();
                            _amtb02 = (_amtb02 > 0) ? (_amtb02 * 0.01) : _amtb02;
                            riskObj.emeRlb = riskObj.emeRlb + _amtb02;

                            let _amtb04 = numeral(_premiumChargesData.old.T7089.AMTB04).value();
                            _amtb04 = (_amtb04 > 0) ? (_amtb04 * 0.01) : _amtb04;
                            riskObj.emeRlbZERTTY = _amtb04;

                        } else {
                            let _amtc02 = numeral(_premiumChargesData.old.T7089.AMTC02).value();
                            _amtc02 = (_amtc02 > 0) ? (_amtc02 * 0.01) : _amtc02;
                            riskObj.emeRlb = riskObj.emeRlb + _amtc02;

                            let _amtc04 = numeral(_premiumChargesData.old.T7089.AMTC04).value();
                            _amtc04 = (_amtc04 > 0) ? (_amtc04 * 0.01) : _amtc04;
                            riskObj.emeRlbZERTTY = _amtc04;
                        }
                    }
                    else if (parentRiskObj.familyEmeOrRlb == 'Y' && riskObj.itemNo == 1) {
                        let _amtd02 = numeral(_premiumChargesData.old.T7089.AMTD02).value();
                        _amtd02 = (_amtd02 > 0) ? (_amtd02 * 0.01) : _amtd02;
                        riskObj.emeRlb = riskObj.emeRlb + _amtd02;

                        let _amtd04 = numeral(_premiumChargesData.old.T7089.AMTD04).value();
                        _amtd04 = (_amtd04 > 0) ? (_amtd04 * 0.01) : _amtd04;
                        riskObj.emeRlbZERTTY = _amtd04;
                    }
                }

                if (riskObj.ZOFLG02 == 'Y') {
                    if (parentRiskObj.familyEmeOrRlb == 'N') {
                        if (age > 17) {
                            let _amtb03 = numeral(_premiumChargesData.old.T7089.AMTB03).value();
                            _amtb03 = (_amtb03 > 0) ? (_amtb03 * 0.01) : _amtb03;
                            riskObj.emeRlb = riskObj.emeRlb + _amtb03;
                        } else {
                            let _amtc03 = numeral(_premiumChargesData.old.T7089.AMTC03).value();
                            _amtc03 = (_amtc03 > 0) ? (_amtc03 * 0.01) : _amtc03;
                            riskObj.emeRlb = riskObj.emeRlb + _amtc03;
                        }
                    }
                    else if (parentRiskObj.familyEmeOrRlb == 'Y' && riskObj.itemNo == 1) {
                        let _amtd03 = numeral(_premiumChargesData.old.T7089.AMTD03).value();
                        _amtd03 = (_amtd03 > 0) ? (_amtd03 * 0.01) : _amtd03;
                        riskObj.emeRlb = riskObj.emeRlb + _amtd03;
                    }
                }
            }
            else {
                this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Insured " + riskObj.itemNo + " : Cannot get Premium details for insured age - " + age, 6000));
            }

        }

        riskObj.basicPremium = numeral(numeral(_premiumCharges).format(this.premiumFormat)).value();

        let rate: any = riskObj.occupationClassRate;
        let load: any = riskObj.load;

        rate = (rate == null || rate == "") ? 0 : parseFloat("" + rate);
        load = (load == null || load == "") ? 0 : parseFloat("" + load);

        let occRateMultiplierPrem = 0;
        if (rate > 0) {
            occRateMultiplierPrem = _premiumCharges * rate / 100;
        }

        if (load > 0) {
            let _loadRatePremium = occRateMultiplierPrem + (_premiumCharges * (load - 100) / 100);
            // riskObj.basicPremium = _loadRatePremium;
            riskObj.basicPremium = numeral(numeral(_loadRatePremium).format(this.premiumFormat)).value();
        } else if (occRateMultiplierPrem > 0) {
            // riskObj.basicPremium = occRateMultiplierPrem;
            riskObj.basicPremium = numeral(numeral(occRateMultiplierPrem).format(this.premiumFormat)).value();
        }

        if (rate > 0 && load > 0) {
            _maternityPremiumCharges = (_maternityPremiumCharges * rate / 100) + (_maternityPremiumCharges * (rate - 100));
            _IBRPremiumCharges = (_IBRPremiumCharges * rate / 100) + (_IBRPremiumCharges * (load - 100) / 100);

            if (riskObj.maternityOption == 'Y')
                riskObj.maternityPremium = numeral(numeral(_maternityPremiumCharges).format(this.premiumFormat)).value();

            riskObj.ibrPremium = numeral(numeral(_IBRPremiumCharges).format(this.premiumFormat)).value();
        }


        riskObj.loadingPremium = 0;
        let loadOcc: any = riskObj.loadingOccupation;
        let loadTravel: any = riskObj.loadingTravel;
        let loadClaim: any = riskObj.loadingClaim;
        let loadOthers: any = riskObj.loadingOthers;
        let _loadOcc = (loadOcc == null || loadOcc == "") ? 0 : parseFloat("" + loadOcc);
        let _loadTravel = (loadTravel == null || loadTravel == "") ? 0 : parseFloat("" + loadTravel);
        let _loadClaim = (loadClaim == null || loadClaim == "") ? 0 : parseFloat("" + loadClaim);
        let _loadOthers = (loadOthers == null || loadOthers == "") ? 0 : parseFloat("" + loadOthers);

        let loadTotal = _loadOcc + _loadTravel + _loadClaim + _loadOthers;

        if (loadTotal > 0) {
            riskObj.loadingPremium = riskObj.basicPremium * loadTotal / 100;
            riskObj.loadingPremium = numeral(numeral(riskObj.loadingPremium).format(this.premiumFormat)).value();
        }

        riskObj.totalPremium = parseFloat("" + numeral(riskObj.basicPremium).value()) + parseFloat("" + numeral(riskObj.loadingPremium).value()) + parseFloat("" + numeral(riskObj.ibrPremium).value()) + parseFloat("" + numeral(riskObj.maternityPremium).value());

        if (riskObj.discountPercent > 0) {
            // riskObj.totalPremium = ( (parseFloat(""+numeral(riskObj.totalPremium).value()) + parseFloat(""+numeral(riskObj.emeRlbZERTTY).value())) * (100 - parseFloat(""+riskObj.discountPercent))/100) - parseFloat(""+numeral(riskObj.emeRlbZERTTY).value()) ;
            let _totAmount = parseFloat("" + numeral(riskObj.totalPremium).value());
            let _discountPercent = parseFloat("" + numeral(riskObj.discountPercent).value());
            riskObj.totalPremium = _totAmount - (_totAmount * _discountPercent * 0.01);
        }
        else if (riskObj.discountAmount > 0) {
            riskObj.totalPremium = parseFloat("" + numeral(riskObj.totalPremium).value()) - parseFloat("" + numeral(riskObj.discountAmount).value());
        }

        riskObj.totalPremium = numeral(numeral(riskObj.totalPremium).format(this.premiumFormat)).value();
        riskObj.totalAnnualPremium = riskObj.totalPremium;

        let _totAmnt = riskObj.totalPremium - riskObj.emeRlbZERTTY;
        riskObj.integratedTotalPremium = numeral(numeral(_totAmnt).format(this.premiumFormat)).value();

        if (riskObj.plan) {
            ProgressBarComponent.hide();
        }
    }

    getPlanCodesRecords(planCodeDescItemsStr, effectiveDate) {
        let results = [];
        if (planCodeDescItemsStr) {

            let request: GetLOVData = new GetLOVData().getRequest('ALL', 'MED', 'ALL', 'ALL', 'ALL', 'S5382', 'Plan Data', 'LOV');
            request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
            request.ADVANCE_CONFIG_XML.FILTERS = new Filter();

            request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push(
                { "@FIELD_NAME": "DESCITEM", "@FIELD_VALUE": planCodeDescItemsStr, "@OPERATION": "IN", "@CONDITION": "AND" },
                { "@FIELD_NAME": "ITMFRM", "@FIELD_VALUE": moment(effectiveDate, "YYYY-MM-DD").format("YYYYMMDD"), "@OPERATION": "LT", "@CONDITION": "AND" },
                { "@FIELD_NAME": "ITMTO", "@FIELD_VALUE": moment(effectiveDate, "YYYY-MM-DD").format("YYYYMMDD"), "@OPERATION": "GT", "@CONDITION": "AND" });

            this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, null, null, false, null).success((data) => {

                if (data.tuple) {
                    if (Array.prototype.isPrototypeOf(data.tuple)) {
                        results = data.tuple;
                    }
                    else if (data.tuple.old && data.tuple.old.T7088) {
                        results = [data.tuple];
                    }
                }

            }).error((response, status, errorText) => {
                this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error while getting Plan codes - " + planCodeDescItemsStr, 5000));
            });
        }

        return results;
    }


    addBenefitsFromPlanRecord(records: any, riskObj, parentRiskObj) {

        riskObj.routingSumInsured = 0;
        if (records) {
            riskObj.planBenefits.benefit = [];

            let worldwide_HORS = 0;
            let worldwide_HOTS = 0;

            for (let _rec of records) {

                if (_rec.old.T7088.ZGMCDE) {
                    //ZGMCDE,ZGMDSC,LONGDESC,ZMFLG,ZMPAID01,ZMPAID02,ZOFLG01,ZOFLG02,ZSPAID01,ZSPAID02,ZIBRFLG,TOTSI,STPLPC,IND,SUMI,ZTPAID,ITMFRM,ITMTO,ZBINDIC
                    let benefit = new BenefitItem();
                    benefit.seqNumber = riskObj.planBenefits.benefit.length + 1;
                    benefit.coverageCode = _rec.old.T7088.ZGMCDE;
                    benefit.coverageDescription = _rec.old.T7088.ZGMDSC;
                    benefit.sumInsured = _rec.old.T7088.SUMI;
                    benefit.siWorldWide = _rec.old.T7088.ZTPAID;

                    riskObj.planBenefits.benefit.push(benefit);

                    if (benefit.seqNumber == 1) {
                        let si: any = _rec.old.T7088.TOTSI;
                        let emeSI: any = _rec.old.T7088.ZSPAID01;

                        si = (si == null || si == "") ? 0 : parseFloat("" + si);
                        emeSI = (emeSI == null || emeSI == "") ? 0 : parseFloat("" + emeSI);

                        riskObj.capitalSumInsured = (si - emeSI);
                        riskObj.emeSumInsured = emeSI;
                        riskObj.ibrOptionPlan = (_rec.old.T7088.ZIBRFLG) ? _rec.old.T7088.ZIBRFLG : "";
                        riskObj.ibrOption = riskObj.ibrOptionPlan;
                        riskObj.maternityOptionPlan = (_rec.old.T7088.ZMFLG) ? _rec.old.T7088.ZMFLG : "";
                        riskObj.maternityOption = riskObj.maternityOptionPlan;

                        //As the Familty EME/RLB is always 'N', Not required write the logic to populate AEA Fee, EME/RLB(ZEMERLB) and EME/RLB(ZERTTY01)
                        if (_rec.old.T7088.ZOFLG01 && _rec.old.T7088.ZOFLG01 == "Y") {
                            if (parentRiskObj.familyEmeOrRlb == "Y") {
                            }
                        }
                        if (_rec.old.T7088.ZOFLG02 && _rec.old.T7088.ZOFLG02 == "Y") {
                            if (parentRiskObj.familyEmeOrRlb == "Y") {
                            }
                        }

                        riskObj.ZOFLG01 = _rec.old.T7088.ZOFLG01;
                        riskObj.ZOFLG02 = _rec.old.T7088.ZOFLG02;
                    }
                    let _siWorldWide: any = benefit.siWorldWide;
                    _siWorldWide = (_siWorldWide == null || _siWorldWide == "") ? 0 : parseFloat("" + _siWorldWide);

                    if (_rec.old.T7088.ZGMCDE == "HORS")
                        worldwide_HORS = _siWorldWide;
                    else if (_rec.old.T7088.ZGMCDE == "HOTS")
                        worldwide_HOTS = _siWorldWide;
                }
            }
            if (worldwide_HORS > 0) {
                riskObj.routingSumInsured = worldwide_HORS;
            } else if (worldwide_HOTS > 0) {
                riskObj.routingSumInsured = worldwide_HOTS;
            }
        }
    }


    checkReferredRiskConditions(riskObj, contractType, _ageLimitRec, occCodeList, referralReasonList, selectableReasonsList) {
        let _reasons = new Reasons();
        let isReferredRisk = false;
        let isDeclinedRisk = false;

        // if(contractType=='HIG'){
        // isReferredRisk = true;
        // _reasons.reason.push("Referred Product.");
        // }

        if (riskObj.hasClaimExperience == 'Y') {
            isReferredRisk = true;
            _reasons.reason.push("With Claim Experience.");
            this.addReferralReason(riskObj, '11', true, referralReasonList, selectableReasonsList);
        }
        else {
            this.deleteReferralReason(riskObj, '11', true);
        }

        this.calculateAge(riskObj);

        // let reflAgeLimits = this.lovDropDownService.lovDataList.referralAgeLimits.find((_data)=> _data.DESCITEM == this.riskObj.riskType);
        riskObj.ageLimitFlag = "";
        if (_ageLimitRec && riskObj.dateOfBirth && riskObj.occupationCode) {
            let _minAgeLimit = 0;
            let _maxAgeLimit = 0;
            let _minAgeLimitInd = 'Y';
            let _maxAgeLimitInd = 'Y';

            let _adultMinAgeLimit = (_ageLimitRec.ZAGELMT03) ? parseInt("" + _ageLimitRec.ZAGELMT03) : 0;
            //GA001 START
            let _adultMaxAgeLimit = 0;
			if (BMSConstants.getBMSCaseInfo().businessFunction == "Renewal") {
				_adultMaxAgeLimit = (_ageLimitRec.ZAGELMT07) ? parseInt("" + _ageLimitRec.ZAGELMT07) : 0;
			} else {
				_adultMaxAgeLimit = (_ageLimitRec.ZAGELMT05) ? parseInt("" + _ageLimitRec.ZAGELMT05) : 0;
            }
            //let _adultMaxAgeLimit = (_ageLimitRec.ZAGELMT05) ? parseInt("" + _ageLimitRec.ZAGELMT05) : 0;
            //GA001 END

            let _chidldMinAgeLimit = (_ageLimitRec.ZAGELMT04) ? parseInt("" + _ageLimitRec.ZAGELMT04) : 0;
            let _chidldMaxAgeLimit = (_ageLimitRec.ZAGELMT06) ? parseInt("" + _ageLimitRec.ZAGELMT06) : 0;


            if (_chidldMinAgeLimit > 0 && _chidldMaxAgeLimit > 0 && (riskObj.occupationCode == '7STU' || riskObj.occupationCode == '7CLD')) {
                _minAgeLimit = _chidldMinAgeLimit;
                _maxAgeLimit = _chidldMaxAgeLimit;
                _minAgeLimitInd = (_ageLimitRec.ZAGEIND02) ? _ageLimitRec.ZAGEIND02 : "Y";
                _maxAgeLimitInd = (_ageLimitRec.ZAGEIND03) ? _ageLimitRec.ZAGEIND03 : "Y";
            }
            else {

                _minAgeLimit = _adultMinAgeLimit;
                _maxAgeLimit = _adultMaxAgeLimit;
                if (_chidldMinAgeLimit == 0 || _chidldMaxAgeLimit == 0) {
                    _minAgeLimitInd = (_ageLimitRec.ZAGEIND02) ? _ageLimitRec.ZAGEIND02 : "Y";
                    _maxAgeLimitInd = (_ageLimitRec.ZAGEIND03) ? _ageLimitRec.ZAGEIND03 : "Y";
                }
            }

			/*if(riskObj.occupationCode == '7STU' || riskObj.occupationCode == '7CLD'){ //Child
				_maxAgeLimit = (_ageLimitRec.ZAGELMT06) ? parseInt(""+_ageLimitRec.ZAGELMT06) : 0;
				_minAgeLimit = (_ageLimitRec.ZAGELMT04) ? parseInt(""+_ageLimitRec.ZAGELMT04) : 0;
			}
			else { //Adult
				_maxAgeLimit = (_ageLimitRec.ZAGELMT05) ? parseInt(""+_ageLimitRec.ZAGELMT05) : 0;
				_minAgeLimit = (_ageLimitRec.ZAGELMT03) ? parseInt(""+_ageLimitRec.ZAGELMT03) : 0;
			}*/

            if (_maxAgeLimitInd == 'D') {
                if (riskObj && riskObj.inclusionDate && riskObj.dateOfBirth) {
                    let _inclusionDate = moment(riskObj.inclusionDate, "YYYY-MM-DD");
                    let _insuredDOB = moment(riskObj.dateOfBirth, "YYYY-MM-DD");

                    let _ageInDays = moment.duration(_inclusionDate.diff(_insuredDOB)).asDays();
                    if (_ageInDays > _maxAgeLimit) {
                        riskObj.ageLimitFlag = "G";
                    }
                }
            }
            else if (Number(riskObj.insuredAge) > _maxAgeLimit) {
                riskObj.ageLimitFlag = "G";
            }

            if (riskObj.ageLimitFlag != "G") {
                if (_minAgeLimitInd == 'D') {
                    if (riskObj && riskObj.inclusionDate && riskObj.dateOfBirth) {
                        let _inclusionDate = moment(riskObj.inclusionDate, "YYYY-MM-DD");
                        let _insuredDOB = moment(riskObj.dateOfBirth, "YYYY-MM-DD");

                        let _ageInDays = moment.duration(_inclusionDate.diff(_insuredDOB)).asDays();
                        if (_ageInDays < _minAgeLimit) {
                            riskObj.ageLimitFlag = "L";
                        }
                    }
                }
                else if (Number(riskObj.insuredAge) < _minAgeLimit) {
                    riskObj.ageLimitFlag = "L";
                }
            }

			/*if(Number(riskObj.insuredAge) > _maxAgeLimit) {
				isReferredRisk = true;
				riskObj.ageLimitFlag = "G";
				_reasons.reason.push("Insured Age greater than maximum allowed age "+_maxAgeLimit);
				
				this.addReferralReason(riskObj, '01', true, referralReasonList, selectableReasonsList);
			}
			else if(Number(riskObj.insuredAge) < _minAgeLimit) {
				
				riskObj.ageLimitFlag = "L";
			}
			else {
				riskObj.ageLimitFlag = "VALID";
			}*/

            if (riskObj.ageLimitFlag == "G") {
                isReferredRisk = true;
                _reasons.reason.push("Insured (" + riskObj.itemNo + ") Age greater than maximum allowed age " + _maxAgeLimit);
                this.addReferralReason(riskObj, '01', true, referralReasonList, selectableReasonsList);
            }
            else if (riskObj.ageLimitFlag == "") {
                riskObj.ageLimitFlag = "VALID";
            }
        }

        if (riskObj.ageLimitFlag != 'G') {
            this.deleteReferralReason(riskObj, '01', true);
			/*let _ageRefReason = riskObj.referralReasons.referralReason.find((_data1)=> _data1.code=='01');
			if(_ageRefReason && _ageRefReason.isSysReferred == 'Y'){
				_ageRefReason.isSysReferred = 'N';
			}*/
        }

        if (riskObj.occupationCode) {
            let _rec = occCodeList.find((_data) => _data.VALUE == riskObj.occupationCode);

            if (_rec && _rec.REFERREDRISK && _rec.REFERREDRISK == 'Y') {
                isReferredRisk = true;
                riskObj.occRiskClassification = "Referred";
                _reasons.reason.push("Occupation code of type Referred selected");
                this.addReferralReason(riskObj, '05', true, referralReasonList, selectableReasonsList);
            }
            else if (_rec && _rec.REFERREDRISK && _rec.REFERREDRISK == 'D') {
                isDeclinedRisk = true;
                riskObj.occRiskClassification = "Declined";
                _reasons.reason.push("Declined : Occupation code of type Declined selected");
            }
            else {
                riskObj.occRiskClassification = "Standard";
            }

            if (riskObj.occRiskClassification != 'Referred') {
                this.deleteReferralReason(riskObj, '05', true);
				/*let _occRefReason = riskObj.referralReasons.referralReason.find((_data1)=> _data1.code=='05');
				if(_occRefReason && _occRefReason.isSysReferred == 'Y'){
					_occRefReason.isSysReferred = 'N';
				}*/
            }
        }

        if (riskObj.referralReasons.referralReason && riskObj.referralReasons.referralReason.length > 0 && riskObj.referralReasons.referralReason.find((_data1) => _data1.isSysReferred != 'Y')) {
            isReferredRisk = true;
            _reasons.reason.push("Referral Reason added");
        }

        riskObj.riskClassificationReasons.reasons = _reasons;

        if (isDeclinedRisk == true) {
            riskObj.symRiskClassification = "Declined";
        }
        else if (isReferredRisk == true) {
            riskObj.symRiskClassification = "Referred";
        }
        else riskObj.symRiskClassification = "Standard";

        // this.handleRiskClassification();
    }

    addReferralReason(riskObj, refCode, isSysRef, refrlReasonsList, selectableReflReasonsList) {

        let refReasonRecord = refrlReasonsList.find(_data => (_data.code === refCode));

        if (!refReasonRecord) {
            let _refReasons = [];
            let request: GetLOVData = new GetLOVData().getRequest('ALL', 'MED', 'ALL', 'ALL', 'ALL', 'ALL', 'Referral Reasons', 'LOV');
            request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
            request.ADVANCE_CONFIG_XML.FILTERS = new Filter();

            this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, null, null, false, null).success((data) => {
                if (data.tuple) {
                    if (Array.prototype.isPrototypeOf(data.tuple)) {
                        for (let _rec of data.tuple) {
                            _refReasons.push(_rec.old.DESCPF);
                        }
                    }
                    else if (data.tuple && data.tuple.old && data.tuple.old.DESCPF) {
                        _refReasons.push(data.tuple.old.DESCPF);
                    }
                }
            }).error((response, status, errorText) => {
                this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error while getting Referral Reasons ", 5000));
            });

            if (_refReasons && _refReasons.length > 0) {
                refReasonRecord = _refReasons.find(_data => (_data.code === refCode));
            }
        }

        if (refReasonRecord) {
            if (riskObj.referralReasons.referralReason && (riskObj.referralReasons.referralReason.length == 0 || !riskObj.referralReasons.referralReason.find((_data1) => _data1.code == refCode))) {
                let _referralReason = new ReferralReason();
                _referralReason.seqNumber = riskObj.referralReasons.referralReason.length + 1;
                _referralReason.code = refReasonRecord.code;
                _referralReason.description = refReasonRecord.description;
                _referralReason.isSysReferred = (isSysRef) ? 'Y' : 'N';

                riskObj.referralReasons.referralReason.push(_referralReason);

                // this.removeRefrlReasonFromSelectionList(refCode, selectableReflReasonsList);
            }
            else if (riskObj.referralReasons.referralReason && riskObj.referralReasons.referralReason.find((_data1) => _data1.code == refCode)) {
                let _refReason = riskObj.referralReasons.referralReason.find((_data1) => _data1.code == refCode);
                _refReason.isSysReferred = (isSysRef) ? 'Y' : 'N';

                // this.removeRefrlReasonFromSelectionList(refCode, selectableReflReasonsList);
            }
        }
    }

    removeRefrlReasonFromSelectionList(refCode, selectableReflReasonsList) {
        if (selectableReflReasonsList) {
            let _selectedRefReason = selectableReflReasonsList.find(item => item.code == refCode);
            if (_selectedRefReason) {
                selectableReflReasonsList.splice(selectableReflReasonsList.indexOf(_selectedRefReason), 1);
            }
        }
    }

    deleteReferralReason(riskObj, refCode, sysRef) {
        let refReasonRecord = riskObj.referralReasons.referralReason.find((_data1) => _data1.code == refCode);
        if (refReasonRecord && (!sysRef || (sysRef && refReasonRecord.isSysReferred == 'Y'))) {
            riskObj.referralReasons.referralReason.splice(riskObj.referralReasons.referralReason.indexOf(refReasonRecord), 1);
        }
    }

    handleRiskClassification(comp) {

        if (comp.riskObj.symRiskClassification == "Declined")
            comp.riskObj.riskClassification = "Declined";
        else if (comp.riskObj.symRiskClassification == "Referred" || comp.riskObj.riRiskClassification == "Referred")
            comp.riskObj.riskClassification = "Referred";
        else if (comp.isManuallyReferred)
            comp.riskObj.riskClassification = "Referred";
        else
            comp.riskObj.riskClassification = "Standard";

        comp.setRiskClassification(comp);
    }

    setRiskClassification(comp, isSubScreeen) {
        if (comp.riskObj.symRiskClassification != null && comp.riskObj.symRiskClassification != "" && (comp.riskObj.symRiskClassification == "Referred" || comp.riskObj.symRiskClassification == "Declined")) {
            let statusTxt = (comp.riskObj.symRiskClassification != null && comp.riskObj.symRiskClassification != "") ? comp.riskObj.symRiskClassification : comp.riskObj.riskClassification;
            comp.riskObj.riskClassificationReason = "System marked as " + statusTxt;
        }
        else {
            if (comp.riskObj.riskClassificationReason != null && comp.riskObj.riskClassificationReason != "" && (comp.riskObj.riskClassificationReason != "System marked as Standard"
                && comp.riskObj.riskClassificationReason.indexOf("System marked as ") != -1)) {
                comp.riskObj.riskClassificationReason = "";
            }
        }
        if (isSubScreeen) {
            comp.onRiskClsChange.emit(comp.riskObj.itemNo);
        } else {
            comp.onRiskClsChange.emit("");
        }
    }

    setInsuredGenderFromNRIC(riskObj) {
        if (riskObj.IdProofNo) {
            let isValidNRICFormat = new RegExp("[0-9]{6}-[0-9]{2}-[0-9]{4}$").test(riskObj.IdProofNo);
            if (isValidNRICFormat == true) {
                if (riskObj.IdProofNo) {
                    let lastDigit = riskObj.IdProofNo.substring(riskObj.IdProofNo.length - 1);
                    if (/^-?\d*[02468]$/.test(lastDigit)) {
                        riskObj.gender = 'F';
                    } else if (/^-?\d*[13579]$/.test(lastDigit)) {
                        riskObj.gender = 'M';
                    }
                }
            }
        }
    }

}