import { Component, OnInit, ViewChild, ElementRef, EventEmitter, AfterViewInit, ViewContainerRef } from '@angular/core';
declare var Observer: any;
import { DCLInput, CustomDCLService } from '../../../../../common/services/customdcl.service';
import { LOV_Field, LOVDropDownService, SearchFilter } from "../../../../../common/services/lovdropdown/lovdropdown.service";
import { S5381, S5382ItemDetails, Benefit, BenefitItem } from './appobjects/s5381';
import { ModalInput } from '../../../../../common/components/utility/modal/modal';
import { SearchInput } from "../../../../../common/components/utility/search/genericsearch";
import { Clause } from "../appobjects/clause";
import { ClausesComponent } from "../uimodules/clauses.component";
import { NomineeDetails } from "../appobjects/nomineeslist";
import { GetLOVData, SearchAdvancedConfig, Filter } from '../../../../../common/components/utility/search/search.requests';
import { CordysSoapWService } from "../../../../../common/components/utility/cordys-soap-ws";
import { ProposalHeader } from '../../proposalheader/appobjects/proposalheader';
import { ClientDetails } from '../../../../../common/components/client/appobjects/client';
import { AlertMessagesService } from '../../../../../common/components/utility/alertmessage/alertmessages.service';
import { AlertMessage } from '../../../../../common/components/utility/alertmessage/alertmessages.model';
import { ApplicationUtilService } from "../../../../../common/services/application.util.service";
import { S5382Service } from "./services/s5382.service";
import { ExtraTextDialogData } from "../dialogs/extratext.dialog.data";
import { BMSConstants } from '../../../common/constants/bms_constants';
import { ProgressBarComponent } from '../../../../../common/components/utility/progressbar/progressbar.component';
import { ReferredReason, Reasons } from '../../proposalheader/appobjects/referredreason';
import { ReferralReasons, ReferralReason } from '../appobjects/referralReasons';
import { CaseInfo } from '../../../../../common/components/appobjects/caseinfo';

declare var moment: any;
declare var jQuery: any;
declare var numeral: any;

@Component({
    selector: 's5382-risk-component',
    templateUrl: 'app/bms/components/proposal/newbusinessrisks/s5381/s5382.template.html',
    inputs: ["parentRiskObj", "riskObj", 'clientDetails', 'headerInfo'],
    outputs: ['onPremiumChange', 'onSIChange', 'onpostedpremiumchange', 'onRiskClsChange', 'emitDuplicateCheck', 'emitonPlanChangeHandler', "onRtngFlgChange"]
})
export class S5382Component implements OnInit {

    private el: HTMLElement;
    private isCollapsedMode: boolean = false;
    private collapseInsuredInfo: boolean = false;
    private isCoverInfoCollapsed: boolean = false;
    private isNomineeInfoCollapsed: boolean = false;
    private collapseClausesInfo: boolean = false;
    private isExclusionPageCollapsed: boolean = false;
    private isGeneralPageCollapsed: boolean = false;
    private isLoadingSectionCollapsed: boolean = true;
    private isMatnBenefitCollapsed: boolean = true;
    private isIncrInternlCoverCollapsed: boolean = true;

    public riskObj: S5382ItemDetails;
    public parentRiskObj: S5381;
    public clientDetails: ClientDetails;
    public headerInfo: ProposalHeader;

    private referralReasons = [];

    public siFormat: string = "0,00";
    public bonusFormat: string = "0.00";
    public premiumFormat: string = "0,00.00";
    public rateFormat: string = "0.00000";
    public loadFormat: string = "0.00";
    public percentFormat: string = "0.00";

    private DOBCtrl: any;
    private discPrcntCtrl: any;
    private discAmntCtrl: any;
    private maternityDateCtrl: any;
    private maternityPremCtrl: any;
    private termnDateCtrl: any;
    private disableMaternityOption = "Y";
    private disableMaternityPrem = "Y";
    private disableForm = "N";
    // private planPremiumChargesData:any;
    public position = 1;
    public sizeObj = { length: 0, orglength: 0 };
    public contentSizeObs: any;
    public itemPerPage = 5;
    public maxPageCount = 10;

    onSIChange = new EventEmitter<any>();
    onPremiumChange = new EventEmitter<any>();
    onpostedpremiumchange = new EventEmitter<any>();
    onRiskClsChange = new EventEmitter<any>();
    onRtngFlgChange = new EventEmitter<any>();
    emitDuplicateCheck = new EventEmitter<any>();
    emitonPlanChangeHandler = new EventEmitter<any>();

    @ViewChild(ClausesComponent) private clausesComp: ClausesComponent;
    @ViewChild('xtModal', { read: ViewContainerRef }) contentArea: ViewContainerRef;

    private caseInfo: CaseInfo;

    constructor(el: ElementRef, public dcl: CustomDCLService, private lovDropDownService: LOVDropDownService, private _soapService: CordysSoapWService, private _s5382Service: S5382Service, public _alertMsgService: AlertMessagesService) {
        this.el = el.nativeElement;
    }

    ngAfterViewInit() {
        // this.setRiskClassification(this);

        if (this.headerInfo.asyncPostingStatus == "InProgress") {
            this.disableForm = "Y";
        } else if (this.riskObj.contractNumber != "") {
            this.disableForm = "Y";
        }
        else {
            this.disableForm = "N";
        }

        this.disableMaternityPrem = (this.riskObj.maternityOption && this.riskObj.maternityOption == 'Y') ? "N" : "Y";

		/*if( (!this.riskObj.ageLimitFlag && this.riskObj.dateOfBirth && this.riskObj.occupationCode) || (this.riskObj.occupationCode && !this.riskObj.occupationDescription) ){
			this.checkReferredRiskConditions();
		}*/
    }

    setFormDisabled() {
        if (jQuery("#bmsForm").prop("disabled") == true) {
            this.disableForm = "Y";
        }
    }

    ngOnInit() {
        this.populateLOVs();

        // if (this.clientDetails)
        // this.setClientInfo();
        this.caseInfo = BMSConstants.getBMSObj().ApplicationBusinessObject.caseInfo;
    }

    private populateLOVs(): void {

        this.lovDropDownService.createLOVDataList(["Salutation", "Occupation", "ratingClass", "Gender", "MaritalStatus", "nationality", "residence", "areaCode", "coverageCodes", "plans", "referralReasons", "referralAgeLimits"]);

        let riskFilter = (this.riskObj.riskType.length == 2) ? this.riskObj.riskType + ' ' : this.riskObj.riskType;
        let polEffectiveDate = ApplicationUtilService.getFormattedDate(this.headerInfo.effectiveDate, "YYYY-MM-DD", "YYYYMMDD");
        let planCodesFilterDetails = [new SearchFilter("DESCITEM", riskFilter, "STARTSWITH", "AND"),
        new SearchFilter("ITMFRM", polEffectiveDate, "LTEQ", "AND"),
        new SearchFilter("ITMTO", polEffectiveDate, "GTEQ", "AND")];
        if (this.riskObj.riskType == 'HIG') {
            planCodesFilterDetails.push(new SearchFilter("ZBINDIC", 'Y', "EQ", "AND"));
        }
        let planCodesFilterNodes = this.lovDropDownService.createFilter(planCodesFilterDetails);

        let riskTypeFilterDetails = [new SearchFilter("DESCITEM", riskFilter, "STARTSWITH", "AND")];
        let riskTypeFilterNodes = this.lovDropDownService.createFilter(riskTypeFilterDetails);


        let referralAgeLimitNodes = this.lovDropDownService.createFilter([new SearchFilter("DESCITEM", riskFilter, "EQ", "AND")]);

        let lovFields = [
            new LOV_Field("ALL", "ALL", "ALL", "ALL", "ALL", "ALL", "Nationality", "LOV", [], "DESCPF", "nationality", null),
            new LOV_Field("ALL", "ALL", "ALL", "ALL", "ALL", "ALL", "AreaCode", "LOV", [], "DESCPF", "areaCode", null),
            new LOV_Field("ALL", "ALL", "ALL", "ALL", "ALL", "ALL", "Residence", "LOV", [], "DESCPF", "residence", null),
            new LOV_Field("ALL", "MED", "ALL", "ALL", "ALL", "ALL", "Coverage Codes", "LOV", [], "T7087", "coverageCodes", null),
            new LOV_Field("ALL", "MED", "ALL", "ALL", "ALL", "S5382", "Plans", "LOV", planCodesFilterNodes, "T7088", "plans", "callbackForPlansLoad"),
            new LOV_Field("ALL", "MIS", "ALL", "ALL", "ALL", "ALL", "Occupation", "LOV", riskTypeFilterNodes, "T9109", "Occupation", "callbackForOccListLoad"),
            new LOV_Field("ALL", "PERSONAL ACCIDENT", "NEW BUSINESS", "ALL", "NEW", "PERSONAL ACCIDENT", "RatingClass", "LOV", [], "DESCPF", "ratingClass", null),
            new LOV_Field("ALL", "MOTOR", "NEW BUSINESS", "ALL", "NEW", "NAMED_DRIVER", "Sex", "LOV", [], "DESCPF", "Gender", null),
            new LOV_Field("ALL", "CLIENT", "ALL", "ALL", "NEW", "CLIENT_DETAILS", "Marital Status", "LOV", [], "DESCPF", "MaritalStatus", null),
            new LOV_Field("ALL", "MED", "ALL", "ALL", "ALL", "ALL", "Referral Reasons", "LOV", [], "DESCPF", "referralReasons", "callbackForReferralReasons"),
            new LOV_Field("ALL", "MED", "ALL", "ALL", "ALL", "ALL", "Referral Age Limits", "LOV", referralAgeLimitNodes, "T7253", "referralAgeLimits", "callbackReferralAgeLimits")
        ];
        // new LOV_Field("ALL", "CLIENT", "ALL", "ALL", "NEW", "CLIENT_DETAILS", "Salutation", "LOV", [], "DESCPF", "Salutation", null),
        // new LOV_Field("ALL", "ALL", "NEW BUSINESS", "ALL", "NEW", "ALL", "Occupation", "LOV", [], "T3644", "Occupation", "callbackForOccListLoad"),
        this.lovDropDownService.util_populateLOV(lovFields, this);

    }

    callbackForOccListLoad(scopeObject) {
        if (scopeObject.riskObj.occupationCode && !scopeObject.riskObj.occupationDescription) {
            let _occRec = scopeObject.lovDropDownService.lovDataList.Occupation.find((_item) => _item.VALUE == scopeObject.riskObj.occupationCode);
            if (_occRec) {
                scopeObject.riskObj.occupationDescription = _occRec.DESCRIPTION;
            }
            else {
                scopeObject.riskObj.occupationCode = '';
                scopeObject.riskObj.occupationDescription = '';
            }
        }
    }

    callbackForReferralReasons(scopeObject) {
        for (let _refReason of scopeObject.lovDropDownService.lovDataList.referralReasons) {
            // let hasRefReason = scopeObject.referralReasons.some( _data => _data.code === _refReason.code );
            let hasRefReason = scopeObject.riskObj.referralReasons.referralReason.some(_data => _data.code == _refReason.code);
            if (!hasRefReason) {
                scopeObject.referralReasons.push(_refReason);
            }
        }
    }

    callbackReferralAgeLimits(scopeObject) {
        if (this.riskObj.insuredAge == 0 || (!this.riskObj.ageLimitFlag && this.riskObj.dateOfBirth && this.riskObj.occupationCode)) {
            this.checkReferredRiskConditions();
        }
    }

    callbackForPlansLoad(scopeObject) {

        ApplicationUtilService.sortArray(scopeObject.lovDropDownService.lovDataList.plans, 'PLANCODE');

        if (scopeObject.riskObj.plan) {
            let maternityFlg = scopeObject.lovDropDownService.lovDataList.plans.find((_item) => _item.PLANCODE == scopeObject.riskObj.plan).ZMFLG;
            if (maternityFlg && maternityFlg == 'N')
                scopeObject.disableMaternityOption = 'Y';
            else
                scopeObject.disableMaternityOption = 'N';

            scopeObject.setMaternityOptionFlg();
        }
    }

    onPlanChange(ev) {
        this.riskObj.plan = ev.value;
        this.riskObj.planDesc = (ev.record.PLANDESC) ? ev.record.PLANDESC : '';
        this.riskObj.isBrochurePlan = (ev.record.ZBINDIC) ? ev.record.ZBINDIC : 'N';

        this.position = 1;
        this.riskObj.planBenefits.benefit.length = 0;

        ProgressBarComponent.show('Fetching Plan benefits...', { dialogSize: 'm', progressType: 'primary' });
        let riskTypeFilter = (this.riskObj.riskType.length == 2) ? this.riskObj.riskType + ' ' : this.riskObj.riskType;
        let desitemFilter = riskTypeFilter + this.riskObj.plan;

        let polEffectiveDate = ApplicationUtilService.getFormattedDate(this.headerInfo.effectiveDate, "YYYY-MM-DD", "YYYYMMDD");
        let request: GetLOVData = new GetLOVData().getRequest('ALL', 'MED', 'ALL', 'ALL', 'ALL', 'S5382', 'Plan Data', 'LOV');
        request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        request.ADVANCE_CONFIG_XML.FILTERS = new Filter();

        request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push(
            { "@FIELD_NAME": "DESCITEM", "@FIELD_VALUE": desitemFilter, "@OPERATION": "EQ", "@CONDITION": "AND" },
            { "@FIELD_NAME": "ITMFRM", "@FIELD_VALUE": polEffectiveDate, "@OPERATION": "LT", "@CONDITION": "AND" },
            { "@FIELD_NAME": "ITMTO", "@FIELD_VALUE": polEffectiveDate, "@OPERATION": "GT", "@CONDITION": "AND" });
        // this._soapService.callCordysSoapService("GetLOVData","http://schemas.opentext.com/lovhandler/v1.0", request , this.getPlanDataSuccessHandler, this.handleError, false, {comp:this});
		/*this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request , null, null, false, null).success((data)=> {
				
			if(data.tuple){
				let results = [];
				if(Array.prototype.isPrototypeOf(data.tuple)){				
					results = data.tuple;
				}
				else if(data.tuple.old && data.tuple.old.T7088) {
					results = [data.tuple];
				}
				this._s5382Service.addBenefitsFromPlanRecord(results, this.riskObj, this.parentRiskObj);
				this.disableMaternityOption = (this.riskObj.maternityOption != "Y") ? "Y" : "N";
				this.setMaternityOptionFlg();
				this.setAreaCodeRate();
				this.setOccClsRate();
				ProgressBarComponent.hide();
				this.setPremium();
			}
	
		}).error((response, status, errorText)=> {
			ProgressBarComponent.hide();
			this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR,"Error while getting plan benefits for  plan Code-"+this.riskObj.plan, 5000));
		});
		*/
        let promise = this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, null, null, true, null);

        promise.success((data) => {
            if (data.tuple) {
                let results = [];
                if (Array.prototype.isPrototypeOf(data.tuple)) {
                    results = data.tuple;
                }
                else if (data.tuple.old && data.tuple.old.T7088) {
                    results = [data.tuple];
                }
                this._s5382Service.addBenefitsFromPlanRecord(results, this.riskObj, this.parentRiskObj);
                this.disableMaternityOption = (this.riskObj.maternityOption != "Y") ? "Y" : "N";
                this.setMaternityOptionFlg();
                this.setAreaCodeRate();
                this.setOccClsRate();

                ProgressBarComponent.hide();

                this.setPremium();
            }
        });

        promise.error((data) => {
            ProgressBarComponent.hide();
            this.handleError(data, '', '', { comp: this });
        });
    }

    setMaternityOptionFlg() {

        if (this.disableMaternityOption == "Y") {
            this.riskObj.maternityDate = '';
            if (this.maternityDateCtrl != null) {
                this.maternityDateCtrl.setDisable("Y", this.maternityDateCtrl.comp);
                this.maternityDateCtrl.setter("EMPTY", "YYYY-MM-DD", this.maternityDateCtrl.comp);
                jQuery(this.el).find("select[id='maternityOption']").prop("disabled", true);
            }
        }
        else {
            if (this.maternityDateCtrl != null) {
                this.maternityDateCtrl.setDisable("N", this.maternityDateCtrl.comp);
                jQuery(this.el).find("select[id='maternityOption']").prop("disabled", false);
            }
        }

    }

    onMaternityOptionChange() {
        if (this.riskObj.maternityOption == 'N') {
            this.riskObj.maternityDate = '';
            this.riskObj.maternityPremium = 0;
            this.disableMaternityPrem = 'Y';
            if (this.maternityDateCtrl != null) {
                this.maternityDateCtrl.setDisable("Y", this.maternityDateCtrl.comp);
                this.maternityDateCtrl.setter("EMPTY", "YYYY-MM-DD", this.maternityDateCtrl.comp);
            }
            if (this.maternityPremCtrl != null) {
                this.maternityPremCtrl.setDisable('Y', this.maternityPremCtrl.comp);
                this.maternityPremCtrl.setter(this.riskObj.maternityPremium, this.maternityPremCtrl.comp);
            }
        }
        else if (this.riskObj.maternityOption == 'Y') {
            this.disableMaternityPrem = 'N';
            if (this.maternityDateCtrl != null) {
                this.maternityDateCtrl.setDisable("N", this.maternityDateCtrl.comp);
            }
            if (this.maternityPremCtrl != null) {
                this.maternityPremCtrl.setDisable('N', this.maternityPremCtrl.comp);
            }
        }

        // this._s5382Service.calculatePremium(this.riskObj, this.parentRiskObj, this.headerInfo.effectiveDate);
        this.setPremium();
    }

    // getPlanDataSuccessHandler(response, prms){
    // if(response && response.tuple){
    // let results = [];
    // if(Array.prototype.isPrototypeOf(response.tuple)){				
    // results = response.tuple;
    // }
    // else if(response.tuple.old && response.tuple.old.T7088) {
    // results = [response.tuple];
    // }

    // /*
    // for(let _rec of results){

    // if(_rec.old.T7088.ZGMCDE){
    // //ZGMCDE,ZGMDSC,LONGDESC,ZMFLG,ZMPAID01,ZMPAID02,ZOFLG01,ZOFLG02,ZSPAID01,ZSPAID02,ZIBRFLG,TOTSI,STPLPC,IND,SUMI,ZTPAID,ITMFRM,ITMTO
    // let benefit = new BenefitItem();
    // benefit.seqNumber = prms.comp.riskObj.planBenefits.benefit.length + 1;
    // benefit.coverageCode = _rec.old.T7088.ZGMCDE;
    // benefit.coverageDescription = _rec.old.T7088.ZGMDSC;
    // benefit.sumInsured = _rec.old.T7088.SUMI;
    // benefit.siWorldWide = _rec.old.T7088.ZTPAID;

    // prms.comp.riskObj.planBenefits.benefit.push(benefit);

    // if(benefit.seqNumber ==1){
    // let si:any   = _rec.old.T7088.TOTSI;
    // let emeSI:any = _rec.old.T7088.ZSPAID01;

    // si   = (si == null || si == "") ? 0 : parseFloat(""+si);
    // emeSI= (emeSI == null || emeSI == "") ? 0 : parseFloat(""+emeSI);

    // prms.comp.riskObj.capitalSumInsured = (si - emeSI);
    // prms.comp.riskObj.emeSumInsured = emeSI;
    // prms.comp.riskObj.ibrOption = (_rec.old.T7088.ZIBRFLG) ? _rec.old.T7088.ZIBRFLG : "";
    // prms.comp.riskObj.maternityOption = (_rec.old.T7088.ZMFLG) ? _rec.old.T7088.ZMFLG : "";
    // prms.comp.disableMaternityOption = (prms.comp.riskObj.maternityOption != 'Y') ? "Y" : "N";
    // }
    // }
    // }*/

    // this._s5382Service.addBenefitsFromPlanRecord(results, prms.comp.riskObj);
    // prms.comp.disableMaternityOption = (riskObj.maternityOption != 'Y') ? "Y" : "N";

    // /*if(prms.comp.riskObj.areaCode){
    // prms.comp.populateAreaCodeMultiplier();
    // }			
    // if(prms.comp.riskObj.occupationClass){
    // prms.comp.populateOccClsRate();
    // }*/

    // prms.comp.setPremium();

    // }
    // }

    onAreaCodeChange(ev) {
        this.riskObj.areaCode = ev.value;
        this.setAreaCodeRate();
        this.setPremium();

		/*
		if(this.riskObj.plan){
			// let _rate = this._s5382Service.getAreaCodeMultiplierRate(this.riskObj.plan, this.riskObj.areaCode, this.headerInfo.effectiveDate);
			// this.riskObj.load = numeral(numeral(_rate).format(this.loadFormat)).value();
			// // this.populateAreaCodeMultiplier();
			this.setPremium();
		}*/
    }

	/*
	populateAreaCodeMultiplier(){
		this.riskObj.load = 0;
		if(this.riskObj.plan && this.riskObj.areaCode){
			let descItem = this.riskObj.plan + this.riskObj.areaCode;
			let request:GetLOVData = new GetLOVData().getRequest('ALL','ALL','ALL','ALL','ALL','ALL','AreaCodeRate','LOV');
			request.ADVANCE_CONFIG_XML= new SearchAdvancedConfig(); 
			request.ADVANCE_CONFIG_XML.FILTERS = new Filter();
			
			request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push(
				{"@FIELD_NAME":'DESCITEM',"@FIELD_VALUE":descItem ,'@OPERATION':'EQ','@CONDITION':'AND'},			
				{"@FIELD_NAME":'ITMFRM',"@FIELD_VALUE":moment(this.headerInfo.effectiveDate,"YYYY-MM-DD").format("YYYYMMDD") ,'@OPERATION':'LT','@CONDITION':'AND'},
				{"@FIELD_NAME":'ITMTO',"@FIELD_VALUE":moment(this.headerInfo.effectiveDate,"YYYY-MM-DD").format("YYYYMMDD") ,'@OPERATION':'GT','@CONDITION':'AND'});
			this._soapService.callCordysSoapService("GetLOVData","http://schemas.opentext.com/lovhandler/v1.0", request , this.getAreaCodeMultiplierRateSuccessHandler, this.handleError, false, {comp:this});
		}		
	}
	
	getAreaCodeMultiplierRateSuccessHandler(response,prms){
		if(response.tuple){
			if(Array.prototype.isPrototypeOf(response.tuple)){				
				prms.comp.riskObj.load = numeral(numeral(response.tuple[0].old.T7090.ZCRYLOAD).format(prms.comp.loadFormat)).value();
			}
			else if(response.tuple.old && response.tuple.old.T7090) {
				// prms.comp.riskObj.load =  numeral(response.tuple.old.T7090.ZCRYLOAD).format(prms.comp.loadFormat);
				prms.comp.riskObj.load = numeral(numeral(response.tuple.old.T7090.ZCRYLOAD).format(prms.comp.loadFormat)).value();
			}
		}
	}
	*/
    onOccChange(ev) {
        this.riskObj.occupationCode = ev.value;
        this.riskObj.occupationDescription = (ev.record.DESCRIPTION) ? ev.record.DESCRIPTION.slice(0, 40) : "";
		/*
		if(ev.record.REFERREDRISK && ev.record.REFERREDRISK == 'Y'){
			this.riskObj.occRiskClassification = "Referred";
		}
		else if(ev.record.REFERREDRISK && ev.record.REFERREDRISK == 'D'){
			this.riskObj.occRiskClassification = "Declined";
		}
		else {
			this.riskObj.occRiskClassification = "Standard";
		}
		
		this.checkReferredRisk(this);
		*/

        this.checkReferredRiskConditions();
    }

    onCoverCodeChange(cover, ev) {
        cover.coverageCode = ev.value;
        cover.coverageDescription = ev.record.LONGNAME;
        // cover.coverageDescription=(ev.record.LONGNAME) ? ev.record.LONGNAME.slice(0,30) : "";
    }

    onOccClassChange(ev) {
        this.riskObj.occupationClass = ev.value;
        this.setOccClsRate();
        this.setPremium();
		/*
		if(this.riskObj.plan){
			// let _rate = this._s5382Service.getOccClassRate(this.riskObj.plan, this.riskObj.occupationClass, this.headerInfo.effectiveDate);
			// this.riskObj.occupationClassRate = numeral(numeral(_rate).format(this.loadFormat)).value();	
			// //this.populateOccClsRate();
			
			// this.setPremium();
		}*/
    }

    onDOBChange(ev) {
        this.riskObj.dateOfBirth = ev;

		/*
		let isValidNRICFormat = false;
		if( !(this.riskObj.IdProofNo == undefined || this.riskObj.IdProofNo.trim()=="")){
			isValidNRICFormat = new RegExp("[0-9]{6}-[0-9]{2}-[0-9]{4}$").test(this.riskObj.IdProofNo);
            if (isValidNRICFormat == true) {
				this.setDOB();
			}
		}*/

        // if(isValidNRICFormat == false && this.riskObj.dateOfBirth){
        if (this.riskObj.dateOfBirth) {
            let dobDate = moment(this.riskObj.dateOfBirth, "YYYY-MM-DD");
            // var _endDate = moment(this.headerInfo.endDate, "YYYY-MM-DD");
            var _inclusionDate = moment(this.riskObj.inclusionDate, "YYYY-MM-DD");

            if (dobDate._i != _inclusionDate._i && dobDate > _inclusionDate) {
                this.riskObj.dateOfBirth = '';
                if (this.DOBCtrl != null) {
                    this.DOBCtrl.setter("EMPTY", "YYYY-MM-DD", this.DOBCtrl.comp);
                }
                this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Date of Birth must be before the policy Expiry date.", 3000));
            } else {

                // let age = _endDate.diff(dobDate, 'years');
				/*if(age >70){
					this.riskObj.dateOfBirth='';
					if(this.DOBCtrl != null)
						this.DOBCtrl.setter('EMPTY',"YYYY-MM-DD",this.DOBCtrl.comp);
					this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR,"Insured person age cannot more than 70 years", 5000));
				} else {
					if(this.riskObj.plan && this.riskObj.dateOfBirth){
						this.setPremium();
					}
				}*/

                if (this.riskObj.plan && this.riskObj.dateOfBirth) {
                    this.setPremium();
                }
            }
        }

        this._s5382Service.calculateAge(this.riskObj);
        //this.checkReferredRisk(this);
        this.checkReferredRiskConditions();
    }

    setDOB() {
        let givenDate = this.riskObj.IdProofNo.substring(0, 6);
        // let givenDate = this.riskObj.IdProofNo.substr(0,6);
        let finalDate = givenDate;
        if (moment(givenDate, "YYMMDD").toDate() == "Invalid Date") {
            finalDate = "";
            this.riskObj.IdProofNo = "";
            this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Invalid date in NRIC.", 5000));
        }
        else {
            let century = this.riskObj.IdProofNo.substring(0, 2);
            if (Number(century) > 29)
                givenDate = '19' + givenDate;
            else
                givenDate = '20' + givenDate;

            // finalDate = moment(givenDate, "YYYYMMDD").format("YYYYMMDD");
            finalDate = moment(givenDate, "YYYYMMDD").format("YYYY-MM-DD");
        }

        this.riskObj.dateOfBirth = finalDate;
        // this.setInsuredAge();		

        if (this.DOBCtrl != null && finalDate != "") {
            this.DOBCtrl.setter(finalDate, "YYYY-MM-DD", this.DOBCtrl.comp);
        }
        else if (this.DOBCtrl != null && finalDate == "")
            this.DOBCtrl.setter("EMPTY", "YYYY-MM-DD", this.DOBCtrl.comp);

        if (this.riskObj.plan && this.riskObj.dateOfBirth) {
            this.setPremium();
        }
        this.checkReferredRiskConditions();
    }

    onChangeNRIC() {
        if (this.riskObj.IdProofNo != null && this.riskObj.IdProofNo != "") {
            let isValidNRICFormat = new RegExp("[0-9]{6}-[0-9]{2}-[0-9]{4}$").test(this.riskObj.IdProofNo);
            if (isValidNRICFormat == true) {
                /*let givenDate = this.riskObj.IdProofNo.substr(0,6);
                let finalDate = givenDate;
                if (moment(givenDate, "YYMMDD").toDate() == "Invalid Date") {
                    finalDate = "";
                    this.riskObj.IdProofNo = "";
                    this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Invalid date in NRIC.", 5000));
                } else {
                    finalDate = moment(givenDate, "YYMMDD").format("YYYYMMDD");
                }

                if (this.DOBCtrl != null && finalDate != "")
                    this.DOBCtrl.setter(moment(finalDate, "YYYYMMDD").format("YYYY-MM-DD"), "YYYY-MM-DD", this.DOBCtrl.comp);
                else if (this.DOBCtrl != null && finalDate == "")
                    this.DOBCtrl.setter("EMPTY", "YYYY-MM-DD", this.DOBCtrl.comp);
				*/

                this.setDOB();

                if (this.riskObj.IdProofNo) {
                    let lastDigit = this.riskObj.IdProofNo.substring(this.riskObj.IdProofNo.length - 1);
                    if (/^-?\d*[02468]$/.test(lastDigit)) {
                        this.riskObj.gender = 'F';
                    } else if (/^-?\d*[13579]$/.test(lastDigit)) {
                        this.riskObj.gender = 'M';
                    }
                }
            }
        }
    }

    setInsuredAge() {

        if (this.riskObj.inclusionDate != null && this.riskObj.inclusionDate != "" && this.riskObj.dateOfBirth != null && this.riskObj.dateOfBirth != "") {

            // let _inclusionDate = moment(riskObj.inclusionDate, "YYYY-MM-DD");
            // let _insuredDOB = moment(riskObj.dateOfBirth, "YYYY-MM-DD");
            // let age = _inclusionDate.diff(_insuredDOB, 'years');

            let curDate = moment(new Date().toISOString(), "YYYY-MM-DD");
            let date = moment(this.riskObj.dateOfBirth, "YYYY-MM-DD").format("YYYY-MM-DD");
            this.riskObj.insuredAge = curDate.diff(date, 'year') + 1;
        }
        else {
            this.riskObj.insuredAge = 0;
            this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "DOB cannot be empty or age cannot be zero.", 5000));
        }
    }


	/*
	populateOccClsRate(){
		//populate Occupation class rate from 7091... by plan and occupationClass
		this.riskObj.occupationClassRate = 0;
		if(this.riskObj.plan && this.riskObj.occupationClass){			
			let descItem = this.riskObj.plan + this.riskObj.occupationClass;
			let request:GetLOVData = new GetLOVData().getRequest('ALL','MED','ALL','ALL','ALL','ALL','Occupation Class Rate','LOV');
			request.ADVANCE_CONFIG_XML= new SearchAdvancedConfig(); 
			request.ADVANCE_CONFIG_XML.FILTERS = new Filter();
			
			request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push(
				{"@FIELD_NAME":'DESCITEM',"@FIELD_VALUE":descItem ,'@OPERATION':'EQ','@CONDITION':'AND'},
				{"@FIELD_NAME":'ITMFRM',"@FIELD_VALUE":moment(this.headerInfo.effectiveDate,"YYYY-MM-DD").format("YYYYMMDD") ,'@OPERATION':'LT','@CONDITION':'AND'},
				{"@FIELD_NAME":'ITMTO',"@FIELD_VALUE":moment(this.headerInfo.effectiveDate,"YYYY-MM-DD").format("YYYYMMDD") ,'@OPERATION':'GT','@CONDITION':'AND'});
			this._soapService.callCordysSoapService("GetLOVData","http://schemas.opentext.com/lovhandler/v1.0", request , this.getOccClsRateSuccessHandler, this.handleError, false, {comp:this});		
		}
	}
	
	getOccClsRateSuccessHandler(response,prms){
		if(response.tuple){
			if(Array.prototype.isPrototypeOf(response.tuple)){
				prms.comp.riskObj.occupationClassRate = numeral(numeral(response.tuple[0].old.T7091.ZCRYLOAD).format(this.loadFormat)).value();
			}
			else if(response.tuple.old && response.tuple.old.T7091) {
				prms.comp.riskObj.occupationClassRate =  numeral(numeral(response.tuple.old.T7091.ZCRYLOAD).format(prms.comp.loadFormat)).value();
			}
		}
	}
	*/

    onDiscountChange(ev, id) {

        if (id == 'discountPercent') {
            this.riskObj.discountPercent = ev;
            this.riskObj.discountAmount = 0;

        } else if (id == 'discountAmount') {
            this.riskObj.discountAmount = ev;
            this.riskObj.discountPercent = 0;
        }

        if (this.discPrcntCtrl != null) this.discPrcntCtrl.setter(this.riskObj.discountPercent, this.discPrcntCtrl.comp);
        if (this.discAmntCtrl != null) this.discAmntCtrl.setter(this.riskObj.discountAmount, this.discAmntCtrl.comp);

        this.setPremium();
    }

    onRateChange(ev) {
        // this.riskObj.load = ev.value;		
        // this._s5382Service.calculatePremium(this.riskObj, this.parentRiskObj, this.headerInfo.effectiveDate);
        this.setPremium();
    }

    setAreaCodeRate() {
        if (this.riskObj.plan) {
            let areaCodeDescItemsStr = "'" + this.riskObj.plan + this.riskObj.areaCode + "'";
            let _areaCoderate = this._s5382Service.getAreaCodeMultiplierRate(areaCodeDescItemsStr, this.headerInfo.effectiveDate, false);
            this.riskObj.load = numeral(numeral(_areaCoderate).format(this.loadFormat)).value();
        } else {
            this.riskObj.load = 0;
        }
    }

    setOccClsRate() {
        if (this.riskObj.plan) {
            let occClsCodeDescItemsStr = "'" + this.riskObj.plan + this.riskObj.occupationClass + "'";
            let _occClsrate = this._s5382Service.getOccClassRate(occClsCodeDescItemsStr, this.headerInfo.effectiveDate, false);
            this.riskObj.occupationClassRate = numeral(numeral(_occClsrate).format(this.loadFormat)).value();
        } else {
            this.riskObj.occupationClassRate = 0;
        }
    }

    setPremium() {

        // this.riskObj.basicPremium = 0;
        // this.riskObj.ibrPremium = 0;
        // this.riskObj.maternityPremium = 0;
        // let _premiumCharges = 0;
        // let _maternityPremiumCharges = 0;
        // let _IBRPremiumCharges = 0;

        // if(this.riskObj.plan){

        // let areaCodeDescItemsStr = "'"+this.riskObj.plan+this.riskObj.areaCode+"'";
        // let _areaCoderate = this._s5382Service.getAreaCodeMultiplierRate(areaCodeDescItemsStr, this.headerInfo.effectiveDate, false);
        // this.riskObj.load = numeral(numeral(_areaCoderate).format(this.loadFormat)).value();

        // let occClsCodeDescItemsStr = "'"+this.riskObj.plan+this.riskObj.occupationClass+"'";
        // let _occClsrate = this._s5382Service.getOccClassRate(occClsCodeDescItemsStr, this.headerInfo.effectiveDate, false);
        // this.riskObj.occupationClassRate = numeral(numeral(_occClsrate).format(this.loadFormat)).value();	

        // }

        this._s5382Service.calculatePremium(this.riskObj, this.parentRiskObj, this.headerInfo.effectiveDate);

		/*
		let _inclusionDate = moment(this.riskObj.inclusionDate, "YYYY-MM-DD");
		let _insuredDOB = moment(this.riskObj.dateOfBirth, "YYYY-MM-DD");
		let age = _inclusionDate.diff(_insuredDOB, 'years');		
		*/
        // /*this.planPremiumChargesData = new Object();
        // let request:GetLOVData = new GetLOVData().getRequest('ALL','MED','ALL','ALL','ALL','S5382','Premium Charges','LOV');
        // request.ADVANCE_CONFIG_XML= new SearchAdvancedConfig(); 
        // request.ADVANCE_CONFIG_XML.FILTERS = new Filter();		
        // request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push(
        // {"@FIELD_NAME":"DESCITEM", "@FIELD_VALUE":this.riskObj.plan , "@OPERATION":"STARTSWITH", "@CONDITION":"AND"},
        // {"@FIELD_NAME":"ITMFRM", "@FIELD_VALUE":moment(this.headerInfo.effectiveDate,"YYYY-MM-DD").format("YYYYMMDD"), "@OPERATION":"LT", "@CONDITION":"AND"},
        // {"@FIELD_NAME":"ITMTO", "@FIELD_VALUE":moment(this.headerInfo.effectiveDate,"YYYY-MM-DD").format("YYYYMMDD"), "@OPERATION":"GT", "@CONDITION":"AND"},
        // {"@FIELD_NAME":"SUBSTRING(DESCITEM,4,3)", "@FIELD_VALUE":age , "@OPERATION":"GTEQ", "@CONDITION":"AND"});
        // this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request , this.planPremiumChargesDataSuccessHandler, this.handleError, false, {comp:this});

        // if(this.planPremiumChargesData && this.planPremiumChargesData.old && this.planPremiumChargesData.old.T7089){

        // _premiumCharges = numeral(this.planPremiumChargesData.old.T7089.AMTA01).value();
        // _maternityPremiumCharges = numeral(this.planPremiumChargesData.old.T7089.AMTA02).value();
        // _IBRPremiumCharges = numeral(this.planPremiumChargesData.old.T7089.AMTA03).value();

        // _premiumCharges = (_premiumCharges > 0) ? (_premiumCharges/100) : _premiumCharges;

        // this.riskObj.basicPremium = numeral(numeral(_premiumCharges).format(this.premiumFormat)).value();
        // }*/


		/*
		let _premiumChargesData = this._s5382Service.getPremiumCharges(this.riskObj.plan, age, this.headerInfo.effectiveDate);
		if(_premiumChargesData){
			
			_premiumCharges = numeral(_premiumChargesData.AMTA01).value();
			_maternityPremiumCharges = numeral(_premiumChargesData.AMTA02).value();
			_IBRPremiumCharges = numeral(_premiumChargesData.AMTA03).value();
			
			_premiumCharges = (_premiumCharges > 0) ? (_premiumCharges/100) : _premiumCharges;
			_maternityPremiumCharges = (_maternityPremiumCharges > 0) ? (_maternityPremiumCharges/100) : _maternityPremiumCharges;
			_IBRPremiumCharges = (_IBRPremiumCharges > 0) ? (_IBRPremiumCharges/100) : _IBRPremiumCharges;
			
		}
		
		this.riskObj.basicPremium = numeral(numeral(_premiumCharges).format(this.premiumFormat)).value();
			
		// this.getPremiumCharges
		let rate:any  = this.riskObj.occupationClassRate;
		let load:any  = this.riskObj.load;
		
		rate  = (rate == null || rate == "") ? 0 : parseFloat(""+rate);
		load  = (load == null || load == "") ? 0 : parseFloat(""+load);
						
		let occRateMultiplierPrem = 0;
		if(rate > 0){
			occRateMultiplierPrem = _premiumCharges * this.riskObj.occupationClassRate/100;
		}
		
		if(load > 0){
			let _loadRatePremium = occRateMultiplierPrem + (_premiumCharges * (load - 100)/100);
			this.riskObj.basicPremium = _loadRatePremium;
		} else if(occRateMultiplierPrem > 0){
			this.riskObj.basicPremium = occRateMultiplierPrem;
		}
		
		if(rate > 0 && load > 0){
			_maternityPremiumCharges = (_maternityPremiumCharges * rate/100) + (_maternityPremiumCharges * (rate-100)/100);
			_IBRPremiumCharges = (_IBRPremiumCharges * rate/100) + (_IBRPremiumCharges * load/100);
			
			this.riskObj.maternityPremium = numeral(numeral(_maternityPremiumCharges).format(this.premiumFormat)).value();
			this.riskObj.ibrPremium = numeral(numeral(_IBRPremiumCharges).format(this.premiumFormat)).value();			
		}		
		
		this.riskObj.totalPremium = parseFloat(""+numeral(this.riskObj.basicPremium).value()) + parseFloat(""+numeral(this.riskObj.ibrPremium).value()) + parseFloat(""+numeral(this.riskObj.maternityPremium).value());
		this.riskObj.totalAnnualPremium = this.riskObj.totalPremium;
		
		if(this.riskObj.discountAmount > 0)
			this.riskObj.discountPremium = parseFloat(""+numeral(this.riskObj.totalPremium).value()) - parseFloat(""+numeral(this.riskObj.discountAmount).value());
		else if(this.riskObj.discountPercent > 0)
			this.riskObj.discountPremium = parseFloat(""+numeral(this.riskObj.totalPremium).value()) - ( parseFloat(""+numeral(this.riskObj.totalPremium).value()) * (parseFloat(""+numeral(this.riskObj.discountPercent).value())/100) );
		*/

        this.onSIChange.emit("");
        this.onPremiumChange.emit("");

    }

	/*planPremiumChargesDataSuccessHandler(response, prms){
		if(response && response.tuple){			
			prms.comp.planPremiumChargesData = response.tuple;			
		}
	}*/

    setFocusToNext(elmnt) {
        let sutuationElmnts = jQuery(this.el).find("input");
        jQuery(sutuationElmnts[sutuationElmnts.index(elmnt) + 1]).focus();
    }

    validateInput(event, dType, allowedLength) {
        if ([46, 8, 9, 27, 13, 110].indexOf(event.keyCode) !== -1 ||
            // Allow: Ctrl+A, Command+A
            (event.keyCode === 65 && (event.ctrlKey === true || event.metaKey === true)) ||
            // Allow: home, end, left, right, down, up
            (event.keyCode >= 35 && event.keyCode <= 40)) {
            // let it happen, don't do anything
            return;
        }
        // Ensure that it is a number and stop the keypress
        if (dType = "integer") {
            let result = (event.target.value + "").match(/[^0-9]/g);
            if (event.key == ".") {
                // console.log("not allowed");
                return false;
            }
            if (event.target.value != undefined && event.target.value.length >= allowedLength) {
                // console.log("length failed");
                return false;
            }
        } else if (dType = "double") {
            let result = (event.target.value + "").match(/[^0-9.]/g);
            if (result) {
                //console.log("not allowed");
                return false;
            }
        }
        if ((event.shiftKey || (event.keyCode < 48 || event.keyCode > 57)) && (event.keyCode < 96 || event.keyCode > 105)) {
            event.preventDefault();
        }

    }

    getTotalByProperty(prop, ary) {
        let total = numeral(0);
        for (let eachItem of ary) {
            if (eachItem[prop] != null && eachItem[prop] != "")
                total = total.add(numeral().unformat(eachItem[prop]));
        }
        total = numeral(total).format('0.00');
        return total;
    }

    addXT(coverItem) {
        var dialogData = new ExtraTextDialogData("ExtraTextDialogComponent", "app/bms/components/proposal/newbusinessrisks/dialogs/extratext.dialog.module", "ExtraTextDialogModule", "Extra Text", "ExtraText", "fa fa-comment", coverItem, this.extraTextCallBack);
        this.openExtraTextCommentsDialog(dialogData);
    }

    public openExtraTextCommentsDialog(dialogData: ExtraTextDialogData, response?: any) {
        let lookup = new ModalInput();
        lookup.component = [dialogData.component, dialogData.moduleAbsPath, dialogData.moduleName];
        lookup.datainput = {
            dialogName: dialogData.dialogName,
            areCommentsMandatory: false,
            coverageItem: dialogData.coverageItem
        };
        lookup.outputCallback = dialogData.callBackHandler;
        lookup.parentCompPRMS = {
            comp: this,
            response: response
        };
        lookup.heading = dialogData.dialogTitle;
        lookup.icon = dialogData.icon;
        lookup.containerRef = this.contentArea;
        this.dcl.openLookup(lookup);
    }

    private extraTextCallBack(data, prms) {
        if (data.isDialogCancelled) {
            return;
        } else if (!data.isDialogCancelled && data.coverageItem && data.coverageItem.extraText) {
        }
    }

    validateMaternityDate() {
        let _maternityDate = moment(this.riskObj.maternityDate, "YYYY-MM-DD");

        if (this.riskObj.maternityDate != null && this.riskObj.maternityDate != "") {
            let _effectiveDate = moment(this.headerInfo.effectiveDate, "YYYY-MM-DD");
            let _endDate = moment(this.headerInfo.endDate, "YYYY-MM-DD");

            if (_effectiveDate > _maternityDate || _endDate < _maternityDate) {
                this.riskObj.maternityDate = '';
                if (this.maternityDateCtrl != null) {
                    this.maternityDateCtrl.setter("EMPTY", "YYYY-MM-DD", this.maternityDateCtrl.comp);
                }

                this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Maternity Date must be with in the period of insurance", 3000));
            }
        }
    }

    validateTermnDate() {
        let _terminationDate = moment(this.riskObj.terminationDate, "YYYY-MM-DD");
        if (this.riskObj.terminationDate != null && this.riskObj.terminationDate != "") {
            let _effectiveDate = moment(this.headerInfo.effectiveDate, "YYYY-MM-DD");
            let _endDate = moment(this.headerInfo.endDate, "YYYY-MM-DD");
            if (_effectiveDate > _terminationDate || _endDate < _terminationDate) {
                this.riskObj.terminationDate = '';
                if (this.termnDateCtrl != null) {
                    this.termnDateCtrl.setter("EMPTY", "YYYY-MM-DD", this.termnDateCtrl.comp);
                }

                this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Termination Date must be with in the period of insurance", 3000));
            }
        }
    }

    addReferralReason() {
        let refCode = jQuery("#referralReason").val();

        if (this.lovDropDownService.lovDataList.referralReasons && this.lovDropDownService.lovDataList.referralReasons.length > 0 && this.riskObj.referralReasons.referralReason.find((_data1) => _data1.code == refCode)) {
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Referral Reason is added already.", 3000));
        }
        else {
            this._s5382Service.addReferralReason(this.riskObj, refCode, false, this.lovDropDownService.lovDataList.referralReasons, this.referralReasons);
            if (this.riskObj.referralReasons.referralReason.length == 1) {
                this.checkReferredRiskConditions();
            }
        }
        jQuery("#referralReason").val('');
    }

	/*
	addReferralReason(refCode, isSysRef){
		
		if(!refCode){
			refCode = jQuery("#referralReason").val();
		}
		
		let refReasonRecord = this.lovDropDownService.lovDataList.referralReasons.find( _data => (_data.code === refCode) );
		if(refReasonRecord) {
			if( this.riskObj.referralReasons.referralReason && (this.riskObj.referralReasons.referralReason.length == 0 || !this.riskObj.referralReasons.referralReason.find((_data1)=> _data1.code==refCode) ) ){
				let _referralReason = new ReferralReason();
				_referralReason.seqNumber = this.riskObj.referralReasons.referralReason.length + 1;
				_referralReason.code = refReasonRecord.code;
				_referralReason.description = refReasonRecord.description;
				_referralReason.isSysReferred = (isSysRef) ? 'Y' : 'N';
				
				this.riskObj.referralReasons.referralReason.push(_referralReason);
				
				this.removeRefrlReasonFromSelectionList(refCode);
			}
			else if( this.riskObj.referralReasons.referralReason &&  this.riskObj.referralReasons.referralReason.find((_data1)=> _data1.code==refCode) ){
				let _refReason = this.riskObj.referralReasons.referralReason.find((_data1)=> _data1.code==refCode);
				_refReason.isSysReferred = (isSysRef) ? 'Y' : 'N';
				
				this.removeRefrlReasonFromSelectionList(refCode);
			}
		}
	}
	
	removeRefrlReasonFromSelectionList(refCode){
		let _selectedRefReason = this.referralReasons.find(item => item.code == refCode);
		if(_selectedRefReason){					
			this.referralReasons.splice(this.referralReasons.indexOf(_selectedRefReason), 1);
		}
		jQuery("#referralReason").val('');
	}
	*/

    removeReferralReason(refItem) {
        let _idx = this.riskObj.referralReasons.referralReason.indexOf(refItem);
        let _refCode = refItem.code;
        this.riskObj.referralReasons.referralReason.splice(_idx, 1);
        this.resetItemNumber();

        let _refReasonRecord = this.lovDropDownService.lovDataList.referralReasons.find(_data => (_data.code === _refCode));
        if (_refReasonRecord)
            this.referralReasons.push(_refReasonRecord);

        if (this.riskObj.referralReasons.referralReason.length == 0) {
            this.checkReferredRiskConditions();
        }
    }

    resetItemNumber() {
        for (let _refItem of this.riskObj.referralReasons.referralReason) {
            let index = this.riskObj.referralReasons.referralReason.indexOf(_refItem);
            _refItem.seqNumber = (index + 1);
        }
    }

    handleError(response, status, errorText, prms) {
        prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, response.responseJSON.faultstring.text, 5000));
    }

    emitFlagChange() {
        this.onRtngFlgChange.emit(this.riskObj.itemNo);
    }

    checkReferredRiskConditions() {

        let _ageLimitRec = this.lovDropDownService.lovDataList.referralAgeLimits.find((_data) => _data.DESCITEM == this.riskObj.riskType);

        this._s5382Service.checkReferredRiskConditions(this.riskObj, this.headerInfo.contractType, _ageLimitRec, this.lovDropDownService.lovDataList.Occupation, this.lovDropDownService.lovDataList.referralReasons, this.referralReasons);

        if (this.riskObj.ageLimitFlag == "G") {
            this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Insured Age greater than maximum allowed age", 6000));
        }
        else if (this.riskObj.ageLimitFlag == "L") {
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Insured Age Less than minimum allowed age", 6000));
        }

		/*
		let _reasons = new Reasons();
		let isReferredRisk = false;
		let isDeclinedRisk = false;
		
		let _ageLimitRec = this.lovDropDownService.lovDataList.referralAgeLimits.find((_data)=> _data.DESCITEM == this.headerInfo.contractType);
		
		if (_ageLimitRec && this.riskObj.dateOfBirth && this.riskObj.occupationCode) {
			let _maxAgeLimit =0;
			let _minAgeLimit =0;
			if(this.riskObj.occupationCode == '7STU' || this.riskObj.occupationCode == '7CLD'){ //Child
				_maxAgeLimit = (_ageLimitRec.ZAGELMT06) ? parseInt(""+_ageLimitRec.ZAGELMT06) : 0;
				_minAgeLimit = (_ageLimitRec.ZAGELMT04) ? parseInt(""+_ageLimitRec.ZAGELMT04) : 0;
			}
			else { //Adult
				_maxAgeLimit = (_ageLimitRec.ZAGELMT05) ? parseInt(""+_ageLimitRec.ZAGELMT05) : 0;
				_minAgeLimit = (_ageLimitRec.ZAGELMT03) ? parseInt(""+_ageLimitRec.ZAGELMT03) : 0;
			}
			this._s5382Service.calculateAge(this.riskObj);
			if (Number(this.riskObj.insuredAge) > _maxAgeLimit) {
				isReferredRisk = true;
				this.riskObj.ageLimitFlag = "G";
				_reasons.reason.push("Insured Age greater than maximum allowed age "+_maxAgeLimit);
				this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Insured Age greater than maximum allowed age "+_maxAgeLimit , 6000));
				
				this.addReferralReason('01', true);				
			}
			else if (Number(this.riskObj.insuredAge) < _minAgeLimit) {
				this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Insured Age Less than minimum allowed age "+_minAgeLimit , 6000));
				this.riskObj.ageLimitFlag = "L";
			}
			else {
				this.riskObj.ageLimitFlag = "VALID";
			}
		}
		else {
			this.riskObj.ageLimitFlag = "VALID";
		}
		
		if(this.riskObj.occRiskClassification != 'Referred' && this.riskObj.ageLimitFlag != 'G'){
			let _ageRefReason = this.riskObj.referralReasons.referralReason.find((_data1)=> _data1.code=='01');
			if(_ageRefReason && _ageRefReason.isSysReferred == 'Y'){
				_ageRefReason.isSysReferred = 'N';
			}
		}			

		if(this.riskObj.occupationCode){
			let _rec = this.lovDropDownService.lovDataList.Occupation.find((_data)=> _data.VALUE == this.riskObj.occupationCode);
						
			if(_rec && _rec.REFERREDRISK && _rec.REFERREDRISK=='Y'){
				isReferredRisk = true;
				this.riskObj.occRiskClassification="Referred";
				_reasons.reason.push("Occupation code of type Referred selected");
				this.addReferralReason('05', true);
			}
			else if(_rec && _rec.REFERREDRISK && _rec.REFERREDRISK=='D'){
				isDeclinedRisk = true;
				this.riskObj.occRiskClassification="Declined";
				_reasons.reason.push("Declined : Occupation code of type Declined selected");
			}
			else {
				this.riskObj.occRiskClassification="Standard";
			}
			
			if(this.riskObj.occRiskClassification != 'Referred'){
				let _occRefReason = this.riskObj.referralReasons.referralReason.find((_data1)=> _data1.code=='05');
				if(_occRefReason && _occRefReason.isSysReferred == 'Y'){
					_occRefReason.isSysReferred = 'N';
				}
			}			
		}		
			
		this.riskObj.riskClassificationReasons.reasons = _reasons;
		
		if(isDeclinedRisk == true){
			this.riskObj.symRiskClassification = "Declined";			
		}
		else if(isReferredRisk == true){
			this.riskObj.symRiskClassification = "Referred";			
		}
		else this.riskObj.symRiskClassification = "Standard";
		*/

        // this.handleRiskClassification();
        this._s5382Service.handleRiskClassification(this);
    }

    isItInAgeRange() {
        //Other products Age above 70 to be treated as Referred
        if (Number(this.riskObj.insuredAge) > 70) {
            return false;
        }
        else {
            return true;
        }
    }
	/*
	handleRiskClassification(){
		if(this.riskObj.symRiskClassification == "Declined")
			this.riskObj.riskClassification = "Declined";
		else if(this.riskObj.symRiskClassification == "Referred" || this.riskObj.riRiskClassification == "Referred")
			this.riskObj.riskClassification = "Referred";
		else
			this.riskObj.riskClassification = "Standard";
		
		this.setRiskClassification(this);
		this.emitRiskClass(this);
	}*/

    emitRiskClass(comp) {
        comp.onRiskClsChange.emit("");
    }

    checkReferredRisk(comp) {
        //validate date of birth and age range to identify referred risk. if not check on occupation
        if (comp.riskObj.dateOfBirth && comp.isItInAgeRange() == false) {
            comp.riskObj.symRiskClassification = "Referred";
            comp.riskObj.riskClassification = comp.riskObj.symRiskClassification;
        } else {
            if (comp.riskObj.occRiskClassification != null && comp.riskObj.occRiskClassification == "Referred") {
                comp.riskObj.symRiskClassification = "Referred";
                comp.riskObj.riskClassification = comp.riskObj.symRiskClassification;
            } else {//if(comp.riskObj.occRiskClassification != null && comp.riskObj.occRiskClassification != ""){
                if (comp.riskObj.dateOfBirth && comp.isItInAgeRange() == false) {
                    comp.riskObj.symRiskClassification = "Referred";
                    comp.riskObj.riskClassification = comp.riskObj.symRiskClassification;
                } else {
                    comp.riskObj.symRiskClassification = comp.riskObj.occRiskClassification;
                    comp.riskObj.riskClassification = comp.riskObj.symRiskClassification;
                }
            }
        }
        comp.setRiskClassification(comp);
    }

    setRiskClassification(comp) {
        if (comp.riskObj.symRiskClassification != null && comp.riskObj.symRiskClassification != "" && (comp.riskObj.symRiskClassification == "Referred" || comp.riskObj.symRiskClassification == "Declined")) {
            let statusTxt = (comp.riskObj.symRiskClassification != null && comp.riskObj.symRiskClassification != "") ? comp.riskObj.symRiskClassification : comp.riskObj.riskClassification;
            comp.riskObj.riskClassificationReason = "System marked as " + statusTxt;
        }
        else {
            if (comp.riskObj.riskClassificationReason != null && comp.riskObj.riskClassificationReason != "" && (comp.riskObj.riskClassificationReason != "System marked as Standard"
                && comp.riskObj.riskClassificationReason.indexOf("System marked as ") != -1)) {
                comp.riskObj.riskClassificationReason = "";
            }
        }
        comp.onRiskClsChange.emit(comp.riskObj.itemNo);
    }

    changeRiskClassification(event) {
        this.riskObj.riskClassification = event.target.value;
        this.onRiskClsChange.emit(this.riskObj.itemNo);
    }

     //VK013
     public formatText(event) {
        var value = event.target.value;
        var valid = true;
        var maxLineChars = 60;
        var result = "";
        var finalLines = [];
        var lines = value.split(/\r\n|\r|\n/g);
        var length = lines.length;
        var str1: String,str2: String,strn: String,temp_str: String;
        var x = false;
        
        for (var i = 0; i < length; i++) {
            if (lines[i].length > maxLineChars) {
                    strn = lines[i];
                        while( strn.length > maxLineChars ){
                        str1 = strn.substring(0, maxLineChars);
						str2 = strn.substring(maxLineChars);
						
						if( !str1.endsWith(" ") && !str2.startsWith(" ") && str1.lastIndexOf(" ") != -1) {
							
							str1 = str1.substring(0, str1.lastIndexOf(" "));
							temp_str = strn.substring(str1.length);
							if(temp_str.startsWith(" ")) {
								strn = strn.substring(str1.length+1);
							} else { 
								strn = temp_str;
							}
						}
						else {
							strn = str2;
                        }
                        finalLines[finalLines.length] = str1;
                    }
                    if(strn != "" && strn.length <= maxLineChars) {
                        finalLines[finalLines.length] = strn;
                    }
                } else {
                finalLines[finalLines.length] = lines[i];
            }
        }
        
        for (var i = 0; i < finalLines.length; i++) {
            result += finalLines[i];
            if (i + 1 < finalLines.length) {
                result += "\n";
            }
        }
        event.target.value = result;
        this.riskObj.exclusionText = result;
    }

}

