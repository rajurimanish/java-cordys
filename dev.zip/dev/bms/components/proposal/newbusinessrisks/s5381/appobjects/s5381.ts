import { Clause } from "../../appobjects/clause"
import { AppUtil } from '../../../../../../common/components/utility/apputil/app.util';
import { Nominee, NomineeDetails } from "../../appobjects/nomineeslist";
import { GSTDetails } from '../../appobjects/gstDetails';
// import {DoctorDetails} from '../../appobjects/doctorDetails';
import { NBRisk } from '../../../appobjects/nbrisk';
import { PostedPrem } from '../../../proposalheader/appobjects/postedprem';
import { RiskHelper } from '../../../appobjects/riskhelper';
import { ReferredReason } from '../../../proposalheader/appobjects/referredreason';
import { ReferralReasons } from '../../appobjects/referralReasons';
import { S5381Validator } from '../../../validation/s5381.validator';
import { S5382Validator } from '../../../validation/s5382.validator';

export class S5381 extends RiskHelper implements NBRisk {

    public sequenceNumber: string;
    public effectiveDate: string;
    public dateOfAttachment: string;
    public contractNumber: string = "";
    public contractType: string;
    public riskNumber: string;
    public riskType: string;
    public riskName: string;
    public terminationDate: string;

    public insuredPersonNo: string;
    public insuredPerson: string;
    public occupationCode: string;
    public occupationDescription: string;
    public dateOfBirth: string;
    public insuredAge: number = 0;
    public RIRetentionCode: string;
    public ratingFlag: string = "A";
    public SICurrency: string = "RM";
    public currencyRate: string = "1.0000000";
    public premiumClass: string;
    public familyEmeOrRlb: string = "N";

    public RIMethod: string;
    public RIRequired: string = "No";
    public hasClaimExperience: string = "N";
    public isSurveyNeeded: string = "N";
    public RIMethodSys: string;
    public isRIOverWrittenByUW: string = "N";
    public riskClassification: string = "Standard";
    public symRiskClassification: string = "";
    public riskClassificationReason: string = "";
    public occRiskClassification: string = "";

    public minimumPremium: number = 0;
    public bigCapitalSumInsured: number = 0;

    public noOfPersons: number = 0;
    public rebate: number = 0;
    public rebateAmount: number = 0;
    public discountedPremium: number = 0;
    public GST: number = 0;
    public gstAmount: number = 0;
    public totalPremium: number = 0;
    public relatedSumInsured: number = 0;

    public capitalSumInsured: number = 0;
    public emeSumInsured: number = 0;
    public totalEMERLBAnnualPremium: number = 0;
    public totalEMERLBPostingPremium: number = 0;
    public routingSumInsured: number = 0;

    public totalGrossCapacity: number = 0;
    public postingPremium: number = 0;
    public originalTotalPremium: number = 0;
    public basePostedPremiumAdj: number = 0;
    public isPOIConsidered: string = "N";
    public priority: string;
    public postedPremium: number = 0;
    public GT: string;
    public FI: string = "Y";
    public GP: string;
    public CL: string;

    public s5382Items: S5382Item;
    public clauses: Clause;
    public GSTDetails: GSTDetails;

    public gpText: string;
	public gpTextCount:string;//VK004
    public postingMessage: string = "";
    public postedPremDetails: PostedPrem;
    public childRiskPath: string = "s5382Items.s5382Item";
    public childRiskIdentity: string;
    public riskClassificationReasons: ReferredReason;

    public ageLimitFlag: string = "";
    public s5648PostingStatus: string = "N";
    public SST: number = 0; //SST Code
    public sstAmount: number = 0;//SST Code
    public GSTLiveDate: string;//SST Code
    public SSTLiveDate: string;//SST Code
    public isGSTApplicable: boolean = true;//SST Code
    constructor() {
        super();
        this.s5382Items = new S5382Item();
        this.GSTDetails = new GSTDetails();
        this.clauses = new Clause();
        this.riskClassificationReasons = new ReferredReason();
    }

    public getInstance(valObj: S5381) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
            this.s5382Items = new S5382Item().getInstance(valObj.s5382Items);
            this.clauses = new Clause().getInstance(valObj.clauses);
            this.GSTDetails = new GSTDetails().getInstance(valObj.GSTDetails);
            this.riskClassificationReasons = new ReferredReason().getInstance(valObj.riskClassificationReasons);
            if (valObj.isGSTApplicable != undefined && JSON.stringify(valObj.isGSTApplicable) != JSON.stringify("") && typeof (valObj.isGSTApplicable) == "string") {
                this.isGSTApplicable = Boolean(JSON.parse(valObj.isGSTApplicable));
            }
        }
        return this;
    }

    public getNewInstanceByCriteria(criteria: any) {
        let riskType = criteria.riskType;
        let contractType = criteria.contractType;

        // if(contractType=="HIG"){
        // this.riskClassification = "Referred";
        // this.symRiskClassification = "Referred";
        // this.riskClassificationReason = "Referred Product";
        // }

        if (contractType == "HIG" && riskType == "HIG") {
            this.RIRetentionCode = "HI01";
            this.premiumClass = "47A";
        }
        else if (contractType == "HIG" && riskType == "HGM") {
            this.RIRetentionCode = "HI01";
            this.premiumClass = "47A";
        }
        else if (contractType == "HIG" && riskType == "HMG") {
            this.RIRetentionCode = "HI01";
            this.premiumClass = "47I";
        }
        else if (contractType == "HII" && riskType == "HII") {
            this.RIRetentionCode = "HI01";
            this.premiumClass = "47B";
        }
        else if (contractType == "HII" && riskType == "HIC") {
            this.RIRetentionCode = "HI01";
            this.premiumClass = "47F";
        }
        else if (contractType == "HII" && riskType == "HGM") {
            this.RIRetentionCode = "HI01";
            this.premiumClass = "47B";
        }
        else if (contractType == "HII" && riskType == "HMI") {
            this.RIRetentionCode = "HI01";
            this.premiumClass = "47H";
        }
        else if (contractType == "EMC" && riskType == "EMC") {
            this.RIRetentionCode = "HI01";
            this.premiumClass = "47A";
        }

        this.GSTDetails.inputTaxAllowed = "N";

        return this;
    }

    public getValidator() {
        return new S5381Validator(this);
    }
}

export class S5382Item {
    public s5382Item: S5382ItemDetails[] = [];
    public getInstance(valObj: S5382Item) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().handleArray(this, valObj, "s5382Item");
            for (let eachs5382Itm of this.s5382Item) {
                let s5382ItemObj = new S5382ItemDetails().getInstance(eachs5382Itm);
                this.s5382Item[this.s5382Item.indexOf(eachs5382Itm)] = s5382ItemObj;
            }
        }
        return this;
    }
}

export class S5382ItemDetails extends RiskHelper implements NBRisk {

    public contractNumber: string = "";
    public riskType: string;
    public riskName: string = "";
    public dateStart: string;
    public lastDateEnd: string;
    public indicator: string;
    public attachmentDate: string;
    public inclusionDate: string;
    public effectiveDate: string;
    public endorsmentEndDate: string;
    public terminationDate: string;
    public GP: string;
    public NO: string;
    public FI: string;
    public CL: string;
    public DD: string;

    public ratingFlag: string = "A";
    public basis: string = "NAMED";
    public prtCert: string = "Y";
    public noOfUnits: number = 1;

    public itemNo: number;
    public noOfPerson: string;
    public insuredAge: number = 0;
    public insuredPerson: string = "";
    public insuredSalutation: string;
    public occupationCode: string;
    public occupationDescription: string;
    public occupationClass: string;
    public occupationClassRate: number = 0;
    public IdProofNo: string = "";
    public dateOfBirth: string;
    public gender: string;
    public maritalStatus: string;
    public nationality: string;
    public homeCity: string;
    public residence: string;
    public areaCode: string;
    public load: number = 0;
    //public preExistingCondition:string;
    public plan: string;
    public planDesc: string;
    public exclusionText: string;
    public gpText: string;

    public renewalBonusAmount: number = 0;
    public renewalBonusPercentage: number = 0;
    public aeaFee: number = 0;
    public emeRlb: number = 0;
    public loadingOccupation: number = 0;
    public loadingTravel: number = 0;
    public loadingClaim: number = 0;
    public loadingOthers: number = 0;

    public maternityOption: string;
    public maternityOptionPlan: string;
    public ibrOption: string;
    public ibrOptionPlan: string;
    public ibrPremium: number = 0;
    public maternityDate: string;
    public maternityPremium: number = 0;
    public emeSumInsured: number = 0;
    public emePremium: number = 0;
    public discountPercent: number = 0;
    public discountAmount: number = 0;
    //public discountPremium:number;
    public emeRlbZERTTY: number = 0;

    public riskClassification: string = "Standard";
    public symRiskClassification: string = "";
    public riskClassificationReason: string = "";
    public riRiskClassification: string = "Standard";
    public occRiskClassification: string = "Standard";

    public basicPremium: number = 0;
    public loadingPremium: number = 0;
    public discountedPremium: number = 0;
    public postedPremium: string;
    public postingPremium: number = 0;
    public originalTotalPremium: number = 0;
    public totalPremium: number = 0;
    public totalAnnualPremium: number;
    public integratedTotalPremium: number = 0;
    public rebate: number = 0;
    public rebateAmount: number = 0;
    public GST: number = 0//6;//SST Code
    public gstAmount: number = 0;
    public capitalSumInsured: number = 0;
    public routingSumInsured: number = 0;

    public planBenefits: Benefit;
    public clauses: Clause;
    public nomineeDetails: NomineeDetails;
    // public doctorDetails: DoctorDetails;

    public isBrochurePlan: string = "N";
    public ZOFLG01: string = "";
    public ZOFLG02: string = "";
    public postingMessage: string = "";

    public basePostedPremiumAdj: number = 0;
    public isPOIConsidered: string = "N";
    public priority: string;
    public childRiskPath: string;
    public childRiskIdentity: string = "itemNo";
    public riskClassificationReasons: ReferredReason;
    public referralReasons: ReferralReasons;
    public ageLimitFlag: string = "";
    public hasClaimExperience: string = "N";

    public SST: number = 0; //SST
    public sstAmount: number = 0;//SST
    public isInsuredTerminated : string = ""; // Medical Renewals
    constructor() {
        super();
        this.planBenefits = new Benefit();
        this.clauses = new Clause();
        this.nomineeDetails = new NomineeDetails();
        // this.doctorDetails = new DoctorDetails();
        this.riskClassificationReasons = new ReferredReason();
        this.referralReasons = new ReferralReasons();
    }

    public getInstance(valObj: S5382ItemDetails) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
            this.planBenefits = new Benefit().getInstance(valObj.planBenefits);
            this.clauses = new Clause().getInstance(valObj.clauses);
            this.nomineeDetails = new NomineeDetails().getInstance(valObj.nomineeDetails);
            // this.doctorDetails = new DoctorDetails().getInstance(valObj.doctorDetails);
            this.riskClassificationReasons = new ReferredReason().getInstance(valObj.riskClassificationReasons);
            this.referralReasons = new ReferralReasons().getInstance(valObj.referralReasons);
        }
        return this;
    }

    public getNewInstanceByCriteria(criteria: any) {

        let riskType = criteria.riskType;
        let contractType = criteria.contractType;

		/*if(contractType=="EMC"){
			this.occupationCode="7STU";
		}
		else if(contractType=="HII"){
			this.occupationCode="7STU";
			this.nationality="MAL";
			this.homeCity="MAL";
			this.residence="MAL";
			this.areaCode="01";
		}*/

        return this;
    }

    public getValidator() {
        return new S5382Validator(this);
    }
}

export class Benefit {
    public benefit: BenefitItem[] = [];

    public getInstance(valObj: Benefit) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().handleArray(this, valObj, "benefit");
        }
        return this;
    }
}

export class BenefitItem {
    public seqNumber: number;
    public coverageCode: string;
    public coverageDescription: string;
    public extraText: string;
    public etPostingStatus = "N";
    public sumInsured: number;
    public siWorldWide: number;
}