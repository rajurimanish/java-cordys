export class LoadingDiscountCode {
    constructor(
        public loadingDiscountCode?: string
    ) { }
}