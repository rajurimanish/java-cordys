import { RateableClassCode } from './rateableClassCode';
import { AppUtil } from '../../../../../common/components/utility/apputil/app.util';
import { Peril } from './peril';
import { WarrantyClassCode } from './warrantyClassCodes';
// import {XTComments} from './xtComments';

export class FireItems {

    //SAF MYS-2019-0909 start
    public addOnBenefitCode: string;
    public benefitSI: number = 0;
    public benefitPremiumClass: string;
    public benefitPremium: number = 0;//End

    public fireItems: FireItem[] = [];

    public getInstance( valObj: FireItems ) {
        if ( new AppUtil().isValidObj( valObj ) == true ) {
            new AppUtil().setFieldValue( this, valObj );
            new AppUtil().handleArray( this, valObj, "fireItems" );
            for ( let item of this.fireItems ) {
                let itemObj = new FireItem().getInstance( item );
                this.fireItems[this.fireItems.indexOf( item )] = itemObj;
            }
        }
        return this;
    }

    // SAF MYS-2018-1249 start
    public refreshFireItem( valObj: FireItems ) {
        if ( new AppUtil().isValidObj( valObj ) == true ) {
            new AppUtil().setFieldValue( this, valObj );
            new AppUtil().handleArray( this, valObj, "fireItems" );
            for ( let item of this.fireItems ) {
                let itemObj = new FireItem().getInstance( item );
                this.fireItems[this.fireItems.indexOf( item )] = itemObj;
            }
        }
        return this;
    }//End
}

export class FireItem {
    public itemNo: number;
    public seqNumber: number;
    public cover: string;
    public sumInsured: number;
    public basicRate: number;
    public perilRate: number;
    public clauseRate: number;
    public feaRate: number = 0;
    public feaDiscount: number;
    public rate: number;
    public multiplierPercentage: number;
    public premium: number;
    public premiumClass: string;
    public rateableClassCodes: RateableClassCode;
    public extraText: string = "";
    public etPostingStatus = "N";
    // public xtComments:XTComments;
    public deductableRate: number = 0;
    public perilClassCodes: Peril;// SAF MYS-2018-1249
    public wcClassCodes: WarrantyClassCode;// SAF MYS-2018-1249
    public ratingCommitteeRate: number = 0;// SAF MYS-2018-1249

    constructor() {
        this.rateableClassCodes = new RateableClassCode();
        // this.xtComments = new XTComments();
        this.perilClassCodes = new Peril();// SAF MYS-2018-1249
        this.wcClassCodes = new WarrantyClassCode();// SAF MYS-2018-1249
    }

    public getInstance( valObj: FireItem ) {
        if ( new AppUtil().isValidObj( valObj ) == true ) {
            new AppUtil().setFieldValue( this, valObj );
            this.rateableClassCodes = new RateableClassCode().getInstance( valObj.rateableClassCodes );
            // this.xtComments = new XTComments().getInstance(valObj.xtComments);
            this.perilClassCodes = new Peril().getInstance( valObj.perilClassCodes );// SAF MYS-2018-1249
            this.wcClassCodes = new WarrantyClassCode().getInstance( valObj.wcClassCodes );// SAF MYS-2018-1249
        }
        return this;
    }

    // SAF MYS-2018-1249 start
    public refreshFireItemDetails( valObj: FireItem ) {
        if ( new AppUtil().isValidObj( valObj ) == true ) {
            new AppUtil().setFieldValue( this, valObj );
            this.rateableClassCodes = new RateableClassCode().getInstance( valObj.rateableClassCodes );
            this.perilClassCodes = new Peril().getInstance( valObj.perilClassCodes );
            this.wcClassCodes = new WarrantyClassCode().getInstance( valObj.wcClassCodes );
        }
        return this;
    }//End
}