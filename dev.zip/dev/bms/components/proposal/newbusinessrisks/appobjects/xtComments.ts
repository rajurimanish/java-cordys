import { AppUtil } from '../../../../../common/components/utility/apputil/app.util';

export class XTComments {
    public xtComment: XTComment[] = [];
    public postingStatus: string = 'N';

    public getInstance(valObj: XTComments) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().handleArray(this, valObj, "xtComment");
            for (let item of this.xtComment) {
                let itemObj = new XTComment().getInstance(item);
                this.xtComment[this.xtComment.indexOf(item)] = itemObj;
            }
        }
        return this;
    }
}

export class XTComment {
    public itemNo: number;
    public comment: string;

    constructor() { }

    public getInstance(valObj: XTComment) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
        }
        return this;
    }

}

