import { AppUtil } from '../../../../../common/components/utility/apputil/app.util';

export class GSTDetails {
    public riskUsage: string = "P";
    public riskLocation: string = "PCA";
    public placeOfRecidence: string = "PCA";
    public terminationDate: string;
    public inputTaxAllowed: string = "N";

    constructor() { }
    public getInstance(valObj: GSTDetails) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
        }
        return this;
    }
}