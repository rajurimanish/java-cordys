import { AppUtil } from '../../../../../common/components/utility/apputil/app.util';

export class MotorItems {
    public motorItem: MotorMCVDetail[] = [];
    public getInstance(valObj: MotorItems) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().handleArray(this, valObj, "motorItem");
        }
        return this;
    }

    public refresh(valObj: MotorItems) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().handleArray(this, valObj, "motorItem");
        }
    }
}

export class MotorMCVDetail {
    public sequence: number;
    public code: string;
    public additionalBenifits: string;
    public dateFromAdditionalBenfit: string;
    public dateToAdditionalBenfit: string;
    public limits: string;
    public additionalpremium: number;
    public noOfAdditionalClaims: number;
    public isSpecial: boolean;
    public isLimitDisable: boolean;
    public isSystemDefault: string = "N";
    public extraText: string = "";
    public etPostingStatus = "N";
    public seqNumber: number;

    constructor() { }
}