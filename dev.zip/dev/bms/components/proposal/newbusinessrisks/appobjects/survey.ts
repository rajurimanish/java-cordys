import { AppUtil } from '../../../../../common/components/utility/apputil/app.util';

export class Survey {
    public basicDetails: BasicDetails;
    public clientDetails: ClientDetails;
    public occupationDetails: OccupationDetails;
    public otherDetails: OtherDetails;
    public surveyDetails: SurveyDetails;
    public userid: string;
    public password: string;
    public bpmUniqueId: string;
    public draftValue: string = "1";
    public createdBy: string;
    public referenceNumber: string;

    constructor() {
        this.basicDetails = new BasicDetails();
        this.clientDetails = new ClientDetails();
        this.occupationDetails = new OccupationDetails();
        this.otherDetails = new OtherDetails();
        this.surveyDetails = new SurveyDetails();
    }

    public getInstance(valObj: Survey) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
            this.basicDetails = new BasicDetails().getInstance(valObj.basicDetails);
            this.clientDetails = new ClientDetails().getInstance(valObj.clientDetails);
            this.occupationDetails = new OccupationDetails().getInstance(valObj.occupationDetails);
            this.otherDetails = new OtherDetails().getInstance(valObj.otherDetails);
            this.surveyDetails = new SurveyDetails().getInstance(valObj.surveyDetails);
        }
        return this;
    }
}

export class BasicDetails {
    public dateOfReq: string;
    public from: string;
    public department: string;
    public getInstance(valObj: BasicDetails) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
        }
        return this;
    }
}

export class ClientDetails {
    public insuredName: string;
    public intermediaryName: string;
    public intermediaryCode: string;
    public contactPerson: string;
    public contactNumber: string;
    public emailId: string;
    public addressLine1: string;
    public addressLine2: string;
    public addressLine3: string;
    public countryid: string;
    public state: string;
    public city: string;
    public postCode: string;
    public intermediary: string = "0";
    public insured: string = "1";
    public salutation: string;

    public getInstance(valObj: ClientDetails) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
        }
        return this;
    }
}

export class OccupationDetails {
    public occOrTrade: string = "";
    public piamCode: string;
    public fireRiskCode: string = "";
    public constructionClass: string;
    public burglarySurveyCode: string = "";
    public getInstance(valObj: OccupationDetails) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
        }
        return this;
    }
}

export class OtherDetails {
    public lossHistory: string = "0";
    public specialReq: string = "0";
    public proMeetDate: string;
    public proMeetTime: string
    public documentsDetails: DocumentsDetails;
    constructor() {
        this.documentsDetails = new DocumentsDetails();
    }
    public getInstance(valObj: OtherDetails) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
        }
        return this;
    }
}

export class DocumentsDetails {
    public module: string = "surveyOTH";
    public uploadDownloadList: UploadDownloadItem[] = [];
    public getInstance(valObj: DocumentsDetails) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
            new AppUtil().handleArray(this, valObj, "uploadDownloadList");
        }
        return this;
    }
}

export class UploadDownloadItem {
    public docType: string;
    public docName: string;
    public remarks: string;
    public hardCopy: string;
    public actionFlag: string;
    public docIndex: string;
    public fileSize: string;
    public fileType: string;
    public fileName: string;
    public isMandatory: string;
    public fileExtension: string;
    public fileSrc: string;

    public getInstance(valObj: DocumentsDetails) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
        }
        return this;
    }
}

export class SurveyDetails {
    public newBusiness: NewBusiness[] = [];
    //public resurvey:Resurvey;
    constructor() {
        //this.newBusiness = new NewBusiness();
        //this.resurvey = new Resurvey();
    }
    public getInstance(valObj: SurveyDetails) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().handleArray(this, valObj, "newBusiness");
            //this.newBusiness = new NewBusiness().getInstance(valObj.newBusiness);
            //this.resurvey = new Resurvey().getInstance(valObj.resurvey);
        }
        return this;
    }
}

export class NewBusiness {

    public typeOfSurvey: string = "0";
    public typeOfSurveyDesc: string = "Fire";
    public totalNewPolicySI: string;
    public newPolicySIList: NewPolicySI[] = [];
    public totalSI: string;

    public getInstance(valObj: NewBusiness) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
            new AppUtil().handleArray(this, valObj, "newPolicySIList");
        }
        return this;
    }
}

export class Resurvey {
    public typeOfSurvey: string;
    public typeOfSurveyDesc: string;
    public totalNewPolicySI: string;
    public newPolicySIList: NewPolicySIList;
    public totalSI: string;
    public previousID: string;
    public policyNo: string;
    public policyExpiryDate: string;
    public previousPolicySI: string;
    public addEditFlag: string

    public getInstance(valObj: Resurvey) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
        }
        return this;
    }
}

export class NewPolicySIList {
    public newPolicySIList: NewPolicySI[] = [];

    public getInstance(valObj: NewPolicySIList) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().handleArray(this, valObj, "newPolicySIList");
        }
        return this;
    }
}

export class NewPolicySI {
    public si: string;
    public siFor: string;
}