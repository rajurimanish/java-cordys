import { AppUtil } from '../../../../../common/components/utility/apputil/app.util';

export class FireRelatedCases {
    public isReferredRisk: string = "N";
    public sumInsured: string;
    public relatedCases: RelatedCases;
    constructor() {
        this.relatedCases = new RelatedCases();
    }
    public getInstance(valObj: FireRelatedCases) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
            this.relatedCases = new RelatedCases().getInstance(valObj.relatedCases);
        }
        return this;
    }
}

export class RelatedCases {
    public relatedCase: RelatedCase[] = [];
    public getInstance(valObj: RelatedCases) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().handleArray(this, valObj, "relatedCase");
        }
        return this;
    }
}

export class RelatedCase {
    public id: string;
    public riskType: string;
    public producerCode: string;
    public accountHandlerName: string;
    public inceptionDate: string;
    public endDate: string;
    public riskNumber: string;
    public sumInsured: string;
}