export class RateableClassIndicator {

    public rateableClassIndicator: Object[] = [];

    constructor() { }
}