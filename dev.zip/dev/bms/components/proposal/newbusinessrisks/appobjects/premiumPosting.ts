export class PremiumPosting {

    public annualGrossPremium: number = 0;
    public annualStampDuty: number = 0;
    public annualDiscount: number = 0;
    public annualCommission: number = 0;
    public annualOverridingCommission: number = 0;
    public annualNetPremium: number = 0;
    public annualServiceTax: number = 0;
    public annualBankCharges: number = 0;
    public annualIGSFLevy: number = 0;
    public annualServiceCharge: number = 0;
    public annualgstOnCommission: number = 0;
    public annualgstOnOverridingCommission: number = 0;
    public annualgstOnPremium: number = 0;
    public annualgstOnServiceCharge: number = 0;
    public annualgstOnBankCharges: number = 0;
    public annualgstOnPremiumAbs: number = 0;
    public annualPremiumNoGST: number = 0;
    public annualPremiumGST: number = 0;
    public annualPremiumDue: number = 0;
    public postedGrossPremium: number = 0;
    public postedStampDuty: number = 0;
    public postedDiscount: number = 0;
    public postedCommission: number = 0;
    public postedOverridingCommission: number = 0;
    public postedNetPremium: number = 0;
    public postedServiceTax: number = 0;
    public postedBankCharges: number = 0;
    public postedIGSFLevy: number = 0;
    public postedServiceCharge: number = 0;
    public postedgstOnCommission: number = 0;
    public postedgstOnOverridingCommission: number = 0;
    public postedgstOnPremium: number = 0;
    public postedgstOnServiceCharge: number = 0;
    public postedgstOnBankCharges: number = 0;
    public postedgstOnPremiumAbs: number = 0;
    public postedPremiumNoGST: number = 0;
    public postedPremiumGST: number = 0;
    public postedPremiumDue: number = 0;
    public stampDutyMethod: number = 0;
    public serviceTaxMethod: number = 0;
    public bankChargesMethod: number = 0;
    public igsfLevyMethod: number = 0;
    public scMethod: number = 0;
    public gstMethod: number = 0;
    public scGstMethod: number = 0;
    public bcGstMethod: number = 0;
    public commGstMethod: number = 0;
    public orCommGstMethod: number = 0;
    public transCode: number = 0;
    public surcharge: number = 0;
    public directDiscount: number = 0;
    public brokerDiscount: number = 0;
    public discount: number = 0;

    constructor() { }
}