import { AppUtil } from '../../../../../common/components/utility/apputil/app.util';

export class RateableClassCode {

    public rateableClassCode: RateableClassCodeDetail[] = [];

    constructor() { }

    public getInstance(valObj: RateableClassCode) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().handleArray(this, valObj, "rateableClassCode");
        }
        return this;
    }

    // SAF MYS-2018-1249 --start
    public refreshRateableClassCode(valObj: RateableClassCode) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().handleArray(this, valObj, "rateableClassCode");
        }
        return this;
    } //End
}

export class RateableClassCodeDetail {

    public classCode: string;
    public rate: string;
    public description: string;
    public isPercent: string = "N";
    public originalRate: string;
    // SAF MYS-2018-1249 --start
    public nature: string;
    public nominatedSumInsured: number;
    public nominatedSumInsuredNew: number;
    public amount: string = "0.00";
    public unFormattedAmount: number;
    public overrideInd: string;
    public disableItem: string;
    public coverItems: Array<string> = [];
    public prlPRT: string;
    public overrideIndRate: string;
    public isDefaultRCClause: string;
    constructor() {
        this.coverItems = [];
    }//End
}