import { AppUtil } from '../../../../../common/components/utility/apputil/app.util';

export class DoctorDetails {
    public name: string;
    public addressLine1: string;
    public addressLine2: string;
    public addressLine3: string;
    public addressLine4: string;
    public phoneNumber: string;

    constructor() { }
    public getInstance(valObj: DoctorDetails) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
        }
        return this;
    }
}