export class DeclarationDetails {

    public declarationDetail: DeclarationDetail[] = [];

}

export class DeclarationDetail {

    public expectedDate: string;
    public receivedDate: string;
    public description: string;
    public sumInsured: string;
    public premiumClass: string;

    constructor() { }

}
