import { AppUtil } from '../../../../../common/components/utility/apputil/app.util';

export class PIAMStatistics {

    public garage: string = "";
    public logBookNo: string;
    public color: string;
    public ownershipType: string;
    public antiTheft: string = "";
    public saftyFeatures: string = "";
    public vehicalFrom: string;
    public vehicalCondition: string = "";
    public localOrImport: string = "";
    public purchasePrice: string;
    public purchaseDate: string;
    public previousInsurer: string = "999";
    public previousPolicyNumber: string;
    public vehicalRegNo: string;
    public previousPOIFrom: string;
    public previousPOITo: string;
    public engineNo: string;
    public chassisNo: string;
    public vehicalClass: string = "";
    public vehicalBodyCode: string = "";

    constructor() { }

    public getInstance(valObj: PIAMStatistics) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
        }
        return this;
    }
}