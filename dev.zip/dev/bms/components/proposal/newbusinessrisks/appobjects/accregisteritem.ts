export class AccRegisterItem {
    public caseId: string;
    public riskNo: string;
    public riskType: string;
    public totalSI: number;
    public freg: string;
    public dteeff;
    public dteter;
    public status: string;
    public policyNumber: string;
    public riskGAL;
    public riskMNRB;
    public riskTREATY;
    public riskFAC;
    constructor() { }
}