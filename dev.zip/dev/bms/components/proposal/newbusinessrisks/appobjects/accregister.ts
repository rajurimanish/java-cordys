import { AppUtil } from '../../../../../common/components/utility/apputil/app.util';
import { AccRegisterItem } from './accregisteritem';

export class AccRegister {
    public ExposerQuotAccepted: string;
    public formattedExposerQuotAccepted: string;
    public HoldCoverExposer: string;
    public formattedHoldCoverExposer: string;
    public GAL: string;
    public formattedGAL: string;
    public P400InforcedExposer: string;
    public formattedP400InforcedExposer: string;
    public TotalExposer: string;
    public formattedTotalExposer: string;
    public Outstanding: string;
    public formattedOutstanding: string;
    public cessionOutwords: string;
    public formattedcessionOutwords: string;
    public totalPercentage: number;
    public isSystemReferred: boolean;
    public isAccuSystemReferredFlag: boolean;
    public accRegisterItem?: AccRegisterItem[];

    constructor() {
        this.ExposerQuotAccepted = "";
        this.HoldCoverExposer = "";
        this.GAL = "";
        this.P400InforcedExposer = "";
        this.TotalExposer = "";
        this.Outstanding = "";
        this.cessionOutwords = "";
        this.totalPercentage = 0;

        this.formattedExposerQuotAccepted = "";
        this.formattedHoldCoverExposer = "";
        this.formattedGAL = "";
        this.formattedP400InforcedExposer = "";
        this.formattedTotalExposer = "";
        this.formattedOutstanding = "";
        this.formattedcessionOutwords = "";
        this.isSystemReferred = false;
        this.isAccuSystemReferredFlag = false;

        this.accRegisterItem = [];
    }

    public getInstance(valObj: AccRegister) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().handleArray(this, valObj, "accRegister");
        }
        return valObj;
    }
}