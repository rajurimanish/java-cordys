export class SituationRiskDetails {

    public situationOfRisk: string;
    public latitude: string;
    public longitude: string;

    constructor() { }
}