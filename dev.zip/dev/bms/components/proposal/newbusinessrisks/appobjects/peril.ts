import { AppUtil } from '../../../../../common/components/utility/apputil/app.util';

export class Peril {
    public fireAndLightingRate: string = "0";
    public perilTotal: number = 0;
    public peril: PerilDetail[] = [];

    public getInstance(valObj: Peril) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
            new AppUtil().handleArray(this, valObj, "peril");
        }
        return this;
    }

    // SAF MYS-2018-1249 --start
    public refreshPerils(valObj: Peril) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
            new AppUtil().handleArray(this, valObj, "peril");
        }
        return this;
    } //End
}

export class PerilDetail {

    public perilCode: string;
    public autoPerilRate: string;
    public perilRate: string;
    public description: string;
    // SAF MYS-2018-1249 --start
    public nature: string;
    public nominatedSumInsured: number;
    public nominatedSumInsuredNew: number;
    public amount: string = "0.00";
    public unFormattedAmount: number;
    public overrideInd: string;
    public disableItem: string;
    public coverItems: Array<string> = [];
    public prlPRT: string;
    public overrideIndRate: string;
    //End
    constructor() {
        this.coverItems = [];
    }
}