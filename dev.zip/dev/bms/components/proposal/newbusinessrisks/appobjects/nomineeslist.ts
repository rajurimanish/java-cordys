import { AppUtil } from '../../../../../common/components/utility/apputil/app.util';

export class NomineeDetails {
    public nominee: Nominee[] = [];
    public getInstance(valObj: NomineeDetails) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().handleArray(this, valObj, "nominee");
        }
        return this;
    }
}

export class Nominee {

    public name: string;
    public ICPassport: string;
    public relationship: string = "";
    public address: string;
    public DOB: string;
    public percentageOfShare: string;
    constructor() { }
}

