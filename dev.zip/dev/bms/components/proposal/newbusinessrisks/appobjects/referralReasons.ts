import { AppUtil } from '../../../../../common/components/utility/apputil/app.util';

export class ReferralReasons {
    public referralReason: ReferralReason[] = [];

	/*public getInstance(valObj:ReferralReasons){
		if(new AppUtil().isValidObj(valObj) == true){
			new AppUtil().handleArray(this,valObj,"referralReason");
			for(let ref of valObj){
				let itemObj = new ReferralReason().getInstance(ref);				
				this.referralReason[this.referralReason.indexOf(ref)] = itemObj;
			}
		}		
		return this;
	}*/

    public getInstance(valObj: ReferralReasons) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().handleArray(this, valObj, "referralReason");
        }
        return this;
    }


}

export class ReferralReason {
    public seqNumber;
    public code: string = "";
    public description: string = "";
    public comments: string = "";
    public isSysReferred: string = 'N';
    // public isSelected: string = 'N';
    // public isSelectedUI: boolean = false;

    constructor() { }

    public getInstance(valObj: ReferralReason) {

        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
            // this.isSelectedUI = (this.isSelected == 'Y') ? true : false;
        }
        return this;
    }
}
