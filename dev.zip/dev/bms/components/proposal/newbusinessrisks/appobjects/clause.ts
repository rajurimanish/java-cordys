import { AppUtil } from '../../../../../common/components/utility/apputil/app.util';

export class Clause {
    public clause: ClauseDetail[] = [];

    public getInstance(valObj: Clause) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().handleArray(this, valObj, "clause");
        }
        return this;
    }

    // SAF MYS-2018-1249 --start
    public refreshClause(valObj: Clause) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().handleArray(this, valObj, "clause");
        }
        return this;
    } //End
}

export class ClauseDetail {
    public clauseCode: string;
    public description: string;
    public isDefaultClause: string = "N";
    constructor() { }
}

export class SpecialClauses {
    public clause: SpecialClause[] = [];

    public getInstance(valObj: SpecialClauses) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().handleArray(this, valObj, "clause");
        }
        return this;
    }
}

export class SpecialClause {
    public clauseCode: string;
}