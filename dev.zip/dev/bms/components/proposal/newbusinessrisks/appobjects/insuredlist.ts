/*
 * Change History:
 * 
 * No      Date          Description                                         Changed By
 * ====    ==========    ===========                                         ==========
 * GA001   01/10/2018    MYS-2018-0443 - Age Checking for PA Products (T7253)    KGA					   
*/
import { AppUtil } from '../../../../../common/components/utility/apputil/app.util';
import { ReferralReasons } from '../appobjects/referralReasons';//GA001

export class InsuredDetails {
    public insured: Insured[] = [];
    public getInstance(valObj: InsuredDetails) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().handleArray(this, valObj, "insured");
        }
        return this;
    }
}

export class Insured {
    public itemNo: number;
    public name: string;
    public nric: string;
    public ICPassport: string;
    public DOB: string;
    public gender: string;
    public address: string;
    public occupationCode: string;
    public occupationDescription: string;
    public terminationDate: string;
    public insuredAge: number;// DIvek -0555
    public ageLimitFlag: string;//GA001
    public referralReasons: ReferralReasons;//GA001

    constructor() { }
}

