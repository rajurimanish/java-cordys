import { AppUtil } from '../../../../../common/components/utility/apputil/app.util';

export class CBIItems {
    public cbiItems: CBIItem[] = [];
    public getInstance(valObj: CBIItems) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().handleArray(this, valObj, "cbiItems");

            for (let eachcbi of this.cbiItems) {
                let cd = eachcbi.cbiCode;
                while (cd.length < 5) {
                    cd = " " + cd;
                }
                eachcbi.cbiCode = cd;
            }
        }
        return this;
    }
}

export class CBIItem {
    public cbiCode: string;
    public cbiDescription: string;
}