import { AppUtil } from '../../../../../common/components/utility/apputil/app.util';

export class WarrantyClassCode {

    public warrantyClassCode: WarrantyClassCodeDetail[] = [];
    public wcTotal: number = 0;

    constructor() { }

    public getInstance(valObj: WarrantyClassCode) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().handleArray(this, valObj, "warrantyClassCode");
        }
        return this;
    }

    // SAF MYS-2018-1249 --start
    public refreshWarrantyClassCodes(valObj: WarrantyClassCode) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().handleArray(this, valObj, "warrantyClassCode");
        }
        return this;
    } //End
}

export class WarrantyClassCodeDetail {

    public classCode: string;
    public rate: string;
    public description: string;
    public nature: string;
    public overrideInd: string;
    public disableItem: string;
    public coverItems: Array<string> = [];
    public nominatedSumInsured: number;
    public nominatedSumInsuredNew: number;
    public amount: string = "0.00";
    public unFormattedAmount: number;
    public prlPRT: string;
    public overrideIndRate: string;
    constructor() {
        this.coverItems = [];
    }
}