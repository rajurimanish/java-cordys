/*
Change History	:

	No      Date          Description                                 Changed By
	====    ==========    ===========                                 ==========
	AL001   15/08/2017   MYS-2017-0371    -  Develop MPD               ALA										   
	VK004	03/12/2018	 MYS-2018-1192 General Page						VKR
*/
import { FinancialInterest } from '../../../../../../common/components/financialinterest/appobjects/financialInterest';
import { Clause } from "../../appobjects/clause";
import { PANPAItem } from "../../pa/appobjects/pa";
import { NomineeDetails } from "../../appobjects/nomineeslist";
import { AppUtil } from '../../../../../../common/components/utility/apputil/app.util';
import { NBRisk } from '../../../appobjects/nbrisk';
import { PostedPrem } from '../../../proposalheader/appobjects/postedprem';
import { RiskHelper } from '../../../appobjects/riskhelper';
import { ReferredReason } from '../../../proposalheader/appobjects/referredreason';
import { DPATableValidator } from '../../../validation/dpatable.validator';
import { DPAValidator } from '../../../validation/dpa.validator';

export class DriverPersonalAccident extends RiskHelper implements NBRisk {
    public sequenceNumber: string;
    public effectiveDate: string;
    public dateOfAttachment: string;
    public contractNumber: string;
    public contractType: string;
    public riskNumber: string;
    public riskType: string;
    public riskName: string = "Driver Personal Accident";//AL001
    public ratingFlag: string;
    public insuredPerson: string;
    public RIRetentionCode: string = "PA01";
    public occupationCode: string;
    public occupationDescription: string;
    public SICurrency: string;
    public currencyRate: string;
    public journey: string;
    public searchCode: string;
    public searchDescription: string;
    public noOfPersons: string;
    public capitalSumInsured: number = 0;
    public bigCapitalSumInsured: number = 0;
    public totalPremium: number = 0;
    public postingPremium: number = 0;
    public clauses: Clause;
    public terminationDate: string;
    public RIMethod: string = "0";
    public RIRequired: string = "No";
    public RIMethodSys: string = "0";
    public GT: string;
    public FI: string;
    public GP: string;
    public CL: string;
    public paDPAItems: PADPAItem;
    public financialInterest: FinancialInterest;
    public identity: string = "";
    public minimumPremium: number = 0;
    public originalTotalPremium: number = 0;
    public postedPremium: number = 0;
    public basePostedPremiumAdj: number = 0;
    public discountedPremium: number = 0;
    public rebate: number = 0;
    public rebateAmount: number = 0;
    public GST: number = 0;//6;//SAF MYS-2018-0629
    public gstAmount: number = 0;
    public riskClassification: string = "Standard";
    public symRiskClassification: string = "";
    public riskClassificationReason: string = '';
    public isPOIConsidered: string = "N";
    public priority: string;
    public postedPremDetails: PostedPrem;
    //AL001 START
    public vehicalRegNumber: string;
    public modelCode: string = "";
    public makeCode: string;
    public description: string;
    public yearOfMake: string = "";
    public seatNo: number = 0;
    //AL001 END
    public childRiskPath: string = "paDPAItems.paDPAItem";
    public childRiskIdentity: string;
    public riskClassificationReasons: ReferredReason;
    public gpText: string;
    public gpTextCount:string; //VK004
    public modelCodeNew: string = "";

    public SST: number = 0; //SST Code
    public sstAmount: number = 0;//SST Code
    public SSTLiveDate: string;//SST Code
    public GSTLiveDate: string;//SST Code
    public isGSTApplicable: boolean = true;//SST Code

    constructor() {
        super();
        this.paDPAItems = new PADPAItem();
        this.financialInterest = new FinancialInterest();
        this.clauses = new Clause();
        this.riskClassificationReasons = new ReferredReason();
    }

    public getInstance(valObj: DriverPersonalAccident) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
            this.paDPAItems = new PADPAItem().getInstance(valObj.paDPAItems);
            this.clauses = new Clause().getInstance(valObj.clauses);
            this.riskClassificationReasons = new ReferredReason().getInstance(valObj.riskClassificationReasons);
            if (valObj.FI == "Y") {
                this.financialInterest = new FinancialInterest().getInstance(valObj.financialInterest);
            }
            if (valObj.isGSTApplicable != undefined && JSON.stringify(valObj.isGSTApplicable) != JSON.stringify("") && typeof (valObj.isGSTApplicable) == "string") {
                this.isGSTApplicable = Boolean(JSON.parse(valObj.isGSTApplicable));
            }
        }
        return this;
    }

    public getNewInstanceByCriteria(criteria: any) {
        return this;
    }

    public getValidator() {
        return new DPATableValidator(this);
    }
}

export class PADPAItem {
    public paDPAItem: PADPAItemDetails[] = [];
    public getInstance(valObj: PADPAItem) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().handleArray(this, valObj, "paDPAItem");
            for (let eachDPAItm of this.paDPAItem) {
                let dpaObj = new PADPAItemDetails().getInstance(eachDPAItm);
                this.paDPAItem[this.paDPAItem.indexOf(eachDPAItm)] = dpaObj;
            }
        }
        return this;
    }
}

export class PADPAItemDetails extends RiskHelper implements NBRisk {
    public itemNo: number;
    public dateStart: string;
    public effectiveDate: string;
    public lastDateEnd: string;
    public indicator: string;
    public insuredPerson: string;
    public postedPremium: string;
    public printCI: string;
    public basis: string;
    public noOfPerson: string;
    public seatNo: number = 0;
    public seatPremium: number = 0;
    public insuredSalutation: string;
    public occupationCode: string;
    public occupationDescription: string;
    public riskClassification: string = "Standard";
    public NRIC: string;
    public IdProofNo: string;
    public dateOfBirth: string;
    public inclusionDate: string;
    public endorsmentEndDate: string;
    public maritalStatus: string;
    public gender: string;
    public certificateNo: string;
    public noOfCertificates: string;
    public loanAmount: string;
    public tenure: string;
    public loanInterestRate: string;
    public age: string;
    public creditCardNumber: string;
    public creditCardType: string;
    public plan: string;
    public noOfUnits: number = 1;
    public basicPremium: number = 0;
    public totalPremium: number = 0;
    public surChargeAmount: string;
    public loadingDiscountPercentage: number = 0;
    public loadingDiscountAmount: number = 0;
    public postingPremium: number = 0;
    public totalAnnualPremium: number;
    public clauses: Clause;
    public terminationDate: string;
    public GP: string;
    public NO: string;
    public FI: string;
    public CL: string;
    public DD: string;
    public itemBenefits: Benefit;
    public financialInterest: FinancialInterest;
    public nomineeDetails: NomineeDetails;
    public PADriverDetails: PADriverDetails;
    public sumInsured: number = 0;
    public riskType: string;
    public rebatePercentage: number = 0;
    public rebateAmount: number = 0;
    public symRiskClassification: string = "";
    public riskClassificationReason: string = '';
    public insuredAge: number;
    public planAgeLimit: number;
    public occRiskClassification: string;
    public basePostedPremiumAdj: number = 0;
    public isPOIConsidered: string = "N";
    public priority: string;
    public childRiskPath: string;
    public childRiskIdentity: string = "itemNo";
    public riskClassificationReasons: ReferredReason;
    public gpText: string;
    constructor() {
        super();
        this.itemBenefits = new Benefit();
        this.financialInterest = new FinancialInterest();
        this.nomineeDetails = new NomineeDetails();
        this.PADriverDetails = new PADriverDetails();
        this.clauses = new Clause();
        this.riskClassificationReasons = new ReferredReason();
    }

    public getInstance(valObj: PADPAItemDetails) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
            this.itemBenefits = new Benefit().getInstance(valObj.itemBenefits);
            this.clauses = new Clause().getInstance(valObj.clauses);
            this.nomineeDetails = new NomineeDetails().getInstance(valObj.nomineeDetails);
            this.PADriverDetails = new PADriverDetails().getInstance(valObj.PADriverDetails);
            this.riskClassificationReasons = new ReferredReason().getInstance(valObj.riskClassificationReasons);
            if (valObj.FI == "Y") {
                this.financialInterest = new FinancialInterest().getInstance(valObj.financialInterest);
            }
        }
        return this;
    }

    public getNewInstanceByCriteria(criteria: any) {
        return this;
    }

    public getValidator() {
        return new DPAValidator(this);
    }
}

export class Benefit {
    public benefit: PANPAItem[] = [];

    public getInstance(valObj: Benefit) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().handleArray(this, valObj, "benefit");
        }
        return this;
    }
}

export class PADriverDetails {
    public vehicalRegNumber: string;
    public modelCode: string = "";
    public modelCodeNew: string = "";
    public makeCode: string;
    public description: string;
    public yearOfMake: string = "";
    constructor() { }

    public getInstance(valObj: PADriverDetails) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
        }
        return this;
    }
}