/*
 * Change History:
 * 
 * No      Date          Description                                   Changed By
 * ====    ==========    ===========                                   ==========
 * GA001   27/07/202017  MYS-2017-0484 :(DPA Product)To display the model  
 * 						 and description upon submitting to next level	 KGA
 * KA001   01/04/2019   MYS-2018-1145    -  MPD CoverNote                DKA		
 */
import { Component, OnInit, EventEmitter, AfterViewInit } from '@angular/core';
import { LOV_Field, LOVDropDownService, SearchFilter } from "../../../../../common/services/lovdropdown/lovdropdown.service";
import { PADPAItemDetails, Benefit, PADriverDetails } from './appobjects/dpa';
import { Clause } from "../appobjects/clause";
import { NomineeDetails } from "../appobjects/nomineeslist";
import { GetLOVData, SearchAdvancedConfig, Filter } from '../../../../../common/components/utility/search/search.requests';
import { CordysSoapWService } from "../../../../../common/components/utility/cordys-soap-ws";
import { ProposalHeader } from '../../proposalheader/appobjects/proposalheader';
import { ClientDetails } from '../../../../../common/components/client/appobjects/client';
import { AlertMessagesService } from '../../../../../common/components/utility/alertmessage/alertmessages.service';
import { AlertMessage } from '../../../../../common/components/utility/alertmessage/alertmessages.model';
import { BMSConstants } from '../../../common/constants/bms_constants';//KA001

declare var moment: any;
declare var jQuery: any;
declare var numeral: any;

@Component({
    selector: 'driverpa-risk-component',
    templateUrl: 'app/bms/components/proposal/newbusinessrisks/driverpa/driverparisk.template.html',
    inputs: ["riskObj", 'clientDetails', 'headerInfo'],
    outputs: ['onPremiumChange', 'onSIChange', 'onpostedpremiumchange', 'onRiskClsChange']
})
export class DriverPARiskComponent implements OnInit {
    private isCollapsedMode: boolean = false;
    private collapseDriverInfo: boolean = false;
    private collapseVehiclelInfo: boolean = true;
    private isNomineeInfoCollapsed: boolean = false;
    private isCoverInfoCollapsed: boolean = false;
    private collapseClausesInfo: boolean = false;
    private modelDesc: string = "";
    private DOBCtrl: any;

    public riskObj: PADPAItemDetails;
    public yearOfManfactureList: Object[] = [];
    public seatNumList: Object[] = [];
    public dpaSeatPremList: DPASeatPremInfo[] = [];
    public disableForm = 'N';
    public clientDetails: ClientDetails;
    public headerInfo: ProposalHeader;
    onPremiumChange = new EventEmitter<any>();
    onSIChange = new EventEmitter<any>();
    onpostedpremiumchange = new EventEmitter<any>();
    onRiskClsChange = new EventEmitter<any>();
    private isGeneralPageCollapsed: boolean = false;

    public minimumAge = 16;
    public caseInfo: any;//KA001

    constructor(private lovDropDownService: LOVDropDownService, private _soapService: CordysSoapWService, public _alertMsgService: AlertMessagesService) {

    }

    ngAfterViewInit() {
        this.setRiskClassification(this);
        this.setFormDisabled();
    }

    setFormDisabled() {
        if (jQuery("#bmsForm").prop("disabled") == true) {
            this.disableForm = "Y";
        }
    }

    ngOnInit() {
        this.correctDOB();
        this.populateLOVs();
        this.listForYearofManfacture(20);
        //this.initChilds();
        if (this.clientDetails)
            this.setClientInfo();
        if (this.riskObj.plan)
            this.populateSeatsLOV(this.riskObj.riskType + this.riskObj.plan);
        //GA001 START
        if (this.riskObj != null && this.riskObj.PADriverDetails != null && this.riskObj.PADriverDetails.makeCode != 'undefined'
            && this.riskObj.PADriverDetails.makeCode != null && this.riskObj.PADriverDetails.makeCode != "") {
            var makeObj = { "value": this.riskObj.PADriverDetails.makeCode, "description": this.riskObj.PADriverDetails.description }
            this.filterModel(makeObj);
            this.riskObj.PADriverDetails.description = makeObj.description;
        }
        //GA001 END
        this.caseInfo = BMSConstants.getBMSCaseInfo();	//KA001
    }

    correctDOB() {
        if (this.riskObj.dateOfBirth != null && this.riskObj.dateOfBirth == '99999999')
            this.riskObj.dateOfBirth = "";
        if (this.riskObj.dateOfBirth != null)
            this.setInsuredAge();
    }

    initChilds() {
        if (this.riskObj.itemBenefits.benefit == null)
            this.riskObj.itemBenefits = new Benefit();
        else if (!Array.prototype.isPrototypeOf(this.riskObj.itemBenefits.benefit)) {
            let temp: any = this.riskObj.itemBenefits.benefit;
            this.riskObj.itemBenefits.benefit = [temp];
        }

        if (this.riskObj.clauses != null && this.riskObj.clauses.clause != null && !Array.prototype.isPrototypeOf(this.riskObj.clauses.clause)) {
            let temp: any = this.riskObj.clauses.clause;
            this.riskObj.clauses.clause = [temp];
        }
        else if (this.riskObj.clauses == null || this.riskObj.clauses.clause == null) {
            this.riskObj.clauses = new Clause();
        }

        if (this.riskObj.nomineeDetails != null && this.riskObj.nomineeDetails.nominee != null && !Array.prototype.isPrototypeOf(this.riskObj.nomineeDetails.nominee)) {
            let temp: any = this.riskObj.nomineeDetails.nominee;
            this.riskObj.nomineeDetails.nominee = [temp];
        }
        else if (this.riskObj.nomineeDetails == null || this.riskObj.nomineeDetails.nominee == null) {
            this.riskObj.nomineeDetails = new NomineeDetails();
        }

        let temsPAD: any = this.riskObj.PADriverDetails;

        if (temsPAD == null || temsPAD == "") {
            this.riskObj.PADriverDetails = new PADriverDetails();
        }

        if (this.riskObj.PADriverDetails.makeCode != null && this.riskObj.PADriverDetails.makeCode != "")
            this.fillModel(this.riskObj.PADriverDetails.makeCode)
    }

    private populateLOVs(): void {

        this.lovDropDownService.createLOVDataList(["Occupation", "Saluatation", "make"]);

        let lovFields = [
            new LOV_Field("ALL", "MOTOR", "NEW BUSINESS", "ALL", "NEW", "NAMED_DRIVER", "Occupation", "LOV", [], "DESCPF", "Occupation", null),
            new LOV_Field("ALL", "CLIENT", "ALL", "ALL", "NEW", "CLIENT_DETAILS", "Salutation", "LOV", [], "DESCPF", "Saluation", null),
            new LOV_Field("ALL", "MOTOR", "NEW BUSINESS", "ALL", "NEW", "PRIVATE_MOTOR", "Make", "LOV", [], "DESCPF", "make", null),
        ];
        this.lovDropDownService.util_populateLOV(lovFields, this);
    }

    listForYearofManfacture(number) {
        var year = Number(new Date().getFullYear());
        for (var index = number; index > 0; --index) {
            this.yearOfManfactureList.push(year);
            year--;
        }
    }

    setClientInfo() {
        if (this.riskObj.occupationCode != undefined && this.riskObj.occupationCode != '' && this.clientDetails.client.personalClientDetails != null && this.riskObj.insuredPerson == this.clientDetails.client.personalClientDetails.Name)
            this.setOccDesc(this.riskObj.occupationCode);
    }

    setOccDesc(occupation) {
        if (occupation != undefined && occupation != "")
            this.riskObj.occupationDescription = occupation.description;
        let request: GetLOVData = new GetLOVData().getRequest('ALL', 'ALL', 'NEW BUSINESS', 'ALL', 'NEW', 'ALL', 'Occupation', 'LOV');
        request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        request.ADVANCE_CONFIG_XML.FILTERS = new Filter();

        request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({ "@FIELD_NAME": 'DESCITEM', "@FIELD_VALUE": this.riskObj.occupationCode, '@OPERATION': 'EQ', '@CONDITION': 'AND' });
        this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.occupationSuccessHandler, this.handleError, true, { comp: this });
    }

    occupationSuccessHandler(response, prms) {
        prms.comp.riskObj.occupationDescription = response.tuple.old.T3644.DESCRIPTION;
        prms.comp.riskObj.occRiskClassification = response.tuple.old.T3644.REFERREDRISK;
        prms.comp.checkReferredRisk(prms.comp);
    }

    checkReferredRisk(comp) {
        comp.setRiskClassification(comp);
    }

    setRiskClassification(comp) {
        comp.onRiskClsChange.emit(comp.riskObj.itemNo);
    }

    changeRiskClassification(event) {
        this.riskObj.riskClassification = event.target.value;
        this.onRiskClsChange.emit(this.riskObj.itemNo);
    }

    handleError(response, status, errorText, prms) {
        prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, response.responseJSON.faultstring.text, 5000));
    }

    setSeatPremium(event) {
        this.riskObj.seatNo = event.target.value;
        if (this.riskObj.plan != undefined && this.riskObj.plan != "") {
            this.calculateSeatPremium(this.riskObj.seatNo, this.dpaSeatPremList);
        }
        else {
            this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Please select plan before changing Seats Information.", 5000));
            this.riskObj.seatNo = 0;
            return;
        }
        if (this.riskObj.seatNo == 0) {
            this.riskObj.seatPremium = 0;
            this.setLoadAndPremium();
            this.onPremiumChange.emit("");
        }
    }

    populateSeatsLOV(value) {
        if (this.riskObj.plan != undefined && this.riskObj.plan != "") {
            let request: GetLOVData = new GetLOVData().getRequest('ALL', 'PA', 'NEW BUSINESS', 'ALL', 'NEW', 'DPA', 'Seat Premium', 'LOV');
            request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
            request.ADVANCE_CONFIG_XML.FILTERS = new Filter();

            request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push(
                { "@FIELD_NAME": 'DESCITEM', "@FIELD_VALUE": value, '@OPERATION': 'EQ', '@CONDITION': 'AND' },
                { "@FIELD_NAME": 'ITMFRM', "@FIELD_VALUE": moment(this.headerInfo.effectiveDate, "YYYY-MM-DD").format("YYYYMMDD"), '@OPERATION': 'LT', '@CONDITION': 'AND' },
                { "@FIELD_NAME": 'ITMTO', "@FIELD_VALUE": moment(this.headerInfo.effectiveDate, "YYYY-MM-DD").format("YYYYMMDD"), '@OPERATION': 'GT', '@CONDITION': 'AND' });
            this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.populateSeatsLOVSuccessHandler, this.handleError, true, { comp: this });
        }
    }

    populateSeatsLOVSuccessHandler(response, prms) {
        let ary = [];
        prms.comp.riskObj.seatPremium = 0;
        if (response.tuple != null && !Array.prototype.isPrototypeOf(response.tuple)) {
            ary = [response.tuple];
        }
        else if (response.tuple != null) {
            ary = response.tuple;
        }

        prms.comp.dpaSeatPremList = [];
        prms.comp.seatNumList = [];
        for (let item of ary) {
            let dpaSeatPrem: DPASeatPremInfo = {
                "PREM_PER_SEAT": item.old.T7277.PREM_PER_SEAT,
                "MIN_SEAT_ALLOWED": item.old.T7277.MIN_SEAT_ALLOWED,
                "MAX_SEAT_ALLOWED": item.old.T7277.MAX_SEAT_ALLOWED,
                "NOSEAT": item.old.T7277.NOSEAT,
                "TOTPRE": item.old.T7277.TOTPRE
            };
            prms.comp.dpaSeatPremList.push(dpaSeatPrem);
        }

        if (prms.comp.dpaSeatPremList != null && prms.comp.dpaSeatPremList.length > 0) {
            var index = prms.comp.dpaSeatPremList[0].MIN_SEAT_ALLOWED;
            while (Number(index) <= Number(prms.comp.dpaSeatPremList[0].MAX_SEAT_ALLOWED)) {
                prms.comp.seatNumList.push(index);
                index++;
            }
        }

        if (prms.comp.riskObj.seatNo)
            prms.comp.calculateSeatPremium(prms.comp.riskObj.seatNo, prms.comp.dpaSeatPremList);
    }

    calculateSeatPremium(seatNo, ary) {
        this.riskObj.seatPremium = 0;
        if (ary != null && ary.length > 0) {
            for (let item of ary) {
                if (this.riskObj.seatNo < Number(item.MIN_SEAT_ALLOWED) || this.riskObj.seatNo > Number(item.MAX_SEAT_ALLOWED)) {
                    this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Please provide Seats value between " + item.MIN_SEAT_ALLOWED + " and " + item.MAX_SEAT_ALLOWED, 1000));
                    this.riskObj.seatNo = 0;
                    return;
                }
                else {
                    if (this.riskObj.seatNo < Number(item.MAX_SEAT_ALLOWED) && Number(this.riskObj.seatNo) == Number(item.NOSEAT)) {
                        this.riskObj.seatPremium = numeral(item.TOTPRE).format('0.00');
                        this.riskObj.totalAnnualPremium = Number(this.riskObj.totalPremium) + Number(this.riskObj.seatPremium);
                    }
                }
            }

            if (this.riskObj.seatPremium != undefined && this.riskObj.seatPremium == Number(0)) {
                let item = ary[ary.length - 1];
                let total = 0;
                let diff = Number(this.riskObj.seatNo) - Number(item.NOSEAT);
                total = Number(item.TOTPRE) + Number(Number(item.PREM_PER_SEAT) * diff);
                this.riskObj.totalAnnualPremium = Number(this.riskObj.totalPremium) + Number(total);
                this.riskObj.seatPremium = numeral(total).format('0.00');
            }
            this.setLoadAndPremium();
            //this.setRebateAmount();
            this.onPremiumChange.emit("");
            //this.setPostingPremium();
        }
        else {
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Unable to fetch Seats Minimum and Maximum Allowed Information", 1000));
        }
    }

    onChangeNRIC(value) {
        if (value != null && value != "") {
            let isValidFormat = new RegExp("[0-9]{6}-[0-9]{2}-[0-9]{4}$").test(value);
            if (isValidFormat == false) {
                this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Invalid NRIC format. Correct format is YYMMDD-XX-XXXX.", 5000));
                this.riskObj.NRIC = "";
            }
            else {
                let givenDate = value.substr(0, 6);
                let thisYear = ("" + new Date().getFullYear());
                let finalDate = thisYear.substr(0, 2) + givenDate;

                if (Number(moment().format("YYMMDD")) < Number(givenDate)) {
                    let year = Number(thisYear.substr(0, 2)) - 1;
                    finalDate = year + givenDate;
                }
                else if (moment(finalDate, "YYYYMMDD").toDate() == "Invalid Date") {
                    finalDate = "";
                    this.riskObj.NRIC = "";
                    this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Invalid date in NRIC.", 5000));
                }

                if (this.DOBCtrl != null && finalDate != "")
                    this.DOBCtrl.setter(moment(finalDate, "YYYYMMDD").format("YYYY-MM-DD"), "YYYY-MM-DD", this.DOBCtrl.comp);
                else if (this.DOBCtrl != null && finalDate == "")
                    this.DOBCtrl.setter("EMPTY", "YYYY-MM-DD", this.DOBCtrl.comp);
            }
        }
    }

    validateDOB(value) {
        if (value != null && value != "") {
            let curDate = moment().format("YYYYMMDD");
            if (Number(curDate) < Number(moment(value, "YYYY-MM-DD").format("YYYYMMDD"))) {
                this.DOBCtrl.setter("EMPTY", "YYYY-MM-DD", this.DOBCtrl.comp);
                this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "DOB can not be future date.", 5000));
            }
        }
        this.checkReferredRisk(this);
    }

    checkAgeValidation(value) {
        this.riskObj.planAgeLimit = Number(value);
        this.checkReferredRisk(this);
    }

    setInsuredAge() {
        if (this.riskObj.dateOfBirth != null && this.riskObj.dateOfBirth != "") {
            let curDate = moment(new Date().toISOString(), "YYYY-MM-DD");
            let date = moment(this.riskObj.dateOfBirth, "YYYYMMDD").format("YYYY-MM-DD");
            this.riskObj.insuredAge = curDate.diff(date, 'year');
        }
        else
            this.riskObj.insuredAge = 0;
    }

    isItInAgeRange() {

        if (this.riskObj.planAgeLimit && (Number(this.riskObj.insuredAge) >= Number(this.minimumAge) && Number(this.riskObj.insuredAge) <= Number(this.riskObj.planAgeLimit))) {
            return true;
        }
        else {
            return false;
        }
    }

    validateYearManfacture(value) {
        if ((value == "" || isNaN(value) || value.length != 4))
            this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Please fill Valid Value for field Year Manfacture in YYYY", 5000));
    }

    filterModel(make) {
        this.fillModel(make.value);
        this.modelDesc = make.description;
        this.riskObj.PADriverDetails.description = "";
    }

    fillModel(makeCode) {
        this.lovDropDownService.createLOVDataList(["model"]);
        let filterDetails = [new SearchFilter("DESCITEM", makeCode + " ", "STARTSWITH", "AND")];
        let searchFilterNodes = this.lovDropDownService.createFilter(filterDetails);

        let lovFields = [new LOV_Field("ALL", "MOTOR", "NEW BUSINESS", "ALL", "NEW", "PRIVATE_MOTOR", "Model", "LOV", searchFilterNodes, "DESCPF", "model", null)];
        this.lovDropDownService.util_populateLOV(lovFields, this);
    }

    onChangeModel(event) {
        this.riskObj.PADriverDetails.modelCodeNew = event.target.selectedOptions[0].value;// SAF MYS-2018-0245
        let value = event.target.value;
        let selectedModel = this.lovDropDownService.lovDataList.model.filter((model) => model.VALUE == value);
        this.riskObj.PADriverDetails.modelCode = selectedModel[0].VALUE1;
        this.riskObj.PADriverDetails.modelCodeNew = selectedModel[0].VALUE;

        let textValue = event.target.selectedOptions[0].innerText;
        if (this.riskObj.PADriverDetails.description != "")
            this.riskObj.PADriverDetails.description = this.riskObj.PADriverDetails.description.substring(0, this.riskObj.PADriverDetails.description.indexOf(" ") + 1) + " " + textValue;
        else
            this.riskObj.PADriverDetails.description = this.modelDesc + " " + textValue;
    }

    setSI(siValue) {
        let si = parseFloat(siValue);
        this.riskObj.sumInsured = si;
        this.onSIChange.emit(si);
        this.riskObj.sumInsured = numeral(this.riskObj.sumInsured).format('0.00');
    }

    setTotalPremium(premium) {
        let totalPremium = numeral().unformat(premium);
        this.riskObj.totalPremium = totalPremium;
        this.riskObj.basicPremium = totalPremium;
        this.riskObj.totalAnnualPremium = totalPremium + numeral().unformat(this.riskObj.seatPremium);
        this.setLoadAndPremium();
        //this.setRebateAmount();
        //this.setDiscAmtAndPremium();
        this.onPremiumChange.emit("");
    }

    setLoadAndPremium() {
        let loadingPercent = 0;
        if (this.riskObj.loadingDiscountPercentage != undefined)
            loadingPercent = numeral().unformat(this.riskObj.loadingDiscountPercentage);

        let tempAmount = numeral().unformat(this.riskObj.totalPremium) + numeral().unformat(this.riskObj.seatPremium);
        this.riskObj.loadingDiscountAmount = Number(tempAmount * (loadingPercent / 100));
        this.riskObj.totalAnnualPremium = Number(this.riskObj.totalPremium) + Number(this.riskObj.loadingDiscountAmount) + Number(numeral().unformat(this.riskObj.seatPremium)) - Number(this.riskObj.rebateAmount);
        this.riskObj.loadingDiscountAmount = numeral(this.riskObj.loadingDiscountAmount).format('0.00');

        //this.setPostingPremium();
    }

    setRebateAmount() {
        let rebatePercent = 0;
        if (this.riskObj.rebatePercentage != undefined && Number(this.riskObj.rebatePercentage) <= 25) {
            rebatePercent = numeral().unformat(this.riskObj.rebatePercentage);
            let tempAmount = numeral().unformat(this.riskObj.totalPremium) + numeral().unformat(this.riskObj.loadingDiscountAmount) + numeral().unformat(this.riskObj.seatPremium);
            this.riskObj.rebateAmount = Number(tempAmount * (rebatePercent / 100));
            this.riskObj.totalAnnualPremium = Number(this.riskObj.totalPremium) + Number(this.riskObj.loadingDiscountAmount) + Number(numeral().unformat(this.riskObj.seatPremium)) - Number(this.riskObj.rebateAmount);
            this.riskObj.rebateAmount = numeral(this.riskObj.rebateAmount).format('0.00');
        }
        //this.setPostingPremium();
    }

    validateRebatePctg() {
        if (Number(this.riskObj.rebatePercentage) > 25) {
            this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Max. Allowed Value for Rebate is 25% only", 5000));
            this.riskObj.rebatePercentage = 0;
        }
    }

	/*setDiscAmtAndPremium() {
		if(this.riskObj.loadingDiscountAmount != undefined) {
			this.riskObj.loadingDiscountPercentage = undefined;
			this.riskObj.totalAnnualPremium = Number(this.riskObj.totalPremium) + Number(this.riskObj.loadingDiscountAmount);
			this.riskObj.loadingDiscountAmount = numeral(this.riskObj.loadingDiscountAmount).format('0.00');
		}
		else {
			this.riskObj.loadingDiscountPercentage = '';
		}

		this.setPostingPremium();
	}*/

    setPostingPremium() {
        this.riskObj.postingPremium = ((this.riskObj.totalAnnualPremium) / 365) * this.calcDays();
        this.riskObj.totalAnnualPremium = numeral(this.riskObj.totalAnnualPremium).format('0.00');
        this.riskObj.postingPremium = numeral(this.riskObj.postingPremium).format('0.00');
        this.onpostedpremiumchange.emit("");
    }

    calcDays() {
        let date1 = moment(this.riskObj.dateStart, "YYYY-MM-DD");
        let date2 = moment(this.riskObj.lastDateEnd, "YYYY-MM-DD");
        return date2.diff(date1, 'days') + 1;//added +1 to always include endDate for calculation
        //return Math.ceil(timeDiff / (1000 * 3600 * 24));
    }
}

export class DPASeatPremInfo {
    constructor(public PREM_PER_SEAT: string,
        public MIN_SEAT_ALLOWED: string,
        public MAX_SEAT_ALLOWED: string,
        public NOSEAT: string,
        public TOTPRE: string) { }
}