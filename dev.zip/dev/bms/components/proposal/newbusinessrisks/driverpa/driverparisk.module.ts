import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BasicUIModule } from '../../../../../common/components/utility/basicui.module';
import { NomineeModule } from '../uimodules/nominee.module';
import { CoverageModule } from '../uimodules/coverage.module';
import { ClausesModule } from '../uimodules/clauses.module';
import { GeneralPageModule } from '../uimodules/generalpage.module'; //VK004
import { DriverPARiskComponent } from './driverparisk.component';

@NgModule({
    imports: [CommonModule, FormsModule, ReactiveFormsModule, BasicUIModule,NomineeModule,CoverageModule,ClausesModule,GeneralPageModule],
    declarations: [DriverPARiskComponent],
    exports: [DriverPARiskComponent]
})
export class DriverPARiskModule { }