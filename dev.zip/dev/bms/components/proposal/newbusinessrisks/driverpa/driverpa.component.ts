/*
Change History	:

	No      Date          Description                                 Changed By
	====    ==========    ===========                                 ==========
	AL001   15/08/2017   MYS-2017-0371    -  Develop MPD               ALA		
    KA001   07/03/2019   MYS-2018-0360    -  MPD Renewal               DKA									   
*/
import { Component, OnInit, ElementRef, AfterViewInit, EventEmitter, ApplicationRef, ViewChild, ViewContainerRef } from '@angular/core';
import { DCLInput, CustomDCLService } from '../../../../../common/services/customdcl.service';
import { DriverPersonalAccident, PADPAItemDetails, PADPAItem } from './appObjects/dpa';
import { LOV_Field, LOVDropDownService, SearchFilter } from "../../../../../common/services/lovdropdown/lovdropdown.service";
declare var Observer: any;
import { ProposalHeader } from '../../proposalheader/appobjects/proposalheader';
import { ClientDetails } from '../../../../../common/components/client/appobjects/client';
import { RIService } from '../services/ri.service';
import { RiskClassificationService } from '../services/riskcls.service';
import { BMSUtilService } from "../../../../services/bms.util.service"; //SST code
import { BMSConstants } from '../../../common/constants/bms_constants';
import { ActivatedRoute } from '@angular/router';
import { PostedPrem } from '../../proposalheader/appobjects/postedprem'; //MYS-2018-0360 MPD Renewal- KA001

declare var jQuery: any;
declare var numeral: any;
declare var moment: any;

@Component({
    selector: 'driverpa-component',
    templateUrl: 'app/bms/components/proposal/newbusinessrisks/driverpa/driverpa.template.html',
    inputs: ['riskObj', 'clientDetails', 'headerInfo'],
    outputs: ["onPremiumChange", 'onRiskClsChange'],
    providers: [PostedPrem] // MYS-2018-0360 KA001
})
export class DriverPAComponent implements OnInit {
    public driverDetailList: any[] = [];
    public riskObj: DriverPersonalAccident;
    public clientDetails: ClientDetails;
    public headerInfo: ProposalHeader;
    public currentRiskObj: any;
    public currentRiskComponent: any;
    private el: HTMLElement;
    onPremiumChange = new EventEmitter<any>();
    onRiskClsChange = new EventEmitter<any>();
    public search: String = "";
    public position = 1;
    public sizeObj = { length: 0, orglength: 0 };
    public contentSizeObs: any;
    public itemPerPage = 5;
    public maxPageCount = 5;
    public disableForm = 'N';
    public disableAddInsured: boolean = false;//AL001
    private isGeneralPageCollapsed: boolean = false;

    public hideProgress: boolean = true;
    @ViewChild('dpaRiskArea', { read: ViewContainerRef }) contentArea: ViewContainerRef;

    constructor(public dcl: CustomDCLService, private lovDropDownService: LOVDropDownService, el: ElementRef, private appRef: ApplicationRef, private _rcls: RiskClassificationService, private _riService: RIService, private _bus: BMSUtilService, private _activatedRoute: ActivatedRoute, private _postedPremDetails: PostedPrem) {
        this.populateLovs();
        this.el = el.nativeElement;
    }

    ngAfterViewInit() {
        this.setFormDisabled();
    }

    setFormDisabled() {
        if (jQuery("#bmsForm").prop("disabled") == true) {
            this.disableForm = "Y";
        }
    }


    ngOnInit() {
        //AL001 START
        if (this.riskObj.riskType == "PAM") {
            if (this.riskObj.paDPAItems.paDPAItem.length == 0) {
                this.addRisk();
                this.riskObj.paDPAItems.paDPAItem[0].PADriverDetails.vehicalRegNumber = this.riskObj.vehicalRegNumber;
                this.riskObj.paDPAItems.paDPAItem[0].PADriverDetails.yearOfMake = this.riskObj.yearOfMake;
                this.riskObj.paDPAItems.paDPAItem[0].PADriverDetails.makeCode = this.riskObj.makeCode;
                this.riskObj.paDPAItems.paDPAItem[0].PADriverDetails.modelCode = this.riskObj.modelCode;
                this.riskObj.paDPAItems.paDPAItem[0].PADriverDetails.modelCodeNew = (this.riskObj.modelCodeNew != undefined || this.riskObj.modelCodeNew != "") ? this.riskObj.modelCodeNew : this.riskObj.modelCode; // SAF MYS-2018-0245
                this.riskObj.paDPAItems.paDPAItem[0].PADriverDetails.description = this.riskObj.description;
                this.riskObj.paDPAItems.paDPAItem[0].seatNo = this.riskObj.seatNo;

            }
            this.disableAddInsured = true;
        }
        //AL001 END

        //SST Code
        //if(this.riskObj.GST == 0 || this.riskObj.SST == 0) {
        if (["MyTasks", "MyDrafts"].indexOf(this._activatedRoute.snapshot.params['component']) >= 0 || Object.keys(this._activatedRoute.snapshot.params).length == 0) {
            let respObj = this._bus.getTAXDetails();
            if (respObj != undefined && respObj != "") {
                this.headerInfo.SSTTaxRate = Number(respObj[0].old.ITEMPF.GST);
                this.headerInfo.GSTTaxRate = Number(respObj[1].old.ITEMPF.GST);

                this.riskObj.SST = Number(this.headerInfo.SSTTaxRate);
                this.riskObj.GST = Number(this.headerInfo.GSTTaxRate);
            }

            this.headerInfo = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo;
            this.riskObj.SSTLiveDate = (this.riskObj.SSTLiveDate == undefined) ? this.headerInfo.SSTLiveDate : this.riskObj.SSTLiveDate;
            if (this.riskObj.SSTLiveDate == undefined || this.riskObj.SSTLiveDate == "") {
                let tempRespObj = this._bus.getLiveDate();
                this.riskObj.GSTLiveDate = tempRespObj[0].old.ITEMPF.LIVEDATE;
                this.riskObj.SSTLiveDate = tempRespObj[1].old.ITEMPF.LIVEDATE;
                if (this.headerInfo.SSTLiveDate == undefined || this.headerInfo.SSTLiveDate == "") {
                    this.headerInfo.SSTLiveDate = this.riskObj.SSTLiveDate;
                }
                if (this.headerInfo.GSTLiveDate == undefined || this.headerInfo.GSTLiveDate == "") {
                    this.headerInfo.GSTLiveDate = this.riskObj.GSTLiveDate;
                }
            }
            if (moment(this.headerInfo.effectiveDate, "YYYY-MM-DD").format("YYYYMMDD") >= moment(this.riskObj.SSTLiveDate, "YYYY-MM-DD").format("YYYYMMDD")) {
                this.riskObj.isGSTApplicable = false;
            } else {
                this.riskObj.isGSTApplicable = true;
            }
        }
        //End		
        let caseInfo = BMSConstants.getBMSObj().ApplicationBusinessObject.caseInfo; // MYS-2018-0360 MPD Renewal - KA001
        if (caseInfo.businessFunction == "Renewal" && this.headerInfo.contractType == "MPD") {
            this.riskObj.rebateAmount = this.riskObj.postedPremDetails != undefined ? this.riskObj.postedPremDetails.rebateAmount : this._postedPremDetails.rebateAmount;
            this.riskObj.sstAmount = this.riskObj.postedPremDetails != undefined ? this._postedPremDetails.getSSTAmount(this.riskObj, this.riskObj.postedPremDetails) : this._postedPremDetails.getSSTAmount(this.riskObj, this._postedPremDetails);
            this.riskObj.discountedPremium = this.riskObj.postedPremDetails != undefined ? this.riskObj.postedPremDetails.netPrem : this._postedPremDetails.netPrem;
            this.riskObj.paDPAItems.paDPAItem[0].PADriverDetails.modelCodeNew = this.riskObj.modelCode;
        }
    }

    checkSingleRecord() {
        if (this.riskObj.paDPAItems != null && this.riskObj.paDPAItems.paDPAItem != null) {
            if (!Array.prototype.isPrototypeOf(this.riskObj.paDPAItems.paDPAItem)) {
                let tempItem: any = this.riskObj.paDPAItems.paDPAItem;
                this.riskObj.paDPAItems.paDPAItem = [tempItem];
            }
        }
        else {
            this.riskObj.paDPAItems = new PADPAItem();
        }

    }

    addRisk() {
        if (this.clientDetails.client.genericDetails.clienttype == 'P' && !(this.riskObj.paDPAItems != null && this.riskObj.paDPAItems.paDPAItem != null && this.riskObj.paDPAItems.paDPAItem.length > 0))
            this.setClientInfo();
        else {
            let newDPA = new PADPAItemDetails();
            newDPA.itemNo = this.riskObj.paDPAItems.paDPAItem.length + 1;
            newDPA.dateStart = this.headerInfo.effectiveDate;
            newDPA.lastDateEnd = this.headerInfo.endDate;
            newDPA.riskType = this.riskObj.riskType;
            this.riskObj.paDPAItems.paDPAItem.push(newDPA);
        }
        //this._rcls.setRiskClassification(this.riskObj.riskNumber,"N","").subscribe();
    }

    selectRisk(risk) {
        this.removeRiskContent();
        if (risk != null) {
            //AL001 START
            if (this.riskObj.riskType == "PAM") {
                risk.PADriverDetails.vehicalRegNumber = this.riskObj.vehicalRegNumber;
                risk.PADriverDetails.yearOfMake = this.riskObj.yearOfMake;
                risk.PADriverDetails.makeCode = this.riskObj.makeCode;
                risk.PADriverDetails.modelCode = this.riskObj.modelCode;
                risk.PADriverDetails.description = this.riskObj.description;
                risk.seatNo = this.riskObj.seatNo;
            }
            //AL001 END
            let idx = this.riskObj.paDPAItems.paDPAItem.indexOf(risk);
            this.currentRiskObj = risk;
            this.loadComponent(["DriverPARiskComponent", "app/bms/components/proposal/newbusinessrisks/driverpa/driverparisk.module", "DriverPARiskModule"], null);
        }
    }

    removeRisk(risk) {
        if (this.currentRiskObj != null && this.currentRiskObj.itemNo == risk.itemNo) {
            this.removeRiskContent();
            this.currentRiskObj = null;
        }
        this.riskObj.paDPAItems.paDPAItem.splice(this.riskObj.paDPAItems.paDPAItem.indexOf(risk), 1);
        this.resetItmNumber();
        this.setTotalPremium();
        this.setTotalSI();
        this._rcls.setRiskClassification(this.riskObj.riskNumber, "N", "", "").subscribe();
    }

    resetItmNumber() {
        for (let risk of this.riskObj.paDPAItems.paDPAItem) {
            let index = this.riskObj.paDPAItems.paDPAItem.indexOf(risk);
            risk.itemNo = (index + 1);
        }
    }

    populateLovs() {
        this.lovDropDownService.createLOVDataList(["RIRetentionCode"]);

        let riTypeFilterDetails = [new SearchFilter("DESCITEM", "PA", "STARTSWITH", "AND")];
        let riTypeSearchFilterNodes = this.lovDropDownService.createFilter(riTypeFilterDetails);

        let lovFields = [
            new LOV_Field("ALL", "MOTOR", "NEW BUSINESS", "ALL", "NEW", "PRIVATE_MOTOR", "RI Retention Code", "LOV", riTypeSearchFilterNodes, "DESCPF", "RIRetentionCode", null)
        ];
        this.lovDropDownService.util_populateLOV(lovFields, this);
    }

    getTotalByProperty(prop, ary) {
        let total = numeral(0);
        for (let eachItem of ary) {
            if (eachItem[prop] != null && eachItem[prop] != "")
                total = total.add(numeral().unformat(eachItem[prop]));
        }
        total = numeral(total).format('0.00');
        return total;
    }

    setClientInfo() {
        let newDPA = new PADPAItemDetails();
        if (this.clientDetails.client.personalClientDetails) {
            newDPA.insuredPerson = this.clientDetails.client.personalClientDetails.Name;
            newDPA.insuredSalutation = this.clientDetails.client.personalClientDetails.saluation;
            newDPA.NRIC = this.clientDetails.client.personalClientDetails.NRICNo;
            newDPA.IdProofNo = this.clientDetails.client.personalClientDetails.IdNumber;
            newDPA.dateOfBirth = this.clientDetails.client.personalClientDetails.dateOfBirth;
            newDPA.maritalStatus = this.clientDetails.client.personalClientDetails.maritalStatus;
            newDPA.gender = this.clientDetails.client.personalClientDetails.gender;
            newDPA.occupationCode = this.clientDetails.client.personalClientDetails.occupationCode;
            newDPA.occupationDescription = this.clientDetails.client.personalClientDetails.occupationDescription;
            newDPA.terminationDate = this.clientDetails.client.personalClientDetails.terminationDate;
            newDPA.itemNo = this.riskObj.paDPAItems.paDPAItem.length + 1;
            newDPA.dateStart = this.headerInfo.effectiveDate;
            newDPA.lastDateEnd = this.headerInfo.endDate;
            newDPA.riskType = this.riskObj.riskType;
            this.riskObj.paDPAItems.paDPAItem.push(newDPA);
        }
    }

    setReferredRisk(itemNo) {
		/*this.riskObj.riskClassification = '`';
		if(this.riskObj.paDPAItems != null && this.riskObj.paDPAItems.paDPAItem != null && this.riskObj.paDPAItems.paDPAItem.length > 0) {
			for(let driver of this.riskObj.paDPAItems.paDPAItem)
			{
				if(driver.riskClassification == 'Referred') {
					this.riskObj.riskClassification = 'Referred';
					break;
				}
			}
		}*/
        this._rcls.setRiskClassification(this.riskObj.riskNumber, "N", itemNo, "").subscribe();
        //this.onRiskClsChange.emit('');
    }

    setTotalPremium() {
        this.riskObj.originalTotalPremium = this.getTotalByProperty("totalAnnualPremium", this.riskObj.paDPAItems.paDPAItem);
        this.riskObj.rebate = this.headerInfo.rebate;
        this.riskObj.rebateAmount = Number(numeral().unformat(this.riskObj.originalTotalPremium) / 100 * numeral().unformat(this.riskObj.rebate));
        this.riskObj.discountedPremium = numeral().unformat(this.riskObj.originalTotalPremium) - numeral().unformat(this.riskObj.rebateAmount);
        //SST Code
        //this.riskObj.gstAmount = 0;//Number(this.riskObj.discountedPremium / 100 * 6); //SAF MYS-2018-0629
        let tempGSTAmount = numeral(numeral((this.riskObj.discountedPremium * Number(this.riskObj.GST)) / 100).format("0,00.00")).value();
        this.riskObj.gstAmount = (tempGSTAmount > 0) ? numeral(numeral(BMSUtilService.calculatePremiumAmount(tempGSTAmount, "G")).format("0,00.00")).value() : 0;

        let tempSSTAmount = numeral(numeral((this.riskObj.discountedPremium * Number(this.riskObj.SST)) / 100).format("0,00.00")).value();
        this.riskObj.sstAmount = (tempSSTAmount > 0) ? numeral(numeral(BMSUtilService.calculatePremiumAmount(tempSSTAmount, "S")).format("0,00.00")).value() : 0;

        //this.riskObj.totalPremium = numeral().unformat(this.riskObj.discountedPremium) + numeral().unformat(this.riskObj.gstAmount);
        this.riskObj.totalPremium = numeral().unformat(this.riskObj.discountedPremium) + numeral().unformat(this.riskObj.gstAmount) + numeral().unformat(this.riskObj.sstAmount);

        this.riskObj.sstAmount = numeral(this.riskObj.sstAmount).format('0.00');//End
        this.riskObj.gstAmount = numeral(this.riskObj.gstAmount).format('0.00');
        this.riskObj.totalPremium = numeral(this.riskObj.totalPremium).format('0.00');
        this.onPremiumChange.emit(this.riskObj.totalPremium);
    }

    setTotalSI() {
        this.riskObj.capitalSumInsured = this.getTotalByProperty("sumInsured", this.riskObj.paDPAItems.paDPAItem);
        this.setBigSI();
    }

    setBigSI() {
        let bigSI = 0;
        for (let eachItem of this.riskObj.paDPAItems.paDPAItem) {
            if (eachItem.sumInsured != null && "" + eachItem.sumInsured != "") {
                bigSI = (parseFloat("" + eachItem.sumInsured) > bigSI) ? parseFloat("" + eachItem.sumInsured) : bigSI;
            }
        }
        this.riskObj.bigCapitalSumInsured = bigSI;
    }

    setTotalPP() {
        this.riskObj.postingPremium = this.getTotalByProperty("postingPremium", this.riskObj.paDPAItems.paDPAItem);
    }

    setRIMethod(value) {
        this.riskObj.RIMethod = (value == "Yes") ? "8" : "1";
        this._riService.setRI().subscribe();
    }

    loadComponent(component, prms) {
        this.hideProgress = false;
        let dclInp = new DCLInput();
        dclInp.component = component;
        dclInp.viewContainerRef = this.contentArea;
        dclInp.inputs = { riskObj: this.currentRiskObj, headerInfo: this.headerInfo, clientDetails: this.clientDetails };
        dclInp.callback = this.setOutputHandle;
        dclInp.prms = { comp: this, prms: prms };
        this.dcl.loadComponent(dclInp);
    }

    setOutputHandle(newComp, prms) {
        prms.prms.comp.currentRiskComponent = newComp;
        prms.prms.comp.hideProgress = true;
        let instance: any = newComp.instance;
        if (instance.onPremiumChange != null) {
            instance.onPremiumChange.subscribe(() => {
                prms.prms.comp.setTotalPremium();
            });
        }
        if (instance.onSIChange != null) {
            instance.onSIChange.subscribe(() => {
                prms.prms.comp.setTotalSI();
            });
        }
        if (instance.onRiskClsChange != null) {
            instance.onRiskClsChange.subscribe((data) => {
                prms.prms.comp.setReferredRisk(data);
            });
        }
        if (instance.prms != null) {
            instance.prms = prms.prms.prms;
        }
    }

    removeRiskContent() {
        if (this.currentRiskComponent != null)
            this.dcl.unloadComponent(this.currentRiskComponent);
    }
}