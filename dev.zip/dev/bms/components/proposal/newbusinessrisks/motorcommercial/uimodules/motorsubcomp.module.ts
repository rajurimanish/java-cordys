import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BasicUIModule } from '../../../../../../common/components/utility/basicui.module';

import { NamedDriversComponent } from './nameddrivers.component';
import { PIAMStatisticsComponent } from './piamStatistics.component';

@NgModule({
    imports: [CommonModule, FormsModule, ReactiveFormsModule, BasicUIModule],
    declarations: [PIAMStatisticsComponent, NamedDriversComponent],
    exports: [PIAMStatisticsComponent, NamedDriversComponent]
})
export class MotorSubCompModule { }