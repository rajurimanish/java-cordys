/*
Change History	:

	No      Date          Description                                 Changed By
	====    ==========    ===========                                 ==========
    AL001   15/08/2017   MYS-2017-0371    -  Develop MPD               ALA
    GA001   11/09/2019    MYS-2019-0974 - BMS Enhancement on High Risk Vehicle & Client       KGA										   
*/
import { Component, OnInit, EventEmitter, ViewChild, ViewContainerRef } from '@angular/core';
import { NamedDriver, NamedDriverItem } from '../appobjects/nameddriver';
import { MotorItems } from '../../appobjects/motorItems';
import { DCLInput, CustomDCLService } from '../../../../../../common/services/customdcl.service';
import { LOV_Field, LOVDropDownService, SearchFilter } from "../../../../../../common/services/lovdropdown/lovdropdown.service";
import { ClientDetails } from '../../../../../../common/components/client/appobjects/client';
import { AlertMessagesService } from '../../../../../../common/components/utility/alertmessage/alertmessages.service';
import { AlertMessage } from '../../../../../../common/components/utility/alertmessage/alertmessages.model';
import { ModalInput } from "../../../../../../common/components/utility/modal/modal";
//GA001 START
import { CordysSoapWService } from "../../../../../../common/components/utility/cordys-soap-ws";
import { HighRiskIndReason } from '../../../proposalheader/appobjects/proposalheader';
import { BMSConstants } from '../../../../common/constants/bms_constants';
//GA001 END


declare var moment: any;//GA001

@Component({
    selector: 'nameddrivers-component',
    templateUrl: 'app/bms/components/proposal/newbusinessrisks/motorcommercial/uimodules/nameddrivers.template.html',
    inputs: ["_nameddriver", 'clientDetails', 'riskType', 'benefits', 'cover', 'insuredIsDriver', 'disableForm',"riskObj"], //GA001 - added riskObj
    outputs: ['onaddlprmchange', 'ondefault']
})

export class NamedDriversComponent implements OnInit {

    private isCollapsedMode: boolean = false;
    public effectiveDate: string;
    public attachedDate: string;
    public _nameddriver: NamedDriver;
    public benefits: MotorItems;
    public riskType: string;
    public cover: string;
    public insuredIsDriver: string;
    public clientDetails: ClientDetails;
    onaddlprmchange = new EventEmitter<any>();
    ondefault = new EventEmitter<any>();
    private disableForm: boolean = false;
    public riskObj: any;//GA001 - added riskObj

    @ViewChild('namedDriverModal', { read: ViewContainerRef }) contentArea: ViewContainerRef;

    constructor(public dcl: CustomDCLService, private lovDropDownService: LOVDropDownService, public _alertMsgService: AlertMessagesService,private _cordysService: CordysSoapWService) { }

    ngOnInit(): any {
        this.populateLOVs();
        /*if(this._nameddriver.driverDetail != undefined && !(this._nameddriver.driverDetail.constructor === Array)) {
           let driverItems:any = this._nameddriver.driverDetail;
           this._nameddriver.driverDetail = [driverItems];
       }*/
        if (this.clientDetails.client.genericDetails.clienttype == "P" && this._nameddriver.driverDetail != undefined && this._nameddriver.driverDetail.length == 0)
            this.setDriverInfo();
    }

    openDriverDetailDialog() {
        let lookup = new ModalInput();
        lookup.component = ["DriverDetailsDialogComponent", "app/bms/components/proposal/newbusinessrisks/motorcommercial/dialogs/driverDetailDialog.module", "DriverDetailsDialogModule"];
        lookup.outputCallback = this.addDriver;
        lookup.datainput = { isNew: true, driverList: this._nameddriver, clientInfo: this.clientDetails, insuredIsDriver: this.insuredIsDriver };
        lookup.parentCompPRMS = { comp: this };
        lookup.heading = "Named Driver Details";
        lookup.icon = "fa fa-user";
        lookup.containerRef = this.contentArea;

        let ANYbenefitcode: boolean = this.checkBenefitCode(this.benefits.motorItem);

        if ((this.riskType == 'MPC' || this.riskType == 'MPF' || this.riskType == 'MPD') && this.cover == 'CO' && this.clientDetails.client.genericDetails.clienttype == 'C') { //AL001
            if (!ANYbenefitcode) {
                if (this._nameddriver.driverDetail.length >= 2) {
                    this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Atleast one Named Driver must be added and maximum 2 are allowed for the Risk.", 5000));
                    return;
                }
                else
                    this.dcl.openLookup(lookup);
            }
            else
                this.dcl.openLookup(lookup);
        }
        else
            this.dcl.openLookup(lookup);
    }

    checkBenefitCode(ary) {
        for (let eachMotorItem of ary) {
            if (eachMotorItem.code == "ANY") {
                return true;
            }
        }
        return false;
    }

    viewDriverDetailDialog(idx: number) {
        let lookup = new ModalInput();
        lookup.component = ["DriverDetailsDialogComponent", "app/bms/components/proposal/newbusinessrisks/motorcommercial/dialogs/driverDetailDialog.module", "DriverDetailsDialogModule"];
        let selectedDriver = this._nameddriver.driverDetail[idx];
        let isClientView: boolean = false;
        if (this.clientDetails.client.personalClientDetails && selectedDriver.driverName == this.clientDetails.client.personalClientDetails.Name)
            isClientView = true;
        lookup.datainput = { isView: true, selectedDriver, isClientView, disableForm: this.disableForm, driverList: this._nameddriver, editItem: idx, clientInfo: this.clientDetails, insuredIsDriver: this.insuredIsDriver };
        lookup.outputCallback = this.updateDriver;
        lookup.parentCompPRMS = { comp: this };
        lookup.heading = "Named Driver Details";
        lookup.icon = "fa fa-user";
        lookup.containerRef = this.contentArea;
        this.dcl.openLookup(lookup);
    }

    private updateDriver(returnPrms, prms) {
        //GA001 START
        let headerInfo = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo;
        if (headerInfo.isHighRiskApplicable) {
            let OldDriver = prms.comp._nameddriver.driverDetail[returnPrms.editItem];
            prms.comp.removeHighRiskValidation(prms.comp,OldDriver,prms.comp.riskObj);
            let headerInfo = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo;
            let effectiveDate = "";
            let endDate = "";
            if( headerInfo.effectiveDate!=undefined && headerInfo.effectiveDate!=""
                && moment(headerInfo.effectiveDate).format("YYYYMMDD") != "Invalid date"){
                effectiveDate = moment(headerInfo.effectiveDate).format("YYYYMMDD")
            }
            if( headerInfo.endDate!=undefined && headerInfo.endDate!=""
                && moment(headerInfo.endDate).format("YYYYMMDD") != "Invalid date"){
                endDate = moment(headerInfo.endDate).format("YYYYMMDD")
            }
            prms.comp.checkHighRiskClient(returnPrms.driver,effectiveDate,endDate,prms,"edit",returnPrms.editItem);
        }else{
            prms.comp._nameddriver.driverDetail[returnPrms.editItem] = returnPrms.driver;
        }
        //GA001 END
        //prms.comp._nameddriver.driverDetail[returnPrms.editItem] = returnPrms.driver;
    }

    removeDriver(idx: number) {
        if (this._nameddriver.driverDetail[idx].relationship != "00") {
            //GA002 START
            let headerInfo = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo;
            if (headerInfo.isHighRiskApplicable) {
                this.removeHighRiskValidation(this,this._nameddriver.driverDetail[idx],this.riskObj);
            }
            //GA002 END
            this._nameddriver.driverDetail.splice(idx, 1);
            if (this._nameddriver.driverDetail.length > 1) {
                this._nameddriver.additionalPremium = Number(this._nameddriver.additionalPremium) - Number(10);
                this.onaddlprmchange.emit(this._nameddriver.additionalPremium);
            }
        }
        else {
            if (this.clientDetails.client.personalClientDetails && this._nameddriver.driverDetail[idx].driverName == this.clientDetails.client.personalClientDetails.Name && idx == 0) {
                this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Cannot remove THE INSURED Driver Details", 5000));
            }
            else {
                //GA002 START
                let headerInfo = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo;
                if (headerInfo.isHighRiskApplicable) {
                    this.removeHighRiskValidation(this,this._nameddriver.driverDetail[idx],this.riskObj);
                }
                //GA002 END
                this._nameddriver.driverDetail.splice(idx, 1);
                if (this._nameddriver.driverDetail.length > 1) {
                    this._nameddriver.additionalPremium = Number(this._nameddriver.additionalPremium) - Number(10);
                    this.onaddlprmchange.emit(this._nameddriver.additionalPremium);
                }
            }
        }
    }

    addDriver(driver, prms) {
        //SAF MYS-2018-0737 -- start
        let tempDriverList: any = prms.comp.copy(prms.comp._nameddriver.driverDetail);
        //let tempDriverList:any = prms.comp._nameddriver.driverDetail;
        tempDriverList.push(driver);
        if (tempDriverList.length > 2) {
            let benfitCodeExists = prms.comp.benefits.motorItem.some(function (el) {
                return el.code === 'M011';
            });
            if (benfitCodeExists) {
                prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "More than 2 Named Drivers can't be added if Benefit Code  'M011' exists in the risk.", 10000));
                return;
            }
        } else {
            let benfitCodeExists = prms.comp.benefits.motorItem.some(function (el) {
                return el.code === 'M012';
            });

            if (benfitCodeExists) {
                prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Named Drivers can't be added if Benefit Code : 'M012' exists in the risk.", 10000));
                return;
            }
        }
        //End
        //GA002 START
        let headerInfo = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo;
        if (headerInfo.isHighRiskApplicable) {
            let effectiveDate = "";
            let endDate = "";
            if( headerInfo.effectiveDate!=undefined && headerInfo.effectiveDate!=""
                && moment(headerInfo.effectiveDate).format("YYYYMMDD") != "Invalid date"){
                effectiveDate = moment(headerInfo.effectiveDate).format("YYYYMMDD")
            }
            if( headerInfo.endDate!=undefined && headerInfo.endDate!=""
                && moment(headerInfo.endDate).format("YYYYMMDD") != "Invalid date"){
                endDate = moment(headerInfo.endDate).format("YYYYMMDD")
            }
            prms.comp.checkHighRiskClient(driver,effectiveDate,endDate,prms,"add",-1);
        }else{
            prms.comp._nameddriver.driverDetail.push(driver);
            if (prms.comp._nameddriver.driverDetail.length > 2) {
                prms.comp._nameddriver.additionalPremium = Number(prms.comp._nameddriver.additionalPremium) + Number(10);
                prms.comp.onaddlprmchange.emit(prms.comp._nameddriver.additionalPremium);
            }
        }
       //GA002 END

       /*
        prms.comp._nameddriver.driverDetail.push(driver);
        if (prms.comp._nameddriver.driverDetail.length > 2) {
            prms.comp._nameddriver.additionalPremium = Number(prms.comp._nameddriver.additionalPremium) + Number(10);
            prms.comp.onaddlprmchange.emit(prms.comp._nameddriver.additionalPremium);
        }
        */
    }

    setDriverInfo() {
        if (this.clientDetails.client.clientNumber || this.clientDetails.client.itemNo) {
            let driverItem: NamedDriverItem = new NamedDriverItem();
            if (this.clientDetails.client.personalClientDetails) {
                driverItem.driverName = this.clientDetails.client.personalClientDetails.Name;
                if (this.clientDetails.client.personalClientDetails.NRICNo)
                    driverItem.ICNumber = this.clientDetails.client.personalClientDetails.NRICNo;
                else if (this.clientDetails.client.personalClientDetails.IdNumber)
                    driverItem.ICNumber = this.clientDetails.client.personalClientDetails.IdNumber;
                let dob = this.clientDetails.client.personalClientDetails.dateOfBirth;
                if (dob != '99999999' || dob != ("" + '00000000')) {
                    if (dob != null && dob != "" && dob.indexOf("-") == -1)
                        driverItem.dateOfBirth = dob.substring(0, 4) + "-" + dob.substring(4, 6) + "-" + dob.substring(6, 8);
                    else
                        driverItem.dateOfBirth = dob;
                }
                driverItem.sex = this.clientDetails.client.personalClientDetails.gender;
                driverItem.occupation = this.clientDetails.client.personalClientDetails.occupationCode;
                //Need to have Implemnetation for Driving License, Sex and Occupation. Currently Client module is not setting those values
                driverItem.relationship = "00";
                if (this._nameddriver.driverDetail.length > 0) {
                    var index = 0;
                    for (let driver of this._nameddriver.driverDetail) {
                        if (driver.relationship == "00") {
                            this._nameddriver.driverDetail.splice(index, 1);
                            this._nameddriver.driverDetail.push(driverItem);
                            this.ondefault.emit("");
                            break;
                        }
                        index++;
                    }
                    this._nameddriver.driverDetail.splice(0, 0, driverItem);
                }
                else {
                    this._nameddriver.driverDetail.push(driverItem);
                    this.ondefault.emit("");
                }
            }
        }
    }

    private populateLOVs(): void {
        this.lovDropDownService.createLOVDataList(["Relationship", "Sex", "Occupation"]);
        let lovFields = [
            new LOV_Field("ALL", "MOTOR", "NEW BUSINESS", "ALL", "NEW", "NAMED_DRIVER", "Relationship", "LOV", [], "DESCPF", "Relationship", null)];
        this.lovDropDownService.util_populateLOV(lovFields, this);
    }

    //SAF MYS-2018-0737 -- start
    private copy(o) {
        let out, v, key;
        out = Array.isArray(o) ? [] : {};
        for (key in o) {
            v = o[key];
            out[key] = (typeof v === "object") ? this.copy(v) : v;
        }
        return out;
    } //End

    //GA001 START
    checkHighRiskClient(driver,effectiveDate,endDate,prms,operation,index) {
        let riskNumber:number = 0;
        let clientIDNo = "";

        if(prms.comp.riskObj!=undefined && prms.comp.riskObj.riskNumber!=""){
            riskNumber = prms.comp.riskObj.riskNumber;
        }
        if(driver.ICNumber!=undefined && driver.ICNumber!=""){
            clientIDNo = driver.ICNumber;
        }
        if(clientIDNo!="" && clientIDNo!=undefined){//ICNumber
            prms.comp._cordysService.callCordysSoapService("CheckHighRiskForInternalClient", "http://schemas.cordys.com/bmsintegrationapp", { 
                "CLIENTIDNO": clientIDNo, "EFFECTIVEDATE": effectiveDate, "ENDDATE": endDate }, prms.comp.highRiskDriverInternalICPasHandler, prms.comp.handleError, true, { comp: prms.comp,driver:driver,effectiveDate:effectiveDate,endDate:endDate,operation:operation,index:index });
        }else{
            let item_key = "DRIVER_ICPASSPORT_INTERNAL_CLIENT"+clientIDNo;
            let removeIndex = -1;
            let headerInfo = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo;
            if(headerInfo.highRiskIndicatorReasons!=undefined && headerInfo.highRiskIndicatorReasons.highRiskIndReason.length>0 ){
                //ICNumber Remove
                removeIndex = prms.comp.findIndexByRiskItemKey( headerInfo.highRiskIndicatorReasons.highRiskIndReason, riskNumber, item_key );
                if(removeIndex>=0){
                    headerInfo.highRiskIndicatorReasons.highRiskIndReason.splice(removeIndex, 1);
                }
            }
            headerInfo.highRiskDriverInternalInd = 'N';
        }
    }
    highRiskDriverInternalICPasHandler(response, prms) {
        let riskNumber:number = 0;
        let clientIDNo = "";
        let ind = "";
        let reason = "";
        let reasonA = "";
        let item_key = "";
        let item = "";
        if(prms.driver.ICNumber!=undefined && prms.driver.ICNumber!=""){
            clientIDNo = prms.driver.ICNumber;
        }
        if(prms.comp.riskObj!=undefined && prms.comp.riskObj.riskNumber!=""){
            riskNumber = prms.comp.riskObj.riskNumber;
        }
        if(response.tuple != null && response.tuple.old != null && response.tuple.old.checkHighRiskForInternalClient
            && response.tuple.old.checkHighRiskForInternalClient.checkHighRiskForInternalClient!=null 
            && response.tuple.old.checkHighRiskForInternalClient.checkHighRiskForInternalClient!=""
            && response.tuple.old.checkHighRiskForInternalClient.checkHighRiskForInternalClient!=""){
                ind = response.tuple.old.checkHighRiskForInternalClient.checkHighRiskForInternalClient.substring(0,1);
                reasonA = response.tuple.old.checkHighRiskForInternalClient.checkHighRiskForInternalClient.substring(1);  
        }
        if ( ind != null && ind == 'B' ) {
            reason = "Internal Nominee "+ prms.driver.driverName +" with NRIC/Passport No ("+ prms.driver.ICNumber +") is High Risk Indicator with Block";
            prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, reason, -1));
            return;
        }else{
            if ( ind != null && ind == 'A' ){
                item_key = "DRIVER_ICPASSPORT_INTERNAL_CLIENT"+clientIDNo;
                item = "DRIVER NRIC/Passport No INTERNAL CLIENT - "+prms.driver.driverName;
                let removeIndex = -1;
                let headerInfo = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo;
                if(headerInfo.highRiskIndicatorReasons!=undefined && headerInfo.highRiskIndicatorReasons.highRiskIndReason.length>0 ){
                    //ICNumber Remove
                    removeIndex = prms.comp.findIndexByRiskItemKey( headerInfo.highRiskIndicatorReasons.highRiskIndReason, riskNumber, item_key );
                    if(removeIndex>=0){
                        headerInfo.highRiskIndicatorReasons.highRiskIndReason.splice(removeIndex, 1);
                    }
                }
                let highRiskIndReason:HighRiskIndReason = new HighRiskIndReason();
                if(prms.comp.riskObj!=undefined && prms.comp.riskObj.riskNumber!=undefined){
                    highRiskIndReason.riskNumber = Number(prms.comp.riskObj.riskNumber);
                }else{
                    highRiskIndReason.riskNumber = 1;
                }
                highRiskIndReason.item_key = item_key;
                highRiskIndReason.item = item;
                highRiskIndReason.reason = reasonA;
                highRiskIndReason.ind = ind;
                            
                headerInfo.highRiskIndicator = "true";
                headerInfo.highRiskIndicatorUI = true;
                headerInfo.highRiskDriverInternalInd = ind;
                headerInfo.highRiskIndicatorReasons.highRiskIndReason.push( highRiskIndReason );
                prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, item + " : " + reasonA + " with Alert", -1));
            }
            if(prms.operation=="edit"){
                prms.comp._nameddriver.driverDetail[prms.index] = prms.driver;
            }else{
                prms.comp._nameddriver.driverDetail.push(prms.driver);
                if (prms.comp._nameddriver.driverDetail.length > 2) {
                    prms.comp._nameddriver.additionalPremium = Number(prms.comp._nameddriver.additionalPremium) + Number(10);
                    prms.comp.onaddlprmchange.emit(prms.comp._nameddriver.additionalPremium);
                }
            }
        }
    }
    handleError(response, status, errorText, prms) {
        prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, response.responseJSON.faultstring.text, -1));
    }
    removeHighRiskValidation(thisObj,driver,riskObj){
        let riskNumber:number = 0;
        let clientIDNo = "";
        let item_key = "";
        let removeIndex = -1;
        
        if(riskObj!=undefined && riskObj.riskNumber!=""){
            riskNumber = riskObj.riskNumber;
        }
        if(driver!=undefined && driver.ICNumber!=undefined && driver.ICNumber!=""){
            clientIDNo = driver.ICNumber;
        }
        item_key = "DRIVER_ICPASSPORT_INTERNAL_CLIENT"+clientIDNo;
        let headerInfo = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo;
        if(headerInfo.highRiskIndicatorReasons!=undefined && headerInfo.highRiskIndicatorReasons.highRiskIndReason.length>0 ){
            //ICNumber Remove
            removeIndex = thisObj.findIndexByRiskItemKey( headerInfo.highRiskIndicatorReasons.highRiskIndReason, riskNumber, item_key );
            if(removeIndex>=0){
                headerInfo.highRiskIndicatorReasons.highRiskIndReason.splice(removeIndex, 1);
            }
        }
        if(!(headerInfo.highRiskIndicatorReasons!=undefined && headerInfo.highRiskIndicatorReasons.highRiskIndReason.length>0) ){
            headerInfo.highRiskIndicator = "false";
            headerInfo.highRiskIndicatorUI = false;
            headerInfo.highRiskDriverInternalInd = "";
        }
    }
    public findIndexByRiskItemKey( highRiskIndReason,riskNumber, item_key ) {
        let indexVal: number = -1;
        highRiskIndReason.forEach( function ( elem, i ) {
            if ( elem.riskNumber == riskNumber && elem.item_key == item_key ) {
                indexVal = i;
                return indexVal;
            }             
        } );
        return indexVal;
    }
    //GA001 END
}