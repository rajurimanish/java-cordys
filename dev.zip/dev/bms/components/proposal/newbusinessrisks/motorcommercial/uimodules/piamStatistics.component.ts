/*
 * Change History	:
 *
 * 	No      Date         Description                                 			Changed By
 *	====    ==========   ===========                                 			==========

 *	KA001   11/12/2018  MYS-2018-1189 - Only allow numeric input 			  	DKA   
*/
import { Component, OnInit, AfterViewInit, EventEmitter } from "@angular/core";
import { PIAMStatistics } from "../../appobjects/piamStatistics";
import { LOV_Field, LOVDropDownService, SearchFilter } from "../../../../../../common/services/lovdropdown/lovdropdown.service";
import { AlertMessagesService } from '../../../../../../common/components/utility/alertmessage/alertmessages.service';// MYS-2018-1189
import { AlertMessage } from '../../../../../../common/components/utility/alertmessage/alertmessages.model';// MYS-2018-1189

declare var jQuery: any;
declare var numeral: any;// MYS-2018-1189
@Component({
    selector: 'piam-statistics',
    templateUrl: 'app/bms/components/proposal/newbusinessrisks/motorcommercial/uimodules/piamStatistics.template.html',
    inputs: ["_piamStatistics", "riskCode", "isCoverNote"],
    outputs: ['onexinsurerchange']
})

export class PIAMStatisticsComponent implements OnInit {

    private isCollapsedMode: boolean = false;
    private _piamStatistics: PIAMStatistics;
    private riskCode: string;
    private isCoverNote: boolean;
    onexinsurerchange = new EventEmitter<any>();
    public disableForm = 'N';

    constructor(private lovDropDownService: LOVDropDownService, public _alertMsgService: AlertMessagesService) { }

    ngAfterViewInit() {
        this.setFormDisabled();
        this.isCoverNote = false;
    }
    setFormDisabled() {
        if (jQuery("#bmsForm").prop("disabled") == true) {
            this.disableForm = "Y";
        }
    }


    ngOnInit() {
        this.populateLOVs();
    }

    private populateLOVs(): void {

        this.lovDropDownService.createLOVDataList(["garage", "antiTheft", "safetyFeatures", "exInsurer", "localImport", "ownership"]);

        let lovFields = [
            new LOV_Field("ALL", "MOTOR", "NEW BUSINESS", "ALL", "NEW", "PIAM_STAT", "Garage", "LOV", [], "DESCPF", "garage", null),
            new LOV_Field("ALL", "MOTOR", "NEW BUSINESS", "ALL", "NEW", "PIAM_STAT", "Anti Theft", "LOV", [], "DESCPF", "antiTheft", null),
            new LOV_Field("ALL", "MOTOR", "NEW BUSINESS", "ALL", "NEW", "PIAM_STAT", "Safety Features", "LOV", [], "DESCPF", "safetyFeatures", null),
            new LOV_Field("ALL", "MOTOR", "NEW BUSINESS", "ALL", "NEW", "PIAM_STAT", "Ex Insurer", "LOV", [], "DESCPF", "exInsurer", null),
            new LOV_Field("ALL", "MOTOR", "NEW BUSINESS", "ALL", "NEW", "PIAM_STAT", "LocalImport", "LOV", [], "DESCPF", "localImport", null)
        ];
        this.lovDropDownService.util_populateLOV(lovFields, this);
    }

    changeExinsurer(value) {
        if (value == '998') {
            this.onexinsurerchange.emit(value);
        }
    }
    public onPurchasePriceChange(event) {// MYS-2018-1189 Added this below validation
        if (isNaN(Number(numeral(this._piamStatistics.purchasePrice))) || this._piamStatistics.purchasePrice == null) {
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Enter Valid Purchase Price and Format", 5000));
            this._piamStatistics.purchasePrice = '';
            return;
        }
        if (this._piamStatistics.purchasePrice.toString().includes('.')) {
            if ((this._piamStatistics.purchasePrice.toString().split(".")[1].length + Number(this._piamStatistics.purchasePrice).toString().split(".")[0].length) > 13) {
                this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Maximum 13 Digits Allowed", 8000));
                this._piamStatistics.purchasePrice = '';
                return;
            }
            else if (this._piamStatistics.purchasePrice.toString().split(".")[1].length > 2) {
                this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Only 2 Digits Allowed after Decimal Point ", 8000));
                this._piamStatistics.purchasePrice = '';
                return;
            }
        }
        else if (this._piamStatistics.purchasePrice.toString().length > 13) {
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Maximum 13 Digits Allowed", 8000));
            this._piamStatistics.purchasePrice = '';
            return;
        }
    }
    private checkExcessValidation(event) {
        if (!(event.keyCode >= 48 && event.keyCode <= 57 || (event.keyCode == 46))) {
            event.preventDefault();
        }
    }
}