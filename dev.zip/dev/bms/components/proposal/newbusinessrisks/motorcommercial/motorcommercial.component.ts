/*
 * Change History	:
 *
 * 	No      Date         Description                                 			Changed By
 *	====    ==========   ===========                                 			==========
 *	AL001   15/08/2017  MYS-2017-0371    -  Develop MPD               				ALA		
 *
 *	AL002   20/09/2017  Redmine#1689 -Clauses for HVC/ HVT/ HVF       				ALA
 *	         			(Vehicle Body = Mobile Crane & Vehicle Body = Excavator)
 *
 *	GA001   21/11/2017  MYS-2017-0813 - To enhance BPM to cater 
 *						for minimum sum insured   					   				KGA
 *
 *	GA002   28/11/2017  MYS-2017-1051 - To fix the issue in clauses 
 *						for Motor Products   						   				KGA
 *
 *	GA003   20/12/2017  MYS-2017-1118 - To create a new code for the below 
 *						additional benefit (E57A and M010)   	  	   				KGA	
 *
 *  SR001   27/02/2018  MYS-2017-0083 - To enhance MPC and MPF Policy 
 * 						to allow Non-Tariff Add-On and Remove M001-M010 
 * 						Validations for MPD and make PAM Risk mandatory.			VSR			
 * 
 *  SR002   02/08/2018  MYS-2018-0936 - Enable M003 for MPC, MPD, MPF				VSR
 *  								   
 *
 *  SR003   09/07/2018  MYS-2018-0171 - To enhance Special Type & Motor Trade 
 * 						in BMS to integrate with VPMS for HVC, HVT, HVF,
 * 						MTC, MTF, MTT												VSR
 * 
 *  GA004   25/09/2018  MYS-2018-0707 : Quotation Date in BMS 					    KGA	
 * 	
 *  GA005   01/10/2018  MYS-2018-1186  - Changes on Sum Insured field for 
 *                      ‘Third Party’ cover                                         KGA
 * 
 *  GA006   29/11/2018  MYS-2018-1364 - Incorrect Vehicle Model Code mapping from 
 *                      BMS to P400                                                 KGA
 * 
 *  GA007   29/11/2018  MYS-2018-1146 - Motor To allow ESI request for 
 *                      "Cover = TF" 			                                    KGA
 * 
 *  GA008   04/01/2019  MYS-2018-1542 - Unable to select model code when user 
 *                      select different model code with same short description 
 *                      from BMS 			                                        KGA
 *  GA009   12/02/2019  MYS-2018-0740 - To enhance BMS to check the minimum 
 *                      sum insured table (T9148) - for Renewal                     KGA
 * 
 *  SR004   26/04/2019  MYS-2019-0455 - To default 'seating' for bus in 
 *                      TONNAGE/SEATING selection field                             VSR
 * 
 *	VK006   13/02//2019 MYS-2018-0164 - To Add MMP Product	

    KU001   30/04/2019  MYS-2019-0520 - New Vehicle Type & Endorsement Code         DKU
 *                      (Car Subscription) in BMS
 *  SR006   29/05/2019  MYS-2019-0655 - Create Passenger Risk for Hire Vehicles     VSR
 * 
 *  SR007   29/05/2019  MYS-2019-0606 - To block client = corporate to buy 
 *                      E-Hail E-Zee extension                                      VSR
 *  VK011   02/07/2019  MYS-2019-0705 -Blocking MMP1 benefit for all products       VKR
 * 	MR001   14/05//2019 MYS-2019-0290 - Enable Description FOR ETC                	MRA1
 *                      except for MMP                          
 *  E1009   01/07/2019  MYS-2019-0656 - Max Rebate value for MPD product on 
 *                      loading of risk was override                                SRE1
 * 
 * *  MR002    11/6/2019  MYS-2019-0324 -adding validation on ESI                   MRA1
                        Market Value   
 * 				
 *  MS001   29/08/2019  MYS-2018-0729 - To Add MMF Product							MSU
 *  YPK001  02/08/2019  MYS-2019-0737 - To allow multiple ETC benefit code to       PKU1
 *                       be selected in BMS - to follow P400 functionality.
 *  GA010    11/09/2019  MYS-2019-0974 - BMS Enhancement on High Risk Vehicle & Client       KGA
 * 
 *  KA002    27/09/2019  MYS-2019-0924 - to block prompt alert message on adding    DKA
 *                       E111 benefit if ncd percent = 0;   
 * MSU001    23/10/2019  MYS-2019-0984 - Cover and Region updated        MSU    
*/
import { Component, OnInit, Output, ViewChild, EventEmitter, AfterViewInit, ElementRef, ViewContainerRef } from '@angular/core';
import { NamedDriversComponent } from './uimodules/nameddrivers.component';
import { SearchInput } from "../../../../../common/components/utility/search/genericsearch";
import { CustomDCLService } from '../../../../../common/services/customdcl.service';
import { ClausesComponent } from "../uimodules/clauses.component";
import { MotorCommercial, TrailerDetails, VixResp } from './appobjects/motorcommercial';
import { PremiumInfo, CommonRiskLevelPremium, CommonAnnualPostedPremium, PostedPremium } from './appobjects/premiumInfo';
import { NCDRequest } from './appobjects/ncdRequest';
import { PIAMStatistics } from '../appobjects/piamStatistics';
import { FinancialInterest } from '../../../../../common/components/financialinterest/appobjects/financialInterest';
import { NamedDriver } from './appobjects/nameddriver';
import { LoadingComputation } from './appobjects/loadingComputationItem';
import { Clause } from '../appobjects/clause';
import { RiskType } from '../../proposalheader/uimodules/risktypes';
import { ESIDetails } from './appobjects/esiDetails';
import { ENCDDetails } from './appobjects/encdDetails';
import { GSTDetails } from '../appobjects/gstDetails';
import { MotorItems, MotorMCVDetail } from '../appobjects/motorItems';
import { LOV_Field, LOVDropDownService, SearchFilter } from "../../../../../common/services/lovdropdown/lovdropdown.service";
import { CordysSoapWService } from "../../../../../common/components/utility/cordys-soap-ws";
import { LoadingComputationItem } from "./appobjects/loadingComputationItem";
import { ClientDetails } from '../../../../../common/components/client/appobjects/client';
import { GetLOVData, SearchAdvancedConfig, Filter } from '../../../../../common/components/utility/search/search.requests';
import { ProposalHeader, HighRiskIndReason, HighRiskIndReasons } from '../../proposalheader/appobjects/proposalheader';//GA010
import { AlertMessagesService } from '../../../../../common/components/utility/alertmessage/alertmessages.service';
import { AlertMessage } from '../../../../../common/components/utility/alertmessage/alertmessages.model';
import { ModalInput } from "../../../../../common/components/utility/modal/modal";
import { MotorValidator } from '../../validation/motor.validator';
import { BMSEvents } from '../../events/bms.events';
import { BMSConstants } from '../../../common/constants/bms_constants';
import { BMSType } from '../../../common/constants/bms_types';
import { BMSLOVRequest } from '../../../common/service/lov/bms.lovrequest';
import { MotorVPMSService } from './handler/motor.vpms.service';
import { RiskArray } from '../../proposalheader/uimodules/riskArray';
import { CaseInfo } from '../../../../../common/components/appobjects/caseinfo';
import { NumberField } from '../../../../../common/components/utility/number/number';
import { AppUtil } from '../../../../../common/components/utility/apputil/app.util';
import { RIService } from '../services/ri.service';
import { RiskClassificationService } from '../services/riskcls.service';
import { ExtraTextDialogData } from "../dialogs/extratext.dialog.data";
import { BMSUtilService } from '../../../../services/bms.util.service'; //SST Code
import { ActivatedRoute } from '@angular/router';

declare var jQuery: any;
declare var numeral: any;
declare var moment: any;

@Component({
    selector: 'motor-cv-component',
    templateUrl: 'app/bms/components/proposal/newbusinessrisks/motorcommercial/motorcommercial.template.html',
    inputs: ["riskObj", 'clientDetails', 'headerInfo'],
    outputs: ["onPremiumChange", 'onRiskClsChange', 'onRtngFlgChange']
})
export class MotorCVRiskComponent implements OnInit {
    private el: HTMLElement;
    private collapseVehiclelInfo: boolean = false;
    private collapseAddtnlBenft: boolean = false;
    private collapseInsuranceInfo: boolean = false;
    private isTrailerMode: boolean = false;
    private collapseClausesInfo: boolean = true;
    private isTrailerInfo: boolean = false;
    private addFIPanel: boolean = false;
    private enableISM: boolean = true;
    private blackListIndicatorUI: boolean = false;
    private insuredIsDriverUI: boolean = false;
    private vehicleReferredRisk: boolean = false;
    private modelDesc: string = "";
    private trailerModelDesc: string = "";
    private appCode: string = "";
    private bnmLoadingVal: number;	// MYS-2018-1562  removing the hard coded value private bnmLoadingVal: number = 35;
    private sumAddlAmt: number = 0;
    private driverAddlPrm: number = 0;
    private sourceName: string = '';
    private trailerModel: string = "";
    public riskObj: MotorCommercial;
    private vixObj: VixResp;
    public clientDetails: ClientDetails;
    public vehicleVariantList: VehicleVariant[];
    public defaultClauseCode: string = "";
    public riskCode: string = "";
    public riskScreen: string = "";
    public riskScreenType: string = "";
    public premiumFormat: string = '0.00';
    public siFormat: string = '0,0';
    public siCalcFormat: string = '0';
    public headerInfo: ProposalHeader;
    public yearOfManfactureList: Object[] = [];
    public disableForm = 'N';
    private nvicFlag: string;
    private vixResponseCode: any;
    private bmsType: BMSType;
    public isCoverNote = false;

    private caseInfo: CaseInfo;
    public PMcovernoteCancelled: boolean = false;
    public TRcovernoteCancelled: boolean = false;
    public mandatoryDisable: boolean = false;

    private isGeneralPageCollapsed: boolean = false;
    private trailerModelNew: string = "";
    private isCodeDescriptionEnabled: string = "";//MRA001

    onPremiumChange = new EventEmitter<any>();
    onRiskClsChange = new EventEmitter<any>();
    onRtngFlgChange = new EventEmitter<any>();
    @ViewChild(NamedDriversComponent) private ndComp: NamedDriversComponent;
    @ViewChild(ClausesComponent) private clausesComp: ClausesComponent;
    @ViewChild('motorCommerModal', { read: ViewContainerRef }) contentArea: ViewContainerRef;


    private premiumInfoObj: PremiumInfo;
    private msigRiskLevelPremium: CommonRiskLevelPremium;
    private vpmsRiskLevelPremium: CommonRiskLevelPremium;
    private vpmsAnnualPostingPremium: CommonAnnualPostedPremium;
    private msigAnnualPostingPremium: CommonAnnualPostedPremium;
    private postedPremium: PostedPremium;
    private showVehicleBody: boolean = false; //SR002

    //KU001 start
    public VehicleTypePF: boolean = false;
    public FluxAgentSelected: boolean = false;
    public AgentSelected: boolean = false;
    //KU001 End

    constructor(public dcl: CustomDCLService, private lovDropDownService: LOVDropDownService, private _soapService: CordysSoapWService, private _mvpmsService: MotorVPMSService, public _alertMsgService: AlertMessagesService, el: ElementRef, private _rcls: RiskClassificationService, private _riService: RIService, private _bus: BMSUtilService, private _activatedRoute: ActivatedRoute) {
        this.el = el.nativeElement;
    }

    ngAfterViewInit() {
        //this.setRiskClassification(this);
        this.setTonnageSeating(this);
        this.setFormDisabled();
        if (this.caseInfo.caseId == "" || this.caseInfo.caseId == undefined) {
            this.calculateDefaultClauseCode(this.riskObj.cover);
        }
        //this.calculateDefaultClauseCode(this.riskObj.cover);.
        //START YPK001
        let rIndex = 0;
        if ((this.headerInfo.CoInsurance == 'Y' && this.riskObj.riskNumber == '1') && (["MyTasks", "MyDrafts"].indexOf(this._activatedRoute.snapshot.params['component']) >= 0 || Object.keys(this._activatedRoute.snapshot.params).length == 0)) {
            if (this.headerInfo.coInsuranceDetails.coInsurance.length == 1) {
                if (!(this.headerInfo.coInsuranceDetails.coInsurance[0].coInsuranceindicator == 'L' && this.headerInfo.coInsuranceDetails.coInsurance[0].sharePercentage == '100')) {
                    rIndex = this.riskObj.clauses.clause.map(function (item) { return item.clauseCode; }).indexOf("COIN");
                    if (rIndex == -1)
                        this.setClauses(["COIN"], false);
                }
            }
            else {
                rIndex = this.riskObj.clauses.clause.map(function (item) { return item.clauseCode; }).indexOf("COIN");
                if (rIndex == -1)
                    this.setClauses(["COIN"], false);
            }
        }
    }
    //END YPK001

    setFormDisabled() {
        if (jQuery("#bmsForm").prop("disabled") == true) {
            this.disableForm = "Y";
        }
        //Added below condition for SAF MYS-2019-0490 to disable complete form.  VK012
        if (["Quotation", "Policy Processing", "P400 In forced", "Appeal to BU SMT", "Appeal Approved", "Appeal Approved by HM", "RFI", "Pending Receipting"].indexOf(this.caseInfo.status) >= 0) {
            jQuery("#bmsRiskForm").prop("disabled", true);
        }
    }

    ngOnInit() {
        this.setRatingFlag();
        this.handleCoverNote();
        this.setRiskCode();
        this.setRiskScreen();
        //this.initializeChildComp();
        //GA010 START
        if (this.headerInfo.isHighRiskApplicable) {
            this.checkHighRiskVehicle();
        } else {
            this.checkBlackList();
        }
        //GA010 END
        this.setDataForViewMode();
        this.populateLOVs();
        this.checkFluxAgentOrNot();
        if (this.clientDetails)
            this.setClientInfo();
        if (!this.riskObj.use)
            this.defaultVehicleUse();
        if (!this.riskObj.insuredIsDriver)
            this.handleInsuredISDriver();
        this.setInsuredISDriverUI();
        this.manfactureYearList(40);
        //AL001 START
		/*if(!this.riskObj.vehicalClass || !this.riskObj.use || !this.riskObj.CI)
			this.initiateCIDefaulting();
			*/
        if (!this.riskObj.vehicalClass || !this.riskObj.use || !this.riskObj.CI) {
            this.initiateCIDefaulting();
            if (this.clientDetails && (this.riskObj.riskType == 'MPD')) {
                if (this.clientDetails.client.genericDetails.clienttype == 'P') {
                    this.riskObj.CI = 'MX1';
                }
            }
        }
        //AL001 END
        if (!this.riskObj.permittedDriver)
            this.defaultPermittedDriver();
        this.getSourceName();
        //this.setRatingMethod(this.riskObj.ratingFlag,true);
        this.setPremInfo();
        this.callForISMResponse();
        this.setCoverage(this.riskObj.vehicalClass, "oninit");
        this.handleRenewalReferredRiskCase();
        //GA001 START
        if (this.riskObj.cover && this.riskObj.minSumInsured == 0)
            this.minimumSumInsuredVal();
        //GA001 END
        //SR003
        this.vehicleBodyAvailablitly(this.riskObj.vehicalClass);
        if (this.showVehicleBody && this.riskObj.vehClassCode && this.riskObj.use) {
            this.getVehicleBody();
        }

        //SST code
        //if(this.riskObj.GST == 0 || this.riskObj.SST == 0) {
        if (["MyTasks", "MyDrafts"].indexOf(this._activatedRoute.snapshot.params['component']) >= 0 || Object.keys(this._activatedRoute.snapshot.params).length == 0) {
            let respObj = this._bus.getTAXDetails();
            if (respObj != undefined && respObj != "") {
                this.headerInfo.SSTTaxRate = Number(respObj[0].old.ITEMPF.GST);
                this.headerInfo.GSTTaxRate = Number(respObj[1].old.ITEMPF.GST);

                this.riskObj.SST = Number(this.headerInfo.SSTTaxRate);
                this.riskObj.GST = Number(this.headerInfo.GSTTaxRate);
            }

            this.headerInfo = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo;
            this.riskObj.SSTLiveDate = (this.riskObj.SSTLiveDate == undefined) ? this.headerInfo.SSTLiveDate : this.riskObj.SSTLiveDate;
            if (this.riskObj.SSTLiveDate == undefined || this.riskObj.SSTLiveDate == "") {
                let tempRespObj = this._bus.getLiveDate();
                this.riskObj.GSTLiveDate = tempRespObj[0].old.ITEMPF.LIVEDATE;
                this.riskObj.SSTLiveDate = tempRespObj[1].old.ITEMPF.LIVEDATE;
                if (this.headerInfo.SSTLiveDate == undefined || this.headerInfo.SSTLiveDate == "") {
                    this.headerInfo.SSTLiveDate = this.riskObj.SSTLiveDate;
                }
                if (this.headerInfo.GSTLiveDate == undefined || this.headerInfo.GSTLiveDate == "") {
                    this.headerInfo.GSTLiveDate = this.riskObj.GSTLiveDate;
                }
            }
            if (moment(this.headerInfo.effectiveDate, "YYYY-MM-DD").format("YYYYMMDD") >= moment(this.riskObj.SSTLiveDate, "YYYY-MM-DD").format("YYYYMMDD")) {
                this.riskObj.isGSTApplicable = false;
            } else {
                this.riskObj.isGSTApplicable = true;
            }
        }
        //End
        //Added below condition for SAF MYS-2019-0490 -- bizAcceptanceDate = QuotationDate & bizReceivedDate = SubmittedDate. 
        if (this.headerInfo.VPMSProduct == "Y" && this.headerInfo.bizAcceptanceDate < this.headerInfo.bizReceivedDate && ["Quotation", "Policy Processing", "P400 In forced", "Appeal to BU SMT", "Appeal Approved", "Appeal Approved by HM", "RFI"].indexOf(this.caseInfo.status) != -1) {
            this.clearPremiumInfo();
            this._alertMsgService.add(new AlertMessage(AlertMessage.WARN, "Quotation Date is less than the Assessment Date. Hence Premium Info will be cleared. Please click on GetQuotation button and proceed.", -1));
        }
        //VK006 Function Call to add MMP1 default benefit
        //MS001 Function Call to add MMP1 default benefit
        //if (this.riskObj.riskType == 'MMP' && (this.caseInfo.caseId == "" || this.caseInfo.caseId == undefined))
        if ((["MyTasks", "MyDrafts"].indexOf(this._activatedRoute.snapshot.params['component']) >= 0 || Object.keys(this._activatedRoute.snapshot.params).length == 0) && ((this.riskObj.riskType == 'MMP' || this.riskObj.riskType == 'MMF') && this.riskObj.motorItems)) {
            let isMMPBenfit = this.riskObj.motorItems.motorItem.filter((item) => item.code == "MMP1");
            if (isMMPBenfit.length == 0) {
                this.addMMPBenefit();
            }
        }

    }
    addMMPBenefit() {
        this.getSpecificBenefitDetails("MMP1", 'Y');
    }
    //GA001 START
    minimumSumInsuredVal() {
        let descitemVal = "";
        let itemtoval = "99999999";
        let riskType: string = this.riskObj.riskType;
        if (riskType && riskType.length == 2) {
            descitemVal = riskType + " " + riskType + " " + this.riskObj.cover;
        } else {
            descitemVal = riskType + riskType + this.riskObj.cover;
        }
        let request: GetLOVData = new GetLOVData();
        request.BRANCH = 'ALL';
        request.LOB = 'MOTOR';
        request.BUSINESS_FUNCTION = 'NEW BUSINESS';
        request.PRODUCT = 'ALL';
        request.OPERATION = 'NEW';
        request.FORM_NAME = 'PRIVATE_MOTOR';
        request.FORM_FIELD_NAME = 'MINSUMINSURED';
        request.FIELD_TYPE = 'LOV';
        request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        request.ADVANCE_CONFIG_XML.FILTERS = new Filter();

        request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({ "@FIELD_NAME": 'DESCITEM', "@FIELD_VALUE": descitemVal, '@OPERATION': 'EQ', '@CONDITION': 'AND' },
            { "@FIELD_NAME": 'ITMTO', "@FIELD_VALUE": itemtoval, '@OPERATION': 'EQ', '@CONDITION': 'AND' });
        this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.successOfDefaultMinSIData, this.handleError, false, { comp: this });
    }

    private successOfDefaultMinSIData(data, prms) {
        if (data && data.tuple && data.tuple.old && data.tuple.old.T9148 && data.tuple.old.T9148.MINSUMINSURED) {
            prms.comp.riskObj.minSumInsured = data.tuple.old.T9148.MINSUMINSURED;
        }
    }
    //GA001 END
    handleCoverNote() {
        if (BMSConstants.getBMSType() == BMSType.CoverNote) {
            this.riskObj.PIAMStatistics.vehicalCondition = 'N';
            let status = BMSConstants.getBMSObj().ApplicationBusinessObject.caseInfo.status;
            if (status != "Ready for Conversion" && status != "Policy Processing" && status != "P400 In forced" && status != "Closed" && status != "Cover Note Accepted") {
                this.isCoverNote = true;
            }
            if (BMSConstants.getBMSObj().ApplicationBusinessObject.caseInfo.status == "Cover Note Cancelled") {
                this.mandatoryDisable = true;
                this.PMcovernoteCancelled = true;
                this.TRcovernoteCancelled = true;
                if (this.riskObj.newVehicleCoverNote.nvCoverNote[0].coverNoteStatus == 'CANCELLED') {
                    this.PMcovernoteCancelled = false;
                }
                if (this.riskObj.newVehicleCoverNote.nvCoverNote[1].coverNoteStatus == 'CANCELLED') {
                    this.TRcovernoteCancelled = false;
                }

            }

        }
    }
    setRatingFlag() {
        if (!this.riskObj.ratingFlag && this.riskObj.isVPMS == "N") {
            let riskType: string = this.riskObj.riskType;
            /* SR003 Changes Starts */
			/*if(riskType == "MPC" || riskType == "MPT" || riskType == "MPF" || riskType == "CV" || riskType == "CVT" || riskType == "CVF" || riskType == "MCY" || riskType == "MCT" || riskType == "MCF" || riskType == "MPD" )//AL001
				this.riskObj.ratingFlag = 'A';
			else if(riskType == "HVC" || riskType == "HVT" || riskType == "HVF" || riskType == "MTC" || riskType == "MTT" || riskType == "MTF" )
				this.riskObj.ratingFlag = 'M';*/
            //VK006 Added MMP
            //MS001 Added MMF
            if (["MPC", "MMP", "MMF", "MPT", "MPF", "CV", "CVT", "CVF", "MCY", "MCT", "MCF", "MPD", "HVC", "HVT", "HVF", "MTC", "MTT", "MTF"].indexOf(this.riskObj.riskType) != -1) {
                this.riskObj.ratingFlag = 'A';
            } else {
                this.riskObj.ratingFlag = 'M';
            }
            /* SR003 Changes Ends */
            this.onRtngFlgChange.emit("");
        }
        else if (!this.riskObj.ratingFlag && this.riskObj.isVPMS == "Y") {
            this.riskObj.ratingFlag = 'A';
            this.onRtngFlgChange.emit("");
        }
    }

    defaultState() {
        let city = this.clientDetails.getCityCode();
        if (AppUtil.isEmpty(this.riskObj.state, false) == true && AppUtil.isEmpty(city, false) == false) {
            let filters = [{ "@FIELD_NAME": 'A.DESCITEM', "@FIELD_VALUE": city, '@OPERATION': 'EQ', '@CONDITION': 'AND' }];
            let request = new BMSLOVRequest().getLOVRequest("DefaultState", filters);

            let prom = this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, null, null, true, null);
            prom.success((data) => this.setDefaultState(data));
            prom.error((data) => {
                this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error while getting default state value.", 10000));
            });
        }
    }

    setDefaultState(data) {
        let defaultState = AppUtil.getValueByPath(data, "tuple.old.DESCPF.SHORTDESC");
        if (AppUtil.isEmpty(defaultState, false) == false) {
            let avlItms = this.lovDropDownService.lovDataList.states.filter((item) => item.DESCITEM == defaultState);
            if (avlItms.length > 0)
                this.riskObj.state = defaultState;
        }
    }


    /*** Below functions added by Rajesh**/
    private handleInsuredISDriver() {
        if (this.clientDetails.client.genericDetails.clienttype == 'P') {
            this.riskObj.insuredType = 'P';
            //VK006 Added MMP Condition
            //MS001 Added MMF Condition
            if (this.riskObj.riskType == 'MPC' || this.riskObj.riskType == 'MPD' || this.riskObj.riskType == "MMP" || this.riskObj.riskType == "MMF") { //AL001 ADDED MPD 
                this.riskObj.insuredIsDriver = "true";
            }
        } else {
            this.riskObj.insuredType = 'C';
            this.riskObj.insuredIsDriver = "false";
        }
    }

    setRatingMethod(rating, onInit) {
        if (onInit == false)
            this.clearPremiumInfo();
        if (rating == "M") {
            this.riskObj.premiumInfo = null;
            this.riskObj.isVPMS = "N";

        }
        else {
            if (onInit == false)
                this.riskObj.premiumInfo = new PremiumInfo();
            this.riskObj.isVPMS = "Y";
        }
        this.setPremInfo();
    }

    setPremInfo() {
        if (this.riskObj.isVPMS == "Y") {
            this.premiumInfoObj = this.riskObj.premiumInfo;
            this.msigRiskLevelPremium = this.riskObj.premiumInfo.riskLevelPremium.msigRiskLevelPremium;
            this.vpmsRiskLevelPremium = this.riskObj.premiumInfo.riskLevelPremium.vpmsRiskLevelPremium;
            this.msigAnnualPostingPremium = this.riskObj.premiumInfo.annualPostingPremium.msigAnnualPostingPremium;
            this.vpmsAnnualPostingPremium = this.riskObj.premiumInfo.annualPostingPremium.vpmsAnnualPostingPremium;
            this.postedPremium = this.riskObj.premiumInfo.postedPremium;
            //AL001 START
            if (this.riskObj.riskType == "MPD") {
                this.headerInfo.rebate = this.riskObj.premiumCalculator == "M" ? this.msigAnnualPostingPremium.directDiscountRate : this.vpmsAnnualPostingPremium.directDiscountRate;
                this.headerInfo.maxRebate = this.headerInfo.rebate;
            }
            //AL001 END
        }
        else {
            this.premiumInfoObj = null;
            this.msigRiskLevelPremium = null;
            this.vpmsRiskLevelPremium = null;
            this.msigAnnualPostingPremium = null;
            this.vpmsAnnualPostingPremium = null;
            this.postedPremium = null;
        }
    }

    private setInsuredISDriverUI() {
        if (this.riskObj.insuredIsDriver == "true")
            this.insuredIsDriverUI = true;
        else
            this.insuredIsDriverUI = false;
    }

    private onChangeInsuredIsDriver(e) {
        if (e.target.checked == false) {
            this.handleCITypeDefaulting("user");
            this.riskObj.CI = 'MX12';
            this.riskObj.insuredIsDriver = "false";
            this.removeInsured();
        } else {
            this.handleCITypeDefaulting("system");
            this.riskObj.insuredIsDriver = "true";
            this.addInsured();
        }
    }

    removeInsured() {
        if (this.ndComp && this.ndComp._nameddriver && this.ndComp._nameddriver.driverDetail.length > 0 && this.ndComp._nameddriver.driverDetail[0].ICNumber == this.clientDetails.client.personalClientDetails.NRICNo) {
            this.ndComp._nameddriver.driverDetail.splice(0, 1);
        }
    }

    addInsured() {
        if (this.ndComp) {
            this.ndComp.setDriverInfo();
        }
    }

    private defaultVehicleUse() {
        if (this.clientDetails && this.riskObj.vehicalClass == 'PC') {
            if (this.clientDetails.client.genericDetails.clienttype == 'P') {
                this.riskObj.use = '01';
            }
            else if (this.clientDetails.client.genericDetails.clienttype == 'C') {
                this.riskObj.use = '02';
            }
        }
        if (this.clientDetails && (this.riskObj.riskType == 'MCY' || this.riskObj.riskType == 'MCT' || this.riskObj.riskType == 'MCF')) {
            if (this.clientDetails.client.genericDetails.clienttype == 'P') {
                this.riskObj.use = '11';
            }
            else if (this.clientDetails.client.genericDetails.clienttype == 'C') {
                this.riskObj.use = '12';
            }
        }
    }
    private defaultCoverageCode() {
        let riskType: string = this.riskObj.riskType;
        //VK006 Added MMP Condition
        //MS001 Added MMF Condition
        if (riskType == "MPC" ||
            riskType == "MCF" ||
            riskType == "MTF" ||
            riskType == "MPF" ||
            riskType == "MCY" ||
            riskType == "CV" ||
            riskType == "CVF" ||
            riskType == "HVC" ||
            riskType == "HVF" ||
            riskType == "MTC" ||
            riskType == "MPD" ||
            riskType == "MMP" ||
            riskType == "MMF") { //AL001 ADDED MPD
            this.checkDefaultCoverage("CO");
        }
        else if (riskType == "MCT" ||
            riskType == "MPT" ||
            riskType == "CVT" ||
            riskType == "HVT" ||
            riskType == "MTT") {
            this.checkDefaultCoverage("TP");
        }
        this.calculateDefaultClauseCode(this.riskObj.cover);
        this.minimumSumInsuredVal();//GA001
    }

    checkDefaultCoverage(value) {
        let cover = this.lovDropDownService.lovDataList.Coverage.filter((item) => item.VALUE == value);
        if (cover && cover.length == 0) {
            this.riskObj.cover = "";
        }
        else {
            this.riskObj.cover = value;
        }

    }

    private getSourceName() {
        this._soapService.callCordysSoapService("GetXMLObject", "http://schemas.cordys.com/1.0/xmlstore", { key: "com/msig/insurance/bms/BusinessFunctionList.xml" }, this.sourceNameSuccessHandler, this.handleError, true, { comp: this });
    }

    sourceNameSuccessHandler(response, prms) {
        if (response.tuple)
            prms.comp.sourceName = response.tuple.old.BusinessFunctionList.source;
        if (!prms.comp.validateEmpty(prms.comp.sourceName)) {
            prms.comp.sourceName = 'BPM';
            prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "NCD Source Name is not configured in System. Defaulting the Source Name to BPM to avoid error while calling", 10000));
        }
    }

    handleCITypeDefaulting(source) {
        this.initiateCIDefaulting();
    }
    private initiateCIDefaulting() {

        var StatisticsData = this._soapService.callCordysSoapService("GetLOVData",
            "http://schemas.opentext.com/lovhandler/v1.0", this.getDefaultCIDataRequest(), this.successOfDefaultCIData, this.errorOfDefaultCIData, false, { comp: this });

    }
    private successOfDefaultCIData(data, prms) {
        if (data && data.tuple && data.tuple.old && data.tuple.old.P400_CI_TYPE_DEFAULTS && data.tuple.old.P400_CI_TYPE_DEFAULTS.DEFAULT_CI_TYPE) {
            prms.comp.riskObj.CI = data.tuple.old.P400_CI_TYPE_DEFAULTS.DEFAULT_CI_TYPE;
            if (data.tuple.old.P400_CI_TYPE_DEFAULTS.DEFAULT_CI_TYPE == "MY1") {
                //remove additional benefit code ALL
                this.removeOtherBenefits(prms.comp.riskObj.motorItems.motorItem, "code", "ALL")
            } else if (data.tuple.old.P400_CI_TYPE_DEFAULTS.DEFAULT_CI_TYPE == "MY3") {
                //check and add ALL benefit code
                if (!prms.comp.validateIfAdditionalBenefitAdded("ALL")) {
                    prms.comp.getSpecificBenefitDetails("ALL");
                }
            }
        }
    }

    private errorOfDefaultCIData(response, status, errorText, prms) {
        prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, response.responseJSON.faultstring.text, 10000));
    }
    private onChangeCertificateOfInsurance(newCI) {
        let riskType: string = this.riskObj.riskType;
        this.riskObj.CI = newCI;
        if (riskType == "MCY" || riskType == "MCT" || riskType == "MCF") {
            if (newCI == "MY1") {
                //remove additional benefit code ALL
                this.removeOtherBenefits(this.riskObj.motorItems.motorItem, "code", "ALL");
                this.riskObj.permittedDriver = "04";
            } else if (newCI == "MY3") {
                //check and add ALL benefit code
                this.riskObj.permittedDriver = "05";
                if (!this.validateIfAdditionalBenefitAdded("ALL")) {
                    this.getSpecificBenefitDetails("ALL", "N");

                }
            }
        }
    }

    private onBlurCertificateOfInsurance(newCI) {
        if (this.headerInfo.insuredType == "Personal" && this.riskObj.vehicalClass == "PF" && newCI == "MX4") {
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "You are not able to change the Certificate of Insurance to " + newCI, 10000));
            this.riskObj.CI = '';
        }
        else if (this.headerInfo.insuredType == "Corporate" && this.riskObj.vehicalClass == "PF" && newCI == "MX1") {
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "You are not able to change the Certificate of Insurance to " + newCI, 10000));
            this.riskObj.CI = '';
        }
    }

    removeOtherBenefits(ary, prop, benefitCode) {
        if (ary && ary.length > 0) {
            for (var index = 0, assoLength = ary.length; index < assoLength; index++) {
                if (ary[index][prop] != null && ary[index][prop] != "" && ary[index][prop] == benefitCode) {
                    this.removeBenefit(index, ary[index]["additionalpremium"]);
                    break;
                }
            }
        }
    }

    setRiskClassification(comp) {
        comp._rcls.setRiskClassification(comp.riskObj.riskNumber, "N", "", "").subscribe();
		/*if(comp.riskObj.symRiskClassification != null && comp.riskObj.symRiskClassification != "" && (comp.riskObj.symRiskClassification == "Referred" || comp.riskObj.symRiskClassification == "Declined")){
			let statusTxt = (comp.riskObj.symRiskClassification != null && comp.riskObj.symRiskClassification != "")?comp.riskObj.symRiskClassification:comp.riskObj.riskClassification;
			comp.riskObj.riskClassificationReason = "System marked as "+statusTxt;        
		}
		else{
			if(comp.riskObj.riskClassificationReason != null && comp.riskObj.riskClassificationReason != "" && (comp.riskObj.riskClassificationReason != "System marked as Standard" 
					&& comp.riskObj.riskClassificationReason.indexOf("System marked as ") != -1)){
				comp.riskObj.riskClassificationReason = "";
			}
		}
		comp.onRiskClsChange.emit('');*/
    }

    changeRiskClassification(event) {
        this.riskObj.riskClassification = event.target.value;
        //this._rcls.setRiskClassification(this.riskObj.riskNumber,"N","").subscribe();
        this.setRiskClassification(this);
    }

    resetTonnageSelection() {
        this.setTonnageSeating(this);
    }

    setTonnageSeating(comp) {
        /* SR003 Changes Starts */
        //if (this.riskObj.riskType == "CV" || this.riskObj.riskType == "CVT" || this.riskObj.riskType == "CVF") {
        // Changed the condition to include HVC, HVT, HVF, MTC, MTT, MTF
        if (["CV", "CVT", "CVF", "HVC", "HVT", "HVF", "MTC", "MTT", "MTF"].indexOf(this.riskObj.riskType) != -1) {
            /* SR003 Changes Ends */
            jQuery(comp.el).find("#tonnageFlag").find("option").removeAttr("disabled");
            if (comp.riskObj.tommangeIndicator != null && comp.riskObj.tommangeIndicator == "T") {
                jQuery(comp.el).find("#tonnageFlag").find("option[value='S']").attr("disabled", "");
                jQuery(comp.el).find("#tonnageFlag").find("option[value='']").attr("disabled", "");
            }
            else if (comp.riskObj.tommangeIndicator != null && comp.riskObj.tommangeIndicator == "S") {
                jQuery(comp.el).find("#tonnageFlag").find("option[value='T']").attr("disabled", "");
                jQuery(comp.el).find("#tonnageFlag").find("option[value='']").attr("disabled", "");
            }
            else if (comp.riskObj.tommangeIndicator != null && comp.riskObj.tommangeIndicator == "") {
                jQuery(comp.el).find("#tonnageFlag").find("option[value='T']").attr("disabled", "");
                jQuery(comp.el).find("#tonnageFlag").find("option[value='S']").attr("disabled", "");
            }
        }
    }

    private getDefaultCIDataRequest() {
        var vehBodyCode = "";
        var vehUseCode = "";
        if (this.riskObj.PIAMStatistics.vehicalBodyCode != undefined) {
            vehBodyCode = this.riskObj.PIAMStatistics.vehicalBodyCode;
        }
        if (this.riskObj.use != undefined) {
            vehUseCode = this.riskObj.use;
        }

        return {
            "cursor": {
                "@id": "0",
                "@position": "0",
                "@numRows": "500",
                "@maxRows": "99999",
                "@sameConnection": "false"
            },
            "BRANCH": "ALL",
            "LOB": "ALL",
            "BUSINESS_FUNCTION": "NEW BUSINESS",
            "PRODUCT": "ALL",
            "OPERATION": "NEW",
            "FORM_NAME": "MOTOR",
            "FORM_FIELD_NAME": "Default CI",
            "FIELD_TYPE": "LOOKUP",
            "ADVANCE_CONFIG_XML": {
                "FILTERS": {
                    "FILTER": [
                        {
                            "@FIELD_NAME": "",
                            "@FIELD_VALUE": "",
                            "@OPERATION": "OPNPRNTHS",
                            "@CONDITION": ""
                        },
                        {
                            "@FIELD_NAME": "CLIENT_TYPE",
                            "@FIELD_VALUE": this.clientDetails.client.genericDetails.clienttype,
                            "@OPERATION": "EQ",
                            "@CONDITION": "OR"
                        },
                        {
                            "@FIELD_NAME": "CLIENT_TYPE",
                            "@FIELD_VALUE": "ALL",
                            "@OPERATION": "EQ",
                            "@CONDITION": ""
                        },
                        {
                            "@FIELD_NAME": "",
                            "@FIELD_VALUE": "",
                            "@OPERATION": "CLSPRNTHS",
                            "@CONDITION": "AND"
                        },
                        /******/
                        {
                            "@FIELD_NAME": "",
                            "@FIELD_VALUE": "",
                            "@OPERATION": "OPNPRNTHS",
                            "@CONDITION": ""
                        },
                        {
                            "@FIELD_NAME": "CONTRACT_TYPE",
                            "@FIELD_VALUE": this.headerInfo.contractType,
                            "@OPERATION": "EQ",
                            "@CONDITION": "OR"
                        },
                        {
                            "@FIELD_NAME": "CONTRACT_TYPE",
                            "@FIELD_VALUE": "ALL",
                            "@OPERATION": "EQ",
                            "@CONDITION": ""
                        },
                        {
                            "@FIELD_NAME": "",
                            "@FIELD_VALUE": "",
                            "@OPERATION": "CLSPRNTHS",
                            "@CONDITION": "AND"
                        },
                        /******/
                        {
                            "@FIELD_NAME": "",
                            "@FIELD_VALUE": "",
                            "@OPERATION": "OPNPRNTHS",
                            "@CONDITION": ""
                        },
                        {
                            "@FIELD_NAME": "VEHICLE_CLASS",
                            "@FIELD_VALUE": this.riskObj.vehicalClass,
                            "@OPERATION": "EQ",
                            "@CONDITION": "OR"
                        },
                        {
                            "@FIELD_NAME": "VEHICLE_CLASS",
                            "@FIELD_VALUE": "ALL",
                            "@OPERATION": "EQ",
                            "@CONDITION": ""
                        },
                        {
                            "@FIELD_NAME": "",
                            "@FIELD_VALUE": "",
                            "@OPERATION": "CLSPRNTHS",
                            "@CONDITION": "AND"
                        },
                        /******/
                        {
                            "@FIELD_NAME": "",
                            "@FIELD_VALUE": "",
                            "@OPERATION": "OPNPRNTHS",
                            "@CONDITION": ""
                        },
                        {
                            "@FIELD_NAME": "VEHICLE_USE",
                            "@FIELD_VALUE": vehUseCode,
                            "@OPERATION": "EQ",
                            "@CONDITION": "OR"
                        },
                        {
                            "@FIELD_NAME": "VEHICLE_USE",
                            "@FIELD_VALUE": "ALL",
                            "@OPERATION": "EQ",
                            "@CONDITION": ""
                        },
                        {
                            "@FIELD_NAME": "",
                            "@FIELD_VALUE": "",
                            "@OPERATION": "CLSPRNTHS",
                            "@CONDITION": "AND"
                        },
                        /******/
                        {
                            "@FIELD_NAME": "",
                            "@FIELD_VALUE": "",
                            "@OPERATION": "OPNPRNTHS",
                            "@CONDITION": ""
                        },
                        {
                            "@FIELD_NAME": "VEHICLE_BODY",
                            "@FIELD_VALUE": vehBodyCode,
                            "@OPERATION": "EQ",
                            "@CONDITION": "OR"
                        },
                        {
                            "@FIELD_NAME": "VEHICLE_BODY",
                            "@FIELD_VALUE": "ALL",
                            "@OPERATION": "EQ",
                            "@CONDITION": ""
                        },
                        {
                            "@FIELD_NAME": "",
                            "@FIELD_VALUE": "",
                            "@OPERATION": "CLSPRNTHS",
                            "@CONDITION": "AND"
                        }
                    ]
                }
            }
        }

    }
    //VK011 Validation to check if the selected benefit code is allowed for the Risk
    validateBenefitBasedonL06(benefitCode) {
        let indicator6Flag: String;
        let flag: String;
        let risk: String;
        let filters = [
            { "@FIELD_NAME": 'DESCITEM', "@FIELD_VALUE": this.riskObj.vehicalClass + benefitCode, '@OPERATION': 'EQ', '@CONDITION': 'AND' }
        ];
        let request: GetLOVData = new GetLOVData().getLovRequest('ALL', 'MOTOR', 'ALL', 'ALL', 'NEW', 'FLAG', 'Add Benefit Flag', 'LOV', filters, {}, []);
        let reqs = this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, null, null, false, { comp: this });
        reqs.success((resp) => {
            if (resp.tuple) {
                indicator6Flag = resp.tuple.old.T9133.ZFLAG06A.toString();
                if (indicator6Flag == 'Y') {
                    let replacefields = [
                        { "@FIELD_NAME": 'VCBNFT', "@FIELD_VALUE": "'" + this.riskObj.vehicalClass + benefitCode + "'", '@OPERATION': 'PARAM' },
                        { "@FIELD_NAME": 'BNFTCD', "@FIELD_VALUE": "'" + benefitCode + "'", '@OPERATION': 'PARAM' },
                        { "@FIELD_NAME": 'RISK', "@FIELD_VALUE": "'" + this.riskObj.riskType + "'", '@OPERATION': 'PARAM' }
                    ];
                    let request1: GetLOVData = new GetLOVData().getLovRequest('ALL', 'MOTOR', 'ALL', 'ALL', 'NEW', 'ALL', 'Add Benefit Products', 'LOV', [], {}, replacefields);
                    let prom = this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request1, null, null, false, { comp: this });
                    prom.success((resp) => {
                        if (resp.tuple) {
                            risk = resp.tuple.old.TABLE.RC.toString();
                            if (this.riskObj.riskType == risk) {
                                flag = "Y";
                            } else {
                                flag = "N";
                            }
                        } else {
                            flag = "N";
                        }
                    });
                    prom.error((error) => {
                        this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error while Validating Benifit Codes.", -1));
                    });
                }
            }
            else
                flag = "Y";
        });
        reqs.error((error) => {
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error while Validating Benifit Code.", -1));
        });
        return flag;
    }

    private validateIfAdditionalBenefitAdded(benefitCode) {
        //VK011
        let flag = this.validateBenefitBasedonL06(benefitCode);
        if (flag == 'N') {//VK011
            this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Benefit code " + benefitCode + " is only allowed for MMP Product.", 10000));
            return true;
        }

        // KA002- START MYS-2019-0924 Need to block prompt alert message on adding E111 benefit if ncd percent = 0; START
        if (benefitCode == "E111" && (numeral(this.riskObj.ENCDDetails.nextNcdPercent).format('0') == '0' ||
            this.riskObj.ENCDDetails.nextNcdPercent == undefined) && ['PC', 'PT', 'PF'].indexOf(this.riskObj.vehicalClass) != -1) {
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Additional Benefit E111 cannot be added if NCD percentage is 0%", 10000));
            return true;
        }
        //KA002- END        
        if (benefitCode == "ALL" && this.riskObj.CI == "MY1") {
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Benefit ALL is not allowed if Certificate of Insurance is MY1", 10000));
            return true;
        }
        else if (this.clientDetails.client.genericDetails.clienttype == 'C' && (this.riskObj.riskType == 'MPC' || this.riskObj.riskType == 'MPD' || this.riskObj.riskType == 'MMP' || this.riskObj.riskType == 'MMF') && benefitCode == 'ND') { //AL001 //VK006 //MS001
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Benefit ND is not allowed if client is of type Corporate", 10000));
            return true;
        }
        else if (this.clientDetails.client.genericDetails.clienttype == 'P' && (this.riskObj.riskType == 'MPC' || this.riskObj.riskType == 'MPD' || this.riskObj.riskType == 'MMP' || this.riskObj.riskType == 'MMF') && benefitCode == 'ANY') { //AL001 //VK006 //MS001
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Benefit ANY is not allowed if client is of type Individiual ", 10000));
            return true;
        }
        /* SR001 Changes Starts */
        else if (this.riskObj.riskType == 'MPC' || this.riskObj.riskType == 'MPF' || this.riskObj.riskType == 'MPD' || this.riskObj.riskType == 'MMP' || this.riskObj.riskType == 'MMF') {
            //VK006 Added condition for MMP
            if (this.riskObj.riskType == 'MMP' && (benefitCode == 'E25' || benefitCode == 'M011' || benefitCode == 'M012' || benefitCode == 'M013' || benefitCode == 'LLP' || benefitCode == 'E72' || benefitCode == 'M017' || benefitCode == 'E57A' || benefitCode == 'M002' || benefitCode == 'M010')) {
                this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Benefit code " + benefitCode + " is not allowed to add as it is already part of MMP1.", 10000));
                return true;
            }
            //MS001 Added condition for MMF
            if (this.riskObj.riskType == 'MMF' && (benefitCode == 'E25' || benefitCode == 'M011' || benefitCode == 'M012' || benefitCode == 'M013' || benefitCode == 'LLP' || benefitCode == 'E72' || benefitCode == 'M017' || benefitCode == 'E57A' || benefitCode == 'M002' || benefitCode == 'M010')) {
                this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Benefit code " + benefitCode + " is not allowed to add as it is already part of MMF1.", 10000));
                return true;
            }
            //sree MYS-2018-0737 -- start
            if ((this.riskObj.vehicalClass == 'PC' || this.riskObj.vehicalClass == 'PT') && this.riskObj.cover == 'CO') {
                if (this.clientDetails.client.genericDetails.clienttype == 'P' && benefitCode == 'M012') {
                    this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "This benefit code " + benefitCode + " is only allow Corporate client.", 10000));
                    return true;
                }

                if (this.clientDetails.client.genericDetails.clienttype == 'C' && benefitCode == 'M011') {
                    this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "This benefit code " + benefitCode + " is only allow Personal client.", 10000));
                    return true;
                }

                if (this.clientDetails.client.genericDetails.clienttype == 'C' && benefitCode == 'M012' && this.riskObj.driverDetails != undefined && this.riskObj.driverDetails.driverDetail != undefined && this.riskObj.driverDetails.driverDetail.length > 0) {
                    this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "This benefit code " + benefitCode + " is not allowed to add if any Named drivers exists in the risk.", 10000));
                    return true;
                }

                if (benefitCode == 'M011') {
                    let found = this.riskObj.motorItems.motorItem.some(function (el) {
                        return el.code === 'ND';
                    });
                    if (found) {
                        this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Benefit code " + benefitCode + " is can't be added if 'ND' Benefit Code exists in the risk.", 10000));
                        return true;
                    }
                }
            } else if (this.riskObj.cover != 'CO' && (benefitCode == 'M012' || benefitCode == 'M011')) {
                this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Invalid Cover Type.", 10000));
                return true;
            }

            // End

            let yearDifference = Number(new Date().getFullYear()) - Number(this.riskObj.yearManufacture);
            let isInValid = false;
            let message = '';

            if ((benefitCode == 'M004' || benefitCode == 'M005' || benefitCode == 'M006') && this.riskObj.vehicalSumInsured > 100000) {
                message = benefitCode + " Additional Benefit cannot be added if Vehicle Sum Insured is greater than 100K";
                isInValid = true;
            } else if ((benefitCode == 'M007' || benefitCode == 'M008' || benefitCode == 'M009') && this.riskObj.vehicalSumInsured < 100000) {
                message = benefitCode + " Additional Benefit cannot be added if Vehicle Sum Insured is greater than 100K";
                isInValid = true;
            } else if (benefitCode == 'M003') {
                // SR007 - Added the below condition to check for client type
                if (this.clientDetails.client.genericDetails.clienttype == 'C') {
                    this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, benefitCode + " Additional Benefit cannot be added for Corporate Clients", 10000));
                    return true;
                }
                this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Please change the C/I Type to MX22", 10000));
                return false;
            }
            if (!isInValid) {
                switch (benefitCode) {
                    case 'M002':
                        message = "M002 Additional Benefit cannot be added. Please add M010 Benefit.";
                        isInValid = true;
                        break;
                    case 'M004':
                    case 'M007':
                        if (yearDifference < 5 || yearDifference > 7) {
                            message = " Benefit " + benefitCode + " is not allowed if Year of Manufature is not between 5-7 years from Current Year";
                            isInValid = true;
                        }
                        break;
                    case 'M005':
                    case 'M008':
                        if (yearDifference < 8 || yearDifference > 11) {
                            message = " Benefit " + benefitCode + " is not allowed if Year of Manufature is not between 8-11 years from Current Year";
                            isInValid = true;
                        }
                        break;
                    case 'M006':
                    case 'M009':
                        if (yearDifference < 12 || yearDifference > 15) {
                            message = " Benefit " + benefitCode + " is not allowed if Year of Manufature is not between 12-15 years from Current Year";
                            isInValid = true;
                        }
                        break;
                    case 'M010':
                        if (this.riskObj.motorItems.motorItem.findIndex(addBenefit => addBenefit.code === 'M002') != -1) {
                            message = "M010 Additional Benefit cannot be added along with M002";
                            isInValid = true;
                        }
                        break;
                }
            }
            if (isInValid) {
                this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, message, 10000));
                return true;
            }
            /* SR001 Changes Ends */
            //PKU1 MYS-2019-0737 To allow multiple ETC benefit code to be selected 
        } else {
            for (let eachMotorItem of this.riskObj.motorItems.motorItem) {
                if ((eachMotorItem.code == benefitCode && eachMotorItem.code != 'ETC') || (benefitCode == "ALL" && this.riskObj.CI == "MY1")) {
                    return true;
                }
            }
            return false;
        }
    }
    private onChangeVehicleUse(e) {
        this.riskObj.use = e;
        this.riskObj.useDesc = AppUtil.getValueByPathFromAry(e, "VALUE", "DESCRIPTION", this.lovDropDownService.lovDataList.UseOfVehicle);
        this.initiateCIDefaulting();
        if (this.showVehicleBody)
            this.getVehicleBody();
    }

    /* SR001 Changes Starts */
    private hanldeClauseonVehicleClass(selectVehicleClass) {
        if (["HVC", "HVF", "HVT"].indexOf(this.riskObj.riskType) != -1) {
            this.initiateCIDefaulting();
            if (["MN", "MW"].indexOf(selectVehicleClass) != -1) {
                if (!this.validateIfAdditionalBenefitAdded("E39")) {
                    this.setClauses(["E39"], false);
                } else {
                    this.deleteClause(this.riskObj.clauses.clause, 'E39', "clauseCode");
                }
            } else {
                this.deleteClause(this.riskObj.clauses.clause, 'E39', "clauseCode");
            }

            if (selectVehicleClass == "CR") {
                if (this.validateIfAdditionalBenefitAdded("E38") && this.validateIfAdditionalBenefitAdded("E38B")
                    && this.validateIfAdditionalBenefitAdded("E38A")) {
                    this.deleteClause(this.riskObj.clauses.clause, 'E38', "clauseCode");
                    this.setClauses(["E38A"], false);
                } else if (this.validateIfAdditionalBenefitAdded("E38") && (this.validateIfAdditionalBenefitAdded("E38B")
                    || this.validateIfAdditionalBenefitAdded("E38A"))) {
                    this.deleteClause(this.riskObj.clauses.clause, 'E38', "clauseCode");
                } else {
                    this.deleteClause(this.riskObj.clauses.clause, 'E38A', "clauseCode");//AL002
                    this.setClauses(["E38"], false);
                }
            } else {
                this.deleteClause(this.riskObj.clauses.clause, 'E38A', "clauseCode");
                this.deleteClause(this.riskObj.clauses.clause, 'E38', "clauseCode");
            }

            if (selectVehicleClass == "MP") {
                if (this.validateIfAdditionalBenefitAdded("E41") || this.validateIfAdditionalBenefitAdded("E42")) {
                    this.deleteClause(this.riskObj.clauses.clause, 'E39', "clauseCode");
                    (this.validateIfAdditionalBenefitAdded("E41")) ? this.setClauses(["E41"], false) : {};
                    (this.validateIfAdditionalBenefitAdded("E42")) ? this.setClauses(["E42"], false) : {};
                } else if (!this.validateIfAdditionalBenefitAdded("E39")) {
                    this.setClauses(["E39"], false);
                }
            }
        }
    }
    /* SR001 Changes Ends */

    /* //AL002 START
	private deleteDefaultedClausesOnChangeVehicleBody(selectedVehicleBody){
         if(["MN", "MW", "MP"].indexOf(selectedVehicleBody) != -1){ 
               if(this.validateIfAdditionalBenefitAdded("E39")){
					this.deleteClause(this.riskObj.clauses.clause, 'E39', "clauseCode");
				} else {
					  this.setClauses(["E39"], false); //Clause should not be listed, If additional benefit added
				}
            } 
			
		 if(selectedVehicleBody == "CR"){
               if(!this.validateIfAdditionalBenefitAdded("E38")){
					this.deleteClause(this.riskObj.clauses.clause, 'E38', "clauseCode");
				} else {
					  this.setClauses(["E38"], false); //Clause should be listed, If additional benefit added
				}
				
				if(!this.validateIfAdditionalBenefitAdded("E38A")){
					this.deleteClause(this.riskObj.clauses.clause, 'E38A', "clauseCode");
				} else {
					  this.setClauses(["E38A"], false); //Clause should be listed, If additional benefit added
				}
         } 
	}
  //AL002 END */

    private onChangeVehicleBody(e) {
        this.riskObj.vehicleBodyDesc = AppUtil.getValueByPathFromAry(e.target.value, "VALUE", "DESCRIPTION", this.lovDropDownService.lovDataList.VehicleBody);
    }

    private addSpecificBenefitRequest(beneCode) {
        let request: any;
        if (this.riskObj.isVPMS == "Y" || !this.validateIfAdditionalBenefitAdded(beneCode)) {
            request = {
                "cursor": {
                    "@id": "0",
                    "@position": "0",
                    "@numRows": "500",
                    "@maxRows": "99999",
                    "@sameConnection": "false"
                },
                "BRANCH": "ALL",
                "LOB": "MOTOR",
                "BUSINESS_FUNCTION": "NEW BUSINESS",
                "PRODUCT": "ALL",
                "OPERATION": "NEW",
                "FORM_NAME": "ADDTNL_BENEFIT",
                "FORM_FIELD_NAME": "Additional Benefit",
                "FIELD_TYPE": "LOOKUP",
                "ADVANCE_CONFIG_XML": {
                    "FILTERS": {
                        "FILTER": [
                            {
                                "@FIELD_NAME": "A.DESCITEM",
                                "@FIELD_VALUE": beneCode,
                                "@OPERATION": "EQ",
                                "@CONDITION": ""
                            }
                        ]
                    }
                }
            };
            if (this.riskObj.isVPMS == "Y") {
                request.FORM_NAME = "ADDTNL_BENEFIT_VPMS";
            }
            if (this.riskObj.riskType == 'MMP' || this.riskObj.riskType == 'MMF') {
                request.FORM_FIELD_NAME = "VPMSADDTNLBENEFIT";
                request.FORM_NAME = "ADDTNL_BENEFIT";
                request.ADVANCE_CONFIG_XML = {
                    "FILTERS": {
                        "FILTER": [
                            {
                                "@FIELD_NAME": "A.VEHCLS",
                                "@FIELD_VALUE": "PC",
                                "@OPERATION": "EQ",
                                "@CONDITION": "AND"
                            },
                            {
                                "@FIELD_NAME": "A.ADBEN",
                                "@FIELD_VALUE": "''",
                                "@OPERATION": "NOT IN",
                                "@CONDITION": "AND"
                            },
                            {
                                "@FIELD_NAME": "A.ADBEN",
                                "@FIELD_VALUE": "MMP1",
                                "@OPERATION": "LIKE",
                                "@CONDITION": "AND",
                                "@IGNORECASE": "Y"
                            }
                        ]
                    }
                };
            }

        }

        return request;
    }
    private getSpecificBenefitDetails(beneCode, isSystemDefault) {
        var StatisticsData = this._soapService.callCordysSoapService("GetLOVData",
            "http://schemas.opentext.com/lovhandler/v1.0", this.addSpecificBenefitRequest(beneCode), this.addBenefit, this.errorOfAddSpecificBeneft, false, { comp: this, isSystemDefault: isSystemDefault });

    }
    private successOfAddSpecificBeneft(data, scopeObject) {

        scopeObject.addBenefit(data, scopeObject);
    }
    private errorOfAddSpecificBeneft(response, status, errorText, prms) {
        prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, response.responseJSON.faultstring.text, 10000));
    }

    manfactureYearList(number) {
        var year = Number(new Date().getFullYear());
        for (var index = number; index > 0; --index) {
            this.yearOfManfactureList.push(year);
            year--;
        }
    }

    setRiskCode() {
        this.riskCode = this.riskObj.riskType;
        while (this.riskCode.length < 3) {
            this.riskCode = this.riskCode + " ";
        }
    }

    setRiskScreen() {
        let riskType: RiskType = RiskType[this.riskObj.riskType];
        switch (riskType) {
            case RiskType.MCF:
            case RiskType.MCT:
            case RiskType.MCY:
            case RiskType.MPC:
            case RiskType.MMP://VK006 ADDED MMP
            case RiskType.MMF://MS001 ADDED MMF  
            case RiskType.MPF:
            case RiskType.MPT:
            case RiskType.MPD: //AL001 ADDED MPD
                this.riskScreen = "S4814";
                break;
            case RiskType.CV:
            case RiskType.CVF:
            case RiskType.CVT:
            case RiskType.HVC:
            case RiskType.HVF:
            case RiskType.HVT:
            case RiskType.MTC:
            case RiskType.MTF:
            case RiskType.MTT:
                this.riskScreen = "S6240";
        }

        this.riskScreenType = new RiskArray().getArrayByRiskType(this.riskObj.riskType);
    }

    setDataForViewMode() {
        this.riskObj.makeModelNew = (this.riskObj.makeModelNew == undefined || this.riskObj.makeModelNew == "") ? this.riskObj.makeModel : this.riskObj.makeModelNew; //SAF MYS-2018-0245
        this.sumAddlAmt = this.getTotalByProperty("additionalpremium", this.riskObj.motorItems.motorItem);
        if (this.riskObj.CI != undefined || this.riskObj.makeModel != undefined || this.riskObj.use != undefined) {
            this.populateLOVForView();
			/* old 
			this.listForYearofManfacture(this.riskObj.makeModel,"manual");*/
            this.listForYearofManfacture(this.riskObj.makeModelNew, "manual");//SAF MYS-2018-0245
            if (this.riskObj.yearManufacture != undefined) {
				/* old 
				this.getCubicCapacity(this.riskObj.makeModel,"manual"); */
                this.getCubicCapacity(this.riskObj.makeModelNew, "manual");//SAF MYS-2018-0245
            }
            if (this.riskScreen == 'S4814' && this.riskObj.yearManufacture != undefined && this.riskObj.capacityValue != undefined)
                this.getNVIC("manual");

            if (BMSConstants.getBMSType() != BMSType.CoverNote && this.riskObj.trailerRegistration && (this.riskObj.vehicalClass == 'GA' || this.riskObj.vehicalClass == 'GC')) {
                this.isTrailerMode = true;
            }
            else if (BMSConstants.getBMSType() == BMSType.CoverNote && (this.riskObj.trailerRegistration || this.riskObj.CTP == "Y") && (this.riskObj.vehicalClass == 'GA' || this.riskObj.vehicalClass == 'GC')) {
                this.isTrailerMode = true;
            }
            else
                this.isTrailerMode = false;

        }
        if (this.riskObj.vehicalClass == 'AT' || this.riskObj.vehicalClass == 'CT')
            this.enableISM = false;
        if (this.riskObj.driverDetails)
            this.driverAddlPrm = this.riskObj.driverDetails.additionalPremium;
    }

    initializeChildComp() {
        if (!this.riskObj.clauses)
            this.riskObj.clauses = new Clause();
        if (!this.riskObj.motorItems)
            this.riskObj.motorItems = new MotorItems();
        if (!this.riskObj.loadingDetails)
            this.riskObj.loadingDetails = new LoadingComputation();
        if (!this.riskObj.PIAMStatistics)
            this.riskObj.PIAMStatistics = new PIAMStatistics();
        if (this.riskScreen == "S6240") {
            if (!this.riskObj.trailerDetails)
                this.riskObj.trailerDetails = new TrailerDetails();
        }
        if (!this.riskObj.financialInterest)
            this.riskObj.financialInterest = new FinancialInterest();
        if (!this.riskObj.driverDetails || !this.riskObj.driverDetails.driverDetail)
            this.riskObj.driverDetails = new NamedDriver();
        if (!this.riskObj.GSTDetails)
            this.riskObj.GSTDetails = new GSTDetails();
        if (this.riskObj.motorItems.motorItem != undefined && !(this.riskObj.motorItems.motorItem.constructor === Array)) {
            let motorItems: any = this.riskObj.motorItems.motorItem;
            this.riskObj.motorItems.motorItem = [motorItems];
        }
    }


    addBenefit(listOfBenefits, prms) {
        var index = 0;
        var limit, premium;
        let ary = [];
        ary = new AppUtil().getArray(listOfBenefits.tuple);
        if (ary.length == 0)
            ary = new AppUtil().getArray(listOfBenefits);
        for (let benefit of ary) {
            //let viewName: any
            let viewName = (prms.comp.riskObj.isVPMS === 'Y') ? benefit.old.T9133 : benefit.old.T4662;
            /*if(prms.comp.riskObj.riskType === 'MMF'){
            //MS001 - added table config (T7382) for MMF product
            viewName = (prms.comp.riskObj.isVPMS === 'Y') ? benefit.old.T7382 : benefit.old.T4662;
            }
            else{
            viewName = (prms.comp.riskObj.isVPMS === 'Y') ? benefit.old.T9133 : benefit.old.T4662;
            }*/

            if (!prms.comp.validateIfAdditionalBenefitAdded(viewName.DESCITEM)) {
                if (viewName.ZBASTYP == '1') {
                    premium = (prms.comp.riskObj.vehicalSumInsured * viewName.ZBASPER) / 100;
                    limit = viewName.AMTRI;
                }
                else if (viewName.ZBASTYP == '2') {
                    premium = (viewName.AMTRI * viewName.ZBASPER) / 100;
                    limit = viewName.AMTRI;
                }
                else if (viewName.ZBASTYP == '3') {
                    limit = '';
                    premium = '';
                }
                else if (viewName.ZBASTYP == '5') {
                    premium = viewName.AMTRI;
                }
                else {
                    premium = viewName.AMTRI;
                    limit = 0;
                }
                //GA003 START - Modified from M002 to M010
                if (viewName.DESCITEM == 'M010') {
                    //if(viewName.DESCITEM=='M002'){ //AL001 START
                    //GA003 END
                    limit = prms.comp.riskObj.vehicalSumInsured * 0.25;
                } //AL001 END
                prms.comp.getBenifitCodesOfEnabledDescription("AllowChangingAdditionalBenefitDescription", viewName.DESCITEM);//MRA001	


                let found = prms.comp.riskObj.motorItems.motorItem.some(function (el) {
                    return (el.code != 'ETC') ? el.code === viewName.DESCITEM : false;  //PKU1 MYS-2019-0737 To allow multiple ETC benefit code to be selected 
                });
                if (!found) {
                    prms.comp.riskObj.motorItems.motorItem.push({
                        "sequence": index + 1,
                        "code": viewName.DESCITEM,
                        "additionalBenifits": viewName.LONGDESC,
                        "limits": numeral(limit).format(prms.comp.premiumFormat),
                        "additionalpremium": numeral(premium).format(prms.comp.premiumFormat),
                        "isLimitDisable": viewName.ZLMITIND,
                        "isSpecial": viewName.ZHNDLING,
                        "isSystemDefault": prms.isSystemDefault,
                        "etPostingStatus": "N",
                        "isCodeDescriptionEnabled": prms.comp.isCodeDescriptionEnabled //MRA001
                    });
                    index++;
                    prms.comp.setClauses([viewName.DESCITEM], false);
                }
            }

            if (prms.comp.clientDetails) {
                if (prms.comp.clientDetails.client.genericDetails.clienttype == 'P' && prms.comp.riskObj.vehicalClass == 'PC' && viewName.DESCITEM == 'PT') {
                    prms.comp.riskObj.use = '03';
                }
                prms.comp.handleCITypeDefaulting("system");
            }
        }

        let total = prms.comp.getTotalByProperty("additionalpremium", prms.comp.riskObj.motorItems.motorItem);
        if (prms.comp.riskObj.isVPMS === 'N') {
            prms.comp.riskObj.totalPremium = Number(prms.comp.riskObj.premiumNetOfNCB) + Number(total) + Number(prms.comp.riskObj.trailerPremium);
        }
        prms.comp.riskObj.setAllRidersPremium(prms.comp.premiumFormat);
        prms.comp.calculateGST();
        prms.comp.clearPremiumInfo();
        prms.comp.hanldeClauseonVehicleClass(prms.comp.riskObj.vehicalClass);//SR003 - To update default clauses
    }
    //MR001 changes begin
    getBenifitCodesOfEnabledDescription(key: string, benefitCode: string) {
        let prom = this._soapService.callCordysSoapService("GetMsigPropertiesObject", "http://schemas.cordys.com/msig/masterdata/1.0", { "KEY": key }, null, null, false, null);
        prom.success((resp) => {
            let Values = resp.tuple.old.MSIG_PROPERTIES.VALUE.toString();
            if (Values.indexOf(benefitCode) != -1) {
                this.isCodeDescriptionEnabled = 'Y';
            }
            else {
                this.isCodeDescriptionEnabled = 'N';
            }

        });
        prom.error((error) => {
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error while fetching Description Enabled benifit Codes.", -1));
        });
    }
    //MR001 Changes end

    removeBenefit(idx: number, amount: number) {
        let benefit = this.riskObj.motorItems.motorItem[idx];
        if (benefit.code == "ALL" && this.riskObj.CI == "MY3")
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Benefit ALL is Compulsory if Certificate of Insurance is MY3", 10000));
        else {
            if (benefit.code == "M003") { // SR002 Clearing the CI Type on Removing M003 Addon
                this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Please select the new Certificate of Insurance", 5000))
                this.riskObj.CI = "";
            }
            this.riskObj.motorItems.motorItem.splice(idx, 1);
            this.deleteClause(this.riskObj.clauses.clause, benefit.code, "clauseCode");
            this.calculateGST();
            this.clearPremiumInfo();
            this.hanldeClauseonVehicleClass(this.riskObj.vehicalClass);//SR003 - To update default clauses
        }
    }

    deleteClause(ary, clauseCode, prop) {
        let val = undefined;
        if (ary && ary.length > 0) {
            for (var index = 0, assoLength = ary.length; index < assoLength; index++) {
                if (ary[index][prop] != null && ary[index][prop] != "" && ary[index][prop] == clauseCode) {
                    val = index;
                    break;
                }
            }
        }
        if (val != undefined)
            this.clausesComp.removeClause(val, clauseCode);
    }

    setCoverDesc(cover) {
        this.riskObj.cover = cover;
        if (cover != "")
            this.riskObj.coverDesc = AppUtil.getValueByPathFromAry(cover, "VALUE", "DESCRIPTION", this.lovDropDownService.lovDataList.Coverage);
        else
            this.riskObj.coverDesc = cover;
        this.checkReferredRisk();
        //GA005 START
        if (cover != "" && cover == "TP") {
            this.riskObj.vehicalSumInsured = 0;
            this.riskObj.vehicalSumInsuredUI = "0";
        }
        //GA005 End
    }

    calculateDefaultClauseCode(coverValue) {
        this.riskObj.cover = coverValue;
        this.defaultClauseCode = this.riskCode + coverValue + this.riskObj.vehicalClass;
        //VK006 Adding Clause related conditions
        //MS001 Adding Clause related conditions
        if (this.riskObj.riskType == 'MMP' || this.riskObj.riskType == 'MMF') {
            if (this.headerInfo.insuredType == 'Corporate') {
                this.defaultClauseCode = this.riskCode + "CORP"
            } else if (this.headerInfo.insuredType == 'Personal') {
                this.defaultClauseCode = this.riskCode + "INDI"
            }
        }
        if (this.clausesComp)
            this.clausesComp.setDefaultClause(this.defaultClauseCode);
    }

    openBenefitDetailsDialog() {
        if (this.riskObj.vehicalClass) {
            let searchInput = new SearchInput();
            searchInput.isSingleSelect = false;
            searchInput.BRANCH = 'ALL';
            searchInput.BUSINESS_FUNCTION = 'NEW BUSINESS';
            searchInput.FIELD_TYPE = 'LOOKUP';
            searchInput.FORM_FIELD_NAME = (this.riskObj.isVPMS === 'Y') ? 'VPMSADDTNLBENEFIT' : 'Additional Benefit';
            searchInput.FORM_NAME = 'ADDTNL_BENEFIT';
            searchInput.LOB = 'MOTOR';
            searchInput.OPERATION = 'NEW';
            searchInput.PRODUCT = 'ALL';

            if (this.riskObj.motorItems.motorItem.length > 0) {
                let newArr = [];
                for (let item of this.riskObj.motorItems.motorItem) {
                    if (item["code"] != 'ETC')
                        newArr = newArr.concat(item["code"]); //PKU1 MYS-2019-0737 To allow multiple ETC benefit code to be selected 
                }
                let benefitCodes = "'" + newArr.toString().replace(/,/g, "\',\'") + "'";
                searchInput.condition = (this.riskObj.isVPMS === 'Y') ? { "A.VEHCLS": this.riskObj.vehicalClass, "A.ADBEN": benefitCodes } : { "A.VEHCLS": this.riskObj.vehicalClass, "A.DESCITEM": benefitCodes };
            }
            else
                searchInput.condition = (this.riskObj.isVPMS === 'Y') ? { "A.VEHCLS": this.riskObj.vehicalClass, "A.ADBEN": "''" } : { "A.VEHCLS": this.riskObj.vehicalClass, "A.DESCITEM": "''" };

            let input = new ModalInput();
            input = input.get("GenericSearchComponent");
            input.datainput = searchInput;
            input.outputCallback = this.addBenefit;
            input.parentCompPRMS = { comp: this };
            input.heading = "Additional Benefit Details";
            input.icon = "fa fa-file-pdf-o";
            input.containerRef = this.contentArea;
            this.dcl.openLookup(input);
        }
        else
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Please fill Value for Vehicle Class", 3000));

    }

    openLoadingComputationDialog() {
        if (this.riskObj.yearManufacture) {
            if (this.riskObj.loadingDetails.loadingDetail) {  //MYS-2018-1562 
                this.bnmLoadingVal = this.riskObj.bnmValue;
            }
            let lookup = new ModalInput();
            lookup.component = ["LoadingComputationComponent", "app/bms/components/proposal/newbusinessrisks/motorcommercial/dialogs/loadingComputation.module", "LoadingComputationModule"];

            lookup.datainput = {
                effDate: this.headerInfo.effectiveDate,
                yearManf: this.riskObj.yearManufacture,
                code: this.riskObj.vehicalClass + this.riskObj.cover,
                bnmLoadVal: this.bnmLoadingVal,
                claims: this.riskObj.CFY,
                driverList: this.riskObj.driverDetails.driverDetail,
                loadItemsList: this.riskObj.loadingDetails.loadingDetail,
                effectiveDate: this.convertDateForP400(this.headerInfo.effectiveDate),
                origLoadingAmt: this.riskObj.loadingPercentage
            };
            lookup.outputCallback = this.setLoadingAmount;
            lookup.parentCompPRMS = { comp: this };
            lookup.heading = "Loading Computation Details";
            lookup.icon = "fa fa-link";
            lookup.containerRef = this.contentArea;
            this.dcl.openLookup(lookup);
        }
        else {
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Please fill Values for fields Year of Manufacture and Driver Detail Information", 10000));
        }
    }

    setClientInfo() {
        if (this.ndComp)
            this.ndComp.setDriverInfo();
        if (!this.riskObj.occupationCode) {
            if (this.clientDetails.client.genericDetails.clienttype == 'P') {
                this.setLocationDescription(this.clientDetails.client.personalClientDetails.address.city);
                this.riskObj.occupationCode = this.clientDetails.client.personalClientDetails.occupationCode;
                this.riskObj.occupationDescription = this.clientDetails.client.personalClientDetails.occupationDescription;
                /*** Below line added by Rajesh**/
                this.riskObj.insuredIsDriver = "true";
            }
            else if (this.clientDetails.client.genericDetails.clienttype == 'C') {
                this.setLocationDescription(this.clientDetails.client.corporateClientDetails.address.city);
                this.riskObj.occupationCode = this.clientDetails.client.corporateClientDetails.BusinessSec;
                /*** Below line added by Rajesh**/
                this.riskObj.insuredIsDriver = "false";
            }
        }
        if (this.validateEmpty(this.riskObj.occupationCode) && !this.validateEmpty(this.riskObj.occupationDescription))
            this.setOccupationDescription(this.riskObj.occupationCode);
    }

    setLocationDescription(locationCode) {
        if (locationCode) {
            let request: GetLOVData = new GetLOVData();
            request.BRANCH = 'ALL';
            request.LOB = 'MOTOR';
            request.BUSINESS_FUNCTION = 'NEW BUSINESS';
            request.PRODUCT = 'ALL';
            request.OPERATION = 'NEW';
            request.FORM_NAME = 'PRIVATE_MOTOR';
            request.FORM_FIELD_NAME = 'LocationDefault';
            request.FIELD_TYPE = 'LOV';
            request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
            request.ADVANCE_CONFIG_XML.FILTERS = new Filter();

            request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({ "@FIELD_NAME": 'ITEMITEM', "@FIELD_VALUE": locationCode, '@OPERATION': 'EQ', '@CONDITION': 'AND' });
            this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.locationSucccessHandler, this.handleError, true, { comp: this });
        }
    }

    setOccupationDescription(occupationCode) {
        this.riskObj.occupationDescription = occupationCode.description;
        let request: GetLOVData = new GetLOVData();
        request.BRANCH = 'ALL';
        request.LOB = 'ALL';
        request.BUSINESS_FUNCTION = 'NEW BUSINESS';
        request.PRODUCT = 'ALL';
        request.OPERATION = 'NEW';
        request.FORM_NAME = 'ALL';
        request.FORM_FIELD_NAME = 'Occupation';
        request.FIELD_TYPE = 'LOV';
        request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        request.ADVANCE_CONFIG_XML.FILTERS = new Filter();

        request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({ "@FIELD_NAME": 'DESCITEM', "@FIELD_VALUE": this.riskObj.occupationCode, '@OPERATION': 'EQ', '@CONDITION': 'AND' });
        this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.occupationSuccessHandler, this.handleError, true, { comp: this });

    }

    locationSucccessHandler(response, prms) {
        prms.comp.riskObj.location = response.tuple.old.ITEMPF.LOCATION;
    }

    occupationSuccessHandler(response, prms) {
        prms.comp.riskObj.occupationDescription = response.tuple.old.T3644.DESCRIPTION;
    }

    checkReferredRisk() {
		/*this._rcls.setRiskClassification(this.riskObj.riskNumber,"N","").subscribe();
		if((this.riskObj.riskType == 'MPC' || this.riskObj.riskType == 'MPD') && this.riskObj.cover == 'CO') { //AL001
			if((this.headerInfo.insuredAge && (this.headerInfo.insuredAge < 22 || this.headerInfo.insuredAge > 70)) || (this.riskObj.yearManufacture && (Number(new Date().getFullYear()) - Number(this.riskObj.yearManufacture)) > 15)
			|| this.riskObj.vehicleReferredRisk == 'true') {
				this.riskObj.symRiskClassification = "Referred";
				this.riskObj.riskClassification = this.riskObj.symRiskClassification;
			}
			else {
				this.riskObj.symRiskClassification = "Standard";
				this.riskObj.riskClassification = this.riskObj.symRiskClassification;
			}
		}
		else if(['CV','CVF'].indexOf(this.riskObj.riskType) != -1 && this.riskObj.cover == 'CO') {
			if(['GA','GC','AT','CT'].indexOf(this.riskObj.vehicalClass) != -1 && Number(this.riskObj.tonnage) > 15) {
				this.riskObj.symRiskClassification = "Referred";
				this.riskObj.riskClassification = this.riskObj.symRiskClassification;
			}
			else {
				this.riskObj.symRiskClassification = "Standard";
				this.riskObj.riskClassification = this.riskObj.symRiskClassification;
			}
		}
		else {
			this.riskObj.symRiskClassification = "Standard";
			this.riskObj.riskClassification = this.riskObj.symRiskClassification;
		}*/

        this.setRiskClassification(this);
        this.handleRenewalReferredRiskCase();
    }

    setLoadingAmount(loadingData, prms) {
        prms.comp.riskObj.loadingPercentage = loadingData.loading;
        prms.comp.riskObj.loadingDetails.loadingDetail = loadingData.loadList;
        prms.comp.bnmLoadingVal = loadingData.bnmLoad;
        prms.comp.riskObj.bnmValue = loadingData.bnmLoad; // MYS-2018-1562 setting in BO
        prms.comp.onChangeOfLoadPctg();
    }

    listForYearofManfacture(modelCode, flag) {
        if (this.riskObj.makeCode != undefined && modelCode != undefined) {
            this.vehicleVariantList = [];
            this.lovDropDownService.createLOVDataList(["yearManf"]);
            let filterDetails = [new SearchFilter("ZVEHMAKE", this.riskObj.makeCode.trim(), "EQ", "AND"),
            new SearchFilter("ZVEHMODEL", modelCode, "EQ", "AND")];
            let searchFilterNodes = this.lovDropDownService.createSearchFilter(filterDetails);
            let lovFields;
            if (flag == "vixResponse") {


                lovFields = [new LOV_Field("ALL", "MOTOR", "NEW BUSINESS", "ALL", "NEW", "PRIVATE_MOTOR", "YearManfacture", "LOV", searchFilterNodes, "VARNPF", "yearManf", "successCallBackOfYear")];
            }
            else {


                lovFields = [new LOV_Field("ALL", "MOTOR", "NEW BUSINESS", "ALL", "NEW", "PRIVATE_MOTOR", "YearManfacture", "LOV", searchFilterNodes, "VARNPF", "yearManf", null)];
            }

            this.lovDropDownService.util_populateLOV_New(lovFields, this);
        }
    }

    successCallBackOfYear(scopeObject) {
        scopeObject.riskObj.yearManufacture = scopeObject.vixObj.yearManufacture;
        //scopeObject.getCubicCapacity(scopeObject.riskObj.makeModel);
        scopeObject.onChangeYearOfMfct(scopeObject.riskObj.yearManufacture, "vixResponse");
    }

    onChangeYearOfMfct(event, flag) {
        this.clearPremiumInfo();
        if (isNaN(event))
            this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Please fill Valid Value for fields Year of Manufacture", 10000));
        else {
            if (this.riskObj.loadingDetails.loadingDetail.length > 0) {
                this.riskObj.loadingPercentage = 0;
                this.riskObj.loadingDetails.loadingDetail = [];
                this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Please Re-visit Loading Computation.", 10000));
            }
            this.riskObj.yearManufacture = event;
            this.riskObj.capacityValue = "";
			/* old 
			this.getCubicCapacity(this.riskObj.makeModel,flag); */
            this.getCubicCapacity(this.riskObj.makeModelNew, flag);//SAF MYS-2018-0245
            this.checkReferredRisk();
            if (this.riskScreen == 'S4814') {
                this.riskObj.NVIC = "";
                this.riskObj.variant = "";
            }
        }
    }

    private populateLOVs(): void {
        this.lovDropDownService.createLOVDataList(["riCode", "VehicleClass", "VehicleBody", "make", "condition", "excessType", "permittedDriver", "location", "Occupation", "riskOccupationCode", "states"]);

        let riTypeFilterDetails = [new SearchFilter("DESCITEM", "MV", "STARTSWITH", "AND")];
        let riTypeSearchFilterNodes = this.lovDropDownService.createSearchFilter(riTypeFilterDetails);

        let riskTypeFilterDetails = [new SearchFilter("CNTTYPE", this.riskCode, "EQ", "AND")];
        if ("P" == this.clientDetails.client.genericDetails.clienttype)
            riskTypeFilterDetails.push(new SearchFilter("VEHCLS", "PT", "NTEQ", "AND"));
        let riskTypeSearchFilterNodes = this.lovDropDownService.createSearchFilter(riskTypeFilterDetails);

        let vehConditionFilter = [new SearchFilter("DESCITEM", "N", "EQ", "AND")];
        let nvVehCondition = [new SearchFilter("DESCITEM", "N", "NTEQ", "AND")];
        let vehConditionFilterNodes = (this.caseInfo.businessFunction == "CoverNote") ? this.lovDropDownService.createSearchFilter(vehConditionFilter) : this.lovDropDownService.createSearchFilter(nvVehCondition);
        let lovFields = [
            new LOV_Field("ALL", "MOTOR", "NEW BUSINESS", "ALL", "NEW", "PRIVATE_MOTOR", "RI Retention Code", "LOV", riTypeSearchFilterNodes, "DESCPF", "riCode", null),
            new LOV_Field("ALL", "MOTOR", "NEW BUSINESS", "ALL", "NEW", "PRIVATE_MOTOR", "Vehicle Class", "LOV", riskTypeSearchFilterNodes, "T4663", "VehicleClass", "setVehicleClassDesc"),
            //new LOV_Field("ALL", "MOTOR", "NEW BUSINESS", "ALL", "NEW", "PRIVATE_MOTOR", "Vehicle Body", "LOV", [], "DESCPF", "VehicleBody",null), // SR003
            new LOV_Field("ALL", "MOTOR", "NEW BUSINESS", "ALL", "NEW", "PRIVATE_MOTOR", "Make", "LOV", [], "DESCPF", "make", null),
            new LOV_Field("ALL", "MOTOR", "NEW BUSINESS", "ALL", "NEW", "PRIVATE_MOTOR", "Condition", "LOV", vehConditionFilterNodes, "DESCPF", "condition", null),
            new LOV_Field("ALL", "MOTOR", "NEW BUSINESS", "ALL", "NEW", "PRIVATE_MOTOR", "Excess Type", "LOV", [], "DESCPF", "excessType", "setExcessDesc"),
            new LOV_Field("ALL", "MOTOR", "NEW BUSINESS", "ALL", "NEW", "PRIVATE_MOTOR", "Permitted Driver", "LOV", [], "DESCPF", "permittedDriver", null),
            new LOV_Field("ALL", "MOTOR", "NEW BUSINESS", "ALL", "NEW", "PRIVATE_MOTOR", "Location", "LOV", [], "DESCPF", "location", null),
            new LOV_Field("ALL", "MOTOR", "NEW BUSINESS", "ALL", "NEW", "NAMED_DRIVER", "Occupation", "LOV", [], "DESCPF", "Occupation", null),
            new LOV_Field("ALL", "FIRE", "NEW BUSINESS", "ALL", "NEW", "FIRE_IDC", "RiskOccupationCode", "LOV", [], "DESCPF", "riskOccupationCode", null),
            new LOV_Field("ALL", "ALL", "MOTOR_VPMS", "MTR", "ALL", "MOTOR_SCREEN", "State", "LOV", [], "DESCPF", "states", "defaultState")
        ];
        this.lovDropDownService.util_populateLOV_New(lovFields, this);

        // if(!this.riskObj.cover)
        // 	this.defaultCoverageCode();

        if (!this.riskObj.vehicalClass)
            this.defaultVehicleClass();
    }

    private populateLOVForView(): void {
        this.setVehRegClass("manual");
        this.lovDropDownService.createLOVDataList(["model"]);

        let filterDetails = [new SearchFilter("DESCITEM", this.riskObj.makeCode + " ", "STARTSWITH", "AND")];
        let searchFilterNodes = this.lovDropDownService.createFilter(filterDetails);

        let lovFields = [new LOV_Field("ALL", "MOTOR", "NEW BUSINESS", "ALL", "NEW", "PRIVATE_MOTOR", "Model", "LOV", searchFilterNodes, "DESCPF", "model", null)];
        this.lovDropDownService.util_populateLOV(lovFields, this);

        if (this.riskObj.trailerDetails && this.riskObj.trailerDetails.makeCode) {
            this.lovDropDownService.createLOVDataList(["trailerModel"]);
            let filterDetails = [new SearchFilter("DESCITEM", this.riskObj.trailerDetails.makeCode + " ", "STARTSWITH", "AND")];
            let searchFilterNodes = this.lovDropDownService.createFilter(filterDetails);

            let lovFields = [new LOV_Field("ALL", "MOTOR", "NEW BUSINESS", "ALL", "NEW", "PRIVATE_MOTOR", "Model", "LOV", searchFilterNodes, "DESCPF", "trailerModel", null)];
            this.lovDropDownService.util_populateLOV(lovFields, this);
        }
    }

    checkBlackList() {
        if (this.riskObj.PIAMStatistics.chassisNo && this.headerInfo.effectiveDate) {
            let request: GetLOVData = new GetLOVData();
            request.BRANCH = 'ALL';
            request.LOB = 'MOTOR';
            request.BUSINESS_FUNCTION = 'NEW BUSINESS';
            request.PRODUCT = 'ALL';
            request.OPERATION = 'NEW';
            request.FORM_NAME = 'PRIVATE_MOTOR';
            request.FORM_FIELD_NAME = 'Blacklisted Vehicle';
            request.FIELD_TYPE = 'LOV';
            request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
            request.ADVANCE_CONFIG_XML.FILTERS = new Filter();

            request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({ "@FIELD_NAME": 'CHASSI', "@FIELD_VALUE": this.riskObj.PIAMStatistics.chassisNo, '@OPERATION': 'EQ', '@CONDITION': 'AND' },
                { "@FIELD_NAME": 'RLSEDATE', "@FIELD_VALUE": moment(this.headerInfo.effectiveDate, "YYYY-MM-DD").format("YYYYMMDD"), '@OPERATION': 'GT', '@CONDITION': 'AND' });
            this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.blackListSuccessHandler, this.handleError, true, { comp: this });
        }
    }

    blackListSuccessHandler(response, prms) {
        if (response.tuple.old.ZBLVPF.FLAG > 0) {
            let result = response.tuple.old.ZBLVPF;
            prms.comp.blackListIndicatorUI = true;
            prms.comp.riskObj.blackListIndicator = 'true';
            prms.comp.riskObj.blackListReason = result.REMARKS;
            prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Selected Vehicle is BlackListed in Policy Inception Date.", 5000));
        }
        else {
            prms.comp.blackListIndicatorUI = false;
            prms.comp.riskObj.blackListIndicator = 'false';
        }
    }

    setRIMethod(value) {
        this.riskObj.RIMethod = (value == "Yes") ? "8" : "1";
        this._riService.setRI().subscribe();
    }

    onClickISM() {

        this.clearPremiumInfo();
        if (this.riskObj.PIAMStatistics.chassisNo == undefined || this.riskObj.capacityValue == undefined || this.riskObj.vehicalClass == undefined || this.riskObj.makeModel == undefined ||
            this.riskObj.makeCode == undefined || this.riskObj.yearManufacture == undefined) {
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Please fill Values for fields Make, Model, Class, Year of Manufacture, Capacity Value and Chassis Number", -1));
        }
        else if ((this.riskObj.registrationNumber == undefined || this.riskObj.registrationNumber == '') && BMSConstants.getBMSType() != BMSType.CoverNote) {
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Please fill Values for Registration Number.", -1));
        }
		/* else if((this.riskObj.riskType == 'MPC' || this.riskObj.riskType == 'MPF' || this.riskObj.riskType == 'MPT') && (this.riskObj.variant==undefined || this.riskObj.variant==''))
		{
			this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR,"Please select Vehicle Variant and proceed", -1));
		} */
        else {
            //VK006 Added MMP Conditions
            //MS001 Added MMF Conditions
            // added below condition for prod issue.
            if ((this.riskObj.riskType == 'MPC' || this.riskObj.riskType == 'MPF' || this.riskObj.riskType == 'MPT' || this.riskObj.riskType == 'MPD' || this.riskObj.riskType == 'MMP' || this.riskObj.riskType == 'MMF') && (this.riskObj.variant == undefined || this.riskObj.variant == '')) {
                this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "ESI service is not Invoked, Vehicle variant should be selected to call ESI service.", -1));
            }
            //GA007 added Cover = 'TF'
            else if ((this.riskObj.cover == 'CO' || this.riskObj.cover == 'TF') && (this.riskObj.riskType == 'MPC' || this.riskObj.riskType == 'MPF' || this.riskObj.riskType == 'MPD' || this.riskObj.riskType == 'MMP' || this.riskObj.riskType == 'MMF')) {

                let regNo = (this.riskObj.registrationNumber == undefined || this.riskObj.registrationNumber == '') ? 'WNG2516' : this.riskObj.registrationNumber;
                let abiParams: ABIRequest = new ABIRequest("B" + Math.random().toString().substring(2, 9), regNo, this.riskObj.vehicalClass,
                    this.riskObj.yearManufacture, this.riskObj.makeCode, this.riskObj.makeModel, this.riskObj.capacityValue, this.riskObj.PIAMStatistics.chassisNo,
                    this.convertDateForP400(this.headerInfo.effectiveDate), this.sourceName, this.headerInfo.agentCode, this.riskObj.cover, (this.riskObj.EW == 'W') ? "WEST" : "EAST",
                    this.riskObj.NVIC != undefined ? this.riskObj.NVIC : ''); //MSU001 : MYS-2019-0984 - Cover and Region updated
                this._soapService.callCordysSoapService("getABIReqDetails", "http://ws.msig.com.my", { abiRequest: abiParams }, this.ESISuccessHandler, this.ESIErrorHandler, true, { curcomp: this });

            }
            if (this.riskObj.vehicalClass != 'AT' && this.riskObj.vehicalClass != 'CT' && (!(this.riskObj.ENCDDetails != undefined && this.isResponseCodeValid(this.riskObj.ENCDDetails.respCode)))) {
                //this.riskObj.cover
                let ncdParams: NCDRequest = new NCDRequest(this.headerInfo.agentCode, "3", this.riskObj.PIAMStatistics.chassisNo, this.riskObj.registrationNumber, this.getDocType(), this.getIdNo(), "", "",
                    this.riskObj.PIAMStatistics.previousInsurer, this.riskObj.PIAMStatistics.previousPolicyNumber, "", this.riskObj.PIAMStatistics.vehicalRegNo, this.riskObj.riskType,
                    "BP" + new Date().valueOf(), this.sourceName, this.riskObj.vehClassCode, this.riskObj.use);
				/*let ncdParams:NCDRequest = new NCDRequest("KL0001-A", "3", "PM2M301S002054425", "WPC8040", this.getDocType() , "850902146203", "", "", "86145942",  "", 
						"WPC8040", this.riskObj.riskType, "BP" + new Date().valueOf(), "BPM", "02" , "01" );*/
                this._soapService.callCordysSoapService("getNCDReqDetails", "http://ws.msig.com.my", { request: ncdParams }, this.NCDSuccessHandler, this.NCDErrorHandler, true, { curcomp: this });
            }
        }
    }

    isResponseCodeValid(code) {
        if (code && ['ENQ000', 'ENQ014', 'ENQ016', 'ENQ017', 'ENQ030', 'ENQ044', 'ENQ048', 'ENQ051', 'ENQ057', 'ENQ060', 'ENQ062', 'ENQ063', 'ENQ066', 'ENQ067',
            'ENQ078', 'ENQ079', 'ENQ080', 'ENQ082', 'ENQ089', 'ENQ090', 'ENQ091', 'ENQ092', 'ENQ093', 'ENQ096', 'ENQ097', 'ENQ098'].indexOf(code) != -1) {
            return true
        }
        return false;
    }

    getDocType(): string {
        return "ENQ";
    }

    getIdNo(): string {
        let idNo: string = "";
        if (this.clientDetails.client.itemNo && this.riskObj.ENCDDetails != undefined && this.riskObj.ENCDDetails.respCode == 'ENQ008')
            this._soapService.callCordysSoapService("GetClientDetailsRequest", "http://schemas.insurance.com/businessobject/1.0/", { "itemNo": this.clientDetails.client.itemNo, "type": this.clientDetails.client.genericDetails.clienttype },
                this.getProspectDataCallBack, this.handleError, false, { comp: this });
        if (this.clientDetails) {
            if (this.clientDetails.client.genericDetails.clienttype == 'C')
                idNo = this.clientDetails.client.corporateClientDetails.BusinessRegNo;
            else if (this.clientDetails.client.genericDetails.clienttype == 'P') {
                if (this.clientDetails.client.personalClientDetails.NRICNo)
                    idNo = this.clientDetails.client.personalClientDetails.NRICNo;
                else if (this.clientDetails.client.personalClientDetails.IdNumber)
                    idNo = this.clientDetails.client.personalClientDetails.IdNumber;
            }
        }
        return idNo.replace(/[-]/g, "");
    }

    getProspectDataCallBack(response, prms) {
        if (response.success.client.genericDetails.clienttype == 'C')
            prms.comp.clientDetails.client.corporateClientDetails.BusinessRegNo = response.success.client.corporateClientDetails.BusinessRegNo;
        else if (response.success.client.genericDetails.clienttype == 'P') {
            if (response.success.client.personalClientDetails.NRICNo)
                prms.comp.clientDetails.client.personalClientDetails.NRICNo = response.success.client.personalClientDetails.NRICNo;
            else if (response.success.client.personalClientDetails.IdNumber)
                prms.comp.clientDetails.client.personalClientDetails.IdNumber = response.success.client.personalClientDetails.IdNumber;
        }
    }

    openeSIDetailDialog() {
        if (this.riskObj.cover == 'CO' && (this.riskObj.riskType == 'MPC' || this.riskObj.riskType == 'MPF' || this.riskObj.riskType == 'MPD' || this.riskObj.riskType == 'MMP' || this.riskObj.riskType == 'MMF')) { //AL001 ADDED MPD //VK006 //MS001
            if (!this.riskObj.ESIDetails)
                this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Invoke Call ISM Service before viewing eSIDetail", 10000));
            else {
                let lookup = new ModalInput();
                lookup.component = ["ESIDetailsComponent", "app/bms/components/proposal/newbusinessrisks/motorcommercial/dialogs/eSIDetails.module", "ESIDetailsModule"];
                lookup.datainput = { esiDetails: this.riskObj.ESIDetails };
                lookup.parentCompPRMS = { comp: this };
                lookup.heading = "eSI Details";
                lookup.icon = "fa fa-link";
                lookup.containerRef = this.contentArea;
                this.dcl.openLookup(lookup);
            }
        }
        else {
            this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "ESI Details - ISM Service Call is not Applicable for Risk Type : " + this.riskObj.riskType + " And Coverage Type : " + this.riskObj.cover, 10000));
        }
    }

    openeNCDDetailDialog() {
        if (!this.riskObj.ENCDDetails.respCode)
            this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Invoke Call ISM Service before viewing eNCDDetail", 10000));
        else {
            let lookup = new ModalInput();
            lookup.component = ["ENCDDetailsComponent", "app/bms/components/proposal/newbusinessrisks/motorcommercial/dialogs/eNCDDetails.module", "ENCDDetailsModule"];
            lookup.datainput = { encdDetails: this.riskObj.ENCDDetails };
            lookup.parentCompPRMS = { comp: this };
            lookup.heading = "eNCD Details";
            lookup.icon = "fa fa-link";
            lookup.containerRef = this.contentArea;
            this.dcl.openLookup(lookup);
        }
    }

    editAdditionalBenifit(idx) {
        let lookup = new ModalInput();
        lookup.component = ["AdditionalBenefitsComponent", "app/bms/components/proposal/newbusinessrisks/motorcommercial/dialogs/additionalBenefits.module", "AdditionalBenefitsModule"];;
        lookup.datainput = { addnlBenefits: this.riskObj.motorItems.motorItem[idx], index: idx };
        lookup.parentCompPRMS = { comp: this };
        lookup.outputCallback = this.editAddnlBenfCallback;
        lookup.heading = "Additional Benefit Details";
        lookup.containerRef = this.contentArea;
        lookup.icon = "fa fa-link";
        this.dcl.openLookup(lookup);
    }
    editAddnlBenfCallback(response, prms) {

        prms.comp.riskObj.motorItems.motorItem[response.index] = response.item;
    }

    ESISuccessHandler(response, prms) {
        let data = response.getABIReqDetailsReturn;
        //GA007	START
        if (prms.curcomp.riskObj.cover == 'TF') {
            prms.curcomp.riskObj.esiRVOrg = numeral(data.recommendedValue).format(prms.curcomp.siFormat);
            data.recommendedValue = 0;
        }
        //GA007 END
        prms.curcomp.riskObj.esiRV = numeral(data.recommendedValue).format(prms.curcomp.siFormat);
        prms.curcomp.riskObj.esiRVFormattedValue = numeral(data.recommendedValue).format(prms.curcomp.siCalcFormat);//MR002
        //VK006 Added MMP
        //MS001 Added MMF
        if ((BMSConstants.getBMSType() != BMSType.CoverNote) || (BMSConstants.getBMSType() == BMSType.CoverNote && (['MPC', 'MPD', 'MMP', 'MMF'].indexOf(prms.curcomp.riskObj.riskType) == -1))) {
            if (prms.curcomp.validateEmpty(data.recommendedValue) && numeral().unformat(data.recommendedValue) > 0) {

                prms.curcomp.riskObj.vehicalSumInsured = data.recommendedValue;
                prms.curcomp.riskObj.vehicalSumInsuredUI = data.recommendedValue;
                /****
                Added by Rajesh for RedMine Case 186 on 03-Nov-2016
                --add clause E87 && remove clause E113
                ****/
                prms.curcomp.setClauses(["E87"], false);
                prms.curcomp.deleteClause(prms.curcomp.riskObj.clauses.clause, 'E113', "clauseCode");



            }
            else {
                prms.curcomp.riskObj.vehicalSumInsured = data.curMktValue;
                prms.curcomp.riskObj.vehicalSumInsuredUI = data.curMktValue;
				/****
				Added by Rajesh for RedMine Case 186 on 03-Nov-2016
				--add clause E113 && remove clause E87
				****/
                prms.curcomp.setClauses(["E113"], false);
                prms.curcomp.deleteClause(prms.curcomp.riskObj.clauses.clause, 'E87', "clauseCode");
            }
        }
        prms.curcomp.riskObj.esiMV = numeral(data.curMktValue).format(prms.curcomp.siFormat);
        prms.curcomp.riskObj.esiMVOrg = numeral(data.curMktValue).format(prms.curcomp.siCalcFormat);//MR002
        prms.curcomp.riskObj.ESIDetails = new ESIDetails();
        prms.curcomp.riskObj.ESIDetails.recommendVal = data.recommendedValue;
        prms.curcomp.riskObj.ESIDetails.sumInsValue = data.sumInsValue;
        prms.curcomp.riskObj.ESIDetails.marketVal = data.curMktValue;
        prms.curcomp.riskObj.ESIDetails.indicator = data.indicator;
        prms.curcomp.riskObj.ESIDetails.insCode = data.insCode;
        prms.curcomp.riskObj.ESIDetails.respCode = data.respCode;
        if (data.respCode)
            prms.curcomp.riskObj.ESIDetails.respCodeDesc = data.respCode.substr(3, 6);
        prms.curcomp.riskObj.ESIDetails.eSIEffective = data.polEffDate;
        prms.curcomp.riskObj.ESIDetails.dateReq = data.respDate;
        prms.curcomp.riskObj.ESIDetails.dateResp = data.respDate;
        prms.curcomp.riskObj.ESIDetails.respMsg = data.respMsg;
        prms.curcomp._alertMsgService.add(new AlertMessage(AlertMessage.INFO, data.respMsg, 2000));
        prms.curcomp.onChangeForSumInsured();
        prms.curcomp.setRiskClassification(prms.curcomp);//checking risk classification for MSIG Reommended value
    }

    NCDSuccessHandler(response, prms) {
        let data = response.getNCDReqDetailsReturn;
        if (prms.curcomp.validateEmpty(data.nextNcdPercent) && numeral().unformat(data.nextNcdPercent) > 0 && !(moment(data.nxtNCDEffDt, "DDMMYYYY") > moment(prms.curcomp.headerInfo.effectiveDate, "YYYY-MM-DD"))) {
            prms.curcomp.riskObj.fleetDiscountPercentage = data.nextNcdPercent;
            prms.curcomp.riskObj.CFY = data.nxtNCDLevel;
            prms.curcomp._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "NCD Inquiry is completed. Click View NCD to see details.", 10000));
        }
        else {
            prms.curcomp.riskObj.fleetDiscountPercentage = '0.0';
            prms.curcomp.riskObj.CFY = '';
            if (prms.curcomp.validateEmpty(data.nxtNCDEffDt))
                prms.curcomp._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "No NCD% allowed due to next NCD percentage is 0", 10000));
            else
                prms.curcomp._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "NCD Inquiry is completed. Click View NCD to see details.", 10000));
        }
        prms.curcomp.appCode = data.appCode;
        prms.curcomp.riskObj.ENCDDetails = new ENCDDetails();
        prms.curcomp.riskObj.ENCDDetails.appCode = data.appCode;
        prms.curcomp.riskObj.ENCDDetails.curNCDEffDt = data.curNCDEffDt;
        prms.curcomp.riskObj.ENCDDetails.curNCDExpDt = data.curNCDExpDt;
        prms.curcomp.riskObj.ENCDDetails.curNCDLevel = data.curNCDLevel;
        prms.curcomp.riskObj.ENCDDetails.curNCDPercent = data.curNCDPercent;
        prms.curcomp.riskObj.ENCDDetails.insCode = data.insCode;
        prms.curcomp.riskObj.ENCDDetails.nextNcdPercent = data.nextNcdPercent;
        prms.curcomp.riskObj.ENCDDetails.nxtNCDEffDt = data.nxtNCDEffDt;
        prms.curcomp.riskObj.ENCDDetails.nxtNCDLevel = data.nxtNCDLevel;
        prms.curcomp.riskObj.ENCDDetails.respCode = data.respCode;
        if (data.respCode)
            prms.curcomp.riskObj.ENCDDetails.respCodeDesc = data.respCode.substr(3, 6);
        prms.curcomp.riskObj.ENCDDetails.preInsCode = data.preInsCode;
        prms.curcomp.riskObj.ENCDDetails.refNo = data.refNo;
        prms.curcomp.onChangeFleetPctg();
    }

    ESIErrorHandler(response, status, errorText, prms) {
        prms.curcomp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, response.responseJSON.faultstring.text, 10000));
    }

    NCDErrorHandler(response, status, errorText, prms) {
        prms.curcomp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, response.responseJSON.faultstring.text, 10000));
    }

    clearFI(event) {
        if (event.target.value == "N") {
            this.riskObj.financialInterest.financialInterestList = [];
            this.deleteClause(this.riskObj.clauses.clause, 'E15', "clauseCode");
        }
        else if (event.target.value == "Y") {
            if (!this.riskObj.financialInterest)
                this.riskObj.financialInterest = new FinancialInterest();
            this.setClauses(["E15"], false);
        }
    }

    handleCTPFlag() {
        if (["GA", "GC", "AT", "CT"].indexOf(this.riskObj.vehicalClass) == -1)
            this.riskObj.CTP = "N";
        if (["AT", "CT"].indexOf(this.riskObj.vehicalClass) != -1)
            this.riskObj.CTP = "Y";
    }

    onChangeTrailer(value) {
        this.handleCTPFlag();
        this.riskObj.trailerRegistration = value;
        this.resetTrailerInfo();
    }

    onCTPChange() {
        this.resetTrailerInfo();
    }

    resetTrailerInfo() {
        if (BMSConstants.getBMSType() != BMSType.CoverNote && this.riskObj.trailerRegistration && (this.riskObj.vehicalClass == 'GA' || this.riskObj.vehicalClass == 'GC')) {
            this.riskObj.trailerDetails.trailerNo = this.riskObj.trailerRegistration;
            this.riskObj.trailerDetails.effectiveDate = this.headerInfo.effectiveDate;
            this.isTrailerMode = true;
        }
        else if (BMSConstants.getBMSType() == BMSType.CoverNote && (this.riskObj.trailerRegistration || this.riskObj.CTP == "Y") && (this.riskObj.vehicalClass == 'GA' || this.riskObj.vehicalClass == 'GC')) {
            this.riskObj.trailerDetails.trailerNo = this.riskObj.trailerRegistration;
            this.riskObj.trailerDetails.effectiveDate = this.headerInfo.effectiveDate;
            this.isTrailerMode = true;
        }
        else {
            this.isTrailerMode = false;
            if (this.riskObj.trailerDetails) {
                this.riskObj.trailerDetails.chassesNo = '';
                this.riskObj.trailerDetails.excess = '';
                this.riskObj.trailerDetails.logBook = '';
                this.riskObj.trailerDetails.makeCode = '';
                this.riskObj.trailerDetails.makeModel = '';
                this.riskObj.trailerDetails.makeCodeDescription = '';
                this.riskObj.trailerDetails.trailerNo = '';
                this.riskObj.trailerDetails.yearOfMake = '';
                this.riskObj.trailerDetails.effectiveDate = '';
                this.riskObj.trailerSumInsured = 0;
                this.riskObj.trailerPremium = 0;
            }
        }
    }

    setCapacityType(vehicleClass) {
        this.riskObj.capacityType = '';
        if (vehicleClass == "PC" || vehicleClass == "MC" || vehicleClass == "PT") {
            this.riskObj.tommangeIndicator = 'CC';
            this.riskObj.capacityType = 'Capacity';
            this.riskObj.tonnage = "";
        } else if (vehicleClass == "HD" || vehicleClass == "BS" || vehicleClass == "BU" || vehicleClass == "BP" || vehicleClass == "BE" || vehicleClass == "BC") { //SR004 
            this.riskObj.tommangeIndicator = 'S';
            this.riskObj.capacityType = 'Seating';
            this.riskObj.tonnage = "";
        } else if (vehicleClass == "TC" || vehicleClass == "GC" || vehicleClass == "GA" || vehicleClass == "AT" || vehicleClass == "CT" || vehicleClass == "TA" || vehicleClass == "RR") {
            this.riskObj.tommangeIndicator = 'T';
            this.riskObj.capacityType = 'Tonnage';
            this.riskObj.tonnage = "";
        } else if (vehicleClass == "TX") {
            this.riskObj.tommangeIndicator = "";
            this.riskObj.capacityType = '';
            this.riskObj.tonnage = "";
        } else if (vehicleClass == "CD" || vehicleClass == "HC") { // SR006 - Added the tonnage indicator for HC and CD
            this.riskObj.tommangeIndicator = "S";
            this.riskObj.capacityType = '';
            this.riskObj.tonnage = "2";
        } else {
            if (vehicleClass == "HV" || vehicleClass == "MT") {
                this.riskObj.tommangeIndicator = "";
                this.riskObj.capacityType = 'Tonnage';
                this.riskObj.tonnage = "1";
            }
        }
    }

    setEngineChassisNo(vehicleClass) {
        if (vehicleClass == "AT" || vehicleClass == "CT") {
            this.riskObj.PIAMStatistics.engineNo = "NA";
            if (this.validateEmpty(this.riskObj.registrationNumber)) {
                this.riskObj.trailerRegistration = this.riskObj.registrationNumber;
            }
        }
    }

    setTrailerMode(vehicleClass) {
        if (vehicleClass == "GA" || vehicleClass == "GC") {
            //this.riskObj.trailerRegistration = this.riskObj.registrationNumber;
            this.isTrailerMode = true;
            this.riskObj.trailerDetails.trailerNo = this.riskObj.trailerRegistration;
        }
        else
            this.isTrailerMode = false;
    }

    setISM(vehicleClass) {
        if (vehicleClass == "AT" || vehicleClass == "CT") {
            this.enableISM = false;
            this.riskObj.vehicalSumInsured = 0;
            this.riskObj.vehicalSumInsuredUI = '0';
            this.onChangeForSumInsured();
        }
        else
            this.enableISM = true;
    }

    setVehicleUse(vehicleClass) {
        if (this.clientDetails) {
            if (this.clientDetails.client.genericDetails.clienttype == 'P' && vehicleClass == 'PC') {
                this.riskObj.use = '';
                this.riskObj.use = '01';
            }
            else if (this.clientDetails.client.genericDetails.clienttype == 'C' && vehicleClass == 'PC') {
                this.riskObj.use = '';
                this.riskObj.use = '02';
            }
            this.handleCITypeDefaulting("system");
            if (this.showVehicleBody) {
                this.getVehicleBody();
            }
            //KU001 Start
            if (vehicleClass == 'PF') {
                this.riskObj.use = '';
                this.riskObj.use = '02';
            }
            //KU001 End
        }
    }

    setVehicleClassDesc() {
        this.riskObj.vehicalClassDesc = AppUtil.getValueByPathFromAry(this.riskObj.vehicalClass, "VALUE", "DESCRIPTION", this.lovDropDownService.lovDataList.VehicleClass);
    }

    onChangeVehicleClass(value, flag) {
        this.riskObj.vehicalClass = value;
        this.checkReferredRisk();
        this.setVehicleClassDesc();
        this.setVehRegClass(flag);
        if (flag == "vixResponse") {
            this.onChangeVehicleUse(this.riskObj.use);
        }
        this.riskObj.trailerRegistration = '';
        this.setCapacityType(value);
        this.riskObj.PIAMStatistics.vehicalBodyCode = '';
        this.riskObj.use = '';
        /***Added by Rajesh to handle Engine Number and Chassis number defaulting based on Vehicle Class***/
        this.setEngineChassisNo(value);
        this.setTrailerMode(value);
        this.setISM(value);
        this.calculateDefaultClauseCode(this.riskObj.cover);
        this.setTonnageSeating(this);
        this.onChangeTrailer(this.riskObj.trailerRegistration);
        this.setVehicleUse(value);
        if (value) {
            this.setCoverage(value, "change");
        }
        this.hanldeClauseonVehicleClass(this.riskObj.vehicalClass); // SR003 - To default the clauses
        this.vehicleBodyAvailablitly(value);
        //KU001 Start
        this.setDefaultForVehicleTypePF(value);
        //KU001 End
    }
    // KU001 Start
    onBlurVehicleClass(value) {
        if (!this.FluxAgentSelected && value == "PF") {
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Cannot select vehicle class – PF", 10000));
            this.riskObj.vehicalClass = '';
        }
    }
    setDefaultForVehicleTypePF(vehicleClass) {
        if (vehicleClass == "PF") {
            this.VehicleTypePF = true;
            this.riskObj.permittedDriver = '';
            this.riskObj.permittedDriver = '03';
            this.riskObj.cover = '';
            this.riskObj.cover = 'CO';
            this.handleCITypeDefaulting("system");
        }
        else {
            this.VehicleTypePF = false;
        }
    }
    //KU001 End

    setVehClassCode(code) {
        if (code != "" && code != undefined) {
            let request: GetLOVData = new GetLOVData();
            request.BRANCH = 'ALL';
            request.LOB = 'MOTOR';
            request.BUSINESS_FUNCTION = 'NEW BUSINESS';
            request.PRODUCT = 'ALL';
            request.OPERATION = 'NEW';
            request.FORM_NAME = 'PRIVATE_MOTOR';
            request.FORM_FIELD_NAME = 'vehClassCode';
            request.FIELD_TYPE = 'LOV';
            request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
            request.ADVANCE_CONFIG_XML.FILTERS = new Filter();

            request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({ "@FIELD_NAME": 'DESCITEM', "@FIELD_VALUE": code, '@OPERATION': 'EQ', '@CONDITION': 'AND' });
            this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.vehClassCodeSuccessHandler, this.handleError, false, { comp: this });
        }
    }

    vehClassCodeSuccessHandler(response, prms) {
        if (response.tuple) {
            prms.comp.riskObj.vehClassCode = response.tuple.old.DESCPF.VALUE;
            let secondClassCode = (parseInt(prms.comp.riskObj.vehClassCode) + Number(10)).toString();
            if (prms.comp.riskObj.PIAMStatistics.vehicalClass != prms.comp.riskObj.vehClassCode && prms.comp.riskObj.PIAMStatistics.vehicalClass != secondClassCode)
                prms.comp.riskObj.PIAMStatistics.vehicalClass = response.tuple.old.DESCPF.VALUE;
        }
    }

    filterModel(event, flag) {
        this.clearPremiumInfo();
        let make;
        if (flag == "manual") {
            make = event.value;
            this.modelDesc = event.description;
        }
        else {
            make = this.vixObj.makeCode;
        }
        this.lovDropDownService.createLOVDataList(["model"]);
        let filterDetails = [new SearchFilter("DESCITEM", make + " ", "STARTSWITH", "AND")];
        let searchFilterNodes = this.lovDropDownService.createFilter(filterDetails);
        let lovFields;
        if (flag == "manual") {
            this.riskObj.makeModel = "";
            this.riskObj.makeModelNew = "";//SAF MYS-2018-0245
            lovFields = [new LOV_Field("ALL", "MOTOR", "NEW BUSINESS", "ALL", "NEW", "PRIVATE_MOTOR", "Model", "LOV", searchFilterNodes, "DESCPF", "model", null)];
        }
        else {
            lovFields = [new LOV_Field("ALL", "MOTOR", "NEW BUSINESS", "ALL", "NEW", "PRIVATE_MOTOR", "Model", "LOV", searchFilterNodes, "DESCPF", "model", "successCallBackForModel")];
        }

        this.lovDropDownService.util_populateLOV(lovFields, this);

        this.riskObj.makeModelDescription = "";
        this.riskObj.yearManufacture = "";
        this.riskObj.capacityValue = "";

        if (this.lovDropDownService.lovDataList.yearManf !== undefined && this.lovDropDownService.lovDataList.yearManf.length !== 0) {
            this.lovDropDownService.lovDataList.yearManf = [];
        }
        if (this.lovDropDownService.lovDataList.cubicCap !== undefined && this.lovDropDownService.lovDataList.cubicCap.length !== 0) {
            this.lovDropDownService.lovDataList.cubicCap = [];
        }
        if (this.riskScreen == 'S4814') {
            this.riskObj.NVIC = "";
            this.riskObj.variant = "";
            if (make == '31' || make == '33')
                this.riskObj.PIAMStatistics.localOrImport = '01';
            else
                this.riskObj.PIAMStatistics.localOrImport = '';
            this.vehicleVariantList = [];
        }
    }

    filterTrailerModel(make) {

        this.lovDropDownService.createLOVDataList(["trailerModel"]);
        let filterDetails = [new SearchFilter("DESCITEM", make.value + " ", "STARTSWITH", "AND")];
        let searchFilterNodes = this.lovDropDownService.createFilter(filterDetails);

        let lovFields = [new LOV_Field("ALL", "MOTOR", "NEW BUSINESS", "ALL", "NEW", "PRIVATE_MOTOR", "Model", "LOV", searchFilterNodes, "DESCPF", "trailerModel", null)];
        this.lovDropDownService.util_populateLOV(lovFields, this);

        this.trailerModelDesc = make.description;
        this.riskObj.trailerDetails.makeCodeDescription = "";
    }

    successCallBackForModel(scopeObject) {
        scopeObject.riskObj.makeModel = scopeObject.vixObj.makeModel;
        scopeObject.riskObj.makeModelNew = scopeObject.vixObj.makeModel;//SAF MYS-2018-0245
        let obj = scopeObject.lovDropDownService.lovDataList.make.filter((item) => item.VALUE == scopeObject.riskObj.makeCode);
        if (obj.length !== 0)
            scopeObject.modelDesc = obj[0].DESCRIPTION;
        //GA006 START
        let obj1 = scopeObject.lovDropDownService.lovDataList.model.filter((item) => item.VALUE == scopeObject.riskObj.makeModelNew);
        if (obj1.length !== 0)
            scopeObject.riskObj.makeModel = obj1[0].VALUE1;
        //GA006 END
        scopeObject.onChangeModel("", "vixResponse");

    }

    onChangeModel(event, flag) {
        this.clearPremiumInfo();
        var textValue;
        if (flag == "manual") {
            textValue = event.description;
			/* old 
			this.riskObj.makeModel = event.value; */
            this.riskObj.makeModel = event.record.VALUE1;//SAF MYS-2018-0245
            //this.riskObj.makeModelNew = event.value;//SAF MYS-2018-0245
            this.riskObj.makeModelNew = event.record.VALUE;//event.value;//SAF MYS-2018-0245 GA008
        }
        else {
			/*
			let obj = this.lovDropDownService.lovDataList.model.filter((item) => item.VALUE==this.riskObj.makeModel);
			*/
            let obj = this.lovDropDownService.lovDataList.model.filter((item) => item.VALUE == this.riskObj.makeModelNew);//SAF MYS-2018-0245
            if (obj.length !== 0)
                textValue = obj[0].DESCRIPTION;
        }

        if (this.riskObj.makeModelDescription != "")
            this.riskObj.makeModelDescription = this.riskObj.makeModelDescription.substring(0, this.riskObj.makeModelDescription.indexOf(" ") + 1) + " " + textValue;
        else
            this.riskObj.makeModelDescription = this.modelDesc + " " + textValue;
        this.riskObj.makeModelDescription = this.riskObj.makeModelDescription.substring(0, 30);
        //this.riskObj.makeModel = event.value;
        this.checkVehicleReferredRisk();
		/* old
		this.listForYearofManfacture(this.riskObj.makeModel,flag); */
        this.listForYearofManfacture(this.riskObj.makeModelNew, flag);//SAF MYS-2018-0245

        if (flag == "manual") {
			/* old
			this.getCubicCapacity(this.riskObj.makeModel,flag); */
            this.getCubicCapacity(this.riskObj.makeModelNew, flag);//SAF MYS-2018-0245			
        }
        this.riskObj.yearManufacture = "";
        this.riskObj.capacityValue = "";
        if (this.riskScreen == 'S4814') {
            this.riskObj.NVIC = "";
            this.riskObj.variant = "";
            this.vehicleVariantList = [];
        }
    }

    onChangeTrailerModel(event) {
        let value = event.target.value;
        let selectedModel = this.lovDropDownService.lovDataList.trailerModel.filter((model) => model.VALUE == value);
        this.riskObj.trailerDetails.makeModel = selectedModel[0].VALUE1;
        this.riskObj.trailerDetails.makeModelNew = selectedModel[0].VALUE;
        let textValue = "";
        if (selectedModel.length > 0) {
            textValue = selectedModel[0].DESCRIPTION;
            if (this.riskObj.trailerDetails.makeCodeDescription != "")
                this.riskObj.trailerDetails.makeCodeDescription = this.riskObj.trailerDetails.makeCodeDescription.substring(0, this.riskObj.trailerDetails.makeCodeDescription.indexOf(" ") + 1) + " " + textValue;
            else
                this.riskObj.trailerDetails.makeCodeDescription = this.trailerModelDesc + " " + textValue;
        }
        else
            this.riskObj.trailerDetails.makeCodeDescription = "";
        this.riskObj.trailerDetails.makeCodeDescription = this.riskObj.trailerDetails.makeCodeDescription.substring(0, 30);
    }

    getCubicCapacity(modelCode, flag) {
        if (this.validateEmpty(this.riskObj.makeCode) && this.validateEmpty(modelCode) && this.validateEmpty(this.riskObj.yearManufacture)) {
            this.lovDropDownService.createLOVDataList(["cubicCap"]);
            let filterDetails = [new SearchFilter("ZVEHMAKE", this.riskObj.makeCode.trim(), "EQ", "AND"),
            new SearchFilter("ZVEHMODEL", modelCode, "EQ", "AND"),
            new SearchFilter("YRMANF", this.riskObj.yearManufacture, "EQ", "AND"),];
            let searchFilterNodes = this.lovDropDownService.createSearchFilter(filterDetails);
            let lovFields;
            if (flag == "vixResponse") {

                lovFields = [new LOV_Field("ALL", "MOTOR", "NEW BUSINESS", "ALL", "NEW", "PRIVATE_MOTOR", "CubicCapacity", "LOV", searchFilterNodes, "VARNPF", "cubicCap", "successofCubicCapacity")];
            }
            else {

                lovFields = [new LOV_Field("ALL", "MOTOR", "NEW BUSINESS", "ALL", "NEW", "PRIVATE_MOTOR", "CubicCapacity", "LOV", searchFilterNodes, "VARNPF", "cubicCap", null)];
            }

            this.lovDropDownService.util_populateLOV_New(lovFields, this);
        }
    }
    successofCubicCapacity(scopeObject) {
        scopeObject.riskObj.capacityValue = scopeObject.vixObj.capacityValue;
        scopeObject.onChangeCapcityVal(scopeObject.riskObj.capacityValue, "vixResponse");

    }

    onChangeCapcityVal(event, flag) {
        this.riskObj.capacityValue = event;
        this.clearPremiumInfo();
        if (isNaN(event))
            this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Please fill Valid Value for fields Capacity", 10000));
        else {
            if (this.riskScreen == 'S4814') {
                this.riskObj.NVIC = "";
                this.riskObj.variant = "";
                this.getNVIC(flag);
            }
        }
    }

    checkVehicleReferredRisk() {
        if (this.validateEmpty(this.riskObj.makeCode) && this.validateEmpty(this.riskObj.makeModel)) {
            let request: GetLOVData = new GetLOVData();
            request.BRANCH = 'ALL';
            request.LOB = 'MOTOR';
            request.BUSINESS_FUNCTION = 'NEW BUSINESS';
            request.PRODUCT = 'ALL';
            request.OPERATION = 'NEW';
            request.FORM_NAME = 'PRIVATE_MOTOR';
            request.FORM_FIELD_NAME = 'MOTOR_REF_RISK';
            request.FIELD_TYPE = 'LOV';
            request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
            request.ADVANCE_CONFIG_XML.FILTERS = new Filter();

            request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({ "@FIELD_NAME": 'VEHICLEMAKE', "@FIELD_VALUE": this.riskObj.makeCode.trim(), '@OPERATION': 'EQ', '@CONDITION': 'AND' },
                { "@FIELD_NAME": 'VEHICLEMODEL', "@FIELD_VALUE": this.riskObj.makeModelNew, '@OPERATION': 'EQ', '@CONDITION': 'AND' },
                { "@FIELD_NAME": 'ITMFRM', "@FIELD_VALUE": moment(this.headerInfo.effectiveDate, "YYYY-MM-DD").format("YYYYMMDD"), '@OPERATION': 'LT', '@CONDITION': 'AND' },
                { "@FIELD_NAME": 'ITMTO', "@FIELD_VALUE": moment(this.headerInfo.effectiveDate, "YYYY-MM-DD").format("YYYYMMDD"), '@OPERATION': 'GT', '@CONDITION': 'AND' });
            this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.vehicleRefRiskSuccessHandler, this.handleError, true, { comp: this });
        }// changed filed from riskObj.makeModel to riskObj.makeModelNew for SAF MYS-2018-0245
    }

    vehicleRefRiskSuccessHandler(response, prms) {
        if (response.tuple) {
            if (response.tuple.old.T7161.FLAG == 'Y') {
                prms.comp.riskObj.vehicleReferredRisk = 'true';
            }
            else {
                prms.comp.riskObj.vehicleReferredRisk = 'false';
            }
        }
        else {
            prms.comp.riskObj.vehicleReferredRisk = 'false';
        }

        prms.comp.checkReferredRisk();
    }

    changePreVehRegNo(event) {
        if (this.riskObj.PIAMStatistics.vehicalCondition == "U") {
            this.riskObj.PIAMStatistics.vehicalRegNo = event.target.value;
        }
        if (this.riskObj.vehicalClass == "AT" || this.riskObj.vehicalClass == "CT") {
            this.riskObj.trailerRegistration = event.target.value;
        }
    }

    setVehiclePrevRegNo(event) {
        if (event.target.value == 'U' && this.validateEmpty(this.riskObj.registrationNumber)) {
            this.riskObj.PIAMStatistics.vehicalRegNo = this.riskObj.registrationNumber;
        }
    }

    getNVIC(flag) {
        this.nvicFlag = flag;
        if (this.validateEmpty(this.riskObj.makeCode) && this.validateEmpty(this.riskObj.makeModel) &&
            this.validateEmpty(this.riskObj.yearManufacture) && this.validateEmpty(this.riskObj.capacityValue)) {
            let request: GetLOVData = new GetLOVData();
            request.BRANCH = 'ALL';
            request.LOB = 'MOTOR';
            request.BUSINESS_FUNCTION = 'NEW BUSINESS';
            request.PRODUCT = 'ALL';
            request.OPERATION = 'NEW';
            request.FORM_NAME = 'PRIVATE_MOTOR';
            request.FORM_FIELD_NAME = 'NVIC';
            request.FIELD_TYPE = 'LOV';
            request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
            request.ADVANCE_CONFIG_XML.FILTERS = new Filter();

            request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({ "@FIELD_NAME": 'ZVEHMAKE', "@FIELD_VALUE": this.riskObj.makeCode.trim(), '@OPERATION': 'EQ', '@CONDITION': 'AND' },
                { "@FIELD_NAME": 'ZVEHMODEL', "@FIELD_VALUE": this.riskObj.makeModelNew, '@OPERATION': 'EQ', '@CONDITION': 'AND' },
                { "@FIELD_NAME": 'YRMANF', "@FIELD_VALUE": this.riskObj.yearManufacture, '@OPERATION': 'EQ', '@CONDITION': 'AND' },
                { "@FIELD_NAME": 'ZCAPCTY', "@FIELD_VALUE": this.riskObj.capacityValue, '@OPERATION': 'EQ', '@CONDITION': 'AND' });
            this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.successHandler, this.handleError, true, { comp: this });
        }// changed filed from riskObj.makeModel to riskObj.makeModelNew for SAF MYS-2018-0245
    }

    validateEmpty(field) {
        if (field != undefined && field != "")
            return true;
        else
            return false;
    }

    successHandler(response, prms) {
        let ary = [];

        if (response.tuple != null && !Array.prototype.isPrototypeOf(response.tuple)) {
            ary = [response.tuple];
        }
        else if (response.tuple != null) {
            ary = response.tuple;
        }
        prms.comp.vehicleVariantList = [];
        for (let variant of ary) {
            let vehVariant: VehicleVariant = {
                "vehVariant": variant.old.VARNPF.VEHVARIANT,
                "nvic": variant.old.VARNPF.ZNVIC,
                "country": variant.old.VARNPF.ZCOUTRY
            };
            prms.comp.vehicleVariantList.push(vehVariant);
        }
        if (prms.comp.nvicFlag == "vixResponse") {
            let obj = prms.comp.vehicleVariantList.filter((item) => item.nvic == prms.comp.vixObj.NVIC);
            if (obj.length !== 0) {
                prms.comp.riskObj.NVIC = "";
                prms.comp.riskObj.variant = "";
                prms.comp.riskObj.NVIC = obj[0].nvic;
                prms.comp.riskObj.variant = obj[0].nvic;
            }
        }
        else {
            if (prms.comp.vehicleVariantList.length == 1) {
                prms.comp.riskObj.NVIC = "";
                prms.comp.riskObj.variant = "";
                prms.comp.riskObj.NVIC = response.tuple.old.VARNPF.ZNVIC;
                prms.comp.riskObj.variant = response.tuple.old.VARNPF.ZNVIC;
                if (!prms.comp.validateEmpty(prms.comp.riskObj.PIAMStatistics.localOrImport)) {
                    if (response.tuple.old.VARNPF.ZCOUTRY == 'MALAYSIA')
                        prms.comp.riskObj.PIAMStatistics.localOrImport = '02';
                    else
                        prms.comp.riskObj.PIAMStatistics.localOrImport = '';
                }
            }

        }
    }

    onChangeVehicleVarinat(value) {
        this.riskObj.NVIC = value;
        if (this.riskObj.PIAMStatistics.localOrImport != '01') {
            for (let item of this.vehicleVariantList) {
                if (value == item.nvic && item.country == 'MALAYSIA') {
                    this.riskObj.PIAMStatistics.localOrImport = '02';
                    break;
                }
                else
                    this.riskObj.PIAMStatistics.localOrImport = '';
            }
        }
        if (this.riskObj.NVIC && this.riskObj.NVIC != "") {
            this.getSeatCapacity(this.riskObj.NVIC);
        }
    }

    handleError(response, status, errorText, prms) {
        prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, response.responseJSON.faultstring.text, 10000));
    }

    defaultExcessType() {
        if (this.riskObj.cover == 'CO' || this.riskObj.cover == 'TF') {
            //VK006 Added MMP Condition
            //MS001 Added MMF Condition
            if (['MPC', 'MPF', 'MCY', 'MCF', 'MPD', 'MMP', 'MMF'].indexOf(this.riskObj.riskType) != -1) { //AL001
                //this.riskObj.excessType = "D";
                this.changeExcessType("D");
            }
            else {
                //this.riskObj.excessType = "A";
                this.changeExcessType("A");
            }
        }
        if (this.riskObj.cover == 'TP') {
            //this.riskObj.excessType = "";	
            this.changeExcessType("");
        }

        this.setExcessDesc(this);
    }

    setExcessDesc(comp) {
        if (AppUtil.isEmpty(comp.riskObj.excessType, false) == false) {
            let exsItems = comp.lovDropDownService.lovDataList.excessType.filter((item) => item.VALUE == comp.riskObj.excessType);
            if (exsItems.length > 0) {
                let exsItem = exsItems[0];
                comp.riskObj.excessTypeDesc = exsItem.DESCRIPTION;
            }
            else
                comp.riskObj.excessTypeDesc = "";
        }
        else
            comp.riskObj.excessTypeDesc = "";
    }

    changeExcessType(value) {
        this.riskObj.excessType = value;
        this.setExcessDesc(this);
        if (value == 'D')
            this.setClauses(["E2"], true);
        else if (value == 'A')
            this.setClauses(["E1"], true);
        else {
            this.deleteClause(this.riskObj.clauses.clause, 'E1', "clauseCode");
            this.deleteClause(this.riskObj.clauses.clause, 'E2', "clauseCode");
        }
    }

    changeExcessAmount() {
        //VK006 Added MMP Condition
        //MS001 Added MMF Condition
        if (["CV ", "CVF", "HVC", "HVF", "MCF", "MCT", "MCY", "MPC", "MPF", "MTC", "MTF", "MPD", "MMP", 'MMF'].indexOf(this.riskCode) != -1) {//AL001
            if (this.validateEmpty(this.riskObj.totalSumInsured) && this.validateEmpty(this.riskObj.capacityValue) && this.validateEmpty(this.riskCode)
                && this.validateEmpty(this.riskObj.vehicalClass) && this.riskObj.excessAmount > 0) {
                let sumIns = numeral().unformat(this.riskObj.totalSumInsured);
                let code = this.riskCode + this.riskObj.vehicalClass;
                let request: GetLOVData = new GetLOVData();
                request.BRANCH = 'ALL';
                request.LOB = 'MOTOR';
                request.BUSINESS_FUNCTION = 'NEW BUSINESS';
                request.PRODUCT = 'ALL';
                request.OPERATION = 'NEW';
                request.FORM_NAME = 'PRIVATE_MOTOR';
                request.FORM_FIELD_NAME = 'EXCESS_AMT';
                request.FIELD_TYPE = 'LOV';
                request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
                request.ADVANCE_CONFIG_XML.FILTERS = new Filter();

                request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({ "@FIELD_NAME": 'DESCITEM', "@FIELD_VALUE": code, '@OPERATION': 'EQ', '@CONDITION': 'AND' },
                    { "@FIELD_NAME": 'SIFR', "@FIELD_VALUE": sumIns, '@OPERATION': 'LTEQ', '@CONDITION': 'AND' },
                    { "@FIELD_NAME": 'SITO', "@FIELD_VALUE": sumIns, '@OPERATION': 'GTEQ', '@CONDITION': 'AND' },
                    { "@FIELD_NAME": 'ZCAPCTYFR', "@FIELD_VALUE": this.riskObj.capacityValue, '@OPERATION': 'LTEQ', '@CONDITION': 'AND' },
                    { "@FIELD_NAME": 'ZCAPCTYTO', "@FIELD_VALUE": this.riskObj.capacityValue, '@OPERATION': 'GTEQ', '@CONDITION': 'AND' });
                this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.exsAmountSuccessHandler, this.handleError, true, { comp: this, exsAmount: this.riskObj.excessAmount, sumIns });
            }
        }
        this.handleRenewalReferredRiskCase();
    }

    exsAmountSuccessHandler(response, prms) {
        if (response.tuple) {
            let exPer = response.tuple.old.T7044.EXPER;
            let exAmt = Number(numeral().unformat(response.tuple.old.T7044.EXAMT));
            let perAmt = Number(numeral().unformat(prms.sumIns) / 100 * numeral().unformat(exPer));
            if (exAmt != 0 && Number(exPer) != 0) {
                if (Number(exAmt) < prms.exsAmount || (Number(prms.exsAmount) > perAmt)) {
                    prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Max. Allowed Value for Entered Excess Amount should be less than Excess Amount : " + Math.min(perAmt, exAmt), 10000));
                    prms.comp.riskObj.excessAmount = 0;
                    return;
                }
            }
            if (Number(exPer) != 0) {
                if (prms.exsAmount > perAmt) {
                    prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Max. Allowed Value for Entered Excess Amount should be less than Excess Amount : " + perAmt, 10000));
                    prms.comp.riskObj.excessAmount = 0;
                    return;
                }
            }
            if (exAmt != 0) {
                if (prms.exsAmount > Number(exAmt)) {
                    prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Max. Allowed Value for Entered Excess Amount should be less than Excess Amount : " + exAmt, 10000));
                    prms.comp.riskObj.excessAmount = 0;
                    return;
                }
            }
        }
    }

    changeTonnage(value) {
        this.clearPremiumInfo();
        // SR003 Change - Added HVC, HVF, MTC, MTT in the below condition
        if (['CV', 'CVF', 'HVC', 'HVF', 'MTC', 'MTT'].indexOf(this.riskObj.riskType) != -1 && this.riskObj.cover == 'CO') {
            this.checkReferredRisk();
        }
    }

    setClauses(clausesList, flag) {
        if (this.clausesComp) {
            //START YPK001
            if (clausesList[0] == "COIN")
                this.clausesComp.addClause(clausesList, '', flag);
            else
                //END YPK001
                this.clausesComp.addClause(clausesList, this.riskObj.excessType, flag);
        }
    }

    defaultVehicleClass() {
        //VK006 ADDED MMP
        //MS001 ADDED MMF
        if (['MPC', 'MPF', 'MPT', 'MPD', 'MMP', 'MMF'].indexOf(this.riskObj.riskType) != -1) {//AL001  
            this.riskObj.vehicalClass = "PC";
            // KU001 Start
            this.checkFluxAgentOrNot();
            if (this.riskObj.riskType == "MPC" && this.FluxAgentSelected) {
                this.riskObj.vehicalClass = "PF";
                this.onChangeVehicleClass("PF", "manual");
            }
            else if (this.riskObj.riskType == "MPC" && !this.FluxAgentSelected && this.headerInfo.insuredType == "Personal") {
                this.riskObj.vehicalClass = "PC";
                this.AgentSelected = true;
            }
            else
                this.riskObj.vehicalClass = "PC";
            //KU001 End
        }
		/*else if( ['MTC','MTF','MTT'].indexOf(this.riskObj.riskType) != -1 )
			this.riskObj.vehicalClass = "MT";
		else if( ['HVC','HVF','HVT'].indexOf(this.riskObj.riskType) != -1 )
			this.riskObj.vehicalClass = "HV";*/
        else if (['MCY', 'MCF', 'MCT'].indexOf(this.riskObj.riskType) != -1)
            this.riskObj.vehicalClass = "MC";
        if (this.riskObj.vehicalClass && this.riskObj.vehicalClass !== "") {
            this.setVehicleClassDesc();
            this.setVehRegClass("manual");
            this.setCoverage(this.riskObj.vehicalClass, "change");
            this.setTonnageSeating(this); //SR003
        }
    }

    //KU001 Start
    checkFluxAgentOrNot() {
        let agentCode = this.headerInfo.agentCode;
        let request: GetLOVData = new GetLOVData();
        request.BRANCH = 'ALL';
        request.LOB = 'MOTOR';
        request.BUSINESS_FUNCTION = 'ALL';
        request.PRODUCT = 'ALL';
        request.OPERATION = 'ALL';
        request.FORM_NAME = 'PRIVATE_MOTOR';
        request.FORM_FIELD_NAME = 'fluxAgentList1';
        request.FIELD_TYPE = 'LOV';
        request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        request.ADVANCE_CONFIG_XML.FILTERS = new Filter();

        request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({ "@FIELD_NAME": 'PFAGNT', "@FIELD_VALUE": agentCode, '@OPERATION': 'LIKE', '@CONDITION': 'AND' });
        this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.successOfFluxAgent, this.handleError, false, { comp: this });
    }
    private successOfFluxAgent(data, prms) {
        if (data && data.tuple && data.tuple.old && data.tuple.old.T9192GA && prms.comp.headerInfo.contractType == "MPC") {
            prms.comp.FluxAgentSelected = true;
        } else {
            prms.comp.FluxAgentSelected = false;
            if (prms.comp.riskObj.riskType == "MPC" && prms.comp.headerInfo.insuredType == "Personal") {
                prms.comp.AgentSelected = true;
            }
        }
    }
    //KU001 End

    setCoverage(vehicalClass, flag) {
        this.lovDropDownService.createLOVDataList(["Coverage"]);
        let lovFields;
        let FilterDetails = [new SearchFilter("VEHCLS", vehicalClass, "EQ", "AND"),
        new SearchFilter("CNTTYPE", this.riskCode, "EQ", "AND")];
        let SearchFilterNodes = this.lovDropDownService.createSearchFilter(FilterDetails);
        if (flag == "change") {
            lovFields = [new LOV_Field("ALL", "MOTOR", "NEW BUSINESS", "ALL", "NEW", "PRIVATE_MOTOR", "Coverage", "LOV", SearchFilterNodes, "T4663", "Coverage", "successCallBackCoverage")];
        }
        else {
            lovFields = [new LOV_Field("ALL", "MOTOR", "NEW BUSINESS", "ALL", "NEW", "PRIVATE_MOTOR", "Coverage", "LOV", SearchFilterNodes, "T4663", "Coverage", null)];
        }

        this.lovDropDownService.util_populateLOV_New(lovFields, this);
    }

    successCallBackCoverage(scopeObject) {
        this.setCoverDesc("");
        if (scopeObject.lovDropDownService.lovDataList.Coverage.length !== 0) {
            scopeObject.defaultCoverageCode();
            this.setCoverDesc(this.riskObj.cover);
            if (!this.riskObj.excessType)
                this.defaultExcessType();
        }

    }

    defaultPermittedDriver() {
        if (["CV", "CVF", "CVT", "HVC", "HVF", "HVT", "MTC", "MTF", "MTT"].indexOf(this.riskObj.riskType) != -1) {
            this.riskObj.permittedDriver = "09";
        }
        else if (["MPT"].indexOf(this.riskObj.riskType) != -1) {
            if (this.clientDetails.client.genericDetails.clienttype == 'C')
                this.riskObj.permittedDriver = "03";
        }
    }

    setPermittedDriver() {
        let noOfDr = this.riskObj.driverDetails.driverDetail.length;
        //this.riskObj.permittedDriver = "" + noOfDr;
        if (this.riskObj.isVPMS == "Y") {
            if (noOfDr > 2)
                this.getSpecificBenefitDetails(this.riskObj.vehicalClass + "ND", "Y");
            else
                this.removeOtherBenefits(this.riskObj.motorItems.motorItem, "code", "ND");
            this.clearPremiumInfo();
        }
    }

    setVehRegClass(flag) {
        if (this.riskObj.vehicalClass != undefined && this.riskObj.vehicalClass != "") {
            this.lovDropDownService.createLOVDataList(["UseOfVehicle", "ciType", "regClass"]);

            let filterDetails = [new SearchFilter("DESCITEM", this.riskObj.vehicalClass, "STARTSWITH", "AND")];
            let searchFilterNodes = this.lovDropDownService.createFilter(filterDetails);

            this.setVehClassCode(this.riskCode + this.riskObj.vehicalClass);

            let shortDescfilterDetails = [new SearchFilter("DESCITEM", "'" + this.riskObj.vehClassCode + "'" + "," + "'" + (parseInt(this.riskObj.vehClassCode) + Number(10)).toString() + "'", "IN", "AND")];
            let shortDescSearchFilterNodes = this.lovDropDownService.createFilter(shortDescfilterDetails);
            let lovFields;
            if (flag == "vixResponse") {
                lovFields = [new LOV_Field("ALL", "MOTOR", "NEW BUSINESS", "ALL", "NEW", "PRIVATE_MOTOR", "Use of Vehicle", "LOV", searchFilterNodes, "DESCPF", "UseOfVehicle", "successCallBackVehicleUse"),
                new LOV_Field("ALL", "MOTOR", "NEW BUSINESS", "ALL", "NEW", "PRIVATE_MOTOR", "CI Type", "LOV", searchFilterNodes, "DESCPF", "ciType", null),
                new LOV_Field("ALL", "MOTOR", "NEW BUSINESS", "ALL", "NEW", "PIAM_STAT", "VehRegClass", "LOV", shortDescSearchFilterNodes, "DESCPF", "regClass", null)];

            } else {
                lovFields = [new LOV_Field("ALL", "MOTOR", "NEW BUSINESS", "ALL", "NEW", "PRIVATE_MOTOR", "Use of Vehicle", "LOV", searchFilterNodes, "DESCPF", "UseOfVehicle", null),
                new LOV_Field("ALL", "MOTOR", "NEW BUSINESS", "ALL", "NEW", "PRIVATE_MOTOR", "CI Type", "LOV", searchFilterNodes, "DESCPF", "ciType", null),
                new LOV_Field("ALL", "MOTOR", "NEW BUSINESS", "ALL", "NEW", "PIAM_STAT", "VehRegClass", "LOV", shortDescSearchFilterNodes, "DESCPF", "regClass", null)];
            }
            this.lovDropDownService.util_populateLOV(lovFields, this);
        }
    }

    successCallBackVehicleUse(scopeObject) {
        scopeObject.riskObj.use = scopeObject.vixObj.use;
        scopeObject.riskObj.useDesc = AppUtil.getValueByPathFromAry(scopeObject.riskObj.use, "VALUE", "DESCRIPTION", scopeObject.lovDropDownService.lovDataList.UseOfVehicle);

        scopeObject.setVehicleUse(scopeObject.riskObj.vehicalClass);

    }

    getTotalByProperty(prop, ary) {
        let total = numeral(0);
        if (ary && ary.length > 0) {
            for (let eachItem of ary) {
                if (eachItem[prop] != null && eachItem[prop] != "")
                    total = total.add(numeral().unformat(eachItem[prop]));
            }
        }
        total = numeral(total).format(this.premiumFormat);
        return total;
    }

    getAllRidersPremium(prop, ary) {
        if (ary && ary.length > 0) {
            for (let eachItem of ary) {
                if (eachItem[prop] != null && eachItem[prop] != "" && eachItem[prop] == "ALL")
                    this.riskObj.allRidersPremium = numeral(eachItem["additionalpremium"]).format(this.premiumFormat);
            }
        }
    }

    onChangeForAddlAmount() {
        let total = this.getTotalByProperty("additionalpremium", this.riskObj.motorItems.motorItem);
        return total;
    }

    onChangeForTotalPremium() {
        if (this.riskObj.isVPMS === 'N') {
            this.riskObj.totalPremium = Number(numeral().unformat(this.riskObj.premiumNetOfNCB)) + Number(this.sumAddlAmt) + numeral().unformat(this.driverAddlPrm) - Number(numeral().unformat(this.riskObj.rebateAmount));
            this.riskObj.totalPremium = numeral(this.riskObj.totalPremium).format(this.premiumFormat);
        }
        this.calculateGST();
    }

    calculateGST() {
        if (this.riskObj.isVPMS === 'N') {
            this.riskObj.originalTotalPremium = Number(numeral().unformat(this.riskObj.premiumNetOfNCB)) + Number(this.getTotalByProperty("additionalpremium", this.riskObj.motorItems.motorItem))
                + numeral().unformat(this.driverAddlPrm);
            this.riskObj.discountedPremium = Number(numeral().unformat(this.riskObj.premiumNetOfNCB)) + Number(this.getTotalByProperty("additionalpremium", this.riskObj.motorItems.motorItem))
                + numeral().unformat(this.driverAddlPrm) - Number(numeral().unformat(this.riskObj.rebateAmount));
            //this.riskObj.gstAmount = 0;//Number(this.riskObj.discountedPremium / 100 * 6); //SAF MYS-2018-0629
            //SST Code
            let tempGSTAmount = (Number(this.riskObj.GST) > 0) ? numeral(numeral((this.riskObj.discountedPremium * Number(this.riskObj.GST)) / 100).format(this.premiumFormat)).value() : 0;
            this.riskObj.gstAmount = (tempGSTAmount > 0) ? numeral(numeral(BMSUtilService.calculatePremiumAmount(tempGSTAmount, "G")).format(this.premiumFormat)).value() : 0;

            let tempSSTAmount = (Number(this.riskObj.SST) > 0) ? numeral(numeral((this.riskObj.discountedPremium * Number(this.riskObj.SST)) / 100).format(this.premiumFormat)).value() : 0;
            this.riskObj.sstAmount = (tempSSTAmount > 0) ? numeral(numeral(BMSUtilService.calculatePremiumAmount(tempSSTAmount, "S")).format(this.premiumFormat)).value() : 0;

            //End
            this.riskObj.gstAmount = numeral(this.riskObj.gstAmount).format(this.premiumFormat);
            //this.riskObj.totalPremium = Number(numeral().unformat(this.riskObj.discountedPremium) + numeral().unformat(this.riskObj.gstAmount));
            this.riskObj.totalPremium = Number(numeral().unformat(this.riskObj.discountedPremium) + numeral().unformat(this.riskObj.gstAmount) + numeral().unformat(this.riskObj.sstAmount));
            this.riskObj.totalPremium = numeral(this.riskObj.totalPremium).format(this.premiumFormat);
        }
        else {
            this.riskObj.gstAmount = (this.riskObj.premiumCalculator == 'M') ? this.msigAnnualPostingPremium.gstPremium : this.vpmsAnnualPostingPremium.gstPremium;
            //SST Code
            this.riskObj.sstAmount = (this.riskObj.premiumCalculator == 'M') ? this.msigAnnualPostingPremium.sstPremium : this.vpmsAnnualPostingPremium.sstPremium;
            //End
            this.riskObj.totalPremium = (this.riskObj.premiumCalculator == 'M') ? Number(numeral().unformat(this.msigAnnualPostingPremium.totalPremium)) + Number(numeral().unformat(this.headerInfo.stampDuty)) : Number(numeral().unformat(this.vpmsAnnualPostingPremium.totalPremium)) + Number(numeral().unformat(this.headerInfo.stampDuty))
        }
        this.onPremiumChange.emit(this.riskObj.totalPremium);
    }

    onChangeDriverAddlPrm(driverPrmValue) {
        this.driverAddlPrm = driverPrmValue;
        this.onChangeForTotalPremium();
    }

    onExInsurerChange(insurerValue) {
        if (insurerValue == '998') {
            this.riskObj.fleetDiscountPercentage = 0.0;
            this.riskObj.CFY = '0';
            this.clearPremiumInfo();
        }
    }
    // checking the 10 % of vechSumInsure should be less then ISM Market 
    OnChangeOfVechSumInsured() {

        this.setRiskClassification(this);
    }
    onChangeForSumInsured() {
        this.clearPremiumInfo();
        //GA001 START
        //GA009 START
        //if( (BMSConstants.getBMSType()!= BMSType.CoverNote) || (BMSConstants.getBMSType()== BMSType.CoverNote && (['MPC','MPD'].indexOf(this.riskObj.riskType)==-1)))
        if (this.riskObj.cover == 'CO' || this.riskObj.cover == 'TF') {
            //GA009 END
            if (this.riskObj.vehicalClass == 'AT' || this.riskObj.vehicalClass == 'CT') {
                this.handleBeforeMinSumIsuredValueForTrailer();
            } else {
                this.handleBeforeMinSumIsuredValue();
            }
        }

        //GA001 END
        if (numeral().unformat(this.riskObj.vehicalSumInsuredUI) >= 0)
            this.riskObj.vehicalSumInsured = numeral().unformat(this.riskObj.vehicalSumInsuredUI);
        this.riskObj.totalSumInsured = numeral().unformat(this.riskObj.vehicalSumInsured) + numeral().unformat(this.riskObj.trailerSumInsured);
        this.riskObj.capitalSumInsured = this.riskObj.totalSumInsured;
        this.riskObj.totalSumInsuredUI = numeral(this.riskObj.totalSumInsured).format(this.siFormat);
        this.riskObj.vehicalSumInsured = numeral(this.riskObj.vehicalSumInsured).format(this.siCalcFormat);
        this.riskObj.vehicalSumInsuredUI = numeral(this.riskObj.vehicalSumInsured).format(this.siFormat);
        this.onChangeOfBasicPrmPctg();
        /*** Added By Rajesh for RedMine case 186 on 03-Nov-2016***/
        //VK006 Added MMP Condition
        //MS001 Added MMF Condition
        if (this.riskObj.cover == 'CO' && (this.riskObj.riskType == 'MPC' || this.riskObj.riskType == 'MPF' || this.riskObj.riskType == 'MPD' || this.riskObj.riskType == 'MMP' || this.riskObj.riskType == 'MMF') && (BMSConstants.getBMSType() != BMSType.CoverNote)) { //AL001 ADDED MPD
            if (numeral().unformat(this.riskObj.vehicalSumInsuredUI) > 0) {

                let vSI = 0;
                let MV: any;
                let RV: any;
                if ((this.riskObj.variant == undefined || this.riskObj.variant == '') && (this.vehicleVariantList == undefined || this.vehicleVariantList.length == 0)) {
                    vSI = numeral().unformat(this.riskObj.vehicalSumInsuredUI);
                    //GA002 START
                    //MV = vSI;
                    //RV = vSI;
                    //GA002 END
                } else if (this.vehicleVariantList.length > 0 && (this.riskObj.variant == undefined || this.riskObj.variant == '')) {
                    vSI = numeral().unformat(this.riskObj.vehicalSumInsuredUI);
                    //GA002 START
                    //MV = vSI;
                    //RV = vSI;
                    //GA002 END
                    this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Vehicle Variant is not selected.", 6000));
                }
                else if (this.riskObj.ESIDetails === undefined) {
                    this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Call eSI Before Changing Sum Insured.", 10000));
                    this.riskObj.vehicalSumInsuredUI = '';
                    return;
                }

                if (this.riskObj.ESIDetails != undefined && this.riskObj.variant != undefined) {
                    vSI = numeral().unformat(this.riskObj.vehicalSumInsuredUI);
                    MV = this.riskObj.ESIDetails.marketVal;
                    RV = this.riskObj.ESIDetails.recommendVal;
                }
                if (vSI == RV) {
                    //if Vehicle Sum Insured == Recommended Value then Add Clause E87 && Remove Clause E113
                    this.setClauses(["E87"], false);
                    this.deleteClause(this.riskObj.clauses.clause, 'E113', "clauseCode");
                } else if (vSI == MV) {
                    //if Vehicle Sum Insured == Market Value then Remove Clause E87 && Add Clause E113
                    this.setClauses(["E113"], false);
                    this.deleteClause(this.riskObj.clauses.clause, 'E87', "clauseCode");
                } else {
                    //if Vehicle Sum Insured != Market Value && Vehicle Sum Insured != Recommended Value then Remove Clause E87 && Remove Clause E113
                    this.deleteClause(this.riskObj.clauses.clause, 'E87', "clauseCode");
                    this.deleteClause(this.riskObj.clauses.clause, 'E113', "clauseCode");
                }
            } else {
                //if Vehicle Sum Insured is undefined then Remove Clause E87 && Remove Clause E113
                this.deleteClause(this.riskObj.clauses.clause, 'E87', "clauseCode");
                this.deleteClause(this.riskObj.clauses.clause, 'E113', "clauseCode");
            }
        }
        //GA001 START
        else {
            //if Vehicle Sum Insured is undefined then Remove Clause E87 && Remove Clause E113
            this.deleteClause(this.riskObj.clauses.clause, 'E87', "clauseCode");
            this.deleteClause(this.riskObj.clauses.clause, 'E113', "clauseCode");
        }
        //GA001 END

        //AL001 Change additional benefit M002 premium on SumInsured change
        //GA003 START
        //let id=this.riskObj.motorItems.motorItem.findIndex(addBenefit => addBenefit.code==='M002');
        let id = this.riskObj.motorItems.motorItem.findIndex(addBenefit => addBenefit.code === 'M010');
        //GA003 END
        if (id >= 0) {
            let limit = this.riskObj.vehicalSumInsured * 0.25;
            let motorItem: any = this.riskObj.motorItems.motorItem[id];
            motorItem.limits = numeral(limit).format(this.premiumFormat);
            this.riskObj.motorItems.motorItem[id] = motorItem;
        }
        //AL001
        /*** Ends here***/
        this.handleRenewalReferredRiskCase();
        //GA001 START
        //GA009 START
        //if( (BMSConstants.getBMSType()!= BMSType.CoverNote) || (BMSConstants.getBMSType()== BMSType.CoverNote && (['MPC','MPD'].indexOf(this.riskObj.riskType)==-1))){
        if (this.riskObj.cover == 'CO' || this.riskObj.cover == 'TF') {
            //GA009 END
            if (this.riskObj.vehicalClass == 'AT' || this.riskObj.vehicalClass == 'CT') {
                this.handleAfterMinSumIsuredValueForTrailer();
            } else {
                this.handleAfterMinSumIsuredValue();
            }
        }
        //GA001 END
    }
    //GA001 START
    handleBeforeMinSumIsuredValue() {
        if (this.riskObj.minSumInsured > 0 && this.riskObj.minSumInsured >= numeral().unformat(this.riskObj.vehicalSumInsuredUI)) {
            this.riskObj.vehicalSumInsured = this.riskObj.minSumInsured;
            this.riskObj.vehicalSumInsuredUI = String(this.riskObj.minSumInsured);
        }
    }
    handleBeforeMinSumIsuredValueForTrailer() {
        if (this.riskObj.minSumInsured > 0 && this.riskObj.minSumInsured >= numeral().unformat(this.riskObj.trailerSumInsured)) {
            this.riskObj.trailerSumInsured = this.riskObj.minSumInsured;
        }
    }
    handleAfterMinSumIsuredValue() {
        if (this.riskObj.minSumInsured > 0 && this.riskObj.minSumInsured >= numeral().unformat(this.riskObj.vehicalSumInsuredUI)) {
            this.setClauses(["E87"], false);
            this.deleteClause(this.riskObj.clauses.clause, 'E113', "clauseCode");
            this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Sum Insured entered/ ISM Market Value is below than Min Sum Insured", 50000));
        }
    }
    handleAfterMinSumIsuredValueForTrailer() {
        if (this.riskObj.minSumInsured > 0 && this.riskObj.minSumInsured >= numeral().unformat(this.riskObj.trailerSumInsured)) {
            this.setClauses(["E87"], false);
            this.deleteClause(this.riskObj.clauses.clause, 'E113', "clauseCode");
            this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Sum Insured entered/ ISM Market Value is below than Min Sum Insured", 50000));
        }
    }
    //GA001 END
    handleRenewalReferredRiskCase() {
        if (this.caseInfo.businessFunction == 'Renewal') {
			/*if((this.riskObj.totalSumInsured > this.riskObj.vehSIRenOrg || this.riskObj.numberOfClaims > 1)
				|| (this.riskObj.coverRenewalOrg == 'TF' && this.riskObj.cover == 'CO')
				|| (this.riskObj.ldngPrctgRnwlOrg > 0  && (this.riskObj.loadingPercentage == 0 ||  this.riskObj.loadingPercentage == null))
				|| (this.riskObj.excessRnwlOrg > 0  && (this.riskObj.excessAmount <= 0 || this.riskObj.excessAmount == null))
				)
			{
				this.riskObj.symRiskClassification = "Referred";
				this.riskObj.riskClassification = this.riskObj.symRiskClassification;
			}
			else
			{
				this.riskObj.symRiskClassification = "Standard";
				this.riskObj.riskClassification = this.riskObj.symRiskClassification;
			}*/
            this.setRiskClassification(this);
        }
    }
    onChangeForGrossPremium() {
        if (this.riskObj.isVPMS === 'N') {
            this.riskObj.grossBasicPremium = Number(numeral().unformat(this.riskObj.basicPremium) + numeral().unformat(this.riskObj.trailerPremium) + numeral().unformat(this.riskObj.loadingAmount));
            this.riskObj.premiumNetOfNCB = Number(numeral().unformat(this.riskObj.grossBasicPremium));
            this.riskObj.grossBasicPremium = numeral(this.riskObj.grossBasicPremium).format(this.premiumFormat);
            this.riskObj.premiumNetOfNCB = numeral(this.riskObj.premiumNetOfNCB).format(this.premiumFormat);
            this.riskObj.basicPremium = numeral(this.riskObj.basicPremium).format(this.premiumFormat);
            this.riskObj.trailerPremium = numeral(this.riskObj.trailerPremium).format(this.premiumFormat);
        }
        this.onChangeFleetPctg();
        this.onChangeRebatePctg();
        this.onChangeForTotalPremium();
    }

    clearLoading(cover) {
        if (this.riskObj.isVPMS == 'N') {
            if (cover == 'CO' || cover == 'TF') {
                this.riskObj.loadingPercentage = 0;
                this.riskObj.loadingAmount = 0;
            }
            this.onChangeOfBasicPrmPctg();
        }
    }

    onChangeOfBasicPrmPctg() {
        this.onChangeOfLoadPctg();
        this.onChangeForGrossPremium();
    }

    onChangeOfLoadPctg() {
        this.clearPremiumInfo();
        this.riskObj.loadingPercentage = (this.riskObj.loadingPercentage == null) ? 0 : this.riskObj.loadingPercentage;
        if (this.riskObj.vehicalClass == 'MC')
            this.getAllRidersPremium("code", this.riskObj.motorItems.motorItem);
        if (this.riskObj.isVPMS === 'N' && this.riskObj.loadingPercentage != null) {
            this.riskObj.loadingAmount = Number(this.riskObj.loadingPercentage / 100 * (numeral().unformat(this.riskObj.basicPremium) + numeral().unformat(this.riskObj.trailerPremium) + numeral().unformat(this.riskObj.allRidersPremium)));
            this.riskObj.loadingAmount = numeral(this.riskObj.loadingAmount).format(this.premiumFormat);
        }
        this.onChangeForGrossPremium();
        this.handleRenewalReferredRiskCase();
    }

    onChangeFleetPctg() {
        if (this.riskObj.isVPMS === 'N') {
            if (this.riskObj.fleetDiscountPercentage) {
                if (this.riskObj.vehicalClass != 'GA' && this.riskObj.vehicalClass != 'GC')
                    this.riskObj.fleetDiscountAmount = Number(numeral().unformat(this.riskObj.fleetDiscountPercentage) / 100 * (numeral().unformat(this.riskObj.basicPremium) + numeral().unformat(this.riskObj.loadingAmount)));
                else
                    this.riskObj.fleetDiscountAmount = Number(numeral().unformat(this.riskObj.fleetDiscountPercentage) / 100 * (numeral().unformat(this.riskObj.basicPremium) + Number(this.riskObj.loadingPercentage / 100 * numeral().unformat(this.riskObj.basicPremium))));
            }
            this.riskObj.fleetDiscountAmount = numeral(this.riskObj.fleetDiscountAmount).format(this.premiumFormat);
            this.riskObj.premiumNetOfNCB = Number(Number(numeral().unformat(this.riskObj.grossBasicPremium)) - numeral().unformat(this.riskObj.fleetDiscountAmount));
            this.riskObj.premiumNetOfNCB = numeral(this.riskObj.premiumNetOfNCB).format(this.premiumFormat);

        }
        this.onChangeForTotalPremium();
    }

    onChangeRebatePctg() {
        if (this.riskObj.isVPMS === 'N' && this.riskObj.rebate && Number(this.riskObj.rebate) <= 10) {
            let tempAmount = Number(this.sumAddlAmt) + numeral().unformat(this.riskObj.premiumNetOfNCB);
            this.riskObj.subTotal = tempAmount;
            this.riskObj.rebateAmount = Number(numeral().unformat(this.riskObj.rebate) / 100 * numeral().unformat(tempAmount));
            this.riskObj.subTotal = numeral(this.riskObj.subTotal).format(this.premiumFormat);
            this.riskObj.rebateAmount = numeral(this.riskObj.rebateAmount).format(this.premiumFormat);
        }

        this.onChangeForTotalPremium();
    }

    validateRebatePctg() {
        if (Number(this.riskObj.rebate) > 10)
            this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Max. Allowed Value for Rebate is 10% only", 10000));
    }

    convertDateForP400(dateInput) {
        if (dateInput != null && dateInput != "")
            return moment(dateInput, "YYYY-MM-DD").format("YYYYMMDD");
        return "";
    }

    setIdentity() {
        this.riskObj.identity = this.riskObj.registrationNumber;
    }

    getQuote() {

        if ((['HVC', 'HVF', 'HVT', 'CV', 'CVF', 'CVT'].indexOf(this.riskObj.riskType) != -1) && (this.enableISM != true) && (BMSConstants.getBMSType() != BMSType.CoverNote && (this.riskObj.trailerRegistration == undefined || this.riskObj.trailerRegistration == ''))) {
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Trailer Number is mandatory", -1));
        } else {
            this.clearPremiumInfo();
            this._mvpmsService.getQuote(this.riskObj).subscribe((data) => {
                //E1009 Start
                if (this.riskObj.riskType == "MPD") {
                    this.headerInfo.rebate = this.riskObj.premiumCalculator == "M" ? this.riskObj.premiumInfo.annualPostingPremium.msigAnnualPostingPremium.directDiscountRate : this.riskObj.premiumInfo.annualPostingPremium.vpmsAnnualPostingPremium.directDiscountRate;
                    this.headerInfo.maxRebate = this.headerInfo.rebate;
                } // E1009 End
                this.onPremiumChange.emit(this.riskObj.totalPremium);
            });
        }
        this.headerInfo.quotationDate = moment.utc(new Date()).format("YYYY-MM-DD");
        this.headerInfo.bizAcceptanceDate = this.headerInfo.quotationDate;//GA004
        this.riskObj.quotationDate = moment.utc(new Date()).format("YYYY-MM-DD");
        this._soapService.callCordysSoapService("GetXMLObject", "http://schemas.cordys.com/1.0/xmlstore", { key: "/com/msig/insurance/QuotationValidity.xml" }, null, null, false, this)
            .success((data) => {
                let noOfDays = data.tuple.old.Config.QuotationDate;
                this.riskObj.quotationValidUntil = (['MPF', 'MCF', 'CVF', 'HVF', 'MTF'].indexOf(this.riskObj.riskType) != -1) ? noOfDays.Fleet : noOfDays.Singlerisk;

            });
    }

    clearPremiumInfo() {
        if (this.riskObj.isVPMS === 'Y') {
            this.riskObj.setPremiumInfo(null, null);
            this.onPremiumChange.emit(this.riskObj.totalPremium);
        }
        this.riskObj.useDesc = AppUtil.getValueByPathFromAry(this.riskObj.use, "VALUE", "DESCRIPTION", this.lovDropDownService.lovDataList.UseOfVehicle);
        this.riskObj.coverDesc = AppUtil.getValueByPathFromAry(this.riskObj.cover, "VALUE", "DESCRIPTION", this.lovDropDownService.lovDataList.Coverage);

    }

    onChangeRegistrationNumber() {
        if (this.riskObj.registrationNumber.length !== 0 && new RiskArray().getArrayByRiskType(this.riskObj.riskType) == "motorMPV" && (this.caseInfo.status == "Draft" || this.caseInfo.status == "Assessment")) {
            this.callForVehicleDetails();
        }
    }

    callForVehicleDetails() {

        var responsePromise = this._soapService.callCordysSoapService("getVIXReqDetails", "http://ws.vix.msig.com.my", {
            "vixRecordReq": {
                "vehRegNo": this.riskObj.registrationNumber
            }
        }, this.populateVehicleDetails, this.errorHandler, true, this);


    }

    populateVehicleDetails(data, scopeObject) {
        scopeObject.vixObj = new VixResp();

        if (data.getVIXReqDetailsReturn !== undefined && Object.keys(data.getVIXReqDetailsReturn).length !== 0) {
            if (data.getVIXReqDetailsReturn.respcode == "000") {
                scopeObject.vixObj.makeCode = data.getVIXReqDetailsReturn.vehMake;
                //GA006 -- COMMENTED
                //scopeObject.vixObj.makeModel=(data.getVIXReqDetailsReturn.vehModel.length >= 3)?data.getVIXReqDetailsReturn.vehModel.substring(1):data.getVIXReqDetailsReturn.vehModel;//SAF MYS-2018-0245
                scopeObject.vixObj.makeModel = data.getVIXReqDetailsReturn.vehModel;
                scopeObject.vixObj.makeModelNew = data.getVIXReqDetailsReturn.vehModel;
                scopeObject.vixObj.capacityValue = data.getVIXReqDetailsReturn.capacity;
                scopeObject.vixObj.yearManufacture = data.getVIXReqDetailsReturn.yearMake;
                scopeObject.vixObj.NVIC = data.getVIXReqDetailsReturn.nvic;
                scopeObject.riskObj.makeCode = data.getVIXReqDetailsReturn.vehMake;
                scopeObject.riskObj.PIAMStatistics.chassisNo = data.getVIXReqDetailsReturn.chassisNo;
                scopeObject.riskObj.PIAMStatistics.engineNo = data.getVIXReqDetailsReturn.engineNo;
                if (data.getVIXReqDetailsReturn.nvic && data.getVIXReqDetailsReturn.nvic !== "") {
                    scopeObject.getSeatCapacity(data.getVIXReqDetailsReturn.nvic);
                }
                if (!scopeObject.FluxAgentSelected) {
                    if (data.getVIXReqDetailsReturn.vehClass.length != 0) {
                        scopeObject.getvehicleClassDesc(data.getVIXReqDetailsReturn.vehClass);
                    }
                    if (data.getVIXReqDetailsReturn.coverType.length != 0) {
                        if (data.getVIXReqDetailsReturn.coverType.length == 1)
                            scopeObject.getVehicleCoverage("0" + data.getVIXReqDetailsReturn.coverType);
                        else
                            scopeObject.getVehicleCoverage(data.getVIXReqDetailsReturn.coverType);
                    }
                    if (data.getVIXReqDetailsReturn.vehUse.length == 1) {
                        scopeObject.vixObj.use = "0" + data.getVIXReqDetailsReturn.vehUse;
                    }
                    else {
                        scopeObject.vixObj.use = data.getVIXReqDetailsReturn.vehUse;
                    }
                }
                if (scopeObject.riskObj.makeCode.length !== 0) {
                    scopeObject.filterModel("", "vixResponse");
                }
                scopeObject._alertMsgService.add(new AlertMessage(AlertMessage.INFO, scopeObject.showVIXResponseCode(data.getVIXReqDetailsReturn.respcode), -1));
            }
            else {
                scopeObject._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, scopeObject.showVIXResponseCode(data.getVIXReqDetailsReturn.respcode), -1));
            }


        }
        //GA010 START
        if (scopeObject.headerInfo.isHighRiskApplicable) {
            scopeObject.checkBlackList();
        } else {
            scopeObject.checkHighRiskVehicle();
        }
        //GA010 END

    }

    getvehicleClassDesc(vehicleClass) {
        this.lovDropDownService.createLOVDataList(["VehicleClassCode"]);
        let filterDetails = [new SearchFilter("DESCITEM", vehicleClass, "EQ", "AND")];
        let searchFilterNodes = this.lovDropDownService.createFilter(filterDetails);
        let lovFields = [new LOV_Field("ALL", "MTR", "NEW BUSINESS", "MOTOR", "NEW", "VEHICLE INFO", "VEHICLE CLASS", "LOV", searchFilterNodes, "DESCPF", "VehicleClassCode", "successCallBackVehicleClass")];
        this.lovDropDownService.util_populateLOV(lovFields, this);
    }

    getVehicleCoverage(coverage) {
        this.lovDropDownService.createLOVDataList(["VehicleCoverageCode"]);
        let filterDetails = [new SearchFilter("COVERAGE", coverage, "EQ", "AND")];
        let searchFilterNodes = this.lovDropDownService.createFilter(filterDetails);
        let lovFields = [new LOV_Field("ALL", "MTR", "NEW BUSINESS", "MOTOR", "NEW", "VEHICLE INFO", "COVERAGE", "LOV", searchFilterNodes, "T4664", "VehicleCoverageCode", "successCallBackVehicleCoverage")];
        this.lovDropDownService.util_populateLOV(lovFields, this);
    }

    successCallBackVehicleClass(scopeObject) {
        scopeObject.riskObj.vehicalClass = "";
        if (scopeObject.lovDropDownService.lovDataList.VehicleClassCode.length !== 0) {
            scopeObject.riskObj.vehicalClass = scopeObject.lovDropDownService.lovDataList.VehicleClassCode[0].SHORTDESC;
            scopeObject.onChangeVehicleClass(scopeObject.riskObj.vehicalClass, "vixResponse");
        }
    }

    successCallBackVehicleCoverage(scopeObject) {
        scopeObject.riskObj.cover = "";
        if (scopeObject.lovDropDownService.lovDataList.VehicleCoverageCode.length !== 0)
            scopeObject.riskObj.cover = scopeObject.lovDropDownService.lovDataList.VehicleCoverageCode[0].DESCITEM;
    }

    errorHandler(response, status, errorText, scopeObject) {

    }

    callForISMResponse() {
        let resp = this._soapService.httpget("config/bms/vix/config.txt");
        resp.subscribe((data) => this.loadResponseCode(data));

    }

    loadResponseCode(data) {
        this.vixResponseCode = data;

    }

    showVIXResponseCode(respcode) {
        if (this.vixResponseCode.response.hasOwnProperty(respcode)) {
            return this.vixResponseCode.response[respcode];
        }
    }
    getSeatCapacity(nvic) {
        var seatCapacity = this._soapService.callCordysSoapService("GetLOVData",
            "http://schemas.opentext.com/lovhandler/v1.0", this.getSeatCapacityRequest(nvic), null, null, true, this);

        seatCapacity.success((data) => {
            if (data.tuple && data.tuple.old && data.tuple.old.VARNPF) {
                this.riskObj.seats = data.tuple.old.VARNPF.ZTRSEAT;
            }
        });
        seatCapacity.error((data) => {
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "No seat capacity found the given NVIC.", 10000));

        });

    }

    getSeatCapacityRequest(nvic) {
        let request: GetLOVData = new GetLOVData();
        request = request.getRequest("ALL", "ALL", "NEW BUSINESS", "MOTOR", "NEW", "VEHICLE INFO", "seatCapacity", "LOV");
        request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        request.ADVANCE_CONFIG_XML.FILTERS = new Filter();
        request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({ "@FIELD_NAME": 'ZNVIC', "@FIELD_VALUE": nvic, '@OPERATION': 'EQ', '@CONDITION': 'AND' });
        return request;

    }

    getCoverDisableByBFN(item) {
        let toDisable = null;
        if (BMSConstants.getBMSType() == BMSType.Renewal) {
            if (item.VALUE == 'TP' && (this.riskObj.coverRenewalOrg == 'CO' || this.riskObj.coverRenewalOrg == 'TF'))
                toDisable = true;
            else if ((item.VALUE == 'CO' || item.VALUE == 'TF') && this.riskObj.coverRenewalOrg == 'TP')
                toDisable = true;
        }
        return toDisable;
    }
    addXT(coverItem) {
        var dialogData = new ExtraTextDialogData("ExtraTextDialogComponent", "app/bms/components/proposal/newbusinessrisks/dialogs/extratext.dialog.module", "ExtraTextDialogModule", "Extra Text", "ExtraText", "fa fa-comment", coverItem, this.extraTextCallBack);
        this.openExtraTextCommentsDialog(dialogData);
    }

    public openExtraTextCommentsDialog(dialogData: ExtraTextDialogData, response?: any) {
        let lookup = new ModalInput();
        lookup.component = [dialogData.component, dialogData.moduleAbsPath, dialogData.moduleName];
        lookup.datainput = {
            dialogName: dialogData.dialogName,
            areCommentsMandatory: false,
            coverageItem: dialogData.coverageItem
        };
        lookup.outputCallback = dialogData.callBackHandler;
        lookup.parentCompPRMS = {
            comp: this,
            response: response
        };
        lookup.heading = dialogData.dialogTitle;
        lookup.icon = dialogData.icon;
        lookup.containerRef = this.contentArea;
        this.dcl.openLookup(lookup);
    }

    private extraTextCallBack(data, prms) {
        if (data.isDialogCancelled) {
            return;
        } else if (!data.isDialogCancelled && data.coverageItem && data.coverageItem.extraText) {
        }
    }

    private getVehicleBody() {
        if (this.validateEmpty(this.riskObj.vehicalClass) && this.validateEmpty(this.riskObj.use)) {
            this.lovDropDownService.createLOVDataList(["Vehicle Body"]);
            let filterDetails = [new SearchFilter("VEHCLASS", this.riskObj.vehicalClass.trim(), "EQ", "AND"),
            new SearchFilter("VEHUSE", this.riskObj.use, "EQ", "AND"),];
            let searchFilterNodes = this.lovDropDownService.createSearchFilter(filterDetails);
            let lovFields;
            let vehBodyFormName = "PRIVATE_MOTOR";
            let label = "DESCPF";
            if (["HVC", "HVT", "HVF", "MTC", "MTT", "MTF"].indexOf(this.riskObj.riskType) != -1) {
                vehBodyFormName = "COMMERCIAL_MOTOR";
                label = "T9149";
            }
            lovFields = [new LOV_Field("ALL", "MOTOR", "NEW BUSINESS", "ALL", "NEW", vehBodyFormName, "Vehicle Body", "LOV", searchFilterNodes, label, "VehicleBody", null),];
            this.lovDropDownService.util_populateLOV_New(lovFields, this);
        }
    }

    private vehicleBodyAvailablitly(vehClass) {
        if (['MN', 'MW', 'SC', 'SW'].indexOf(vehClass) != -1) {
            this.showVehicleBody = true;
        } else {
            this.showVehicleBody = false;
        }
    }
    public onAmountChange($event) {// MYS-2018-1189 Added this below validation
        if (isNaN(Number(numeral($event.target.value))) || $event.target.value == null) {
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Enter Valid Amount and Format", 5000));
            $event.target.value = '';
            return;
        } else {
            $event.target.value = Number(numeral($event.target.value));
        }
    }
    private checkExcessValidation(event) { // MYS-2018-1189 Added this below validation
        if (!(event.keyCode >= 48 && event.keyCode <= 57 || (event.keyCode == 46))) {
            event.preventDefault();
        }
    }
    //GA010 START
    checkHighRiskVehicle() {
        let clientIDNo = this.riskObj.PIAMStatistics.chassisNo;
        if (clientIDNo != "" && clientIDNo != undefined) {
            this._soapService.callCordysSoapService("CheckHighRiskForVehicle", "http://schemas.cordys.com/bmsintegrationapp", {
                "CHASISNUM": clientIDNo, "EFFECTIVEDATE": moment(this.headerInfo.effectiveDate).format("YYYYMMDD"), "ENDDATE": moment(this.headerInfo.endDate).format("YYYYMMDD")
            }, this.highRiskVehicleHandler, this.handleError, true, { comp: this });
        }
    }
    highRiskVehicleHandler(response, prms) {
        let ind = "";
        let reason = "";
        let item_key = "HIGHRISK_VEHICLE";
        let item = "VEHICLE";
        let headerInfo = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo;
        if (response.tuple != null && response.tuple.old != null && response.tuple.old.checkHighRiskForVehicle
            && response.tuple.old.checkHighRiskForVehicle.checkHighRiskForVehicle != null
            && response.tuple.old.checkHighRiskForVehicle.checkHighRiskForVehicle != "") {
            ind = response.tuple.old.checkHighRiskForVehicle.checkHighRiskForVehicle.substring(0, 1);
            reason = response.tuple.old.checkHighRiskForVehicle.checkHighRiskForVehicle.substring(1);
        }
        if (ind != "" && (ind == 'A' || ind == 'B')) {
            let highRiskIndReason: HighRiskIndReason = new HighRiskIndReason();
            if (prms.comp.riskObj != undefined && prms.comp.riskObj.riskNumber != undefined) {
                highRiskIndReason.riskNumber = Number(prms.comp.riskObj.riskNumber);
            } else {
                highRiskIndReason.riskNumber = 1;
            }
            highRiskIndReason.item = item;
            highRiskIndReason.reason = reason;
            highRiskIndReason.ind = ind;
            highRiskIndReason.item_key = item_key;

            headerInfo.highRiskIndicator = "true";
            headerInfo.highRiskIndicatorUI = true;
            headerInfo.highRiskVehicleIndicator = ind;

            let removeIndex = -1;
            if (headerInfo.highRiskIndicatorReasons != undefined && headerInfo.highRiskIndicatorReasons.highRiskIndReason.length > 0) {
                removeIndex = headerInfo.highRiskIndicatorReasons.highRiskIndReason.map(function (item) { return item.item_key; }).indexOf("HIGHRISK_VEHICLE");
                if (removeIndex >= 0) {
                    headerInfo.highRiskIndicatorReasons.highRiskIndReason.splice(removeIndex, 1);
                }
            }

            headerInfo.highRiskIndicatorReasons.highRiskIndReason.push(highRiskIndReason);
            prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Selected Vehicle is High Risk Indicator.", 15000));
        } else {
            headerInfo.highRiskVehicleIndicator = "";
            let removeIndex = -1;
            if (headerInfo.highRiskIndicatorReasons != undefined && headerInfo.highRiskIndicatorReasons.highRiskIndReason.length > 0) {
                removeIndex = headerInfo.highRiskIndicatorReasons.highRiskIndReason.map(function (item) { return item.item_key; }).indexOf("HIGHRISK_VEHICLE");
                if (removeIndex >= 0) {
                    headerInfo.highRiskIndicatorReasons.highRiskIndReason.splice(removeIndex, 1);
                }
            }
            if (!(headerInfo.highRiskIndicatorReasons != undefined && headerInfo.highRiskIndicatorReasons.highRiskIndReason.length > 0)) {
                headerInfo.highRiskIndicator = "false";
                headerInfo.highRiskIndicatorUI = false;
                headerInfo.highRiskVehicleIndicator = "";
            }
        }
    }
    //GA010 END
}

export class ABIRequest {
    constructor(
        public refNo: string,
        public vehRegNo: string,
        public vehClass: string,
        public yearOfMft: string,
        public vehMake: string,
        public vehModel: string,
        public vehCC: string,
        public chassisNo: string,
        public polEffDate: string,
        public sourceName: string,
        public accountNo: string,
        public coverType: string, //MSU001 : MYS-2019-0984
        public region?: string,
        public nvic?: string
    ) { }
}

export class VehicleVariant {
    constructor(
        public vehVariant: string,
        public nvic: string,
        public country: string
    ) { }
}