import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BasicUIModule } from '../../../../../common/components/utility/basicui.module';

import { MotorSubCompModule } from './uimodules/motorsubcomp.module';
import { ClausesModule } from '../uimodules/clauses.module';
import { GSTModule } from '../uimodules/gst.module';
import { FIModule } from '../../../../../common/components/financialinterest/fi.module';
import { MotorVPMSModule } from './handler/motor.vpms.module';
import { GeneralPageModule } from '../uimodules/generalpage.module'; //VK004
import { MotorCVRiskComponent } from './motorcommercial.component';

@NgModule({
    imports: [CommonModule, FormsModule, ReactiveFormsModule, BasicUIModule,MotorSubCompModule,ClausesModule,GSTModule,FIModule,MotorVPMSModule,GeneralPageModule],
    declarations: [MotorCVRiskComponent],
    exports: [MotorCVRiskComponent]
})
export class MotorCVRiskModule { }