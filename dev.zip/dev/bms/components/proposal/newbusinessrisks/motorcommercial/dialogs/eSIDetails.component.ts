import { Component, OnInit } from "@angular/core";
import { ChangeDetector } from '../../../../../../common/services/changedetector.service';
import { ESIDetails } from "../appobjects/esiDetails";
import { LOV_Field, LOVDropDownService, SearchFilter } from "../../../../../../common/services/lovdropdown/lovdropdown.service";

@Component({
    selector: 'eSI-details-component',
    templateUrl: 'app/bms/components/proposal/newbusinessrisks/motorcommercial/dialogs/eSIDetails.template.html',
    inputs: ['datainput', 'closeDialog', 'parentCompPRMS']
})

export class ESIDetailsComponent implements OnInit {

    private _esiDetails: ESIDetails;

    public datainput: any;
    public closeDialog: Function;
    public parentCompPRMS: any;

    constructor(private lovDropDownService: LOVDropDownService) { }

    ngOnInit(): any {
        this._esiDetails = this.datainput.esiDetails;
        if ((this._esiDetails.respCodeDesc == undefined || this._esiDetails.respCodeDesc == "") && (this._esiDetails.respCode != undefined && this._esiDetails.respCode != ""))
            this._esiDetails.respCodeDesc = this._esiDetails.respCode.substr(3, 6);
        this.populateLOVs();
    }

    private populateLOVs(): void {
        this.lovDropDownService.createLOVDataList(["RespCode"]);
        let filterDetails = [new SearchFilter("DESCITEM", this._esiDetails.respCodeDesc, "EQ", "AND")];
        let searchFilterNodes = this.lovDropDownService.createFilter(filterDetails);
        let lovFields = [new LOV_Field("ALL", "ALL", "NEW BUSINESS", "ALL", "NEW", "ISM_VIEW", "ISM_RESP_CODES", "LOV", searchFilterNodes, "DESCPF", "RespCode", null)];
        this.lovDropDownService.util_populateLOV(lovFields, this);
    }

}