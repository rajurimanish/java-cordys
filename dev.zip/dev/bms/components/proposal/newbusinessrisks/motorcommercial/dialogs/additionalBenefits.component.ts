import { Component, OnInit } from "@angular/core";
import { MotorMCVDetail } from "../../appobjects/motorItems";
import { AlertMessagesService } from '../../../../../../common/components/utility/alertmessage/alertmessages.service';
import { AlertMessage } from '../../../../../../common/components/utility/alertmessage/alertmessages.model';
import { NumberField } from '../../../../../../common/components/utility/number/number';
declare var jQuery: any;
declare var moment: any;

@Component({
    selector: 'additional-details-component',
    templateUrl: 'app/bms/components/proposal/newbusinessrisks/motorcommercial/dialogs/additionalBenefits.template.html',
    inputs: ["addnlBenefits"]
})

export class AdditionalBenefitsComponent implements OnInit {

    public addnlBenefits: MotorMCVDetail;
    private endDateCtrl: any;
    public datainput: any;
    public closeDialog: Function;
    public parentCompPRMS: any;

    constructor(public _alertMsgService: AlertMessagesService) {
    }

    ngOnInit(): any {
        this.addnlBenefits = jQuery.extend(true, {}, this.datainput.addnlBenefits);
    }
    onOkay() {
        this.closeDialog({ item: this.addnlBenefits, index: this.datainput.index }, this.parentCompPRMS);
    }
    validateEndDate() {
        if ((this.addnlBenefits.dateFromAdditionalBenfit != null || this.addnlBenefits.dateFromAdditionalBenfit != "") && (this.addnlBenefits.dateToAdditionalBenfit != null || this.addnlBenefits.dateToAdditionalBenfit != "")) {
            if (moment(this.addnlBenefits.dateFromAdditionalBenfit, "YYYY-MM-DD") > moment(this.addnlBenefits.dateToAdditionalBenfit, "YYYY-MM-DD")) {
                this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "To Date can not be smaller than From Date.", 10000));
                this.endDateCtrl.setter("EMPTY", "YYYY-MM-DD", this.endDateCtrl.comp);
            }
        }
    }
}