import { Component, ElementRef, OnInit } from "@angular/core";
import { ChangeDetector } from '../../../../../../common/services/changedetector.service';
import { NamedDriverItem } from "../appobjects/nameddriver";
import { NamedDriver } from "../appobjects/nameddriver";
import { LOV_Field, LOVDropDownService, SearchFilter } from "../../../../../../common/services/lovdropdown/lovdropdown.service";
import { NamedDriverValidator } from '../../../validation/nameddriver.validator';
import { AlertMessagesService } from '../../../../../../common/components/utility/alertmessage/alertmessages.service';
import { AlertMessage } from '../../../../../../common/components/utility/alertmessage/alertmessages.model';
import { ClientDetails } from '../../../../../../common/components/client/appobjects/client';

declare var moment: any;
declare var jQuery: any;

@Component({
    selector: 'driverDetails-dialog',
    templateUrl: 'app/bms/components/proposal/newbusinessrisks/motorcommercial/dialogs/driverDetaildialog.template.html',
    inputs: ['datainput', 'closeDialog', 'parentCompPRMS']
})

export class DriverDetailsDialogComponent implements OnInit {

    constructor(private lovDropDownService: LOVDropDownService, public _alertMsgService: AlertMessagesService) { }

    public _driverDetails: NamedDriverItem;
    public driverList: NamedDriver;
    public yearOfManfactureList: Object[] = [];
    public isClientViewMode: boolean = false;
    private DOBCtrl: any;
    private editItemIdx;
    private isViewMode: boolean = false;
    public clientDetails: ClientDetails;
    public insuredIsDriver: string;

    public datainput: any;
    public closeDialog: Function;
    public parentCompPRMS: any;

    private isDisable: boolean = false;
    private CloseDialog() {
        let result = this.isDriverValid();
        if (result.isValid) {
            if (this.isViewMode)
                this.closeDialog({ "driver": this._driverDetails, "editItem": this.editItemIdx }, this.parentCompPRMS);
            else
                this.closeDialog(this._driverDetails, this.parentCompPRMS);
        }
        else
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, result.message, 10000));
    }

    ngOnInit(): any {
        this.isViewMode = this.datainput.isView;
        this.isClientViewMode = this.datainput.isClientView;
        this.clientDetails = this.datainput.clientInfo;
        this.insuredIsDriver = this.datainput.insuredIsDriver;
        this.driverList = this.datainput.driverList;
        this.isDisable = this.datainput.disableForm;
        if (this.isViewMode == true) {
            this._driverDetails = new NamedDriverItem();
            this._driverDetails = jQuery.extend(true, {}, this.datainput.selectedDriver);//clone and assign
            this.editItemIdx = this.datainput.editItem;
        } else {
            this._driverDetails = new NamedDriverItem();
        }

        this.populateLOVs();
        this.listForYearofManfacture(40);
    }

    private isDriverValid() {
        let result = new NamedDriverValidator(this._driverDetails).validate();
        if (result.isValid == false) {
            result.message = "Please fill Valid Driver Details and then Proceed";
        }
        else {
            if (this.driverList != null && this.driverList.driverDetail.length > 0) {
                for (var index = 0, assoLength = this.driverList.driverDetail.length; index < assoLength; index++) {
                    //GA001 - added replace(/[-,/]/g, '')
                    if ((this.driverList.driverDetail[index].ICNumber != undefined && this._driverDetails.ICNumber.replace(/[-,/]/g, '') == this.driverList.driverDetail[index].ICNumber.replace(/[-,/]/g, '')) && this.editItemIdx != index) {
                        result.message = "A Driver already exists with the entered ICNumber";
                        result.isValid = false;
                        return result;
                    }
                }
            }
            if (this.clientDetails && this.clientDetails.client.genericDetails.clienttype == "P") {
                if (this.clientDetails.client.personalClientDetails && this.insuredIsDriver === 'false') {
                    if ((this._driverDetails.ICNumber.replace(/[-,/]/g, '') == this.clientDetails.client.personalClientDetails.NRICNo.replace(/[-,/]/g, '')) ||
                        (this._driverDetails.ICNumber == this.clientDetails.client.personalClientDetails.IdNumber)) {
                        result.message = "Insured cannot be selected as Driver as Insured is Driver checkbox is unchecked";
                        result.isValid = false;
                        return result;
                    }
                }
            }
        }
        return result;
    }

    private populateLOVs(): void {

        this.lovDropDownService.createLOVDataList(["Relationship", "Sex", "Occupation"]);

        let lovFields = [
            new LOV_Field("ALL", "MOTOR", "NEW BUSINESS", "ALL", "NEW", "NAMED_DRIVER", "Relationship", "LOV", [], "DESCPF", "Relationship", null),
            new LOV_Field("ALL", "MOTOR", "NEW BUSINESS", "ALL", "NEW", "NAMED_DRIVER", "Sex", "LOV", [], "DESCPF", "Sex", null),
            new LOV_Field("ALL", "MOTOR", "NEW BUSINESS", "ALL", "NEW", "NAMED_DRIVER", "Occupation", "LOV", [], "DESCPF", "Occupation", null)
        ];
        this.lovDropDownService.util_populateLOV(lovFields, this);
    }

    listForYearofManfacture(number) {
        var year = Number(new Date().getFullYear());
        for (var index = number; index > 0; --index) {
            this.yearOfManfactureList.push(year);
            year--;
        }
    }

    onChangeNRIC(event) {
        let value = event.target.value
        if (value != "") {
            let count = this._driverDetails.ICNumber.split("-").length - 1;
            if (this._driverDetails.ICNumber.length > 0 && this._driverDetails.ICNumber.length != 14 && count != 2)
                this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Please fill Valid format for field NRIC. Please enter NRIC in format xxxxxx-xx-xxxx.", -1));
            else {
                let date = value.substring(0, 6);
                let century = value.substring(0, 2)
                if (Number(century) > 29)
                    date = '19' + date;
                else
                    date = '20' + date;
                if (this.DOBCtrl != null)
                    this.DOBCtrl.setter(moment(date, "YYYYMMDD").format("YYYY-MM-DD"), "YYYY-MM-DD", this.DOBCtrl.comp);
            }
        }
    }

    validateDOB() {
        if (this._driverDetails.ICNumber != undefined && this._driverDetails.ICNumber != "") {
            let date = this._driverDetails.ICNumber.substring(0, 6);
            let century = this._driverDetails.ICNumber.substring(0, 2)
            if (Number(century) > 29)
                date = '19' + date;
            else
                date = '20' + date;
            if (date != moment(this._driverDetails.dateOfBirth, "YYYY-MM-DD").format("YYYYMMDD"))
                this.DOBCtrl.setter(moment(date, "YYYYMMDD").format("YYYY-MM-DD"), "YYYY-MM-DD", this.DOBCtrl.comp);
        }
    }
}