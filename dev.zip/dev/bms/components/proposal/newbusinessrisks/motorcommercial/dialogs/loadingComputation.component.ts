import { Component, OnInit } from "@angular/core";
import { LoadingComputationItem } from "../appobjects/loadingComputationItem";
import { CordysSoapWService } from "../../../../../../common/components/utility/cordys-soap-ws";
import { NamedDriverItem } from '../appobjects/nameddriver'
import { GetLOVData, SearchAdvancedConfig, Filter } from '../../../../../../common/components/utility/search/search.requests';
import { AlertMessagesService } from '../../../../../../common/components/utility/alertmessage/alertmessages.service';
import { AlertMessage } from '../../../../../../common/components/utility/alertmessage/alertmessages.model';

@Component({
    selector: 'loading-computation',
    templateUrl: 'app/bms/components/proposal/newbusinessrisks/motorcommercial/dialogs/loadingComputation.template.html',
    inputs: ['datainput', 'closeDialog', 'parentCompPRMS']
})

export class LoadingComputationComponent {

    private isCollapsedMode: boolean = false;
    constructor(private _soapService: CordysSoapWService, public _alertMsgService: AlertMessagesService) { }

    public origLoading: number;
    public bnmLoading: number;
    public totalLoading: number = 0;
    public code: string;
    public loadingComputationItems: LoadingComputationItem[] = [];
    public loadingComputationList: LoadingComputationItem[] = [];

    public datainput: any;
    public closeDialog: Function;
    public parentCompPRMS: any;

    private CloseDialog() {
        this.totalLoading = this.calculateTotal(this.loadingComputationList);
        if (this.totalLoading > this.bnmLoading) {
            // this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Not Valid ! Please Change so that value will be less than bnmLoading" , -1));
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Total Loading exceeds Max BNM Loading allowed.", -1));
        }
        else {
            this.closeDialog({ bnmLoad: this.bnmLoading, loading: this.totalLoading, loadList: this.loadingComputationList }, this.parentCompPRMS);
        }
    }

    ngOnInit(): any {
        this.code = this.datainput.code;
        this.origLoading = this.datainput.origLoadingAmt;
        if (this.datainput.loadItemsList.length > 0) {
            this.loadingComputationList = this.datainput.loadItemsList;
            this.totalLoading = this.calculateTotal(this.loadingComputationList);
            this.bnmLoading = this.datainput.bnmLoadVal;
        }
        else {
            this.getLDdetails();
        }

    }

    onChange(inputLoading, limit) {
        if (Number(inputLoading) > Number(limit)) {
            // this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Not Valid ! Please Change so that value will be less than Loading Limit Allowed" , -1));
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Input Loading(%) exceeds Loading Limit(%) allowed.", -1));
            return;
        }
        if (this.loadingComputationList != undefined) {
            this.totalLoading = this.calculateTotal(this.loadingComputationList);
        }
        if (this.totalLoading > this.bnmLoading) {
            // this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Not Valid ! Please Change so that value will be less than bnmLoading" , -1));
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Total Loading exceeds Max BNM Loading allowed.", -1));
        }
    }

    calculateTotal(loadList: LoadingComputationItem[]): number {
        let sumAddlAmt: number = 0;
        for (let load of loadList) {
            if (load.inputLoadingPerctg != undefined) {
                sumAddlAmt = sumAddlAmt + Number(load.inputLoadingPerctg);
            }
        }
        return sumAddlAmt;
    }

    private getLDdetails() {
        let request: GetLOVData = new GetLOVData();
        request.BRANCH = 'ALL';
        request.LOB = 'MOTOR';
        request.BUSINESS_FUNCTION = 'NEW BUSINESS';
        request.PRODUCT = 'ALL';
        request.OPERATION = 'NEW';
        request.FORM_NAME = 'LOADING_POPUP';
        request.FORM_FIELD_NAME = 'Loading Computation';
        request.FIELD_TYPE = 'LOV';
        request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        request.ADVANCE_CONFIG_XML.FILTERS = new Filter();

        request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({ "@FIELD_NAME": 'DESCITEM', "@FIELD_VALUE": this.code, '@OPERATION': 'EQ', '@CONDITION': 'AND' },
            { "@FIELD_NAME": 'ITMFRM', "@FIELD_VALUE": this.datainput.effectiveDate, '@OPERATION': 'LT', '@CONDITION': 'AND' },
            { "@FIELD_NAME": 'ITMTO', "@FIELD_VALUE": this.datainput.effectiveDate, '@OPERATION': 'GT', '@CONDITION': 'AND' });
        this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.successHandler, this.errorHandler, true, { curcomp: this });
    }

    successHandler(response, prms) {
        let ldItems = [];
        if (response.tuple != null && !Array.prototype.isPrototypeOf(response.tuple)) {
            ldItems = [response.tuple];
        }
        else if (response.tuple != null) {
            ldItems = response.tuple;
        }

        for (let val of ldItems) {
            let ldItem: LoadingComputationItem = new LoadingComputationItem();
            ldItem.code = val.old.T9040.ZLOADCOD;
            ldItem.sequence = val.old.T9040.SEQNO;
            ldItem.description = val.old.T9040.ENTYDESC;
            ldItem.ageFrom = val.old.T9040.ZAGEFRM;
            ldItem.ageTo = val.old.T9040.ZAGETO;
            ldItem.numOfClaims = val.old.T9040.ZCOUNT;
            ldItem.loadingPerctgLimit = val.old.T9040.ZLOADLIM;
            prms.curcomp.bnmLoading = val.old.T9040.ZLOADMAX;
            if (prms.curcomp.loadingComputationItems == undefined)
                prms.curcomp.loadingComputationItems = [];
            prms.curcomp.loadingComputationItems.push(ldItem);
        }

        let yearofManf: number = Number(prms.curcomp.datainput.yearManf);
        let cfy: number = Number(prms.curcomp.datainput.claims);
        let driverList: NamedDriverItem[] = prms.curcomp.datainput.driverList;

        let diffYear = Number(new Date().getFullYear()) - yearofManf;

        if (prms.curcomp.loadingComputationItems != undefined) {
            for (let item of prms.curcomp.loadingComputationItems) {
                //If loading % is 0 do not load
                if (item.loadingPerctgLimit == 0 || item.loadingPerctgLimit == "0") {
                    return;
                }
                //Logic to excelude mutually exclusive conditions
                if (item.description != "" && (item.description.split(">").length > 1 || item.description.split("<").length > 1)) {
                    let tempArray = item.description.split(">");
                    let tempArrayMutualEx = item.description.split("<");
                    let stringCondition = "";
                    let stringConditionMutualEx = "";

                    if (tempArray.length > 1) {
                        stringCondition = tempArray[0] + ">" + tempArray[1];
                    }
                    else if (tempArray.length == 1 && tempArrayMutualEx.length > 1) {
                        stringCondition = tempArrayMutualEx[0] + ">"; tempArrayMutualEx[1];
                    }


                    if (tempArrayMutualEx.length > 1) {
                        stringConditionMutualEx = tempArrayMutualEx[0] + "<" + tempArrayMutualEx[1];
                    }
                    else if (tempArrayMutualEx.length == 1 && tempArray.length > 1) {
                        stringConditionMutualEx = tempArray[0] + "<" + tempArray[1];
                    }

                    for (var loadingComputationItem of prms.curcomp.loadingComputationList) {
                        if ((loadingComputationItem.description.toUpperCase() == stringCondition.toUpperCase()) || (loadingComputationItem.description.toUpperCase() == stringConditionMutualEx.toUpperCase())) {
                            return;
                        }
                    }
                }
                //Other already existing  validations
                if (item.code.startsWith("VA")) {
                    if ((diffYear >= item.ageFrom && diffYear <= item.ageTo))
                        prms.curcomp.loadingComputationList.push(item);
                }
                else {
                    prms.curcomp.loadingComputationList.push(item);
                }
				/*else if(item.code.startsWith("CE001") && cfy <= item.numOfClaims ) 
				{
					prms.curcomp.loadingComputationList.push(item);
				}
				else if(item.code.startsWith("CE002") && cfy >= item.numOfClaims ) 
				{
					prms.curcomp.loadingComputationList.push(item);
				}
				else if(item.code.startsWith("DA")) {
					for ( let driver of driverList ) {
						if(driver.dateOfBirth == undefined) {
							prms.curcomp.loadingComputationList.push(item);
							break;
						}
						else {
							let dob = driver.dateOfBirth.substring(6,10);
							let dobDiff = Number(new Date().getFullYear()) - Number(dob);
							if(!(dobDiff >= item.ageFrom && dobDiff <= item.ageTo)) {
								prms.curcomp.loadingComputationList.push(item);
								break;
							}
						}
					}
				}*/
            }
        }
    }

    errorHandler(response, status, errorText, prms) {
        prms.curcomp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, response.responseJSON.faultstring.text, -1));
    }

}