import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BasicUIModule } from '../../../../../../common/components/utility/basicui.module';

import { ESIDetailsComponent } from "./eSIDetails.component";

@NgModule({
    imports: [CommonModule, FormsModule, ReactiveFormsModule, BasicUIModule],
    declarations: [ESIDetailsComponent],
    exports: [ESIDetailsComponent]
})
export class ESIDetailsModule { }