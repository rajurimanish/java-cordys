import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BasicUIModule } from '../../../../../../common/components/utility/basicui.module';

import { DriverDetailsDialogComponent } from "./driverDetailDialog.component";

@NgModule({
    imports: [CommonModule, FormsModule, ReactiveFormsModule, BasicUIModule],
    declarations: [DriverDetailsDialogComponent],
    exports: [DriverDetailsDialogComponent]
})
export class DriverDetailsDialogModule { }