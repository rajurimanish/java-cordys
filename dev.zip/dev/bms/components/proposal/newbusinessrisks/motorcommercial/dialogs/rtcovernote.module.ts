import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BasicUIModule } from '../../../../../../common/components/utility/basicui.module';
import { RTCoverNoteComponent } from './rtcovernote.component';
import { PaginationModule } from '../../../../../../common/components/utility/pagination/pagination.module';
import { CoverNoteServiceModule } from '../../../../../services/covernote.service.module';
@NgModule({
    imports: [CommonModule, FormsModule, ReactiveFormsModule, BasicUIModule, PaginationModule, CoverNoteServiceModule],
    declarations: [RTCoverNoteComponent],
    exports: [RTCoverNoteComponent]
})
export class RTCoverNoteModule { }