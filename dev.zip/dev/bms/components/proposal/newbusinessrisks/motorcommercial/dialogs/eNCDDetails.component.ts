import { Component, OnInit } from "@angular/core";
import { ChangeDetector } from '../../../../../../common/services/changedetector.service';
import { ENCDDetails } from "../appobjects/encdDetails";
import { LOV_Field, LOVDropDownService, SearchFilter } from "../../../../../../common/services/lovdropdown/lovdropdown.service";

@Component({
    selector: 'eNCD-details-component',
    templateUrl: 'app/bms/components/proposal/newbusinessrisks/motorcommercial/dialogs/eNCDDetails.template.html',
    inputs: ['datainput', 'closeDialog', 'parentCompPRMS']
})

export class ENCDDetailsComponent implements OnInit {

    private _encdDetails: ENCDDetails;

    public datainput: any;
    public closeDialog: Function;
    public parentCompPRMS: any;

    constructor(private lovDropDownService: LOVDropDownService) { }

    ngOnInit(): any {
        this._encdDetails = this.datainput.encdDetails;
        if (this._encdDetails.respCodeDesc == undefined || this._encdDetails.respCodeDesc == "")
            this._encdDetails.respCodeDesc = this._encdDetails.respCode.substr(3, 6);
        this.populateLOVs();
    }

    private populateLOVs(): void {
        this.lovDropDownService.createLOVDataList(["RespCode"]);
        let filterDetails = [new SearchFilter("DESCITEM", this._encdDetails.respCodeDesc, "EQ", "AND")];
        let searchFilterNodes = this.lovDropDownService.createFilter(filterDetails);
        let lovFields = [new LOV_Field("ALL", "ALL", "NEW BUSINESS", "ALL", "NEW", "ISM_VIEW", "ISM_RESP_CODES", "LOV", searchFilterNodes, "DESCPF", "RespCode", null)];
        this.lovDropDownService.util_populateLOV(lovFields, this);
    }

}