import { Component, OnInit } from "@angular/core";
import { CordysSoapWService } from '../../../../../../common/components/utility/cordys-soap-ws';
import { AlertMessagesService } from '../../../../../../common/components/utility/alertmessage/alertmessages.service';
import { AlertMessage } from '../../../../../../common/components/utility/alertmessage/alertmessages.model';
import { BMSAppObjService } from '../../../../../services/bmsappobj.service';
import { ProgressBarComponent } from '../../../../../../common/components/utility/progressbar/progressbar.component';
import { BMSConstants } from '../../../../common/constants/bms_constants';
import { MiscCoverNote } from '../appobjects/misccovernote';
import { RTCoverNote } from '../appobjects/misccovernote';
import { CoverNoteService } from '../../../../../services/covernote.service';
import { BMSLOVRequest } from '../../../../common/service/lov/bms.lovrequest';
import { AppUtil } from '../../../../../../common/components/utility/apputil/app.util';
import { Approval } from "../../../../../../common/components/appobjects/approval";
import { Risk } from "../../../../common/appobjects/miscobject";
import { RTCNValidator } from "../../../validation/rtcoverrnote.validator";
import { LOV_Field, LOVDropDownService, SearchFilter } from "../../../../../../common/services/lovdropdown/lovdropdown.service";
import { GetLOVData, SearchAdvancedConfig, Filter } from "../../../../../../common/components/utility/search/search.requests";
declare var Observer: any;

declare var jQuery: any;
declare var moment: any;

@Component({
    selector: "rt-covernote",
    templateUrl: "app/bms/components/proposal/newbusinessrisks/motorcommercial/dialogs/rtcovernote.template.html",
    inputs: ['datainput', 'closeDialog', 'parentCompPRMS']
})
export class RTCoverNoteComponent implements OnInit {
    public datainput: any;
    public closeDialog: Function;
    public parentCompPRMS: any;

    public rtObj: any;
    public headerObj: any;
    private caseInfo: any;
    public rtCoverNote: RTCoverNote;
    public riskObj: any;
    public isReadyOnly: boolean;
    public coverage: any;
    public coverNoteTypes: any;
    public _appUtil: AppUtil;
    private startDateCtrl: any;
    private endDateCtrl: any;
    private transactionDateCtrl: any;
    public rtCoverNoteArray = [];
    public dateSentToJPJCtrl: any;
    public dateRecJPJCtrl: any;
    public hasTrailer: boolean = false;

    public itemPerPage = 3;
    public maxPageCount = 3;
    public position = 1;
    public sizeObj = { length: 0, orglength: 0 };
    public contentSizeObs: any;



    constructor(public _alertMsgService: AlertMessagesService, private lovDropDownService: LOVDropDownService, public _appObjService: BMSAppObjService, private _cordysService: CordysSoapWService, private cnService: CoverNoteService) { }

    ngOnInit() {
        this.setVars();
        this.populateLOVs();
        this.initRTData();
        this.handleDateFileds();


    }
    lovMapping() {
        if (this.rtCoverNote.vehicalClass != '' || this.rtCoverNote.vehicalClass != undefined) {
            this.lovDropDownService.createLOVDataList(["UseOfVehicle"]);
            let filterDetails = [new SearchFilter("DESCITEM", this.rtCoverNote.vehicalClass, "STARTSWITH", "AND")];
            let searchFilterNodes = this.lovDropDownService.createFilter(filterDetails);
            let lovFields = [new LOV_Field("ALL", "MOTOR", "NEW BUSINESS", "ALL", "NEW", "PRIVATE_MOTOR", "Use of Vehicle", "LOV", searchFilterNodes, "DESCPF", "UseOfVehicle", "successCallBackVehicleUse")];
            this.lovDropDownService.util_populateLOV(lovFields, this);
        }

    }
    successCallBackVehicleUse(scopeObject) {
        scopeObject.riskObj.use = scopeObject.riskObj.use;
        scopeObject.riskObj.useDesc = AppUtil.getValueByPathFromAry(scopeObject.riskObj.use, "VALUE", "DESCRIPTION", scopeObject.lovDropDownService.lovDataList.UseOfVehicle);



    }
    handleDateFileds() {
        if (!this.rtCoverNote || !this.startDateCtrl || !this.endDateCtrl || this.isReadyOnly) {
            return;
        }

        // handle max and min dates

        if (this.rtCoverNote.coverNoteType == "EC") {
            let startDate = moment.utc(new Date()).format("YYYY-MM-DD");
            let endDate = moment(this.headerObj.endDate).format("YYYY-MM-DD");
            this.startDateCtrl.setMinDate(moment(startDate), this.startDateCtrl.comp);
            this.startDateCtrl.setMaxDate(moment(endDate), this.startDateCtrl.comp);
            this.endDateCtrl.setMaxDate(moment(endDate), this.endDateCtrl.comp);
        }
        if (this.rtCoverNote.coverNoteType == "CE") {

            this.startDateCtrl.setDisable('N', this.startDateCtrl.comp);
            this.endDateCtrl.setDisable('Y', this.endDateCtrl.comp);
            this.rtCoverNote.inceptionDate = moment(new Date().toISOString(), "YYYYMMDD").format("YYYY-MM-DD");
            this.startDateCtrl.setter(this.rtCoverNote.inceptionDate, "YYYY-MM-DD", this.startDateCtrl.comp);
            this.rtCoverNote.endDate = this.headerObj.endDate;
            this.endDateCtrl.setter(this.rtCoverNote.endDate, "YYYY-MM-DD", this.endDateCtrl.comp);

        }
        else if (this.rtCoverNote.coverNoteType == "ED") {

            let date = moment.utc(new Date()).format("YYYY-MM-DD");
            let startDate = moment(this.headerObj.endDate).format("YYYY-MM-DD");
            startDate = moment.utc(startDate).add(1, 'days').format("YYYY-MM-DD");
            let eDate = moment.utc(startDate).add(364, 'days').format("YYYY-MM-DD");
            this.startDateCtrl.setMinDate(moment(date), this.startDateCtrl.comp);
            this.startDateCtrl.setMaxDate(moment(startDate), this.startDateCtrl.comp);
            this.endDateCtrl.setMaxDate(moment(eDate), this.endDateCtrl.comp);

            this.startDateCtrl.setDisable('Y', this.startDateCtrl.comp);
            this.endDateCtrl.setDisable('N', this.endDateCtrl.comp);
            let endDate = moment.utc(this.headerObj.endDate).add(1, 'days').format("YYYY-MM-DD");
            this.rtCoverNote.inceptionDate = endDate;
            this.startDateCtrl.setter(this.rtCoverNote.inceptionDate, "YYYY-MM-DD", this.startDateCtrl.comp);
            //MYS-2019-0805 - Extension (ED) not having end date set Hence setting end - MSU --start
            
            //this.endDateCtrl.setter("", "YYYY-MM-DD", this.endDateCtrl.comp);
            //this.rtCoverNote.endDate = (this.endDateCtrl.comp.value != "") ? this.endDateCtrl.comp.value : date;
            //this.rtCoverNote.endDate = this.endDateCtrl.comp.value;            
            this.rtCoverNote.endDate = this.endDateCtrl.comp.value != "" ? this.endDateCtrl.comp.value : ""; 
            
            //End
        }

        else if (this.rtCoverNote.coverNoteType == "RT" || this.rtCoverNote.coverNoteType == "EC") {

            this.startDateCtrl.setDisable('N', this.startDateCtrl.comp);
            this.endDateCtrl.setDisable('N', this.endDateCtrl.comp);

        }

    }

    setVars() {
        this.riskObj = this.datainput.riskObj;
        this.headerObj = BMSConstants.getBMSHeaderInfo();
        this.caseInfo = BMSConstants.getBMSCaseInfo();
        this.handleTrailerCase();
        this._appUtil = new AppUtil();
    }

    handleTrailerCase() {
        let riskObj = this.datainput.riskObj;
        this.hasTrailer = riskObj.hasTrailer();
    }

    populateLOVs() {
        let request = new BMSLOVRequest().getLOVRequest("Coverage", null);
        this._cordysService.callCordysSoapService("GetLOVData",
            "http://schemas.opentext.com/lovhandler/v1.0", request, null, null, true, this)
            .success((data) => {
                this.coverage = this._appUtil.getArray(data.tuple);
                //populate cover note types

                request = new BMSLOVRequest().getLOVRequest("CoverNoteType", null);
                request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
                request.ADVANCE_CONFIG_XML.FILTERS = new Filter();

                this._cordysService.callCordysSoapService("GetLOVData",
                    "http://schemas.opentext.com/lovhandler/v1.0", request, null, null, true, this)
                    .success((data) => {
                        this.coverNoteTypes = this._appUtil.getArray(data.tuple);

                    })
                    .error((data) => {
                        this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error while getting CoverNoteTypes", 10000));

                    });
                //
            })
            .error((data) => {
                this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error while getting Coverage Info.", 10000));

            });
    }

    ngAfterViewInit() {
        this.initiateTooltip();
    }

    initiateTooltip() {
        jQuery('[data-toggle="tooltip"]').tooltip();
    }

    initRTData() {
        let policyNo = BMSConstants.getBMSCaseInfo().policyNumber;
        this._appObjService.getRTCaseForPolicy(policyNo).subscribe(() => {
            let rtRisks = BMSConstants.getRTRisks();
            let miscObj = BMSConstants.getMsicObj();
            let riRskObj = miscObj.getRTObjByRiskNumber(this.riskObj.riskNumber);
            if (AppUtil.isEmpty(riRskObj, false) == false)
                this.rtObj = riRskObj;
            else {
                this.rtObj = new Risk();
                miscObj.add(this.rtObj);
            }
            this.rtObj.riskNumber = this.riskObj.riskNumber;
            this.rtCoverNoteArray = this.rtObj.risk.rtCoverNote;

        });
    }

    private addRTCoverNote(type) {
        let rtItem = new RTCoverNote().getNewInstance(this.datainput.riskObj, this.datainput.client, type, this.headerObj);
        this.rtCoverNoteArray.push(rtItem);
        this.resetSeqNumber();

    }

    public removeRTItem(rtItem) {
        let idx = this.rtCoverNoteArray.indexOf(rtItem);
        if (this.rtCoverNote != null && rtItem.serialNo == this.rtCoverNote.serialNo) {
            this.rtCoverNote = null;
        }
        this.rtCoverNoteArray.splice(idx, 1);
        this.resetSeqNumber();
        this._appObjService.setCnTrnData("D", this.datainput.riskObj.riskNumber, rtItem.coverNoteNo);
        this._appObjService.saveRTData().subscribe();
    }

    private resetSeqNumber() {
        for (let eachRT of this.rtCoverNoteArray) {
            let index = this.rtCoverNoteArray.indexOf(eachRT);
            eachRT.sequenceNo = "" + (index + 1);
            eachRT.serialNo = eachRT.sequenceNo;
        }
    }

    setStartDateRange() {
        if (this.startDateCtrl != null) {
            let endDate, date, dateValue;
            dateValue = this.rtCoverNote.inceptionDate;
            date = moment.utc(new Date()).format("YYYY-MM-DD");
            if (dateValue != null && dateValue != NaN && dateValue != "") {
                let diffDate = moment(new Date()).diff(moment(dateValue), 'days');
                if (diffDate > 0) {
                    date = moment.utc(dateValue).format("YYYY-MM-DD");
                }
            }
            endDate = moment(this.headerObj.endDate).format("YYYY-MM-DD");
            if (this.rtCoverNote.coverNoteType == "RT" || this.rtCoverNote.coverNoteType == "EC" || this.rtCoverNote.coverNoteType == "NV") {
                this.startDateCtrl.setMinDate(moment(date), this.startDateCtrl.comp);
                this.startDateCtrl.setMaxDate(moment(endDate), this.startDateCtrl.comp);
            }


        }
    }


    setEndDateRange() {
        if (this.endDateCtrl != null) {
            let date, endDate;
            if (this.startDateCtrl != null) {
                date = moment.utc(this.startDateCtrl).format("YYYY-MM-DD");

            } else {
                date = moment.utc(new Date()).format("YYYY-MM-DD");

            }
            this.endDateCtrl.setMinDate(moment(date), this.endDateCtrl.comp);
            
           //this.endDateCtrl.setter('2022-01-01', 'YYYY-MM-DD', this.endDateCtrl.comp);
        }
        else
        {
            this.endDateCtrl.setter(this.startDateCtrl.comp.VALUE, 'YYYY-MM-DD', this.endDateCtrl.comp);
        }
        //else
        //this.endDateCtrl.setter('2022-02-02', 'YYYY-MM-DD', this.endDateCtrl.comp);

    }

    setEndDate() {
        if (this.rtCoverNote.coverNoteType == 'ED' || this.rtCoverNote.coverNoteType == 'CE') {
            return;

        }
        if (this.endDateCtrl != null && this.rtCoverNote.inceptionDate != null) {
            let endDate = moment.utc(this.rtCoverNote.inceptionDate).add(364, 'days').format("YYYY-MM-DD");
            if (this.rtCoverNote.coverNoteType == "EC") {
                this.endDateCtrl.setMaxDate(moment(endDate), this.endDateCtrl.comp);
                this.endDateCtrl.setter(moment(endDate), 'YYYY-MM-DD', this.endDateCtrl.comp);
            }
        }

    }

    handleButtons() {
        if (this.rtCoverNote.status == 'Not Initiated' || this.rtCoverNote.status == "JPJ Rejected")
            this.isReadyOnly = false;
        else
            this.isReadyOnly = true;
    }

    createCoverNote() {
        if (this.rtCoverNote != null) {
            let lovMappingDetails = this.lovMapping();


            let result = new RTCNValidator(this.rtCoverNote).validate();

            if (result.isValid == true) {
                ProgressBarComponent.show('Creating CoverNote is in Progress', { dialogSize: 'm', progressType: 'primary' });
                this.cnService.createRTCoverNote(this.riskObj.riskNumber, this.rtCoverNote.serialNo, (this.rtCoverNote.type == 'Trailer') ? 'T' : 'PM', this.rtCoverNote.coverNoteNo, this.rtCoverNote.coverNoteType).subscribe(
                    (data) => {
                        this.transactionDateCtrl.setter(this.rtCoverNote.transactionDate, "YYYY-MM-DD", this.transactionDateCtrl.comp);
                        this.handleButtons();
                        this.handleDateCtrls();
                        ProgressBarComponent.hide();
                    },
                    (error) => ProgressBarComponent.hide()
                );
            }
            else
                this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, result.message, -1));
        }
        else
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Please select one item to proceed.", 10000));
    }

    private cancelCoverNote(rtItem) {
        this.selectRTCN(rtItem);
        ProgressBarComponent.show('Cancelling CoverNote is in Progress', { dialogSize: 'm', progressType: 'primary' });
        this.cnService.coverNoteServiceRT(BMSConstants.getRTCaseID(), this.rtCoverNote.coverNoteType, "CANCEL", this.datainput.riskObj.riskNumber, this.rtCoverNote.serialNo, (this.rtCoverNote.type == 'Trailer') ? 'T' : 'PM').subscribe(
            (data) => this.aftercancelCoverNoteService(data, rtItem),
            error => ProgressBarComponent.hide()
        );
    }

    private aftercancelCoverNoteService(data, rtItem) {
        this.rtCoverNote.status = 'Cover Note Cancelled';
        this.rtCoverNote.coverNoteStatus = 'Cover Note Cancelled';
        this.handleButtons();
        this.handleDateCtrls();
        this._appObjService.setCnTrnData("U", this.datainput.riskObj.riskNumber, rtItem.coverNoteNo);
        this._appObjService.saveRTData().subscribe(() => {
            ProgressBarComponent.hide();
        });
    }

    public modifyCoverNote(rtItem) {
        this.selectRTCN(rtItem);
        ProgressBarComponent.show('Modify CoverNote is in Progress', { dialogSize: 'm', progressType: 'primary' });
        this._appObjService.saveRTData().subscribe(() => {
            this.cnService.coverNoteServiceRT(BMSConstants.getRTCaseID(), this.rtCoverNote.coverNoteType, "MODIFY", this.datainput.riskObj.riskNumber, this.rtCoverNote.serialNo, (this.rtCoverNote.type == 'Trailer') ? 'T' : 'PM').subscribe(
                (data) => this.afterModifyCoverNoteService(data, rtItem),
                error => ProgressBarComponent.hide()
            );
        });
    }

    private afterModifyCoverNoteService(data, rtItem) {
        this.rtCoverNote.status = 'Pending JPJ Reply';
        this.rtCoverNote.coverNoteStatus = 'Cover Note Modified';
        this._appObjService.setCnTrnData("U", this.datainput.riskObj.riskNumber, rtItem.coverNoteNo);
        this._appObjService.saveRTData().subscribe(() => {
            ProgressBarComponent.hide();
        });
    }

    private handleDateCtrls() {
        let isDisable = (this.rtCoverNote.status != 'Not Initiated' && this.rtCoverNote.status != "JPJ Rejected") ? 'Y' : 'N';

        if (this.startDateCtrl != null) {
            this.startDateCtrl.setDisable(isDisable, this.startDateCtrl.comp);
            if (this.rtCoverNote.inceptionDate == undefined || this.rtCoverNote.inceptionDate == '')
                this.startDateCtrl.setter("EMPTY", "YYYY-MM-DD", this.startDateCtrl.comp);
            else
                this.startDateCtrl.setter(this.rtCoverNote.inceptionDate, "YYYY-MM-DD", this.startDateCtrl.comp);
        }

        if (this.endDateCtrl != null) {
            this.endDateCtrl.setDisable(isDisable, this.endDateCtrl.comp);
            if (this.rtCoverNote.endDate == undefined || this.rtCoverNote.endDate == '')
                this.endDateCtrl.setter("EMPTY", "YYYY-MM-DD", this.endDateCtrl.comp);
            else
                this.endDateCtrl.setter(this.rtCoverNote.endDate, "YYYY-MM-DD", this.endDateCtrl.comp);
        }

        if (this.transactionDateCtrl != null) {
            if (this.rtCoverNote.transactionDate == undefined || this.rtCoverNote.transactionDate == '')
                this.transactionDateCtrl.setter("EMPTY", "YYYY-MM-DD", this.transactionDateCtrl.comp);
            else
                this.transactionDateCtrl.setter(this.rtCoverNote.transactionDate, "YYYY-MM-DD", this.transactionDateCtrl.comp);
        }

        if (this.dateRecJPJCtrl != null) {
            if (this.rtCoverNote.dateReply == undefined || this.rtCoverNote.dateReply == '')
                this.dateRecJPJCtrl.setter("EMPTY", "YYYY-MM-DD", this.dateRecJPJCtrl.comp);
            else
                this.dateRecJPJCtrl.setter(this.rtCoverNote.dateReply, "YYYY-MM-DD", this.dateRecJPJCtrl.comp);
        }

        if (this.dateSentToJPJCtrl != null) {
            if (this.rtCoverNote.dateSentToJPJ == undefined || this.rtCoverNote.dateSentToJPJ == '')
                this.dateSentToJPJCtrl.setter("EMPTY", "YYYY-MM-DD", this.dateSentToJPJCtrl.comp);
            else
                this.dateSentToJPJCtrl.setter(this.rtCoverNote.dateSentToJPJ, "YYYY-MM-DD", this.dateSentToJPJCtrl.comp);
        }
        //this.setStartDateRange();
    }

    public selectRTCN(rtItem) {
        this.rtCoverNote = rtItem;
        this.handleButtons();
        this.handleDateCtrls();
        this.handleDateFileds();
		
    }

    public generateSummary(rtCoverItem) {
        ProgressBarComponent.show('Generating document. Please wait...', { dialogSize: 'm', progressType: 'primary' });
        this.cnService.attachMiscReportToCase(BMSConstants.getRTCaseID(), rtCoverItem.coverNoteNo, this.riskObj.riskNumber).subscribe((data) => {
            ProgressBarComponent.hide();
            this.addProcessHistoryRecord("Report " + "'" + data.reportName + "' Attached", "SELF", "SELF", "-");
            this._appObjService.saveRTData().subscribe();
            this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Document generated successfully and attached to the case.", -1));
        },
            (error) => {
                ProgressBarComponent.hide();
            });
    }


    private addProcessHistoryRecord(action, target, targetType, comments) {
        var newApprovalNode = new Approval();
        newApprovalNode.action = action;
        newApprovalNode.target = target
        newApprovalNode.targetType = targetType;
        newApprovalNode.comment = comments;
        newApprovalNode.user = BMSConstants.getUserName();
        let caseInfo = BMSConstants.getRTBMSCaseInfo();
        caseInfo.approvalInfo.addItem(newApprovalNode);
    }

    private calculatePremium() {
        this.rtCoverNote.setPOIBasedCalc(this.riskObj);
    }

    private handleCNTypeChange() {
        this.rtCoverNote.setPremiumVals(this.riskObj, this.headerObj);
        //Refresh POI
        this.startDateCtrl.setter("EMPTY", "YYYY-MM-DD", this.startDateCtrl.comp);
        this.endDateCtrl.setter("EMPTY", "YYYY-MM-DD", this.endDateCtrl.comp);
        //Hanlde date fields
        this.handleDateFileds();
    }
}
