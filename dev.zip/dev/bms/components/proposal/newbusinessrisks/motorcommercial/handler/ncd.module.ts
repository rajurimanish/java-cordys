import { NgModule } from '@angular/core';
import { NCDService } from './ncd.service';

@NgModule({
    providers: [NCDService]
})
export class NCDModule { }