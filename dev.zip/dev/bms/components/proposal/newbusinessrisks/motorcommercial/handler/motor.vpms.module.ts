import { NgModule } from '@angular/core';

import { MotorVPMSService } from './motor.vpms.service';

@NgModule({
    providers: [MotorVPMSService]
})
export class MotorVPMSModule { }