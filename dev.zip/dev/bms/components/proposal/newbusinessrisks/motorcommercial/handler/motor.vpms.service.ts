import { Injectable } from '@angular/core';
import { BMSConstants } from '../../../../common/constants/bms_constants';
import { MotorValidator } from '../../../validation/motor.validator';
import { AlertMessagesService } from '../../../../../../common/components/utility/alertmessage/alertmessages.service';
import { AlertMessage } from '../../../../../../common/components/utility/alertmessage/alertmessages.model';
import { CordysSoapWService } from "../../../../../../common/components/utility/cordys-soap-ws";
import { RiskArray } from '../../../proposalheader/uimodules/riskArray';
import { AppUtil } from '../../../../../../common/components/utility/apputil/app.util';
declare var Rx: any;
declare var Observer: any;
import { BMSAppObjService } from '../../../../../services/bmsappobj.service';

@Injectable()
export class MotorVPMSService {
    public premiumFormat: string = '0.00';

    constructor(private _soapService: CordysSoapWService, public _alertMsgService: AlertMessagesService, private _appObjService: BMSAppObjService) { }

    setPremiumCalcInfo(response, eachRisk, observer) {
        if (response.fault == null) {
            let premiumCalculator = response.success.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.premiumCalculator;
            let risks = response.success.ApplicationBusinessObject.businessObject.bms.newBusiness.risks;

            let riskAryName = new RiskArray().getArrayByRiskType(eachRisk.riskType);
            new AppUtil().handleArray(risks, risks, riskAryName);
            let mtrRisks = risks[riskAryName];

            let matchingRisk = mtrRisks.filter((mtrRisk) => mtrRisk.riskNumber == eachRisk.riskNumber);
            if (matchingRisk.length == 1) {
                eachRisk.premiumCalculator = premiumCalculator;
                eachRisk.setPremiumInfo(matchingRisk[0].premiumInfo, matchingRisk[0]);
                eachRisk.premiumInfoFlag = "Y";
            }
        }
        else
            this.handleError(response);

        observer.next("");
    }

    public handleError(response) {
        let error = "Error occurred while invoking VPMS service.";
        let errorAry = [];
        if (response.errors != null && response.errors.message)
            errorAry = new AppUtil().getArray(response.errors.message);
        if (errorAry.length > 0) {
            let index = 1;
            for (let eachEr of errorAry) {
                if (eachEr.text != null && eachEr.text.startsWith("ADB")) {
                    let adbEr = this.getAddBenErr(eachEr.text);
                    if (adbEr != "")
                        error = error + "<p>" + index + ") " + adbEr + "</p>";
                    index++
                }
                else if (eachEr.text != null && eachEr.text.startsWith("BSP")) {
                    let premEr = this.getPremErr(eachEr.text);
                    if (premEr != "")
                        error = error + "<p>" + index + ") " + premEr + "</p>";
                    index++
                }
            }
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, error, -1));
        }

    }

    public getAddBenErr(error) {
        let message = "";
        if (error != null) {
            message = error.replace("ADB:", "");
            if (message.indexOf("does not contain key ") != -1) {
                let msgs = message.split("does not contain key ");
                if (msgs.length > 1) {
                    message = "Additional benefit code " + msgs[1] + " is not supported by VPMS.";
                }
            }
            else
                message = "Additional benefit error: " + message;
        }

        return message;
    }

    public getPremErr(error) {
        let message = "";
        if (error != null)
            message = error.replace("BSP:", "");

        return message;
    }

    public calculate(eachRisk, observer) {
        let caseID = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.caseId;
        let respProm = this._soapService.callCordysSoapService("CalculatePremiumRequest", "http://schemas.insurance.com/businessobject/1.0/", { caseId: caseID, riskno: eachRisk.riskNumber }, null, null, true, null);
        respProm.success((response) => this.setPremiumCalcInfo(response, eachRisk, observer));
        respProm.error((error) => {
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Premium service is down. Error occurred while getting premium calculation info.", -1));
        });
    }

    public getQuote(risk) {
        return Rx.Observable.create((observer) => {
            risk.premiumInfoFlag = "N";
            let result = new MotorValidator(risk).validatePremiumInfoInput();
            if (result.isValid) {
                this._appObjService.saveData().subscribe((data) => this.calculate(risk, observer));
            }
            else {
                this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, result.message, -1));
            }
        });
    }
}