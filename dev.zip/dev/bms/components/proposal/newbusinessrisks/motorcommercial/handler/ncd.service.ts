/*
 * Change History:
 * 
 * No      Date          Description                                   Changed By
 * ====    ==========    ===========                                   ==========
 *KA0001  26/03/2018   MYS-2017-1062 - To move DPA from PA to MTR LOB     Divek
 MD002   14/03/2019    MYS-2018-0877    -  Renewal for Phase2a products                     MKU1 
*/
import { Injectable } from '@angular/core';
import { CordysSoapWService } from '../../../../../../common/components/utility/cordys-soap-ws';
import { NCDRequest } from '../appobjects/ncdRequest';
import { BMSConstants } from '../../../../common/constants/bms_constants';
import { BMSEvents } from '../../../events/bms.events';
import { AlertMessagesService } from '../../../../../../common/components/utility/alertmessage/alertmessages.service';
import { AlertMessage } from '../../../../../../common/components/utility/alertmessage/alertmessages.model';
import { ProgressBarComponent } from '../../../../../../common/components/utility/progressbar/progressbar.component';
import { ENCDDetails } from '../appobjects/encdDetails';
import { RiskArray } from '../../../proposalheader/uimodules/riskArray';
declare var Rx: any;
declare var Observer: any;

declare var jQuery: any;
declare var numeral: any;
declare var moment: any;
@Injectable()
export class NCDService {

    private _businessObject;
    private header;
    private _risks;
    private mCount;
    public riskArray: RiskArray = new RiskArray();
    constructor(private _cordysService: CordysSoapWService, public _alertMsgService: AlertMessagesService) { }

    initializeGVariables() {
        this._businessObject = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject;
        this.header = this._businessObject.bms.newBusiness.headerInfo;
        this._risks = this._businessObject.bms.newBusiness.risks;
    }

    public getNCDDetails(curObj, successHandler, errorHandler) {
        this.initializeGVariables();
        if (this.header.lineOfBusiness === "MTR") {
            let _motorCommercial = this._risks[this.riskArray.getArrayByRiskType(this.header.contractType)];
            let vehicleCondition = "ENQ";
            //_motorCommercial[0].cover
            let ncdParams: NCDRequest = new NCDRequest(this.header.agentCode, "3", _motorCommercial[0].PIAMStatistics.chassisNo, _motorCommercial[0].registrationNumber, vehicleCondition, this.getIdNo(), "", "",
                _motorCommercial[0].PIAMStatistics.previousInsurer, _motorCommercial[0].PIAMStatistics.previousPolicyNumber, "", _motorCommercial[0].PIAMStatistics.vehicalRegNo,
                _motorCommercial[0].riskType, "BP" + new Date().valueOf(), "BPM", _motorCommercial[0].vehClassCode, _motorCommercial[0].use);

            this._cordysService.callCordysSoapService("getNCDReqDetails", "http://ws.msig.com.my", { request: ncdParams }, null,
                null, true, null)
                .success((data) => this.getNCDSuccessHandler(data))
                .error((response, status, errorText) => this.getNCDErrorHandler(response, status, errorText));
        }
        else {

            BMSEvents.MotorcommercialBeforeP400.getNCDEndTrigger.next("NA");
        }

    }
    private getNCDSuccessHandler(response) {

        let _motorCommercialArray = this._risks[this.riskArray.getArrayByRiskType(this.header.contractType)];
        let _motorCommercial = _motorCommercialArray[0];

        let data = response.getNCDReqDetailsReturn;

        if ((data.nextNcdPercent != undefined && data.nextNcdPercent != "") && numeral().unformat(data.nextNcdPercent) > 0 && !(moment(data.nxtNCDEffDt, "DDMMYYYY") > moment(this.header.effectiveDate, "YYYY-MM-DD"))) {
            _motorCommercial.fleetDiscountPercentage = data.nextNcdPercent;
            _motorCommercial.CFY = data.nxtNCDLevel;
            this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "NCD Inquiry has been sent to ISM. Click View NCD to see details", 10000));
        }
        else {
            _motorCommercial.fleetDiscountPercentage = '0.0';
            _motorCommercial.CFY = '';
            if (data.nextNcdPercent != undefined && data.nextNcdPercent != "")
                this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "No NCD% allowed due to next NCD percentage is 0", 10000));
        }
        //prms.curcomp.appCode = data.appCode;
        _motorCommercial.ENCDDetails = new ENCDDetails();
        let _encDetails = _motorCommercial.ENCDDetails;
        _encDetails.appCode = data.appCode;
        _encDetails.curNCDEffDt = data.curNCDEffDt;
        _encDetails.curNCDExpDt = data.curNCDExpDt;
        _encDetails.curNCDLevel = data.curNCDLevel;
        _encDetails.curNCDPercent = data.curNCDPercent;
        _encDetails.insCode = data.insCode;
        _encDetails.nextNcdPercent = data.nextNcdPercent;
        _encDetails.nxtNCDEffDt = data.nxtNCDEffDt;
        _encDetails.nxtNCDLevel = data.nxtNCDLevel;
        _encDetails.respCode = data.respCode;
        if (data.respCode)
            _encDetails.respCodeDesc = data.respCode.substr(3, 6);
        _encDetails.preInsCode = data.preInsCode;
        _encDetails.refNo = data.refNo;

        BMSEvents.MotorcommercialBeforeP400.getNCDEndTrigger.next("SUCCESS");

    }
    private getNCDErrorHandler(response, status, errorText) {
        this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, response.responseJSON.faultstring.text, 10000));
        BMSEvents.MotorcommercialBeforeP400.getNCDEndTrigger.error("ERROR");

    }
    // KA0001 Start Divek added conditon to skip NCD validation for DPA 
    public confirmNCD() {
        return Rx.Observable.create((observer) => {
            this.initializeGVariables();
            this.mCount = 0;
            if (this.header.lineOfBusiness === "MTR" && this.header.contractType != 'DPA' && this.header.contractType != 'MPA' && this.header.contractType != 'MSW' && this.header.contractType != 'MWP') {//md002
                let _motorCommercial = this._risks[this.riskArray.getArrayByRiskType(this.header.contractType)];
                //(this._risks.motorMPV != null && this._risks.motorMPV.length > 0 )?this._risks.motorMPV : this._risks.motorMCV;

                if (_motorCommercial == null) {
                    this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "No proper risk information present", -1));
                    observer.error("ERROR");

                }
                else {

                    for (var i = 0; i < _motorCommercial.length; i++) {
                        let vehicleCondition = (_motorCommercial[i].PIAMStatistics.vehicalCondition === "N") ? "CFN" : "CFO";
                        let index = i;
                        if ((_motorCommercial[i].vehicalClass != 'AT' && _motorCommercial[i].vehicalClass != 'CT') && _motorCommercial[i].ENCDDetails == undefined) {
                            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Please call NCD Enquiry (Call ISM button) before calling NCD confirmation", -1));
                            observer.error("ERROR");

                        }
                        else {
                            /** need to check this condition */
                            if ((_motorCommercial[i].ENCDDetails.appCode == undefined || _motorCommercial[i].ENCDDetails.appCode == '') && (_motorCommercial[i].ENCDDetails.ncdCfnRespCode != 'CFN000' && _motorCommercial[i].ENCDDetails.ncdCfnRespCode != 'CFO000')) {
                                //_motorCommercial[i].cover
                                let ncdParams: NCDRequest = new NCDRequest(this.header.agentCode, "3", _motorCommercial[i].PIAMStatistics.chassisNo, _motorCommercial[i].registrationNumber, vehicleCondition,
                                    this.getIdNo(), "", "", _motorCommercial[i].PIAMStatistics.previousInsurer, _motorCommercial[i].PIAMStatistics.previousPolicyNumber, "",
                                    _motorCommercial[i].PIAMStatistics.vehicalRegNo, _motorCommercial[i].riskType, "BP" + new Date().valueOf(), "BPM", _motorCommercial[i].vehClassCode,
                                    _motorCommercial[i].use);
                                this._cordysService.callCordysSoapService("getNCDReqDetails", "http://ws.msig.com.my", { request: ncdParams }, null, null, true, { index: i })
                                    .success((data) => {
                                        this.confirmNCDSuccessHandler(data, index, observer);
                                    })
                                    .error((response, status, errorText) => this.confirmNCDErrorHandler(response, status, errorText, observer));
                            }
                            else {
                                this.mCount += 1;
                                if (this.mCount == _motorCommercial.length)
                                    observer.next("SUCCESS");
                            }

                        }
                    }
                }
            }
            else
                observer.next("NA");
        });
    }
    // KA0001 END
    private confirmNCDSuccessHandler(data, index, observer) {

        let _motorCommercialArray = this._risks[this.riskArray.getArrayByRiskType(this.header.contractType)];
        let _motorCommercial = _motorCommercialArray[index];
        let _encDetails = _motorCommercial.ENCDDetails;

        if (_encDetails) {

            _encDetails.ncdCfnRespCode = data.getNCDReqDetailsReturn.respCode;

            if (data.getNCDReqDetailsReturn.respCode == 'CFO000' || data.getNCDReqDetailsReturn.respCode == 'CFN000') {
                if (numeral().unformat(data.getNCDReqDetailsReturn.nextNcdPercent) > 0 && !(moment(data.getNCDReqDetailsReturn.nxtNCDEffDt, "DDMMYYYY") > moment(this.header.effectiveDate, "YYYY-MM-DD"))) {
                    _motorCommercial.fleetDiscountPercentage = data.getNCDReqDetailsReturn.nextNcdPercent;
                    _motorCommercial.CFY = data.getNCDReqDetailsReturn.nxtNCDLevel;
                } else {
                    _motorCommercial.fleetDiscountPercentage = '0.0';
                    _motorCommercial.CFY = '';
                    this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "No NCD% allowed due to next NCD percentage is 0", 10000));
                }
                _encDetails.appCode = data.getNCDReqDetailsReturn.appCode;
                _encDetails.curNCDEffDt = data.getNCDReqDetailsReturn.curNCDEffDt;
                _encDetails.curNCDExpDt = data.getNCDReqDetailsReturn.curNCDExpDt;
                _encDetails.curNCDLevel = data.getNCDReqDetailsReturn.curNCDLevel;
                _encDetails.curNCDPercent = data.getNCDReqDetailsReturn.curNCDPercent;
                _encDetails.insCode = data.getNCDReqDetailsReturn.insCode;
                _encDetails.nextNcdPercent = data.getNCDReqDetailsReturn.nextNcdPercent;
                _encDetails.nxtNCDLevel = data.getNCDReqDetailsReturn.nxtNCDLevel;
                _encDetails.preInsCode = data.getNCDReqDetailsReturn.preInsCode;
                _encDetails.respCode = data.getNCDReqDetailsReturn.respCode;
                _encDetails.respCodeDesc = data.getNCDReqDetailsReturn.respCode.substr(3, 6);
                _encDetails.refNo = data.getNCDReqDetailsReturn.refNo;
            }

        }
        this.mCount += 1;
        if (this.mCount == _motorCommercialArray.length) {
            observer.next("SUCCESS");
        }
    }
    confirmNCDErrorHandler(response, status, errorText, observer) {

        // ProgressBarComponent.hide();
        this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Get NCD Details Failed", -1));
        observer.error("ERROR");

    }
    cancelNCD() {
        return Rx.Observable.create((observer) => {
            this.initializeGVariables();
            let productObj = this._risks[this.riskArray.getArrayByRiskType(this.header.contractType)][0];
            //productObj.cover
            let ncdParams: NCDRequest = new NCDRequest(this.header.agentCode, "3", productObj.PIAMStatistics.chassisNo, productObj.registrationNumber, "CCN", this.getIdNo(), "", "",
                productObj.PIAMStatistics.previousInsurer, productObj.PIAMStatistics.previousPolicyNumber, "", productObj.PIAMStatistics.vehicalRegNo, productObj.riskType,
                "BP" + new Date().valueOf(), "BPM", productObj.vehClassCode, productObj.use);
            this._cordysService.callCordysSoapService("getNCDReqDetails", "http://ws.msig.com.my", { request: ncdParams }, null, null, true, { curcomp: this })
                .success((data) => {
                    observer.next("SUCCESS");
                })
                .error((response, status, errorText) => observer.error("ERROR"));
        });
    }
    private getIdNo(): string {
        let idNo: string = "";
        if (this._businessObject.bms.newBusiness.clientDetails) {
            let _client = this._businessObject.bms.newBusiness.clientDetails.client;
            if (_client.genericDetails.clienttype == 'C')
                idNo = _client.corporateClientDetails.BusinessRegNo;
            else if (_client.genericDetails.clienttype == 'P') {
                if (_client.personalClientDetails.NRICNo)
                    idNo = _client.personalClientDetails.NRICNo;
                else if (_client.personalClientDetails.IdNumber)
                    idNo = _client.personalClientDetails.IdNumber;
            }
        }
        return idNo.replace(/[-]/g, "");
    }
    validateEmpty(field) {
        if (field != undefined && field != "")
            return true;
        else
            return false;
    }
}