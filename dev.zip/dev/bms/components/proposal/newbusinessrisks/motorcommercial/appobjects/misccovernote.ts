
/* 
 *
 * Change History:		
 * 
 * No      Date				Description												Changed By
 * ====    ==========		===========												==========
 * 
 * SU001   15/07/2019		MYS-2019-0805 : Unable to post Miscellaneous            MSU
 *						    Cover Note for non-trailer in BMS
 *
 * 
 */


import { AppUtil } from '../../../../../../common/components/utility/apputil/app.util';
import { FinancialInterest } from '../../../../../../common/components/financialinterest/appobjects/financialInterest';
import { MotorItems } from '../../appobjects/motorItems';
import { NamedDriver } from './nameddriver';
import { BMSUtilService } from '../../../../../services/bms.util.service';

declare var moment: any;
declare var numeral: any;

export class MiscCoverNote {
    /**Add other miscCoverNote types here */
    public rtCoverNote: RTCoverNote[] = [];
    constructor() { }
    public getInstance(valObj: MiscCoverNote) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().handleArray(this, valObj, "rtCoverNote");
            for (let item of this.rtCoverNote) {
                let itemObj = new RTCoverNote().getInstance(item);
                this.rtCoverNote[this.rtCoverNote.indexOf(item)] = itemObj;
            }
        }
        return this;
    }
}
export class RTCoverNote {
    public serialNo: string;
    public coverNoteNo: string = '';
    public coverNoteStatus: string = 'Not Initiated';
    public coverNoteType: string = 'RT';
    public nric: string = '';
    public registrationNumber: string = '';
    public oldIc: string = '';
    public engineNumber: string = '';
    public chasisNumber: string = '';
    public cover: string = '';
    public inceptionDate: string = '';
    public endDate: string = '';
    public transactionDate: string = '';
    public dateSentToJPJ: string = '';
    public timeSentToJPJ: string = '';
    public dateReply: string = '';
    public timeReceivedFromJPJ: string = '';
    public reason: string = '';
    public status: string = 'Not Initiated';
    public message: string = '';
    public comments: string = '';
    public type: string = 'Prime Mover / Other Vehicle';
    public clientName: string = "";
    public clientType: string = "";
    public gstCoding: string = "";
    public address1: string = "";
    public address2: string = "";
    public address3: string = "";
    public address4: string = "";
    public clntPhone: string = "";
    public make: string = "";
    public model: string = "";
    public makeModelDescription: string = "";
    public use: string = "";
    public useDesc: string = "";
    public suminsured: string = "";
    public typeofBody: string = "";
    public ncdPercentage: string = "";
    public excess: string = "";
    public capacity: string = "";
    public capacityType: string = "";
    public vehicalClass: string = "";
    public yom: string = "";
    public seatingCapacity: string = "";
    public financialInterest: FinancialInterest;
    public motorItems: MotorItems;
    public driverDetails: NamedDriver;
    public totalPremium: number = 0;
    public newTotalPremium: number = 0;
    public basicPremium: number = 0;
    public loadingPercentage: number = 0;
    public loadingAmount: number = 0;
    public grossBasicPremium: number = 0;
    public fleetDiscountPercentage: number = 0;
    public fleetDiscountAmount: number = 0;
    public premiumNetOfNCB: number = 0;
    public stampDuty: number = 0;
    public GST: number = 0;
    public gstAmount: number = 0;
    public policyTotalPremium: number = 0;
    public SST: number = 0;//SST Code
    public sstAmount: number = 0;//SST Code

    constructor() {
        this.financialInterest = new FinancialInterest();
        this.motorItems = new MotorItems();
        this.driverDetails = new NamedDriver();
    }
    public getInstance(valObj: RTCoverNote) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
            this.financialInterest = new FinancialInterest().getInstance(valObj.financialInterest);
            this.motorItems = new MotorItems().getInstance(valObj.motorItems);
            this.driverDetails = new NamedDriver().getInstance(valObj.driverDetails);
        }
        return this;
    }

    public getNewInstance(riskObj: any, clientObj: any, type: string, header) {
        this.fillData(riskObj, clientObj, type, header);
        return this;
    }

    public fillData(riskObj: any, clientObj: any, type: string, header) {
        this.setClientDetails(clientObj);
        this.registrationNumber = riskObj.registrationNumber;
        this.engineNumber = riskObj.PIAMStatistics.engineNo;
        this.chasisNumber = riskObj.PIAMStatistics.chassisNo;
        this.cover = riskObj.coverDesc;
        if (type == 'T') {
            this.type = 'Trailer';
            this.engineNumber = 'NA';
            this.chasisNumber = riskObj.trailerDetails.chassesNo;
            this.registrationNumber = riskObj.trailerDetails.trailerNo;
        }
        this.make = riskObj.makeCode;
        this.model = riskObj.makeModel;
        this.makeModelDescription = riskObj.makeModelDescription;
        this.vehicalClass = riskObj.vehicalClass;
        this.use = riskObj.use;
        this.useDesc = riskObj.useDesc;
        this.suminsured = riskObj.capitalSumInsured;

        this.typeofBody = type;
        this.ncdPercentage = riskObj.fleetDiscountPercentage;
        this.excess = riskObj.excessAmount;
        this.capacity = riskObj.capacityValue;
        this.capacityType = riskObj.capacityType;
        this.yom = riskObj.yearManufacture;
        this.seatingCapacity = riskObj.seats;

        this.financialInterest = new FinancialInterest().getInstance(riskObj.financialInterest);
        this.motorItems = new MotorItems().getInstance(riskObj.motorItems);
        this.driverDetails = new NamedDriver().getInstance(riskObj.driverDetails);
        this.setPremiumVals(riskObj, header);
    }

    setClientDetails(clientObj: any) {
        let clientType = clientObj.client.genericDetails.clienttype;
        this.clientType = clientType;
        let clientDetails = (clientType == 'P') ? clientObj.client.personalClientDetails : clientObj.client.corporateClientDetails;
        if (clientType == "P") {
            this.nric = clientDetails.NRICNo;
            this.oldIc = clientDetails.IdNumber;
            this.clientName = clientDetails.Name;
        }
        else {
            this.oldIc = clientDetails.BusinessRegNo;
            this.clientName = clientDetails.corporation;
        }

        this.gstCoding = clientObj.client.gstDetails.gstCoding;
        this.clntPhone = clientDetails.address.telephone1;
        this.address1 = clientDetails.address.address1;
        this.address2 = clientDetails.address.address2;
        this.address3 = clientDetails.address.address3;
        this.address3 = clientDetails.address.address3;
    }

    setPremiumVals(riskObj, header) {
        this.totalPremium = riskObj.totalPremium;
        this.newTotalPremium = this.totalPremium;
        if (["RT", "CE", "EC"].indexOf(this.coverNoteType) == -1) {
            this.basicPremium = riskObj.basicPremium;
            this.loadingPercentage = (riskObj.loadingPercentage != "" && riskObj.loadingPercentage.trim().length > 0) ? riskObj.loadingPercentage : 0;
            this.loadingAmount = (riskObj.loadingAmount != "" && riskObj.loadingAmount.trim().length > 0) ? riskObj.loadingAmount : 0;
			
            this.grossBasicPremium = riskObj.grossBasicPremium;
            this.fleetDiscountPercentage = riskObj.fleetDiscountPercentage;
            this.fleetDiscountAmount = riskObj.fleetDiscountAmount;
            this.premiumNetOfNCB = riskObj.premiumNetOfNCB;
            this.stampDuty = riskObj.stampDuty;
            this.GST = 0;//riskObj.GST; //SAF MYS-2018-0629
            this.gstAmount = 0;//riskObj.gstAmount; //SAF MYS-2018-0629
            this.SST = riskObj.GST; //SST Code
            this.sstAmount = riskObj.gstAmount; //SST Code
            this.policyTotalPremium = header.totalPremium;

        }
        else {
            this.basicPremium = 0;
            this.loadingPercentage = 0;
            this.loadingAmount = 0;
            this.grossBasicPremium = 0;
            this.fleetDiscountPercentage = 0;
            this.fleetDiscountAmount = 0;
            this.premiumNetOfNCB = 0;
            this.stampDuty = 0;
            this.GST = 0;
            this.gstAmount = 0;
            this.SST = 0; //SST Code
            this.sstAmount = 0; //SST Code
            this.newTotalPremium = 0;
            this.policyTotalPremium = 0;
        }
    }

    setPOIBasedCalc(riskObj) {
        if (this.coverNoteType == 'ED' && this.inceptionDate != '' && this.endDate != '') {
            let inceptionDate = moment(this.inceptionDate, "YYYYMMDD").format("YYYY-MM-DD");
            let endDate = moment(this.endDate, "YYYYMMDD");
            let noOfDays = Number((endDate.diff(inceptionDate, 'days'))) + 1;
            this.newTotalPremium = Number(Number(riskObj.totalPremium) * (Number(noOfDays) / 365));
            this.newTotalPremium = (Math.round((this.newTotalPremium * 100)) / 100);
			/* this.GST =  0;//riskObj.GST; //SAF MYS-2018-0629
			this.gstAmount = 0;//Number(this.GST/100)*Number(this.newTotalPremium); //SAF MYS-2018-0629
			this.gstAmount = 0; //(Math.round((this.gstAmount * 100))/100) ;//SAF MYS-2018-0629 */
            //SST Code
            this.GST = riskObj.GST;
            let tempGSTAmount = Number(this.GST / 100) * Number(this.newTotalPremium);
            this.gstAmount = BMSUtilService.calculatePremiumAmount(tempGSTAmount, "G")
            this.SST = riskObj.SST;
            this.sstAmount = Number(this.SST / 100) * Number(this.newTotalPremium);
            //this.sstAmount = BMSUtilService.calculatePremiumAmount(this.sstAmount, "S");
			this.sstAmount = numeral(numeral(BMSUtilService.calculatePremiumAmount(this.sstAmount, "S")).format("0,00.00")).value();
			// SU001 : MYS-2019-0805 - Here sstAmount was exceeding 2 decimal points hence format is applied
            this.stampDuty = 0;
            this.totalPremium = Number(this.newTotalPremium) + Number(this.gstAmount) + Number(this.sstAmount);
            this.policyTotalPremium = (Math.round((this.totalPremium * 100)) / 100);
        }
    }
}