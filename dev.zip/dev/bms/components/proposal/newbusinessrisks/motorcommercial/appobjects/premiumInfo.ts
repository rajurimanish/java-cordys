import { AppUtil } from '../../../../../../common/components/utility/apputil/app.util';

declare var numeral: any;

export class PremiumInfo {
    public premiumClass: string = "";
    public totalGST: number = 0;
    public totalStampDuty: number = 0;
    public vehicalMotorGroup: string = "";
    public vehicalSegment: string = "";
    public msigVPMSVersion: string = "";
    public tariffVPMSVersion: string = "";
    public ismVPMSVersion: string = "";
    public riskLevelPremium: RiskLevelPremium;
    public annualPostingPremium: AnnualPostingPremium;
    public postedPremium: PostedPremium;
    public totalSST: number = 0; //SST Code
    constructor() {
        this.riskLevelPremium = new RiskLevelPremium();
        this.annualPostingPremium = new AnnualPostingPremium();
        this.postedPremium = new PostedPremium();
    }

    public getInstance(valObj: PremiumInfo) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValueByType(this, valObj);
            this.riskLevelPremium = new RiskLevelPremium().getInstance(valObj.riskLevelPremium);
            this.annualPostingPremium = new AnnualPostingPremium().getInstance(valObj.annualPostingPremium);
            this.postedPremium = new PostedPremium().getInstance(valObj.postedPremium);
        }
        return this;
    }

    public refresh(valObj: PremiumInfo) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValueByType(this, valObj);
            this.riskLevelPremium.refresh(valObj.riskLevelPremium);
            this.annualPostingPremium.refresh(valObj.annualPostingPremium);
            this.postedPremium.refresh(valObj.postedPremium);
        }
    }

    public getAnnualPremiumObj(calculator) {
        let premObj = null;
        if ("M" == calculator)
            premObj = this.annualPostingPremium.msigAnnualPostingPremium;
        else
            premObj = this.annualPostingPremium.vpmsAnnualPostingPremium;
        return premObj;
    }

    public getPostedPremiumObj(calculator) {
        let premObj = null;
        if ("M" == calculator)
            premObj = this.postedPremium.msigPostedPremium;
        else
            premObj = this.postedPremium.vpmsPostedPremium;
        return premObj;
    }
}

export class RiskLevelPremium {
    public vpmsRiskLevelPremium: CommonRiskLevelPremium;
    public msigRiskLevelPremium: CommonRiskLevelPremium;
    public ismRiskLevelPremium: CommonRiskLevelPremium;

    constructor() {
        this.vpmsRiskLevelPremium = new CommonRiskLevelPremium();
        this.msigRiskLevelPremium = new CommonRiskLevelPremium();
        this.ismRiskLevelPremium = new CommonRiskLevelPremium();
    }

    public getInstance(valObj: RiskLevelPremium) {
        if (new AppUtil().isValidObj(valObj) == true) {
            this.vpmsRiskLevelPremium = new CommonRiskLevelPremium().getInstance(valObj.vpmsRiskLevelPremium);
            this.msigRiskLevelPremium = new CommonRiskLevelPremium().getInstance(valObj.msigRiskLevelPremium);
            this.ismRiskLevelPremium = new CommonRiskLevelPremium().getInstance(valObj.ismRiskLevelPremium);
        }
        return this;
    }

    public refresh(valObj: RiskLevelPremium) {
        if (new AppUtil().isValidObj(valObj) == true) {
            this.vpmsRiskLevelPremium.refresh(valObj.vpmsRiskLevelPremium);
            this.msigRiskLevelPremium.refresh(valObj.msigRiskLevelPremium);
            this.ismRiskLevelPremium.refresh(valObj.ismRiskLevelPremium);
        }
    }
}

export class CommonRiskLevelPremium {
    public basicPremium: number = 0;
    public loadingAmount: number = 0;
    public grossBasicPremium: number = 0;
    public ncdAmount: number = 0;
    public premiumOfNetNCD: number = 0;
    public totalPremium: number = 0;
    public discountPercentage: number = 0;
    public discountAmount: number = 0;
    public trailerPremium: number = 0;
    public ncdPercentage: number = 0;
    public gstPremium: number = 0;
    public gstPercentage: number = 0;
    public gstAmount: number = 0;

    public getInstance(valObj: CommonRiskLevelPremium) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValueByType(this, valObj);
        }
        return this;
    }

    public refresh(valObj: CommonRiskLevelPremium) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValueByType(this, valObj);
        }
    }
}

export class AnnualPostingPremium {
    public vpmsAnnualPostingPremium: CommonAnnualPostedPremium;
    public msigAnnualPostingPremium: CommonAnnualPostedPremium;
    public ismAnnualPostingPremium: CommonAnnualPostedPremium;

    constructor() {
        this.vpmsAnnualPostingPremium = new CommonAnnualPostedPremium();
        this.msigAnnualPostingPremium = new CommonAnnualPostedPremium();
        this.ismAnnualPostingPremium = new CommonAnnualPostedPremium();
    }

    public getInstance(valObj: AnnualPostingPremium) {
        if (new AppUtil().isValidObj(valObj) == true) {
            this.vpmsAnnualPostingPremium = new CommonAnnualPostedPremium().getInstance(valObj.vpmsAnnualPostingPremium);
            this.msigAnnualPostingPremium = new CommonAnnualPostedPremium().getInstance(valObj.msigAnnualPostingPremium);
            this.ismAnnualPostingPremium = new CommonAnnualPostedPremium().getInstance(valObj.ismAnnualPostingPremium);
        }
        return this;
    }

    public refresh(valObj: AnnualPostingPremium) {
        if (new AppUtil().isValidObj(valObj) == true) {
            this.vpmsAnnualPostingPremium.refresh(valObj.vpmsAnnualPostingPremium);
            this.msigAnnualPostingPremium.refresh(valObj.msigAnnualPostingPremium);
            this.ismAnnualPostingPremium.refresh(valObj.ismAnnualPostingPremium);
        }
    }
}

export class CommonAnnualPostedPremium {
    public premiumClassCode: string = "";
    public grossPremium: number = 0;
    public totalPremium: number = 0;
    public directDiscountRate: number = 0;
    public directDiscountAmount: number = 0;
    public stampDuty: number = 0;
    public gstCode: number = 0;
    public gstPercentage: number = 0;
    public gstPremium: number = 0;
    public gstAmount: number = 0;
    public commissionAmount: number = 0;
    public commissionPercentage: number = 0;
    public netPremium: number = 0;
    public agentDiscount: number = 0;
    public gstCommission: number = 0;
    public premiumDueAmount: number = 0;
    public rebate: number = 0;
    public rebateAmount: number = 0;
    public sstAmount: number = 0; // SST Code
    public sstPercentage: number = 0; // SST Code
    public sstPremium: number = 0; // SST Code

    public getInstance(valObj: CommonAnnualPostedPremium) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValueByType(this, valObj);
        }
        return this;
    }

    public refresh(valObj: CommonAnnualPostedPremium) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValueByType(this, valObj);
        }
        this.setRebateValues();
        this.setTotalPrem();
    }

    public setRebateValues() {
        if (("" + this.directDiscountRate) == "0") {
            this.rebate = this.directDiscountRate;
            this.rebateAmount = this.directDiscountAmount;
        }
        else {
            this.rebate = this.commissionPercentage;
            this.rebateAmount = this.commissionAmount;
        }
    }

    public setTotalPrem() {
        let numFormat = '0.00';
        let total = numeral(numeral(numeral(numeral(this.premiumDueAmount).format(numFormat)).value() - numeral(numeral(this.stampDuty).format(numFormat)).value()).format(numFormat)).value()
        if (total < 0)
            total = 0;
        this.totalPremium = total;
    }
}

export class PostedPremium {
    public vpmsPostedPremium: CommonAnnualPostedPremium;
    public msigPostedPremium: CommonAnnualPostedPremium;
    public ismPostedPremium: CommonAnnualPostedPremium;

    constructor() {
        this.vpmsPostedPremium = new CommonAnnualPostedPremium();
        this.msigPostedPremium = new CommonAnnualPostedPremium();
        this.ismPostedPremium = new CommonAnnualPostedPremium();
    }

    public getInstance(valObj: PostedPremium) {
        if (new AppUtil().isValidObj(valObj) == true) {
            this.vpmsPostedPremium = new CommonAnnualPostedPremium().getInstance(valObj.vpmsPostedPremium);
            this.msigPostedPremium = new CommonAnnualPostedPremium().getInstance(valObj.msigPostedPremium);
            this.ismPostedPremium = new CommonAnnualPostedPremium().getInstance(valObj.ismPostedPremium);
        }
        return this;
    }

    public refresh(valObj: PostedPremium) {
        if (new AppUtil().isValidObj(valObj) == true) {
            this.vpmsPostedPremium.refresh(valObj.vpmsPostedPremium);
            this.msigPostedPremium.refresh(valObj.msigPostedPremium);
            this.ismPostedPremium.refresh(valObj.ismPostedPremium);
        }
    }
}