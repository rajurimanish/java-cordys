import { AppUtil } from '../../../../../../common/components/utility/apputil/app.util';
export class NewVehicleCoverNote {
    public nvCoverNote: NVCoverNote[] = [];
    constructor() {
        this.nvCoverNote.push(new NVCoverNote());
        let trailer = new NVCoverNote();
        trailer.serialNo = 2;
        trailer.type = 'T';
        this.nvCoverNote.push(trailer);
    }
    public getInstance(valObj: NewVehicleCoverNote) {
        this.refresh(valObj);
        return this;
    }

    public refresh(valObj: NewVehicleCoverNote) {
        if (new AppUtil().isValidObj(valObj) == true) {
            let newContAry = new AppUtil().getArray(valObj.nvCoverNote);
            for (let eachNVC of this.nvCoverNote) {
                eachNVC.refresh(newContAry[this.nvCoverNote.indexOf(eachNVC)]);
            }
        }

    }
}
export class NVCoverNote {
    public serialNo: number = 1;
    public coverNoteNo: string = '';
    public coverNoteStatus: string = 'Not Initiated';
    public coverNoteType: string = 'NV';
    public transactionDate: string = '';
    public dateSentToJPJ: string = '';
    public timeSentToJPJ: string = '';
    public timeReceivedFromJPJ: string = '';
    public dateReceivedFromJPJ: string = '';
    public reason: string = '';
    public status: string = 'Not Initiated';
    public message: string = '';
    public comments: string = '';
    public type: string = 'P';
    public refresh(valObj: NVCoverNote) {
        new AppUtil().setFieldValueByType(this, valObj);
    }
}