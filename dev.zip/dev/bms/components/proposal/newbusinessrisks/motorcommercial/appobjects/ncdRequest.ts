export class NCDRequest {
    constructor(
        public accountNo: string,
        public coverType: string,
        public curChassisNo: string,
        public curVehNo: string,
        public doctype: string,
        public idNo1: string,
        public idNo2: string,
        public preAppCode: string,
        public preInsCode: string,
        public prePolicyNo: string,
        public preRefNo: string,
        public preVehNo: string,
        public productCode: string,
        public refNo: string,
        public sourceName: string,
        public vehClass: string,
        public vehUsed: string
    ) { }
}