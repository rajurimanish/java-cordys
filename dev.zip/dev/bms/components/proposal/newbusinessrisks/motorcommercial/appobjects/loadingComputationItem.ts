import { AppUtil } from '../../../../../../common/components/utility/apputil/app.util';

export class LoadingComputation {
    public loadingDetail: LoadingComputationItem[] = [];
    public getInstance(valObj: LoadingComputation) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().handleArray(this, valObj, "loadingDetail");
        }
        return this;
    }
}

export class LoadingComputationItem {

    public code: string;
    public sequence: string;
    public description: string;
    public ageFrom: number;
    public ageTo: number;
    public numOfClaims: number;
    public loadingPerctgLimit: number;
    public inputLoadingPerctg: number;
    public originalLoadingPerctg: number;
    public maxBNMLoadingPerctg: number;

    constructor() { }
}