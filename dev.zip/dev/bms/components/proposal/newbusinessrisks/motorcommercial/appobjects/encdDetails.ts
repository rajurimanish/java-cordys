import { AppUtil } from '../../../../../../common/components/utility/apputil/app.util';

export class ENCDDetails {
    public appCode: string;
    public curNCDEffDt: string;
    public curNCDExpDt: string;
    public curNCDLevel: string;
    public curNCDPercent: string;
    public nextNcdPercent: string;
    public insCode: string;
    public nxtNCDEffDt: string;
    public nxtNCDLevel: string;
    public respCode: string;
    public respCodeDesc: string;
    public preInsCode: string;
    public refNo: string;
    public ncdCfnRespCode: string;

    constructor() { }

    public getInstance(valObj: ENCDDetails) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
        }
        return this;
    }
}