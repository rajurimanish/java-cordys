import { AppUtil } from '../../../../../../common/components/utility/apputil/app.util';

export class ESIDetails {
    public recommendVal: string;
    public marketVal: string;
    public sumInsValue: string;
    public indicator: string;
    public insCode: string;
    public respCode: string;
    public respCodeDesc: string;
    public respMsg: string;
    public eSIEffective: string;
    public dateReq: string;
    public dateResp: string;

    constructor() { }

    public getInstance(valObj: ESIDetails) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
        }
        return this;
    }
}