import { AppUtil } from '../../../../../../common/components/utility/apputil/app.util';

export class NamedDriver {

    public driverDetail: NamedDriverItem[] = [];
    public additionalPremium: number = 0;
    public getInstance(valObj: NamedDriver) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
            new AppUtil().handleArray(this, valObj, "driverDetail");
        }
        return this;
    }

}

export class NamedDriverItem {

    public driverName: string;
    public ICNumber: string;
    public oldPassportNo: string;
    public dateOfBirth: string;
    public drivingLicense: string = "";
    public relationship: string = "";
    public sex: string = "";
    public occupation: string;

    constructor(
    ) { }
}