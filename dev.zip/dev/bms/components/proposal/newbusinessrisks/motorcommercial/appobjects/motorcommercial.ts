/*
Change History	:

	No      Date          Description                                 Changed By
	====    ==========    ===========                                 ==========
	GA001   23/11/2017    MYS-2017-0813 - To enhance BPM to cater 
						  for minimum sum insured   					KGA		
	GA002   29/11/2018    MYS-2018-1146 - Motor To allow ESI 
                          request for "Cover = TF" 			 			KGA			
   MR001   11/6/2019     MYS-2019-0324 -adding validation on ESI       MRA1
                            Market Value            	                           
*/
import { Clause } from '../../appobjects/clause';
import { LoadingDiscountCode } from '../../appobjects/loadingDiscountCode';
import { PIAMStatistics } from '../../appobjects/piamStatistics';
import { FinancialInterest } from '../../../../../../common/components/financialinterest/appobjects/financialInterest';
import { MotorItems } from '../../appobjects/motorItems';
import { NamedDriver } from './nameddriver';
import { LoadingComputation } from './loadingComputationItem';
import { ESIDetails } from './esiDetails';
import { GSTDetails } from '../../appobjects/gstDetails';
import { ENCDDetails } from './encdDetails';
import { MiscCoverNote } from './misccovernote';
import { NewVehicleCoverNote } from './newvehiclecovernote';
import { AppUtil } from '../../../../../../common/components/utility/apputil/app.util';
import { PremiumInfo } from './premiumInfo';
import { NBRisk } from '../../../appobjects/nbrisk';
import { PostedPrem } from '../../../proposalheader/appobjects/postedprem';
import { RiskHelper } from '../../../appobjects/riskhelper';
import { ReferredReason } from '../../../proposalheader/appobjects/referredreason';
import { MotorValidator } from '../../../validation/motor.validator';

declare var numeral: any;
declare var moment: any;

export class MotorCommercial extends RiskHelper implements NBRisk {

    public sequenceNumber: string;
    public effectiveDate: string;
    public dateOfAttachment: string;
    public contractNumber: string;
    public contractType: string;
    public riskNumber: string;
    public riskType: string;
    public riskName: string;
    public ratingFlag: string;
    public FI: string = "N";
    public RIRetentionCode: string = "MV11";
    public CI: string = "";
    public insuredIsDriver: string;
    public location: string = "";
    public genderCorporate: string;
    public occupationCode: string;
    public occupationDescription: string;
    public registrationNumber: string;
    public engineNumber: string;
    public chassisNumber: string;
    public seats: number;
    public EW: string = "W";
    public makeCode: string;
    public makeModel: string = "";
    public makeModelDescription: string;
    public capacityType: string;
    public capacityValue: string = "";
    public petrolDieselIndicator: string = "P";
    public tonnage: string;
    public tommangeIndicator: string = "";
    public use: string = "";
    public yearManufacture: string = "";
    public esiRV: string;
    public esiRVOrg: string;//GA002
    public esiRVFormattedValue: string; //MR001
    public esiMV: string;
    public esiMVOrg: string;//MR001
    public CFY: string;
    public thirdParty: number = 0;
    public cover: string = "";
    public variant: string = "";
    public vehicalClass: string = "";
    public sumInsured: number = 0;
    public vehicalSumInsured: number = 0;
    public vehicalSumInsuredUI: string;
    public basicPremium: number = 0;
    public trailerRegistration: string;
    public trailerSumInsured: number = 0;
    public trailerPremium: number = 0;
    public allRidersPremium: number = 0;
    public isAllRidersPresent: string = "N";
    public trailerChassesNumber: string;
    public trailerYearManufacture: string;
    public totalSumInsured: number = 0;
    public totalSumInsuredUI: string;
    public basicPremiumPerctg: number = 0;
    public loadingPercentage: number = 0;
    public loadingAmount: number = 0;
    public excessType: string = "";
    public excessTypeDesc: string = "";
    public excessAmount: number = 0;
    public subTotal: number = 0;
    public NVIC: string;
    public ACT: number = 0;
    public OWD: number = 0;
    public grossBasicPremium: number = 0;
    public fleetDiscountPercentage: number = 0;
    public fleetDiscountAmount: number = 0;
    public premiumNetOfNCB: number = 0;
    public loadingDiscountCodes: LoadingDiscountCode[] = [];
    public loadingDiscountPercentage: string;
    public loadingDiscountAmount: string;
    public totalPremium: number = 0;
    public clauses: Clause;
    public terminationDate: string;
    public motorItems: MotorItems;
    public permittedDriver: string;
    public driverDetails: NamedDriver;
    public PIAMStatistics: PIAMStatistics;
    public financialInterest: FinancialInterest;
    public loadingDetails: LoadingComputation;
    public ESIDetails: ESIDetails;
    public ENCDDetails: ENCDDetails;
    public GSTDetails: GSTDetails;
    public RIMethod: string = "0";
    public RIRequired: string = "No";
    public RIMethodSys: string = "0";
    public riskClassification: string = "Standard";
    public identity: string = "";
    public capitalSumInsured: number = 0;
    public stampDuty: number = 10;
    public vehClassCode: string;
    public insuredType: string;
    public symRiskClassification: string = "";
    public riskOccupationCode: string = "";
    public minimumPremium: number = 0;
    public originalTotalPremium: number = 0;
    public totalGrossPremium: number = 0;
    public postedPremium: number = 0;
    public basePostedPremiumAdj: number = 0;
    public discountedPremium: number = 0;
    public rebate: number = 0;
    public rebateAmount: number = 0;
    public GST: number = 0; //6; //SAF MYS-2018-0629
    public gstAmount: number = 0;
    public blackListIndicator: string;
    public vehicleReferredRisk: string;
    public riskClassificationReason: string = '';
    public trailerDetails: TrailerDetails;
    public premiumInfo: PremiumInfo;
    public premiumInfoFlag: string = "N";
    public numberOfClaims: number = 0;
    public telematicsIndOrInfo: string = "";
    public customerLoyalty: string = "";
    public premiumClass: string = "A";
    public premiumCalculator: string;
    public additionalPremTotal: string = "0";
    public isVPMS: string = 'N';
    public state: string;
    public claimExperience: string = "0";
    public adjustmentRate: string = "0";
    public adjustmentAmount: number = 0;
    public adjustmentReasonCode: string = "";
    public vpmsversion: string = "";
    public miscCoverNote: MiscCoverNote;
    public vehicleBodyDesc: string;
    public useDesc: string;
    public coverDesc: string;
    public vehicalClassDesc: string;
    public isPOIConsidered: string = "N";
    public priority: string;
    public coverRenewalOrg: string = "";
    public vehSIRenOrg: number = 0;
    public ldngPrctgRnwlOrg: number = 0;
    public excessRnwlOrg: number = 0;
    public postedPremDetails: PostedPrem;
    public quotationDate: string = "";
    public quotationValidUntil: string = "";
    public PMCoverNoteNo: string = "";
    public vehicleTypeFlag: string = "";
    public newVehicleCoverNote: NewVehicleCoverNote;
    public minSumInsured: number = 0;//GA001
    public childRiskPath: string;
    public childRiskIdentity: string;
    public riskClassificationReasons: ReferredReason;
    public CTP: string = 'N';
    public makeModelNew: string = "";//added for SAF MYS-2018-0245
    public gpText: string;
    public SST: number = 0; //SST Code
    public sstAmount: number = 0;//SST Code
    public GSTLiveDate: string; //SST Code
    public SSTLiveDate: string; //SST Code
    public isGSTApplicable: boolean = true;//SST Code
		public gpTextCount:number = 0;//VK004
    public bnmValue: number; // MYS-2018-1562
    constructor() {
        super();
        this.PIAMStatistics = new PIAMStatistics();
        this.motorItems = new MotorItems();
        this.clauses = new Clause();
        this.driverDetails = new NamedDriver();
        this.GSTDetails = new GSTDetails();
        this.trailerDetails = new TrailerDetails();
        this.loadingDetails = new LoadingComputation();
        this.premiumInfo = new PremiumInfo();
        this.miscCoverNote = new MiscCoverNote();
        this.newVehicleCoverNote = new NewVehicleCoverNote();
        this.riskClassificationReasons = new ReferredReason();
    }

    public getInstance(valObj: MotorCommercial) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
            new AppUtil().handleArray(this, valObj, "loadingDiscountCodes");
            this.PIAMStatistics = new PIAMStatistics().getInstance(valObj.PIAMStatistics);
            this.clauses = new Clause().getInstance(valObj.clauses);
            this.motorItems = new MotorItems().getInstance(valObj.motorItems);
            if (valObj.FI == "Y") {
                this.financialInterest = new FinancialInterest().getInstance(valObj.financialInterest);
            }
            this.ESIDetails = new ESIDetails().getInstance(valObj.ESIDetails);
            this.ENCDDetails = new ENCDDetails().getInstance(valObj.ENCDDetails);
            this.GSTDetails = new GSTDetails().getInstance(valObj.GSTDetails);
            this.driverDetails = new NamedDriver().getInstance(valObj.driverDetails);
            this.trailerDetails = new TrailerDetails().getInstance(valObj.trailerDetails);
            this.loadingDetails = new LoadingComputation().getInstance(valObj.loadingDetails);
            this.miscCoverNote = new MiscCoverNote().getInstance(valObj.miscCoverNote);
            this.newVehicleCoverNote = new NewVehicleCoverNote().getInstance(valObj.newVehicleCoverNote);
            this.riskClassificationReasons = new ReferredReason().getInstance(valObj.riskClassificationReasons);
            if (valObj.premiumInfo != null) {
                this.isVPMS = "Y";
                this.premiumInfo = new PremiumInfo().getInstance(valObj.premiumInfo);
            }
            else {
                this.isVPMS = "N";
                this.premiumInfo = null;
            }
            if (valObj.isGSTApplicable != undefined && JSON.stringify(valObj.isGSTApplicable) != JSON.stringify("") && typeof (valObj.isGSTApplicable) == "string") {
                this.isGSTApplicable = Boolean(JSON.parse(valObj.isGSTApplicable));
            }
        }
        return this;
    }

    public getNewInstanceByCriteria(criteria: any) {
        return this;
    }

    public getValidator() {
        return new MotorValidator(this);
    }

    public refresh(valObj: MotorCommercial) {
        if (new AppUtil().isValidObj(valObj) == true) {
            this.vehicleTypeFlag = valObj.vehicleTypeFlag;
            this.newVehicleCoverNote.refresh(valObj.newVehicleCoverNote);
        }
    }

    public setPremiumInfo(premObj: PremiumInfo, motorObj) {
        let premiumInfoObj = premObj;
        if (premiumInfoObj == null) {
            this.vpmsversion = "";
            this.premiumInfoFlag = "N";
            this.premiumCalculator = "";
            premiumInfoObj = new PremiumInfo();
        }
        this.premiumInfo.refresh(premiumInfoObj);
        this.setPostingPremiumInfo(premiumInfoObj, motorObj);
    }

    public setPostingPremiumInfo(premObj: PremiumInfo, calMotorObj) {
        let numFormat = AppUtil.getPremFormat();
        let motorRiskLObj = null;
        let postedMotorObj = null;
        let annualMotorObj = null;
        if (calMotorObj != null) {
            if (this.premiumCalculator == "M") {
                motorRiskLObj = premObj.riskLevelPremium.msigRiskLevelPremium;
                postedMotorObj = this.premiumInfo.postedPremium.msigPostedPremium;
                annualMotorObj = this.premiumInfo.annualPostingPremium.msigAnnualPostingPremium;
                this.vpmsversion = this.premiumInfo.msigVPMSVersion;
            }
            else {
                motorRiskLObj = premObj.riskLevelPremium.vpmsRiskLevelPremium;
                postedMotorObj = this.premiumInfo.postedPremium.vpmsPostedPremium;
                annualMotorObj = this.premiumInfo.annualPostingPremium.vpmsAnnualPostingPremium;
                this.vpmsversion = this.premiumInfo.tariffVPMSVersion;
            }
            this.gstAmount = numeral(numeral(annualMotorObj.gstPremium).format(numFormat)).value();
            this.sstAmount = numeral(numeral(annualMotorObj.sstPremium).format(numFormat)).value();//SST Code
            this.basicPremium = numeral(numeral(motorRiskLObj.basicPremium).format(numFormat)).value();
            this.loadingAmount = numeral(numeral(motorRiskLObj.loadingAmount).format(numFormat)).value();
            this.grossBasicPremium = numeral(numeral(motorRiskLObj.grossBasicPremium).format(numFormat)).value();
            this.fleetDiscountAmount = numeral(numeral(calMotorObj.fleetDiscountAmount).format(numFormat)).value();
            this.premiumNetOfNCB = numeral(numeral(motorRiskLObj.premiumOfNetNCD).format(numFormat)).value();
            this.totalPremium = annualMotorObj.totalPremium;
            this.originalTotalPremium = postedMotorObj.grossPremium;
            this.totalGrossPremium = annualMotorObj.grossPremium;
            this.trailerPremium = numeral(numeral(motorRiskLObj.trailerPremium).format(numFormat)).value();
            this.motorItems.refresh(calMotorObj.motorItems);
            this.additionalPremTotal = new AppUtil().getTotalByProperty("additionalpremium", this.motorItems.motorItem, numFormat).formatted;
            this.postedPremium = postedMotorObj.totalPremium;
            this.setAllRidersPremium(numFormat);
        }
        else {
            this.gstAmount = 0;
            this.basicPremium = 0;
            this.loadingAmount = 0;
            this.grossBasicPremium = 0;
            this.fleetDiscountAmount = 0;
            this.premiumNetOfNCB = 0;
            this.totalPremium = 0;
            this.originalTotalPremium = 0;
            this.totalGrossPremium = 0;
            this.trailerPremium = 0;
            this.rebate = 0;
            this.rebateAmount = 0;
            this.postedPremium = 0;
            this.additionalPremTotal = "0";
            this.sstAmount = 0;//SST Code
        }
    }


    public setAllRidersPremium(premiumFormat) {
        this.allRidersPremium = numeral(0).format(premiumFormat);
        this.isAllRidersPresent = "N";
        if (this.motorItems.motorItem && this.motorItems.motorItem.length > 0) {
            let allPrItm = this.motorItems.motorItem.filter((item) => item.code == "ALL");
            if (allPrItm.length > 0) {
                this.allRidersPremium = numeral(allPrItm[0].additionalpremium).format(premiumFormat);
                this.isAllRidersPresent = "Y";
            }
        }
    }

    public hasTrailer() {
        if ((this.trailerDetails) && AppUtil.isEmpty(this.trailerDetails.chassesNo, false) == false && ['HVC', 'HVF', 'HVT', 'CV', 'CVF', 'CVT'].indexOf(this.riskType) != -1)
            return true;
        else
            return false;
    }
}

export class TrailerDetails {
    public chassesNo: string;
    public coverNote: string;
    public policyNumberToJPJ: string;
    public effectiveDate: string;
    public makeCode: string;
    public trailerNo: string;
    public makeCodeDescription: string;
    public yearOfMake: string;
    public excess: string;
    public logBook: string;
    public makeModel: string;
    public makeModelNew: string;
    public TRCoverNoteNo: string = "";
    public getInstance(valObj: TrailerDetails) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
            return this;
        }
        return null;
    }
}

export class VixResp {
    public makeCode: string;
    public makeModel: string;
    public capacityValue: string;
    public yearManufacture: string;
    public NVIC: string;
    public use: string;
}