import { AppUtil } from '../../../../../../common/components/utility/apputil/app.util';

export class JPJDetails {
    public status: string = '';
    public messageDescription: string = '';
    public dateSentToJPJ: string = '';
    public timeSentToJPJ: string = '';
    public dateReceivedFromJPJ: string = '';
    public timeReceivedFromJPJ: string = '';

    constructor() { }

    public getInstance(valObj: JPJDetails) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
        }
        return this;
    }
}