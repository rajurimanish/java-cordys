/**
 * No      Date          Description                                 Changed By
	====    ==========    ===========                                 ==========
	MD001   15/03/2019   MYS-2018-1498 - BPM - Marine MAR,MCA -           MKU1
	                     To add in validation for Referred Risks * 
	KA001   03/04/2019   MYS-2019-0289 - HD Log: Unable to fetch 
                         Commodity from P400 Table in BMS for MAR product  KA001
    GA001   01/07/2019   MYS-2019-0256	 BMS Marine (MAR/MCA) Amend Routing Matrix KGA  
    * YPK001 23/09/2019       MYS-2019-0675 Document Validation for Co-outwards            PKU1
 *                         case before sending to PPHO	                        
 */

import { Component, OnInit, ViewChild, ElementRef, EventEmitter, AfterViewInit, ViewContainerRef } from '@angular/core';
declare var Observer: any;
import { DCLInput, CustomDCLService } from '../../../../../common/services/customdcl.service';
import { LOV_Field, LOVDropDownService, SearchFilter } from "../../../../../common/services/lovdropdown/lovdropdown.service";
import { CordysSoapWService } from "../../../../../common/components/utility/cordys-soap-ws";
import { GetLOVData, SearchAdvancedConfig, Filter } from '../../../../../common/components/utility/search/search.requests';
import { ProposalHeader } from '../../proposalheader/appobjects/proposalheader';
import { AlertMessagesService } from '../../../../../common/components/utility/alertmessage/alertmessages.service';
import { AlertMessage } from '../../../../../common/components/utility/alertmessage/alertmessages.model';
import { S4804, RiskCoverage, DeclarationMonth } from './appobjects/s4804';
import { Clause } from "../appobjects/clause";
import { Survey } from '../appobjects/survey';
import { FinancialInterest } from '../../../../../common/components/financialinterest/appobjects/financialInterest';
import { ExtraTextDialogData } from "../dialogs/extratext.dialog.data";
import { ModalInput } from "../../../../../common/components/utility/modal/modal";
import { SearchInput } from "../../../../../common/components/utility/search/genericsearch";
import { BMSConstants } from '../../../common/constants/bms_constants';
import { CaseInfo } from '../../../../../common/components/appobjects/caseinfo';
import { PaginationModule } from '../../../../../common/components/utility/pagination/pagination.module';
import { PaginationPipe } from '../../../../../common/components/utility/pagination/filtertable.pipe';
import { FilterTableContentPipe } from '../../../../../common/components/utility/pagination/filtercontent.pipe';
import { ApplicationUtilService } from "../../../../../common/services/application.util.service";
import { BMSUtilService } from "../../../../services/bms.util.service";
import { AppUtil } from '../../../../../common/components/utility/apputil/app.util';
import { RIService } from '../services/ri.service';
import { ReferredReason, Reasons } from '../../proposalheader/appobjects/referredreason';
import { ClausesComponent } from "../uimodules/clauses.component";
import { ActivatedRoute } from '@angular/router';

declare var jQuery: any;
declare var moment: any;
declare var numeral: any;

@Component({
    selector: 's4804-risk-component',
    templateUrl: 'app/bms/components/proposal/newbusinessrisks/s4804/s4804.template.html',
    inputs: ['riskObj', 'clientDetails', "headerInfo", "caseInfo"],
    outputs: ["onPremiumChange", "onRiskClsChange", "onRtngFlgChange"]
})

export class S4804Component implements OnInit {
    private el: HTMLElement;
    public riskObj: S4804;
    public headerInfo: ProposalHeader;
    public caseInfo: CaseInfo;
    private clCBIInfoCollapse: boolean = true;
    private coverageInfoCollapse: boolean = false;
    private surInfoCollapse: boolean = false;
    private declMonthCollapse: boolean = false;
    private isGeneralPageCollapsed: boolean = false;

    public siFormat: string = "0,00";
    public premiumFormat: string = "0,00.00";
    public rateFormat: string = "0.00000";
    public marineRateFormat: string = "0.0000";
    public percentFormat: string = "0.00";
    public currencyRateFormat: string = "0.0000000";

    private isExcessPercentMandatory: string = 'N';
    private isExcessAmountMandatory: string = 'N';

    public position = 1;
    public sizeObj = { length: 0, orglength: 0 };
    public contentSizeObs: any;
    public itemPerPage = 3;
    public maxPageCount = 10;
    private isUnderWriter = "N";
    private isRIMethodEditable = "Y";
    private areaPorts = [];
    private conveyanceList = [];
    private shipmntTypesList = [];
    private scopeOfCoversList = [];
    private excessTypesList = [];
    private commodityCodeList = [];
    private wocdpfData: any;
    private woclpfDataList = [];
    //private wocmpfDataList=[];
    private currencyRateCtrl: any;
    private vesselCtrl: any;
    private tShipVesselCtrl: any;
    private etdDateCtrl: any;

    onPremiumChange = new EventEmitter<any>();
    onRiskClsChange = new EventEmitter<any>();
    onRtngFlgChange = new EventEmitter<any>();
    @ViewChild('xtModal', { read: ViewContainerRef }) contentArea: ViewContainerRef;
    @ViewChild(ClausesComponent) private clausesComp: ClausesComponent;

    constructor(private lovDropDownService: LOVDropDownService, private _soapService: CordysSoapWService, public _alertMsgService: AlertMessagesService, el: ElementRef, public dcl: CustomDCLService, private _appUtilService: ApplicationUtilService, private _bmsUtilService: BMSUtilService, private _riService: RIService, private _activatedRoute: ActivatedRoute) {
        this.el = el.nativeElement;
    }

    ngOnInit() {
        if (this.headerInfo.marineOpenCover && !this.riskObj.openCover) {
            this.riskObj.openCover = this.headerInfo.marineOpenCover;
        }

        this.populateLOVs();

        this._appUtilService.isUnderWriterUser().subscribe((data) => {
            this.isUnderWriter = data;
            this.setRIMethodEditableFlag();
        });

        //SST Code
        if (["MyTasks", "MyDrafts"].indexOf(this._activatedRoute.snapshot.params['component']) >= 0 || Object.keys(this._activatedRoute.snapshot.params).length == 0) {
            let respObj = this._bmsUtilService.getTAXDetails();
            if (respObj != undefined && respObj != "") {
                this.headerInfo.SSTTaxRate = Number(respObj[0].old.ITEMPF.GST);
                this.headerInfo.GSTTaxRate = Number(respObj[1].old.ITEMPF.GST);

                this.riskObj.SST = Number(this.headerInfo.SSTTaxRate);
                this.riskObj.GST = Number(this.headerInfo.GSTTaxRate);
            }

            this.headerInfo = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo;
            this.riskObj.SSTLiveDate = (this.riskObj.SSTLiveDate == undefined) ? this.headerInfo.SSTLiveDate : this.riskObj.SSTLiveDate;
            if (this.riskObj.SSTLiveDate == undefined || this.riskObj.SSTLiveDate == "") {
                let tempRespObj = this._bmsUtilService.getLiveDate();
                this.riskObj.GSTLiveDate = tempRespObj[0].old.ITEMPF.LIVEDATE;
                this.riskObj.SSTLiveDate = tempRespObj[1].old.ITEMPF.LIVEDATE;
                if (this.headerInfo.SSTLiveDate == undefined || this.headerInfo.SSTLiveDate == "") {
                    this.headerInfo.SSTLiveDate = this.riskObj.SSTLiveDate;
                }
                if (this.headerInfo.GSTLiveDate == undefined || this.headerInfo.GSTLiveDate == "") {
                    this.headerInfo.GSTLiveDate = this.riskObj.GSTLiveDate;
                }
            }
            if (moment(this.headerInfo.effectiveDate, "YYYY-MM-DD").format("YYYYMMDD") >= moment(this.riskObj.SSTLiveDate, "YYYY-MM-DD").format("YYYYMMDD")) {
                this.riskObj.isGSTApplicable = false;
            } else {
                this.riskObj.isGSTApplicable = true;
            }
        }
        if (["IM", "EX", "CV"].indexOf(this.riskObj.shipmentType) >= 0) {
            this.riskObj.sstAmount = 0;
            this.riskObj.SST = Number(0);
            this.headerInfo.SSTTaxRate = this.riskObj.SST;
        }
        else {
            if (this.riskObj.SST == 0) {
                let respObj = this._bmsUtilService.getTAXDetails();
                if (respObj != undefined && respObj != "") {
                    this.headerInfo.SSTTaxRate = Number(respObj[0].old.ITEMPF.GST);
                    this.headerInfo.GSTTaxRate = Number(respObj[1].old.ITEMPF.GST);

                    this.riskObj.SST = Number(this.headerInfo.SSTTaxRate);
                    this.riskObj.GST = Number(this.headerInfo.GSTTaxRate);
                }
            }
        }
        //End
    }
    //START YPK001
    ngAfterViewInit() {
        let rIndex = 0;
        if ((this.headerInfo.CoInsurance == 'Y' && this.riskObj.riskNumber == '1') && (["MyTasks", "MyDrafts"].indexOf(this._activatedRoute.snapshot.params['component']) >= 0 || Object.keys(this._activatedRoute.snapshot.params).length == 0)) {
            if (this.headerInfo.coInsuranceDetails.coInsurance.length == 1) {
                if (!(this.headerInfo.coInsuranceDetails.coInsurance[0].coInsuranceindicator == 'L' && this.headerInfo.coInsuranceDetails.coInsurance[0].sharePercentage == '100')) {
                    rIndex = this.riskObj.clauses.clause.map(function (item) { return item.clauseCode; }).indexOf("COIN");
                    if (rIndex == -1)
                        this.setClauses(["COIN"], false);
                }
            }
            else {
                rIndex = this.riskObj.clauses.clause.map(function (item) { return item.clauseCode; }).indexOf("COIN");
                if (rIndex == -1)
                    this.setClauses(["COIN"], false);
            }
        }
    }
    //END YPK001

    populateLOVs() {

        if (this.riskObj.openCover) {
            this.initWOCDPFData();
            this.initWOCLPFData();
            //this.initWOCMPFData();
        }

        this.lovDropDownService.createLOVDataList(["vessel", "country", "currency", "conveyance", "shipmentType", "scopeOfCover", "riCode", "excessType", "vesselType", "packingCode", "cargoType", "commodity", "areaPorts", "premiumClass", "month", "mocCountry", "mocClauses", "mocCommodityList"]);

        let polEffDate = ApplicationUtilService.getFormattedDate(this.headerInfo.effectiveDate, "YYYY-MM-DD", "YYYYMMDD");
        let currencyDateFilterDetails = [new SearchFilter("FRMDATE", polEffDate, "LTEQ", "AND"), new SearchFilter("TODATE", polEffDate, "GTEQ", "AND")];
        let currencyDateFilterNodes = this.lovDropDownService.createFilter(currencyDateFilterDetails);

        let riskFilter = (this.riskObj.riskType.length == 2) ? this.riskObj.riskType + ' ' : this.riskObj.riskType;
        let excessTypeFilterDetails = [new SearchFilter("DESCITEM", riskFilter, "STARTSWITH", "AND")];
        let excessTypeFilterNodes = this.lovDropDownService.createFilter(excessTypeFilterDetails);

        let riskTypeFilterDetails = [new SearchFilter("RSKTYPE", this.riskObj.riskType, "EQ", "AND")];
        let riskTypeFilterNodes = this.lovDropDownService.createFilter(riskTypeFilterDetails);

        let lovFields = [
            new LOV_Field("ALL", "MAR", "ALL", "ALL", "ALL", "ALL", "Vessel", "LOV", [], "CMSN", "vessel", null),
            new LOV_Field("ALL", "ALL", "ALL", "ALL", "ALL", "ALL", "Currency", "LOV", currencyDateFilterNodes, "T3629", "currency", null),
            new LOV_Field("ALL", "MAR", "ALL", "ALL", "ALL", "ALL", "Conveyance", "LOV", [], "T7060", "conveyance", "callbackForConveyanceLoad"),
            new LOV_Field("ALL", "MAR", "ALL", "ALL", "ALL", "ALL", "ShipmentType", "LOV", [], "T4989", "shipmentType", "callbackForShipmTypeLoad"),
            new LOV_Field("ALL", "MAR", "ALL", "ALL", "ALL", "ALL", "ScopeOfCover", "LOV", [], "T4956", "scopeOfCover", "callbackForScopeCovrLoad"),
            new LOV_Field("ALL", "MAR", "ALL", "ALL", "ALL", "ALL", "VesselType", "LOV", [], "DESCPF", "vesselType", null),
            new LOV_Field("ALL", "MAR", "ALL", "ALL", "ALL", "ALL", "Packing Code", "LOV", [], "T7346", "packingCode", null),
            new LOV_Field("ALL", "MAR", "ALL", "ALL", "ALL", "ALL", "Cargo Type", "LOV", [], "DESCPF", "cargoType", null),
            new LOV_Field("ALL", "ALL", "ALL", "ALL", "ALL", "ALL", "Month", "LOV", [], "DESCPF", "month", null),
            new LOV_Field("ALL", "MIS", "NEW BUSINESS", "ALL", "ALL", "ALL", "Excess Type", "LOV", excessTypeFilterNodes, "T9107", "excessType", "callbackForExcessTypesLoad"),
            new LOV_Field("ALL", "FIRE", "NEW BUSINESS", "ALL", "NEW", "FIRE_IDC", "PremiumClass", "LOV", riskTypeFilterNodes, "T4688", "premiumClass", null)
        ];

        if (this.riskObj.riskType == "MAR") {
            let riCodeFilterDetails = [new SearchFilter("DESCITEM", "MC", "STARTSWITH", "AND")];
            let riCodeFilterNodes = this.lovDropDownService.createFilter(riCodeFilterDetails);

            lovFields.push(new LOV_Field("ALL", "MOTOR", "NEW BUSINESS", "ALL", "NEW", "PRIVATE_MOTOR", "RI Retention Code", "LOV", riCodeFilterNodes, "DESCPF", "riCode", null));
        }

        if (this.riskObj.openCover) {
            let mocCountryDateFilterDetails = [new SearchFilter("W.MCOVER", this.riskObj.openCover, "EQ", "AND"),
            new SearchFilter("W.EFFDATE", polEffDate, "GTEQ", "AND")];//KA001
            /* Commenting this code to fetch the result using EFFDate filter, to follow GenLink Logic	
            new SearchFilter("W.FRMDATE", polEffDate ,"LTEQ", "AND"),								
            new SearchFilter("W.TODATE", polEffDate ,"GTEQ", "AND")];*/
            let mocCountryDateFilterNodes = this.lovDropDownService.createFilter(mocCountryDateFilterDetails);

            let defaultClausesFilterDetails = [new SearchFilter("MCOVER", this.riskObj.openCover, "EQ", "AND"),
            new SearchFilter("EFFDATE", polEffDate, "GTEQ", "AND")];//KA001
            /* new SearchFilter("FRMDATE", polEffDate ,"LTEQ", "AND"), new SearchFilter("TODATE", polEffDate ,"GTEQ", "AND")];*/
            let defaultClasuesFilterNodes = this.lovDropDownService.createFilter(defaultClausesFilterDetails);

            let mocCommodityFilterDetails = [new SearchFilter("MCOVER", this.riskObj.openCover, "EQ", "AND"),
            new SearchFilter("EFFDATE", polEffDate, "GTEQ", "AND")];//KA001
            /*new SearchFilter("FRMDATE", polEffDate ,"LTEQ", "AND"),
            new SearchFilter("TODATE", polEffDate ,"GTEQ", "AND")];*/
            let mocCommodityFilterNodes = this.lovDropDownService.createFilter(mocCommodityFilterDetails);

            lovFields.push(new LOV_Field("ALL", "MAR", "ALL", "ALL", "ALL", "ALL", "MOC Country", "LOV", mocCountryDateFilterNodes, "WOCCPF", "mocCountry", null));
            lovFields.push(new LOV_Field("ALL", "MAR", "ALL", "ALL", "ALL", "ALL", "WOCUPF Data", "LOV", defaultClasuesFilterNodes, "WOCUPF", "mocClauses", null));
            lovFields.push(new LOV_Field("ALL", "MAR", "ALL", "ALL", "ALL", "ALL", "WOCMPF Data", "LOV", mocCommodityFilterNodes, "WOCMPF", "mocCommodityList", "callBackForMOCCommodity"));
        }
        else {
            lovFields.push(new LOV_Field("ALL", "MAR", "ALL", "ALL", "ALL", "ALL", "Commodity Code", "LOV", [], "T4988", "commodity", "callbackForCommodityLoad"));
        }

        lovFields.push(new LOV_Field("ALL", "ALL", "ALL", "ALL", "ALL", "ALL", "Country", "LOV", [], "T4958", "country", null));

        if (this.riskObj.toCountryCode) {
            //lovFields.push(new LOV_Field("ALL", "MAR", "ALL", "ALL", "ALL", "ALL", "AreaPorts", "LOV", [], "LOCL", "areaPorts", "callbackForAreaPortsLoad"));
            this.populateAreaPorts();
        }

        this.lovDropDownService.util_populateLOV(lovFields, this);
    }

    onCountrySelection(ev) {
        this.riskObj.fromCountryCode = ev.value;
        this.riskObj.voyageFrom = ev.record.DESCRIPTION;

        let _isReferredCountry = false;
        if (this.riskObj.openCover) {
            let _mocCountry = this.lovDropDownService.lovDataList.mocCountry.find((_item) => _item.VALUE == this.riskObj.fromCountryCode);
            if (!_mocCountry) {
                _isReferredCountry = true;
            }
        }

        if (_isReferredCountry) {
            this.riskObj.isReferredFromCountry = "Y";
        }
        else {
            this.riskObj.isReferredFromCountry = "N";
        }

        this.checkReferredRiskConditions();
    }

    onToCountrySelection(ev) {
        this.riskObj.toCountryCode = ev.value;
        this.riskObj.voyageTo = ev.record.DESCRIPTION;
        this.populateAreaPorts();

        this.riskObj.areaOrPortCode = "";
        this.riskObj.areaOrPortLocation = "";
        this.riskObj.surveyAgent = "";
        this.riskObj.settlingAgent = "";

        let _isReferredCountry = false;
        if (this.riskObj.openCover) {
            let _mocCountry = this.lovDropDownService.lovDataList.mocCountry.find((_item) => _item.VALUE == this.riskObj.toCountryCode);
            if (!_mocCountry) {
                _isReferredCountry = true;
            }
        }

        if (_isReferredCountry) {
            this.riskObj.isReferredToCountry = "Y";
        }
        else {
            this.riskObj.isReferredToCountry = "N";
        }
        this.checkReferredRiskConditions();
    }

    initWOCLPFData() {

        let request: GetLOVData = new GetLOVData().getRequest('ALL', 'MAR', 'ALL', 'ALL', 'ALL', 'ALL', 'WOCLPF Data', 'LOV');
        request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        request.ADVANCE_CONFIG_XML.FILTERS = new Filter();

        request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({ "@FIELD_NAME": "MCOVER", "@FIELD_VALUE": this.riskObj.openCover, "@OPERATION": "EQ", "@CONDITION": "AND" });
        request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({ "@FIELD_NAME": "TODATE", "@FIELD_VALUE": '99999999', "@OPERATION": "EQ", "@CONDITION": "AND" });

        this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, null, null, false, null).success((data) => {
            this.woclpfDataList = [];
            if (data.tuple) {
                if (Array.prototype.isPrototypeOf(data.tuple)) {
                    this.woclpfDataList = data.tuple;
                }
                else if (data.tuple.old && data.tuple.old.WOCLPF) {
                    this.woclpfDataList = [data.tuple];
                }

				/*
				if(this.woclpfData){
					//MCOVER,RATMAR,SHPMTY,ZCOMDCODE,ZCONVCOD,ZCTRYCODE,ZPSCOPE,SEXTYP,SEXCPE,SEXCES,RATDUT,RATWAR					
					if( !(this.riskObj.marineRate > 0) ){
						let _marineRate:any = (this.woclpfData.old.WOCLPF.RATMAR == null || this.woclpfData.old.WOCLPF.RATMAR=="") ? 0 : parseFloat(""+this.woclpfData.old.WOCLPF.RATMAR);
						if(_marineRate > 0){
							this.riskObj.marineRate = numeral(numeral(_marineRate).format(this.marineRateFormat)).value();							
						}
					}
					
					if( !(this.riskObj.dutyRate > 0) ){
						let _dutyRate:any = (this.woclpfData.old.WOCLPF.RATDUT == null || this.woclpfData.old.WOCLPF.RATDUT=="") ? 0 : parseFloat(""+this.woclpfData.old.WOCLPF.RATDUT);
						if(_dutyRate > 0){
							this.riskObj.dutyRate = numeral(numeral(_dutyRate).format(this.marineRateFormat)).value();							 
						}
					}
					
					if( !(this.riskObj.warSrccRate > 0) ){
						let _warSrccRate:any = (this.woclpfData.old.WOCLPF.RATWAR == null || this.woclpfData.old.WOCLPF.RATWAR=="") ? 0 : parseFloat(""+this.woclpfData.old.WOCLPF.RATWAR);
						if(_warSrccRate > 0){
							this.riskObj.warSrccRate = numeral(numeral(_warSrccRate).format(this.marineRateFormat)).value();							 
						}
					}
				}
				*/
            }
        }).error((response, status, errorText) => {
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error while getting WOCLPF Data ", 5000));
        });

    }

    initWOCDPFData() {

        let polEffDate = ApplicationUtilService.getFormattedDate(this.headerInfo.effectiveDate, "YYYY-MM-DD", "YYYYMMDD");

        let request: GetLOVData = new GetLOVData().getRequest('ALL', 'MAR', 'ALL', 'ALL', 'ALL', 'ALL', 'WOCDPF Data', 'LOV');
        request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        request.ADVANCE_CONFIG_XML.FILTERS = new Filter();

        request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({ "@FIELD_NAME": "MCOVER", "@FIELD_VALUE": this.riskObj.openCover, "@OPERATION": "EQ", "@CONDITION": "AND" });
        request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({ "@FIELD_NAME": "TODATE", "@FIELD_VALUE": polEffDate, "@OPERATION": "GT", "@CONDITION": "AND" });

        this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, null, null, false, null).success((data) => {
            this.wocdpfData = new Object();
            if (data.tuple) {
                if (Array.prototype.isPrototypeOf(data.tuple)) {
                    this.wocdpfData = data.tuple[0];
                }
                else if (data.tuple.old && data.tuple.old.WOCDPF) {
                    this.wocdpfData = data.tuple;
                }

				/*
				//Default transhipment rate only on tShipment Vessel selection.
				if(this.wocdpfData){
					if( !(this.riskObj.tShipmentRate > 0) ){
						let _tShipmentRate:any = (this.wocdpfData.old.WOCDPF.TRANSHIPMENTRATE == null || this.wocdpfData.old.WOCDPF.TRANSHIPMENTRATE=="") ? 0 : parseFloat(""+this.wocdpfData.old.WOCDPF.TRANSHIPMENTRATE);
						if(_tShipmentRate > 0){
							this.riskObj.tShipmentRate = numeral(numeral(_tShipmentRate).format(this.marineRateFormat)).value();
						}
					}
				}
				*/
            }
        }).error((response, status, errorText) => {
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error while getting WOCDPF data", 5000));
            this.areaPorts = [];
        });

    }

	/*initWOCMPFData(){
		
		let polEffDate = ApplicationUtilService.getFormattedDate(this.headerInfo.effectiveDate,"YYYY-MM-DD","YYYYMMDD");
		
		let request:GetLOVData = new GetLOVData().getRequest('ALL','MAR','ALL','ALL','ALL','ALL','WOCMPF Data','LOV');
		request.ADVANCE_CONFIG_XML= new SearchAdvancedConfig();
		request.ADVANCE_CONFIG_XML.FILTERS = new Filter();
			
		request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({"@FIELD_NAME":"MCOVER", "@FIELD_VALUE":this.riskObj.openCover, "@OPERATION":"EQ", "@CONDITION":"AND"});
		request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({"@FIELD_NAME":"FRMDATE", "@FIELD_VALUE":polEffDate, "@OPERATION":"LTEQ", "@CONDITION":"AND"});
		request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({"@FIELD_NAME":"TODATE", "@FIELD_VALUE":polEffDate, "@OPERATION":"GTEQ", "@CONDITION":"AND"});
		
		this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request , null, null, false, null).success((data)=> {
			this.wocmpfDataList= [];
			if(data.tuple){
				if(Array.prototype.isPrototypeOf(data.tuple)){
					this.wocmpfDataList = data.tuple;
				}
				else if(data.tuple.old && data.tuple.old.WOCMPF) {
					this.wocmpfDataList = [data.tuple];
				}
			}
		}).error((response, status, errorText)=> {
			this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR,"Error while getting MOC Commodity data", 5000));
			this.areaPorts = [];
		});
		
	}*/

    populateAreaPorts() {
        let request: GetLOVData = new GetLOVData().getRequest('ALL', 'MAR', 'ALL', 'ALL', 'ALL', 'ALL', 'AreaPorts', 'LOV');
        request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        request.ADVANCE_CONFIG_XML.FILTERS = new Filter();

        request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({ "@FIELD_NAME": "CTRYCODE", "@FIELD_VALUE": this.riskObj.toCountryCode, "@OPERATION": "EQ", "@CONDITION": "AND" });

        this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, null, null, false, null).success((data) => {
            this.areaPorts = [];
            if (data.tuple) {
                if (Array.prototype.isPrototypeOf(data.tuple)) {
                    for (let _item of data.tuple) {
                        this.areaPorts.push(_item.old.LOCL);
                    }
                }
                else if (data.tuple.old && data.tuple.old.LOCL) {
                    this.areaPorts = [data.tuple.old.LOCL];
                }
            }

        }).error((response, status, errorText) => {
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error while getting plan Area ports for Country - " + this.riskObj.toCountryCode, 5000));
            this.areaPorts = [];
        });
    }

    // callbackForAreaPortsLoad(scopeObject){		
    // scopeObject.areaPorts= scopeObject.lovDropDownService.lovDataList.areaPorts;
    // }

    onShipmentTypeChange(ev) {
        this.riskObj.shipmentType = ev.value;
        this.riskObj.shipmentTypeDesc = ev.record.DESCRIPTION;

        this.riskObj.fromCountryCode = '';
        this.riskObj.voyageFrom = '';
        this.riskObj.toCountryCode = '';
        this.riskObj.voyageTo = '';
        this.riskObj.areaOrPortCode = '';
        this.riskObj.areaOrPortLocation = '';
        this.areaPorts = [];
        this.riskObj.surveyAgent = '';
        this.riskObj.settlingAgent = '';

        // if(["IC","IT","IM"].indexOf(this.riskObj.shipmentType) != -1){
        if (["IC", "IT", "EX", "CV"].indexOf(this.riskObj.shipmentType) >= 0) {
            let _rec = this.lovDropDownService.lovDataList.country.find((_item) => _item.VALUE == "MY");
            if (_rec) {
                this.riskObj.fromCountryCode = _rec.VALUE;
                this.riskObj.voyageFrom = _rec.DESCRIPTION;
            }
        }

        if (["IM", "IC", "IT", "CV"].indexOf(this.riskObj.shipmentType) >= 0) {
            let _rec = this.lovDropDownService.lovDataList.country.find((_item) => _item.VALUE == "MY");
            if (_rec) {
                this.riskObj.toCountryCode = _rec.VALUE;
                this.riskObj.voyageTo = _rec.DESCRIPTION;
            }
        }
        if (this.riskObj.toCountryCode) {
            this.populateAreaPorts();
            if (this.areaPorts && this.areaPorts.length > 0) {
                let _areaPortRec = this.areaPorts.find((_item) => _item.CTRYCODE == this.riskObj.toCountryCode);
                let _setAreaOrPortLocation = false;
                if (_areaPortRec) {
                    this.riskObj.areaOrPortCode = _areaPortRec.CTRYCODE;
                    if (this.riskObj.areaOrPortLocation) {
                        let _areaPortLocationRec = this.areaPorts.find((_item) => (_item.CTRYCODE == this.riskObj.toCountryCode && _item.ZSRVAGTLOC == this.riskObj.areaOrPortLocation));
                        this.riskObj.areaOrPortLocation = _areaPortLocationRec.ZSRVAGTLOC;
                        this.riskObj.surveyAgent = _areaPortLocationRec.ZSRVAGT01;
                        this.riskObj.settlingAgent = _areaPortLocationRec.ZSRVAGT02;
                        _setAreaOrPortLocation = true;
                    }
                }

                if (!_setAreaOrPortLocation) {
                    this.riskObj.areaOrPortLocation = "";
                    this.riskObj.surveyAgent = "";
                    this.riskObj.settlingAgent = "";
                }
            } else {
                this.riskObj.areaOrPortCode = "";
                this.riskObj.areaOrPortLocation = "";
                this.riskObj.surveyAgent = "";
                this.riskObj.settlingAgent = "";
            }
        }

        this.populateMOCDefaults();

        //this.checkReferredRiskConditions();
    }

    onPackingCodeChange(ev) {
        this.riskObj.packingCode = ev.value;
        this.checkReferredRiskConditions();
    }

    onScopeOfCoverChange(ev) {
        this.riskObj.scopeOfCover = ev.value;
        this.setSIMarkUp();
        this.populateMOCDefaults();
    }

    setSIMarkUp() {

        if (this.riskObj.openCover && this.wocdpfData && this.wocdpfData.old) {
            let _orgMarkUpRate = this.getSIMarkUpRate();
            let _markUpRate: any = this.riskObj.markUp;
            _markUpRate = (_markUpRate == null || _markUpRate == "") ? 0 : parseFloat("" + _markUpRate);
            if (!(_markUpRate > 0)) {
                this.riskObj.markUp = numeral(numeral(parseFloat("" + _orgMarkUpRate)).format(this.rateFormat)).value();
            }
        }
    }

    getSIMarkUpRate() {
        let _rate = 0;
        if (this.wocdpfData && this.wocdpfData.old) {
            _rate = numeral(numeral(parseFloat("" + this.wocdpfData.old.WOCDPF.SUMMARKUP)).format(this.rateFormat)).value();
        }
        return _rate;
    }

    onSIMarkupChange(ev) {
        this.riskObj.markUp = ev;
        //this.checkReferredRiskConditions();
        this.resetTotal();
    }

    onAreaPortChange(ev) {
        this.riskObj.areaOrPortLocation = ev.value;
        this.riskObj.areaOrPortCode = ev.record.CTRYCODE;
        this.riskObj.surveyAgent = ev.record.ZSRVAGT01;
        this.riskObj.settlingAgent = ev.record.ZSRVAGT02;
    }

    onConveyanceChange(ev) {
        this.riskObj.conveyance = ev.value;
        this.riskObj.conveyanceDesc = ev.record.DESCRIPTION;
        this.riskObj.riRetentionCode = ev.record.ZRIRETN;
        // ev.record.ZRFRDRSK;
        // this.riskObj.markUp = numeral(ev.record.SUMMARKUP).format(this.currencyRateFormat);
        this.populateMOCDefaults();
        this.checkReferredRiskConditions();//MD001
    }

    onCurrencyChange(ev) {
        this.riskObj.siCurrency = ev.value;
        this.riskObj.siRate = numeral(numeral(parseFloat("" + ev.record.SCRATE)).format(this.currencyRateFormat)).value();
        if (this.riskObj.riskCoverageDetails.riskCoverage && this.riskObj.riskCoverageDetails.riskCoverage.length > 0)
            this.resetTotal();
    }

    onCurrencyRateChange(ev) {
        if (this.riskObj.siCurrency) {
            this.riskObj.siRate = ev;

            let _rec = this.lovDropDownService.lovDataList.currency.find((_data) => _data.VALUE == this.riskObj.siCurrency);
            let _lLimit = (_rec.SLRATE == null || _rec.SLRATE == "") ? 0 : parseFloat(_rec.SLRATE);
            let _uLimit = (_rec.SHRATE == null || _rec.SHRATE == "") ? 0 : parseFloat(_rec.SHRATE);

            let _modifiedRate = (ev == null || ev == "") ? 0 : parseFloat("" + ev);

            if (_modifiedRate < _lLimit || _modifiedRate > _uLimit) {
                this.riskObj.siRate = numeral(numeral(parseFloat("" + _rec.SCRATE)).format(this.currencyRateFormat)).value();
                if (this.currencyRateCtrl != null) this.currencyRateCtrl.setter(this.riskObj.siRate, this.currencyRateCtrl.comp);
            }
        }
        else {
            this.riskObj.siRate = 0;
            if (this.currencyRateCtrl != null) this.currencyRateCtrl.setter(this.riskObj.siRate, this.currencyRateCtrl.comp);
        }

        //this.checkReferredRiskConditions();

        if (this.riskObj.riskCoverageDetails.riskCoverage && this.riskObj.riskCoverageDetails.riskCoverage.length > 0)
            this.resetTotal();
    }

    onETDChange() {
        let _etdDate = moment(this.riskObj.etd, "YYYY-MM-DD");
        let _effctiveDate = moment(this.headerInfo.effectiveDate, "YYYY-MM-DD");
        let diffMonths = _etdDate.diff(_effctiveDate, 'months');
        // let diffDays = toDate.diff(fromDate, 'days');

        if (_effctiveDate && diffMonths >= 3) {
            this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "ETD date is greater than 3 months", 3000));
        }
    }

    resetTotal() {

        let _siRate: any = this.riskObj.siRate;
        let _dutyAmount: any = this.riskObj.duty;
        let _dutyRate: any = this.riskObj.dutyRate;
        let _marineRate: any = this.riskObj.marineRate;
        let _warSrccRate: any = this.riskObj.warSrccRate;
        let _oAgeVesselRate: any = this.riskObj.oAgeVesselRate;
        let _tShipmentRate: any = this.riskObj.tShipmentRate;

        _siRate = (_siRate == null || _siRate == "") ? 0 : _siRate;
        _dutyAmount = (_dutyAmount == null || _dutyAmount == "") ? 0 : parseFloat("" + _dutyAmount);
        _dutyRate = (_dutyRate == null || _dutyRate == "") ? 0 : _dutyRate;
        _marineRate = (_marineRate == null || _marineRate == "") ? 0 : _marineRate;
        _warSrccRate = (_warSrccRate == null || _warSrccRate == "") ? 0 : _warSrccRate;
        _oAgeVesselRate = (_oAgeVesselRate == null || _oAgeVesselRate == "") ? 0 : _oAgeVesselRate;
        _tShipmentRate = (_tShipmentRate == null || _tShipmentRate == "") ? 0 : _tShipmentRate;

        for (let _coverItem of this.riskObj.riskCoverageDetails.riskCoverage) {
            let si: any = _coverItem.originalSI;
            si = (si == null || si == "") ? 0 : si;
            let _covertedSI = si * _siRate;
            _coverItem.convertedSI = numeral(numeral(_covertedSI).format(this.premiumFormat)).value();
        }

        this.riskObj.totalCoverOriginalSI = this.getTotalByProperty("originalSI", this.riskObj.riskCoverageDetails.riskCoverage, this.premiumFormat);
        this.riskObj.totalCoverConvertedSI = this.getTotalByProperty("convertedSI", this.riskObj.riskCoverageDetails.riskCoverage, this.premiumFormat);

        this.riskObj.totalGoodsOriginalSI = this.riskObj.totalCoverOriginalSI + (this.riskObj.totalCoverOriginalSI * this.riskObj.markUp * 0.01);
        this.riskObj.totalGoodsConvertedSI = this.riskObj.totalGoodsOriginalSI * _siRate;

        // this.riskObj.totalGoodsOriginalSI = this.getTotalByProperty("originalSI",this.riskObj.riskCoverageDetails.riskCoverage, this.premiumFormat);
        // this.riskObj.totalGoodsConvertedSI = this.getTotalByProperty("convertedSI",this.riskObj.riskCoverageDetails.riskCoverage, this.premiumFormat);		
        // this.riskObj.totalGoods = this.riskObj.totalCoverOriginalSI + (this.riskObj.totalCoverOriginalSI * this.riskObj.markUp * 0.01);		
        // let _totalGoodsBillAmount = this.riskObj.totalGoods * _siRate;

        this.riskObj.dutyPremium = _dutyAmount * _siRate * _dutyRate * 0.01;

		/*this.riskObj.marinePremium = this.riskObj.totalGoodsConvertedSI * _marineRate * 0.01;
		this.riskObj.warSrccPremium = this.riskObj.totalGoodsConvertedSI * _warSrccRate * 0.01;
		this.riskObj.oAgeVesselPremium = this.riskObj.totalGoodsConvertedSI * _oAgeVesselRate * 0.01;
		this.riskObj.tShipmentPremium = this.riskObj.totalGoodsConvertedSI * _tShipmentRate * 0.01;*/

		/*let _marinePremium = _totalGoodsBillAmount * _marineRate * 0.01;
		let _warSrccPremium = _totalGoodsBillAmount * _warSrccRate * 0.01;
		let _oAgeVesselPremium = _totalGoodsBillAmount * _oAgeVesselRate * 0.01;
		let _tShipmentPremium = _totalGoodsBillAmount * _tShipmentRate * 0.01;*/

        let _marinePremium = this.riskObj.totalGoodsConvertedSI * _marineRate * 0.01;
        let _warSrccPremium = this.riskObj.totalGoodsConvertedSI * _warSrccRate * 0.01;
        let _oAgeVesselPremium = this.riskObj.totalGoodsConvertedSI * _oAgeVesselRate * 0.01;
        let _tShipmentPremium = this.riskObj.totalGoodsConvertedSI * _tShipmentRate * 0.01;

        this.riskObj.marinePremium = numeral(numeral(_marinePremium).format(this.premiumFormat)).value();
        this.riskObj.warSrccPremium = numeral(numeral(_warSrccPremium).format(this.premiumFormat)).value();
        this.riskObj.oAgeVesselPremium = numeral(numeral(_oAgeVesselPremium).format(this.premiumFormat)).value();
        this.riskObj.tShipmentPremium = numeral(numeral(_tShipmentPremium).format(this.premiumFormat)).value();

        // let _totOrgSI = this.riskObj.totalGoods + this.riskObj.dutyPremium;
        let _totOrgSI = this.riskObj.totalGoodsOriginalSI + _dutyAmount;
        this.riskObj.totalOriginalSI = numeral(numeral(_totOrgSI).format(this.premiumFormat)).value();

        this.riskObj.totalConvertedSI = numeral(numeral(this.riskObj.totalOriginalSI * _siRate).format(this.premiumFormat)).value();
        this.riskObj.totalSI = this.riskObj.totalOriginalSI;
        //GA001 START
        //this.riskObj.capitalSumInsured = this.riskObj.totalSI;
        this.riskObj.capitalSumInsured = this.riskObj.totalConvertedSI;
        this.headerInfo.targetSumInsured = this.riskObj.totalConvertedSI;
        //GA001 END

        // this.riskObj.originalTotalPremium = this.riskObj.marinePremium + this.riskObj.warSrccPremium + this.riskObj.oAgeVesselPremium + this.riskObj.tShipmentPremium + (this.riskObj.dutyPremium * _siRate * _dutyRate * 0.01);
        this.riskObj.originalTotalPremium = this.riskObj.marinePremium + this.riskObj.warSrccPremium + this.riskObj.oAgeVesselPremium + this.riskObj.tShipmentPremium + this.riskObj.dutyPremium;

        //SST Code
        if (["IM", "EX", "CV"].indexOf(this.riskObj.shipmentType) == -1) {
            if (this.riskObj.SST == 0) {
                let respObj = this._bmsUtilService.getTAXDetails();
                if (respObj != undefined && respObj != "") {
                    this.headerInfo.SSTTaxRate = Number(respObj[0].old.ITEMPF.GST);
                    this.headerInfo.GSTTaxRate = Number(respObj[1].old.ITEMPF.GST);

                    this.riskObj.SST = Number(this.headerInfo.SSTTaxRate);
                    this.riskObj.GST = Number(this.headerInfo.GSTTaxRate);
                }
            }

            let tempSSTAmount = (Number(this.riskObj.SST) > 0) ? numeral(numeral((this.riskObj.originalTotalPremium * Number(this.riskObj.SST)) / 100).format(this.premiumFormat)).value() : 0;
			/*commenting below code since Marine products should not calculate pro-rated tax
			this.riskObj.sstAmount = (tempSSTAmount > 0)?numeral(numeral(BMSUtilService.calculatePremiumAmount(tempSSTAmount,"S")).format(this.premiumFormat)).value():0; */
            this.riskObj.sstAmount = (tempSSTAmount > 0) ? numeral(numeral(tempSSTAmount).format(this.premiumFormat)).value() : 0;
        }
        else {
            this.riskObj.sstAmount = 0;
            this.riskObj.SST = Number(0);
            this.headerInfo.SSTTaxRate = this.riskObj.SST;
        }
        //this.riskObj.totalPremium = numeral(numeral(this.riskObj.originalTotalPremium).format(this.premiumFormat)).value();
        this.riskObj.totalPremium = parseFloat("" + numeral(numeral(this.riskObj.originalTotalPremium).format(this.premiumFormat)).value()) + parseFloat("" + numeral(this.riskObj.sstAmount).value());
        let tempSSTAmt = this.riskObj.sstAmount;
        let tempTotPrem = this.riskObj.totalPremium;
        this.onPremiumChange.emit(this.riskObj.totalPremium);
        this.riskObj.sstAmount = parseFloat("" + numeral(tempSSTAmt).value());
        this.riskObj.totalPremium = parseFloat("" + numeral(tempTotPrem).value());
        //End

        this.checkReferredRiskConditions();
        this.validateSumInsured();
    }

    validateSumInsured() {
        if (this.riskObj.riRetentionCode && this.riskObj.isRIOverWrittenByUW == 'N') {
            this._bmsUtilService.getTotalGrossCapacity(this.riskObj.riRetentionCode).subscribe((data) => this.compareSIWithTotGrossCap(data));
        }
        else
            this.setRIMethodEditableFlag();
    }

    compareSIWithTotGrossCap(totGrossCap) {

        let _totalGrossCapacity = (!totGrossCap) ? 0 : parseFloat("" + totGrossCap);
        this.riskObj.totalGrossCapacity = _totalGrossCapacity;

        let _capitalSumInsured = parseFloat("" + this.riskObj.capitalSumInsured);

        if (_totalGrossCapacity > 0 && _capitalSumInsured > _totalGrossCapacity && (this.riskObj.RIMethod == null || this.riskObj.RIMethod == "" || parseFloat("" + this.riskObj.RIMethod) != 8)) {
            this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Capital Sum Insured is greater than Total Gross Capacity: " + _totalGrossCapacity + ",  RI is Required.", 10000));

            this.riskObj.RIRequired = "Yes";
            this.riskObj.RIMethod = "8";
        }
        else if (_capitalSumInsured <= _totalGrossCapacity) {
            this.riskObj.RIRequired = "No";
            this.riskObj.RIMethod = this.riskObj.RIMethodSys;
        }
        this._riService.setRI().subscribe();
        this.setRIMethodEditableFlag();
    }

    onChangeTBAIndicator(ev, fld) {
        if (fld == 'vslTBAIndicator') {
            this.riskObj.vslTBAIndicator = "false";
            if (ev.target.checked == true) {
                this.riskObj.vslTBAIndicator = "true";
            }
        }
        else if (fld == 'tShipVslTBAIndicator') {
            this.riskObj.tShipVslTBAIndicator = "false";
            if (ev.target.checked == true) {
                this.riskObj.tShipVslTBAIndicator = "true";
            }
        }
    }

    onTShipVeslChnage(ev) {
        this.riskObj.tShipVessel = ev.value;
        this.riskObj.tShipVesselDesc = (ev.record.DESCRIPTION) ? ev.record.DESCRIPTION.slice(0, 20) : "";

        if (this.riskObj.openCover && this.riskObj.tShipVessel && this.riskObj.tShipVessel != "TBA" && this.wocdpfData && this.wocdpfData.old) {
            if (!(this.riskObj.tShipmentRate > 0)) {
                let _tShipmentRate: any = (this.wocdpfData.old.WOCDPF.TRANSHIPMENTRATE == null || this.wocdpfData.old.WOCDPF.TRANSHIPMENTRATE == "") ? 0 : parseFloat("" + this.wocdpfData.old.WOCDPF.TRANSHIPMENTRATE);
                if (_tShipmentRate > 0) {
                    this.riskObj.tShipmentRate = numeral(numeral(_tShipmentRate).format(this.marineRateFormat)).value();
                }
            }
        }

    }

    onVesselChange(ev) {
        this.riskObj.vessel = ev.value;
        this.riskObj.vesselDesc = (ev.record.DESCRIPTION) ? ev.record.DESCRIPTION.slice(0, 35) : "";

        if (this.riskObj.openCover && this.wocdpfData && this.wocdpfData.old) {
            this.riskObj.oAgeVesselRate = 0;
            this.riskObj.vesselAge = 0;
            let ageOfVessel = 0;
            let _year: any = ev.record.SNCONB;
            _year = (_year == null || _year == "") ? 0 : parseInt("" + _year);
            if (_year > 0) {
                let currentYear = Number(new Date().getFullYear());
                ageOfVessel = currentYear - _year;
            }

            if (ageOfVessel > 0) {
                this.riskObj.vesselAge = ageOfVessel;
                let _range1: any = this.wocdpfData.old.WOCDPF.OLDAGERATE1; //16-20
                let _range2: any = this.wocdpfData.old.WOCDPF.OLDAGERATE2; //21-25
                let _range3: any = this.wocdpfData.old.WOCDPF.OLDAGERATE3; //26-30
                let _range4: any = this.wocdpfData.old.WOCDPF.OLDAGERATE4; //31-35
                let _range5: any = this.wocdpfData.old.WOCDPF.OLDAGERATE5; //36-40

                _range1 = (_range1 == null || _range1 == "") ? 0 : parseFloat("" + _range1);
                _range2 = (_range2 == null || _range2 == "") ? 0 : parseFloat("" + _range2);
                _range3 = (_range3 == null || _range3 == "") ? 0 : parseFloat("" + _range3);
                _range4 = (_range4 == null || _range4 == "") ? 0 : parseFloat("" + _range4);
                _range5 = (_range5 == null || _range5 == "") ? 0 : parseFloat("" + _range5);

                let _oAgeVesselRate = 0;
                if (_range1 > 0 && ageOfVessel >= 16 && ageOfVessel <= 20) {
                    _oAgeVesselRate = _range1;
                }
                else if (_range2 > 0 && ageOfVessel >= 21 && ageOfVessel <= 25) {
                    _oAgeVesselRate = _range2;
                }
                else if (_range3 > 0 && ageOfVessel >= 26 && ageOfVessel <= 30) {
                    _oAgeVesselRate = _range3;
                }
                else if (_range4 > 0 && ageOfVessel >= 31 && ageOfVessel <= 35) {
                    _oAgeVesselRate = _range4;
                }
                else if (_range5 > 0 && ageOfVessel >= 36 && ageOfVessel <= 40) {
                    _oAgeVesselRate = _range5;
                }

                if (_oAgeVesselRate > 0) {
                    this.riskObj.oAgeVesselRate = _oAgeVesselRate;
                }
            }

            this.resetTotal();
        }
    }

    getTotalByProperty(prop, ary, format: string) {
        let total = 0;
        for (let eachItem of ary) {
            if (eachItem[prop] != null && eachItem[prop] != "")
                total = total + parseFloat(numeral(eachItem[prop]).value());
        }
        if (format != null)
            return numeral(numeral(total).format(format)).value();
        else
            return total;
    }

    handleError(response, status, errorText, prms) {
        prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, response.responseJSON.faultstring.text, -1));
    }

    addRiskCoverage() {
        let riskCoverageItem = new RiskCoverage();
        riskCoverageItem.seqNumber = this.riskObj.riskCoverageDetails.riskCoverage.length + 1;

        this.riskObj.riskCoverageDetails.riskCoverage.push(riskCoverageItem);
    }

    removeRiskCover(coverItem) {
        let _idx = this.riskObj.riskCoverageDetails.riskCoverage.indexOf(coverItem);
        this.riskObj.riskCoverageDetails.riskCoverage.splice(_idx, 1);
        this.resetItemNumber();
        this.resetTotal();
    }

    resetItemNumber() {
        for (let _riskCoverage of this.riskObj.riskCoverageDetails.riskCoverage) {
            let index = this.riskObj.riskCoverageDetails.riskCoverage.indexOf(_riskCoverage);
            _riskCoverage.seqNumber = (index + 1);
        }
    }

    addDeclarationMonth() {
        let declarationMonthItem = new DeclarationMonth();
        declarationMonthItem.seqNumber = this.riskObj.declarationMonthDetails.declarationMonth.length + 1;

        this.riskObj.declarationMonthDetails.declarationMonth.push(declarationMonthItem);
    }

    removeDeclarationMonth(item) {
        let _idx = this.riskObj.declarationMonthDetails.declarationMonth.indexOf(item);
        this.riskObj.declarationMonthDetails.declarationMonth.splice(_idx, 1);
        this.resetDMItemNumber();
        this.calDMTotalPrem();
    }

    resetDMItemNumber() {
        for (let _declMonth of this.riskObj.declarationMonthDetails.declarationMonth) {
            let index = this.riskObj.declarationMonthDetails.declarationMonth.indexOf(_declMonth);
            _declMonth.seqNumber = (index + 1);
        }
    }

    calDMTotalPrem() {
        this.riskObj.declarationMonthDetails.totalSI = this.getTotalByProperty("sumInsured", this.riskObj.declarationMonthDetails.declarationMonth, null);
        this.riskObj.declarationMonthDetails.totalPremium = this.getTotalByProperty("orgPremium", this.riskObj.declarationMonthDetails.declarationMonth, null);

    }

    setReferredFromUI() {
        if (event.target != null) {
            let riskClass = jQuery(event.target).find("option:selected").text();
            this.riskObj.riskClassification = riskClass;
            this.setReferredByRiskClass(this, riskClass);
        }
    }

    setReferredByRiskClass(comp, riskClass) {
        if (riskClass != null && riskClass == "Referred") {
            comp.setReferred(comp, true);
        }
        else {
            comp.setReferredByRI(comp, comp.riskObj.riRetentionCode);
        }
    }

    setReferred(comp, toRefer) {
        comp.onRiskClsChange.emit("");
    }

    setReferredByRI(comp, riCode) {
        // if(this.leastPreferredRI.indexOf(riCode) != -1){
        // comp.riskObj.riskClassification = "Referred";
        // comp.riskObj.symRiskClassification = "Referred";
        // comp.setReferred(comp,true);
        // }
        // else{
        comp.setReferred(comp, false);
        // }
    }

    setReferredByRIFromUI() {
        if (event.target != null) {
            let riCode = jQuery(event.target).find("option:selected").text();
            this.setReferredByRI(this, riCode);
        }
    }

    emitRiskClass(comp) {
        comp.onRiskClsChange.emit("");
    }

    resetFI(value) {
        if (value == "Y")
            this.riskObj.financialInterest = new FinancialInterest();
        else
            this.riskObj.financialInterest = null;
    }

    resetSurvey(value) {
        if ("Y" == value) {
            this.riskObj.survey = new Survey();
        }
        else {
            this.riskObj.survey = null;
        }
    }

    setSurveyNeed() {

        this.riskObj.survey = null;
        this.riskObj.isSurveyNeeded = 'N';
    }

    onRIRtnChange(value) {
        this.riskObj.riRetentionCode = value;
        this.setSurveyNeed();
        this.validateSumInsured();
    }

    onExcessTypeChange(ev) {
        this.riskObj.excessType = ev.value;
        this.setExcessValidationFiels();
    }

    setExcessValidationFiels() {
        if (this.riskObj.excessType && this.riskObj.excessType != '') {
            for (let _etItem of this.lovDropDownService.lovDataList.excessType) {
                if (_etItem.VALUE == this.riskObj.excessType) {
                    this.isExcessPercentMandatory = (_etItem.ACTN02 == 'Y') ? 'Y' : 'N';
                    this.isExcessAmountMandatory = (_etItem.ACTN01 == 'Y') ? 'Y' : 'N';
                    BMSConstants.setExcessTypeRecord(this.riskObj.riskType + this.riskObj.excessType, _etItem);
                }
            }
        }
        else {
            this.isExcessPercentMandatory = 'N';
            this.isExcessAmountMandatory = 'N';
            this.riskObj.excessPercentage = 0;
            this.riskObj.excessAmount = 0;
        }
    }

    callbackForExcessTypesLoad(scopeObject) {
        if (this.riskObj.openCover) {
			/*if(this.woclpfData && this.woclpfData.SEXTYP){				
				this.excessTypesList.push(this.lovDropDownService.lovDataList.excessType.find((_data)=> _data.SEXTYP==this.woclpfData.SEXTYP));
				
				if(!this.riskObj.excessType){
					this.riskObj.excessType = this.woclpfData.SEXTYP;
					
					let _excsPercentage:any = (this.woclpfData.SEXCPE == null || this.woclpfData.SEXCPE =="") ? 0 : parseFloat(""+this.woclpfData.SEXCPE);
					if(_excsPercentage>0){
						this.riskObj.excessPercentage = numeral(numeral(_excsPercentage).format(this.percentFormat)).value();
					}
					
					let _excsAmount:any = (this.woclpfData.SEXCES == null || this.woclpfData.SEXCES =="") ? 0 : parseFloat(""+this.woclpfData.SEXCES);
					if(_excsAmount>0){
						this.riskObj.excessAmount = numeral(numeral(_excsAmount).format(this.siFormat)).value();
					}
				}
			}*/
        }
        else {
            this.excessTypesList = this.lovDropDownService.lovDataList.excessType;
        }
        if (scopeObject.excessType && scopeObject.excessType != '') {
            scopeObject.setExcessValidationFiels();
        }
    }

    callbackForConveyanceLoad(scopeObject) {
        scopeObject.conveyanceList = [];

        if (scopeObject.riskObj.openCover && scopeObject.lovDropDownService.lovDataList.conveyance && scopeObject.wocdpfData && scopeObject.wocdpfData.old) {
            let _conveyanceCodesList = scopeObject.wocdpfData.old.WOCDPF.ZCONVCOD;
            scopeObject.conveyanceList = scopeObject.lovDropDownService.lovDataList.conveyance.filter((_data) => _conveyanceCodesList.split(",").indexOf(_data.VALUE) != -1);
        } else if (!scopeObject.riskObj.openCover) {
            scopeObject.conveyanceList = scopeObject.lovDropDownService.lovDataList.conveyance;
        }

        if (scopeObject.riskObj.conveyance && !scopeObject.riskObj.conveyanceDesc) {
            if (scopeObject.conveyanceList && scopeObject.conveyanceList.length > 0) {
                let _conveyanceItem = scopeObject.conveyanceList.find((_data) => _data.VALUE == scopeObject.riskObj.conveyance);
                if (_conveyanceItem) {
                    scopeObject.riskObj.conveyanceDesc = _conveyanceItem.DESCRIPTION;
                }
            }
            else {
                scopeObject.riskObj.conveyance = '';
                scopeObject.riskObj.conveyanceDesc = ''
            }
        }

    }

    callbackForShipmTypeLoad(scopeObject) {
        scopeObject.shipmntTypesList = [];
        if (scopeObject.riskObj.openCover && scopeObject.lovDropDownService.lovDataList.shipmentType && scopeObject.wocdpfData && scopeObject.wocdpfData.old) {
            let _shipmentCodes = scopeObject.wocdpfData.old.WOCDPF.SHPMTY;
            scopeObject.shipmntTypesList = scopeObject.lovDropDownService.lovDataList.shipmentType.filter((_data) => _shipmentCodes.split(",").indexOf(_data.VALUE) != -1);
        } else if (!scopeObject.riskObj.openCover) {
            scopeObject.shipmntTypesList = scopeObject.lovDropDownService.lovDataList.shipmentType;
        }

        if (scopeObject.riskObj.shipmentType && !scopeObject.riskObj.shipmentTypeDesc) {
            if (scopeObject.shipmntTypesList && scopeObject.shipmntTypesList.length > 0) {
                let _shpmntItem = scopeObject.shipmntTypesList.find((_data) => _data.VALUE == scopeObject.riskObj.shipmentType);
                if (_shpmntItem) {
                    scopeObject.riskObj.shipmentTypeDesc = _shpmntItem.DESCRIPTION;
                }
            }
            else {
                scopeObject.riskObj.shipmentType = '';
                scopeObject.riskObj.shipmentTypeDesc = '';
            }
        }
    }

    callbackForScopeCovrLoad(scopeObject) {
        scopeObject.scopeOfCoversList = [];
        if (scopeObject.riskObj.openCover && scopeObject.lovDropDownService.lovDataList.scopeOfCover && scopeObject.wocdpfData && scopeObject.wocdpfData.old) {
            let _scopeOfCovers = scopeObject.wocdpfData.old.WOCDPF.ZPSCOPE;
            scopeObject.scopeOfCoversList = scopeObject.lovDropDownService.lovDataList.scopeOfCover.filter((_data) => _scopeOfCovers.split(",").indexOf(_data.VALUE) != -1);
        } else if (!scopeObject.riskObj.openCover) {
            scopeObject.scopeOfCoversList = scopeObject.lovDropDownService.lovDataList.scopeOfCover;
        }
    }

    callBackForMOCCommodity(scopeObject) {
        //let _mocCommdList = scopeObject.lovDropDownService.lovDataList.mocCommodityList;
        //GA001 START
        if (scopeObject.headerInfo.targetSumInsured != scopeObject.riskObj.totalConvertedSI) {
            scopeObject.resetTotal();
        }
        //GA001 END
    }

    callbackForCommodityLoad(scopeObject) {
        scopeObject.commodityCodeList = [];
        //scopeObject.commodityCodeList = scopeObject.lovDropDownService.lovDataList.commodity;

        scopeObject.populateCommodityList();

		/*
		if(scopeObject.riskObj.openCover && scopeObject.lovDropDownService.lovDataList.commodity && scopeObject.woclpfDataList && scopeObject.woclpfDataList.length > 0){
			
			for(let _item of scopeObject.woclpfDataList){
				if(_item.old.WOCLPF.COMMODITY){
					let _listItem = scopeObject.commodityCodeList.find((_data)=> _data.VALUE == _item.old.WOCLPF.COMMODITY);
					if(!_listItem){
						let _mocItem = scopeObject.lovDropDownService.lovDataList.commodity.find((_data)=> _data.VALUE == _item.old.WOCLPF.COMMODITY);
						scopeObject.commodityCodeList.push(_mocItem);
					}
				}
			}
			//let _scoeOfCovers = scopeObject.wocdpfData.old.WOCDPF.ZPSCOPE;
			//scopeObject.commodityCodeList = scopeObject.lovDropDownService.lovDataList.commodity.filter( (_data)=> _scoeOfCovers.split(",").indexOf(_data.VALUE) != -1 );
			
		} else {
			scopeObject.commodityCodeList = scopeObject.lovDropDownService.lovDataList.commodity;
		}
        */
        //GA001 START
        if (scopeObject.headerInfo.targetSumInsured != scopeObject.riskObj.totalConvertedSI) {
            scopeObject.resetTotal();
        }
        //GA001 END
    }

    populateCommodityList() {
		/*
		if(this.riskObj.openCover && this.lovDropDownService.lovDataList.commodity && this.wocmpfDataList && this.wocmpfDataList.length > 0){			
			for(let _item of this.wocmpfDataList){
				if(_item.old.WOCMPF.BASE){
					let _listItem = this.commodityCodeList.find((_data)=> _data.VALUE == _item.old.WOCMPF.BASE);
					if(!_listItem){
						let _mocItem = this.lovDropDownService.lovDataList.commodity.find((_data)=> _data.VALUE == _item.old.WOCMPF.BASE);
						this.commodityCodeList.push(_mocItem);
					}
				}
			}
		}
		else {
			this.commodityCodeList = this.lovDropDownService.lovDataList.commodity;
		}
		*/
    }

    populateMOCDefaults() {

        if (this.riskObj.openCover) {
            //defaulting excess type
            let _setExcessType = false;
            if (this.riskObj.conveyance && this.riskObj.scopeOfCover && this.riskObj.shipmentType && this.woclpfDataList && this.woclpfDataList.length > 0) {

                let _lst = this.woclpfDataList.filter((_data) => (_data.old.WOCLPF.CONVEYANCE == this.riskObj.conveyance && _data.old.WOCLPF.SCOPE == this.riskObj.scopeOfCover && _data.old.WOCLPF.SHIPMENT == this.riskObj.shipmentType));

                if (_lst && _lst.length > 0) {
                    let _excessType = _lst[0].old.WOCLPF.EXCESSTYPE;
                    let _excessAmount: any = (_lst[0].old.WOCLPF.EXCESSAMOUNT == null || _lst[0].old.WOCLPF.EXCESSAMOUNT == "") ? 0 : parseFloat("" + _lst[0].old.WOCLPF.EXCESSAMOUNT);
                    let _excessPercentage: any = (_lst[0].old.WOCLPF.EXCESSRATE == null || _lst[0].old.WOCLPF.EXCESSRATE == "") ? 0 : parseFloat("" + _lst[0].old.WOCLPF.EXCESSRATE);
                    if (_excessType) {

                        let _mocExcessType = this.lovDropDownService.lovDataList.excessType.find((_data) => _data.VALUE == _excessType);
                        if (_mocExcessType) {
                            this.riskObj.excessType = _excessType;
                        }
                        else {
                            this.riskObj.excessType = '';
                        }

                        // this.riskObj.excessType = _excessType;
                        this.riskObj.excessPercentage = _excessPercentage;
                        this.riskObj.excessAmount = _excessAmount;
                        _setExcessType = true;
                    }
                }
            }

            if (!_setExcessType) {
                this.riskObj.excessType = '';
                this.riskObj.excessPercentage = 0;
                this.riskObj.excessAmount = 0;
            }

            //defaulting Rates
            let _commodityCode = (this.riskObj.riskCoverageDetails.riskCoverage && this.riskObj.riskCoverageDetails.riskCoverage.length > 0) ? this.riskObj.riskCoverageDetails.riskCoverage[0].commodityDesc : '';
            let _commodityBase = (this.riskObj.riskCoverageDetails.riskCoverage && this.riskObj.riskCoverageDetails.riskCoverage.length > 0) ? this.riskObj.riskCoverageDetails.riskCoverage[0].commodity : '';

			/*let _commodityCode = '';
			if( _commodityBase ){
				let _commItem = this.wocmpfDataList.find((_data)=> _data.old.WOCMPF.BASE == _commodityBase);
				if(_commItem){
					_commodityCode= _commItem.old.WOCMPF.ZCOMDCODE;
				}			
			}*/

            if (this.riskObj.conveyance && this.woclpfDataList && this.woclpfDataList.length > 0) {
                let _lst = this.woclpfDataList.filter((_data) => (_data.old.WOCLPF.COMMODITY == _commodityCode && _data.old.WOCLPF.CONVEYANCE == this.riskObj.conveyance && (_data.old.WOCLPF.SHIPMENT == '' || this.riskObj.shipmentType == _data.old.WOCLPF.SHIPMENT) && (_data.old.WOCLPF.SCOPE == '' || this.riskObj.scopeOfCover == _data.old.WOCLPF.SCOPE)));
                if (!_lst || _lst.length == 0) {
                    _lst = this.woclpfDataList.filter((_data) => (_data.old.WOCLPF.CONVEYANCE == this.riskObj.conveyance && (_data.old.WOCLPF.SHIPMENT == '' || this.riskObj.shipmentType == _data.old.WOCLPF.SHIPMENT) && (_data.old.WOCLPF.SCOPE == '' || this.riskObj.scopeOfCover == _data.old.WOCLPF.SCOPE)));
                }

                //RTRIM(ZCOMDCODE) as COMMODITY, RTRIM(ZCONVCOD) as CONVEYANCE, RTRIM(ZCTRYCODE) as COUNTRY, RATMAR as MARINERATE, RATWAR as WARRATE, RATDUT as DUTYRATE, SEXCPE as EXCESSRATE, SEXCES as EXCESSAMOUNT, SEXTYP as EXCESSTYPE, RTRIM(ZPSCOPE) as SCOPE, RTRIM(SHPMTY) as SHIPMENT, ZCVRGNO as STORAGE, TOTCRE as LIMIT
                if (_lst && _lst.length > 0) {
                    let _marineRate: any = (_lst[0].old.WOCLPF.MARINERATE == null || _lst[0].old.WOCLPF.MARINERATE == "") ? 0 : parseFloat("" + _lst[0].old.WOCLPF.MARINERATE);
                    let _warRate: any = (_lst[0].old.WOCLPF.WARRATE == null || _lst[0].old.WOCLPF.WARRATE == "") ? 0 : parseFloat("" + _lst[0].old.WOCLPF.WARRATE);
                    let _dutyRate: any = (_lst[0].old.WOCLPF.DUTYRATE == null || _lst[0].old.WOCLPF.DUTYRATE == "") ? 0 : parseFloat("" + _lst[0].old.WOCLPF.DUTYRATE);

                    let _excessType: any = (_lst[0].old.WOCLPF.EXCESSTYPE == null || _lst[0].old.WOCLPF.EXCESSTYPE == "") ? '' : _lst[0].old.WOCLPF.EXCESSTYPE;
                    let _excessRate: any = (_lst[0].old.WOCLPF.EXCESSRATE == null || _lst[0].old.WOCLPF.EXCESSRATE == "") ? 0 : parseFloat("" + _lst[0].old.WOCLPF.EXCESSRATE);
                    let _excessAmount: any = (_lst[0].old.WOCLPF.EXCESSAMOUNT == null || _lst[0].old.WOCLPF.EXCESSAMOUNT == "") ? 0 : parseFloat("" + _lst[0].old.WOCLPF.EXCESSAMOUNT);

                    this.riskObj.marineRate = _marineRate;
                    this.riskObj.warSrccRate = _warRate;
                    // this.riskObj.dutyRate = _dutyRate;

                    let _mocExcessType = this.lovDropDownService.lovDataList.excessType.find((_data) => _data.VALUE == _excessType);
                    if (_mocExcessType) {
                        this.riskObj.excessType = _excessType;
                    }
                    else {
                        this.riskObj.excessType = '';
                    }
                    // this.riskObj.excessType = _excessType;
                    this.riskObj.excessPercentage = _excessRate;
                    this.riskObj.excessAmount = _excessAmount;
                }
            }
            else {
                this.riskObj.marineRate = 0;
                this.riskObj.marinePremium = 0;
                this.riskObj.warSrccRate = 0;
                this.riskObj.warSrccPremium = 0;

                //this.riskObj.oAgeVesselRate = 0;
                //this.riskObj.oAgeVesselPremium = 0;
                //this.riskObj.tShipmentRate = 0;
                //this.riskObj.tShipmentPremium = 0;
            }

            //defaulting clauses
            //MCOVER,CLAU,SHPMTY,ZCOMDCODE,ZCONVCOD,ZCTRYCODE,ZPSCOPE,FRMDATE,TODATE		
            if (this.lovDropDownService.lovDataList.mocClauses && this.lovDropDownService.lovDataList.mocClauses.length > 0) {

                let _defaultClause = this.lovDropDownService.lovDataList.mocClauses.filter((_data) => ((!_data.ZCONVCOD || _data.ZCONVCOD == this.riskObj.conveyance) && (!_data.ZPSCOPE || _data.ZPSCOPE == this.riskObj.scopeOfCover) && (!_data.SHPMTY || _data.SHPMTY == this.riskObj.shipmentType)));

                if (_defaultClause && _defaultClause.length > 0) {
                    for (let _clause of _defaultClause) {
                        if (_clause.CLAU)
                            this.addClause(_clause.CLAU);
                    }

                    if (this.riskObj.clauses && this.riskObj.clauses.clause && this.riskObj.clauses.clause.length > 0) {
                        for (let _cls of this.riskObj.clauses.clause) {
                            _cls.isDefaultClause = 'N';
                        }
                    }
                }
            }

        }

        this.resetTotal();
    }

    onMOCChange() {
        this.riskObj.conveyance = '';
        this.riskObj.shipmentType = '';
        this.riskObj.scopeOfCover = '';
        this.riskObj.riRetentionCode = '';

        this.initWOCDPFData();
        this.initWOCLPFData();
        // this.initWOCMPFData();
        this.callbackForConveyanceLoad(this);
        this.callbackForShipmTypeLoad(this);
        this.callbackForScopeCovrLoad(this);
    }

    private onTextChange(ev) {
        if (ev.target.value == ' ') {
            ev.target.value = '';
        }
    }

    validateTextInput(ev) {
        let eVal = ev.target.value;
        ev.target.value = eVal.replace(/\s\s+/g, ' ');
    }

    addXT(coverItem) {
        var dialogData = new ExtraTextDialogData("ExtraTextDialogComponent", "app/bms/components/proposal/newbusinessrisks/dialogs/extratext.dialog.module", "ExtraTextDialogModule", "Extra Text", "ExtraText", "fa fa-comment", coverItem, this.extraTextCallBack);
        this.openExtraTextCommentsDialog(dialogData);
    }

    public openExtraTextCommentsDialog(dialogData: ExtraTextDialogData, response?: any) {
        let lookup = new ModalInput();
        lookup.component = [dialogData.component, dialogData.moduleAbsPath, dialogData.moduleName];
        lookup.datainput = {
            dialogName: dialogData.dialogName,
            areCommentsMandatory: false,
            coverageItem: dialogData.coverageItem
        };
        lookup.outputCallback = dialogData.callBackHandler;
        lookup.parentCompPRMS = {
            comp: this,
            response: response
        };
        lookup.heading = dialogData.dialogTitle;
        lookup.icon = dialogData.icon;
        lookup.containerRef = this.contentArea;
        this.dcl.openLookup(lookup);
    }

    private extraTextCallBack(data, prms) {
        if (data.isDialogCancelled) {
            return;
        } else if (!data.isDialogCancelled && data.coverageItem && data.coverageItem.extraText) {
        }
    }

    onVslTBDChange() {
        if (this.riskObj.vslTBAIndicator == 'Y') {
            this.riskObj.vessel = "TBA";
            this.riskObj.vesselDesc = "To Be Advised";
            if (this.vesselCtrl != null) this.vesselCtrl.setDisable('Y', this.vesselCtrl.comp);

            jQuery(this.el).find("input[id='vesselDesc']").prop("disabled", true);
        }
        else {
            this.riskObj.vessel = "";
            this.riskObj.vesselDesc = "";

            if (this.vesselCtrl != null) this.vesselCtrl.setDisable('N', this.vesselCtrl.comp);

            jQuery(this.el).find("input[id='vesselDesc']").prop("disabled", false);
        }

        if (this.riskObj.openCover && this.riskObj.vesselAge > 0) {
            this.riskObj.vesselAge = 0;
            this.checkReferredRiskConditions();
        }
    }

    onTShipVslTBDChange() {
        if (this.riskObj.tShipVslTBAIndicator == 'Y') {
            this.riskObj.tShipVessel = "TBA";
            this.riskObj.tShipVesselDesc = "To Be Advised";
            if (this.tShipVesselCtrl != null) this.tShipVesselCtrl.setDisable('Y', this.tShipVesselCtrl.comp);

            jQuery(this.el).find("input[id='tShipVesselDesc']").prop("disabled", true);
        }
        else {
            this.riskObj.tShipVessel = "";
            this.riskObj.tShipVesselDesc = "";
            if (this.tShipVesselCtrl != null) this.tShipVesselCtrl.setDisable('N', this.tShipVesselCtrl.comp);

            jQuery(this.el).find("input[id='tShipVesselDesc']").prop("disabled", false);
        }
    }

    onMOCCommodityChange(ev, cover) {
        cover.commodityDesc = ev.value;
        cover.commodity = ev.record.BASE;

        this.populateMOCDefaults();
    }

    onCommodityChange(ev, cover) {
        cover.commodity = ev.value;
        if (cover.originalSI > 0) { //MD001
            this.checkReferredRiskConditions();
        }
    }

    checkReferredRiskConditions() {

        let _reasons = new Reasons();

        if (!(this.riskObj.symRiskClassification == "Declined")) {
            let isReferredRisk = false;
			/*if(this.riskObj.siCurrency){
				let _rec = this.lovDropDownService.lovDataList.currency.find((_data)=> _data.VALUE == this.riskObj.siCurrency);
				
				let _orgRate = numeral(numeral(parseFloat(""+_rec.SCRATE)).format(this.currencyRateFormat)).value();
				let _rate:any = this.riskObj.siRate;
				_rate = (_rate == null || _rate == "") ? 0 : parseFloat(""+_rate);
				if(_orgRate != _rate){
					isReferredRisk = true;
					_reasons.reason.push("SI Rate is modified");
				}
			}
			
			if(this.riskObj.openCover && this.wocdpfData && this.wocdpfData.old){
				let _orgMarkUpRate = this.getSIMarkUpRate();
				if(this.riskObj.markUp != _orgMarkUpRate){
					isReferredRisk = true;
					_reasons.reason.push("Sum Insured Mark Up(%) is modified");
				}
			}*/

            if (this.riskObj.shipmentType && this.shipmntTypesList) {
                let _shipmentRec = this.shipmntTypesList.find((_data) => _data.VALUE == this.riskObj.shipmentType);
                let _ynFlg = _shipmentRec.YNFLAG;
                let _referred = _shipmentRec.ZRFRDRSK;
                let _referredLimit: any = _shipmentRec.ZRFRLMT;
                _referredLimit = (_referredLimit == null || _referredLimit == "") ? 0 : parseFloat("" + _referredLimit);

                //GA001 START
                //if ((_referredLimit > 0 && this.riskObj.totalSI > _referredLimit) || (_referred && _referred == 'Y')) {
                if ((_referredLimit > 0 && this.riskObj.capitalSumInsured > _referredLimit) || (_referred && _referred == 'Y')) {
                    //GA001 END
                    isReferredRisk = true;
                    _reasons.reason.push("Total SI is greater than Shipment Type limit");
                }
            }

            if (this.riskObj.packingCode) {
                let _packCodeRec = this.lovDropDownService.lovDataList.packingCode.find((_data) => _data.VALUE == this.riskObj.packingCode);
                if (_packCodeRec != undefined && _packCodeRec.ZRFRDRSK && _packCodeRec.ZRFRDRSK == 'Y') {//GA001 updated null check
                    isReferredRisk = true;
                    _reasons.reason.push("Marine Packing Code of type Referred is selected");
                }
            }
            if (this.riskObj.toCountryCode) {//MD001
                let _countryCodeRec = this.lovDropDownService.lovDataList.country.find((_data) => _data.VALUE == this.riskObj.toCountryCode);
                //if (_countryCodeRec.ZRFRDRSK && _countryCodeRec.ZRFRDRSK == 'Y') {
                if (_countryCodeRec != undefined && _countryCodeRec.ZRFRDRSK && _countryCodeRec.ZRFRDRSK == 'Y') {//GA001 updated null check
                    isReferredRisk = true;
                    _reasons.reason.push("Marine Area/ Port Code (To-Country) of type Referred is selected");
                }
            }
            if (this.riskObj.fromCountryCode) {//MD001
                let _countryCodeRec = this.lovDropDownService.lovDataList.country.find((_data) => _data.VALUE == this.riskObj.fromCountryCode);
                //if (_countryCodeRec.ZRFRDRSK && _countryCodeRec.ZRFRDRSK == 'Y') {
                if (_countryCodeRec != undefined && _countryCodeRec.ZRFRDRSK && _countryCodeRec.ZRFRDRSK == 'Y') {//GA001 updated null check
                    isReferredRisk = true;
                    _reasons.reason.push("Marine Area/ Port Code (From-Country) of type Referred is selected");
                }
            }
            if (this.riskObj.conveyance) {//MD001				
                let _conveyanceRec = this.lovDropDownService.lovDataList.conveyance.find((_data) => _data.VALUE == this.riskObj.conveyance);
                //if (_conveyanceRec.ZRFRDRSK && _conveyanceRec.ZRFRDRSK == 'Y') {
                if (_conveyanceRec != undefined && _conveyanceRec.ZRFRDRSK && _conveyanceRec.ZRFRDRSK == 'Y') {//GA001 updated null check
                    isReferredRisk = true;
                    _reasons.reason.push("Marine Conveyance Code of type Referred is selected");
                }
            }
            if (this.riskObj.riskCoverageDetails.riskCoverage && this.riskObj.riskCoverageDetails.riskCoverage.length > 0) {
                for (let _cover of this.riskObj.riskCoverageDetails.riskCoverage) {
                    if (_cover.commodity) {
                        let _commdRec = this.lovDropDownService.lovDataList.commodity.find((_data) => _data.VALUE == _cover.commodity);
                        if (_commdRec) {
                            let _referred = _commdRec.ZRFRDRSK;
                            let _referredLimit = _commdRec.ZRFRLMT;
                            _referredLimit = (_referredLimit == null || _referredLimit == "") ? 0 : parseFloat("" + _referredLimit);
                            //GA001 START
                            //if ((_referredLimit > 0 && this.riskObj.totalSI > _referredLimit) || (_referred && _referred == 'Y')) {
                            if ((_referredLimit > 0 && this.riskObj.capitalSumInsured > _referredLimit) || (_referred && _referred == 'Y')) {
                                //GA001 END
                                isReferredRisk = true;
                                _reasons.reason.push("Total SI is greater than selected Commodity limit");
                            }

                        }
                    }
                }
            }

            if (this.riskObj.isReferredFromCountry == "Y") {
                isReferredRisk = true;
                _reasons.reason.push("Selected 'From' Country is not in the MOC Country List");
            }
            if (this.riskObj.isReferredToCountry == "Y") {
                isReferredRisk = true;
                _reasons.reason.push("Selected 'To' Country is not in the MOC Country List");
            }

            if (this.riskObj.openCover && this.riskObj.vessel && ["AA003", "AA004", "AA006", "TBA"].indexOf(this.riskObj.vessel) == -1) {
                if (this.riskObj.vesselAge > 40) {
                    isReferredRisk = true;
                    _reasons.reason.push("Vessel age is greater than 40.");
                }
                else if (this.riskObj.vesselAge == 0) {
                    isReferredRisk = true;
                    _reasons.reason.push("Vessel age is 0.");
                }
            }

            this.riskObj.riskClassificationReasons.reasons = _reasons;

            if (isReferredRisk)
                this.riskObj.symRiskClassification = "Referred";
            else
                this.riskObj.symRiskClassification = "Standard";

            this.handleRiskClassification();
        }

    }

    setRIMethod(val) {

        this.riskObj.RIMethod = (val == "Yes") ? "8" : this.riskObj.RIMethodSys;

        if (this.isUnderWriter == "Y" || val == "Yes")
            this.riskObj.isRIOverWrittenByUW = "Y";
        else if (val == "No") {
            this.riskObj.isRIOverWrittenByUW = "N";
            this.validateSumInsured();
        }
        this._riService.setRI().subscribe();
    }

    handleRiskClassification() {
        if (this.riskObj.symRiskClassification == "Declined")
            this.riskObj.riskClassification = "Declined";
        else if (this.riskObj.symRiskClassification == "Referred" || this.riskObj.riRiskClassification == "Referred")
            this.riskObj.riskClassification = "Referred";
        else
            this.riskObj.riskClassification = "Standard";
        //this.setRiskClassification();//GA001 - commented
        this.emitRiskClass(this);
    }

    setRiskClassification() {
        if (this.riskObj.symRiskClassification != null && this.riskObj.symRiskClassification != "" && (this.riskObj.symRiskClassification == "Referred" || this.riskObj.symRiskClassification == "Declined")) {
            this.riskObj.riskClassificationReason = "System marked as " + this.riskObj.symRiskClassification;
        }
        else if (this.riskObj.riRiskClassification != null && this.riskObj.riRiskClassification != "" && this.riskObj.riRiskClassification == "Referred") {
            this.riskObj.riskClassificationReason = "System marked as " + this.riskObj.riRiskClassification;
        }
        else {
            if (this.riskObj.riskClassificationReason != null && this.riskObj.riskClassificationReason != "" && (this.riskObj.riskClassificationReason != "System marked as Standard" && this.riskObj.riskClassificationReason.indexOf("System marked as ") != -1)) {
                this.riskObj.riskClassificationReason = "";
            }
        }
    }

    setRIMethodEditableFlag() {
        let _capitalSumInsured = parseFloat("" + this.riskObj.capitalSumInsured);
        let _totalGrossCapacity = parseFloat("" + this.riskObj.totalGrossCapacity);
        if (_totalGrossCapacity > 0 && _capitalSumInsured > _totalGrossCapacity && this.isUnderWriter == "N") {
            this.isRIMethodEditable = "N";
        }
        else {
            this.isRIMethodEditable = "Y";
        }
    }

    emitFlagChange() {
        this.onRtngFlgChange.emit("");
    }

    setIdentity(isIdentityChange) {
        if (isIdentityChange == true && (this.riskObj.identityFiller == null || this.riskObj.identityFiller == "")) {
            // if(this.riskObj.situation1 != null){
            // this.riskObj.identity = this.riskObj.situation1.slice(0, 15);
            // this.riskObj.identityFiller = this.riskObj.situation1.slice(0, 15);
            // }
        }
        else {
            // if(isIdentityChange == false && this.riskObj.situation1 != null){
            if (isIdentityChange == false) {
                // this.riskObj.identity = this.riskObj.situation1.slice(0, 15);
                // this.riskObj.identityFiller = this.riskObj.situation1.slice(0, 15);
            }
            else if (this.riskObj.identityFiller != null)
                this.riskObj.identity = this.riskObj.identityFiller.slice(0, 15);
        }
    }

    addClause(clauseCode) {
        let isClausePresent = false;

        if (this.riskObj.clauses && this.riskObj.clauses.clause && this.riskObj.clauses.clause.length > 0) {
            for (let clause of this.riskObj.clauses.clause) {
                if (clause.clauseCode == clauseCode) {
                    isClausePresent = true;
                }
            }
        }

        if (!isClausePresent) {
            this.setClauses([clauseCode], false);
        }

    }

    setClauses(clausesList, flag) {
        if (this.clausesComp)
            this.clausesComp.addClause(clausesList, '', flag);
    }

    getVesselSearchModalInput() {
        let si = new SearchInput();
        si.BRANCH = 'ALL',
            si.LOB = 'MAR';
        si.BUSINESS_FUNCTION = 'ALL';
        si.PRODUCT = 'ALL';
        si.OPERATION = 'ALL';
        si.FORM_NAME = 'ALL';
        si.FORM_FIELD_NAME = 'Vessel Lookup';
        si.FIELD_TYPE = 'LOOKUP';
        si.isSingleSelect = true;

        let input = new ModalInput().get("GenericSearchComponent");
        input.datainput = si;
        input.heading = "Open Vessel Search";
        input.icon = "fa fa-file-pdf-o";
        input.containerRef = this.contentArea;

        return input;
    }

    openVesselLookup() {
        /*let si = new SearchInput();
        si.BRANCH='ALL',
        si.LOB='MAR';
        si.BUSINESS_FUNCTION='ALL';
        si.PRODUCT='ALL';
        si.OPERATION='ALL';
        si.FORM_NAME='ALL';
        si.FORM_FIELD_NAME='Vessel Lookup';
        si.FIELD_TYPE='LOOKUP';
        si.isSingleSelect=true;
		
        let input = new ModalInput().get("GenericSearchComponent");
        input.datainput = si;
        input.heading = "Open Vessel Search";
        input.icon = "fa fa-file-pdf-o";
		input.containerRef = this.contentArea;*/

        let input = this.getVesselSearchModalInput();
        this.dcl.openLookup(input).subscribe((data) => {
            this.setVesselCode(data);
        });
    }

    setVesselCode(resp) {

        if (resp && resp.data && resp.data[0]) {
            let _data = resp.data[0];
            this.riskObj.vessel = _data.old.CMSN.VALUE;
            this.riskObj.vesselDesc = (_data.old.CMSN.DESCRIPTION) ? _data.old.CMSN.DESCRIPTION.slice(0, 35) : "";

            if (this.riskObj.openCover && this.wocdpfData && this.wocdpfData.old) {
                this.riskObj.oAgeVesselRate = 0;
                this.riskObj.vesselAge = 0;
                let ageOfVessel = 0;
                let _year: any = _data.old.CMSN.SNCONB;
                _year = (_year == null || _year == "") ? 0 : parseInt("" + _year);

                if (_year > 0) {
                    let currentYear = Number(new Date().getFullYear());
                    ageOfVessel = currentYear - _year;
                }

                if (ageOfVessel > 0) {
                    this.riskObj.vesselAge = ageOfVessel;
                    let _range1: any = this.wocdpfData.old.WOCDPF.OLDAGERATE1; //16-20
                    let _range2: any = this.wocdpfData.old.WOCDPF.OLDAGERATE2; //21-25
                    let _range3: any = this.wocdpfData.old.WOCDPF.OLDAGERATE3; //26-30
                    let _range4: any = this.wocdpfData.old.WOCDPF.OLDAGERATE4; //31-35
                    let _range5: any = this.wocdpfData.old.WOCDPF.OLDAGERATE5; //36-40

                    _range1 = (_range1 == null || _range1 == "") ? 0 : parseFloat("" + _range1);
                    _range2 = (_range2 == null || _range2 == "") ? 0 : parseFloat("" + _range2);
                    _range3 = (_range3 == null || _range3 == "") ? 0 : parseFloat("" + _range3);
                    _range4 = (_range4 == null || _range4 == "") ? 0 : parseFloat("" + _range4);
                    _range5 = (_range5 == null || _range5 == "") ? 0 : parseFloat("" + _range5);

                    let _oAgeVesselRate = 0;
                    if (_range1 > 0 && ageOfVessel >= 16 && ageOfVessel <= 20) {
                        _oAgeVesselRate = _range1;
                    }
                    else if (_range2 > 0 && ageOfVessel >= 21 && ageOfVessel <= 25) {
                        _oAgeVesselRate = _range2;
                    }
                    else if (_range3 > 0 && ageOfVessel >= 26 && ageOfVessel <= 30) {
                        _oAgeVesselRate = _range3;
                    }
                    else if (_range4 > 0 && ageOfVessel >= 31 && ageOfVessel <= 35) {
                        _oAgeVesselRate = _range4;
                    }
                    else if (_range5 > 0 && ageOfVessel >= 36 && ageOfVessel <= 40) {
                        _oAgeVesselRate = _range5;
                    }

                    if (_oAgeVesselRate > 0) {
                        this.riskObj.oAgeVesselRate = _oAgeVesselRate;
                    }
                }

                this.resetTotal();
            }

        }
    }

    onVesselClear(ev) {
        this.riskObj.vessel = '';
        this.riskObj.vesselDesc = '';
        this.riskObj.vesselAge = 0;
    }

    openTshipmentVesselLookup() {
        let input = this.getVesselSearchModalInput();
        this.dcl.openLookup(input).subscribe((data) => {
            this.setTshipmentVesselCode(data);
        });
    }

    setTshipmentVesselCode(resp) {
        if (resp && resp.data && resp.data[0]) {
            let _data = resp.data[0];
            this.riskObj.tShipVessel = _data.old.CMSN.VALUE;
            this.riskObj.tShipVesselDesc = (_data.old.CMSN.DESCRIPTION) ? _data.old.CMSN.DESCRIPTION.slice(0, 20) : "";

            if (this.riskObj.openCover && this.riskObj.tShipVessel && this.riskObj.tShipVessel != "TBA" && this.wocdpfData && this.wocdpfData.old) {
                if (!(this.riskObj.tShipmentRate > 0)) {
                    let _tShipmentRate: any = (this.wocdpfData.old.WOCDPF.TRANSHIPMENTRATE == null || this.wocdpfData.old.WOCDPF.TRANSHIPMENTRATE == "") ? 0 : parseFloat("" + this.wocdpfData.old.WOCDPF.TRANSHIPMENTRATE);
                    if (_tShipmentRate > 0) {
                        this.riskObj.tShipmentRate = numeral(numeral(_tShipmentRate).format(this.marineRateFormat)).value();
                    }
                }
            }

        }
    }

    onTshipmentVesselClear(ev) {
        this.riskObj.tShipVessel = '';
        this.riskObj.tShipVesselDesc = '';
    }

}
