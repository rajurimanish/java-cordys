import { Clause } from '../../appobjects/clause';
import { DeclarationDetails } from '../../appobjects/declarationDetails';
import { FinancialInterest } from '../../../../../../common/components/financialinterest/appobjects/financialInterest';
import { GSTDetails } from '../../appobjects/gstDetails';
import { AppUtil } from '../../../../../../common/components/utility/apputil/app.util';
import { Survey } from '../../appobjects/survey';
import { NBRisk } from '../../../appobjects/nbrisk';
import { PostedPrem } from '../../../proposalheader/appobjects/postedprem';
import { RiskHelper } from '../../../appobjects/riskhelper';
import { ReferredReason } from '../../../proposalheader/appobjects/referredreason';
import { S4804Validator } from '../../../validation/s4804.validator';

export class S4804 extends RiskHelper implements NBRisk {
    public sequenceNumber: string;
    public effectiveDate: string;
    public dateOfAttachment: string;
    public contractNumber: string;
    public contractType: string;
    public riskNumber: string;
    public riskType: string;
    public riskName: string;
    public ratingFlag: string = "A";
    public openCover: string = "";
    public vessel: string;
    public vesselDesc: string;
    public vslTBAIndicator: string = "N";
    public vesselType: string;
    public fromCountryCode: string;
    public voyageFrom: string;
    // public fromCountryDesc: string;
    public toCountryCode: string;

    public isReferredFromCountry: string = "N";
    public isReferredToCountry: string = "N";

    public voyageTo: string;
    public areaOrPortCode: string;
    public areaOrPortLocation: string;
    public voyNo: string;
    public conveyance: string;
    public conveyanceDesc: string;
    public tShipVessel: string;
    public tShipVesselDesc: string;
    public tShipVslTBAIndicator: string = "N";
    public tShipAt: string;
    public etd: string;
    public shipmentType: string;
    public shipmentTypeDesc: string;
    public surveyAgent: string;
    public settlingAgent: string;
    public scopeOfCover: string;
    public awbOrBl: string;
    public lcNo: string;
    public claimCurrency: string = "RM";
    public ciRef: string;
    public riRetentionCode: string;
    public excessType: string = "";
    public excessPercentage: number;
    public excessAmount: number;
    public siCurrency: string = "RM";
    public siRate: number = 1;
    public invoice: string;
    public packingCode: string;
    public assuredClient: string;
    public cargoType: string;
    public duty: number = 0;
    public dutyRate: number = 0;
    public dutyPremium: number = 0;
    public markUp: number = 0;
    public totalCoverOriginalSI: number = 0;
    public totalCoverConvertedSI: number = 0;
    // public totalGoods: number=0;
    public totalGoodsOriginalSI: number = 0;
    public totalGoodsConvertedSI: number = 0;
    public totalOriginalSI: number = 0;
    public totalConvertedSI: number = 0;
    public premiumClass: string;
    public marineRate: number = 0;
    public marinePremium: number = 0;
    public warSrccRate: number = 0;
    public warSrccPremium: number = 0;
    public oAgeVesselRate: number = 0;
    public oAgeVesselPremium: number = 0;
    public tShipmentRate: number = 0;
    public tShipmentPremium: number = 0;

    public minimumPremium: number = 0;
    public originalTotalPremium: number = 0;
    public postedPremium: number = 0;
    public basePostedPremiumAdj: number = 0;
    public discountedPremium: number = 0;
    public grossPremium: number = 0;
    public totalPremium: number = 0;
    public capitalSumInsured: number = 0;
    public relatedSumInsured: number = 0;
    public totalGrossCapacity: number = 0;
    public totalSI: number = 0;
    public GST: number = 0;
    public gstAmount: number = 0;
    public rebate: number = 0;
    public rebateAmount: number = 0;

    public riskCoverageDetails: RiskCoverageDetails;
    public shipmentTypeDetails: ShipmentTypeDetails;
    public declarationMonthDetails: DeclarationMonthDetails;
    public clauses: Clause;
    public survey: Survey;
    public financialInterest: FinancialInterest;
    public GSTDetails: GSTDetails;

    public riskClassification: string = "Standard";
    public riskClassificationReason: string = "";
    public symRiskClassification: string = "";
    public riRiskClassification: string = "Standard";
    public RIMethod: string = "0";
    public RIMethodSys: string = "0";
    public RIRequired: string = "No";
    public isRIOverWrittenByUW: string = "N";
    public isSurveyNeeded: string = "N";
    public addRelatedCases: string = "N";
    public hasClaimExperience: string = "N";
    public GT: string;
    public GP: string;
    public FI: string = 'N';
    public DS: string;
    public CL: string;
    public MI: string;
    public isLeastPreferred: string = "N";
    public isPOIConsidered: string = "Y";
    public priority: string;
    public postedPremDetails: PostedPrem;

    public gpText: string;
    public gpTextCount:string;//VK004
    public identity: string = "";
    public identityFiller: string = "";

    public childRiskPath: string;
    public childRiskIdentity: string;
    public riskClassificationReasons: ReferredReason;

    public vesselAge: number = 0;

    public SST: number = 0; //SST Code
    public sstAmount: number = 0;//SST Code
    public SSTLiveDate: string;//SST Code
    public GSTLiveDate: string;//SST Code
    public isGSTApplicable: boolean = true;//SST Code
    constructor() {
        super();
        this.riskCoverageDetails = new RiskCoverageDetails();
        this.shipmentTypeDetails = new ShipmentTypeDetails();
        this.declarationMonthDetails = new DeclarationMonthDetails();
        this.clauses = new Clause();
        this.financialInterest = new FinancialInterest();
        this.GSTDetails = new GSTDetails();
        this.riskClassificationReasons = new ReferredReason();
    }

    public getInstance(valObj: S4804) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
            this.riskCoverageDetails = new RiskCoverageDetails().getInstance(valObj.riskCoverageDetails);
            this.shipmentTypeDetails = new ShipmentTypeDetails().getInstance(valObj.shipmentTypeDetails);
            this.declarationMonthDetails = new DeclarationMonthDetails().getInstance(valObj.declarationMonthDetails);
            this.clauses = new Clause().getInstance(valObj.clauses);
            if (valObj.FI == "Y") {
                this.financialInterest = new FinancialInterest().getInstance(valObj.financialInterest);
            }
            if (valObj.isSurveyNeeded == "Y") {
                this.survey = new Survey().getInstance(valObj.survey);
            }
            this.GSTDetails = new GSTDetails().getInstance(valObj.GSTDetails);
            this.riskClassificationReasons.refresh(valObj.riskClassificationReasons);
            if (valObj.isGSTApplicable != undefined && JSON.stringify(valObj.isGSTApplicable) != JSON.stringify("") && typeof (valObj.isGSTApplicable) == "string") {
                this.isGSTApplicable = Boolean(JSON.parse(valObj.isGSTApplicable));
            }
        }
        return this;
    }

    public getNewInstanceByCriteria(criteria: any) {
        let riskType = criteria.riskType;
        if (riskType == "MAR") {
            this.premiumClass = "24";
        }
        else if (riskType == "MCA") {
            // this.vessel="Land";
            this.vesselType = "61";
            this.fromCountryCode = "MY";
            this.toCountryCode = "MY";
            this.areaOrPortCode = "MY";
            this.conveyance = "ROAD";
            this.shipmentType = "IT";
            this.scopeOfCover = "16";
            this.riRetentionCode = "MC4";
            this.cargoType = "01";
            this.premiumClass = "23";
        }

        return this;
    }

    public getValidator() {
        return new S4804Validator(this);
    }

}

export class RiskCoverageDetails {

    public riskCoverage: RiskCoverage[] = [];

    public getInstance(valObj: RiskCoverageDetails) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
            new AppUtil().handleArray(this, valObj, "riskCoverage");
        }
        return this;
    }
}

export class RiskCoverage {
    public seqNumber: number;
    public interestInsured: string;
    public commodity: string;
    public commodityDesc: string;//for MOC
    public originalSI: number = 0;
    public convertedSI: number = 0;
    public extraText: string = "";
    public etPostingStatus = "N";

    constructor() {
    }

    public getInstance(valObj: RiskCoverage) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
        }
        return this;
    }
}

export class ShipmentTypeDetails {
    public shipmentType: ShipmentType[] = [];
    public totalSumInsured: number;
    public totalGrossPremium: number;
    public totalServiceTax: number;
    public totalNetPremium: number;

    public getInstance(valObj: ShipmentTypeDetails) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
            new AppUtil().handleArray(this, valObj, "shipmentType");
        }
        return this;
    }
}

export class ShipmentType {
    public shipmentType: string;
    public sumInsured: number;
    public grossPremium: number;
    public serviceTax: number;
    public netPremium: number;

    public getInstance(valObj: ShipmentType) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
        }
        return this;
    }
}

export class DeclarationMonthDetails {
    public declarationMonth: DeclarationMonth[] = [];
    public totalSI: number = 0;
    public totalPremium: number = 0;

    public getInstance(valObj: DeclarationMonthDetails) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
            new AppUtil().handleArray(this, valObj, "declarationMonth");
        }
        return this;
    }
}

export class DeclarationMonth {
    public seqNumber: number;
    public month: string;
    public year: string;
    public sumInsured: number = 0;
    public orgPremium: number = 0;

    public getInstance(valObj: DeclarationMonth) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
        }
        return this;
    }
}
