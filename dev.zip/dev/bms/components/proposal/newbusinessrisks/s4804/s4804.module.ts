import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BasicUIModule } from '../../../../../common/components/utility/basicui.module';
import { FIModule } from '../../../../../common/components/financialinterest/fi.module';
import { LovModule } from "../../../../../common/services/lovdropdown/lov.module";
import { SurveyModule } from '../uimodules/survey.module';
import { ClausesModule } from '../uimodules/clauses.module';
import { GSTModule } from '../uimodules/gst.module';
import { PaginationModule } from '../../../../../common/components/utility/pagination/pagination.module';
import { GeneralPageModule } from '../uimodules/generalpage.module'; //VK004

import { S4804Component } from './s4804.component';

@NgModule({
    imports: [
        CommonModule, FormsModule, ReactiveFormsModule,
        BasicUIModule, FIModule, LovModule,
        ClausesModule, GSTModule, SurveyModule, PaginationModule, GeneralPageModule ],
    declarations: [S4804Component],
    exports: [S4804Component]
})
export class S4804Module { }