import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BasicUIModule } from '../../../../../common/components/utility/basicui.module';
import { GeneralPageComponent } from './generalpage.component'

@NgModule({
    imports: [CommonModule, FormsModule, ReactiveFormsModule, BasicUIModule],
    declarations: [ GeneralPageComponent ],
    exports: [GeneralPageComponent ]
})
export class GeneralPageModule { }