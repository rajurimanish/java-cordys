import { Component, OnInit } from '@angular/core';
import { PremiumPosting } from '../appobjects/premiumPosting';
import { LOV_Field, LOVDropDownService, SearchFilter } from "../../../../../common/services/lovdropdown/lovdropdown.service";
import { GetLOVData, SearchAdvancedConfig, Filter } from '../../../../../common/components/utility/search/search.requests';
import { DCLInput, CustomDCLService } from '../../../../../common/services/customdcl.service';
import { CordysSoapWService } from "../../../../../common/components/utility/cordys-soap-ws";
import { AlertMessagesService } from '../../../../../common/components/utility/alertmessage/alertmessages.service';
import { AlertMessage } from '../../../../../common/components/utility/alertmessage/alertmessages.model';

declare var moment: any;

@Component({
    selector: 'premium-posting-component',
    templateUrl: 'app/bms/components/proposal/newbusinessrisks/uimodules/premiumposting.template.html',
    inputs: ['riskType', 'riskNo', 'policyNo', 'effectiveDate']
})

export class PremiumPostingComponent implements OnInit {
    private isCollapsedMode: boolean = false;

    private riskType: string;
    private riskNo: string;
    private policyNo: string;
    private effectiveDate: string;
    private premiumClass: string;
    private premPostingObj: PremiumPosting;

    constructor(public dcl: CustomDCLService, private lovDropDownService: LOVDropDownService, public _alertMsgService: AlertMessagesService, private _soapService: CordysSoapWService) { }

    ngOnInit() {
        this.effectiveDate = moment(this.effectiveDate, "YYYY-MM-DD").format("YYYYMMDD");
        this.premPostingObj = new PremiumPosting();
        this.getPremiumClass();
        //this.getPremiumPostedInfo();
    }

    private getPremiumClass(): void {
        let request: GetLOVData = new GetLOVData();
        request.BRANCH = 'ALL';
        request.LOB = 'FIRE';
        request.BUSINESS_FUNCTION = 'NEW BUSINESS';
        request.PRODUCT = 'ALL';
        request.OPERATION = 'NEW';
        request.FORM_NAME = 'FIRE_IDC';
        request.FORM_FIELD_NAME = 'PremiumClass';
        request.FIELD_TYPE = 'LOV';
        request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        request.ADVANCE_CONFIG_XML.FILTERS = new Filter();
        request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({ "@FIELD_NAME": 'RSKTYPE', "@FIELD_VALUE": this.riskType, '@OPERATION': 'EQ', '@CONDITION': 'AND' },
            { "@FIELD_NAME": 'DESCITEM', "@FIELD_VALUE": this.riskType, '@OPERATION': 'EQ', '@CONDITION': 'AND' });
        this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.premiumClassSuccessHandler, this.handleError, false, { comp: this });
    }

    premiumClassSuccessHandler(response, prms) {
        let ary = [];

        if (response.tuple != null && !Array.prototype.isPrototypeOf(response.tuple)) {
            ary = [response.tuple];
        }
        else if (response.tuple != null) {
            ary = response.tuple;
        }

        for (let item of ary) {
            prms.comp.premiumClass = item.old.T4688.VALUE;
            prms.comp.getPremiumPostedInfo();
        }
    }

    getPremiumPostedInfo() {
        let request: GetLOVData = new GetLOVData();
        request.BRANCH = 'ALL';
        request.LOB = 'ALL';
        request.BUSINESS_FUNCTION = 'NEW BUSINESS';
        request.PRODUCT = 'ALL';
        request.OPERATION = 'NEW';
        request.FORM_NAME = 'PREMIUM_POSTING';
        request.FORM_FIELD_NAME = 'Premium Posting Info';
        request.FIELD_TYPE = 'LOV';
        request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        request.ADVANCE_CONFIG_XML.FILTERS = new Filter();
        request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({ "@FIELD_NAME": 'CHDRNO', "@FIELD_VALUE": this.policyNo, '@OPERATION': 'EQ', '@CONDITION': 'AND' },
            { "@FIELD_NAME": 'DTEEFF', "@FIELD_VALUE": this.effectiveDate, '@OPERATION': 'EQ', '@CONDITION': 'AND' },
            { "@FIELD_NAME": 'RSKNO', "@FIELD_VALUE": this.riskNo, '@OPERATION': 'EQ', '@CONDITION': 'AND' },
            { "@FIELD_NAME": 'PREMCL', "@FIELD_VALUE": this.premiumClass, '@OPERATION': 'EQ', '@CONDITION': 'AND' });
        this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.premiumPostingSuccessHandler, this.handleError, false, { comp: this });
    }

    premiumPostingSuccessHandler(response, prms) {
        if (response.tuple) {
            prms.comp.premPostingObj.annualGrossPremium = Number(prms.comp.premPostingObj.annualGrossPremium) + Number(response.tuple.old.PREMPF.A_GROSS_PREMIUM);
            prms.comp.premPostingObj.annualStampDuty = Number(prms.comp.premPostingObj.annualStampDuty) + Number(response.tuple.old.PREMPF.A_STAMP_DUTY);
            prms.comp.premPostingObj.annualDiscount = Number(prms.comp.premPostingObj.annualDiscount) + Number(response.tuple.old.PREMPF.A_DISCOUNT);
            prms.comp.premPostingObj.annualCommission = Number(prms.comp.premPostingObj.annualCommission) + Number(response.tuple.old.PREMPF.A_COMISSION);
            prms.comp.premPostingObj.annualOverridingCommission = Number(prms.comp.premPostingObj.annualOverridingCommission) + Number(response.tuple.old.PREMPF.A_OVERRIDING_COMISSION);
            prms.comp.premPostingObj.annualNetPremium = Number(prms.comp.premPostingObj.annualNetPremium) + Number(response.tuple.old.PREMPF.A_NET_PREMIUM);
            prms.comp.premPostingObj.annualServiceTax = Number(prms.comp.premPostingObj.annualServiceTax) + Number(response.tuple.old.PREMPF.A_SERVICE_TAX);
            prms.comp.premPostingObj.annualBankCharges = Number(prms.comp.premPostingObj.annualBankCharges) + Number(response.tuple.old.PREMPF.A_BANK_CHARGES);
            prms.comp.premPostingObj.annualIGSFLevy = Number(prms.comp.premPostingObj.annualIGSFLevy) + Number(response.tuple.old.PREMPF.A_IGSF_LEVY);
            prms.comp.premPostingObj.annualServiceCharge = Number(prms.comp.premPostingObj.annualServiceCharge) + Number(response.tuple.old.PREMPF.A_SERVICE_CHARGE);
            prms.comp.premPostingObj.annualgstOnCommission = Number(prms.comp.premPostingObj.annualgstOnCommission) + Number(response.tuple.old.PREMPF.A_GST_ON_COMISSION);
            prms.comp.premPostingObj.annualgstOnOverridingCommission = Number(prms.comp.premPostingObj.annualgstOnOverridingCommission) + Number(response.tuple.old.PREMPF.A_GST_ON_OVERRIDING_COMISSION);
            prms.comp.premPostingObj.annualgstOnPremium = Number(prms.comp.premPostingObj.annualgstOnPremium) + Number(response.tuple.old.PREMPF.A_GST_ON_PREMIUM);
            prms.comp.premPostingObj.annualgstOnServiceCharge = Number(prms.comp.premPostingObj.annualgstOnServiceCharge) + Number(response.tuple.old.PREMPF.A_GST_ON_SERVICE_CHARGE);
            prms.comp.premPostingObj.annualgstOnBankCharges = Number(prms.comp.premPostingObj.annualgstOnBankCharges) + Number(response.tuple.old.PREMPF.A_GST_ON_BANK_CHARGES);
            prms.comp.premPostingObj.annualgstOnPremiumAbs = Number(prms.comp.premPostingObj.annualgstOnPremiumAbs) + Number(response.tuple.old.PREMPF.A_GST_ON_PREMIUM_ABSORBED);
            prms.comp.premPostingObj.annualPremiumNoGST = Number(prms.comp.premPostingObj.annualPremiumNoGST) + Number(response.tuple.old.PREMPF.A_PREMIUM_NO_GST);
            prms.comp.premPostingObj.annualPremiumGST = Number(prms.comp.premPostingObj.annualPremiumGST) + Number(response.tuple.old.PREMPF.A_PREMIUM_GST);
            prms.comp.premPostingObj.postedGrossPremium = Number(prms.comp.premPostingObj.postedGrossPremium) + Number(response.tuple.old.PREMPF.P_GROSS_PREMIUM);
            prms.comp.premPostingObj.postedStampDuty = Number(prms.comp.premPostingObj.postedStampDuty) + Number(response.tuple.old.PREMPF.P_STAMP_DUTY);
            prms.comp.premPostingObj.postedDiscount = Number(prms.comp.premPostingObj.postedDiscount) + Number(response.tuple.old.PREMPF.P_DISCOUNT);
            prms.comp.premPostingObj.postedCommission = Number(prms.comp.premPostingObj.postedCommission) + Number(response.tuple.old.PREMPF.P_COMISSION);
            prms.comp.premPostingObj.postedOverridingCommission = Number(prms.comp.premPostingObj.postedOverridingCommission) + Number(response.tuple.old.PREMPF.P_OVERRIDING_COMISSION);
            prms.comp.premPostingObj.postedNetPremium = Number(prms.comp.premPostingObj.postedNetPremium) + Number(response.tuple.old.PREMPF.P_NET_PREMIUM);
            prms.comp.premPostingObj.postedServiceTax = Number(prms.comp.premPostingObj.postedServiceTax) + Number(response.tuple.old.PREMPF.P_SERVICE_TAX);
            prms.comp.premPostingObj.postedBankCharges = Number(prms.comp.premPostingObj.postedBankCharges) + Number(response.tuple.old.PREMPF.P_BANK_CHARGES);
            prms.comp.premPostingObj.postedIGSFLevy = Number(prms.comp.premPostingObj.postedIGSFLevy) + Number(response.tuple.old.PREMPF.P_IGSF_LEVY);
            prms.comp.premPostingObj.postedServiceCharge = Number(prms.comp.premPostingObj.postedServiceCharge) + Number(response.tuple.old.PREMPF.P_SERVICE_CHARGE);
            prms.comp.premPostingObj.postedgstOnCommission = Number(prms.comp.premPostingObj.postedgstOnCommission) + Number(response.tuple.old.PREMPF.P_GST_ON_COMISSION);
            prms.comp.premPostingObj.postedgstOnOverridingCommission = Number(prms.comp.premPostingObj.postedgstOnOverridingCommission) + Number(response.tuple.old.PREMPF.P_GST_ON_OVERRIDING_COMISSION);
            prms.comp.premPostingObj.postedgstOnPremium = Number(prms.comp.premPostingObj.postedgstOnPremium) + Number(response.tuple.old.PREMPF.P_GST_ON_PREMIUM);
            prms.comp.premPostingObj.postedgstOnServiceCharge = Number(prms.comp.premPostingObj.postedgstOnServiceCharge) + Number(response.tuple.old.PREMPF.P_GST_ON_SERVICE_CHARGE);
            prms.comp.premPostingObj.postedgstOnBankCharges = Number(prms.comp.premPostingObj.postedgstOnBankCharges) + Number(response.tuple.old.PREMPF.P_GST_ON_BANK_CHARGES);
            prms.comp.premPostingObj.postedgstOnPremiumAbs = Number(prms.comp.premPostingObj.postedgstOnPremiumAbs) + Number(response.tuple.old.PREMPF.P_GST_ON_PREMIUM_ABSORBED);
            prms.comp.premPostingObj.postedPremiumNoGST = Number(prms.comp.premPostingObj.postedPremiumNoGST) + Number(response.tuple.old.PREMPF.P_PREMIUM_NO_GST);
            prms.comp.premPostingObj.postedPremiumGST = Number(prms.comp.premPostingObj.postedPremiumGST) + Number(response.tuple.old.PREMPF.P_PREMIUM_GST);
            prms.comp.premPostingObj.stampDutyMethod = response.tuple.old.PREMPF.STAMP_DUTY_METHOD;
            prms.comp.premPostingObj.serviceTaxMethod = response.tuple.old.PREMPF.SERVICE_TAX_METHOD;
            prms.comp.premPostingObj.bankChargesMethod = response.tuple.old.PREMPF.BANK_CHARGES_METHOD;
            prms.comp.premPostingObj.igsfLevyMethod = response.tuple.old.PREMPF.IGSF_LEVY_METHOD;
            prms.comp.premPostingObj.scMethod = response.tuple.old.PREMPF.SC_METHOD;
            prms.comp.premPostingObj.gstMethod = response.tuple.old.PREMPF.GST_METHOD;
            prms.comp.premPostingObj.scGstMethod = response.tuple.old.PREMPF.SC_GST_METHOD;
            prms.comp.premPostingObj.bcGstMethod = response.tuple.old.PREMPF.BC_GST_METHOD;
            prms.comp.premPostingObj.commGstMethod = response.tuple.old.PREMPF.COMM_GST_METHOD;
            prms.comp.premPostingObj.orCommGstMethod = response.tuple.old.PREMPF.OR_COMM_GST_METHOD;
            prms.comp.premPostingObj.transCode = response.tuple.old.PREMPF.TRANS_CODE;
            prms.comp.premPostingObj.surcharge = Number(prms.comp.premPostingObj.surcharge) + Number(response.tuple.old.PREMPF.SURCHARGE);
            prms.comp.premPostingObj.directDiscount = Number(prms.comp.premPostingObj.directDiscount) + Number(response.tuple.old.PREMPF.DIRECT_DISCOUNT);
            prms.comp.premPostingObj.brokerDiscount = Number(prms.comp.premPostingObj.brokerDiscount) + Number(response.tuple.old.PREMPF.BROKER_DISCOUNT);
            prms.comp.premPostingObj.discount = Number(prms.comp.premPostingObj.discount) + Number(response.tuple.old.PREMPF.DISCOUNT);
        }
        prms.comp.calculatePremiumDue();
    }

    handleError(response, status, errorText, prms) {
        prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, response.responseJSON.faultstring.text, -1));
    }

    calculatePremiumDue() {
        this.premPostingObj.annualPremiumDue = Number(this.premPostingObj.annualGrossPremium) + Number(this.premPostingObj.annualStampDuty) + Number(this.premPostingObj.annualgstOnPremium) +
            Number(this.premPostingObj.annualBankCharges) + Number(this.premPostingObj.annualServiceTax) + Number(this.premPostingObj.annualgstOnBankCharges) +
            Number(this.premPostingObj.annualServiceCharge) + Number(this.premPostingObj.annualgstOnServiceCharge) + Number(this.premPostingObj.annualIGSFLevy);
        this.premPostingObj.postedPremiumDue = Number(this.premPostingObj.postedGrossPremium) + Number(this.premPostingObj.postedStampDuty) + Number(this.premPostingObj.postedgstOnPremium) +
            Number(this.premPostingObj.postedBankCharges) + Number(this.premPostingObj.postedServiceTax) + Number(this.premPostingObj.postedgstOnBankCharges) +
            Number(this.premPostingObj.postedServiceCharge) + Number(this.premPostingObj.postedgstOnServiceCharge) + Number(this.premPostingObj.postedIGSFLevy);
    }

}