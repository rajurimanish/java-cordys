/*
*  Change History	:
*
*	No      Date           Description                          Changed By
*	====    ==========     ===========                          ==========
*   VK002   18/10/2018     REDMine Ticket #1920                   VKR
*
*   E1003   19/12/2018   MYS-2017-1096 : New default clauses for MIS channel       SRE1
*   GA001   07/01/2018   MYS-2018-0808 : Unable to remove �Third Party Fire� clauses 
                         for Comprehensive Coverage (Motor)       KGA
*   Ku001   30/05/2019   MYS-2019-0520 - New vehicle Class PF     DKU
*    YPK001 23/09/2019   MYS-2019-0675 Document Validation for Co-outwards            PKU1
*                        case before sending to PPHO		
*
*/

import { Component, OnInit, ViewChild, ViewContainerRef } from '@angular/core';
import { AlertMessage } from '../../../../../common/components/utility/alertmessage/alertmessages.model';
import { AlertMessagesService } from '../../../../../common/components/utility/alertmessage/alertmessages.service';
import { CordysSoapWService } from "../../../../../common/components/utility/cordys-soap-ws";
import { ModalInput } from '../../../../../common/components/utility/modal/modal';
import { SearchInput } from "../../../../../common/components/utility/search/genericsearch";
import { Filter, GetLOVData, SearchAdvancedConfig } from '../../../../../common/components/utility/search/search.requests';
import { CustomDCLService } from '../../../../../common/services/customdcl.service';
import { LOVDropDownService } from "../../../../../common/services/lovdropdown/lovdropdown.service";
import { BMSConstants } from '../../../common/constants/bms_constants';
import { Clause } from "../appobjects/clause";
import { ProposalHeader } from '../../proposalheader/appobjects/proposalheader';
import { COInsurance } from '../../../../../common/components/coinsurance/appobjects/coinsurance';

declare var jQuery: any;
declare var moment: any; //VK002B

@Component({
    selector: 'clauses-component',
    templateUrl: 'app/bms/components/proposal/newbusinessrisks/uimodules/clauses.template.html',
    inputs: ['riskCode', '_clauses', 'defaultClauseCode', 'exsType', 'isAssessment','riskNo']

})

export class ClausesComponent implements OnInit {

    @ViewChild('clauses', { read: ViewContainerRef }) contentArea: ViewContainerRef;

    public _clauses: Clause;
    public _selectedClauses: Clause = new Clause();
    public _defaultClauses: Clause = new Clause();
    public _defaultProductClauses = new Clause(); // E1003
    public riskCode: string;
    public defaultClauseCode: string;
    public exsType: string;
    public isAssessment: boolean;
    public effectiveDate: string; // SAF MYS-2018-1249
    public headerInfo: ProposalHeader;// SAF MYS-2018-1249
    public riskNo: any;

    constructor(public dcl: CustomDCLService, private lovDropDownService: LOVDropDownService, private _soapService: CordysSoapWService, public _alertMsgService: AlertMessagesService) { }

    ngOnInit() {
        //this.handleSingleRecord();
        if (this._clauses.clause.length == 0 && this.defaultClauseCode != undefined && this.defaultClauseCode != "") this.setDefaultClause(this.defaultClauseCode);
        this.updateRiskCode();
        this.updateClauses();
        if (this.isAssessment == undefined) {
            this.isAssessment = true;
        }
        // SAF MYS-2018-1249 start
        this.headerInfo = BMSConstants.getBMSHeaderInfo();
        this.effectiveDate = this.headerInfo.effectiveDate;
        //End
    }

    updateClauses() {
        if (this._clauses.clause.length !== 0) {
            this._defaultClauses.clause = this._clauses.clause.filter((item) => item.isDefaultClause == "Y");
            this._selectedClauses.clause = this._clauses.clause.filter((item) => item.isDefaultClause == undefined);
            this._defaultProductClauses.clause = this._clauses.clause.filter((item) => item.isDefaultClause == "N");// E1003
        }
    }

    handleSingleRecord() {
        if (!Array.prototype.isPrototypeOf(this._clauses.clause)) {
            let tempAry: any = this._clauses.clause;
            this._clauses.clause = [tempAry];
        }
    }

    updateRiskCode() {
        while (this.riskCode != undefined && this.riskCode.length < 3) {
            this.riskCode = this.riskCode + " ";
        }
    }

    addClauseCallback(listOfClauses, prms) {
        prms.comp._selectedClauses.clause = [];
        for (let clause of listOfClauses) {
            if (!prms.comp._selectedClauses.clause)
                prms.comp._selectedClauses.clause = [];
            if (prms.comp.validClause(clause.old.T4997.CLAUSECODE, "clauseCode", prms.comp._clauses.clause)) {
                prms.comp._selectedClauses.clause.push({
                    "clauseCode": clause.old.T4997.CLAUSECODE,
                    "description": clause.old.T4997.LONGDESC
                });
                prms.comp.getFinalClauses(prms.comp);
            }
        }

    }

    validClause(clauseCode, prop, ary) {
        if (ary) {
            for (let eachItem of ary) {
                if (eachItem[prop] != null && eachItem[prop] != "" && eachItem[prop] == clauseCode)
                    return false;
            }
        }
        return true;
    }

    addClause(listOfClauseCode, excessType, excessTypeCheck) {
        if (excessTypeCheck) {
            if (excessType == 'A') {
                this.removeOtherClauses(this._selectedClauses.clause, "clauseCode", "E2");
                this.removeOtherClauses(this._defaultClauses.clause, "clauseCode", "E2");
            }
            else if (excessType == 'D') {
                this.removeOtherClauses(this._selectedClauses.clause, "clauseCode", "E1");
                this.removeOtherClauses(this._defaultClauses.clause, "clauseCode", "E1");
            }
            else {
                this.removeOtherClauses(this._selectedClauses.clause, "clauseCode", "E2");
                this.removeOtherClauses(this._selectedClauses.clause, "clauseCode", "E1");
                this.removeOtherClauses(this._defaultClauses.clause, "clauseCode", "E2");
                this.removeOtherClauses(this._defaultClauses.clause, "clauseCode", "E1");
                this.getFinalClauses(this);
            }
        }
        for (let clauseCode of listOfClauseCode) {
            if ( !this._defaultClauses.clause ) 
                this._defaultClauses.clause = [];
            this.seClausesInfo(this, clauseCode);
            this.getFinalClauses(this);
        }
    }

    openClausesDetailsDialog() {
        let searchInput = new SearchInput();
        searchInput.isSingleSelect = false;
        searchInput.BRANCH = 'ALL';
        searchInput.BUSINESS_FUNCTION = 'ALL';
        searchInput.FIELD_TYPE = 'LOOKUP';
        searchInput.FORM_FIELD_NAME = 'PrimaryClause';
        searchInput.FORM_NAME = 'ALL';
        searchInput.LOB = 'ALL';
        searchInput.OPERATION = 'ALL';
        searchInput.PRODUCT = 'ALL';

        if (this._clauses.clause.length > 0) {
            let newArr = [];
            for (let item of this._clauses.clause) {
                newArr = newArr.concat(item["clauseCode"]);
            }
            //KU001 - Start
            if (this.headerInfo.contractType == "MPC") {
                let vehicleTypeObj = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.risks.motorMPV[0];
                if (vehicleTypeObj != "" && vehicleTypeObj != undefined && vehicleTypeObj.vehicalClass != "PF") {
                    newArr.push('M018');
                }
            }
            //KU001 - End
            let clauseCodes = "'" + newArr.toString().replace(/,/g, "\',\'") + "'";
            searchInput.condition = { "D.DESCITEM": this.riskCode, "SUBSTRING(D.DESCITEM,4,4)": clauseCodes };
        }
        else
            searchInput.condition = { "D.DESCITEM": this.riskCode, "SUBSTRING(D.DESCITEM,4,4)": "''" };

        let input = new ModalInput();
        input = input.get("GenericSearchComponent");
        input.datainput = searchInput;
        input.outputCallback = this.addClauseCallback;
        input.parentCompPRMS = { comp: this };
        input.heading = "Clauses Details";
        input.icon = "fa fa-link";
        input.containerRef = this.contentArea;
        this.dcl.openLookup(input);
    }

    viewSubClause(clause) {
        let searchInput = new SearchInput();
        searchInput.isSingleSelect = false;
        searchInput.BRANCH = 'ALL';
        searchInput.BUSINESS_FUNCTION = 'ALL';
        searchInput.FIELD_TYPE = 'LOOKUP';
        searchInput.FORM_FIELD_NAME = 'SubClause';
        searchInput.FORM_NAME = 'ALL';
        searchInput.LOB = 'ALL';
        searchInput.OPERATION = 'ALL';
        searchInput.PRODUCT = 'ALL';
        while (clause.clauseCode && clause.clauseCode.length < 4) {
            clause.clauseCode = clause.clauseCode + " ";
        }
        searchInput.condition = { "D.DESCITEM": this.riskCode + "" + clause.clauseCode, "SUBSTRING(D.DESCITEM,4,5)": clause.clauseCode };

        let input = new ModalInput();
        input = input.get("GenericSearchComponent");
        input.datainput = searchInput;
        input.parentCompPRMS = { comp: this };
        input.heading = "SubClauses Details";
        input.icon = "fa fa-link";
        input.containerRef = this.contentArea;
        this.dcl.openLookup(input);
    }
    //VK002
    // VK002 START
    viewClauseWordings(clause) {
        let request: GetLOVData = new GetLOVData();
        request.BRANCH = 'ALL';
        request.LOB = 'ALL';
        request.BUSINESS_FUNCTION = 'ALL';
        request.PRODUCT = 'ALL';
        request.OPERATION = 'ALL';
        request.FORM_NAME = 'ALL';
        request.FORM_FIELD_NAME = 'SubClauses';
        request.FIELD_TYPE = 'LOOKUP';
        request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        request.ADVANCE_CONFIG_XML.FILTERS = new Filter();
        while (clause.clauseCode && clause.clauseCode.length < 4) {
            clause.clauseCode = clause.clauseCode + " ";
        }
        //VK002A, VK002B
        let inceptionDate = BMSConstants.getBMSHeaderInfo().effectiveDate;
        inceptionDate = moment(inceptionDate, "YYYY-MM-DD").format("YYYYMMDD");
        request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push(
            { "@FIELD_NAME": 'ITEMITEM', "@FIELD_VALUE": this.riskCode + "" + clause.clauseCode, '@OPERATION': 'STARTSWITH', '@CONDITION': 'AND' },
            { "@FIELD_NAME": 'ITMFRM', "@FIELD_VALUE": inceptionDate, '@OPERATION': 'LTEQ', '@CONDITION': 'AND' },
            { "@FIELD_NAME": 'ITMTO', "@FIELD_VALUE": inceptionDate, '@OPERATION': 'GTEQ', '@CONDITION': 'AND' }
        );
        this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.subClauseCodeHandler, this.handleError, false, { comp: this });
    }
    //VK002
    subClauseCodeHandler(response, prms) {
        let ary = [];
        let wordingVal: string = "";
        if (response.tuple != null && !Array.prototype.isPrototypeOf(response.tuple)) {
            ary = [response.tuple];
        }
        else if (response.tuple != null) {
            ary = response.tuple;
        }
        for (let clause of ary) {
            //VK002A
            wordingVal = wordingVal + clause.old.CLATPF.WORD;
        }
        let lookup = new ModalInput();
        lookup.component = ["SubClausesDialogComponent", "app/bms/components/proposal/newbusinessrisks/uimodules/clauses.module", "ClausesModule"];
        lookup.datainput = { isView: true, comments: wordingVal, parent: prms.comp };
        lookup.outputCallback = prms.comp.viewSubClus;
        lookup.parentCompPRMS = { comp: prms.comp };
        //lookup.id = "ClausesWording";
        lookup.heading = "Clauses Wording";
        lookup.icon = "fa fa-bars";
        lookup.containerRef = prms.comp.contentArea;
        prms.comp.dcl.openLookup(lookup);
    }
    //VK002 END

    removeClause(idx: number, clauseCode) {
        //START YPK001
        if ( clauseCode == 'COIN' && this.headerInfo.CoInsurance == 'Y' && this.riskNo == 1) {
            this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Selected clause cannot be removed, since CO-Insurance is selected.", 10000));
            return;
        }
        //END YPK001
        this._clauses.clause.splice(idx, 1);
        this.removeOtherClauses(this._selectedClauses.clause, "clauseCode", clauseCode);
        this.removeOtherClauses(this._defaultClauses.clause, "clauseCode", clauseCode);
        this.removeOtherClauses(this._defaultProductClauses.clause, "clauseCode", clauseCode);// E1003
    }

    removeOtherClauses(ary, prop, clauseCode) {
        let val = undefined;
        if (ary != undefined && ary.length > 0) {
            for (var index = 0, assoLength = ary.length; index < assoLength; index++) {
                if (ary[index][prop] != null && ary[index][prop] != "" && ary[index][prop] == clauseCode) {
                    val = index;
                }
            }
        }
        if (val != undefined)
            ary.splice(val, 1);
    }
    //VK002 call back Method
    viewSubClus() {
    }

    setDefaultClause(defaultClauseCode) {
        if (defaultClauseCode) {
            let request: GetLOVData = new GetLOVData();
            request.BRANCH = 'ALL';
            request.LOB = 'ALL';
            request.BUSINESS_FUNCTION = 'NEW BUSINESS';
            request.PRODUCT = 'ALL';
            request.OPERATION = 'NEW';
            request.FORM_NAME = 'CLAUSE';
            request.FORM_FIELD_NAME = 'ClauseCode';
            request.FIELD_TYPE = 'LOV';
            request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
            request.ADVANCE_CONFIG_XML.FILTERS = new Filter();

            request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({ "@FIELD_NAME": 'C.DESCITEM', "@FIELD_VALUE": defaultClauseCode, '@OPERATION': 'EQ', '@CONDITION': 'AND' });
            this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.clauseCodeHandler, this.handleError, false, { comp: this });
            this.getFinalClauses(this);
        }
    }

    clauseCodeHandler(response, prms) {
        let ary = [];

        if (response.tuple != null && !Array.prototype.isPrototypeOf(response.tuple)) {
            ary = [response.tuple];
        }
        else if (response.tuple != null) {
            ary = response.tuple;
        }

        prms.comp._defaultClauses.clause = [];
        prms.comp._clauses.clause = prms.comp._clauses.clause.filter((item) => item.isDefaultClause != "Y");// GA001 - new code to clear default clauses form Clauses. MYS-2018-0808
        for (let clause of ary) {
            if (prms.comp.validClause(clause.old.T7382.VALUE, "clauseCode", prms.comp._selectedClauses.clause)) {
                prms.comp._defaultClauses.clause.push({
                    "clauseCode": clause.old.T7382.VALUE,
                    "description": clause.old.T7382.DESCRIPTION,
                    "isDefaultClause": 'Y'
                });
            }
        }
        if (prms.comp.exsType == 'A')
            prms.comp.seClausesInfo(prms.comp, "E1");
        else if (prms.comp.exsType == 'D')
            prms.comp.seClausesInfo(prms.comp, "E2");
    }

    seClausesInfo(comp, clauseCode) {
        let clauseReq: GetLOVData = new GetLOVData();
        clauseReq.BRANCH = 'ALL';
        clauseReq.LOB = 'ALL';
        clauseReq.BUSINESS_FUNCTION = 'NEW BUSINESS';
        clauseReq.PRODUCT = 'ALL';
        clauseReq.OPERATION = 'NEW';
        clauseReq.FORM_NAME = 'CLAUSE';
        clauseReq.FORM_FIELD_NAME = 'ClauseDesc';
        clauseReq.FIELD_TYPE = 'LOV';
        clauseReq.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        clauseReq.ADVANCE_CONFIG_XML.FILTERS = new Filter();

        clauseReq.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({ "@FIELD_NAME": 'DESCITEM', "@FIELD_VALUE": comp.riskCode + clauseCode, '@OPERATION': 'EQ', '@CONDITION': 'AND' });
        this._soapService.callCordysSoapService( "GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", clauseReq, comp.clauseHandler, comp.handleError, false, { comp: comp, clauseCode: clauseCode });
    }

    clauseHandler(response, prms) {
        if (response.tuple) {
            if (prms.comp.validClause(response.tuple.old.T4997.VALUE, "clauseCode", prms.comp._selectedClauses.clause) && prms.comp.validClause(response.tuple.old.T4997.VALUE, "clauseCode", prms.comp._defaultClauses.clause)) {
                prms.comp._defaultClauses.clause.push({
                    "clauseCode": response.tuple.old.T4997.VALUE,
                    "description": response.tuple.old.T4997.DESCRIPTION,
                    "isDefaultClause": (response.tuple.old.T4997.VALUE == "COIN" ) ? 'N' : 'Y' //YPK001
                });
            }
        }
        else if ( prms.comp.headerInfo.CoInsurance == "Y" && prms.clauseCode == "COIN") {//YPK001
            prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "No 'COIN' clause available for the selected risk.", 10000));
        } //YPK001
    }

    getFinalClauses(comp) {
        for (let dClause of comp._defaultClauses.clause) {
            let found = comp._clauses.clause.some(function (el) {
                return el.clauseCode === dClause.clauseCode;
            });
            if (!found) {
				if(!(this.headerInfo.CoInsurance == "N" && dClause.clauseCode == "COIN"))  //SRE1
                comp._clauses.clause.push(dClause);
            }
        }
        for (let sClause of comp._selectedClauses.clause) {
            let found = comp._clauses.clause.some(function (el) {
                return el.clauseCode === sClause.clauseCode;
            });
            if (!found) {
                comp._clauses.clause.push(sClause);
            }
        }
    }

    handleError(response, status, errorText, prms) {
        prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, response.responseJSON.faultstring.text, -1));
    }


    // SAF MYS-2018-1249 start
    openSCDetailsDialog() {
        let searchInput = new SearchInput();
        searchInput.isSingleSelect = false;
        searchInput.BRANCH = 'ALL';
        searchInput.LOB = 'FIRE';
        searchInput.BUSINESS_FUNCTION = 'NEW_BUSINESS';
        searchInput.PRODUCT = 'ALL';
        searchInput.OPERATION = 'ALL';
        searchInput.FORM_NAME = 'FIRE';
        searchInput.FORM_FIELD_NAME = 'StandardClauses';
        searchInput.FIELD_TYPE = 'LOOKUP';
        if (this._clauses.clause.length > 0) {
            let newArr = [];
            for (let item of this._clauses.clause) {
                newArr = newArr.concat(item["clauseCode"]);
            }
            let clauseCodes = "'" + newArr.toString().replace(/,/g, "\',\'") + "'";
            searchInput.condition = { "RISKTYP": this.riskCode, "ITMFRM": moment(this.effectiveDate).format("YYYYMMDD"), "ITMTO": moment(this.effectiveDate).format("YYYYMMDD"), "CLAUSECODE": clauseCodes };
        }
        else
            searchInput.condition = { "RISKTYP": this.riskCode, "ITMFRM": moment(this.effectiveDate).format("YYYYMMDD"), "ITMTO": moment(this.effectiveDate).format("YYYYMMDD"), "CLAUSECODE": "''" };

        let input = new ModalInput();
        input = input.get("GenericSearchComponent");
        input.datainput = searchInput;
        input.outputCallback = this.addStandardClauseCallback;
        input.parentCompPRMS = { comp: this };
        input.heading = "Clauses Details";
        input.icon = "fa fa-link";
        input.containerRef = this.contentArea;
        this.dcl.openLookup(input);
    }

    addStandardClauseCallback(listOfClauses, prms) {
        prms.comp._selectedClauses.clause = [];
        for (let clause of listOfClauses) {
            if (!prms.comp._selectedClauses.clause)
                prms.comp._selectedClauses.clause = [];
            if (prms.comp.validClause(clause.old.TABLE.CLAUSECODE, "clauseCode", prms.comp._clauses.clause)) {
                prms.comp._selectedClauses.clause.push({
                    "clauseCode": clause.old.TABLE.CLAUSECODE,
                    "description": clause.old.TABLE.LONGDESC
                });
                prms.comp.getFinalClauses(prms.comp);
            }
        }
    }
    //End
}

