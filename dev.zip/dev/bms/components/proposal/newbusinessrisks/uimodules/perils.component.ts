/*
Change History	:

	No      Date          Description                                            Changed By
	====    ==========    ===========                                            ==========

	MD001   04/10/2018   MYS-2018-0679    -  Incorrect peril details 
	                                         populated for Fire products in BMS		MKU1 								 											   
*/
import { Component, EventEmitter, OnInit, ViewChild, ViewContainerRef } from '@angular/core';
import { AlertMessage } from '../../../../../common/components/utility/alertmessage/alertmessages.model';
import { AlertMessagesService } from '../../../../../common/components/utility/alertmessage/alertmessages.service';
import { CordysSoapWService } from "../../../../../common/components/utility/cordys-soap-ws";
import { ModalInput } from "../../../../../common/components/utility/modal/modal";
import { SearchInput } from "../../../../../common/components/utility/search/genericsearch";
import { CustomDCLService } from '../../../../../common/services/customdcl.service';
import { LOVDropDownService } from "../../../../../common/services/lovdropdown/lovdropdown.service";
import { FireItems } from '../appobjects/fireItems';
import { Peril, PerilDetail } from "../appobjects/peril";
import { RiskCoverageDetails } from '../s4846/appobjects/s4846';
import { BMSConstants } from '../../../common/constants/bms_constants';
import { ProposalHeader } from '../../proposalheader/appobjects/proposalheader';

declare var moment: any;
declare var numeral: any;

@Component({
    selector: 'perils-component',
    templateUrl: 'app/bms/components/proposal/newbusinessrisks/uimodules/perils.template.html',
    inputs: ['riskCode', '_perils', 'effectiveDate', 'rateBasic', 'ratingFlag', 'fireItems', 'riskCoverageDetails', '_headerInfo'],
    outputs: ['onperilratechange']
})

export class PerilsComponent implements OnInit {

    public _perils: Peril;
    public riskCode: string;
    public effectiveDate: string;
    public perilrate: string = "";
    public rateBasic: string;
    public ratingFlag: string;
    public rateNeeded: boolean = true;
    public perilRateFormat: string = "0.00000";
    public perilAmtFormat: string = "0,00";
    public premiumFormat: string = "0,00.00";
    public fireItems: FireItems;
    public _headerInfo: ProposalHeader;
    onperilratechange = new EventEmitter<any>();

    //Table search
    public search: String = "";
    public position = 1;
    public sizeObj = { length: 0, orglength: 0 };
    public contentSizeObs: any;
    public itemPerPage = 5;
    public maxPageCount = 5;

    public riskCoverageDetails: RiskCoverageDetails;
    @ViewChild('perilModal', { read: ViewContainerRef }) contentArea: ViewContainerRef;

    constructor(public dcl: CustomDCLService, public _alertMsgService: AlertMessagesService) { }

    ngOnInit() {
        this.updateRiskCode();
        this.effectiveDate = moment(this.effectiveDate, "YYYY-MM-DD").format("YYYYMMDD");
        this.setRateNeeded(this.rateBasic, this.ratingFlag);
        this._perils.perilTotal = this.getTotalByProperty("perilRate", this._perils.peril, this.perilRateFormat);//MD001
        this._headerInfo = BMSConstants.getBMSHeaderInfo();
    }

    setRateNeeded(rateBasic, ratingFlag) {
        if (rateBasic == "G" || rateBasic == "S" || rateBasic == "L" || ratingFlag == "M")
            this.rateNeeded = false;
        else
            this.rateNeeded = true;
    }

    evaluatePerilRateNeeded(rateBasic, ratingFlag) {
        if (rateBasic == "G" || rateBasic == "S" || rateBasic == "L" || ratingFlag == "M") {
            this.rateNeeded = false;
        }
        else {
            this.rateNeeded = true;
            this._perils.fireAndLightingRate = "0";
            for (let peril of this._perils.peril) {
                peril.perilRate = peril.autoPerilRate;
            }
        }
        this.resetTotal();
    }

    updateRiskCode() {
        while (this.riskCode != undefined && this.riskCode.length < 3) {
            this.riskCode = this.riskCode + " ";
        }
        this.riskCode = "E" + this.riskCode;
    }

    addPeril(listOfPerils, prms) {
        for (let peril of listOfPerils) {
            if (!prms.comp._perils.peril)
                prms.comp._perils.peril = [];
            prms.comp._perils.peril.push({
                "perilCode": peril.old.DESCPF.PERILCODE,
                "description": peril.old.DESCPF.LONGDESC,
                "perilRate": numeral(peril.old.DESCPF.PERILRATE).format(prms.comp.perilRateFormat),
                "autoPerilRate": numeral(peril.old.DESCPF.PERILRATE).format(prms.comp.perilRateFormat),
                "nature": peril.old.DESCPF.NATURE_01,// SAF MYS-2018-1249 --start
                "overrideInd": peril.old.DESCPF.ZOVRSI,//new code
                "disableItem": (peril.old.DESCPF.NATURE_01 == '**' && (prms.comp._headerInfo.VPMSProduct == 'Y' || prms.comp._headerInfo.firePostingScreen == 'NEW')) ? 'Y' : 'N',
                "amount": "0.00",
                "unFormattedAmount": "0",
                "coverItems": [],
                "prlPRT": peril.old.DESCPF.ZPRLPRT,
                "overrideIndRate": peril.old.DESCPF.ZOVRIND//End
            });
        }
        prms.comp.resetTotal();
    }

    openPerilsDetailsDialog() {
        let searchInput = new SearchInput();
        searchInput.isSingleSelect = false;
        searchInput.BRANCH = 'ALL';
        searchInput.BUSINESS_FUNCTION = 'ALL';
        searchInput.FIELD_TYPE = 'LOOKUP';
        searchInput.FORM_FIELD_NAME = 'PrimaryPeril';
        searchInput.FORM_NAME = 'ALL';
        searchInput.LOB = 'ALL';
        searchInput.OPERATION = 'ALL';
        searchInput.PRODUCT = 'ALL';

        if (this._perils.peril.length > 0) {
            let newArr = [];
            for (let item of this._perils.peril) {
                newArr = newArr.concat(item["perilCode"]);
            }
            let perilCodes = "'" + newArr.toString().replace(/,/g, "\',\'") + "'";
            searchInput.condition = { "D.DESCITEM": this.riskCode, "B.ITMFRM": moment(this.effectiveDate).format("YYYYMMDD"), "B.ITMTO": moment(this.effectiveDate).format("YYYYMMDD"), "SUBSTRING(D.DESCITEM,5,4)": perilCodes, "SUBSTRING(GENAREA,114,2)": "PR" };
        }
        else
            searchInput.condition = { "D.DESCITEM": this.riskCode, "B.ITMFRM": moment(this.effectiveDate).format("YYYYMMDD"), "B.ITMTO": moment(this.effectiveDate).format("YYYYMMDD"), "SUBSTRING(D.DESCITEM,5,4)": "''", "SUBSTRING(GENAREA,114,2)": "PR" };

        let input = new ModalInput();
        input = input.get("GenericSearchComponent");
        input.datainput = searchInput;
        input.outputCallback = this.addPeril;
        input.parentCompPRMS = { comp: this };
        input.heading = "Peril Details";
        input.icon = "fa fa-link";
        input.containerRef = this.contentArea;
        this.dcl.openLookup(input);
    }

    removePeril(idx: number) {
        let finalPerilItemArr = [];
        let removedPerilCode = this._perils.peril[idx].perilCode;
        let tempArr = (this.riskCode != "" && this.riskCode.includes("HHO")) ? this.riskCoverageDetails.riskCoverage : this.fireItems.fireItems
        for (let item of tempArr) {
            finalPerilItemArr = item.perilClassCodes.peril.filter(function (item) { return item.perilCode != removedPerilCode; });
            item.perilClassCodes.peril = finalPerilItemArr;
        }
        this._perils.peril.splice(idx, 1);
        this.resetTotal();
    }

    getTotalByProperty(prop, ary, format) {
        let total: string = "0";
        for (let eachItem of ary) {
            if (eachItem[prop] != null && eachItem[prop] != "") {
                total = "" + (parseFloat(total) + parseFloat(eachItem[prop]));
                total = numeral(total).format(format);
            }
        }
        return parseFloat(total);
    }

    resetTotal() {
        this._perils.perilTotal = this.getTotalByProperty("perilRate", this._perils.peril, this.perilRateFormat);
        //this._perils.perilTotal = numeral((parseFloat(""+this._perils.perilTotal) + parseFloat(this._perils.fireAndLightingRate))).format(this.perilRateFormat);
        this.emitRateChange();
    }

    emitRateChange() {
        this.onperilratechange.emit(this._perils.perilTotal);
    }

    onChangePerilRate() {
        this.resetTotal();
    }

    onFireLigtningRate() {
        this.onperilratechange.emit(this._perils.perilTotal);
    }
    // SAF MYS-2018-1249 Start
    resetPerilAmount(selectedItem, perilItem: PerilDetail) {
        perilItem.nominatedSumInsuredNew = numeral(perilItem.nominatedSumInsuredNew).value();
        let selPerilSI: string;
        let count: number = 0;
        for (let cover of this.fireItems.fireItems) {
            let isItemFound: PerilDetail = cover.perilClassCodes.peril.find(function (item) { return item.perilCode == perilItem.perilCode; });
            if (isItemFound != undefined) {
                selPerilSI = numeral(selPerilSI).value() + numeral(cover.sumInsured).value();
            }
            count = (isItemFound != undefined) ? count + 1 : count;
        }
        if (count == 0) {
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Please select Peril for atleast one cover to adjust Nominated Sum Insured.", 10000));
            selectedItem.target.value = "0";
            perilItem.nominatedSumInsured = 0;
            perilItem.amount = "0.00";
            return;
        }

        if (numeral(selectedItem.target.value).value() == 0 || numeral(selectedItem.target.value).value() > numeral(selPerilSI).value()) {
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Nominated Sum Insured (" + selectedItem.target.value + ") Shouldn't be more than Cover Sum Insured (" + numeral(perilItem.nominatedSumInsured).format(this.premiumFormat) + ") for Peril Code - " + perilItem.perilCode + " .", 10000));
            selectedItem.target.value = "0";
            perilItem.nominatedSumInsured = numeral(selPerilSI).value();
            perilItem.nominatedSumInsuredNew = perilItem.nominatedSumInsured;
            perilItem.amount = numeral((numeral(perilItem.nominatedSumInsured).value() * parseFloat(perilItem.perilRate)) / 100).format(this.premiumFormat);
            return;
        }
        if (numeral(selectedItem.target.value).value() != 0 && numeral(selectedItem.target.value).value() != numeral(perilItem.nominatedSumInsured).value()) {
            this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Nominated Sum Insured has been adjusted from : " + numeral(perilItem.nominatedSumInsured).format(this.premiumFormat) + " to : " + selectedItem.target.value + " for Peril Code - " + perilItem.perilCode + ".", 10000));
        }
        perilItem.amount = (numeral(selectedItem.target.value).value() > 0) ? numeral((numeral(selectedItem.target.value).value() * parseFloat(perilItem.perilRate)) / 100).format(this.premiumFormat) : 0;
    }//End
}