/*
Change History	:

	No      Date          Description                                 Changed By
	====    ==========    ===========                                 ==========
	AL001   13/09/2017   MYS-2017-0350-  Risk GST Details Information 
	             - Risk Usage to defaulted based on Client Type             ALA										   
*/
import { Component, OnInit } from "@angular/core";
import { GSTDetails } from "../appobjects/gstDetails";
import { LOV_Field, LOVDropDownService, SearchFilter } from "../../../../../common/services/lovdropdown/lovdropdown.service";
import { AlertMessagesService } from '../../../../../common/components/utility/alertmessage/alertmessages.service';
import { AlertMessage } from '../../../../../common/components/utility/alertmessage/alertmessages.model';
import { BMSConstants } from '../../../common/constants/bms_constants';
import { BMSUtilService } from "../../../../services/bms.util.service";

@Component({
    selector: 'gst-details',
    templateUrl: 'app/bms/components/proposal/newbusinessrisks/uimodules/gstDetails.template.html',
    inputs: ["_gstDetails"],
    providers: [LOVDropDownService]
})

export class GSTDetailsComponent implements OnInit {

    private isCollapsedMode: boolean = false;
    private _gstDetails: GSTDetails;
    private riskType: string;
    private insuredType: string;
    private showRiskLocation = 'N';
    private showRiskUsage = 'N';
    private showPlaceOfRecidence = 'N';
    private showInputTaxAllowed = 'N';
    // private gstP400FieldsMapping:any = {'ZGSTLOC':'riskLocation','ZGSTUSE':'riskUsage','ZGSTRES':'placeOfRecidence','ZGSTITP':'inputTaxAllowed'};

    constructor(private lovDropDownService: LOVDropDownService, public _alertMsgService: AlertMessagesService, private _bmsUtilService: BMSUtilService) { this._gstDetails = new GSTDetails(); }

    ngOnInit() {
        this.populateLOVs();
        this.riskType = BMSConstants.getSelectedRiskType();
        this.insuredType = BMSConstants.getInsuredType();

        this._bmsUtilService.getGstMandatoryFields().subscribe((data) => this.setGstFields(data));

        if (!this._gstDetails.inputTaxAllowed && this.insuredType == 'C') { // defaulting for Corportate Client
            this._gstDetails.inputTaxAllowed = 'N';
        }

        if (BMSConstants.getBMSObj().ApplicationBusinessObject.caseInfo.businessFunction == 'NewBusiness' || BMSConstants.getBMSObj().ApplicationBusinessObject.caseInfo.businessFunction == 'CoverNote') {
            //AL001 START
            if (this.insuredType == 'C') { // If client type is Corportate Client
                this._gstDetails.riskUsage = 'B';
            } else {
                this._gstDetails.riskUsage = 'P';
            }
            // AL001 END
        }
        this.handleSimplified();

        // Adding below code for SAF MYS-2017-0846 -- start
        let boObject = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness;
        let currRiskObj: any;
        let clientPostCode = (this.insuredType == 'C') ? boObject.clientDetails.client.corporateClientDetails.address.postCode : boObject.clientDetails.client.personalClientDetails.address.postCode;

        let city = (this.insuredType == 'C') ? boObject.clientDetails.client.corporateClientDetails.address.city : boObject.clientDetails.client.personalClientDetails.address.city;

        this._gstDetails.placeOfRecidence = (city == "LLB") ? "DA" : (clientPostCode.match(/[A-Za-z]/i) != null) ? "OS" : "PCA";

        if (boObject.risks.fireIDC.length >= 1) {
            currRiskObj = boObject.risks.fireIDC[0];
        } else if (boObject.risks.fireLOP.length >= 1) {
            currRiskObj = boObject.risks.fireLOP[0];
        } else if (boObject.risks.s4805.length >= 1) {
            currRiskObj = boObject.risks.s4805[0];
        } else if (boObject.risks.s4846.length >= 1) {
            currRiskObj = boObject.risks.s4846[0];
        }
        if (currRiskObj != undefined && currRiskObj.postCode != undefined && currRiskObj.postCode != null) {
            currRiskObj.GSTDetails.riskLocation = (currRiskObj.city == "LLB") ? "DA" : (currRiskObj.postCode.match(/[A-Za-z]/i) != null) ? "OS" : "PCA";
        }
        //End

    }
    handleSimplified() {
        if (BMSConstants.TEMPOBJ.ISSIMPLIFIEDPROCESS == 'Y') {
            this.isCollapsedMode = true;
        }
    }

    private populateLOVs(): void {
        this.lovDropDownService.createLOVDataList(["RiskUsage", "RiskLocation"]);

        let lovFields = [
            new LOV_Field("ALL", "ALL", "NEW BUSINESS", "ALL", "NEW", "GST_DETAILS", "Risk Usage", "LOV", [], "DESCPF", "RiskUsage", null),
            new LOV_Field("ALL", "ALL", "NEW BUSINESS", "ALL", "NEW", "GST_DETAILS", "Risk Location", "LOV", [], "DESCPF", "RiskLocation", null)
        ];
        this.lovDropDownService.util_populateLOV(lovFields, this);
    }

    setGstFields(data) {

        let _mandatoryFields: any = [];
        let _keys: any = [];
        if (data) {
            _keys = Object.keys(data);
            for (let _key of _keys) {
                if (data[_key]) {
                    _mandatoryFields.push(data[_key]);
                    if (data[_key] == 'riskLocation') {
                        this.showRiskLocation = 'Y';
                    } else if (data[_key] == 'riskUsage') {
                        this.showRiskUsage = 'Y';
                    } else if (data[_key] == 'placeOfRecidence') {
                        this.showPlaceOfRecidence = 'Y';
                    } else if (data[_key] == 'inputTaxAllowed') {
                        this.showInputTaxAllowed = 'Y';
                    }
                }
            }
        }

        if (!data || _keys.length == 0) {
            if (this.insuredType == 'C') {
                _mandatoryFields = ['riskLocation', 'riskUsage', 'placeOfRecidence', 'inputTaxAllowed'];
                this.showInputTaxAllowed = 'Y';
            } else {
                _mandatoryFields = ['riskLocation', 'riskUsage', 'placeOfRecidence'];
                this.showInputTaxAllowed = 'N';
            }

            this.showRiskLocation = 'Y';
            this.showRiskUsage = 'Y';
            this.showPlaceOfRecidence = 'Y';

            // BMSConstants.setMandatoryGSTFields(this.riskType,_mandatoryFields);
        }

    }

    private expandOrCollapseGSTInfo() {
        this.isCollapsedMode = ( this.isCollapsedMode ) ? false : true;
    }
}