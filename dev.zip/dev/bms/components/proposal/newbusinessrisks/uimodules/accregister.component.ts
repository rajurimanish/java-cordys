import { Component, OnInit, ViewChild, ViewContainerRef } from '@angular/core';
import { CordysSoapWService } from "../../../../../common/components/utility/cordys-soap-ws";
import { AlertMessagesService } from '../../../../../common/components/utility/alertmessage/alertmessages.service';
import { AlertMessage } from '../../../../../common/components/utility/alertmessage/alertmessages.model';
import { AccRegister } from "../appobjects/accregister";
import { BMSConstants } from '../../../common/constants/bms_constants';
import { ModalInput } from '../../../../../common/components/utility/modal/modal';
import { CustomDCLService } from "../../../../../common/services/customdcl.service";

declare var moment: any;
declare var numeral: any;

@Component({
    selector: 'accregister-component',
    templateUrl: 'app/bms/components/proposal/newbusinessrisks/uimodules/accregister.template.html',
    inputs: ["accRegisterObj", "riskObj"]
})

export class AccRegisterComponent implements OnInit {
    @ViewChild('accRegister', { read: ViewContainerRef }) contentArea: ViewContainerRef;

    private isCollapsedMode: boolean = true;
    private riskObj: any;
    private caseInfo: any;
    private locality: any;
    private accRegisterObj: any = {};

    constructor(public dcl: CustomDCLService, private _soapService: CordysSoapWService, public _alertMsgService: AlertMessagesService) { }

    ngOnInit() {

        if (this.riskObj.locality != null && this.riskObj.locality != undefined) {
            this.locality = this.riskObj.locality;
        }
        else {
            this.locality = this.riskObj.localityRegister;
        }

    }

    private viewAccuRegDialog() {


        this._soapService.callCordysSoapService("GetCurrentExposerAccuRegister", "http://schemas.insurance.com/businessobject/1.0/",
            {
                "caseID": BMSConstants.getBMSObj().ApplicationBusinessObject.caseInfo.caseId,
                "snedmail": "",
                "AccumulationReg": this.riskObj.accumulationRegister,
                "PostCode": this.riskObj.postCode,
                "LocationCode": this.locality,
                "TotalSI": this.riskObj.totalSI,
                "Branch": BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.servicingBranch,
                "cslAmount": this.riskObj.cslAmount,
                "city": this.riskObj.city,
                "responseType": "2"
            },
            this.setAccRegisterInfoSuccess, this.setAccRegisterInfoError, true, { comp: this });
    }

    setAccRegisterInfoSuccess(response, prms) {
        if (!response.fault) {
            prms.comp.riskObj.accRegister.ExposerQuotAccepted = response.ExposerQuotAccepted.text;
            prms.comp.riskObj.accRegister.HoldCoverExposer = response.HoldCoverExposer.text;
            prms.comp.riskObj.accRegister.GAL = response.GAL.text;
            prms.comp.riskObj.accRegister.P400InforcedExposer = response.P400InforcedExposer.text;
            prms.comp.riskObj.accRegister.TotalExposer = response.TotalExposer.text;
            prms.comp.riskObj.accRegister.Outstanding = response.Outstanding.text;
            prms.comp.riskObj.accRegister.totalPercentage = (Number(response.TotalExposer.text) * 100) / Number(response.GAL.text);
            prms.comp.riskObj.accRegister.cessionOutwords = response.cessionOutwords.text;

            prms.comp.riskObj.accRegister.TOTGR = response.TOTGR.text
            prms.comp.riskObj.accRegister.TOTMNR = response.TOTMNR.text
            prms.comp.riskObj.accRegister.TOTFAC = response.TOTFAC.text
            prms.comp.riskObj.accRegister.TOTTREATY = response.TOTTREATY.text
            prms.comp.riskObj.accRegister.LIMITMNR = response.LIMITMNR.text
            prms.comp.riskObj.accRegister.LIMITFAC = response.LIMITFAC.text
            prms.comp.riskObj.accRegister.LIMITTREATY = response.LIMITTREATY.text
            prms.comp.riskObj.accRegister.LIMITNET = response.LIMITNET.text

            if (prms.comp.riskObj.accRegister.totalPercentage < 0) {
                prms.comp.riskObj.accRegister.totalPercentage = -(Number(prms.comp.riskObj.accRegister.totalPercentage));
            }

            prms.comp.riskObj.accRegister.cessionOutwordsPercentage = (Number(response.cessionOutwords.text) * 100) / Number(response.Outstanding.text);
            if (prms.comp.riskObj.accRegister.cessionOutwordsPercentage < 0) {
                prms.comp.riskObj.accRegister.cessionOutwordsPercentage = -(Number(prms.comp.riskObj.accRegister.cessionOutwordsPercentage));
            }


            // formatted values
            prms.comp.riskObj.accRegister.formattedExposerQuotAccepted = numeral(prms.comp.riskObj.accRegister.ExposerQuotAccepted).format("0,0");
            prms.comp.riskObj.accRegister.formattedHoldCoverExposer = numeral(prms.comp.riskObj.accRegister.HoldCoverExposer).format("0,0");
            prms.comp.riskObj.accRegister.formattedGAL = numeral(prms.comp.riskObj.accRegister.GAL).format("0,0");
            prms.comp.riskObj.accRegister.formattedP400InforcedExposer = numeral(prms.comp.riskObj.accRegister.P400InforcedExposer).format("0,0");
            prms.comp.riskObj.accRegister.formattedTotalExposer = numeral(prms.comp.riskObj.accRegister.TotalExposer).format("0,0");
            prms.comp.riskObj.accRegister.formattedOutstanding = numeral(prms.comp.riskObj.accRegister.Outstanding).format("0,0");
            prms.comp.riskObj.accRegister.formattedcessionOutwords = numeral(prms.comp.riskObj.accRegister.cessionOutwords).format("0,0");
            prms.comp.riskObj.accRegister.formattedGALPercentage = isNaN(prms.comp.riskObj.accRegister.totalPercentage) ? numeral(0).format("00.00") : numeral(prms.comp.riskObj.accRegister.totalPercentage).format("00.00");
            prms.comp.riskObj.accRegister.formattedcessionOutPercentage = isNaN(prms.comp.riskObj.accRegister.cessionOutwordsPercentage) ? numeral(0).format("00.00") : numeral(prms.comp.riskObj.accRegister.cessionOutwordsPercentage).format("00.00");
            prms.comp.riskObj.accRegister.formattedtotGR = numeral(prms.comp.riskObj.accRegister.TOTGR).format("0,0");
            prms.comp.riskObj.accRegister.formattedtotMNR = numeral(prms.comp.riskObj.accRegister.TOTMNR).format("0,0");
            prms.comp.riskObj.accRegister.formattedtotFAC = numeral(prms.comp.riskObj.accRegister.TOTFAC).format("0,0");
            prms.comp.riskObj.accRegister.formattedtotTREATY = numeral(prms.comp.riskObj.accRegister.TOTTREAT).format("0,0");
            prms.comp.riskObj.accRegister.formattedLimitMNR = numeral(prms.comp.riskObj.accRegister.LIMITMNR).format("0,0");
            prms.comp.riskObj.accRegister.formattedLimitFAC = numeral(prms.comp.riskObj.accRegister.LIMITFA).format("0,0");
            prms.comp.riskObj.accRegister.formattedLimitTREATY = numeral(prms.comp.riskObj.accRegister.LIMITTREATY).format("0,0");
            prms.comp.riskObj.accRegister.formattedLimitNet = numeral(prms.comp.riskObj.accRegister.LIMITNET).format("0,0");

            //
            prms.comp.viewAccRegisterExtraInfo(response);

        } else {
            prms.comp.tempSysReferred = prms.comp.riskObj.accRegister.isSystemReferred;
            prms.comp.tempAccuSysReferred = prms.comp.riskObj.accRegister.isAccuSystemReferredFlag;
            prms.comp.riskObj.accRegister = new AccRegister();
            prms.comp.riskObj.accRegister.isSystemReferred = prms.comp.tempSysReferred;
            prms.comp.riskObj.accRegister.isAccuSystemReferredFlag = prms.comp.tempAccuSysReferred;

            prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error while Calling Accumulation Register service.", 8000));
        }
    }

    setAccRegisterInfoError(response, status, errorText, prms) {
        prms.comp.tempSysReferred = prms.comp.riskObj.accRegister.isSystemReferred;
        prms.comp.tempAccuSysReferred = prms.comp.riskObj.accRegister.isAccuSystemReferredFlag;
        prms.comp.riskObj.accRegister = new AccRegister();
        prms.comp.riskObj.accRegister.isSystemReferred = prms.comp.tempSysReferred;
        prms.comp.riskObj.accRegister.isAccuSystemReferredFlag = prms.comp.tempAccuSysReferred;

        prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error while Calling Accumulation Register service.", 8000));
    }

    public viewAccRegisterExtraInfo(responseObj) {
        let lookup = new ModalInput();
        lookup.component = ["AccRegisterItemComponent", "app/bms/components/proposal/newbusinessrisks/uimodules/accregister.module", "AccRegisterModule"];
        lookup.datainput = { isView: true, resAccRegisterObj: responseObj };
        lookup.outputCallback = this.callbackAccRegisterInfo;
        lookup.parentCompPRMS = { comp: this };
        lookup.id = "accRegExtraInfoDialog";
        lookup.heading = "Accumulation Register Details";
        lookup.icon = "fa fa-eye";
        lookup.containerRef = this.contentArea;
        this.dcl.openLookup(lookup);
    }

    private callbackAccRegisterInfo() {

    }
}

