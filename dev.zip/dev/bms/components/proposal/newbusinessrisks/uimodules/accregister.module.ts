import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { PaginationModule } from '../../../../../common/components/utility/pagination/pagination.module';

import { AccRegisterComponent } from './accregister.component';
import { AccRegisterItemComponent } from './accregisteritem.component';

@NgModule({
    imports: [CommonModule, FormsModule, ReactiveFormsModule, PaginationModule],
    declarations: [AccRegisterComponent, AccRegisterItemComponent],
    exports: [AccRegisterComponent, AccRegisterItemComponent]
})
export class AccRegisterModule {

}