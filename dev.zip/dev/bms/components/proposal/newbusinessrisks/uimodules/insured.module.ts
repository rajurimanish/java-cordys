import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DatePickerModule } from '../../../../../common/components/utility/date/datepicker.module';
import { SelectBoxModule } from "../../../../../common/components/utility/selectbox/selectbox.module";
import { InsuredComponent } from './insured.component';

@NgModule({
    imports: [CommonModule, FormsModule, ReactiveFormsModule, DatePickerModule, SelectBoxModule],
    declarations: [InsuredComponent],
    exports: [InsuredComponent]
})
export class InsuredModule { }