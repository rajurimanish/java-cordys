/*
 * Change History:
 * 
 * No      Date          Description                                         Changed By
 * ====    ==========    ===========                                         ==========				   
 * GA001   11/09/2019    MYS-2019-0974 - BMS Enhancement on High Risk Vehicle & Client       KGA
*/
import { Nominee, NomineeDetails } from "../appobjects/nomineeslist";
import { Component, OnInit, ViewChild, ViewContainerRef } from '@angular/core';
import { DCLInput, CustomDCLService } from '../../../../../common/services/customdcl.service';
import { LOV_Field, LOVDropDownService, SearchFilter } from "../../../../../common/services/lovdropdown/lovdropdown.service";
import { AlertMessagesService } from '../../../../../common/components/utility/alertmessage/alertmessages.service';
import { AlertMessage } from '../../../../../common/components/utility/alertmessage/alertmessages.model';
import { ModalInput } from '../../../../../common/components/utility/modal/modal';
import { BMSConstants } from '../../../common/constants/bms_constants';
import { ApplicationUtilService } from "../../../../../common/services/application.util.service";
import { CordysSoapWService } from "../../../../../common/components/utility/cordys-soap-ws";//GA001
import { HighRiskIndReason, ProposalHeader } from '../../proposalheader/appobjects/proposalheader';//GA001

declare var moment: any;//GA001

@Component({
    selector: 'driverpa-nominee-component',
    templateUrl: 'app/bms/components/proposal/newbusinessrisks/uimodules/nominee.template.html',
    inputs: ["_namineeDetaillist", "riskObj"] //GA001 - added riskObj

})
export class NomineeComponent implements OnInit {

    @ViewChild('nominee', { read: ViewContainerRef }) contentArea: ViewContainerRef;

    public riskObj: any;//GA001 - added riskObj
    private isCollapsedMode: boolean = false;
    public _namineeDetaillist: NomineeDetails;
    private riskType: string;
    private nomineeAllowedToAdd: string = 'Y';
    //GA001 - added _cordysService
    constructor(public dcl: CustomDCLService, private lovDropDownService: LOVDropDownService, public _alertMsgService: AlertMessagesService,private _cordysService: CordysSoapWService) { }

    ngOnInit(): any {
        this.populateLOVs();
        this.riskType = BMSConstants.getSelectedRiskType();
        //start - MYS-2018-1151
        let caseInfo = BMSConstants.getBMSCaseInfo();
        if (caseInfo != undefined && caseInfo.businessFunction == 'Renewal') {
            for (let nominee of this._namineeDetaillist.nominee) {
                if (nominee.DOB.length < 9) {
                    nominee.DOB = ApplicationUtilService.getFormattedDate(nominee.DOB, "YYYYMMDD", "YYYY-MM-DD");
                }
            }
        }//End
        if (this._namineeDetaillist.nominee != undefined && (this._namineeDetaillist.nominee.constructor != Array)) {
            let nomineeItems: any = this._namineeDetaillist.nominee;
            this._namineeDetaillist.nominee = [nomineeItems];
        }
    }

    openNomineeDetailsDialog() {
        let lookup = new ModalInput();
        lookup.component = ["NomineeDetailsDialogComponent", "app/bms/components/proposal/newbusinessrisks/dialogs/nomineeDetailDialog.module", "NomineeDetailsDialogModule"];
        lookup.outputCallback = this.addNominee;
        lookup.datainput = { isNew: true, nomineeAry: this._namineeDetaillist };
        lookup.parentCompPRMS = { comp: this };
        lookup.heading = "Nominee Details";
        lookup.icon = "fa fa-user";
        lookup.containerRef = this.contentArea;
        this.dcl.openLookup(lookup);
    }

    viewNomineeDetailDialog(idx: number) {
        let lookup = new ModalInput();
        lookup.component = ["NomineeDetailsDialogComponent", "app/bms/components/proposal/newbusinessrisks/dialogs/nomineeDetailDialog.module", "NomineeDetailsDialogModule"];
        let selectedNominee = this._namineeDetaillist.nominee[idx];
        lookup.datainput = { isView: true, selectedNominee, nomineeAry: this._namineeDetaillist, editItem: idx };
        lookup.outputCallback = this.updateNominee;
        lookup.parentCompPRMS = { comp: this };
        lookup.heading = "Nominee Details";
        lookup.icon = "fa fa-user";
        lookup.containerRef = this.contentArea;
        this.dcl.openLookup(lookup);
    }

    private updateNominee(returnPrms, prms) {
        //prms.comp._namineeDetaillist.nominee[returnPrms.editItem] = returnPrms.nominee;
        //GA001 START
        let headerInfo = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo;
        if (headerInfo.isHighRiskApplicable) {
            let OldNominee = prms.comp._namineeDetaillist.nominee[returnPrms.editItem];
            prms.comp.removeHighRiskValidation(prms.comp,OldNominee,prms.comp.riskObj);
            let headerInfo = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo;
            let effectiveDate = "";
            let endDate = "";
            if( headerInfo.effectiveDate!=undefined && headerInfo.effectiveDate!=""
                && moment(headerInfo.effectiveDate).format("YYYYMMDD") != "Invalid date"){
                effectiveDate = moment(headerInfo.effectiveDate).format("YYYYMMDD")
            }
            if( headerInfo.endDate!=undefined && headerInfo.endDate!=""
                && moment(headerInfo.endDate).format("YYYYMMDD") != "Invalid date"){
                endDate = moment(headerInfo.endDate).format("YYYYMMDD")
            }
            prms.comp.checkHighRiskClient(returnPrms.nominee,effectiveDate,endDate,prms,"edit",returnPrms.editItem);
        }else{
            prms.comp._namineeDetaillist.nominee[returnPrms.editItem] = returnPrms.nominee;
        }
        //GA001 END
    }


    removeNominee(idx: number) {
         //GA002 START
        let headerInfo = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo;
        if (headerInfo.isHighRiskApplicable) {
            this.removeHighRiskValidation(this,this._namineeDetaillist.nominee[idx],this.riskObj);
        }
        //GA002 END
        this._namineeDetaillist.nominee.splice(idx, 1);

        this.resetDisplayControlParameters(this);
    }

    addNominee(nominee, prms) {

        //GA002 START
        let headerInfo = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo;
        if (headerInfo.isHighRiskApplicable) {
            let effectiveDate = "";
            let endDate = "";
            if( headerInfo.effectiveDate!=undefined && headerInfo.effectiveDate!=""
                && moment(headerInfo.effectiveDate).format("YYYYMMDD") != "Invalid date"){
                effectiveDate = moment(headerInfo.effectiveDate).format("YYYYMMDD")
            }
            if( headerInfo.endDate!=undefined && headerInfo.endDate!=""
                && moment(headerInfo.endDate).format("YYYYMMDD") != "Invalid date"){
                endDate = moment(headerInfo.endDate).format("YYYYMMDD")
            }
            prms.comp.checkHighRiskClient(nominee,effectiveDate,endDate,prms,"add",-1);
        }else{
            prms.comp._namineeDetaillist.nominee.push(nominee);
            prms.comp.resetDisplayControlParameters(prms.comp);
        }
       //GA002 END
        
    }

    resetDisplayControlParameters(scopeObject) {
        if ((scopeObject.riskType == 'TDA' || scopeObject.riskType == 'TDI' || scopeObject.riskType == 'TPI') && scopeObject._namineeDetaillist.nominee.length >= 5) {
            scopeObject.nomineeAllowedToAdd = 'N';
        } else {
            scopeObject.nomineeAllowedToAdd = 'Y';
        }
        if ((scopeObject.riskType == 'PAC' || scopeObject.riskType == 'PAG' || scopeObject.riskType == 'PMA' || scopeObject.riskType == 'PMB' || scopeObject.riskType == 'PMC' || scopeObject.riskType == 'PMP' || scopeObject.riskType == 'PAS') && scopeObject._namineeDetaillist.nominee.length >= 8) {
            scopeObject.nomineeAllowedToAdd = 'N';
        } else {
            scopeObject.nomineeAllowedToAdd = 'Y';
        }
    }

    private populateLOVs(): void {

        this.lovDropDownService.createLOVDataList(["NomineeRelationship"]);
        let lovFields = [
            new LOV_Field("ALL", "PERSONAL ACCIDENT", "NEW BUSINESS", "ALL", "NEW", "Nominee", "NomineeRelationship", "LOV", [], "DESCPF", "NomineeRelationship", null)];
        this.lovDropDownService.util_populateLOV(lovFields, this);
    }

    //GA002 START
    checkHighRiskClient(nominee,effectiveDate,endDate,prms,operation,index) {
        let riskNumber:number = 0;
        let clientIDNo = "";

        if(prms.comp.riskObj!=undefined && prms.comp.riskObj.riskNumber!=""){
            riskNumber = prms.comp.riskObj.riskNumber;
        }
        if(nominee.ICPassport!=undefined && nominee.ICPassport!=""){
            clientIDNo = nominee.ICPassport;
        }
        if(clientIDNo!="" && clientIDNo!=undefined){//ICPassport
            prms.comp._cordysService.callCordysSoapService("CheckHighRiskForInternalClient", "http://schemas.cordys.com/bmsintegrationapp", { 
                "CLIENTIDNO": clientIDNo, "EFFECTIVEDATE": effectiveDate, "ENDDATE": endDate }, prms.comp.highRiskNomineeInternalICPasHandler, prms.comp.handleError, true, { comp: prms.comp,nominee:nominee,effectiveDate:effectiveDate,endDate:endDate,operation:operation,index:index });
        }else{
            let item_key = "INSURED_ICPASSPORT_INTERNAL_CLIENT"+clientIDNo;
            let removeIndex = -1;
            let headerInfo = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo;
            if(headerInfo.highRiskIndicatorReasons!=undefined && headerInfo.highRiskIndicatorReasons.highRiskIndReason.length>0 ){
                //ICPassport Remove
                removeIndex = prms.comp.findIndexByRiskItemKey( headerInfo.highRiskIndicatorReasons.highRiskIndReason, riskNumber, item_key );
                if(removeIndex>=0){
                    headerInfo.highRiskIndicatorReasons.highRiskIndReason.splice(removeIndex, 1);
                }
            }
            headerInfo.highRiskNomineeInternalInd = 'N';
        }
    }
    highRiskNomineeInternalICPasHandler(response, prms) {
        let riskNumber:number = 0;
        let clientIDNo = "";
        let ind = "";
        let reason = "";
        let reasonA = "";
        let item_key = "";
        let item = "";
        if(prms.nominee.ICPassport!=undefined && prms.nominee.ICPassport!=""){
            clientIDNo = prms.nominee.ICPassport;
        }
        if(prms.comp.riskObj!=undefined){
            if(prms.comp.riskObj.riskNumber!=undefined && prms.comp.riskObj.riskNumber!=""){
                riskNumber = prms.comp.riskObj.riskNumber;
            }else if(prms.comp.riskObj.riskType!=undefined && prms.comp.riskObj.riskType=="PAM"){
                riskNumber = 2;
            }
        }
        if(response.tuple != null && response.tuple.old != null && response.tuple.old.checkHighRiskForInternalClient
            && response.tuple.old.checkHighRiskForInternalClient.checkHighRiskForInternalClient!=null 
            && response.tuple.old.checkHighRiskForInternalClient.checkHighRiskForInternalClient!=""
            && response.tuple.old.checkHighRiskForInternalClient.checkHighRiskForInternalClient!=""){
                ind = response.tuple.old.checkHighRiskForInternalClient.checkHighRiskForInternalClient.substring(0,1);
                reasonA = response.tuple.old.checkHighRiskForInternalClient.checkHighRiskForInternalClient.substring(1);  
        }
        if ( ind != null && ind == 'B' ) {
            reason = "Internal Nominee "+ prms.nominee.name +" with NRIC / BC ("+ prms.nominee.ICPassport +") is High Risk Indicator with Block";
            prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, reason, -1));
            return;
        }else{
            if ( ind != null && ind == 'A' ){
                item_key = "NOMINEE_ICPASSPORT_INTERNAL_CLIENT"+clientIDNo;
                item = "NOMINEE NRIC / BC INTERNAL CLIENT - "+prms.nominee.name;
                let removeIndex = -1;
                let headerInfo = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo;
                if(headerInfo.highRiskIndicatorReasons!=undefined && headerInfo.highRiskIndicatorReasons.highRiskIndReason.length>0 ){
                    //ICPassport Remove
                    removeIndex = prms.comp.findIndexByRiskItemKey( headerInfo.highRiskIndicatorReasons.highRiskIndReason, riskNumber, item_key );
                    if(removeIndex>=0){
                        headerInfo.highRiskIndicatorReasons.highRiskIndReason.splice(removeIndex, 1);
                    }
                }
                let highRiskIndReason:HighRiskIndReason = new HighRiskIndReason();
                highRiskIndReason.riskNumber = Number(riskNumber);
                highRiskIndReason.item_key = item_key;
                highRiskIndReason.item = item;
                highRiskIndReason.reason = reasonA;
                highRiskIndReason.ind = ind;
                            
                headerInfo.highRiskIndicator = "true";
                headerInfo.highRiskIndicatorUI = true;
                headerInfo.highRiskNomineeInternalInd = ind;
                headerInfo.highRiskIndicatorReasons.highRiskIndReason.push( highRiskIndReason );
                prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, item + " : " + reasonA + " with Alert", -1));
            }
            if(prms.operation=="edit"){
                prms.comp._namineeDetaillist.nominee[prms.index] = prms.nominee;
            }else{
                prms.comp._namineeDetaillist.nominee.push(prms.nominee);
                prms.comp.resetDisplayControlParameters(prms.comp);
            }
        }
    }
    handleError(response, status, errorText, prms) {
        prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, response.responseJSON.faultstring.text, -1));
    }
    removeHighRiskValidation(thisObj,nominee,riskObj){
        let riskNumber:number = 0;
        let clientIDNo = "";
        let item_key = "";
        let removeIndex = -1;
        
        if(riskObj!=undefined){
            if(riskObj.riskNumber!=undefined && riskObj.riskNumber!=""){
                riskNumber = riskObj.riskNumber;
            }else if(riskObj.riskType!=undefined && riskObj.riskType=="PAM"){
                riskNumber = 2;
            }
        }
        if(nominee!=undefined && nominee.ICPassport!=undefined && nominee.ICPassport!=""){
            clientIDNo = nominee.ICPassport;
        }
        item_key = "NOMINEE_ICPASSPORT_INTERNAL_CLIENT"+clientIDNo;
        let headerInfo:ProposalHeader = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo;
        if(headerInfo.highRiskIndicatorReasons!=undefined && headerInfo.highRiskIndicatorReasons.highRiskIndReason.length>0 ){
            //ICPassport Remove
            removeIndex = thisObj.findIndexByRiskItemKey( headerInfo.highRiskIndicatorReasons.highRiskIndReason, riskNumber, item_key );
            if(removeIndex>=0){
                headerInfo.highRiskIndicatorReasons.highRiskIndReason.splice(removeIndex, 1);
            }
        }
        if(!(headerInfo.highRiskIndicatorReasons!=undefined && headerInfo.highRiskIndicatorReasons.highRiskIndReason.length>0) ){
            headerInfo.highRiskIndicator = "false";
            headerInfo.highRiskIndicatorUI = false;
            headerInfo.highRiskNomineeInternalInd = "";
        }
    }
    public findIndexByRiskItemKey( highRiskIndReason,riskNumber, item_key ) {
        let indexVal: number = -1;
        highRiskIndReason.forEach( function ( elem, i ) {
            if ( elem.riskNumber == riskNumber && elem.item_key == item_key ) {
                indexVal = i;
                return indexVal;
            }             
        } );
        return indexVal;
    }
    //GA002 END

}