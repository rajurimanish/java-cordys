import { Component, OnInit } from '@angular/core';
import { CordysSoapWService } from "../../../../../common/components/utility/cordys-soap-ws";
import { AlertMessagesService } from '../../../../../common/components/utility/alertmessage/alertmessages.service';
import { AlertMessage } from '../../../../../common/components/utility/alertmessage/alertmessages.model';
import { AccRegister } from "../appobjects/accregister";
declare var Observer: any;

declare var moment: any;
declare var numeral: any;

@Component({
    selector: 'accregisteritem-component',
    templateUrl: 'app/bms/components/proposal/newbusinessrisks/uimodules/accregisteritem.template.html',
    inputs: ['parentCompPRMS', 'datainput', 'closeDialog']
})

export class AccRegisterItemComponent implements OnInit {
    public datainput: any;
    public parentCompPRMS: any;
    public closeDialog: Function;

    public search: String = "";
    public position = 1;
    public sizeObj = { length: 0, orglength: 0 };
    public contentSizeObs: any;
    public itemPerPage = 10;
    public maxPageCount = 10;

    private fireCaseDetailsNodes;
    private accRegisterObj: any;

    constructor(private _soapService: CordysSoapWService, public _alertMsgService: AlertMessagesService) { }

    ngOnInit(): any {

        this.accRegisterObj = this.datainput.resAccRegisterObj;

        if (this.accRegisterObj != undefined) {
            let accRegItem: any = this.accRegisterObj.FIRE_CASE_DETAILS;
            if (accRegItem != undefined && !Array.prototype.isPrototypeOf(accRegItem)) {
                this.fireCaseDetailsNodes = [];
                this.fireCaseDetailsNodes.push(accRegItem);
            } else {
                this.fireCaseDetailsNodes = accRegItem;
            }
        } else {
            this.fireCaseDetailsNodes = [];
        }
    }

}