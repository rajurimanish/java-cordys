import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { PaginationModule } from '../../../../../common/components/utility/pagination/pagination.module';
import { SelectBoxModule } from "../../../../../common/components/utility/selectbox/selectbox.module";

import { CoverageComponent } from './coverage.component';

@NgModule({
    imports: [CommonModule, FormsModule, ReactiveFormsModule, PaginationModule, SelectBoxModule],
    declarations: [CoverageComponent],
    exports: [CoverageComponent]
})
export class CoverageModule { }