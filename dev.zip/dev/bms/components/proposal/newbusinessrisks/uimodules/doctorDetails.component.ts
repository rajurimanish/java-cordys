import { Component, OnInit, ElementRef } from "@angular/core";
import { LOV_Field, LOVDropDownService, SearchFilter } from "../../../../../common/services/lovdropdown/lovdropdown.service";
import { DoctorDetails } from "../appobjects/doctorDetails";
import { AlertMessagesService } from '../../../../../common/components/utility/alertmessage/alertmessages.service';
import { AlertMessage } from '../../../../../common/components/utility/alertmessage/alertmessages.model';
import { BMSConstants } from '../../../common/constants/bms_constants';

declare var jQuery: any;
@Component({
    selector: 'doctor-details',
    templateUrl: 'app/bms/components/proposal/newbusinessrisks/uimodules/doctorDetails.template.html',
    inputs: ["_doctorDetails"]
})

export class DoctorDetailsComponent implements OnInit {
    private el: HTMLElement;
    private isCollapsedMode: boolean = false;
    private _doctorDetails: DoctorDetails;

    constructor(el: ElementRef, public _alertMsgService: AlertMessagesService) {
        // this._doctorDetails = new DoctorDetails();		
        this.el = el.nativeElement;
    }

    ngOnInit() {
    }

    private onTextChange(ev) {
        if (ev.target.value == ' ') {
            ev.target.value = '';
        }
    }

    private onKeyPressHandler(ev) {
        if (ev.keyCode == 13 || ev.target.value.length == 35) {
            this.setFocusToNext(ev.target);
        } else if (ev.keyCode == 32) {
            ev.target.value = ev.target.value.trim();
        }
    }

    setFocusToNext(elmnt) {
        let locationElmnts = jQuery(this.el).find("input");
        jQuery(locationElmnts[locationElmnts.index(elmnt) + 1]).focus();
    }

    validateTelephone() {
        if (this._doctorDetails.phoneNumber) {
            if (!/^\d{3}\-\d{0,12}/g.test(this._doctorDetails.phoneNumber)) {
                this._doctorDetails.phoneNumber = '';
                this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Telephone is not entered in valid format XXX-XXXXXXXXXXXX.", 4000));
            }
        }
    }
}