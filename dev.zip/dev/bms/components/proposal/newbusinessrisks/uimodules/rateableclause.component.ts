import { Component, EventEmitter, OnInit, ViewChild, ViewContainerRef } from '@angular/core';
import { AlertMessagesService } from '../../../../../common/components/utility/alertmessage/alertmessages.service';
import { CordysSoapWService } from "../../../../../common/components/utility/cordys-soap-ws";
import { ModalInput } from "../../../../../common/components/utility/modal/modal";
import { SearchInput } from "../../../../../common/components/utility/search/genericsearch";
import { CustomDCLService } from '../../../../../common/services/customdcl.service';
import { RateableClassCode } from "../appobjects/rateableClassCode";
import { ProposalHeader } from '../../proposalheader/appobjects/proposalheader';
import { BMSConstants } from '../../../common/constants/bms_constants';
import { AppUtil } from '../../../../../common/components/utility/apputil/app.util';

declare var moment: any;
declare var numeral: any;

@Component({
    selector: 'rateable-clauses-component',
    templateUrl: 'app/bms/components/proposal/newbusinessrisks/uimodules/rateableclause.template.html',
    inputs: ['riskCode', '_rateableClause', 'basicRate', 'rateBasis', '_headerInfo'],
    outputs: ['onadd', 'onremove', 'onupdate']
})

export class RateableClausesComponent implements OnInit {

    public _rateableClause: RateableClassCode;
    public riskCode: string;
    public rateBasis: string = '';
    public isEditMode: string = 'Y';
    public clauseRateFormat: string = "0.00000";
    public basicRate: number = 0;
    public clauseAmtFormat: string = "0,00";
    public _headerInfo: ProposalHeader;

    onadd = new EventEmitter<any>();
    onremove = new EventEmitter<any>();
    onupdate = new EventEmitter<any>();
    @ViewChild('rateableClauseModal', { read: ViewContainerRef }) contentArea: ViewContainerRef;

    constructor(public dcl: CustomDCLService, private _soapService: CordysSoapWService, public _alertMsgService: AlertMessagesService) { }

    ngOnInit() {
        this.updateRiskCode();
        if (this.riskCode == "PP1")
            this.setItEditMode(this.rateBasis);

        this._headerInfo = BMSConstants.getBMSHeaderInfo();
    }

    updateRiskCode() {
        while (this.riskCode != undefined && this.riskCode.length < 3) {
            this.riskCode = this.riskCode + " ";
        }
    }

    setItEditMode(mode) {
        if (this.riskCode == "PP1" && mode == "T") {
            this.isEditMode = "N";
        }
        else
            this.isEditMode = "Y";

		/*
		if(mode == "G" || mode == "S") {
			this.isEditMode = "Y";
		}
		else{
			this.isEditMode = "N";
			this.resetRate();
		}*/
    }

    resetRate() {
        for (let eachCls of this._rateableClause.rateableClassCode) {
            eachCls.rate = eachCls.originalRate;
        }
        this.emitUpdate();
    }

    addClause(listOfClauses, prms,defaultRC) {
        if (prms == undefined || prms == "") {
            prms = {};
            prms.comp = this;
        }
        for (let clause of listOfClauses) {
            if (!prms.comp._rateableClause.rateableClassCode)
                prms.comp._rateableClause.rateableClassCode = [];
            let rateVal;
            let isPercent = "N";
            if (clause.old.TABLE.LVLNO != null && clause.old.TABLE.LVLNO == "2") {
                if (prms.comp.riskCode != "HHO")
                    rateVal = numeral((parseFloat(clause.old.TABLE.RATE) * parseFloat("" + prms.comp.basicRate)) / 100).format(prms.comp.clauseRateFormat);
                else
                    rateVal = numeral(clause.old.TABLE.RATE).format(prms.comp.clauseRateFormat);

                isPercent = "Y";
            }
            else {
                rateVal = numeral(clause.old.TABLE.RATE).format(prms.comp.clauseRateFormat);
            }

            if (prms.comp._headerInfo.VPMSProduct == "Y" || prms.comp._headerInfo.firePostingScreen == 'NEW') { // SAF MYS-2018-1249 --start
                prms.comp._rateableClause.rateableClassCode.push({
                    "classCode": clause.old.TABLE.CLAUSECODE,
                    "description": clause.old.TABLE.HEAD,
                    "isPercent": isPercent,
                    "rate": rateVal,
                    "originalRate": clause.old.TABLE.RATE,
                    "nature": clause.old.TABLE.NATURE_01,// SAF MYS-2018-1249 --start
                    "overrideInd": clause.old.TABLE.ZOVRSI,
                    "disableItem": (clause.old.TABLE.NATURE_01 == '**' && (prms.comp._headerInfo.VPMSProduct == 'Y' || prms.comp._headerInfo.firePostingScreen == 'NEW')) ? 'Y' : 'N',
                    "amount": "0.00",
                    "unFormattedAmount": "0",
                    "coverItems": [],
                    "prlPRT": clause.old.TABLE.ZPRLPRT,
                    "overrideIndRate": clause.old.TABLE.ZOVRIND,
                    "isDefaultRCClause": (defaultRC == true)?"Y":"N"//End
                });
            } else {
               //Default
                prms.comp._rateableClause.rateableClassCode.push({
                    "classCode": clause.old.TABLE.CLAUSECODE,
                    "description": clause.old.TABLE.HEAD,
                    "isPercent": isPercent,
                    "rate": rateVal,
                    "isDefaultRCClause": "N"
                });
            } // End

            prms.comp._rateableClause.rateableClassCode = AppUtil.removeAryDuplicates(prms.comp._rateableClause.rateableClassCode,"classCode");
        }
        prms.comp.onadd.emit("");
    }

    updatePercentClauses() {
        if (this._rateableClause.rateableClassCode != null && this._rateableClause.rateableClassCode.length > 0) {
            let percentClauses = this._rateableClause.rateableClassCode.filter((clause) => clause.isPercent == "Y");
            for (let eachPerCls of percentClauses) {
                eachPerCls.rate = numeral((parseFloat(eachPerCls.originalRate) * parseFloat("" + this.basicRate)) / 100).format(this.clauseRateFormat);
            }
            this.onupdate.emit("");
        }
    }

    emitUpdate() {
        this.onupdate.emit("");
    }

    openClausesDialog() {
        let searchInput = new SearchInput();
        searchInput.isSingleSelect = false;
        searchInput.BRANCH = 'ALL';
        searchInput.BUSINESS_FUNCTION = 'NEW_BUSINESS';
        searchInput.FIELD_TYPE = 'LOOKUP';
        if (this._headerInfo.VPMSProduct == "Y" || this._headerInfo.firePostingScreen == 'NEW') { // SAF MYS-2018-1249 --start
            searchInput.FORM_FIELD_NAME = 'RatableClauses';
        } else {
            searchInput.FORM_FIELD_NAME = 'RatableClause';//Default
        } // End
        searchInput.FORM_NAME = 'FIRE';
        searchInput.LOB = 'FIRE';
        searchInput.OPERATION = 'ALL';
        searchInput.PRODUCT = 'ALL';

        let riskTypeFilter = this.riskCode;
        // if(this.riskCode=='ECP' || this.riskCode == 'ARI'){
        // riskTypeFilter='';
        // }

        if (this._rateableClause.rateableClassCode.length > 0) {
            let newArr = [];
            for (let item of this._rateableClause.rateableClassCode) {
                newArr = newArr.concat(item["classCode"]);
            }
            let rateableClassCodes = "'" + newArr.toString().replace(/,/g, "\',\'") + "'";
            searchInput.condition = { "DESCITEM": riskTypeFilter, "ITMFRM": moment().format("YYYYMMDD"), "ITMTO": moment().format("YYYYMMDD"), "SUBSTRING(DESCITEM,4,4)": rateableClassCodes };
        }
        else
            searchInput.condition = { "DESCITEM": riskTypeFilter, "ITMFRM": moment().format("YYYYMMDD"), "ITMTO": moment().format("YYYYMMDD"), "SUBSTRING(DESCITEM,4,4)": "''" };

        let input = new ModalInput();
        input = input.get("GenericSearchComponent");
        input.datainput = searchInput;
        input.outputCallback = this.addClause;
        input.parentCompPRMS = { comp: this };
        input.heading = "Rateable Clauses Details";
        input.icon = "fa fa-link";
        input.containerRef = this.contentArea;
        this.dcl.openLookup(input);
    }

    removeClause(idx: number) {
        let removedItem = this._rateableClause.rateableClassCode.splice(idx, 1);
        this.onremove.emit(removedItem);
    }

    resetBasicRate(rate) {
        this.basicRate = rate;
        this.updatePercentClauses();
    }
}