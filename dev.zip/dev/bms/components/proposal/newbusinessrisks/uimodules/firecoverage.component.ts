/*
Change History	:

	No      Date          Description                               					    Changed By
	====    ==========    ===========                              						    ==========						 
					  								   
    KA001  18/10/2018    MYS-2018-0896    -  To save Premium Details	               		  DKA
    
    E1001  04/11/2019    MYS-2019-1280    -  Incorrect Total Rate when user change rating 
                         flag from 'A' to 'M' for product type FC1 in BMS	               	  SRE1
*/
import { AfterViewInit, Component, ElementRef, EventEmitter, OnInit, ViewChild, ViewContainerRef } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { AlertMessage } from '../../../../../common/components/utility/alertmessage/alertmessages.model';
import { AlertMessagesService } from '../../../../../common/components/utility/alertmessage/alertmessages.service';
import { AppUtil } from '../../../../../common/components/utility/apputil/app.util';
import { CordysSoapWService } from "../../../../../common/components/utility/cordys-soap-ws";
import { ModalInput } from "../../../../../common/components/utility/modal/modal";
import { ProgressBarComponent } from '../../../../../common/components/utility/progressbar/progressbar.component';
import { Filter, GetLOVData, SearchAdvancedConfig } from '../../../../../common/components/utility/search/search.requests';
import { CustomDCLService } from '../../../../../common/services/customdcl.service';
import { LOVDropDownService, LOV_Field, SearchFilter } from "../../../../../common/services/lovdropdown/lovdropdown.service";
import { BMSUtilService } from "../../../../services/bms.util.service"; //SST code
import { BMSAppObjService } from '../../../../services/bmsappobj.service';
import { BMSConstants } from '../../../common/constants/bms_constants';
import { BMSType } from '../../../common/constants/bms_types';
import { ProposalHeader } from '../../proposalheader/appobjects/proposalheader';
import { AccRegister } from '../appobjects/accregister';
import { FireItem, FireItems } from '../appobjects/fireItems';
import { Peril, PerilDetail } from '../appobjects/peril';
import { RateableClassCode, RateableClassCodeDetail } from '../appobjects/rateableClassCode';
import { WarrantyClassCode } from '../appobjects/warrantyClassCodes';
import { ExtraTextDialogData } from "../dialogs/extratext.dialog.data";
import { FireIDC } from '../fireidc/appobjects/fireIDC';

declare var numeral: any;
declare var jQuery: any;
declare var moment: any;
declare var Rx: any;
declare var Observer: any;

@Component( {
    selector: 'fire-coverage-comp',
    templateUrl: 'app/bms/components/proposal/newbusinessrisks/uimodules/firecoverage.template.html',
    inputs: ['fireItems', 'clauses', 'fireObj', 'isAssessment', 'perilClauses', 'wcClauses'],
    outputs: ['onpremiumchange', 'onsichange', 'onfeachange']
} )
export class FireCoverageComponent implements OnInit, AfterViewInit {
    private el: HTMLElement;
    public fireItems: FireItems;
    public fireObj: FireIDC; //any; // SAF MYS-2018-1249 changed from any to FireIDC
    public clauses: RateableClassCode;
    public multiSelectListern: any = { value: "" }
    public colSpanVal: number = 9;
    public totalColSpanVal: number = 3//2;
    public rebateColSpan: any = { prem: 4, empty: 4 };
    onpremiumchange = new EventEmitter<any>();
    onsichange = new EventEmitter<any>();

    public siFormat: string = "0,00";
    public premiumFormat: string = "0,00.00";
    public rateFormat: string = "0.00000";
    public percentFormat: string = "0.00";

    public bsRateCtrl: any;

    public search: String = "";
    public position = 1;
    public sizeObj = { length: 0, orglength: 0 };
    public contentSizeObs: any;
    public itemPerPage = 5;
    public maxPageCount = 5;

    public isFEADisAmountReadOnly = 'Y';
    public disablePerilRate = 'Y';
    public isAssessment: boolean;
    public isApprovalCompleted: string = "N";
    public isdisableFEADetailInfo: boolean = true; // SAF MYS-2018-0666
    public isdisableDDDetailInfo: boolean = true; // SAF MYS-2018-0666

    public headerInfo: ProposalHeader;
    public perilClauses: Peril; // SAF MYS-2018-1249
    public wcClauses: WarrantyClassCode; // SAF MYS-2018-1249
    @ViewChild( 'xtModal', { read: ViewContainerRef } ) contentArea: ViewContainerRef;

    constructor( private lovDropDownService: LOVDropDownService, public _alertMsgService: AlertMessagesService, el: ElementRef, public dcl: CustomDCLService, private _soapService: CordysSoapWService, private _bus: BMSUtilService, private _activatedRoute: ActivatedRoute, private _appObjService: BMSAppObjService ) {
        this.el = el.nativeElement;
    }

    ngOnInit() {
        this.headerInfo = BMSConstants.getBMSHeaderInfo();
        this.setColSpanVal();
        this.populateLOVs();
        this.triggerMulSelListern();
        if ( this.fireObj.riskType == 'ECP' ) {
            // this.isFEADisAmountReadOnly='N';
            // this.disablePerilRate = 'N';
        }
        this.isApprovalCompleted = BMSConstants.getApprovalStatus();
        this.setIsAssessment();

        // SAF MYS-2018-0666 -- start
        //this.headerInfo = BMSConstants.getBMSHeaderInfo();
        this.isdisableFEADetailInfo = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.disableFEAInfo;
        this.isdisableFEADetailInfo = ( this.isdisableFEADetailInfo != undefined ) ? this.isdisableFEADetailInfo : false;
        this.isdisableDDDetailInfo = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.disableDDInfo;
        this.isdisableDDDetailInfo = ( this.isdisableDDDetailInfo != undefined ) ? this.isdisableDDDetailInfo : false;
        //End

        //SST code
        if ( ["MyTasks", "MyDrafts"].indexOf( this._activatedRoute.snapshot.params['component'] ) >= 0 || Object.keys( this._activatedRoute.snapshot.params ).length == 0 ) {
            this.headerInfo = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo;
            this.fireObj.SSTLiveDate = ( this.fireObj.SSTLiveDate == undefined ) ? this.headerInfo.SSTLiveDate : this.fireObj.SSTLiveDate;
            if ( this.fireObj.SSTLiveDate == undefined || this.fireObj.SSTLiveDate == "" ) {
                let tempRespObj = this._bus.getLiveDate();
                this.fireObj.GSTLiveDate = tempRespObj[0].old.ITEMPF.LIVEDATE; //"20180630";
                this.fireObj.SSTLiveDate = tempRespObj[1].old.ITEMPF.LIVEDATE;
                if ( this.headerInfo.SSTLiveDate == undefined || this.headerInfo.SSTLiveDate == "" ) {
                    this.headerInfo.SSTLiveDate = this.fireObj.SSTLiveDate;
                }
                if ( this.headerInfo.GSTLiveDate == undefined || this.headerInfo.GSTLiveDate == "" ) {
                    this.headerInfo.GSTLiveDate = this.fireObj.GSTLiveDate;
                }
            }
            if ( moment( this.headerInfo.effectiveDate, "YYYY-MM-DD" ).format( "YYYYMMDD" ) > moment( this.fireObj.SSTLiveDate, "YYYY-MM-DD" ).format( "YYYYMMDD" ) ) {
                this.fireObj.isGSTApplicable = false;
            } else {
                this.fireObj.isGSTApplicable = true;
            }
            //End
        }

        // SAF MYS-2018-1249 start
        for ( let pItem of this.perilClauses.peril ) {
            if ( pItem.coverItems == undefined ) {
                pItem.coverItems = [];
            }
        }
        this.totalColSpanVal = ( this.headerInfo.VPMSProduct == 'Y' || this.headerInfo.firePostingScreen == "NEW" ) ? 3 : 2;
        if ( BMSConstants.getBMSType() == BMSType.Renewal || BMSConstants.getBMSType() == BMSType.RenewalRerate ) {
            this.resetTotal();
        }
        //End
    }

    setIsAssessment() {
        if ( BMSConstants.getBMSType() != BMSType.Renewal ) {
            if ( this.isApprovalCompleted == "Y" )
                this.isAssessment = false;
        }
    }

    ngAfterViewInit() {
        this.setHoverForAllCover();
    }
    populateLOVs() {
        this.lovDropDownService.createLOVDataList( ["premiumclass","FireAddonPlans"] );
        let riTypeFilterDetails = [new SearchFilter( "DESCITEM", this.fireObj.riskType, "STARTSWITH", "AND" )];
        let riTypeSearchFilterNodes = this.lovDropDownService.createFilter( riTypeFilterDetails );

        let lovFields = [new LOV_Field( "ALL", "FIRE", "NEW BUSINESS", "ALL", "NEW", "FIRE_IDC", "PremiumClass", "LOV", riTypeSearchFilterNodes, "T4688", "premiumclass", null )];

        riTypeFilterDetails = [
            new SearchFilter( "", "", "OPNPRNTHS", "" ),
            new SearchFilter( "DESCITEM", this.fireObj.riskType, "STARTSWITH", "OR" ),
            new SearchFilter( "DESCITEM", '', "EQ", "" ),
            new SearchFilter( "", "", "CLSPRNTHS", "" )
        ];
        riTypeSearchFilterNodes = this.lovDropDownService.createFilter( riTypeFilterDetails );

        // SAF MYS-2019-0909
        lovFields.push( new LOV_Field( "ALL", "FIRE", "NEW BUSINESS", "ALL", "NEW", "FIRE", "Fire_AddonPlans", "LOV", riTypeSearchFilterNodes, "T9223", "FireAddonPlans", null ) );
        //End

        this.lovDropDownService.util_populateLOV( lovFields, this );
    }

    setColSpanVal() {
        // if(this.fireObj.riskType == "LOP" || this.fireObj.riskType =="ECP" || this.fireObj.riskType == "PP1"){
        if ( this.fireObj.riskType == "LOP" ) {
            this.colSpanVal = 10;
            this.totalColSpanVal = 4//3;
            this.rebateColSpan.prem = 5;
            this.rebateColSpan.empty = ( this.headerInfo.VPMSProduct == 'Y' || this.headerInfo.firePostingScreen == "NEW" ) ? 3 : 2;
        }
    }

    hangleSingleRecord() {
        if ( this.fireItems == null || ( this.fireItems != null && typeof ( this.fireItems ) === "string" ) ) {
            this.fireItems = new FireItems();
        }
        else if ( this.fireItems != null && this.fireItems.fireItems != null && !Array.prototype.isPrototypeOf( this.fireItems.fireItems ) ) {
            let tempAry: any = this.fireItems.fireItems;
            this.fireItems.fireItems = [tempAry];
        }
        else if ( this.fireItems.fireItems == null ) {
            this.fireItems.fireItems = [];
        }

        if ( Array.prototype.isPrototypeOf( this.fireItems.fireItems ) ) {
            for ( let fireItem of this.fireItems.fireItems ) {
                if ( fireItem.rateableClassCodes == null || ( fireItem.rateableClassCodes != null && typeof ( fireItem.rateableClassCodes ) === "string" ) ) {
                    fireItem.rateableClassCodes = new RateableClassCode();
                }
                else if ( fireItem.rateableClassCodes != null && fireItem.rateableClassCodes.rateableClassCode != null && !Array.prototype.isPrototypeOf( fireItem.rateableClassCodes.rateableClassCode ) ) {
                    let tempAry: any = fireItem.rateableClassCodes.rateableClassCode;
                    fireItem.rateableClassCodes.rateableClassCode = [tempAry];
                }
                else if ( fireItem.rateableClassCodes.rateableClassCode == null ) {
                    fireItem.rateableClassCodes.rateableClassCode = [];
                }

                // SAF MYS-2018-1249 start
                if ( this.headerInfo.VPMSProduct == "Y" || this.headerInfo.firePostingScreen == "NEW" ) {
                    if ( fireItem.perilClassCodes == null || ( fireItem.perilClassCodes != null && typeof ( fireItem.perilClassCodes ) === "string" ) ) {
                        fireItem.perilClassCodes = new Peril();
                    }
                    else if ( fireItem.perilClassCodes != null && fireItem.perilClassCodes.peril != null && !Array.prototype.isPrototypeOf( fireItem.perilClassCodes.peril ) ) {
                        let tempAry: any = fireItem.perilClassCodes.peril;
                        fireItem.perilClassCodes.peril = [tempAry];
                    }
                    else if ( fireItem.perilClassCodes.peril == null ) {
                        fireItem.perilClassCodes.peril = [];
                    }
                }
            }
        }
    }

    addCover() {
        let newCover = new FireItem();
        newCover.itemNo = this.fireItems.fireItems.length + 1;
        newCover.seqNumber = this.fireItems.fireItems.length + 1;
        newCover.basicRate = this.fireObj.basicRate;
        newCover.perilRate = this.fireObj.perilsRate;
        newCover.clauseRate = 0;
        newCover.feaRate = this.fireObj.FEARate;
        newCover.multiplierPercentage = 100;
        // if(this.fireObj.riskType!='ECP'){ //commenting as per Redmine-1981
        newCover.rate = numeral( ( parseFloat( "" + this.fireObj.perilsRate ) + parseFloat( "" + this.fireObj.basicRate ) ) - parseFloat( "" + this.fireObj.FEARate ) ).format( this.rateFormat );
        // }
        this.fireItems.fireItems.push( newCover );
        let premCls = "";
        if ( this.fireObj.riskType == "IIF" ) {
            premCls = "11P";
        } else if ( this.fireObj.riskType != "PP1" && this.lovDropDownService.lovDataList.premiumclass != null && this.lovDropDownService.lovDataList.premiumclass[0] != null ) {
            premCls = this.lovDropDownService.lovDataList.premiumclass[0].VALUE;
        }
        newCover.premiumClass = premCls;

        // SAF MYS-2018-1249 start
        if ( this.headerInfo.VPMSProduct == "Y" || this.headerInfo.firePostingScreen == "NEW" ) {
            let totalFireItemsSI = this.getTotalByProperty( "sumInsured", this.fireItems.fireItems, null );
            this.resetAllPremiumInfo( event, this.fireItems.fireItems );
            // Below code to add Peril clauses into Fire Items.
            if ( this.fireObj.riskType != "LOP" ) {
                for ( let perilItem of this.perilClauses.peril ) {
                    if ( perilItem.nature == '**' ) {
                        let isItemExists = newCover.perilClassCodes.peril.find( _item => _item.perilCode == perilItem.perilCode );
                        if ( isItemExists == undefined ) {
                            newCover.perilClassCodes.peril.push( perilItem );
                            if ( !Array.prototype.isPrototypeOf( perilItem.coverItems ) ) {
                                let temp: any = [perilItem.coverItems];
                                perilItem.coverItems = temp;
                            }
                            perilItem.coverItems.push( newCover.itemNo.toString() );
                        }                       
                        perilItem.nominatedSumInsured = numeral( totalFireItemsSI ).value();
                        if ( this.headerInfo.VPMSProduct != "Y" || this.fireObj.ratingFlag == 'M' ) {
                            perilItem.amount = ( numeral( perilItem.nominatedSumInsured ).value() > 0 ) ? numeral( ( numeral( perilItem.nominatedSumInsured ).value() * parseFloat( perilItem.perilRate ) ) / 100 ).format( this.premiumFormat ) : 0;
                        } else {
                            perilItem.amount = numeral( 0 ).format( this.premiumFormat );
                        }
                        perilItem.unFormattedAmount = numeral().unformat( perilItem.amount );
                    }
                }
                // Below code to add Ratable clauses into Fire Items.
                for ( let rcItem of this.clauses.rateableClassCode ) {
                    if ( rcItem.nature == '**' ) {
                        let isItemExists = newCover.rateableClassCodes.rateableClassCode.find( _item => _item.classCode == rcItem.classCode );
                        if ( isItemExists == undefined ) {
                            newCover.rateableClassCodes.rateableClassCode.push( rcItem );
                            if ( !Array.prototype.isPrototypeOf( rcItem.coverItems ) ) {
                                let temp: any = [rcItem.coverItems];
                                rcItem.coverItems = temp;
                            }
                            rcItem.coverItems.push( newCover.itemNo.toString() );
                        }
                        rcItem.nominatedSumInsured = numeral( totalFireItemsSI ).value();
                        if ( this.headerInfo.VPMSProduct != "Y" || this.fireObj.ratingFlag == 'M' ) {
                            rcItem.amount = ( numeral( rcItem.nominatedSumInsured ).value() > 0 ) ? numeral( ( numeral( rcItem.nominatedSumInsured ).value() * parseFloat( rcItem.rate ) ) / 100 ).format( this.premiumFormat ) : 0;
                        } else {
                            rcItem.amount = numeral( 0 ).format( this.premiumFormat );
                        }
                        rcItem.unFormattedAmount = numeral().unformat( rcItem.amount );
                    }
                }
                // Below code to add Warranty clauses into Fire Items.
                for ( let wcItem of this.wcClauses.warrantyClassCode ) {
                    if ( wcItem.nature == '**' ) {
                        let isItemExists = newCover.wcClassCodes.warrantyClassCode.find( _item => _item.classCode == wcItem.classCode );
                        if ( isItemExists == undefined ) {
                            newCover.wcClassCodes.warrantyClassCode.push( wcItem );
                            if ( !Array.prototype.isPrototypeOf( wcItem.coverItems ) ) {
                                let temp: any = [wcItem.coverItems];
                                wcItem.coverItems = temp;
                            }
                            wcItem.coverItems.push( newCover.itemNo.toString() );
                        }
                        wcItem.nominatedSumInsured = numeral( totalFireItemsSI ).value();
                        if ( this.headerInfo.VPMSProduct != "Y" || this.fireObj.ratingFlag == 'M' ) {
                            wcItem.amount = ( numeral( wcItem.nominatedSumInsured ).value() > 0 ) ? numeral( ( numeral( wcItem.nominatedSumInsured ).value() * parseFloat( wcItem.rate ) ) / 100 ).format( this.premiumFormat ) : 0;
                        } else {
                            wcItem.amount = numeral( 0 ).format( this.premiumFormat );
                        }
                        wcItem.unFormattedAmount = numeral().unformat( wcItem.amount );
                    }
                }
            }
        }
        //End
    }

    setFeaRate() {
        if ( this.fireObj.riskType == "LOP" ) {
            this.fireObj.FEARate = 0;
        }
        else {
            this.fireObj.FEARate = ( parseFloat( "" + this.fireObj.FEAPercentage ) / 100 ) * parseFloat( "" + this.fireObj.basicRate );
        }
    }

    resetTotal() {
        /* org code */
        if ( this.fireObj.ratingFlag == 'M' || ( this.headerInfo.VPMSProduct != "Y" && this.headerInfo.firePostingScreen != "NEW" ) || this.fireObj.riskType == "LOP" ) {
            for ( let cover of this.fireItems.fireItems ) {
                this.setTotalForCover( cover );
            }
        }
        // SAF MYS-2018-1249 start
        if ( this.fireObj.riskType != "LOP" && ( this.headerInfo.VPMSProduct == "Y" || this.headerInfo.firePostingScreen == "NEW" ) ) {
            this.clearCoverItemsInfo( this.clauses.rateableClassCode.filter( ( item ) => item.nature == '**' ) );
            this.clearCoverItemsInfo( this.perilClauses.peril.filter( ( item ) => item.nature == '**' ) );
            this.clearCoverItemsInfo( this.wcClauses.warrantyClassCode.filter( ( item ) => item.nature == '**' ) );

            let totalFireItemsSI = this.getTotalByProperty( "sumInsured", this.fireItems.fireItems, null );
            for ( let cover of this.fireItems.fireItems ) {
                // Default Peril Clauses
                if ( this.fireObj.perils.peril != undefined && cover.perilClassCodes != undefined ) {
                    if ( !Array.prototype.isPrototypeOf( cover.perilClassCodes.peril ) ) {
                        cover.perilClassCodes.peril = new AppUtil().getArray( cover.perilClassCodes.peril );
                    }
                    let defaultPItems = this.perilClauses.peril.filter( ( item ) => item.nature == '**' );
                    for ( let perilItem of defaultPItems ) {
                        //if (perilItem.nature == '**') {
                        let isItemExists = cover.perilClassCodes.peril.find( _item => _item.perilCode == perilItem.perilCode );
                        if ( isItemExists == undefined ) {
                            cover.perilClassCodes.peril.push( perilItem );
                        }
                        perilItem.nominatedSumInsured = numeral( totalFireItemsSI ).value();
                        perilItem.nominatedSumInsuredNew = perilItem.nominatedSumInsured;
                        if ( this.fireObj.ratingFlag == 'M' || this.headerInfo.VPMSProduct != "Y" ) {
                            perilItem.amount = numeral( ( numeral( perilItem.nominatedSumInsured ).value() * parseFloat( perilItem.perilRate ) ) / 100 ).format( this.premiumFormat );
                        }
                        perilItem.unFormattedAmount = numeral().unformat( perilItem.amount );
                        if ( perilItem.coverItems == undefined || perilItem.coverItems.toString() == "" ) {
                            perilItem.coverItems = [];
                        } else if ( !Array.prototype.isPrototypeOf( perilItem.coverItems ) ) {
                            let temp: any = [perilItem.coverItems];
                            perilItem.coverItems = temp;
                        }
                        if ( perilItem.coverItems.indexOf( cover.itemNo.toString() ) == -1 ) {
                            perilItem.coverItems.push( cover.itemNo.toString() );
                        }
                        //}
                    }
                    // new code to default Perils Items to FireItems for Renewals
                    if ( BMSConstants.getBMSType() == BMSType.Renewal || BMSConstants.getBMSType() == BMSType.RenewalRerate ) {
                        let nonDefaultPItems = this.perilClauses.peril.filter( ( item ) => item.nature != '**' );
                        for ( let perilItem of nonDefaultPItems ) {
                            if ( perilItem.coverItems == undefined || perilItem.coverItems.toString() == "" ) {
                                perilItem.coverItems = [];
                            } else if ( !Array.prototype.isPrototypeOf( perilItem.coverItems ) ) {
                                let temp: any = [perilItem.coverItems];
                                perilItem.coverItems = temp;
                            }
                            perilItem.coverItems.forEach( cItem => {
                                if ( cItem.toString() == cover.itemNo.toString() ) {
                                    let isItemExists = cover.perilClassCodes.peril.find( _item => _item.perilCode == perilItem.perilCode );
                                    if ( isItemExists == undefined ) {
                                        cover.perilClassCodes.peril.push( perilItem );
                                    }
                                }
                            } );
                        }
                    }
                }


                // Defaulting Ratable Clauses 
                if ( JSON.stringify( this.fireObj.rateableClassCode ) != JSON.stringify( "" ) && this.fireObj.rateableClassCode.rateableClassCode != undefined && JSON.stringify( cover.rateableClassCodes ) != JSON.stringify( "" ) ) {
                    if ( !Array.prototype.isPrototypeOf( cover.rateableClassCodes.rateableClassCode ) ) {
                        cover.rateableClassCodes.rateableClassCode = new AppUtil().getArray( cover.rateableClassCodes.rateableClassCode );
                    }
                    let defaultRItems = this.clauses.rateableClassCode.filter( ( item ) => item.nature == '**' );
                    for ( let rItem of defaultRItems ) {
                        //if (rItem.nature == '**') {
                        let isItemExists = cover.rateableClassCodes.rateableClassCode.find( _item => _item.classCode == rItem.classCode );
                        if ( isItemExists == undefined ) {
                            cover.rateableClassCodes.rateableClassCode.push( rItem );
                        }
                        rItem.nominatedSumInsured = numeral( totalFireItemsSI ).value();
                        rItem.nominatedSumInsuredNew = rItem.nominatedSumInsured;
                        if ( this.fireObj.ratingFlag == 'M' || this.headerInfo.VPMSProduct != "Y" ) {
                            rItem.amount = numeral( ( numeral( rItem.nominatedSumInsured ).value() * parseFloat( rItem.rate ) ) / 100 ).format( this.premiumFormat );
                        }
                        rItem.unFormattedAmount = numeral().unformat( rItem.amount );
                        if ( rItem.coverItems == undefined || rItem.coverItems.toString() == "" ) {
                            rItem.coverItems = [];
                        } else if ( !Array.prototype.isPrototypeOf( rItem.coverItems ) ) {
                            let temp: any = [rItem.coverItems];
                            rItem.coverItems = temp;
                        }
                        if ( rItem.coverItems.indexOf( cover.itemNo.toString() ) == -1 ) {
                            rItem.coverItems.push( cover.itemNo.toString() );
                        }
                        //}
                    }

                    // new code to default Perils Items to FireItems for Renewals
                    if ( BMSConstants.getBMSType() == BMSType.Renewal || BMSConstants.getBMSType() == BMSType.RenewalRerate ) {
                        let nonDefaultRItems = this.clauses.rateableClassCode.filter( ( item ) => item.nature != '**' );
                        for ( let rItem of nonDefaultRItems ) {
                            if ( rItem.coverItems == undefined || rItem.coverItems.toString() == "" ) {
                                rItem.coverItems = [];
                            } else if ( !Array.prototype.isPrototypeOf( rItem.coverItems ) ) {
                                let temp: any = [rItem.coverItems];
                                rItem.coverItems = temp;
                            }
                            rItem.coverItems.forEach( cItem => {
                                if ( cItem.toString() == cover.itemNo.toString() ) {
                                    let isItemExists = cover.rateableClassCodes.rateableClassCode.find( _item => _item.classCode == rItem.classCode );
                                    if ( isItemExists == undefined ) {
                                        cover.rateableClassCodes.rateableClassCode.push( rItem );
                                    }
                                }
                            } );
                        }
                    }
                }

                // Default Warranty Clauses
                if ( this.fireObj.warrantyClassCodes.warrantyClassCode != undefined && cover.wcClassCodes != undefined ) {
                    if ( !Array.prototype.isPrototypeOf( cover.wcClassCodes.warrantyClassCode ) ) {
                        cover.wcClassCodes.warrantyClassCode = new AppUtil().getArray( cover.wcClassCodes.warrantyClassCode );
                    }
                    let defaultWCItems = this.fireObj.warrantyClassCodes.warrantyClassCode.filter( ( item ) => item.nature == '**' );//this.wcClauses.warrantyClassCode.filter((item) => item.nature == '**');
                    for ( let wcItem of defaultWCItems ) {
                        let isItemExists = this.fireObj.warrantyClassCodes.warrantyClassCode.find( _item => _item.classCode == wcItem.classCode );
                        if ( isItemExists == undefined ) {
                            this.fireObj.warrantyClassCodes.warrantyClassCode.push( wcItem );
                        }
                        wcItem.nominatedSumInsured = numeral( totalFireItemsSI ).value();
                        wcItem.nominatedSumInsuredNew = wcItem.nominatedSumInsured;
                        if ( this.fireObj.ratingFlag == 'M' || this.headerInfo.VPMSProduct != "Y" ) {
                            wcItem.amount = numeral( ( numeral( wcItem.nominatedSumInsured ).value() * parseFloat( wcItem.rate ) ) / 100 ).format( this.premiumFormat );
                        }
                        wcItem.unFormattedAmount = numeral().unformat( wcItem.amount );
                        if ( wcItem.coverItems == undefined || wcItem.coverItems.toString() == "" ) {
                            wcItem.coverItems = [];
                        } else if ( !Array.prototype.isPrototypeOf( wcItem.coverItems ) ) {
                            let temp: any = [wcItem.coverItems];
                            wcItem.coverItems = temp;
                        }
                        if ( wcItem.coverItems.indexOf( cover.itemNo.toString() ) == -1 ) {
                            wcItem.coverItems.push( cover.itemNo.toString() );
                        }
                    }
                }

				/* if(this.headerInfo.VPMSProduct == "Y" && this.headerInfo.firePostingScreen != "NEW" ) {
					this.resetAllPremiumInfo(event,cover);
				} */
                if ( this.headerInfo.VPMSProduct != "Y" ) {
                    this.setTotalForCover( cover );
                }

            }
        }
        //End

        this.setDiscount();
        this.setRebateGST();
        this.emitTotals();
    }

    private clearCoverItemsInfo( defaultItems: any ) {
        for ( let item of defaultItems ) {
            if ( item.nature == '**' ) {
                item.coverItems = [];
            }
            if ( this.fireItems.fireItems.length == 0 ) {
                item.nominatedSumInsured = 0;
                item.amount = numeral( 0 ).format( this.premiumFormat );
                item.unFormattedAmount = numeral( 0 );
            }
        }
    } //End

    emitTotals() {
        this.onpremiumchange.emit( this.fireObj.totalPremium );
        this.onsichange.emit( this.fireObj.totalSI );
    }

    setTotalForCover( cover ) {
        cover.basicRate = this.fireObj.basicRate;
        //cover.perilRate = this.fireObj.perilsRate; // SAF MYS-2018-1249
        cover.feaRate = this.fireObj.FEARate;
        cover.clauseRate = ( cover.clauseRate == undefined ) ? 0 : cover.clauseRate;
        cover.perilRate = ( cover.perilRate == undefined ) ? 0 : cover.perilRate;
        // if(this.fireObj.riskType!='ECP'){ //commenting as per Redmine-1981
        /* org code  */
        if ( this.fireObj.ratingFlag == 'M' || ( this.headerInfo.VPMSProduct != "Y" && this.headerInfo.firePostingScreen != "NEW" ) ) {// SAF MYS-2018-1249 start
            cover.rate = numeral( ( parseFloat( "" + this.fireObj.basicRate ) + parseFloat( "" + this.fireObj.perilsRate ) + parseFloat( cover.clauseRate ) ) - parseFloat( "" + this.fireObj.FEARate ) ).format( this.rateFormat );
        } else if ( this.headerInfo.VPMSProduct == "Y" || this.headerInfo.firePostingScreen == "NEW" ) {
            cover.rate = numeral( ( parseFloat( "" + this.fireObj.basicRate ) + parseFloat( cover.perilRate ) + parseFloat( cover.clauseRate ) ) - parseFloat( "" + this.fireObj.FEARate ) ).format( this.rateFormat );
        } //End 	
        // }
        this.setPremium( cover );
    }

    removeFireItem( fireItem ) {
        if ( this.headerInfo.VPMSProduct == "Y" || this.headerInfo.firePostingScreen == "NEW" ) { // SAF MYS-2018-1249 start
            this._alertMsgService.add( new AlertMessage( AlertMessage.INFO, "Cover " + fireItem.itemNo + " has been removed, all Clauses's data will be refereshed.", 5000 ) );
        } //End
        let _idx = this.fireItems.fireItems.indexOf( fireItem );
        this.fireItems.fireItems.splice( _idx, 1 );
        this.resetSecNumber();
        this.setCapitalSI();
        if ( this.fireObj.ratingFlag == 'M' || ( this.headerInfo.VPMSProduct != "Y" && this.headerInfo.firePostingScreen != "NEW" ) ) {
            this.resetTotal();
        }

        // SAF MYS-2018-1249 start
        if ( this.headerInfo.VPMSProduct == "Y" && this.headerInfo.firePostingScreen == "NEW" ) {
            this.resetAllPremiumInfo( event, this.fireItems.fireItems );
        }
        //Clear values for all Peril, Ratable & Warranty Clauses.
        if ( this.fireObj.riskType != "LOP" ) {
            this.clearAllClausesData( "" );
        }
        //End

        this.resetTotal();
    }
    // SAF MYS-2018-1249 start
    private clearAllClausesData( flag ) {
        let selectedPItems = ( "ClearAll" == flag ) ? this.perilClauses.peril : this.perilClauses.peril.filter( function ( val ) { return val.nature != '**'; } );
        this.resetAllClausesInfo( selectedPItems, flag );
        let selectedRItems = ( "ClearAll" == flag ) ? this.clauses.rateableClassCode : this.clauses.rateableClassCode.filter( function ( val ) { return val.nature != '**'; } );
        this.resetAllClausesInfo( selectedRItems, flag );
        if ( this.wcClauses != undefined ) {
            let selectedWCItems = ( "ClearAll" == flag ) ? this.wcClauses.warrantyClassCode : this.wcClauses.warrantyClassCode.filter( function ( val ) { return val.nature != '**'; } );
            this.resetAllClausesInfo( selectedWCItems, flag );
        }

        //reset clauses data.
        for ( let cover of this.fireItems.fireItems ) {
            if ( JSON.stringify( cover.perilClassCodes ) != JSON.stringify( "" ) ) {
                let selectedPItems = ( "ClearAll" == flag ) ? cover.perilClassCodes.peril : cover.perilClassCodes.peril.filter( function ( val ) { return val.nature != '**' } );
                this.clearAllClausesInfo( selectedPItems, flag, cover );
            }
            if ( JSON.stringify( cover.rateableClassCodes ) != JSON.stringify( "" ) ) {
                let selectedRItems = ( "ClearAll" == flag ) ? cover.rateableClassCodes.rateableClassCode : cover.rateableClassCodes.rateableClassCode.filter( function ( val ) { return val.nature != '**' } );
                this.clearAllClausesInfo( selectedRItems, flag, cover );
            }
            if ( JSON.stringify( cover.wcClassCodes ) != JSON.stringify( "" ) ) {
                let selectedWCItems = ( "ClearAll" == flag ) ? cover.wcClassCodes.warrantyClassCode : cover.wcClassCodes.warrantyClassCode.filter( function ( val ) { return val.nature != '**' } );
                this.clearAllClausesInfo( selectedWCItems, flag, cover );
            }

        }
    }

    private resetAllClausesInfo( selectedItems: any, flag: any ) {
        if ( selectedItems != undefined ) {
            for ( let item of selectedItems ) {
                item.nominatedSumInsured = 0;
                if ( "SIChanged" != flag ) {
                    item.nominatedSumInsuredNew = item.nominatedSumInsured;
                    item.amount = "0.00";
                    item.unFormattedAmount = 0;
                    item.coverItems = [];
                }
            }
        }
    }

    private clearAllClausesInfo( selectedItems: any, flag: any, cover: FireItem ) {
        if ( selectedItems != undefined ) {
            for ( let item of selectedItems ) {
                let rateVal = ( item.perilRate != undefined ) ? item.perilRate : item.rate;
                if ( "SIChanged" != flag ) {
                    if ( !Array.prototype.isPrototypeOf( item.coverItems ) ) {
                        item.coverItems = new AppUtil().getArray( item.coverItems );
                    }
                    item.coverItems.push( cover.itemNo.toString() );
                }
                item.nominatedSumInsured = numeral( item.nominatedSumInsured ).value() + numeral( cover.sumInsured ).value();
                item.nominatedSumInsuredNew = item.nominatedSumInsured;
                if ( this.headerInfo.VPMSProduct != "Y" || this.fireObj.ratingFlag == 'M' ) {
                    item.amount = ( numeral( item.nominatedSumInsured ).value() > 0 ) ? numeral( ( numeral( item.nominatedSumInsured ).value() * parseFloat( rateVal ) ) / 100 ).format( this.premiumFormat ) : 0;
                }
                else {
                    item.amount = numeral( 0 ).format( this.premiumFormat );
                }
                item.unFormattedAmount = numeral().unformat( item.amount );
            }
        }
    } //End

    getTotalByProperty( prop, ary, format: string ) {
        let total = 0;
        for ( let eachItem of ary ) {
            if ( eachItem[prop] != null && eachItem[prop] != "" )
                total = total + parseFloat( numeral( eachItem[prop] ).value() );
        }
        if ( format != null )
            return numeral( numeral( total ).format( format ) ).value();
        else
            return total;
    }

    setPremium( fireItem: FireItem ) {
        let si: any = fireItem.sumInsured;
        let rate: any = fireItem.rate;
        fireItem.feaRate = ( fireItem.feaRate == undefined || fireItem.feaRate == null ) ? 0 : fireItem.feaRate;
        fireItem.perilRate = ( fireItem.perilRate == undefined || fireItem.perilRate == null ) ? 0 : fireItem.perilRate;
        let rate1: any = 0;
        si = ( si == null || si == "" ) ? 0 : si;
        // SAF MYS-2018-0666
        if ( this.headerInfo.VPMSProduct != "Y" && this.headerInfo.firePostingScreen != "NEW" && this.headerInfo.disableDDInfo == false && si != undefined && si != "" && si != null && !isNaN( rate ) && fireItem.deductableRate != undefined ) {
            this.onChangeDDInfo( si, fireItem );
            rate1 = ( parseFloat( "" + fireItem.basicRate ) > parseFloat( "" + fireItem.deductableRate ) ) ? parseFloat( "" + fireItem.basicRate ) - parseFloat( "" + fireItem.deductableRate ) : parseFloat( "" + fireItem.deductableRate ) - parseFloat( "" + fireItem.basicRate );
            rate1 = numeral( ( parseFloat( "" + fireItem.basicRate ) + parseFloat( "" + fireItem.perilRate ) + parseFloat( "" + fireItem.clauseRate ) ) - parseFloat( "" + this.fireObj.FEARate ) ).format( this.rateFormat );
            fireItem.rate = ( !isNaN( rate1 ) ) ? numeral( numeral( rate1 ).format( this.rateFormat ) ).value() : numeral( fireItem.rate );
            this.fireObj.deductableRate = parseFloat( "" + fireItem.deductableRate );
        }
        //End

        rate = ( rate == null || rate == "" ) ? 0 : rate;
        let discPremium = ( si * rate ) / 100;
        let fullPremium = ( si * ( parseFloat( "" + rate ) + parseFloat( "" + fireItem.feaRate ) ) ) / 100;
        // if(this.fireObj.riskType == "LOP" || this.fireObj.riskType == "ECP" || this.fireObj.riskType == "PP1"){
        if ( this.fireObj.riskType == "LOP" ) {
            if ( fireItem.multiplierPercentage == null || AppUtil.isEmpty( fireItem.multiplierPercentage, false ) == true ) {
                fireItem.multiplierPercentage = 100;
                fireItem.premium = numeral( numeral( discPremium ).format( this.premiumFormat ) ).value();
            }
            else {
                fireItem.premium = numeral( numeral( ( discPremium * parseFloat( "" + fireItem.multiplierPercentage ) ) / 100 ).format( this.premiumFormat ) ).value();
            }
        }
        else {
            fireItem.premium = numeral( numeral( discPremium ).format( this.premiumFormat ) ).value();
        }
        fireItem.feaDiscount = numeral( numeral( fullPremium - discPremium ).format( this.rateFormat ) ).value();
        this.setDiscount();
        this.setRebateGST();
        this.emitTotals();
    }

    setDiscount() {
        this.fireObj.originalTotalPremium = this.getTotalByProperty( "premium", this.fireItems.fireItems, this.premiumFormat );
        if ( this.fireObj.riskType != "LOP" )
            this.fireObj.FEADisAmount = this.getTotalByProperty( "feaDiscount", this.fireItems.fireItems, this.rateFormat );;
    }

    setClauseRate( selectedClauseDetail: RateableClassCodeDetail[], fireItem ) {
        let total = 0;
        for ( let clauseDetail of selectedClauseDetail ) {
            total = total + parseFloat( clauseDetail.rate );
        }
        fireItem.clauseRate = numeral( fireItem.clauseRate ).format( this.rateFormat );
        if ( total != fireItem.clauseRate ) { // MYS-2018-0896 - Added this condition
            fireItem.clauseRate = numeral( total ).format( this.rateFormat );
            if ( this.fireObj.ratingFlag == 'M' || ( this.headerInfo.VPMSProduct != "Y" && this.headerInfo.firePostingScreen != "NEW" ) ) {
                this.setTotalForCover( fireItem );
            }
        }
    }

    resetClauseRate() {
        this.triggerMulSelListern();
        if ( this.headerInfo.VPMSProduct == "Y" || this.headerInfo.firePostingScreen == "NEW" ) { // SAF MYS-2018-1249 start
            this.resetTotal();
            if ( this.fireItems.fireItems.length > 0 ) {
                this.resetAllPremiumInfo( event, this.fireItems.fireItems );
            }
        } //End		
    }

    triggerMulSelListern() {
        this.multiSelectListern.value = new Date().getTime();
    }

    resetBasicRate( baseRate: number ) {
        this.setFeaRate();
        this.resetTotal();
    }

    resetPerilRate( perilRate: number ) {
        if ( this.headerInfo.VPMSProduct == "Y" || this.headerInfo.firePostingScreen == "NEW" ) { // SAF MYS-2018-1249 start
            this.triggerMulSelListern();
            this.resetTotal();
            if ( this.headerInfo.VPMSProduct == "Y" && this.fireItems.fireItems.length > 0 ) {
                this.resetAllPremiumInfo( event, this.fireItems.fireItems );
            }
        } else {
            this.resetTotal();
        }
        //End		
    }

    resetFEARate( feaPercent: number ) {
        this.resetTotal();
    }

    setCapitalSI() {
        this.fireObj.totalSI = this.getTotalByProperty( "sumInsured", this.fireItems.fireItems, null );
        if ( this.fireObj.accumulationRegister != "" && this.fireObj.accumulationRegister != "0" )
            this.callAccRegisterFunction();      
    }
    // AccRegister code --start
    private callAccRegisterFunction() {
        this._soapService.callCordysSoapService( "GetCurrentExposerAccuRegister", "http://schemas.insurance.com/businessobject/1.0/",
            {
                "caseID": BMSConstants.getBMSObj().ApplicationBusinessObject.caseInfo.caseId,
                "snedmail": "",
                "AccumulationReg": this.fireObj.accumulationRegister,
                "PostCode": this.fireObj.postCode,
                "LocationCode": this.fireObj.locality,
                "TotalSI": this.fireObj.totalSI,
                "Branch": BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.servicingBranch,
                "cslAmount": this.fireObj.cslAmount,
                "city": this.fireObj.city
            },
            this.setAccRegisterInfoSuccess, this.setAccRegisterInfoError, true, { comp: this } );
    }

    setAccRegisterInfoSuccess( response, prms ) {
        if ( !response.fault ) {
            prms.comp.fireObj.accRegister.ExposerQuotAccepted = response.ExposerQuotAccepted.text;
            prms.comp.fireObj.accRegister.HoldCoverExposer = response.HoldCoverExposer.text;
            prms.comp.fireObj.accRegister.GAL = response.GAL.text;
            prms.comp.fireObj.accRegister.P400InforcedExposer = response.P400InforcedExposer.text;
            prms.comp.fireObj.accRegister.TotalExposer = response.TotalExposer.text;
            prms.comp.fireObj.accRegister.Outstanding = response.Outstanding.text;
            prms.comp.fireObj.accRegister.cessionOutwords = response.cessionOutwords.text;

            // formatted values
            prms.comp.fireObj.accRegister.formattedExposerQuotAccepted = numeral( prms.comp.fireObj.accRegister.ExposerQuotAccepted ).format( "0,0.00" );
            prms.comp.fireObj.accRegister.formattedHoldCoverExposer = numeral( prms.comp.fireObj.accRegister.HoldCoverExposer ).format( "0,0.00" );
            prms.comp.fireObj.accRegister.formattedGAL = numeral( prms.comp.fireObj.accRegister.GAL ).format( "0,0.00" );
            prms.comp.fireObj.accRegister.formattedP400InforcedExposer = numeral( prms.comp.fireObj.accRegister.P400InforcedExposer ).format( "0,0.00" );
            prms.comp.fireObj.accRegister.formattedTotalExposer = numeral( prms.comp.fireObj.accRegister.TotalExposer ).format( "0,0.00" );
            prms.comp.fireObj.accRegister.formattedOutstanding = numeral( prms.comp.fireObj.accRegister.Outstanding ).format( "0,0.00" );
            prms.comp.fireObj.accRegister.formattedcessionOutwords = numeral( prms.comp.fireObj.accRegister.cessionOutwords ).format( "0,0.00" );

            prms.comp.accRegisterValidations();

        } else {
            prms.comp.fireObj.accRegister = new AccRegister();
            prms.comp._alertMsgService.add( new AlertMessage( AlertMessage.ERROR, "Error while Calling Accumulation Register service.", 8000 ) );
        }
    }

    setAccRegisterInfoError( response, status, errorText, prms ) {
        prms.comp.fireObj.accRegister = new AccRegister();
        prms.comp._alertMsgService.add( new AlertMessage( AlertMessage.ERROR, "Error while Calling Accumulation Register service.", 8000 ) );
    }

    accRegisterValidations() {
        this.fireObj.accRegister.totalPercentage = 0;
        if ( this.fireObj.accRegister.GAL != "0" && this.fireObj.accRegister.GAL != "" )
            this.fireObj.accRegister.totalPercentage = ( Number( this.fireObj.accRegister.TotalExposer ) * 100 ) / Number( this.fireObj.accRegister.GAL );
    } //AccRegister code --End

    resetSecNumber() {
        for ( let cover of this.fireItems.fireItems ) {
            let index = this.fireItems.fireItems.indexOf( cover );
            cover.itemNo = ( index + 1 );
            cover.seqNumber = ( index + 1 );
        }
    }

    setHoverForAllCover() {
        let allCovers = jQuery( this.el ).find( '[data-toggle="popover"]' );
        let indx = 0;
        for ( let eachCover of allCovers ) {
            if ( this.fireItems.fireItems[indx] != undefined )
                this.setHoverForCover( eachCover, this.fireItems.fireItems[indx].cover );
            indx++;
        }
    }

    setHoverForCover( elmnt, coverVal ) {
        jQuery( elmnt ).popover();
        jQuery( elmnt ).attr( "data-content", coverVal );
    }

    validateCover( fireItem ) {
        if ( this.isCoverExists( fireItem ) == true ) {
            fireItem.cover = "";
        }
    }

    isCoverExists( fireItem ) {
        let has = false;
        let idx = this.fireItems.fireItems.indexOf( fireItem );
        for ( let cover of this.fireItems.fireItems ) {
            let thisIdx = this.fireItems.fireItems.indexOf( cover );
            if ( cover.cover != null && fireItem.cover != null && cover.cover.toUpperCase() == fireItem.cover.toUpperCase() && idx != thisIdx ) {
                has = true;
                this._alertMsgService.add( new AlertMessage( AlertMessage.INFO, "Same cover is added already.", -1 ) );
                return has;
            }
        }
        return has;
    }

    validateRebate() {
        if ( isNaN( this.fireObj.rebate ) || isNaN( parseFloat( "" + this.fireObj.rebate ) ) ) {
            this.fireObj.rebate = 0;
            this._alertMsgService.add( new AlertMessage( AlertMessage.INFO, "Enter valid number", -1 ) );
        }
        else if ( this.fireObj.rebate < 0 || this.fireObj.rebate > 15 ) {
            this.fireObj.rebate = 0;
            this._alertMsgService.add( new AlertMessage( AlertMessage.INFO, "Rebate value must be between 0 to 15.", -1 ) );
        }
        this.setRebateGST();
    }

    setRebateGST() {
        this.fireObj.rebateAmount = numeral( numeral( ( parseFloat( "" + numeral( this.fireObj.originalTotalPremium ).value() ) * parseFloat( "" + this.fireObj.rebate ) ) / 100 ).format( this.premiumFormat ) ).value();
        let discountedPrem = numeral( numeral( parseFloat( "" + numeral( this.fireObj.originalTotalPremium ).value() ) - parseFloat( "" + numeral( this.fireObj.rebateAmount ).value() ) ).format( this.premiumFormat ) ).value();
        this.fireObj.discountedPremium = discountedPrem;
        //this.fireObj.gstAmount = (parseInt(this.fireObj.GST) > 0)?numeral(numeral((discountedPrem*parseInt(this.fireObj.GST))/100).format(this.premiumFormat)).value():0; //SAF MYS-2018-0629

        //SST Code
        let tempGSTAmount = ( parseInt( this.fireObj.GST + "" ) > 0 ) ? numeral( numeral( ( discountedPrem * parseInt( this.fireObj.GST + "" ) ) / 100 ).format( this.premiumFormat ) ).value() : 0;
        if ( ["MyTasks", "MyDrafts"].indexOf( this._activatedRoute.snapshot.params['component'] ) >= 0 || Object.keys( this._activatedRoute.snapshot.params ).length == 0 ) {
            this.fireObj.gstAmount = BMSUtilService.calculatePremiumAmount( tempGSTAmount, "G" );
        } else {
            this.fireObj.gstAmount = tempGSTAmount;
        }


        let tempSSTAmount = ( parseInt( this.fireObj.SST + "" ) > 0 ) ? numeral( numeral( ( discountedPrem * parseInt( this.fireObj.SST + "" ) ) / 100 ).format( this.premiumFormat ) ).value() : 0;
        if ( ["MyTasks", "MyDrafts"].indexOf( this._activatedRoute.snapshot.params['component'] ) >= 0 || Object.keys( this._activatedRoute.snapshot.params ).length == 0 ) {
            this.fireObj.sstAmount = BMSUtilService.calculatePremiumAmount( tempSSTAmount, "S" );
        } else {
            this.fireObj.sstAmount = tempSSTAmount;
        }

        //this.fireObj.totalPremium = parseFloat(""+numeral(discountedPrem).value()) + parseFloat(""+numeral(this.fireObj.gstAmount).value());
        this.fireObj.totalPremium = parseFloat( "" + numeral( discountedPrem ).value() ) + parseFloat( "" + numeral( this.fireObj.gstAmount ).value() ) + parseFloat( "" + numeral( this.fireObj.sstAmount ).value() ) + parseFloat( "" + numeral( this.fireItems.benefitPremium ).value() );

        //End
    }

    setBaseRateEnable( setIt ) {
        if ( this.fireObj.riskType != 'ECP' && this.fireObj.riskType != 'ARI' ) {

            if ( "Y" == setIt ) {
                this.bsRateCtrl.setDisable( "N", this.bsRateCtrl.comp );
            }
            else {
                this.bsRateCtrl.setDisable( "Y", this.bsRateCtrl.comp );
            }
        }
    }

    setBasicRate( bRate ) {
        if ( this.bsRateCtrl != null )
            this.bsRateCtrl.setter( bRate, this.bsRateCtrl.comp );
    }

    addXT( fireItem ) {
        if ( !fireItem.seqNumber ) fireItem.seqNumber = fireItem.itemNo;

        var dialogData = new ExtraTextDialogData( "ExtraTextDialogComponent", "app/bms/components/proposal/newbusinessrisks/dialogs/extratext.dialog.module", "ExtraTextDialogModule", "Extra Text", "ExtraText", "fa fa-comment", fireItem, this.extraTextCallBack );
        this.openExtraTextCommentsDialog( dialogData );
    }

    public openExtraTextCommentsDialog( dialogData: ExtraTextDialogData, response?: any ) {
        let lookup = new ModalInput();
        lookup.component = [dialogData.component, dialogData.moduleAbsPath, dialogData.moduleName];
        lookup.datainput = {
            dialogName: dialogData.dialogName,
            areCommentsMandatory: false,
            coverageItem: dialogData.coverageItem
        };
        lookup.outputCallback = dialogData.callBackHandler;
        lookup.parentCompPRMS = {
            comp: this,
            response: response
        };
        lookup.heading = dialogData.dialogTitle;
        lookup.icon = dialogData.icon;
        lookup.containerRef = this.contentArea;
        this.dcl.openLookup( lookup );
    }

    private extraTextCallBack( data, prms ) {
        if ( data.isDialogCancelled ) {
            return;
        } else if ( !data.isDialogCancelled && data.coverageItem && data.coverageItem.extraText ) {
        }
    }

    onPremiumClsChange( fireItem ) {
        let _selPrmCls = fireItem.premiumClass;
		/*if(this.fireObj.riskType=='ARI' && _selPrmCls == '18C'){ //commenting as mentioned in Redmine #2092
			let _fireItems = this.fireItems.fireItems.filter( (_item)=> _item.premiumClass === '18C');
			if( _fireItems && _fireItems.length > 1){				
				this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Premium Class: IND ALL RISK - LOSS OF PROFIT is not allowed to add more than once." , 5000));
			}
		}*/
    }

    // SAF MYS-2018-0666 start
    onChangeDDInfo( sumInsured, fireItem ) {
        if ( this.fireObj.deductible != undefined && this.fireObj.deductible != "" && sumInsured != undefined && sumInsured != 0 ) {
            if ( ["10", "11", "12"].indexOf( this.fireObj.PIAMCode.substring( 0, 2 ) ) >= 0 ) {
                this.getPremPercentage1( this.fireObj.deductible, fireItem );
            } else {
                this.getPremPercentage2( this.fireObj.deductible, fireItem );
            }
        }
    }

    getPremPercentage1( deductableVal, fireItem ) {
        let request: GetLOVData = new GetLOVData();
        request.BRANCH = 'ALL';
        request.LOB = 'FIRE';
        request.BUSINESS_FUNCTION = 'NEW BUSINESS';
        request.PRODUCT = 'ALL';
        request.OPERATION = 'NEW';
        request.FORM_NAME = 'FIRE';
        request.FORM_FIELD_NAME = 'GET_PREM_PERC1';
        request.FIELD_TYPE = 'LOV';
        request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        request.ADVANCE_CONFIG_XML.FILTERS = new Filter();
        request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push(
            { "@FIELD_NAME": 'Z.ZDDCT', "@FIELD_VALUE": deductableVal, '@OPERATION': 'EQ', '@CONDITION': 'AND' },
            { "@FIELD_NAME": 'Z.EFFDATE', "@FIELD_VALUE": moment( this.headerInfo.effectiveDate, "YYYY-MM-DD" ).format( "YYYYMMDD" ), '@OPERATION': 'LTEQ', '@CONDITION': 'AND' },
            { "@FIELD_NAME": 'Z.DTETER', "@FIELD_VALUE": moment( this.headerInfo.effectiveDate, "YYYY-MM-DD" ).format( "YYYYMMDD" ), '@OPERATION': 'GT', '@CONDITION': 'AND' }
        );
        this._soapService.callCordysSoapService( "GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.getPremPercentage1SuccessHandler, this.errorHandler, false, { comp: this, fireItm: fireItem } );
    }

    getPremPercentage1SuccessHandler( response, prms ) {
        if ( response.tuple ) {
            prms.fireItm.deductableRate = 0;
            for ( let i = 0; i < response.tuple.length; i++ ) {
                if ( parseFloat( "" + response.tuple[i].old.ZDC1PF.SUMINSURED ) == parseFloat( "" + prms.fireItm.sumInsured ) ) {
                    prms.fireItm.deductableRate = parseFloat( "" + parseFloat( "" + response.tuple[i].old.ZDC1PF.RATE ) / 100 );
                    break;
                } else if ( parseFloat( "" + prms.fireItm.sumInsured ) >= parseFloat( "" + response.tuple[i].old.ZDC1PF.SUMINSURED ) && parseFloat( "" + prms.fireItm.sumInsured ) < parseFloat( "" + response.tuple[i + 1].old.ZDC1PF.SUMINSURED ) ) {
                    prms.fireItm.deductableRate = ( parseFloat( "" + response.tuple[i].old.ZDC1PF.RATE ) > parseFloat( "" + response.tuple[i + 1].old.ZDC1PF.RATE ) ) ? parseFloat( "" + parseFloat( "" + response.tuple[i].old.ZDC1PF.RATE ) / 100 ) : parseFloat( "" + parseFloat( "" + response.tuple[i].old.ZDC1PF.RATE ) / 100 );
                    break;
                }
            }
        }
    }

    getPremPercentage2( deductableVal, fireItem ) {
        let request: GetLOVData = new GetLOVData();
        request.BRANCH = 'ALL';
        request.LOB = 'FIRE';
        request.BUSINESS_FUNCTION = 'NEW BUSINESS';
        request.PRODUCT = 'ALL';
        request.OPERATION = 'NEW';
        request.FORM_NAME = 'FIRE';
        request.FORM_FIELD_NAME = 'GET_PREM_PERC2';
        request.FIELD_TYPE = 'LOV';
        request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        request.ADVANCE_CONFIG_XML.FILTERS = new Filter();
        request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push(
            { "@FIELD_NAME": 'Z.ZDDCT', "@FIELD_VALUE": deductableVal, '@OPERATION': 'EQ', '@CONDITION': 'AND' },
            { "@FIELD_NAME": 'Z.EFFDATE', "@FIELD_VALUE": moment( this.headerInfo.effectiveDate, "YYYY-MM-DD" ).format( "YYYYMMDD" ), '@OPERATION': 'LTEQ', '@CONDITION': 'AND' },
            { "@FIELD_NAME": 'Z.DTETER', "@FIELD_VALUE": moment( this.headerInfo.effectiveDate, "YYYY-MM-DD" ).format( "YYYYMMDD" ), '@OPERATION': 'GT', '@CONDITION': 'AND' }
        );
        this._soapService.callCordysSoapService( "GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.getPremPercentage2SuccessHandler, this.errorHandler, false, { comp: this, fireItm: fireItem } );
    }

    getPremPercentage2SuccessHandler( response, prms ) {
        if ( response.tuple ) {
            prms.fireItm.deductableRate = 0;
            for ( let i = 0; i < response.tuple.length; i++ ) {
                if ( parseFloat( "" + response.tuple[i].old.ZDC2PF.SUMINSURED ) == parseFloat( "" + prms.fireItm.sumInsured ) ) {
                    prms.fireItm.deductableRate = parseFloat( "" + parseFloat( "" + response.tuple[i].old.ZDC2PF.RATE ) / 100 );
                    break;
                } else if ( parseFloat( "" + prms.fireItm.sumInsured ) >= parseFloat( "" + response.tuple[i].old.ZDC2PF.SUMINSURED ) && parseFloat( "" + prms.fireItm.sumInsured ) < parseFloat( "" + response.tuple[i + 1].old.ZDC2PF.SUMINSURED ) ) {
                    prms.fireItm.deductableRate = ( parseFloat( "" + response.tuple[i].old.ZDC2PF.RATE ) > parseFloat( "" + response.tuple[i + 1].old.ZDC2PF.RATE ) ) ? parseFloat( "" + parseFloat( "" + response.tuple[i].old.ZDC2PF.RATE ) / 100 ) : parseFloat( "" + parseFloat( "" + response.tuple[i].old.ZDC2PF.RATE ) / 100 );
                    break;
                }
            }
        }
    }

    errorHandler( response, status, errorText, prms ) {
        prms.comp._alertMsgService.add( new AlertMessage( AlertMessage.ERROR, response.responseJSON.faultstring.text, -1 ) );
    }
    //End

    // SAF MYS-2018-1249 start
    setPerilRate( selectedPerilDetail: PerilDetail[], fireItem ) {
        let total = 0;
        for ( let clauseDetail of selectedPerilDetail ) {
            total = total + ( ( clauseDetail.perilRate != "" ) ? parseFloat( clauseDetail.perilRate ) : 0 );
        }
        fireItem.perilRate = numeral( fireItem.perilRate ).format( this.rateFormat );
        if ( !isNaN( total ) && total != fireItem.perilRate ) {
            fireItem.perilRate = numeral( total ).format( this.rateFormat );
            if ( this.headerInfo.VPMSProduct != "Y" || this.fireObj.ratingFlag == 'M' ) {
                this.setTotalForCover( fireItem );
            }
        }
    }

    onClickPerilItem( selectedPerilItem, fireItem, perilCodes ) {
        let elmnt: any = selectedPerilItem.target;
        if ( elmnt.value != undefined && elmnt.value != "" ) {
            let selectedItem: PerilDetail = perilCodes.find( _item => _item.perilCode == elmnt.value );
            if ( selectedItem != undefined && selectedItem.perilCode == elmnt.value && elmnt.checked == true ) {
                selectedItem.nominatedSumInsured = numeral( selectedItem.nominatedSumInsured ).value() + numeral( fireItem.sumInsured ).value();
                selectedItem.nominatedSumInsuredNew = selectedItem.nominatedSumInsured;
                if ( selectedItem.coverItems == undefined || selectedItem.coverItems.toString() == "" ) {
                    selectedItem.coverItems = [];
                } else if ( !Array.prototype.isPrototypeOf( selectedItem.coverItems ) ) {
                    let temp: any = [selectedItem.coverItems];
                    selectedItem.coverItems = temp;
                }
                selectedItem.coverItems.push( fireItem.itemNo.toString() );
            } else if ( selectedItem != undefined && selectedItem.perilCode == elmnt.value && elmnt.checked == false ) {
                let tempSI = ( numeral( selectedItem.nominatedSumInsured ).value() != numeral( selectedItem.nominatedSumInsuredNew ).value() ) ? numeral( selectedItem.nominatedSumInsuredNew ).value() : numeral( selectedItem.nominatedSumInsured ).value();
                if ( tempSI > 0 ) {
                    selectedItem.nominatedSumInsured = numeral( tempSI ).value() - numeral( fireItem.sumInsured ).value();
                    selectedItem.nominatedSumInsuredNew = selectedItem.nominatedSumInsured;
                }
                selectedItem.coverItems = ( selectedItem.coverItems == undefined || selectedItem.coverItems.toString() == "" ) ? [] : selectedItem.coverItems;
                if ( !Array.prototype.isPrototypeOf( selectedItem.coverItems ) ) {
                    let temp: any = [selectedItem.coverItems];
                    selectedItem.coverItems = temp;
                }
                selectedItem.coverItems = selectedItem.coverItems.filter( ( item ) => item != fireItem.itemNo );
            }
            if ( this.headerInfo.VPMSProduct != "Y" || this.fireObj.ratingFlag == 'M' ) {
                selectedItem.amount = ( numeral( selectedItem.nominatedSumInsured ).value() > 0 ) ? numeral( ( numeral( selectedItem.nominatedSumInsured ).value() * parseFloat( selectedItem.perilRate ) ) / 100 ).format( this.premiumFormat ) : 0;
            } else {
                selectedItem.amount = numeral( 0 ).format( this.premiumFormat );
            }
            selectedItem.unFormattedAmount = numeral().unformat( selectedItem.amount );
            if ( this.headerInfo.VPMSProduct == "Y" && this.fireObj.ratingFlag != 'M' ) {
                this.fireItems.fireItems.forEach( item => {
                    item.rate = numeral( 0 ).format( this.premiumFormat );
                    item.premium = numeral( 0 ).format( this.premiumFormat );
                    this.setPremium( item );
                } );
            }
        }
    }
    resetClausesInfo( coverSI: number, fireItem ) {
        this._alertMsgService.add( new AlertMessage( AlertMessage.INFO, "Cover " + fireItem.itemNo + " - Sum Insured has been changed and All Clauses's data will be refereshed.", 5000 ) );
        if ( this.fireObj.riskType != "LOP" && ( this.headerInfo.VPMSProduct == "Y" || this.headerInfo.firePostingScreen == "NEW" ) ) {
            this.clearAllClausesData( "SIChanged" );
        }
        this.resetTotal();
    }

    resetWCRate( wcRate: number ) {
        this.resetTotal();
        if ( this.fireItems.fireItems.length > 0 ) {
            this.resetAllPremiumInfo( event, this.fireItems.fireItems );
        }
    }

    onClickRCItem( selectedRCItem, fireItem, rcCodes ) {
        let elmnt: any = selectedRCItem.target;
        if ( elmnt.value != undefined && elmnt.value != "" ) {
            let selectedItem: RateableClassCodeDetail = rcCodes.find( _item => _item.classCode == elmnt.value );
            if ( selectedItem != undefined && selectedItem.classCode == elmnt.value && elmnt.checked == true ) {
                selectedItem.nominatedSumInsured = numeral( selectedItem.nominatedSumInsured ).value() + numeral( fireItem.sumInsured ).value();
                selectedItem.nominatedSumInsuredNew = selectedItem.nominatedSumInsured;
                if ( selectedItem.coverItems == undefined || selectedItem.coverItems.toString() == "" ) {
                    selectedItem.coverItems = [];
                } else if ( !Array.prototype.isPrototypeOf( selectedItem.coverItems ) ) {
                    let temp: any = [selectedItem.coverItems];
                    selectedItem.coverItems = temp;
                }
                selectedItem.coverItems.push( fireItem.itemNo.toString() );
            } else if ( selectedItem != undefined && selectedItem.classCode == elmnt.value && elmnt.checked == false ) {
                let tempSI = ( numeral( selectedItem.nominatedSumInsured ).value() != numeral( selectedItem.nominatedSumInsuredNew ).value() ) ? numeral( selectedItem.nominatedSumInsuredNew ).value() : numeral( selectedItem.nominatedSumInsured ).value();
                if ( tempSI > 0 ) {
                    selectedItem.nominatedSumInsured = numeral( tempSI ).value() - numeral( fireItem.sumInsured ).value();
                    selectedItem.nominatedSumInsuredNew = selectedItem.nominatedSumInsured;
                }
                selectedItem.coverItems = ( selectedItem.coverItems == undefined || selectedItem.coverItems.toString() == "" ) ? [] : selectedItem.coverItems;
                if ( !Array.prototype.isPrototypeOf( selectedItem.coverItems ) ) {
                    let temp: any = [selectedItem.coverItems];
                    selectedItem.coverItems = temp;
                }
                selectedItem.coverItems = selectedItem.coverItems.filter( ( item ) => item != fireItem.itemNo );
            }
            if ( this.headerInfo.VPMSProduct != "Y" || this.fireObj.ratingFlag == 'M' ) {
                selectedItem.amount = ( selectedItem != undefined && numeral( selectedItem.nominatedSumInsured ).value() > 0 ) ? numeral( ( numeral( selectedItem.nominatedSumInsured ).value() * parseFloat( selectedItem.rate ) ) / 100 ).format( this.premiumFormat ) : 0;
            } else {
                selectedItem.amount = numeral( 0 ).format( this.premiumFormat );
            }
            selectedItem.unFormattedAmount = numeral().unformat( selectedItem.amount );
            if ( this.headerInfo.VPMSProduct == "Y" && this.fireObj.ratingFlag != 'M' ) {
                this.fireItems.fireItems.forEach( item => {
                    item.rate = numeral( 0 ).format( this.premiumFormat );
                    item.premium = numeral( 0 ).format( this.premiumFormat );
                    this.setPremium( item );
                } );
            }
        }
    }

    public getQuote() {
        if ( this.validateFireItems() ) {
            ProgressBarComponent.show( 'Premium Calculation is in Progress', { dialogSize: 'm', progressType: 'primary' } );
            this._appObjService.saveData().subscribe( ( data ) => this.calculate( this.fireObj ) );
        }
    }

    public calculate( eachRisk ) {
        let caseID = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.caseId;
        let respProm = this._soapService.callCordysSoapService( "CalculatePremiumProcessFireVPMS", "http://schemas.insurance.com/businessobject/1.0/",
            { caseId: caseID, riskno: eachRisk.riskNumber, requestType: "", vpmsReqId: "0" }
            , null, null, true, null );
        respProm.success( ( response ) => {
            let caseInfo = BMSConstants.getBMSCaseInfo();
            caseInfo.lastModifiedOn = response.success.ApplicationBusinessObject.caseInfo.lastModifiedOn;
            //eachRisk = response.success.ApplicationBusinessObject.businessObject.bms.newBusiness.risks.fireIDC;
            let tempRiskObjs = response.success.ApplicationBusinessObject.businessObject.bms.newBusiness.risks.fireIDC;//BMSConstants.getRisks().getRisksByPriority();
            let currentObj: FireIDC;
            if ( tempRiskObjs.length > 1 ) {
                for ( let i = 0; i < tempRiskObjs.length; i++ ) {
                    if ( tempRiskObjs[i].riskNumber == eachRisk.riskNumber ) {
                        currentObj = tempRiskObjs[i];
                        break;
                    }
                }
            } else {
                currentObj = response.success.ApplicationBusinessObject.businessObject.bms.newBusiness.risks.fireIDC;
            }
            this.fireObj = this.fireObj.refershRiskObj( currentObj );

            this.fireObj.fireItems = this.fireObj.fireItems.refreshFireItem( this.fireObj.fireItems );
            this.fireItems = this.fireObj.fireItems.refreshFireItem( this.fireObj.fireItems );//new

            if ( JSON.stringify( this.fireObj.fireItems ) != JSON.stringify( "" ) && this.fireObj.fireItems.fireItems != undefined ) {
                for ( let i = 0; i < this.fireObj.fireItems.fireItems.length; i++ ) {
                    this.fireObj.clauses = this.fireObj.clauses.refreshClause( this.fireObj.clauses );
                    //this.setPremium(this.fireItems.fireItems[i]);
                    this.fireObj.totalSI = this.getTotalByProperty( "sumInsured", this.fireItems.fireItems, null );

                    //SAF MYS-2019-0909
                    if ( this.fireObj.isValidBenefitPlan != undefined && this.fireObj.isValidBenefitPlan == "Y" ) {
                        this.fireObj.totalSI = numeral( parseFloat( this.fireObj.totalSI + "" ) + parseFloat( this.fireItems.benefitSI + "" ) ).value();
                    }
                    //End
                    this.resetTotal();
                }
            }
            this._appObjService.saveData().subscribe( ( data ) => this._alertMsgService.add( new AlertMessage( AlertMessage.SUCCESS, "Premium Calculation is completed.", 5000 ) ) );
            ProgressBarComponent.hide();
        } );
        respProm.error( ( error ) => {
            this._alertMsgService.add( new AlertMessage( AlertMessage.ERROR, "Premium Calculation service is down. Error occurred while getting premium calculation info.", -1 ) );
            
            ProgressBarComponent.hide();
        } );
    }

    resetAllPremiumInfo( event, fireItem ) {
        if ( this.headerInfo.VPMSProduct == "Y" && this.fireObj.ratingFlag != 'M' ) {
            this._alertMsgService.add( new AlertMessage( AlertMessage.WARN, "Fire Cover Related Item data has been modified, please click on GetQuotation button and proceed.", 5000 ) );
            this.fireItems.fireItems.forEach( item => {
                item.rate = numeral( 0 ).format( this.premiumFormat );
                item.premium = numeral( 0 ).format( this.premiumFormat );
                this.setPremium( item );
                let _peril: Peril = new Peril;
                item.perilClassCodes = _peril.refreshPerils( item.perilClassCodes );
                let _rateableClause: RateableClassCode = new RateableClassCode;
                item.rateableClassCodes = _rateableClause.refreshRateableClassCode( item.rateableClassCodes );
                let _wcClause: WarrantyClassCode = new WarrantyClassCode;
                item.wcClassCodes = _wcClause.refreshWarrantyClassCodes( item.wcClassCodes );
            } );
            this.fireObj.totalPremium = 0;
            this.fireObj.totalSI = 0;
            this.clearAllClausesData( "ClearAll" );
        }
        if ( this.headerInfo.firePostingScreen == "NEW" ) {
            this.clearAllClausesData( "SIChanged" );
            this.fireObj.totalSI = this.getTotalByProperty( "sumInsured", this.fireItems.fireItems, null );
            if ( fireItem == "" && this.fireItems.fireItems.length > 0 ) {
                fireItem = this.fireItems.fireItems[0];
            } else {
                fireItem = new FireItem();
            }
            this.setPremium( fireItem );
            this.resetTotal();
        }
    }

    validateFireItems() {
        let isValid: boolean = true;
        let message: string = "";
        this.fireItems.fireItems.forEach( item => {
            if ( item.premiumClass == undefined || item.premiumClass == "" ) {
                isValid = false;
                message = "Please select Premium class for added covers and proceed."
                return isValid;
            }
        } );
        if ( !isValid && message.length > 0 ) {
            this._alertMsgService.add( new AlertMessage( AlertMessage.ERROR, message, 10000 ) );
        }
        return isValid;
    }
    //Start E1001
    setBasicRateValue(){
        this.fireObj.basicRate = 0;
    }
    //End E1001

    //End

    //SAF MYS-2019-0909
    onAddonPlanChange( ev ) {        
        if ( ev.value != undefined && ev.value != "" ) {
            this.fireItems.addOnBenefitCode = ev.value;
            this.fireItems.benefitSI = ev.record.ZLIMIT;
            this.fireItems.benefitPremiumClass = ev.record.ZPREMCL;
            this.fireItems.benefitPremium = 0;

            this.validateBenfitwithPIAM();
        } else {
            this.fireItems.addOnBenefitCode = "";
            this.fireItems.benefitSI = 0;
            this.fireItems.benefitPremiumClass = "";  
            this.fireItems.benefitPremium = 0;
        }

        this.resetAllPremiumInfo( event, this.fireItems.fireItems );
    }
    
    validateBenfitwithPIAM() {
        let filters = [
            { "@FIELD_NAME": 'DESCITEM', "@FIELD_VALUE": this.fireObj.PIAMCode, '@OPERATION': 'EQ', '@CONDITION': 'AND' }
        ]; 
        let request: GetLOVData = new GetLOVData().getLovRequest( "ALL", "FIRE", "NEW BUSINESS", "ALL", "NEW", "FIRE", "Fire_AddonPIAMcodes", "LOV", filters, {}, null );
        this._soapService.callCordysSoapService( "GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.validateBenfitSuccessHandler, this.errorHandler, true, { comp: this } );
    }

    validateBenfitSuccessHandler( response, prms ) {
        if ( !response.tuple ) {
            prms.comp._alertMsgService.add( new AlertMessage( AlertMessage.INFO, "Selected Benefit code " + prms.comp.fireItems.addOnBenefitCode + " is not valid for PIAM code" + prms.comp.fireObj.PIAMCode + ".", 10000 ) );

            prms.comp.isValidBenefitPlan = "N";
            prms.comp.fireItems.addOnBenefitCode = "";
            prms.comp.fireItems.benefitSI = 0;
            prms.comp.fireItems.benefitPremiumClass = "";  
        } else {
            prms.comp.isValidBenefitPlan = "Y";
        }
    }
    
    //End
}