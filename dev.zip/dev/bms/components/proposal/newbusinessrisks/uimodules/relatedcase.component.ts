import { Component, OnInit, EventEmitter, ViewChild, ViewContainerRef } from "@angular/core";
import { FireRelatedCases } from "../appobjects/relatedCase";
import { DCLInput, CustomDCLService } from '../../../../../common/services/customdcl.service';
import { SearchInput } from "../../../../../common/components/utility/search/genericsearch";
import { ProposalHeader } from '../../proposalheader/appobjects/proposalheader';
import { AlertMessagesService } from '../../../../../common/components/utility/alertmessage/alertmessages.service';
import { AlertMessage } from '../../../../../common/components/utility/alertmessage/alertmessages.model';
import { ModalInput } from "../../../../../common/components/utility/modal/modal";

declare var moment: any;
declare var numeral: any;

@Component({
    selector: 'relatedcase-comp',
    templateUrl: 'app/bms/components/proposal/newbusinessrisks/uimodules/relatedcase.template.html',
    inputs: ["_firRelatedCases", "_accumulationRegister", "headerInfo"],
    outputs: ["onlistupdate"]
})

export class RelatedCaseComponent implements OnInit {
    public _firRelatedCases: FireRelatedCases;
    public _accumulationRegister: string;
    public headerInfo: ProposalHeader;

    onlistupdate = new EventEmitter<any>();
    @ViewChild('relatedCaseModal', { read: ViewContainerRef }) contentArea: ViewContainerRef;

    constructor(public dcl: CustomDCLService, public _alertMsgService: AlertMessagesService) { }

    ngOnInit() {

    }

    openCaseList() {
        if (this._accumulationRegister != null && this._accumulationRegister != "") {
            let searchInput = new SearchInput();
            searchInput.isSingleSelect = false;
            searchInput.BRANCH = 'ALL';
            searchInput.BUSINESS_FUNCTION = 'NEW BUSINESS';
            searchInput.FIELD_TYPE = 'LOOKUP';
            searchInput.FORM_FIELD_NAME = 'RelatedCasePolicy';
            searchInput.FORM_NAME = 'FIRE';
            searchInput.LOB = 'FIRE';
            searchInput.OPERATION = 'ALL';
            searchInput.PRODUCT = 'FIRE';

            let newArr = [this.headerInfo.caseId];
            for (let item of this._firRelatedCases.relatedCases.relatedCase) {
                newArr.push(item["id"]);
            }
            let relatedIds = "'" + newArr.join("', '") + "'";
            searchInput.condition = { "FREG": this._accumulationRegister, "CHDRNO": relatedIds, "CASE_ID": relatedIds, "DTETER": this.headerInfo.effectiveDate.replace(/-/g, "") };

            let input = new ModalInput();
            input = input.get("GenericSearchComponent");
            input.datainput = searchInput;
            input.outputCallback = this.addCaseCallBack;
            input.parentCompPRMS = { comp: this };
            input.heading = "Related Cases";
            input.icon = "fa fa-link";
            input.containerRef = this.contentArea;
            this.dcl.openLookup(input);
        }
        else {
            this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Select accumulation register before adding case.", -1));
        }
    }

    addCaseCallBack(listOfCases, prms) {
        for (let eachCase of listOfCases) {
            let obj: any;
            if (prms.View == "RelatedCaseLocal") {
                obj = eachCase.old.FIRE_CASE_DETAILS;
            } else {
                obj = eachCase.old.WFIRPF; // fixed issue 801
            }
            prms.comp._firRelatedCases.relatedCases.relatedCase.push({
                id: obj.CHDRNO,
                riskType: obj.RSKTYP,
                producerCode: obj.ZPRODUCER,
                inceptionDate: obj.DTEEFF,
                endDate: obj.DTETER,
                riskNumber: obj.RSKNO,
                sumInsured: obj.TOTSI,
                accountHandlerName: obj.ACC_HANDLER_NAME
            });
        }
        prms.comp.emitTotal();
    }

    emitTotal() {
        let totalSI = this.getTotalByProperty("sumInsured", this._firRelatedCases.relatedCases.relatedCase)
        this._firRelatedCases.sumInsured = totalSI;
        this.onlistupdate.emit(totalSI);
    }

    removeCase(idx: number) {
        this._firRelatedCases.relatedCases.relatedCase.splice(idx, 1);
        this.emitTotal();
    }

    setAccumulationRegister(accReg: string) {
        this._accumulationRegister = accReg;
        this.removeAllCases();
    }

    getTotalByProperty(prop, ary) {
        let total: any = numeral(0);
        for (let eachItem of ary) {
            if (eachItem[prop] != null && eachItem[prop] != "") {
                total = numeral(total).add(numeral(eachItem[prop]));
            }
        }
        return total.value();
    }

    removeAllCases() {
        this._firRelatedCases.relatedCases.relatedCase = [];
        this.emitTotal();
    }
}