/*
 * Change History:
 * 
 * No      Date          Description                                         Changed By
 * ====    ==========    ===========                                         ==========
 * GA001   01/10/2018    MYS-2018-0443 - Age Checking for PA Products (T7253)    KGA					   
 * GA002    11/09/2019      MYS-2019-0974 - BMS Enhancement on High Risk Vehicle & Client       KGA
*/
import { Component, OnInit, ViewChild, ViewContainerRef } from '@angular/core';
import { DCLInput, CustomDCLService } from '../../../../../common/services/customdcl.service';
import { LOV_Field, LOVDropDownService, SearchFilter } from "../../../../../common/services/lovdropdown/lovdropdown.service";
import { AlertMessagesService } from '../../../../../common/components/utility/alertmessage/alertmessages.service';
import { AlertMessage } from '../../../../../common/components/utility/alertmessage/alertmessages.model';
import { ModalInput } from '../../../../../common/components/utility/modal/modal';
import { Insured, InsuredDetails } from "../appobjects/insuredlist";
import { BMSConstants } from '../../../common/constants/bms_constants';
//GA001 START
import { ReferralReasons, ReferralReason } from '../appobjects/referralReasons';
import { ReferredReason, Reasons } from '../../proposalheader/appobjects/referredreason';
import { GetLOVData, SearchAdvancedConfig, Filter } from '../../../../../common/components/utility/search/search.requests';
import { CordysSoapWService } from "../../../../../common/components/utility/cordys-soap-ws";
import { RiskClassificationService } from "../services/riskcls.service";
import { HighRiskIndReason, ProposalHeader } from '../../proposalheader/appobjects/proposalheader';//GA002
//GA001 END

declare var moment: any;

@Component({
    selector: 'insured-details-component',
    templateUrl: 'app/bms/components/proposal/newbusinessrisks/uimodules/insured.template.html',
    inputs: ["_insuredDetailsList", "riskObj"],
    providers: [RiskClassificationService]
})
export class InsuredComponent implements OnInit {

    private isCollapsedMode: boolean = false;
    public _insuredDetailsList: InsuredDetails;
    public riskObj: any;
    private referralReasons = [];//GA001

    @ViewChild('insured', { read: ViewContainerRef }) contentArea: ViewContainerRef;

    constructor(public dcl: CustomDCLService, private lovDropDownService: LOVDropDownService, public _alertMsgService: AlertMessagesService, private _cordysService: CordysSoapWService, public riskClassificationService: RiskClassificationService) { }

    ngOnInit(): any {
        this.populateLOVs();
    }

    openInsuredDetailsDialog() {
        // this.riskObj = BMSConstants.getSelectedRiskObj();
        let _allowAddInsured: boolean = true;
        if (this.riskObj && (this.riskObj.riskType == 'TAA' || this.riskObj.riskType == 'TDA' || this.riskObj.riskType == 'TDI' || this.riskObj.riskType == 'TPI')) {
            let _noOfAdults = (this.riskObj.noOfAdults == null || this.riskObj.noOfAdults == "") ? 0 : parseFloat("" + this.riskObj.noOfAdults);
            let _noOfChildren = (this.riskObj.noOfChildren == null || this.riskObj.noOfChildren == "") ? 0 : parseFloat("" + this.riskObj.noOfChildren);

            if (!((_noOfAdults > 0 || _noOfChildren > 0) && this._insuredDetailsList.insured.length < (_noOfAdults + _noOfChildren))) {
                _allowAddInsured = false;
            }
        }

        if (_allowAddInsured) {

            let lookup = new ModalInput();
            lookup.component = ["InsuredDetailsDialogComponent", "app/bms/components/proposal/newbusinessrisks/dialogs/insuredDetailDialog.module", "InsuredDetailsDialogModule"];
            lookup.outputCallback = this.addInsured;
            lookup.datainput = { isNew: true, insuredAry: this._insuredDetailsList };
            lookup.parentCompPRMS = { comp: this };
            lookup.heading = "Insured Details";
            lookup.icon = "fa fa-user";
            lookup.containerRef = this.contentArea;
            this.dcl.openLookup(lookup);
        } else {
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "No of Adults and Children limit exceeded", 3000));
        }
    }

    viewInsuredDetailDialog(idx: number) {
        let lookup = new ModalInput();
        lookup.component = ["InsuredDetailsDialogComponent", "app/bms/components/proposal/newbusinessrisks/dialogs/insuredDetailDialog.module", "InsuredDetailsDialogModule"];
        let selectedInsured = this._insuredDetailsList.insured[idx];
        lookup.datainput = { isView: true, selectedInsured, insuredAry: this._insuredDetailsList, editItem: idx };
        lookup.outputCallback = this.updateInsured;
        lookup.parentCompPRMS = { comp: this };
        lookup.heading = "Insured Details";
        lookup.icon = "fa fa-user";
        lookup.containerRef = this.contentArea;
        this.dcl.openLookup(lookup);
    }

    updateInsured(returnPrms, prms) {
        //prms.comp._insuredDetailsList.insured[returnPrms.editItem] = returnPrms.insured;  
        let flag = prms.comp.validateReferredRisk(returnPrms.insured);//GA001
        if ("L" == flag) {
            //prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Insured Age Less than minimum allowed age", -1));
            return;
        } else {
            //GA001 START
            let headerInfo = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo;
            if (headerInfo.isHighRiskApplicable) {
                let OldInsured = prms.comp._insuredDetailsList.insured[returnPrms.editItem];
                prms.comp.removeHighRiskValidation(prms.comp,OldInsured,prms.comp.riskObj);
                let headerInfo = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo;
                let effectiveDate = "";
                let endDate = "";
                if( headerInfo.effectiveDate!=undefined && headerInfo.effectiveDate!=""
                    && moment(headerInfo.effectiveDate).format("YYYYMMDD") != "Invalid date"){
                    effectiveDate = moment(headerInfo.effectiveDate).format("YYYYMMDD")
                }
                if( headerInfo.endDate!=undefined && headerInfo.endDate!=""
                    && moment(headerInfo.endDate).format("YYYYMMDD") != "Invalid date"){
                    endDate = moment(headerInfo.endDate).format("YYYYMMDD")
                }
                prms.comp.checkHighRiskClient(returnPrms.insured,effectiveDate,endDate,prms,"edit",returnPrms.editItem);
            }else{
                prms.comp._insuredDetailsList.insured[returnPrms.editItem] = returnPrms.insured;
            }
            //GA001 END
        }
    }

    removeInsured(idx: number) {
        //GA002 START
        let headerInfo = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo;
        if (headerInfo.isHighRiskApplicable) {
            this.removeHighRiskValidation(this,this._insuredDetailsList.insured[idx],this.riskObj);
        }
        //GA002 END
        this._insuredDetailsList.insured.splice(idx, 1);
        this.resetItemNumber();
        this.validateReferredRisk(this._insuredDetailsList.insured[idx]);//GA001
    }

    addInsured(insured, prms) {
        //insured.itemNo = prms.comp._insuredDetailsList.insured.length + 1;
        //prms.comp._insuredDetailsList.insured.push(insured);
        let flag = prms.comp.validateReferredRisk(insured);//GA001
        if ("L" == flag) {
            //prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Insured Age Less than minimum allowed age", -1));
            return;
        } else {
            //GA002 START
            let headerInfo = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo;
            if (headerInfo.isHighRiskApplicable) {
                let effectiveDate = "";
                let endDate = "";
                if( headerInfo.effectiveDate!=undefined && headerInfo.effectiveDate!=""
                    && moment(headerInfo.effectiveDate).format("YYYYMMDD") != "Invalid date"){
                    effectiveDate = moment(headerInfo.effectiveDate).format("YYYYMMDD")
                }
                if( headerInfo.endDate!=undefined && headerInfo.endDate!=""
                    && moment(headerInfo.endDate).format("YYYYMMDD") != "Invalid date"){
                    endDate = moment(headerInfo.endDate).format("YYYYMMDD")
                }
                prms.comp.checkHighRiskClient(insured,effectiveDate,endDate,prms,"add",-1);
            }else{
                insured.itemNo = prms.comp._insuredDetailsList.insured.length + 1;
                prms.comp._insuredDetailsList.insured.push(insured);
            }
           //GA002 END
        }
    }

    resetItemNumber() {
        for (let _insured of this._insuredDetailsList.insured) {
            let index = this._insuredDetailsList.insured.indexOf(_insured);
            _insured.itemNo = (index + 1);
        }
    }

    private populateLOVs(): void {
        //GA001 START
        this.lovDropDownService.createLOVDataList(["Occupation", "Gender", "referralReasons", "referralAgeLimits"]);//ADDED ("referralReasons", "referralAgeLimits")
        let riskFilter = (this.riskObj.riskType.length == 2) ? this.riskObj.riskType + ' ' : this.riskObj.riskType;
        let referralAgeLimitNodes = this.lovDropDownService.createFilter([new SearchFilter("DESCITEM", riskFilter, "EQ", "AND")]);
        //GA001 END

        //this.lovDropDownService.createLOVDataList(["Occupation","Gender"]);
        let lovFields = [
            new LOV_Field("ALL", "MOTOR", "NEW BUSINESS", "ALL", "NEW", "NAMED_DRIVER", "Occupation", "LOV", [], "DESCPF", "Occupation", "callbackOccupationCodes"),
            new LOV_Field("ALL", "ALL", "CLAIMS", "ALL", "ALL", "ALL", "Gender", "LOV", [], "DESCPF", "Gender", null),
            new LOV_Field("ALL", "MED", "ALL", "ALL", "ALL", "ALL", "Referral Reasons", "LOV", [], "DESCPF", "referralReasons", "callbackForReferralReasons"),
            new LOV_Field("ALL", "MED", "ALL", "ALL", "ALL", "ALL", "Referral Age Limits", "LOV", referralAgeLimitNodes, "T7253", "referralAgeLimits", "callbackForReferralAgeLimit")
        ];//GA001 ADDED ("referralReasons", "referralAgeLimits")
        this.lovDropDownService.util_populateLOV(lovFields, this);
    }

    private callbackOccupationCodes(scopeObject) {
        for (let _insured of scopeObject._insuredDetailsList.insured) {
            if (_insured.occupationCode && !_insured.occupationDescription) {
                let _occRecord = scopeObject.lovDropDownService.lovDataList.Occupation.filter(_item => _item.VALUE == _insured.occupationCode);
                if (_occRecord && _occRecord.length > 0) {
                    _insured.occupationDescription = _occRecord[0].DESCRIPTION.slice(0, 40);
                }
            }
        }
    }

    //GA001 START
    validateReferredRisk(insured) {
        let caseInfo = BMSConstants.getBMSCaseInfo();
        let headerInfo = BMSConstants.getBMSHeaderInfo();
        let _ageLimitRec = this.lovDropDownService.lovDataList.referralAgeLimits.find((_data) => _data.DESCITEM == this.riskObj.riskType);
        this.checkReferredRiskConditions(this.riskObj, headerInfo.contractType, _ageLimitRec, this.lovDropDownService.lovDataList.Occupation, this.lovDropDownService.lovDataList.referralReasons, this.referralReasons, insured, caseInfo);

        if (insured.ageLimitFlag == "G") {
            this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Insured age is exceeded maximum age.", 6000));
        }
        else if (insured.ageLimitFlag == "L") {
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Insured age is less than minimum age.", -1));
            //return insured.ageLimitFlag;
        }

        this.handleRiskClassification(this);

        return insured.ageLimitFlag;
    }

    checkReferredRiskConditions(riskObj, contractType, _ageLimitRec, occCodeList, referralReasonList, selectableReasonsList, insuredObj, caseInfo) {
        let _reasons = new Reasons();
        let isReferredRisk = false;
        let isDeclinedRisk = false;

        // if(contractType=='HIG'){
        // isReferredRisk = true;
        // _reasons.reason.push("Referred Product.");
        // }

        if (riskObj.hasClaimExperience == 'Y') {
            isReferredRisk = true;
            _reasons.reason.push("With Claim Experience.");
            this.addReferralReason(riskObj, '11', true, referralReasonList, selectableReasonsList);
        }
        else {
            this.deleteReferralReason(riskObj, '11', true);
        }

        this.calculateAge(riskObj, insuredObj);

        // let reflAgeLimits = this.lovDropDownService.lovDataList.referralAgeLimits.find((_data)=> _data.DESCITEM == this.riskObj.riskType);
        riskObj.ageLimitFlag = "";
        if (insuredObj) { insuredObj.ageLimitFlag = ""; }
        if (_ageLimitRec && insuredObj && insuredObj.DOB && insuredObj.occupationCode) {
            let _minAgeLimit = 0;
            let _maxAgeLimit = 0;
            let _minAgeLimitInd = 'Y';
            let _maxAgeLimitInd = 'Y';

            let _adultMinAgeLimit = (_ageLimitRec.ZAGELMT03) ? parseInt("" + _ageLimitRec.ZAGELMT03) : 0;
            let _adultMaxAgeLimit = 0;
            if ("Renewal" == caseInfo.businessFunction) {
                _adultMaxAgeLimit = (_ageLimitRec.ZAGELMT07) ? parseInt("" + _ageLimitRec.ZAGELMT07) : 0;
            } else {
                _adultMaxAgeLimit = (_ageLimitRec.ZAGELMT05) ? parseInt("" + _ageLimitRec.ZAGELMT05) : 0;
            }

            let _chidldMinAgeLimit = (_ageLimitRec.ZAGELMT04) ? parseInt("" + _ageLimitRec.ZAGELMT04) : 0;
            let _chidldMaxAgeLimit = (_ageLimitRec.ZAGELMT06) ? parseInt("" + _ageLimitRec.ZAGELMT06) : 0;


            if (_chidldMinAgeLimit > 0 && _chidldMaxAgeLimit > 0 && (insuredObj.occupationCode == '7STU' || insuredObj.occupationCode == '7CLD')) {
                _minAgeLimit = _chidldMinAgeLimit;
                _maxAgeLimit = _chidldMaxAgeLimit;
                _minAgeLimitInd = (_ageLimitRec.ZAGEIND02) ? _ageLimitRec.ZAGEIND02 : "Y";
                _maxAgeLimitInd = (_ageLimitRec.ZAGEIND03) ? _ageLimitRec.ZAGEIND03 : "Y";
            }
            else {

                _minAgeLimit = _adultMinAgeLimit;
                _maxAgeLimit = _adultMaxAgeLimit;
                if (_chidldMinAgeLimit == 0 || _chidldMaxAgeLimit == 0) {
                    _minAgeLimitInd = (_ageLimitRec.ZAGEIND02) ? _ageLimitRec.ZAGEIND02 : "Y";
                    _maxAgeLimitInd = (_ageLimitRec.ZAGEIND03) ? _ageLimitRec.ZAGEIND03 : "Y";
                }
            }

            if (_maxAgeLimitInd == 'D') {
                if (riskObj && insuredObj.DOB) {
                    let _inclusionDate = moment(new Date(), "YYYY-MM-DD");
                    let _insuredDOB = moment(insuredObj.DOB, "YYYY-MM-DD");

                    let _ageInDays = moment.duration(_inclusionDate.diff(_insuredDOB)).asDays();
                    if (_ageInDays > _maxAgeLimit) {
                        insuredObj.ageLimitFlag = "G";
                    }
                }
            }
			/* else if(Number(riskObj.insuredAge) > _maxAgeLimit) {				
				riskObj.ageLimitFlag = "G";
			} */
            if (Number(insuredObj.insuredAge) > _maxAgeLimit) {
                insuredObj.ageLimitFlag = "G";
            }

            if (insuredObj.ageLimitFlag != "G") {
                if (_minAgeLimitInd == 'D') {
                    if (riskObj && insuredObj.DOB) {
                        let _inclusionDate = moment(new Date(), "YYYY-MM-DD");
                        let _insuredDOB = moment(insuredObj.DOB, "YYYY-MM-DD");

                        let _ageInDays = moment.duration(_inclusionDate.diff(_insuredDOB)).asDays();
                        if (_ageInDays < _minAgeLimit) {
                            insuredObj.ageLimitFlag = "L";
                        }
                    }
                }
				/* else if(Number(riskObj.insuredAge) < _minAgeLimit) {
					riskObj.ageLimitFlag = "L";
				} */
                if (Number(insuredObj.insuredAge) < _minAgeLimit && _minAgeLimitInd != 'D') {
                    insuredObj.ageLimitFlag = "L";
                }
            }

            if (insuredObj.ageLimitFlag == "G") {
                isReferredRisk = true;
                var i: number = 0;
                var itemFound: number = 1;
                for (i = 0; i < _reasons.reason.length; i++) {
                    itemFound = _reasons.reason[i].search("Insured (" + insuredObj.itemNo + ")");
                }
                if (itemFound > 0) {
                    _reasons.reason.push("Insured (" + insuredObj.itemNo + ") Age greater than maximum allowed age " + _maxAgeLimit);
                }
                this.addReferralReason(riskObj, '01', true, referralReasonList, selectableReasonsList);
            }
            else if (insuredObj.ageLimitFlag == "") {
                insuredObj.ageLimitFlag = "VALID";
            }
        }

        if (insuredObj && insuredObj.occupationCode) {
            let _rec = occCodeList.find((_data) => _data.VALUE == insuredObj.occupationCode);

            if (_rec && _rec.REFERREDRISK && _rec.REFERREDRISK == 'Y') {
                isReferredRisk = true;
                riskObj.occRiskClassification = "Referred";
                _reasons.reason.push("Occupation code of type Referred selected");
                this.addReferralReason(riskObj, '05', true, referralReasonList, selectableReasonsList);
            }
            else if (_rec && _rec.REFERREDRISK && _rec.REFERREDRISK == 'D') {
                isDeclinedRisk = true;
                riskObj.occRiskClassification = "Declined";
                _reasons.reason.push("Declined : Occupation code of type Declined selected");
            }
            else {
                riskObj.occRiskClassification = "Standard";
            }

            if (riskObj.occRiskClassification != 'Referred') {
                this.deleteReferralReason(riskObj, '05', true);
            }
        }

        if (riskObj.referralReasons.referralReason && riskObj.referralReasons.referralReason.length > 0 && riskObj.referralReasons.referralReason.find((_data1) => _data1.isSysReferred != 'Y')) {
            isReferredRisk = true;
            _reasons.reason.push("Referral Reason added");
        }

        riskObj.riskClassificationReasons.reasons = _reasons;

        if (isDeclinedRisk == true) {
            riskObj.symRiskClassification = "Declined";
        }
        else if (isReferredRisk == true) {
            riskObj.isReferredRiskUI = true;
            riskObj.symRiskClassification = "Referred";
        }
        else {
            riskObj.isReferredRiskUI = false;
            riskObj.symRiskClassification = "Standard";
        }

        // this.handleRiskClassification();
    }

    addReferralReason(riskObj, refCode, isSysRef, refrlReasonsList, selectableReflReasonsList) {

        let refReasonRecord = refrlReasonsList.find(_data => (_data.code === refCode));

        if (!refReasonRecord) {
            let _refReasons = [];
            let request: GetLOVData = new GetLOVData().getRequest('ALL', 'MED', 'ALL', 'ALL', 'ALL', 'ALL', 'Referral Reasons', 'LOV');
            request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
            request.ADVANCE_CONFIG_XML.FILTERS = new Filter();

            this._cordysService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, null, null, false, null).success((data) => {
                if (data.tuple) {
                    if (Array.prototype.isPrototypeOf(data.tuple)) {
                        for (let _rec of data.tuple) {
                            _refReasons.push(_rec.old.DESCPF);
                        }
                    }
                    else if (data.tuple && data.tuple.old && data.tuple.old.DESCPF) {
                        _refReasons.push(data.tuple.old.DESCPF);
                    }
                }
            }).error((response, status, errorText) => {
                this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error while getting Referral Reasons ", 5000));
            });

            if (_refReasons && _refReasons.length > 0) {
                refReasonRecord = _refReasons.find(_data => (_data.code === refCode));
            }
        }

        if (refReasonRecord) {
            if (riskObj.referralReasons.referralReason && (riskObj.referralReasons.referralReason.length == 0 || !riskObj.referralReasons.referralReason.find((_data1) => _data1.code == refCode))) {
                let _referralReason = new ReferralReason();
                _referralReason.seqNumber = riskObj.referralReasons.referralReason.length + 1;
                _referralReason.code = refReasonRecord.code;
                _referralReason.description = refReasonRecord.description;
                _referralReason.isSysReferred = (isSysRef) ? 'Y' : 'N';

                riskObj.referralReasons.referralReason.push(_referralReason);

                // this.removeRefrlReasonFromSelectionList(refCode, selectableReflReasonsList);
            }
            else if (riskObj.referralReasons.referralReason && riskObj.referralReasons.referralReason.find((_data1) => _data1.code == refCode)) {
                let _refReason = riskObj.referralReasons.referralReason.find((_data1) => _data1.code == refCode);
                _refReason.isSysReferred = (isSysRef) ? 'Y' : 'N';

                // this.removeRefrlReasonFromSelectionList(refCode, selectableReflReasonsList);
            }
        }
    }

    removeRefrlReasonFromSelectionList(refCode, selectableReflReasonsList) {
        if (selectableReflReasonsList) {
            let _selectedRefReason = selectableReflReasonsList.find(item => item.code == refCode);
            if (_selectedRefReason) {
                selectableReflReasonsList.splice(selectableReflReasonsList.indexOf(_selectedRefReason), 1);
            }
        }
    }

    deleteReferralReason(riskObj, refCode, sysRef) {
        let refReasonRecord = riskObj.referralReasons.referralReason.find((_data1) => _data1.code == refCode);
        if (refReasonRecord && (!sysRef || (sysRef && refReasonRecord.isSysReferred == 'Y'))) {
            riskObj.referralReasons.referralReason.splice(riskObj.referralReasons.referralReason.indexOf(refReasonRecord), 1);
        }
    }

    callbackForReferralReasons(scopeObject) {
        for (let _refReason of scopeObject.lovDropDownService.lovDataList.referralReasons) {
            // let hasRefReason = scopeObject.referralReasons.some( _data => _data.code === _refReason.code );
            let hasRefReason = scopeObject.riskObj.referralReasons.referralReason.some(_data => _data.code == _refReason.code);
            if (!hasRefReason) {
                scopeObject.referralReasons.push(_refReason);
            }
        }
    }

    callbackForReferralAgeLimit(scopeObject) {
        if (scopeObject._insuredDetailsList.insured.length > 0) {
            scopeObject.validateReferredRisk(scopeObject._insuredDetailsList.insured[0]);
        }
    }

    calculateAge(riskObj, insuredObj) {
        if (insuredObj && insuredObj.DOB) {
            let _inclusionDate = moment(new Date(), "YYYY-MM-DD");
            let _insuredDOB = moment(insuredObj.DOB, "YYYY-MM-DD");
            let age = _inclusionDate.diff(_insuredDOB, 'years'); //Redmine#2633- Age should be calculate on Year (not on date) for all medical products.
            let dobYear = _insuredDOB.year();
            let inclDtYear = _inclusionDate.year();
            //let age = inclDtYear - dobYear;

            insuredObj.insuredAge = age;
        }
		/* else {
			insuredObj.insuredAge = 0;
		}	 */
    }

    handleRiskClassification(comp) {

        if (comp.riskObj.symRiskClassification == "Declined")
            comp.riskObj.riskClassification = "Declined";
        else if (comp.riskObj.symRiskClassification == "Referred" || comp.riskObj.riRiskClassification == "Referred")
            comp.riskObj.riskClassification = "Referred";
        else if (comp.isManuallyReferred)
            comp.riskObj.riskClassification = "Referred";
        else
            comp.riskObj.riskClassification = "Standard";

        comp.setRiskClassification(comp);
    }

    setRiskClassification(comp) {
        comp.riskClassificationService.setRiskClassification(comp.riskObj.riskNumber, "N", "", "").subscribe((support) => {
            if (support == "NS") {
                if (comp.riskObj.symRiskClassification != null && comp.riskObj.symRiskClassification != "" && (comp.riskObj.symRiskClassification == "Referred" || comp.riskObj.symRiskClassification == "Declined")) {
                    let statusTxt = (comp.riskObj.symRiskClassification != null && comp.riskObj.symRiskClassification != "") ? comp.riskObj.symRiskClassification : comp.riskObj.riskClassification;
                    comp.riskObj.riskClassificationReason = "System marked as " + statusTxt;
                }
                else {
                    if (comp.riskObj.riskClassificationReason != null && comp.riskObj.riskClassificationReason != "" && (comp.riskObj.riskClassificationReason != "System marked as Standard"
                        && comp.riskObj.riskClassificationReason.indexOf("System marked as ") != -1)) {
                        comp.riskObj.riskClassificationReason = "";
                    }
                }
                comp.onRiskClsChange.emit('');
            }

            if (comp.riskObj.symRiskClassification == null || comp.riskObj.symRiskClassification == '' || comp.riskObj.symRiskClassification == 'Standard') {
                comp.riskObj.riskClassificationReason = "";
            }
        });
    }
    //GA001 END
    //GA002 START
    checkHighRiskClient(insured,effectiveDate,endDate,prms,operation,index) {
        let clientIDNo = "";
        let clientIDNo1 = "";
        let riskNumber:number = 0;

        if(prms.comp.riskObj!=undefined && prms.comp.riskObj.riskNumber!=""){
            riskNumber = prms.comp.riskObj.riskNumber;
        }
        if(insured.nric!=undefined && insured.nric!=""){
            clientIDNo = insured.nric;
        }
        if(insured.ICPassport!=undefined && insured.ICPassport!=""){
            clientIDNo1 = insured.ICPassport;
        }
        if(clientIDNo!="" && clientIDNo!=undefined){//NRIC
            prms.comp._cordysService.callCordysSoapService("CheckHighRiskForBnmClient", "http://schemas.cordys.com/bmsintegrationapp", { 
                "CLIENTIDNO": clientIDNo, "EFFECTIVEDATE": effectiveDate, "ENDDATE": endDate }, prms.comp.highRiskInsuredBNMNRICHandler, prms.comp.handleError, true, { comp: prms.comp,insured:insured,effectiveDate:effectiveDate,endDate:endDate,operation:operation,index:index });
        }else if(clientIDNo1!="" && clientIDNo1!=undefined){//PAS or OLD IC
            prms.comp._cordysService.callCordysSoapService("CheckHighRiskForBnmClient", "http://schemas.cordys.com/bmsintegrationapp", { 
                "CLIENTIDNO": clientIDNo1, "EFFECTIVEDATE": effectiveDate, "ENDDATE": endDate }, prms.comp.highRiskInsuredBNMOLDICHandler, prms.comp.handleError, true, { comp: prms.comp,insured:insured,effectiveDate:effectiveDate,endDate:endDate,operation:operation,index:index });
        }else{
            let item_key = "INSURED_NRIC_INTERNAL_CLIENT"+clientIDNo;
            let item_key1 = "INSURED_OLDIC_INTERNAL_CLIENT"+clientIDNo1;
            let removeIndex = -1;
            let removeIndex1 = -1;
            let headerInfo = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo;
            if(headerInfo.highRiskIndicatorReasons!=undefined && headerInfo.highRiskIndicatorReasons.highRiskIndReason.length>0 ){
                //NRIC Remove
                removeIndex = prms.comp.findIndexByRiskItemKey( headerInfo.highRiskIndicatorReasons.highRiskIndReason, riskNumber, item_key );
                if(removeIndex>=0){
                    headerInfo.highRiskIndicatorReasons.highRiskIndReason.splice(removeIndex, 1);
                }
                //Old IC Remove
                removeIndex1 = prms.comp.findIndexByRiskItemKey( headerInfo.highRiskIndicatorReasons.highRiskIndReason, riskNumber, item_key1 );
                if(removeIndex1>=0){
                    headerInfo.highRiskIndicatorReasons.highRiskIndReason.splice(removeIndex1, 1);
                }
            }
            headerInfo.highRiskInsuredBNMInd = 'N';
            headerInfo.highRiskInsuredInternalInd = 'N';
        }
    }
    highRiskInsuredBNMNRICHandler(response, prms) {
        let clientIDNo = "";
        let clientIDNo1 = "";
        if(prms.insured.nric!=undefined && prms.insured.nric!=""){
            clientIDNo = prms.insured.nric;
        }
        if(prms.insured.ICPassport!=undefined && prms.insured.ICPassport!=""){
            clientIDNo1 = prms.insured.ICPassport;
        }
        let ind = "";
        let reason = "";
        if(response.tuple != null && response.tuple.old != null && response.tuple.old.checkHighRiskForBnmClient
            && response.tuple.old.checkHighRiskForBnmClient.checkHighRiskForBnmClient!=null 
            && response.tuple.old.checkHighRiskForBnmClient.checkHighRiskForBnmClient!=""
            && response.tuple.old.checkHighRiskForBnmClient.checkHighRiskForBnmClient=="B"){
                ind = response.tuple.old.checkHighRiskForBnmClient.checkHighRiskForBnmClient.substring(0,1);
                reason = "BNM Insured with NRIC ("+ prms.insured.nric +") is High Risk Indicator";
        }
        if ( ind != null && ind == 'B' ) {
            reason = reason + " with Block";
            prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, reason, -1));
            return;
        } else if(clientIDNo1!="" && clientIDNo1!=undefined){//PAS or OLD IC
            prms.comp._cordysService.callCordysSoapService("CheckHighRiskForBnmClient", "http://schemas.cordys.com/bmsintegrationapp", { 
                "CLIENTIDNO": clientIDNo1, "EFFECTIVEDATE": prms.effectiveDate, "ENDDATE": prms.endDate }, prms.comp.highRiskInsuredBNMOLDICHandler, prms.comp.handleError, true, { comp: prms.comp,insured:prms.insured,effectiveDate:prms.effectiveDate,endDate:prms.endDate,operation:prms.operation,index:prms.index });
        }else if(clientIDNo!="" && clientIDNo!=undefined){//NRIC
            prms.comp._cordysService.callCordysSoapService("CheckHighRiskForInternalClient", "http://schemas.cordys.com/bmsintegrationapp", { 
                "CLIENTIDNO": clientIDNo, "EFFECTIVEDATE": prms.effectiveDate, "ENDDATE": prms.endDate }, prms.comp.highRiskInsuredInternalNRICHandler, prms.comp.handleError, true, { comp: prms.comp,insured:prms.insured,effectiveDate:prms.effectiveDate,endDate:prms.endDate,operation:prms.operation,index:prms.index });
        }
    }
    highRiskInsuredBNMOLDICHandler(response, prms) {
        let clientIDNo = "";
        let clientIDNo1 = "";
        if(prms.insured.nric!=undefined && prms.insured.nric!=""){
            clientIDNo = prms.insured.nric;
        }
        if(prms.insured.ICPassport!=undefined && prms.insured.ICPassport!=""){
            clientIDNo1 = prms.insured.ICPassport;
        }
        let ind = "";
        let reason = "";
        if(response.tuple != null && response.tuple.old != null && response.tuple.old.checkHighRiskForBnmClient
            && response.tuple.old.checkHighRiskForBnmClient.checkHighRiskForBnmClient!=null 
            && response.tuple.old.checkHighRiskForBnmClient.checkHighRiskForBnmClient!=""
            && response.tuple.old.checkHighRiskForBnmClient.checkHighRiskForBnmClient=="B"){
                ind = response.tuple.old.checkHighRiskForBnmClient.checkHighRiskForBnmClient.substring(0,1);
                reason = "BNM Insured with Old IC or Passport ("+ prms.insured.ICPassport +") is High Risk Indicator";
        }
        if ( ind != null && ind == 'B' ) {
            prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, reason + " with Block", -1));
            return;
        }else if(clientIDNo!="" && clientIDNo!=undefined){//NRIC
            prms.comp._cordysService.callCordysSoapService("CheckHighRiskForInternalClient", "http://schemas.cordys.com/bmsintegrationapp", { 
                "CLIENTIDNO": clientIDNo, "EFFECTIVEDATE": prms.effectiveDate, "ENDDATE": prms.endDate }, prms.comp.highRiskInsuredInternalNRICHandler, prms.comp.handleError, true, { comp: prms.comp,insured:prms.insured,effectiveDate:prms.effectiveDate,endDate:prms.endDate,operation:prms.operation,index:prms.index });
        }else if(clientIDNo1!="" && clientIDNo1!=undefined){//OLD IC
            prms.comp._cordysService.callCordysSoapService("CheckHighRiskForInternalClient", "http://schemas.cordys.com/bmsintegrationapp", { 
                "CLIENTIDNO": clientIDNo1, "EFFECTIVEDATE": prms.effectiveDate, "ENDDATE": prms.endDate }, prms.comp.highRiskInsuredInternalOLDICHandler, prms.comp.handleError, true, { comp: prms.comp,insured:prms.insured,effectiveDate:prms.effectiveDate,endDate:prms.endDate,operation:prms.operation,index:prms.index });
        }
    }
    highRiskInsuredInternalNRICHandler(response, prms) {
        let clientIDNo = "";
        let clientIDNo1 = "";
        let riskNumber:number = 0;
        let ind = "";
        let reason = "";
        let reasonA = "";
        let item_key = "";
        let item = "";

        if(prms.insured.nric!=undefined && prms.insured.nric!=""){
            clientIDNo = prms.insured.nric;
        }
        if(prms.insured.ICPassport!=undefined && prms.insured.ICPassport!=""){
            clientIDNo1 = prms.insured.ICPassport;
        }
        if(prms.comp.riskObj!=undefined && prms.comp.riskObj.riskNumber!=""){
            riskNumber = prms.comp.riskObj.riskNumber;
        }
        if(response.tuple != null && response.tuple.old != null && response.tuple.old.checkHighRiskForInternalClient
            && response.tuple.old.checkHighRiskForInternalClient.checkHighRiskForInternalClient!=null 
            && response.tuple.old.checkHighRiskForInternalClient.checkHighRiskForInternalClient!=""
            && response.tuple.old.checkHighRiskForInternalClient.checkHighRiskForInternalClient!=""){
                ind = response.tuple.old.checkHighRiskForInternalClient.checkHighRiskForInternalClient.substring(0,1);
                reasonA = response.tuple.old.checkHighRiskForInternalClient.checkHighRiskForInternalClient.substring(1);
                reason = "Internal Insured "+ prms.insured.name +" with NRIC ("+ prms.insured.nric +") is High Risk Indicator";
        }
        if ( ind != null && ind == 'B' ) {
            prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, reason + " with Block", -1));
            return;
        }else if(clientIDNo1!="" && clientIDNo1!=undefined){//OLDIC
                prms.comp._cordysService.callCordysSoapService("CheckHighRiskForInternalClient", "http://schemas.cordys.com/bmsintegrationapp", { 
                    "CLIENTIDNO": clientIDNo1, "EFFECTIVEDATE": prms.effectiveDate, "ENDDATE": prms.endDate }, prms.comp.highRiskInsuredInternalOLDICHandler, prms.comp.handleError, true, { comp: prms.comp,insured:prms.insured,effectiveDate:prms.effectiveDate,endDate:prms.endDate,NRICInd:ind,NRICReason:reasonA,operation:prms.operation,index:prms.index });
        }else{
            if ( ind != null && ind == 'A' ){
                item_key = "INSURED_NRIC_INTERNAL_CLIENT"+clientIDNo;
                item = "INSURED NRIC INTERNAL CLIENT - "+prms.insured.name;
                let removeIndex = -1;
                let headerInfo = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo;
                if(headerInfo.highRiskIndicatorReasons!=undefined && headerInfo.highRiskIndicatorReasons.highRiskIndReason.length>0 ){
                    //NRIC Remove
                    removeIndex = prms.comp.findIndexByRiskItemKey( headerInfo.highRiskIndicatorReasons.highRiskIndReason, riskNumber, item_key );
                    if(removeIndex>=0){
                        headerInfo.highRiskIndicatorReasons.highRiskIndReason.splice(removeIndex, 1);
                    }
                }
                let highRiskIndReason:HighRiskIndReason = new HighRiskIndReason();
                if(prms.comp.riskObj!=undefined && prms.comp.riskObj.riskNumber!=undefined){
                    highRiskIndReason.riskNumber = Number(prms.comp.riskObj.riskNumber);
                }else{
                    highRiskIndReason.riskNumber = 1;
                }
                highRiskIndReason.item_key = item_key;
                highRiskIndReason.item = item;
                highRiskIndReason.reason = reasonA;
                highRiskIndReason.ind = ind;
                            
                headerInfo.highRiskIndicator = "true";
                headerInfo.highRiskIndicatorUI = true;
                headerInfo.highRiskInsuredInternalInd = ind;
                headerInfo.highRiskIndicatorType = ind;
                headerInfo.highRiskIndicatorReasons.highRiskIndReason.push( highRiskIndReason );
                prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, item + " : " + reasonA + " with Alert", -1));
            }
            if(prms.operation=="edit"){
                prms.comp._insuredDetailsList.insured[prms.index] = prms.insured;
            }else{
                prms.insured.itemNo = prms.comp._insuredDetailsList.insured.length + 1;
                prms.comp._insuredDetailsList.insured.push(prms.insured);
            }
        }
    }
    highRiskInsuredInternalOLDICHandler(response, prms) {
        let riskNumber:number = 0;
        let clientIDNo = "";
        let clientIDNo1 = "";
        let ind = "";
        let reason = "";
        let reasonA = "";
        let item = "";
        let item_key = "";
        let item_key1 = "";

        if(prms.insured.nric!=undefined && prms.insured.nric!=""){
            clientIDNo = prms.insured.nric;
        }
        if(prms.insured.ICPassport!=undefined && prms.insured.ICPassport!=""){
            clientIDNo1 = prms.insured.ICPassport;
        }
        if(prms.comp.riskObj!=undefined && prms.comp.riskObj.riskNumber!=""){
            riskNumber = prms.comp.riskObj.riskNumber;
        }
        if(response.tuple != null && response.tuple.old != null && response.tuple.old.checkHighRiskForInternalClient
            && response.tuple.old.checkHighRiskForInternalClient.checkHighRiskForInternalClient!=null 
            && response.tuple.old.checkHighRiskForInternalClient.checkHighRiskForInternalClient!=""
            && response.tuple.old.checkHighRiskForInternalClient.checkHighRiskForInternalClient!=""){
                ind = response.tuple.old.checkHighRiskForInternalClient.checkHighRiskForInternalClient.substring(0,1);
                reasonA = response.tuple.old.checkHighRiskForInternalClient.checkHighRiskForInternalClient.substring(1);
                reason = "Internal Insured "+ prms.insured.name +" with Old IC / Passport ("+ prms.insured.ICPassport +") is High Risk Indicator";
        }
        if ( ind != null && ind == 'B' ) {
            prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, reason + " with Block", -1));
            return;
        }else{
            let highRiskIndReason:HighRiskIndReason = new HighRiskIndReason();
            let highRiskIndReason1:HighRiskIndReason = new HighRiskIndReason();
            let removeIndex = -1;
            let removeIndex1 = -1;
            item_key = "INSURED_NRIC_INTERNAL_CLIENT"+clientIDNo;
            item_key1 = "INSURED_OLDIC_INTERNAL_CLIENT"+clientIDNo1;
            let headerInfo = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo;
            if(headerInfo.highRiskIndicatorReasons!=undefined && headerInfo.highRiskIndicatorReasons.highRiskIndReason.length>0 ){
                if (prms.NRICInd != null && prms.NRICInd == 'A') {//NRIC Alert
                    //NRIC Remove
                    removeIndex = prms.comp.findIndexByRiskItemKey( headerInfo.highRiskIndicatorReasons.highRiskIndReason, riskNumber, item_key );
                    if(removeIndex>=0){
                        headerInfo.highRiskIndicatorReasons.highRiskIndReason.splice(removeIndex, 1);
                    }
                }
                if ( ind != null && ind == 'A' ) {//Old IC Alert
                    //Old IC Remove
                    removeIndex1 = prms.comp.findIndexByRiskItemKey( headerInfo.highRiskIndicatorReasons.highRiskIndReason, riskNumber, item_key1 );
                    if(removeIndex1>=0){
                        headerInfo.highRiskIndicatorReasons.highRiskIndReason.splice(removeIndex1, 1);
                    }
                }
            }
            if (prms.NRICInd != null && prms.NRICInd == 'A') {//NRIC Alert
                item = "INSURED NRIC INTERNAL CLIENT - "+ prms.insured.name;
                if(prms.comp.riskObj!=undefined && prms.comp.riskObj.riskNumber!=undefined){
                    highRiskIndReason.riskNumber = Number(prms.comp.riskObj.riskNumber);
                }
                highRiskIndReason.item_key = item_key;
                highRiskIndReason.item = item;
                highRiskIndReason.reason = prms.NRICReason;
                highRiskIndReason.ind = prms.NRICInd;
                headerInfo.highRiskIndicatorReasons.highRiskIndReason.push( highRiskIndReason );

                headerInfo.highRiskIndicator = "true";
                headerInfo.highRiskIndicatorUI = true;
                headerInfo.highRiskInsuredInternalInd = ind;
                prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, item + " : " + prms.NRICReason + " with Alert", -1));
            }
            if ( ind != null && ind == 'A' ) {//Old IC Alert
                item = "INSURED OLDIC INTERNAL CLIENT - "+prms.insured.name;
                if(prms.comp.riskObj!=undefined && prms.comp.riskObj.riskNumber!=undefined){
                    highRiskIndReason1.riskNumber = prms.comp.riskObj.riskNumber;
                }
                highRiskIndReason1.item_key = item_key1;
                highRiskIndReason1.item = item;
                highRiskIndReason1.reason = reasonA;
                highRiskIndReason1.ind = ind;
                headerInfo.highRiskIndicatorReasons.highRiskIndReason.push( highRiskIndReason1 );

                headerInfo.highRiskIndicator = "true";
                headerInfo.highRiskIndicatorUI = true;
                headerInfo.highRiskInsuredInternalInd = ind;
                prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, item + " : " + reasonA + " with Alert", -1));
            }
            if(prms.operation=="edit"){ 
                prms.comp._insuredDetailsList.insured[prms.index] = prms.insured;
            }else{
                prms.insured.itemNo = prms.comp._insuredDetailsList.insured.length + 1;
                prms.comp._insuredDetailsList.insured.push(prms.insured);
            }
        }
    }
    handleError(response, status, errorText, prms) {
        prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, response.responseJSON.faultstring.text, -1));
    }
    removeHighRiskValidation(thisObj,insured,riskObj){
        let clientIDNo = "";
        let clientIDNo1 = "";
        let item_key = "";
        let item_key1 = "";
        let removeIndex = -1;
        let removeIndex1 = -1;
        let riskNumber:number = 0;

        if(riskObj!=undefined && riskObj.riskNumber!=""){
            riskNumber = riskObj.riskNumber;
        }
        if(insured!=undefined && insured.nric!=undefined && insured.nric!=""){
            clientIDNo = insured.nric;
        }
        if(insured!=undefined && insured.ICPassport!=undefined && insured.ICPassport!=""){
            clientIDNo1 = insured.ICPassport;
        }
        item_key = "INSURED_NRIC_INTERNAL_CLIENT"+clientIDNo;
        item_key1 = "INSURED_OLDIC_INTERNAL_CLIENT"+clientIDNo1;
        let headerInfo:ProposalHeader = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo;
        if(headerInfo.highRiskIndicatorReasons!=undefined && headerInfo.highRiskIndicatorReasons.highRiskIndReason.length>0 ){
            //NRIC Remove
            removeIndex = thisObj.findIndexByRiskItemKey( headerInfo.highRiskIndicatorReasons.highRiskIndReason, riskNumber, item_key );
            if(removeIndex>=0){
                headerInfo.highRiskIndicatorReasons.highRiskIndReason.splice(removeIndex, 1);
            }
            //Old IC Remove
            removeIndex1 = thisObj.findIndexByRiskItemKey( headerInfo.highRiskIndicatorReasons.highRiskIndReason, riskNumber, item_key1 );
            if(removeIndex1>=0){
                headerInfo.highRiskIndicatorReasons.highRiskIndReason.splice(removeIndex1, 1);
            }
        }
        if(!(headerInfo.highRiskIndicatorReasons!=undefined && headerInfo.highRiskIndicatorReasons.highRiskIndReason.length>0) ){
            headerInfo.highRiskIndicator = "false";
            headerInfo.highRiskIndicatorUI = false;
            headerInfo.highRiskInsuredInternalInd = "";
        }
    }
    public findIndexByRiskItemKey( highRiskIndReason,riskNumber, item_key ) {
        let indexVal: number = -1;
        highRiskIndReason.forEach( function ( elem, i ) {
            if ( elem.riskNumber == riskNumber && elem.item_key == item_key ) {
                indexVal = i;
                return indexVal;
            }             
        } );
        return indexVal;
    }
    //GA002 END
}