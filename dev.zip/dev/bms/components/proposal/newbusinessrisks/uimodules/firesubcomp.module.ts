import { NgModule } from '@angular/core';
import { GSTModule } from './gst.module';
import { ClausesModule } from "./clauses.module";
import { FireCoverageModule } from './firecoverage.module';

@NgModule({
    imports: [GSTModule, ClausesModule, FireCoverageModule]
})
export class FireSubCompModule { }