import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BasicUIModule } from '../../../../../common/components/utility/basicui.module';
import { PaginationModule } from '../../../../../common/components/utility/pagination/pagination.module';
import { WarrantyClausesComponent } from './warrantyclauses.component';

@NgModule({
    imports: [CommonModule, FormsModule, ReactiveFormsModule, BasicUIModule, PaginationModule],
    declarations: [WarrantyClausesComponent],
    exports: [WarrantyClausesComponent]
})
export class WarrantyClausesModule { }