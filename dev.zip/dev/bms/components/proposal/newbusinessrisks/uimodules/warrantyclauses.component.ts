import { Component, EventEmitter, OnInit, ViewChild, ViewContainerRef } from '@angular/core';
import { AlertMessage } from '../../../../../common/components/utility/alertmessage/alertmessages.model';
import { AlertMessagesService } from '../../../../../common/components/utility/alertmessage/alertmessages.service';
import { ModalInput } from "../../../../../common/components/utility/modal/modal";
import { SearchInput } from "../../../../../common/components/utility/search/genericsearch";
import { CustomDCLService } from '../../../../../common/services/customdcl.service';
import { FireItems } from '../appobjects/fireItems';
import { WarrantyClassCode, WarrantyClassCodeDetail } from '../appobjects/warrantyClassCodes';
import { RiskCoverageDetails } from '../s4846/appobjects/s4846';
import { BMSConstants } from '../../../common/constants/bms_constants';
import { GetLOVData, SearchAdvancedConfig, Filter } from '../../../../../common/components/utility/search/search.requests';
import { CordysSoapWService } from '../../../../../common/components/utility/cordys-soap-ws';
import { AppUtil } from '../../../../../common/components/utility/apputil/app.util';

declare var moment: any;
declare var numeral: any;

@Component({
    selector: 'warranty-clauses-component',
    templateUrl: 'app/bms/components/proposal/newbusinessrisks/uimodules/warrantyclauses.template.html',
    inputs: ['riskCode', '_wcClassCode', 'fireItems', 'riskCoverageDetails', 'effectiveDate'],
    outputs: ["onwarrantyamtchange"]
})

export class WarrantyClausesComponent implements OnInit {

    public _wcClassCode: WarrantyClassCode;
    public riskCode: string;
    public effectiveDate: string;
    public warrantyClauserate: string = "";
    public rateBasic: string;
    public ratingFlag: string;
    public rateNeeded: boolean = true;
    public wcRateFormat: string = "0.00000";
    public wcAmtFormat: string = "0,00";
    public premiumFormat: string = "0,00.00";
    public fireItems: FireItems
    onwarrantyamtchange = new EventEmitter<any>();

    //Table search
    public search: String = "";
    public position = 1;
    public sizeObj = { length: 0, orglength: 0 };
    public contentSizeObs: any;
    public itemPerPage = 5;
    public maxPageCount = 5;

    public riskCoverageDetails: RiskCoverageDetails;
    @ViewChild('warrantyModal', { read: ViewContainerRef }) contentArea: ViewContainerRef;

    constructor(public dcl: CustomDCLService, public _alertMsgService: AlertMessagesService,public _soapService: CordysSoapWService) { }

    ngOnInit() {

    }

    openWCDetailsDialog() {
        let searchInput = new SearchInput();
        searchInput.isSingleSelect = false;
        searchInput.BRANCH = 'ALL';
        searchInput.LOB = 'FIRE';
        searchInput.BUSINESS_FUNCTION = 'NEW_BUSINESS';
        searchInput.PRODUCT = 'ALL';
        searchInput.OPERATION = 'ALL';
        searchInput.FORM_NAME = 'FIRE';
        searchInput.FORM_FIELD_NAME = 'WarrantyClauses';
        searchInput.FIELD_TYPE = 'LOOKUP';
        if (this._wcClassCode.warrantyClassCode.length > 0) {
            let newArr = [];
            for (let item of this._wcClassCode.warrantyClassCode) {
                newArr = newArr.concat(item["classCode"]);
            }
            let wcCodes = "'" + newArr.toString().replace(/,/g, "\',\'") + "'";
            searchInput.condition = { "RISKTYP": this.riskCode, "ITMFRM": moment(this.effectiveDate).format("YYYYMMDD"), "ITMTO": moment(this.effectiveDate).format("YYYYMMDD"), "CLAUSECODE": wcCodes };
        }
        else
            searchInput.condition = { "RISKTYP": this.riskCode, "ITMFRM": moment(this.effectiveDate).format("YYYYMMDD"), "ITMTO": moment(this.effectiveDate).format("YYYYMMDD"), "CLAUSECODE": "''" };

        let input = new ModalInput();
        input = input.get("GenericSearchComponent");
        input.datainput = searchInput;
        input.outputCallback = this.addWCClauses;
        input.parentCompPRMS = { comp: this };
        input.heading = "Warranty Clauses Details";
        input.icon = "fa fa-link";
        input.containerRef = this.contentArea;
        this.dcl.openLookup(input);
    }

    addWCClauses(listOfClauses, prms) {
        for (let item of listOfClauses) {
            if (!prms.comp._wcClassCode.warrantyClassCode)
                prms.comp._wcClassCode.warrantyClassCode = [];
            prms.comp._wcClassCode.warrantyClassCode.push({
                "classCode": item.old.TABLE.CLAUSECODE,
                "description": item.old.TABLE.HEAD,
                "rate": numeral(item.old.TABLE.RATE).format(prms.comp.wcRateFormat),
                "nature": item.old.TABLE.NATURE_01,
                "overrideInd": item.old.TABLE.ZOVRSI,
                "disableItem": (item.old.TABLE.NATURE_01 == '**') ? 'Y' : 'N',
                "amount": "0.00",
                "unFormattedAmount": "0",
                "coverItems": [],
                "prlPRT": item.old.TABLE.ZPRLPRT,
                "overrideIndRate": item.old.TABLE.ZOVRIND,
                "isDefaultWCClause": 'N'
            });
        }
        AppUtil.removeAryDuplicates(prms.comp._wcClassCode.warrantyClassCode,"classCode");
        prms.comp.resetTotal();
    }

    removeWC(idx: number) {
        let finalWCItemArr = [];
        let removedWCCode = this._wcClassCode.warrantyClassCode[idx].classCode;
        let tempArr = (this.riskCode != "" && this.riskCode.includes("HHO")) ? this.riskCoverageDetails.riskCoverage : this.fireItems.fireItems
        for (let item of tempArr) {
            finalWCItemArr = item.wcClassCodes.warrantyClassCode.filter(function (item) { return item.classCode != removedWCCode; });
            item.wcClassCodes.warrantyClassCode = finalWCItemArr;
        }
        this._wcClassCode.warrantyClassCode.splice(idx, 1);
        this.resetTotal();
    }

    resetTotal() {
        this._wcClassCode.wcTotal = this.getTotalByProperty("rate", this._wcClassCode.warrantyClassCode, this.wcRateFormat);
        this.emitRateChange();
    }

    getTotalByProperty(prop, ary, format) {
        let total: string = "0";
        for (let eachItem of ary) {
            if (eachItem[prop] != null && eachItem[prop] != "") {
                total = "" + (parseFloat(total) + parseFloat(eachItem[prop]));
                total = numeral(total).format(format);
            }
        }
        return parseFloat(total);
    }

    emitRateChange() {
        this.onwarrantyamtchange.emit(this._wcClassCode.wcTotal);
    }

    viewClauseWordings(clause) {
        let request: GetLOVData = new GetLOVData();
        request.BRANCH = 'ALL';
        request.LOB = 'ALL';
        request.BUSINESS_FUNCTION = 'ALL';
        request.PRODUCT = 'ALL';
        request.OPERATION = 'ALL';
        request.FORM_NAME = 'ALL';
        request.FORM_FIELD_NAME = 'SubClauses';
        request.FIELD_TYPE = 'LOOKUP';
        request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        request.ADVANCE_CONFIG_XML.FILTERS = new Filter();
        while (clause.classCode && clause.classCode.length < 4) {
            clause.classCode = clause.classCode + " ";
        }
        let inceptionDate = BMSConstants.getBMSHeaderInfo().effectiveDate;
        inceptionDate = moment(inceptionDate, "YYYY-MM-DD").format("YYYYMMDD");
        request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push(
            { "@FIELD_NAME": 'ITEMITEM', "@FIELD_VALUE": this.riskCode + "" + clause.classCode, '@OPERATION': 'STARTSWITH', '@CONDITION': 'AND' },
            { "@FIELD_NAME": 'ITMFRM', "@FIELD_VALUE": inceptionDate, '@OPERATION': 'LTEQ', '@CONDITION': 'AND' },
            { "@FIELD_NAME": 'ITMTO', "@FIELD_VALUE": inceptionDate, '@OPERATION': 'GTEQ', '@CONDITION': 'AND' }
        );
        this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.subClauseCodeHandler, this.handleError, false, { comp: this });
    }
    subClauseCodeHandler(response, prms) {
        let ary = [];
        let wordingVal: string = "";
        if (response.tuple != null && !Array.prototype.isPrototypeOf(response.tuple)) {
            ary = [response.tuple];
        }
        else if (response.tuple != null) {
            ary = response.tuple;
        }
        for (let clause of ary) {
            wordingVal = wordingVal + clause.old.CLATPF.WORD;
        }
        let lookup = new ModalInput();
        lookup.component = ["SubClausesDialogComponent", "app/bms/components/proposal/newbusinessrisks/uimodules/clauses.module", "ClausesModule"];
        lookup.datainput = { isView: true, comments: wordingVal, parent: prms.comp };
        lookup.outputCallback = prms.comp.viewSubClus;
        lookup.parentCompPRMS = { comp: prms.comp };
        lookup.heading = "Clauses Wording";
        lookup.icon = "fa fa-bars";
        lookup.containerRef = prms.comp.contentArea;
        prms.comp.dcl.openLookup(lookup);
    }
    handleError(response, status, errorText, prms) {
        prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, response.responseJSON.faultstring.text, -1));
    }
}