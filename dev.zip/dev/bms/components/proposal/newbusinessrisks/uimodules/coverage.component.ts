/**
 * Change History	:

	No      Date          Description                                                       Changed By
	====    ==========    ===========                                                        ==========
	MD001   06/04/2018    Incomplete List "Additional Coverage" for NGA product in BMS          MKU1
        MO001	17/10/2018    OSI/OSS – Display plan in drop-down list without continuation item    RMO  
 */
import { Component, OnInit, EventEmitter, ViewChild, ViewContainerRef } from '@angular/core';
import { LOV_Field, LOVDropDownService, SearchFilter } from "../../../../../common/services/lovdropdown/lovdropdown.service";
import { SearchInput } from "../../../../../common/components/utility/search/genericsearch";
import { ModalInput } from "../../../../../common/components/utility/modal/modal";
import { GetLOVData, SearchAdvancedConfig, Filter } from '../../../../../common/components/utility/search/search.requests';
import { DCLInput, CustomDCLService } from '../../../../../common/services/customdcl.service';
import { CordysSoapWService } from "../../../../../common/components/utility/cordys-soap-ws";
declare var Observer: any;
import { AlertMessagesService } from '../../../../../common/components/utility/alertmessage/alertmessages.service';
import { AlertMessage } from '../../../../../common/components/utility/alertmessage/alertmessages.model';
import { BMSConstants } from '../../../common/constants/bms_constants'

declare var jQuery: any;
declare var numeral: any;
declare var moment: any;

@Component({
    selector: 'coverage-comp',
    templateUrl: 'app/bms/components/proposal/newbusinessrisks/uimodules/coverage.template.html',
    inputs: ['coverageObj', 'coverageName', 'riskObj'],
    outputs: ['ontotalchange', 'onsichange', 'onplanchange', 'onagechange']
})
export class CoverageComponent implements OnInit {
    isMobile: boolean = /Mobi/.test(navigator.userAgent);
    public coverageObj: any;
    public riskObj: any;
    public coverageName: string;
    public total: number = 0;
    ontotalchange = new EventEmitter<any>();
    onsichange = new EventEmitter<any>();
    onplanchange = new EventEmitter<any>();
    onagechange = new EventEmitter<any>();

    public search: String = "";
    public position = 1;
    public sizeObj = { length: 0, orglength: 0 };
    public contentSizeObs: any;
    public itemPerPage = 10;
    public maxPageCount = 5;
    public benefitFlag: boolean = false;
    public isOSIProduct: string = "N";
    public isRenewal: boolean = false;
    public isApprovalCompleted: string = "N";
    @ViewChild('coverageModal', { read: ViewContainerRef }) contentArea: ViewContainerRef;
    constructor(public dcl: CustomDCLService, private lovDropDownService: LOVDropDownService, private _soapService: CordysSoapWService, public _alertMsgService: AlertMessagesService) { }
    ngOnInit() {
        this.populateLOVs();
        //this.checkSingleRecord();
        this.setBenefitFlag();
        if (this.riskObj.riskType == 'OSI' || this.riskObj.riskType == 'OSS' || this.riskObj.riskType == 'PAX') {
            this.isOSIProduct = 'Y';
        }
        this.isApprovalCompleted = BMSConstants.getApprovalStatus();
    }
    handleRenewal() {
        if ((BMSConstants.getBMSObj().ApplicationBusinessObject.caseInfo.businessFunction != 'NewBusiness' && BMSConstants.getBMSObj().ApplicationBusinessObject.caseInfo.businessFunction != 'CoverNote')) {
            this.isRenewal = true;
        } else {
            this.isRenewal = false;
        }
    }

    checkSingleRecord() {
        if (this.coverageObj[this.coverageName] != null && !Array.prototype.isPrototypeOf(this.coverageObj[this.coverageName])) {
            this.coverageObj[this.coverageName] = [this.coverageObj[this.coverageName]];
        }
    }

    setBenefitFlag() {
        for (let coverage of this.coverageObj[this.coverageName]) {
            if (coverage.indicator == 'F') {
                this.benefitFlag = true;
                return;
            }
        }
    }

    private populateLOVs(): void {
        this.lovDropDownService.createLOVDataList(["Plan"]);
        let curDate = this.getDate();
        let riskType = this.getRiskType();
        // MO001 - Start
        let riTypeFilterDetails = [new SearchFilter("DESCITEM", riskType, "STARTSWITH", "AND"),
        new SearchFilter("ITMFRM", curDate, "LT", "AND"),
        new SearchFilter("ITMTO", curDate, "GT", "AND"),
        new SearchFilter("DESCITEM", "select distinct CONTITEM from T7072   where DESCITEM like '" + riskType + "%' and CONTITEM!='' and CONTITEM IS NOT NULL", "NOT IN", "AND")];
        // MO001 - End
        let riTypeSearchFilterNodes = this.lovDropDownService.createFilter(riTypeFilterDetails);
        let lovFields = [
            new LOV_Field("ALL", "PERSONAL ACCIDENT", "NEW BUSINESS", "ALL", "NEW", "PERSONAL ACCIDENT", "Plan", "LOV", riTypeSearchFilterNodes, "T7072", "Plan", null)
        ];
        this.lovDropDownService.util_populateLOV(lovFields, this);
    }

    removeCoverage(coverage) {
        this.coverageObj[this.coverageName].splice(this.coverageObj[this.coverageName].indexOf(coverage), 1);
        (this.coverageObj["paNPAItem"].length > 0) ? this.onsichange.emit(this.coverageObj["paNPAItem"][0].newSI) : this.onsichange.emit("0");
        this.emitTotal();
    }

    getRiskType() {
        let riskType = this.riskObj.riskType;
        while (riskType != undefined && riskType.length < 3) {
            riskType = riskType + " ";
        }
        return riskType;
    }

    onChangePlan(data) {
        this.coverageObj[this.coverageName] = [];
        let request: GetLOVData = new GetLOVData();
        request.BRANCH = 'ALL';
        request.LOB = 'ALL';
        request.BUSINESS_FUNCTION = 'NEW BUSINESS';
        request.PRODUCT = 'ALL';
        request.OPERATION = 'ALL';
        request.FORM_NAME = 'ALL';
        request.FORM_FIELD_NAME = 'Coverage Information';
        request.FIELD_TYPE = 'LOOKUP';
        request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        request.ADVANCE_CONFIG_XML.FILTERS = new Filter();
        let dateString = this.getDate();
        request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({ "@FIELD_NAME": 'DESCITEM', "@FIELD_VALUE": this.getRiskType() + "" + data.value, '@OPERATION': 'EQ', '@CONDITION': 'AND' },
            { "@FIELD_NAME": 'ITMFRM', "@FIELD_VALUE": dateString, '@OPERATION': 'LT', '@CONDITION': 'AND' },
            { "@FIELD_NAME": 'ITMTO', "@FIELD_VALUE": dateString, '@OPERATION': 'GT', '@CONDITION': 'AND' });
        this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.successHandler, this.handleError, true, { comp: this });
        this.emitPlanChange(data.value);
        this.emitTotal();
    }

    getDate() {
        return moment(new Date().toISOString(), "YYYY-MM-DD").format("YYYYMMDD");
    }

    handleError(response, status, errorText, prms) {
        prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, response.responseJSON.faultstring.text, -1));
    }

    successHandler(response, prms) {
        let ary = [];
        let contitem = '';

        if (response.tuple != null && !Array.prototype.isPrototypeOf(response.tuple)) {
            ary = [response.tuple];
        }
        else if (response.tuple != null) {
            ary = response.tuple;
        }
        prms.comp.benefitFlag = false;
        let capSI = 0;
        let planAge = 0;
        for (let coverage of ary) {
            let coverageInfo: CoverageInfo = {
                "coverageCode": coverage.old.T7072.ZCVCDE,
                "coverageDescription": coverage.old.T7072.COVER_DESC,
                "benefits": parseFloat(coverage.old.T7072.SUMIN) * parseInt(coverage.old.T7072.NOUNTS),
                "newSI": parseFloat(coverage.old.T7072.SUMIN) * parseInt(coverage.old.T7072.NOUNTS),
                "premium": parseFloat(coverage.old.T7072.GPDPREM),
                "rate": coverage.old.T7072.SRAT,
                "load": coverage.old.T7072.SLOA,
                "indicator": coverage.old.T7072.IND,
                "nounts": parseInt(coverage.old.T7072.NOUNTS),
                "optno": coverage.old.T7072.OPTNO,
                "optind": coverage.old.T7072.OPTIND,
                "contitem": coverage.old.T7072.CONTITEM
            };
            if (coverage.old.T7072.OPTNO == "1") {
                capSI = (parseFloat(coverage.old.T7072.ZSORIG) > 0) ? parseFloat(coverage.old.T7072.ZSORIG) * parseInt(coverage.old.T7072.NOUNTS) : parseFloat(coverage.old.T7072.SUMIN) * parseInt(coverage.old.T7072.NOUNTS);
            }
            if (coverage.old.T7072.IND == 'F')
                prms.comp.benefitFlag = true;

            if (coverage.old.T7072.CONTITEM != '' && contitem == '') {
                contitem = coverage.old.T7072.CONTITEM;
            }

            if (planAge == 0) {
                planAge = coverage.old.T7072.AGE;
                prms.comp.onagechange.emit(coverage.old.T7072.AGE);
            }

            if (coverageInfo.optind != 'O')
                prms.comp.coverageObj[prms.comp.coverageName].push(coverageInfo);
        }

        if (contitem != '')
            prms.comp.setContinuationItems(contitem);

        prms.comp.emitTotal();
        prms.comp.onsichange.emit(capSI);
    }

    setContinuationItems(data) {
        let request: GetLOVData = new GetLOVData();
        request.BRANCH = 'ALL';
        request.LOB = 'ALL';
        request.BUSINESS_FUNCTION = 'NEW BUSINESS';
        request.PRODUCT = 'ALL';
        request.OPERATION = 'ALL';
        request.FORM_NAME = 'ALL';
        request.FORM_FIELD_NAME = 'Coverage Information';
        request.FIELD_TYPE = 'LOOKUP';
        request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        request.ADVANCE_CONFIG_XML.FILTERS = new Filter();
        let dateString = this.getDate();
        request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({ "@FIELD_NAME": 'DESCITEM', "@FIELD_VALUE": data, '@OPERATION': 'EQ', '@CONDITION': 'AND' },
            { "@FIELD_NAME": 'ITMFRM', "@FIELD_VALUE": dateString, '@OPERATION': 'LT', '@CONDITION': 'AND' },
            { "@FIELD_NAME": 'ITMTO', "@FIELD_VALUE": dateString, '@OPERATION': 'GT', '@CONDITION': 'AND' });
        this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.continuationSuccessHandler, this.handleError, true, { comp: this });

    }

    continuationSuccessHandler(response, prms) {
        let ary = [];

        if (response.tuple != null && !Array.prototype.isPrototypeOf(response.tuple)) {
            ary = [response.tuple];
        }
        else if (response.tuple != null) {
            ary = response.tuple;
        }

        for (let coverage of ary) {
            let coverageInfo: CoverageInfo = {
                "coverageCode": coverage.old.T7072.ZCVCDE,
                "coverageDescription": coverage.old.T7072.COVER_DESC,
                "benefits": parseFloat(coverage.old.T7072.SUMIN) * parseInt(coverage.old.T7072.NOUNTS),
                "newSI": parseFloat(coverage.old.T7072.SUMIN) * parseInt(coverage.old.T7072.NOUNTS),
                "premium": parseFloat(coverage.old.T7072.GPDPREM),
                "rate": coverage.old.T7072.SRAT,
                "load": coverage.old.T7072.SLOA,
                "indicator": coverage.old.T7072.IND,
                "nounts": parseInt(coverage.old.T7072.NOUNTS),
                "optno": coverage.old.T7072.OPTNO,
                "optind": coverage.old.T7072.OPTIND,
                "contitem": coverage.old.T7072.CONTITEM
            };

            if (coverage.old.T7072.IND == 'F')
                prms.comp.benefitFlag = true;
            if (coverageInfo.optind != 'O')
                prms.comp.coverageObj[prms.comp.coverageName].push(coverageInfo);
        }

        prms.comp.emitTotal();
    }

    setPremiumForEach(coverage, index) {
        let rate = (coverage.rate == null || coverage.rate == "") ? 0 : coverage.rate;
        let load = (coverage.load == null || coverage.load == "") ? 0 : coverage.load;
        let newSI = (coverage.benefits == null || coverage.benefits == "") ? 0 : coverage.benefits;
        coverage.newSI = Number(coverage.benefits) * Number(coverage.nounts);
        let premium = (parseFloat(newSI) * (parseFloat(rate) * 0.01));
        let loadPremium = (Number(premium) * (parseFloat(load) * 0.01));
        if (coverage.indicator == 'F')
            coverage.premium = Number(coverage.premium) + Number(premium) + Number(loadPremium);
        else
            coverage.premium = Number(premium) + Number(loadPremium);
        loadPremium = numeral(loadPremium).format('0.00');
        coverage.premium = numeral(coverage.premium).format('0.00');
        if (index == 0)
            this.onsichange.emit(coverage.newSI);
        this.emitTotal();
    }

    getTotalByProperty(prop, ary) {
        let total = numeral(0);
        for (let eachItem of ary) {
            if (eachItem[prop] != null && eachItem[prop] != "")
                total = total.add(numeral().unformat(eachItem[prop]));
        }
        total = numeral(total).format('0.00');
        return total;
    }

    emitTotal() {
        let total = this.getTotalByProperty("premium", this.coverageObj[this.coverageName])
        this.ontotalchange.emit(total);
    }

    emitPlanChange(plan) {
        let emitVal = this.getRiskType() + "" + plan;
        this.onplanchange.emit(emitVal);
    }

    openAddBenefit(coverage) {
        let searchInput = new SearchInput();
        searchInput.isSingleSelect = false;
        searchInput.BRANCH = 'ALL';
        searchInput.BUSINESS_FUNCTION = 'NEW BUSINESS';
        searchInput.FIELD_TYPE = 'LOOKUP';
        searchInput.FORM_FIELD_NAME = 'Add Coverage Benefit';
        searchInput.FORM_NAME = 'NPA_ADD_BENEFIT';
        searchInput.LOB = 'PA';
        searchInput.OPERATION = 'NEW';
        searchInput.PRODUCT = 'NPA';
        let benefitCode = "''";

        if (this.coverageObj[this.coverageName].length > 0) {
            let newArr = [];
            for (let item of this.coverageObj[this.coverageName]) {
                newArr = newArr.concat(item["coverageCode"]);
            }
            benefitCode = "'" + newArr.toString().replace(/,/g, "\',\'") + "'";
        }

        let descItem = "'" + this.getRiskType() + "" + this.riskObj.plan + "'";//MD001
        if (this.coverageObj[this.coverageName][0] != undefined && this.coverageObj[this.coverageName][0]["contitem"])
            descItem += "," + "'" + this.coverageObj[this.coverageName][0]["contitem"] + "'";

        searchInput.condition = { "DESCITEM": descItem, "ITMFRM": this.getDate(), "ITMTO": this.getDate(), "ZCVCDE": benefitCode };

        let input = new ModalInput();
        input = input.get("GenericSearchComponent");
        input.datainput = searchInput;
        input.outputCallback = this.addBenefit;
        input.parentCompPRMS = { comp: this };
        input.heading = "Add Coverage Items";
        input.icon = "fa fa-file-pdf-o";
        input.containerRef = this.contentArea;
        this.dcl.openLookup(input);
    }

    addBenefit(response, prms) {
        let ary = [];
        let contitem = '';

        if (response != null && !Array.prototype.isPrototypeOf(response)) {
            ary = [response];
        }
        else if (response != null) {
            ary = response;
        }
        prms.comp.benefitFlag = false;
        let capSI = 0;
        let planAge = 0;
        for (let coverage of ary) {
            let coverageInfo: CoverageInfo = {
                "coverageCode": coverage.old.T7072.ZCVCDE,
                "coverageDescription": coverage.old.T7072.COVER_DESC,
                "benefits": parseFloat(coverage.old.T7072.SUMIN) * parseInt(coverage.old.T7072.NOUNTS),
                "newSI": parseFloat(coverage.old.T7072.SUMIN) * parseInt(coverage.old.T7072.NOUNTS),
                "premium": parseFloat(coverage.old.T7072.GPDPREM),
                "rate": coverage.old.T7072.SRAT,
                "load": coverage.old.T7072.SLOA,
                "indicator": coverage.old.T7072.IND,
                "nounts": parseInt(coverage.old.T7072.NOUNTS),
                "optno": coverage.old.T7072.OPTNO,
                "optind": coverage.old.T7072.OPTIND,
                "contitem": coverage.old.T7072.CONTITEM
            };
            if (coverage.old.T7072.OPTNO == "1" && !prms.comp.riskObj.capitalSumInsured) {
                capSI = (parseFloat(coverage.old.T7072.ZSORIG) > 0) ? parseFloat(coverage.old.T7072.ZSORIG) * parseInt(coverage.old.T7072.NOUNTS) : parseFloat(coverage.old.T7072.SUMIN) * parseInt(coverage.old.T7072.NOUNTS);
            }
            else {
                capSI = numeral().unformat(prms.comp.riskObj.capitalSumInsured);
            }
            if (coverage.old.T7072.IND == 'F')
                prms.comp.benefitFlag = true;

            if (coverage.old.T7072.CONTITEM != '' && contitem == '') {
                contitem = coverage.old.T7072.CONTITEM;
            }

            if (planAge == 0) {
                planAge = coverage.old.T7072.AGE;
                prms.comp.onagechange.emit(coverage.old.T7072.AGE);
            }

            prms.comp.coverageObj[prms.comp.coverageName].push(coverageInfo);
        }
        prms.comp.emitTotal();
        prms.comp.onsichange.emit(prms.comp.coverageObj["paNPAItem"][0].newSI);
    }
    public filterInput(event) {
        if (event.type == 'paste' || event.type == 'drop') {
            let data = (event.type == 'paste') ? event.clipboardData.getData('text/plain') : event.dataTransfer.getData('text/plain');
            return (data.indexOf('e') != -1 || data.indexOf('E') != -1) ? false : true;

        }
        else {
            return (event.keyCode == 69) ? false : true;
        }

    }
}

export class CoverageInfo {
    public coverageCode: string;
    public coverageDescription: string;
    public benefits: number = 0;
    public newSI: number = 0;
    public premium: number = 0;
    public rate: number = 0;
    public load: number = 0;
    public indicator: string;
    public nounts: number = 0;
    public optno: string;
    public optind: string;
    public contitem: string;
}
