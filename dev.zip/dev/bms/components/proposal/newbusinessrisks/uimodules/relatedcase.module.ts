import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { BasicUIModule } from '../../../../../common/components/utility/basicui.module';

import { RelatedCaseComponent } from './relatedcase.component';

@NgModule({
    imports: [CommonModule, FormsModule, ReactiveFormsModule, BasicUIModule],
    declarations: [RelatedCaseComponent],
    exports: [RelatedCaseComponent]
})
export class RelatedCaseModule { }
