import { Component, OnInit, ViewChild, ViewContainerRef } from '@angular/core';


declare var jQuery: any;

@Component({
    selector: "sub-clauses-component",
    templateUrl: "app/bms/components/proposal/newbusinessrisks/uimodules/subclauses.template.html",
    inputs: ['datainput', 'parentCompPRMS', 'closeDialog']
})
export class SubClausesDialogComponent implements OnInit {

    private dialogName: string;
    public comments: string;
    public parentCompParams: any;

    public datainput: any;
    public parentCompPRMS: any;
    public closeDialog: Function;

    ngOnInit() {
        this.dialogName = this.datainput.dialogName;
        this.parentCompParams = this.datainput.params;
        this.comments = this.formatClauses(this.datainput.comments);
    }

    private CloseDialogCommemnts() {
        this.CloseDialogWithComments();
    }

    private CloseDialogWithComments() {
        this.closeDialog({
            dialogName: this.dialogName,
            comments: this.comments
        },
            this.parentCompPRMS
        );
    }

    private cancelDialog() {
        this.closeDialog({
            dialogName: this.dialogName,
            isDialogCancelled: true
        },
            this.parentCompPRMS
        );
    }

    private formatClauses(wording) {
        let x: any = wording.split(".");
        let y: string = "";
        if (x.length > 1) {
            for (let i of x) {
                if (i.split("¦").length > 1) {
                    let j: any = i.split("¦");
                    for (let k of j) {
                        y = y + "\n" + k.trim();
                    }
                } else {
                    y = y + "\n" + i.trim();
                }

            }
        } else {
            y = x;
        }

        return y;
    }
}