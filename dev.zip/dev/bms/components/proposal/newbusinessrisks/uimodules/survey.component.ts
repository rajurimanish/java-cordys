/*
*  Change History	:
*
*	No      Date           Description                          Changed By
*	====    ==========     ===========                          ==========
*   VK001   10/10/2018     MYS-2018-1026 : Security Fix            VKR
*
*
*/

import { Component, OnInit } from "@angular/core";
import { Survey, UploadDownloadItem, NewBusiness, NewPolicySI } from '../appobjects/survey';
import { ApplicationUtilService } from '../../../../../common/services/application.util.service';
import { ProposalHeader } from '../../proposalheader/appobjects/proposalheader';
import { ClientDetails } from '../../../../../common/components/client/appobjects/client';
import { DatePicker } from '../../../../../common/components/utility/date/datepicker.component';
import { AlertMessagesService } from '../../../../../common/components/utility/alertmessage/alertmessages.service';
import { AlertMessage } from '../../../../../common/components/utility/alertmessage/alertmessages.model';
import { CaseInfo } from '../../../../../common/components/appobjects/caseinfo';
import { CordysSoapWService } from "../../../../../common/components/utility/cordys-soap-ws";
import { LOV_Field, LOVDropDownService, SearchFilter } from '../../../../../common/services/lovdropdown/lovdropdown.service';
import { BMSAppObjService } from '../../../../services/bmsappobj.service';

declare var moment: any;
declare var JSON: any;

@Component({
    selector: 'survey-comp',
    templateUrl: 'app/bms/components/proposal/newbusinessrisks/uimodules/survey.template.html',
    inputs: ["_survey", "_clientDetails", "_headerInfo", "caseInfo", "_riskObj"]
})

export class SurveyComponent implements OnInit {
    private _survey: Survey;
    private _headerInfo: ProposalHeader;
    private _clientDetails: ClientDetails;
    private _riskObj: any;
    private selectioncntrlPerson: string;
    public startDateCtrl: any;
    public completeDateCtrl: any;
    public caseInfo: CaseInfo;
    private inDisabled: boolean = false;
    public survey_url: string = "";
    constructor(private _aus: ApplicationUtilService, public _alertMsgService: AlertMessagesService, private _soapService: CordysSoapWService, private lovDropDownService: LOVDropDownService, private _appObjService: BMSAppObjService) { }

    ngOnInit() {
        this.checkStatusDiabled();
        this.getConfig();
        this.assignCreatedByValue();
        this.setContactPersonSelection();
        this.populateLovs();
    }

    checkStatusDiabled() {

        if (this.caseInfo.status == "Policy Processing" || this.caseInfo.status == "P400 Pending NB" || this.caseInfo.status == "P400 In forced" || this.caseInfo.status == "Closed") {
            this.formDisabled();
            if (this._riskObj.surveyNumber != null && this._riskObj.surveyNumber != undefined) {
                if (this.caseInfo.status != "Closed" && (this._riskObj.surveyStatus == null || this._riskObj.surveyStatus == undefined)) {
                    this._riskObj.surveyStatus = "Survey Initiated";
                }
                else {
                    if (this._riskObj.surveyStatus == null || this._riskObj.surveyStatus == undefined)
                        this._riskObj.surveyStatus = "Completed";
                }

            }
        }
        else {
            if (this._riskObj.surveyNumber == null || this._riskObj.surveyNumber == undefined || this._riskObj.surveyNumber == "") {
                if (this._riskObj.surveyStatus == null || this._riskObj.surveyStatus == undefined) {
                    this._riskObj.surveyStatus = "Not Started";
                    this._survey.basicDetails.dateOfReq = "";
                    this.inDisabled = false;
                }
            }
            else {
                this.inDisabled = true;
            }
        }
        this._riskObj.surveyor = this._survey.clientDetails.contactPerson;

    }

    /*Adding the state LOVDropDown*/
    populateLovs() {
        this.lovDropDownService.createLOVDataList(["StateCode", "Survey Type", "RiskOccp"]);

        let lovFields = [new LOV_Field("ALL", "FIRE", "NEW BUSINESS", "ALL", "NEW", "SURVEY_FIRE", "State", "LOV", [], "DESCPF", "StateCode", null),
        new LOV_Field("ALL", "FIRE", "NEW BUSINESS", "ALL", "NEW", "SURVEY_FIRE", "Survey Type", "LOV", [], "DESCPF", "SurveyType", null),
        new LOV_Field("ALL", "FIRE", "NEW BUSINESS", "ALL", "NEW", "SURVEY_FIRE", "RiskOccp", "LOV", [], "DESCPF", "RiskOccp", null)];

        this.lovDropDownService.util_populateLOV(lovFields, this);
    }


    setSystemDefaultValues() {
        this.setBasicDetails();
        this.setClientDetails();
        this.setOccupationDetails();
        this.setSurveyDetails();
        this._survey.bpmUniqueId = this.caseInfo.caseId;
        this.setOtherDetails();
    }

    initSurvey() {
        if (this.caseInfo.caseId != null && this.caseInfo.caseId != "") {
            this.setSystemDefaultValues();
        } else {
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Please save the Proposal and then Initiate Survey", -1));
        }

    }

    getConfig() {
        this._soapService.callCordysSoapService("GetSurveryAppConfig", "http://schemas.opentext.com/msig/persistancedb/1.0", null, this.getConfigSuccessHandler, this.handleError, false, { comp: this });
    }

    getConfigSuccessHandler(resp, prms) {
        if ((resp != null) && (resp.tuple) && (resp.tuple.old) && (resp.tuple.old.getSurveryAppConfig) && (resp.tuple.old.getSurveryAppConfig.getSurveryAppConfig) && (resp.tuple.old.getSurveryAppConfig.getSurveryAppConfig.config)) {
            prms.comp.survey_url = resp.tuple.old.getSurveryAppConfig.getSurveryAppConfig.config.url;
            prms.comp._survey.userid = atob(resp.tuple.old.getSurveryAppConfig.getSurveryAppConfig.config.userName);
            prms.comp._survey.password = atob(resp.tuple.old.getSurveryAppConfig.getSurveryAppConfig.config.password);
        }
    }

    setBasicDetails() {
        if (this._riskObj.surveyNumber != null && this._riskObj.surveyNumber != undefined) {
            this._survey.basicDetails.dateOfReq = moment().format("DD/MM/YYYY");
        } else {
            this._survey.basicDetails.dateOfReq = "";
        }
        this._survey.basicDetails.department = this.caseInfo.handlingBranchId;
    }

    assignCreatedByValue() {
        this._aus.getUserDn().subscribe((data) => this.processDn(data));
    }

    processDn(data) {
        if (data != null) {
            //data.substring(data.indexOf("=")+1,data.indexOf(","))
            this._survey.createdBy = data.substring(data.indexOf("=") + 1, data.indexOf(","));
            this._survey.basicDetails.from = "MYITRSA05";
        }
    }


    setClientDetails() {
        if (this._clientDetails.client.genericDetails.clienttype != "C") {
            this._survey.clientDetails.insuredName = this._clientDetails.client.personalClientDetails.Name;
            this._survey.clientDetails.emailId = this._clientDetails.client.personalClientDetails.email;
            //this._survey.clientDetails.emailId ="BPM@gmail.com";
            this._survey.clientDetails.addressLine1 = this._clientDetails.client.personalClientDetails.address.address1;
            this._survey.clientDetails.addressLine2 = this._clientDetails.client.personalClientDetails.address.address2;
            this._survey.clientDetails.addressLine3 = this._clientDetails.client.personalClientDetails.address.address3;
            this._survey.clientDetails.countryid = this._clientDetails.client.personalClientDetails.address.country;
            this._survey.clientDetails.city = this._clientDetails.client.personalClientDetails.address.city;
            this._survey.clientDetails.postCode = this._clientDetails.client.personalClientDetails.address.postCode;
            //	this._survey.clientDetails.contactNumber = this._clientDetails.client.personalClientDetails.address.telephone1.replace(/-/g, '');
            this._survey.clientDetails.salutation = "MR";


        }
        else {
            this._survey.clientDetails.insuredName = this._clientDetails.client.corporateClientDetails.corporation;
            this._survey.clientDetails.emailId = this._clientDetails.client.corporateClientDetails.email;
            //this._survey.clientDetails.emailId ="BPM@gmail.com";
            this._survey.clientDetails.addressLine1 = this._clientDetails.client.corporateClientDetails.address.address1;
            this._survey.clientDetails.addressLine2 = this._clientDetails.client.corporateClientDetails.address.address2;
            this._survey.clientDetails.addressLine3 = this._clientDetails.client.corporateClientDetails.address.address3;
            this._survey.clientDetails.countryid = this._clientDetails.client.corporateClientDetails.address.country;
            this._survey.clientDetails.city = this._clientDetails.client.corporateClientDetails.address.city;
            this._survey.clientDetails.postCode = this._clientDetails.client.corporateClientDetails.address.postCode;
            //this._survey.clientDetails.contactNumber = this._clientDetails.client.corporateClientDetails.address.telephone1.replace(/-/g, '');

            this._survey.clientDetails.salutation = "MR";
            //this._survey.clientDetails.salutation	= this._clientDetails.client.corporateClientDetails.saluation;

        }

        this._survey.clientDetails.intermediaryCode = this._headerInfo.agentCode;
        this._survey.clientDetails.intermediaryName = this._headerInfo.agentName;
    }

    setOccupationDetails() {
        if (this._riskObj.PIAMCode && this._riskObj.PIAMCode.length != 0) {
            this._survey.occupationDetails.piamCode = this._riskObj.PIAMCode;
        }
        else {
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Please select piam code in risk ", -1));
            return;
        }
        this._survey.occupationDetails.constructionClass = this._riskObj.construction;
    }

    setSurveyDetails() {
        let newBusiness = new NewBusiness();
        newBusiness.totalNewPolicySI = this._riskObj.totalSI;
        newBusiness.totalSI = this._riskObj.totalSI;
        this._survey.surveyDetails.newBusiness = [];
        for (let cover of this._riskObj.fireItems.fireItems) {
            let newSIItem = new NewPolicySI();
            newSIItem.siFor = cover.cover;
            newSIItem.si = cover.sumInsured;
            newBusiness.newPolicySIList.push(newSIItem);
        }
        this._survey.surveyDetails.newBusiness.push(newBusiness);
    }

    setOtherDetails() {
        this.processSurveyAttachments();
    }

    selectIntermediary(value) {
        if (value == "Intermediary") {
            this._survey.clientDetails.intermediary = "1";
            this._survey.clientDetails.insured = "0";
        } else {
            this._survey.clientDetails.intermediary = "0";
            this._survey.clientDetails.insured = "1";
        }

    }

    setContactPersonSelection() {
        if (this._survey.clientDetails.insured != null && this._survey.clientDetails.insured == "1") {
            this.selectioncntrlPerson = "Insured";
        }
        else {
            this.selectioncntrlPerson = "Intermediary";

        }
    }

    getListOfSurveyAttachments() {
        return this.caseInfo.attachmentInfo.attachment.filter((item) => item.attachmentType == "SURVRP");
    }

    processSurveyAttachments() {
        let attachmentList = this.getListOfSurveyAttachments();
        let index = 0;
        this._survey.otherDetails.documentsDetails.uploadDownloadList = [];
        if (attachmentList.length > 0) {
            let checkStatus = Array.apply(null, Array(attachmentList.length)).map(String.prototype.valueOf, "false");

            for (let eachAttach of attachmentList) {
                // VK001 Passing empty instead of path to xmlStoreECMPropPath 	
                let request = {
                    documentURL: eachAttach.sLocationUrl,
                    fetchContent: "true",
                    //xmlStoreECMPropPath: '/OpenText/Integration/ecm-config.xml',
                    xmlStoreECMPropPath: ''
                };
                this._soapService.callCordysSoapService("GetDocument", "http://schemas.cordys.com/ecm/integration/1.0", request, this.addDocumentToSurvey, this.handleError, true, { comp: this, isLast: (index == attachmentList.length), attachment: eachAttach, docObj: this._survey.otherDetails.documentsDetails, checkStatus, index });
                index++;
            }
        } else {
            this.postSurvey();
        }
    }

    addDocumentToSurvey(response, prms) {

        let docItem = new UploadDownloadItem();
        let mimeType = "";
        let checkindex = 0;
        let listFordetails = [];
        if (response.tuple != null) {
            mimeType = response.tuple.old.getDocument.getDocument.GetDocumentResponse.Properties.MimeType;
            docItem.fileSrc = "data:" + mimeType + ";base64," + response.tuple.old.getDocument.getDocument.GetDocumentResponse.DocumentContent.text;
        }
        docItem.docType = prms.attachment.attachmentType;
        docItem.docName = prms.attachment.attachmentName;
        docItem.remarks = prms.attachment.comments;
        docItem.hardCopy = "false";
        docItem.actionFlag = "I";
        docItem.docIndex = "0";
        docItem.fileSize = prms.attachment.size;
        docItem.fileType = mimeType;
        docItem.fileName = prms.attachment.attachmentName;
        docItem.isMandatory = "false";
        docItem.fileExtension = prms.attachment.fileExtension;
        prms.docObj.uploadDownloadList.push(docItem);
        if (prms.checkStatus.length > 0) {
            prms.checkStatus[(prms.index)] = "true";
        }

        listFordetails = (prms.checkStatus.filter((item) => item == "false"));

        if (!(listFordetails.length > 0)) {
            prms.comp.postSurvey();
        }

    }

    handleError(response, status, errorText, prms) {
        prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, response.responseJSON.faultstring.text, -1));
    }

    postSurvey() {
        var ErrorMssg = "";
        var index = 0;
        this._survey.basicDetails.dateOfReq = moment().format("DD/MM/YYYY");

        if (this.validatesurvey() == true) {
            if (this._riskObj.PIAMCode == null || this._riskObj.PIAMCode == undefined || this._riskObj.PIAMCode == "") {
                index++;
                ErrorMssg = ErrorMssg + "" + index + ":PIAM code<br>";
            } if (this._riskObj.construction == null || this._riskObj.construction == undefined || this._riskObj.construction == "") {
                index++;
                ErrorMssg = ErrorMssg + "" + index + ":Construction code<br>";
            }
            if (ErrorMssg != "") {
                this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Fire  Section,Maditory Feilds for Initating Survey<br>" + ErrorMssg, -1));
                return;
            }
            this._soapService.httppost(this.survey_url, JSON.stringify(this._survey), 'application/json').subscribe((resp) => this.processSurveyResp(resp), err => this.logError(err));
        }
    }
    logError(err) {
        this._riskObj.surveyStatus = "Error";
        this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error While Intiating Survey  Contact Administrator", -1));

    }
    validatesurvey() {
        var ErrorMessage = "";
        var index = 0;
        if (this._survey.clientDetails.contactPerson == null || this._survey.clientDetails.contactPerson == undefined || this._survey.clientDetails.contactPerson == "") {
            index++;
            ErrorMessage = ErrorMessage + " " + index + ": Contact Person<br>";
        }
        if (this._survey.clientDetails.contactNumber == null || this._survey.clientDetails.contactNumber == undefined || this._survey.clientDetails.contactNumber == "") {
            index++;
            ErrorMessage = ErrorMessage + " " + index + ":Contact Number<br>";
        }
        if (this._survey.clientDetails.state == null || this._survey.clientDetails.state == undefined || this._survey.clientDetails.state == "") {
            index++;
            ErrorMessage = ErrorMessage + " " + index + ":State Feild <br>";
        }
        if (this._riskObj.surveyType == null || this._riskObj.surveyType == undefined || this._riskObj.surveyType == "") {
            index++;
            ErrorMessage = ErrorMessage + " " + index + ":Survey Type <br>";
        }

        if (ErrorMessage != "") {
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Survey  Section,Maditory Feilds for Initating Survey<br>" + ErrorMessage, -1));
            return false;
        } else {
            return true;
        }

    }

    processSurveyResp(resp) {
        let valError: string;
        if (resp.riskSurveyId != null && resp.riskSurveyId != undefined) {
            this._riskObj.surveyNumber = resp.riskSurveyId;

            if (this._riskObj.surveyNumber != null && this._riskObj.surveyNumber != undefined) {
                this.formDisabled();
                this._riskObj.surveyStatus = "Survey Initiated";
                //Save the survey details onto the BO
                this._appObjService.saveData().subscribe();

            } else {
                this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, resp.message, -1));
            }
        }
        else {
            valError = "Error While Initiating Survey ";
            if (resp.validationList && resp.validationList.length !== 0) {
                for (let i = 0; i < resp.validationList.length; i++) {
                    if (resp.validationList[i] != null && resp.validationList[i] != undefined) {
                        valError = valError + "<br>" + ((i + 1) + " : " + resp.validationList[i]);
                    }
                }
            }
            this._riskObj.surveyStatus = "Error";
            this.inDisabled = false;
            this._survey.basicDetails.dateOfReq = "";

            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, valError, -1));
        }
    }

    formDisabled() {
        this.inDisabled = true;
        //this.inDisabled  = true;

    }


}