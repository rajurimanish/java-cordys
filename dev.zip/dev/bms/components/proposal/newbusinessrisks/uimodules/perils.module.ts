import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BasicUIModule } from '../../../../../common/components/utility/basicui.module';
import { PaginationModule } from '../../../../../common/components/utility/pagination/pagination.module';
import { PerilsComponent } from './perils.component';



@NgModule({
    imports: [CommonModule, FormsModule, ReactiveFormsModule, BasicUIModule, PaginationModule],
    declarations: [PerilsComponent],
    exports: [PerilsComponent]
})
export class PerilModule { }