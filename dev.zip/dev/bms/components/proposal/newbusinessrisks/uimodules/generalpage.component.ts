/*
	No		Date			Description										Changed By
	====    ==========    	===========                                 	==========
	VK013   12/08/2019   	MYS-2019-0595- General Page(Print) alignment    VKR
                         
*/
import { Component, OnInit } from '@angular/core';
import { AlertMessage } from '../../../../../common/components/utility/alertmessage/alertmessages.model';
import { AlertMessagesService } from '../../../../../common/components/utility/alertmessage/alertmessages.service';
import { CordysSoapWService } from "../../../../../common/components/utility/cordys-soap-ws";
import { CustomDCLService } from '../../../../../common/services/customdcl.service';

@Component({
    selector: 'general-page-component',
    templateUrl: 'app/bms/components/proposal/newbusinessrisks/uimodules/generalpage.template.html',
    inputs: ['riskObj', 'headerInfo']
})

export class GeneralPageComponent implements OnInit {

    public riskObj: any;
    public headerInfo: any;
    constructor(public dcl: CustomDCLService, public _alertMsgService: AlertMessagesService, private _soapService: CordysSoapWService) { }

    ngOnInit() { 
     
    }

    public lineCount(event) {
        //VK013
       // var gpTextResponse = this._soapService.callCordysSoapService("CoverageExtraTextDT", "http://schemas.cordys.com/bmsintegrationapp", { "extraText": event.target.value }, this.successOfgpTextResponse, null, true, { comp: this });
       
        var value = event.target.value;
        var valid = true;
        var maxLineChars = 60;
        var result = "";
        var finalLines = [];
        var lines = value.split(/\r\n|\r|\n/g);
        var length = lines.length;
        var str1: String,str2: String,strn: String,temp_str: String;
        var x = false;
        
        for (var i = 0; i < length; i++) {
            if (lines[i].length > maxLineChars) {
                    strn = lines[i];
                        while( strn.length > maxLineChars ){
                        str1 = strn.substring(0, maxLineChars);
						str2 = strn.substring(maxLineChars);
						
						if( !str1.endsWith(" ") && !str2.startsWith(" ") && str1.lastIndexOf(" ") != -1) {
							
							str1 = str1.substring(0, str1.lastIndexOf(" "));
							temp_str = strn.substring(str1.length);
							if(temp_str.startsWith(" ")) {
								strn = strn.substring(str1.length+1);
							} else { 
								strn = temp_str;
							}
						}
						else {
							strn = str2;
                        }
                        finalLines[finalLines.length] = str1;
                    }
                    if(strn != "" && strn.length <= maxLineChars) {
                        finalLines[finalLines.length] = strn;
                    }
                } else {
                finalLines[finalLines.length] = lines[i];
            }
        }
        this.riskObj.gpTextCount = finalLines.length;
        if(this.riskObj.gpTextCount >  Number(this.headerInfo.gpTextMaxLines)) {
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "General Page text value exceded the maximum allowed (400) lines. Total General Page lines are :" + this.riskObj.gpTextCount + ".", 10000));
        }
        for (var i = 0; i < this.riskObj.gpTextCount; i++) {
            result += finalLines[i];
            if (i + 1 < this.riskObj.gpTextCount) {
                result += "\n";
            }
        }
        event.target.value = result;
        this.riskObj.gpText = result;
        
    }

    /*private wrapLinesNew(event) {
        var text = event;
        var valid = true;
        var maxLineChars = 60;
        var result = "";
        var value = text.trim();
        var finalLines = [];
        var lines = value.split(/\r\n|\r|\n/g);
        var length = lines.length;
        
        for (var i = 0; i < length; i++) {
            if (lines[i].length > maxLineChars) {
                var str = lines[i];
                var strIndex = 0;
                do {
                    finalLines[finalLines.length] = str.substring(0, maxLineChars);
                    strIndex += maxLineChars;
                    str = str.substring(maxLineChars, str.length);
                } while (str.length > maxLineChars);
                finalLines[finalLines.length] = str;
            } else {
                finalLines[finalLines.length] = lines[i];
            }
        }
        this.riskObj.gpTextCount = finalLines.length;
        if(this.riskObj.gpTextCount >  Number(this.headerInfo.gpTextMaxLines)) {
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "General Page text value exceded the maximum allowed (400) lines. Total General Page lines are :" + this.riskObj.gpTextCount + ".", 10000));
        }
        for (var i = 0; i < this.riskObj.gpTextCount; i++) {
            result += finalLines[i];
            if (i + 1 < this.riskObj.gpTextCount) {
                result += "\n";
            }
        }
        //event.target.value = result;
    } */

    //VK013 END
    
    private successOfgpTextResponse(data, prms) {
        if (data.tuple && data.tuple.old && data.tuple.old.coverageExtraTextDT.coverageExtraTextDT) {
            if (data.tuple.old.coverageExtraTextDT.coverageExtraTextDT.GEN.SEQNOGPS) {
                prms.comp.riskObj.gpTextCount = data.tuple.old.coverageExtraTextDT.coverageExtraTextDT.GEN.SEQNOGPS.SEQNOGP.length;
                if (Number(prms.comp.riskObj.gpTextCount) > Number(prms.comp.headerInfo.gpTextMaxLines)) {
                    prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "General Page text value exceded the maximum allowed (400) lines. Total General Page lines are :" + prms.comp.riskObj.gpTextCount + ".", 10000));
                }
            }
        }
    }


}