import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BasicUIModule } from '../../../../../common/components/utility/basicui.module';
import { CoverageModule } from "../uimodules/coverage.module";
import { ClausesModule } from "../uimodules/clauses.module";
import { NomineeModule } from "../uimodules/nominee.module";
import { FIModule } from '../../../../../common/components/financialinterest/fi.module';
import { GSTModule } from '../uimodules/gst.module';
import { GeneralPageModule } from '../uimodules/generalpage.module'; //VK004

import { PersonalAccidentComponent } from './pa.component';

@NgModule({
    imports: [CommonModule, FormsModule, ReactiveFormsModule, BasicUIModule, CoverageModule, ClausesModule, NomineeModule, FIModule, GSTModule, GeneralPageModule],
    declarations: [PersonalAccidentComponent],
    exports: [PersonalAccidentComponent]
})
export class PersonalAccidentModule { }