/*
 * Change History	:
 *
 * 	No      Date         Description                                 			  Changed By
 *	====    ==========   ===========                                 			  ==========
 *	GA001   09/07/2018   MYS-2018-0443 - Age Checking for PA Products (T7253)    	KGA				 								   
*/
import { Nominee, NomineeDetails } from "../../appobjects/nomineeslist";
import { Clause } from "../../appobjects/clause";
import { GSTDetails } from '../../appobjects/gstDetails';
import { AppUtil } from '../../../../../../common/components/utility/apputil/app.util';
import { NBRisk } from '../../../appobjects/nbrisk';
import { PostedPrem } from '../../../proposalheader/appobjects/postedprem';
import { RiskHelper } from '../../../appobjects/riskhelper';
import { ReferredReason } from '../../../proposalheader/appobjects/referredreason';
import { NPAValidator } from '../../../validation/npa.validator';
import { ReferralReasons } from '../../appobjects/referralReasons';//GA001

export class IndividualPersonalAccident extends RiskHelper implements NBRisk {
    public effectiveDate: string;
    public dateOfAttachment: string;
    public contractNumber: string;
    public contractType: string;
    public riskNumber: string;
    public riskType: string;
    public ratingFlag: string = "A";// added for SAF MYS-2017-1108;
    public staffNo: string;
    public grossFloorArea: string;
    public occupationCode: string;
    public occupationDescription: string;
    public ratingClass: string = "";
    public plan: string;
    public noOfUnits: number = 1;
    public SICurrency: string;
    public currencyRate: number = 1.0000000;
    public situation: string;
    public basicPremium: number = 0;
    public additionalCode: string;
    public additionalLoading: string;
    public addditionalPremium: number = 0;
    public capitalSumInsured: string;
    public totalGrossCapacity: number = 0;
    public totalPremium: number = 0;
    public renewalBonusPercentage: string;
    public renewalBonusAmount: string;
    public terminationDate: string;
    public GT: string;
    public OE: string;
    public FI: string = "N";
    public NO: string;
    public GP: string;
    public CL: string;
    public IN: string;
    public paNPAItems: PANPAItems;
    public hasClaimExperience: String = "N";
    public riskClassification: string = "Standard";
    public isRIRequired: string = "No";
    public isCo_insurance: string = "No";
    public RIRetentionCode: string = "PA01";
    public nomineeDetails: NomineeDetails;
    public additionalCoverDetails: AdditionalCoverageDetails;
    public insuredPersonDetails: InsuredPerson;
    public clauses: Clause;
    public RIMethod: string = "1";
    public RIRequired: string = "No";
    public RIMethodSys: string = "0";
    public isRIOverWrittenByUW: string = "N";
    public identity: string = "";
    public minimumPremium: number = 0;
    public originalTotalPremium: number = 0;
    public postedPremium: number = 0;
    public basePostedPremiumAdj: number = 0;
    public discountedPremium: number = 0;
    public rebate: number = 0;
    public rebateAmount: number = 0;
    public GST: number = 0; //6; //SAF MYS-2018-0629
    public gstAmount: number = 0;
    public symRiskClassification: string = "";
    public occRiskClassification: string;
    public riskClassificationReason: string = '';
    public overseasEducationDetails: OverseasEducationDetails;
    public GSTDetails: GSTDetails;
    public isPOIConsidered: string = "N";
    public priority: string;
    public postedPremDetails: PostedPrem;
    public childRiskPath: string;
    public childRiskIdentity: string;
    public riskClassificationReasons: ReferredReason;
    public gpText: string;
    public gpTextCount:string;//VK004
    //GA001 START
    public ageLimitFlag: string = "";
    public referralReasons: ReferralReasons;
    public ageMin: string = "";
    public ageMax: string = "";
    //GA001 END
    public SST: number = 0; //SST Code
    public sstAmount: number = 0;//SST Code
    public GSTLiveDate: string;//SST Code
    public SSTLiveDate: string;//SST Code
    public isGSTApplicable: boolean = true;//SST Code
    constructor() {
        super();
        this.paNPAItems = new PANPAItems();
        this.nomineeDetails = new NomineeDetails();
        this.additionalCoverDetails = new AdditionalCoverageDetails();
        this.insuredPersonDetails = new InsuredPerson();
        this.clauses = new Clause();
        this.overseasEducationDetails = new OverseasEducationDetails();
        this.GSTDetails = new GSTDetails();
        this.riskClassificationReasons = new ReferredReason();
        this.referralReasons = new ReferralReasons();//GA001
    }

    public getInstance(valObj: IndividualPersonalAccident) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
            this.paNPAItems = new PANPAItems().getInstance(valObj.paNPAItems);
            this.clauses = new Clause().getInstance(valObj.clauses);
            this.nomineeDetails = new NomineeDetails().getInstance(valObj.nomineeDetails);
            this.additionalCoverDetails = new AdditionalCoverageDetails().getInstance(valObj.additionalCoverDetails);
            this.insuredPersonDetails = new InsuredPerson().getInstance(valObj.insuredPersonDetails);
            this.overseasEducationDetails = new OverseasEducationDetails().getInstance(valObj.overseasEducationDetails);
            this.GSTDetails = new GSTDetails().getInstance(valObj.GSTDetails);
            this.riskClassificationReasons = new ReferredReason().getInstance(valObj.riskClassificationReasons);
            this.referralReasons = new ReferralReasons().getInstance(valObj.referralReasons);//GA001
            if (valObj.isGSTApplicable != undefined && JSON.stringify(valObj.isGSTApplicable) != JSON.stringify("") && typeof (valObj.isGSTApplicable) == "string") {
                this.isGSTApplicable = Boolean(JSON.parse(valObj.isGSTApplicable));
            }
        }
        return this;
    }

    public getNewInstanceByCriteria(criteria: any) {
        let riskType = criteria.riskType;
        // this.identity = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.insuredName;
        if (riskType == "OSI" || riskType == "OSS") {
            this.occupationCode = "7STU";
            this.ratingClass = "01";
            this.RIRetentionCode = "PA01";
            this.currencyRate = 1.00;
            this.staffNo = "";
            this.situation = "";
            this.SICurrency = "RM";
            this.ratingFlag = "A";
            this.GST = 0;
            this.isPOIConsidered = "Y";
            this.SST = 0; //SST Code
        }
        else if (riskType == "PAX") {
            // this.occupationCode="7STU";
            // this.ratingClass="01";
            this.RIRetentionCode = "PA01";
            this.currencyRate = 1.00;
            this.staffNo = "";
            this.situation = "";
            this.SICurrency = "RM";
            this.ratingFlag = "A";
        }
        return this;
    }

    public getValidator() {
        return new NPAValidator(this);
    }
}

export class PANPAItems {
    public paNPAItem: PANPAItem[] = [];
    public getInstance(valObj: PANPAItems) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().handleArray(this, valObj, "paNPAItem");
        }
        return this;
    }
}

export class PANPAItem {
    public coverageCode: string;
    public coverageDescription: string;
    public benefits: string;
    public extraText: string;
    public newSI: string;
    public rate: string;
    public load: string;
    public premium: string;
}


export class AdditionalCoverageDetails {

    public additionalCover: AdditionalCoverage[] = [];
    public additionalCoverTotal: number = 0;

    public getInstance(valObj: AdditionalCoverageDetails) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
            new AppUtil().handleArray(this, valObj, "additionalCover");
        }
        return this;
    }
}

export class AdditionalCoverage {

    public additionalCode: string;
    public additionalCover: string;
    public sumInsured: string;
    public rate: string;
    public additionalLoading: string;
    public addditionalPremium: string;
    constructor() { }
}

export class InsuredPerson {
    public insuredPersonType: InsuredPersonType;
    constructor() {
        this.insuredPersonType = new InsuredPersonType();
    }

    public getInstance(valObj: InsuredPerson) {
        if (new AppUtil().isValidObj(valObj) == true) {
            this.insuredPersonType = new InsuredPersonType().getInstance(valObj.insuredPersonType);
        }
        return this;
    }
}

export class InsuredPersonType {
    public name: string;
    public nric: string;
    public ICPassport: string;
    public DOB: string;
    public gender: string;
    public address: string;
    public occupationCode: string;
    public occupationDescription: string;
    public terminationDate: string;
    public insuredAge: number;// Divek-0555
    public age: number = 0;//GA001

    constructor() { }

    public getInstance(valObj: InsuredPersonType) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
        }
        return this;
    }
}

export class OverseasEducationDetails {
    public addOffOverseasResidence: string;
    public addressOfEducInstitute: string;
    public countryCode: string;
    public countryOfStudy: string;
    public terminationDate: string;
    public actualCommencementDate: string;
    // public nameOfEducInstitute:string;

    constructor() { }
    public getInstance(valObj: OverseasEducationDetails) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
        }
        return this;
    }
}