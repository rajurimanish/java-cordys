/*
Change History	:

	No      Date          Description                                 Changed By
	====    ==========    ===========                                 ==========
	MD001   14/03/2018   MYS-2018-0130 - Occupation Code to be Read 
	                    from T9109 - for All Personal Lines Products         MKU1	
	GA001   09/07/2018   MYS-2018-0443 - Age Checking for 
                         PA Products (T7253)  						   	     KGA
 *  KA0001  12/6/2018    MYS-2018-0555- To aupopulate DOB,age & gender       Divek
 *  MO001	09/10/2018   MYS-2018-0904: HD Log: Incorrect Occupation 
 *                       Description populates for PA and Motor products     RMO
 *                       in BMS 
 * YPK001 23/09/2019     MYS-2019-0675 Document Validation for Co-outwards    PKU1
 *                       case before sending to PPHO		
 * 
 */
import { CustomDCLService } from '../../../../../common/services/customdcl.service';
import { Component, OnInit, ViewChild, AfterViewInit, EventEmitter, ElementRef, ViewContainerRef } from '@angular/core';
import { ClausesComponent } from "../uimodules/clauses.component";
import { IndividualPersonalAccident, AdditionalCoverageDetails, AdditionalCoverage, InsuredPersonType, PANPAItems } from "./appobjects/pa";
import { LOV_Field, LOVDropDownService, SearchFilter } from "../../../../../common/services/lovdropdown/lovdropdown.service";
import { SearchInput } from "../../../../../common/components/utility/search/genericsearch";
import { NomineeDetails } from "../appobjects/nomineeslist";
import { ClientDetails } from '../../../../../common/components/client/appobjects/client';
import { GetLOVData, SearchAdvancedConfig, Filter } from '../../../../../common/components/utility/search/search.requests';
import { CordysSoapWService } from "../../../../../common/components/utility/cordys-soap-ws";
import { Clause } from "../appobjects/clause";
import { ProposalHeader } from '../../proposalheader/appobjects/proposalheader';
import { AlertMessagesService } from '../../../../../common/components/utility/alertmessage/alertmessages.service';
import { AlertMessage } from '../../../../../common/components/utility/alertmessage/alertmessages.model';
import { ModalInput } from "../../../../../common/components/utility/modal/modal";
import { ApplicationUtilService } from "../../../../../common/services/application.util.service";
import { BMSUtilService } from "../../../../services/bms.util.service";
import { RiskClassificationService } from '../services/riskcls.service';
import { BMSConstants } from '../../../../components/common/constants/bms_constants';
import { BMSType } from '../../../../components/common/constants/bms_types';
import { AppUtil } from '../../../../../common/components/utility/apputil/app.util';
import { RIService } from '../services/ri.service';
import { ReferralReasons, ReferralReason } from '../appobjects/referralReasons';//GA001
import { ReferredReason, Reasons } from '../../proposalheader/appobjects/referredreason';//GA001
import { ActivatedRoute } from '@angular/router';


declare var jQuery: any;
declare var moment: any;
declare var numeral: any;

@Component({
    selector: 'pa-comp',
    templateUrl: 'app/bms/components/proposal/newbusinessrisks/pa/pa.template.html',
    inputs: ['riskObj', 'clientDetails', 'headerInfo'],
    outputs: ["onPremiumChange", 'onRiskClsChange', 'onRtngFlgChange'],
    providers: [RiskClassificationService]
})
export class PersonalAccidentComponent implements OnInit {
    private el: HTMLElement;
    private isInsuranceInfoCollapsed: boolean = false;
    private isCoverInfoCollapsed: boolean = false;
    private isNomineeInfoCollapsed: boolean = false;
    private collapseVehiclelInfo: boolean = false;
    private collapseClausesInfo: boolean = true;
    private showOverseasEduDet: boolean = false;
    private DOBCtrl: any;
    private comncmtDateCtrl: any;
    private OSEDetTermDateCtrl: any;
    public headerInfo: ProposalHeader;

    hideRow: boolean = true;
    isMobile: boolean = /Mobi/.test(navigator.userAgent);

    riskObj: IndividualPersonalAccident;
    public clientDetails: ClientDetails;
    public defaultClauseCode: string = "";
    public disableForm = 'N';
    private disableOSIPAXField = 'N';
    private disableOccCode = 'N';
    private isUnderWriter = "N";
    private isRIMethodEditable = "Y";
    // MO001: To detect the Occuapation Code change.
    private isOccupationCodeChanged: boolean = true;

    onPremiumChange = new EventEmitter<any>();
    onRiskClsChange = new EventEmitter<any>();
    onRtngFlgChange = new EventEmitter<any>();

    private referralReasons = [];//GA001

    @ViewChild(ClausesComponent) private clausesComp: ClausesComponent;
    @ViewChild('paCompModal', { read: ViewContainerRef }) contentArea: ViewContainerRef;
    private isGeneralPageCollapsed: boolean = false;
    constructor(public dcl: CustomDCLService, private lovDropDownService: LOVDropDownService, private _soapService: CordysSoapWService, public _alertMsgService: AlertMessagesService, el: ElementRef, private _appUtilService: ApplicationUtilService, private _bmsUtilService: BMSUtilService, private _rcls: RiskClassificationService, private _riService: RIService, private _activatedRoute: ActivatedRoute) {
        this.el = el.nativeElement
    }
    ngAfterViewInit() {
        //this.setRiskClassification(this);
        this.setFormDisabled();
        if (this.disableForm == 'Y' || this.riskObj.riskType == 'OSI' || this.riskObj.riskType == 'OSS') {
            this.disableOccCode = 'Y';
        }
        if (this.riskObj.riskType == 'OSI' || this.riskObj.riskType == 'OSS' || this.riskObj.riskType == 'PAX') {
            this.disableOSIPAXField = 'Y';
        }

        if (!this.riskObj.identity) {
            this.riskObj.identity = this.headerInfo.insuredName;
        }
        //START YPK001
        let rIndex = 0;
        if ((this.headerInfo.CoInsurance == 'Y' && this.riskObj.riskNumber == '1') && (["MyTasks", "MyDrafts"].indexOf(this._activatedRoute.snapshot.params['component']) >= 0 || Object.keys(this._activatedRoute.snapshot.params).length == 0)) {
            if (this.headerInfo.coInsuranceDetails.coInsurance.length == 1) {
                if (!(this.headerInfo.coInsuranceDetails.coInsurance[0].coInsuranceindicator == 'L' && this.headerInfo.coInsuranceDetails.coInsurance[0].sharePercentage == '100')) {
                    rIndex = this.riskObj.clauses.clause.map(function (item) { return item.clauseCode; }).indexOf("COIN");
                    if (rIndex == -1)
                        this.setClauses(["COIN"], false);
                }
            }
            else {
                rIndex = this.riskObj.clauses.clause.map(function (item) { return item.clauseCode; }).indexOf("COIN");
                if (rIndex == -1)
                    this.setClauses(["COIN"], false);
            }
        }
    }
    //END YPK001

    setFormDisabled() {
        if (jQuery("#bmsForm").prop("disabled") == true) {
            this.disableForm = "Y";
        }
    }
    ngOnInit() {
        this.populateLOVs();
        this.setClientInfo(false);
        //this.initializeChildComp();

        if (this.riskObj.insuredPersonDetails.insuredPersonType.DOB && this.riskObj.insuredPersonDetails.insuredPersonType.DOB != "Invalid date")
            this.validateAge(this.riskObj.insuredPersonDetails.insuredPersonType.DOB);

        this._appUtilService.isUnderWriterUser().subscribe((data) => {
            this.isUnderWriter = data;
            this.setRIMethodEditableFlag();
        });

        //SST code
        //if(this.riskObj.GST == 0 || this.riskObj.SST == 0) {
        if (["MyTasks", "MyDrafts"].indexOf(this._activatedRoute.snapshot.params['component']) >= 0 || Object.keys(this._activatedRoute.snapshot.params).length == 0) {
            let respObj = this._bmsUtilService.getTAXDetails();
            if (respObj != undefined && respObj != "") {
                if (BMSConstants.getBMSType() == BMSType.Renewal && this.headerInfo.contractType == 'OSI')
                    this.headerInfo.SSTTaxRate = 0; //SST rate to be zero rated for OSI renewal MKU1/MD00
                else
                    this.headerInfo.SSTTaxRate = Number(respObj[0].old.ITEMPF.GST);
                this.headerInfo.GSTTaxRate = Number(respObj[1].old.ITEMPF.GST);

                this.riskObj.SST = Number(this.headerInfo.SSTTaxRate);
                this.riskObj.GST = Number(this.headerInfo.GSTTaxRate);
            }

            this.headerInfo = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo;
            this.riskObj.SSTLiveDate = (this.riskObj.SSTLiveDate == undefined) ? this.headerInfo.SSTLiveDate : this.riskObj.SSTLiveDate;
            if (this.riskObj.SSTLiveDate == undefined || this.riskObj.SSTLiveDate == "") {
                let tempRespObj = this._bmsUtilService.getLiveDate();
                this.riskObj.GSTLiveDate = tempRespObj[0].old.ITEMPF.LIVEDATE;
                this.riskObj.SSTLiveDate = tempRespObj[1].old.ITEMPF.LIVEDATE;
                if (this.headerInfo.SSTLiveDate == undefined || this.headerInfo.SSTLiveDate == "") {
                    this.headerInfo.SSTLiveDate = this.riskObj.SSTLiveDate;
                }
                if (this.headerInfo.GSTLiveDate == undefined || this.headerInfo.GSTLiveDate == "") {
                    this.headerInfo.GSTLiveDate = this.riskObj.GSTLiveDate;
                }
            }
            if (moment(this.headerInfo.effectiveDate, "YYYY-MM-DD").format("YYYYMMDD") >= moment(this.riskObj.SSTLiveDate, "YYYY-MM-DD").format("YYYYMMDD")) {
                this.riskObj.isGSTApplicable = false;
            } else {
                this.riskObj.isGSTApplicable = true;
            }
        }
        //End
    }
    /***Changed by Rajesh on 20-OCT-2016 for bug fix REDMINE-468****/
    private InsuredPersonChange(e) {
        if (e.target.value)
            this.riskObj.identity = e.target.value.slice(0, 15);
    }

    /** Change ends here***/
    initializeChildComp() {
        if (!this.riskObj.nomineeDetails)
            this.riskObj.nomineeDetails = new NomineeDetails();

        if (this.riskObj.additionalCoverDetails.additionalCover == null)
            this.riskObj.additionalCoverDetails.additionalCover = [];
        else if (!Array.prototype.isPrototypeOf(this.riskObj.additionalCoverDetails.additionalCover)) {
            let temp: any = this.riskObj.additionalCoverDetails.additionalCover;
            this.riskObj.additionalCoverDetails.additionalCover = [temp];
        }

        if (this.riskObj.clauses != null && this.riskObj.clauses.clause != null && !Array.prototype.isPrototypeOf(this.riskObj.clauses.clause)) {
            let temp: any = this.riskObj.clauses.clause;
            this.riskObj.clauses.clause = [temp];
        }
        else if (this.riskObj.clauses == null || this.riskObj.clauses.clause == null) {
            this.riskObj.clauses = new Clause();
        }

        if (this.riskObj.paNPAItems.paNPAItem == null)
            this.riskObj.paNPAItems = new PANPAItems();
        else if (!Array.prototype.isPrototypeOf(this.riskObj.paNPAItems.paNPAItem)) {
            let temp: any = this.riskObj.paNPAItems.paNPAItem;
            this.riskObj.paNPAItems.paNPAItem = [temp];
        }
    }

    changeRiskClassification(event) {
        this.riskObj.riskClassification = event.target.value;
        this._rcls.setRiskClassification(this.riskObj.riskNumber, "N", "", "").subscribe();
        this.onRiskClsChange.emit('');//GA001 
    }

    setRIMethod(value) {
        this.riskObj.RIMethod = (value == "Yes") ? "8" : "1";

        if (this.isUnderWriter == "Y" || value == "Yes")
            this.riskObj.isRIOverWrittenByUW = "Y";
        else if (value == "No") {
            this.riskObj.isRIOverWrittenByUW = "N";
            this.validateSumInsured();
        }
        this._riService.setRI().subscribe();
    }

    setRiskClassification(comp) {
        comp._rcls.setRiskClassification(comp.riskObj.riskNumber, "N", "", "").subscribe((support) => {
            if (support == "NS") {
                if (comp.riskObj.symRiskClassification != null && comp.riskObj.symRiskClassification != "" && (comp.riskObj.symRiskClassification == "Referred" || comp.riskObj.symRiskClassification == "Declined")) {
                    let statusTxt = (comp.riskObj.symRiskClassification != null && comp.riskObj.symRiskClassification != "") ? comp.riskObj.symRiskClassification : comp.riskObj.riskClassification;
                    comp.riskObj.riskClassificationReason = "System marked as " + statusTxt;
                }
                else {
                    if (comp.riskObj.riskClassificationReason != null && comp.riskObj.riskClassificationReason != "" && (comp.riskObj.riskClassificationReason != "System marked as Standard"
                        && comp.riskObj.riskClassificationReason.indexOf("System marked as ") != -1)) {
                        comp.riskObj.riskClassificationReason = "";
                    }
                }
                comp.onRiskClsChange.emit('');
            }

            if (comp.riskObj.symRiskClassification == null || comp.riskObj.symRiskClassification == '' || comp.riskObj.symRiskClassification == 'Standard') {
                comp.riskObj.riskClassificationReason = "";
            }
        });
    }

    setOccDesc(occupation) {

        //Insured occupation details
        this.riskObj.insuredPersonDetails.insuredPersonType.occupationCode = "";
        this.riskObj.insuredPersonDetails.insuredPersonType.occupationDescription = "";
        if (AppUtil.isEmpty(this.riskObj.occupationCode, false) == false) {
            this.riskObj.insuredPersonDetails.insuredPersonType.occupationCode = this.riskObj.occupationCode;
            let _currentOccRecords = this.lovDropDownService.lovDataList.Occupation.filter((_item) => _item.VALUE === this.riskObj.occupationCode);
            if (_currentOccRecords && _currentOccRecords.length > 0 && _currentOccRecords[0].DESCRIPTION) {
                this.riskObj.insuredPersonDetails.insuredPersonType.occupationDescription = _currentOccRecords[0].DESCRIPTION.slice(0, 40);
            }

            let request: GetLOVData = new GetLOVData();
            request.BRANCH = 'ALL';
            let occFieldValue = this.riskObj.occupationCode;
            if (this.headerInfo.lineOfBusiness == 'PA') {//MD001
                request.LOB = 'PA';
                occFieldValue = (this.riskObj.riskType.length == 2) ? this.riskObj.riskType + ' ' : this.riskObj.riskType + "" + this.riskObj.occupationCode;
            }
            else
                request.LOB = 'ALL';
            request.BUSINESS_FUNCTION = 'NEW BUSINESS';
            request.PRODUCT = 'ALL';
            request.OPERATION = 'NEW';
            request.FORM_NAME = 'ALL';
            request.FORM_FIELD_NAME = 'Occupation';
            request.FIELD_TYPE = 'LOV';
            request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
            request.ADVANCE_CONFIG_XML.FILTERS = new Filter();

            request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({ "@FIELD_NAME": 'DESCITEM', "@FIELD_VALUE": occFieldValue, '@OPERATION': 'EQ', '@CONDITION': 'AND' });
            this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.occupationSuccessHandler, this.handleError, true, { comp: this });
        }
        else
            this.riskObj.occupationDescription = "";
    }

    occupationSuccessHandler(response, prms) {
        let referedRisk: string = "";
        if (response.tuple) {
            referedRisk = prms.comp.headerInfo.lineOfBusiness == 'PA' ? response.tuple.old.T9109.REFERREDRISK : response.tuple.old.T3644.REFERREDRISK;
            // MO001 - Setting the occupation description value only when the Occupation Code is changed from UI 
            // or Occupation Description is empty and Occupation code is not empty.
            if (prms.comp.isOccupationCodeChanged == true || prms.comp.riskObj.occupationDescription == undefined
                || prms.comp.riskObj.occupationDescription == null || prms.comp.riskObj.occupationDescription == "") {
                prms.comp.riskObj.occupationDescription = prms.comp.headerInfo.lineOfBusiness == 'PA' ? response.tuple.old.T9109.DESCRIPTION : response.tuple.old.T3644.DESCRIPTION;
            }
			/* if(prms.comp.headerInfo.lineOfBusiness == 'PA')//MD001
			{
         		prms.comp.riskObj.occupationDescription = response.tuple.old.T9109.DESCRIPTION;
		 		referedRisk = response.tuple.old.T9109.REFERREDRISK;
			}
			else{
         		prms.comp.riskObj.occupationDescription = response.tuple.old.T3644.DESCRIPTION;
		 		referedRisk = response.tuple.old.T3644.REFERREDRISK;
	    	}*/
        }
        else {
            prms.comp.riskObj.occupationDescription = "";//  MD001
            prms.comp.riskObj.occupationCode = "";
        }
        // MO001: Reverting the values 	
        prms.comp.isOccupationCodeChanged = true;
        prms.comp._rcls.isRCLReasonSupported().subscribe((isSupported) => {
            if (isSupported == "Y") {
                prms.comp.riskObj.occRiskClassification = referedRisk;
                prms.comp.setRiskClassification(prms.comp);
            }
            else {
                prms.comp.riskObj.occRiskClassification = "";
                if (referedRisk == '' || referedRisk == 'N') {
                    prms.comp.riskObj.symRiskClassification = "Standard";
                }
                else if (referedRisk == 'Y') {
                    prms.comp.riskObj.symRiskClassification = "Referred";
                    prms.comp.headerInfo.isReferredRisk = "true";
                    prms.comp.headerInfo.isReferredRiskUI = true;
                }
                else if (referedRisk == 'D') {
                    prms.comp.riskObj.symRiskClassification = "Declined";
                }
                prms.comp.riskObj.riskClassification = prms.comp.riskObj.symRiskClassification;
                prms.comp.riskObj.occRiskClassification = prms.comp.riskObj.symRiskClassification;
                prms.comp.checkReferredRisk(prms.comp);
            }
        });
    }

    checkReferredRisk(comp) {
        if ((comp.riskObj.occRiskClassification != null && comp.riskObj.occRiskClassification == "Referred") || (comp.headerInfo.insuredAge && isNaN(comp.headerInfo.insuredAge) == false && !(comp.headerInfo.insuredAge > 15 && comp.headerInfo.insuredAge < 71))) {
            comp.riskObj.symRiskClassification = "Referred";
            comp.riskObj.riskClassification = comp.riskObj.symRiskClassification;
        }
        else {
            if (comp.riskObj.occRiskClassification != null && comp.riskObj.occRiskClassification != "") {
                comp.riskObj.symRiskClassification = comp.riskObj.occRiskClassification;
                comp.riskObj.riskClassification = comp.riskObj.symRiskClassification;
            }
            else {
                comp.riskObj.symRiskClassification = "Standard";
                comp.riskObj.riskClassification = comp.riskObj.symRiskClassification;
            }
        }
        comp.setRiskClassification(comp);
    }

    handleError(response, status, errorText, prms) {
        prms.comp.isOccupationCodeChanged = true;
        prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, response.responseJSON.faultstring.text, -1));
    }

    calculateDefaultClauseCode(value) {
        this.defaultClauseCode = value;
        if (this.clausesComp)
            this.clausesComp.setDefaultClause(this.defaultClauseCode);
    }

    openAdditionalCoverageDetailsDialog() {
        let searchInput = new SearchInput();
        searchInput.isSingleSelect = false;
        searchInput.BRANCH = 'ALL';
        searchInput.BUSINESS_FUNCTION = 'NEW BUSINESS';
        searchInput.FIELD_TYPE = 'LOOKUP';
        searchInput.FORM_FIELD_NAME = 'Additional Coverage';
        searchInput.FORM_NAME = 'ALL';
        searchInput.LOB = 'ALL';
        searchInput.OPERATION = 'NEW';
        searchInput.PRODUCT = 'ALL';

        if (this.riskObj.additionalCoverDetails.additionalCover.length > 0) {
            let newArr = [];
            for (let item of this.riskObj.additionalCoverDetails.additionalCover) {
                newArr = newArr.concat(item["additionalCode"]);
            }
            let additionalCoverCodes = "'" + newArr.toString().replace(/,/g, "\',\'") + "'";
            searchInput.condition = { "A.DESCITEM": additionalCoverCodes };
        }
        else
            searchInput.condition = { "A.DESCITEM": "''" };

        let input = new ModalInput().get("GenericSearchComponent");
        input.datainput = searchInput;
        input.outputCallback = this.addAdditionalCoverage;
        input.containerRef = this.contentArea;
        input.parentCompPRMS = { comp: this };
        input.heading = "Additional Cover Details";
        input.icon = "fa fa-file-pdf-o";
        this.dcl.openLookup(input);
    }

    addAdditionalCoverage(listOfAdditionalCoverage, prms) {
        for (let eachCover of listOfAdditionalCoverage) {
            let adcover = new AdditionalCoverage();
            adcover.additionalCode = eachCover.old.DESCPF.VALUE;
            adcover.additionalCover = eachCover.old.DESCPF.LONGDESC;
            prms.comp.riskObj.additionalCoverDetails.additionalCover.push(adcover);
            prms.comp.setClauses([eachCover.old.DESCPF.VALUE], false);
        }
    }

    private populateLOVs(): void {

        this.lovDropDownService.createLOVDataList(["riCode", "Occupation", "Rating Class", "Plan", "make", "Sex", "Country", "referralReasons", "referralAgeLimits"]);//GA001 - ADDED (referralReasons,referralAgeLimits)
        let riTypeFilterDetails = [new SearchFilter("DESCITEM", "PA", "STARTSWITH", "AND")];
        let riTypeSearchFilterNodes = this.lovDropDownService.createFilter(riTypeFilterDetails);

        /**MD001  PA Occupation for PA Products*/
        let occLob: string;
        let paoccupationFilterNodes: any[];


        if (this.headerInfo.lineOfBusiness == 'PA') {
            occLob = "PA";
            let occCodeFilter = (this.riskObj.riskType.length == 2) ? this.riskObj.riskType + ' ' : this.riskObj.riskType;
            let paoccupationfilter = [new SearchFilter("DESCITEM", occCodeFilter, "STARTSWITH", "AND")];
            paoccupationFilterNodes = this.lovDropDownService.createFilter(paoccupationfilter);
        }
        else
            occLob = "MOTOR";
        //GA001 START
        let riskFilter = (this.riskObj.riskType.length == 2) ? this.riskObj.riskType + ' ' : this.riskObj.riskType;
        let referralAgeLimitNodes = this.lovDropDownService.createFilter([new SearchFilter("DESCITEM", riskFilter, "EQ", "AND")]);
        //GA001 END
        /** Ends here */
        let lovFields = [
            new LOV_Field("ALL", "PERSONAL ACCIDENT", "NEW BUSINESS", "ALL", "NEW", "PERSONAL ACCIDENT", "RIRetentionCode", "LOV", riTypeSearchFilterNodes, "DESCPF", "riCode", null),
            new LOV_Field("ALL", occLob, "NEW BUSINESS", "ALL", "NEW", "NAMED_DRIVER", "Occupation", "LOV", paoccupationFilterNodes, "DESCPF", "Occupation", "calbackOccupationCodesLoad"),
            new LOV_Field("ALL", "PERSONAL ACCIDENT", "NEW BUSINESS", "ALL", "NEW", "PERSONAL ACCIDENT", "RatingClass", "LOV", [], "DESCPF", "RatingClass", null),
            new LOV_Field("ALL", "PERSONAL ACCIDENT", "NEW BUSINESS", "ALL", "NEW", "PERSONAL ACCIDENT", "Plan", "LOV", [], "DESCPF", "Plan", null),
            new LOV_Field("ALL", "MOTOR", "NEW BUSINESS", "ALL", "NEW", "NAMED_DRIVER", "Sex", "LOV", [], "DESCPF", "Sex", null),
            new LOV_Field("ALL", "CLIENT", "ALL", "ALL", "NEW", "CLIENT_DETAILS", "Country", "LOV", [], "DESCPF", "Country", null),
            new LOV_Field("ALL", "MED", "ALL", "ALL", "ALL", "ALL", "Referral Reasons", "LOV", [], "DESCPF", "referralReasons", "callbackForReferralReasons"),
            new LOV_Field("ALL", "MED", "ALL", "ALL", "ALL", "ALL", "Referral Age Limits", "LOV", referralAgeLimitNodes, "T7253", "referralAgeLimits", "callbackReferralAgeLimits")
        ];//GA001 ADDED (referralReasons,referralAgeLimits)

        this.lovDropDownService.util_populateLOV(lovFields, this);

    }

    calbackOccupationCodesLoad(scopeObject) {
        if (scopeObject.riskObj.occupationCode && !scopeObject.riskObj.occupationDescription) {
            for (let occ of scopeObject.lovDropDownService.lovDataList.Occupation) {
                if (occ.VALUE == scopeObject.riskObj.occupationCode) {
                    scopeObject.riskObj.occupationDescription = occ.DESCRIPTION;
                    break;
                }
            }
        }
        scopeObject.riskObj.insuredPersonDetails.insuredPersonType.occupationCode = scopeObject.riskObj.occupationCode;
        scopeObject.riskObj.insuredPersonDetails.insuredPersonType.occupationDescription = (scopeObject.riskObj.occupationDescription) ? scopeObject.riskObj.occupationDescription.slice(0, 40) : "";

    }

    setClauses(clausesList, flag) {
        if (this.clausesComp)
            this.clausesComp.addClause(clausesList, '', flag);
    }

    removeAdditionalCover(idx: number) {
        let addnlCover = this.riskObj.additionalCoverDetails.additionalCover[idx];
        this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Deleted Benefit Successfully : " + addnlCover.additionalCode, 5000));
        this.riskObj.additionalCoverDetails.additionalCover.splice(idx, 1);
        this.deleteClause(this.riskObj.clauses.clause, addnlCover.additionalCode, "clauseCode");
    }

    deleteClause(ary, clauseCode, prop) {
        let val = undefined;
        if (ary.length > 0) {
            for (var index = 0, assoLength = ary.length; index < assoLength; index++) {
                if (ary[index][prop] != null && ary[index][prop] != "" && ary[index][prop] == clauseCode) {
                    val = index;
                    break;
                }
            }
        }
        if (val != undefined)
            this.clausesComp.removeClause(val, clauseCode);
    }

    setClientInfo(forceChange) {
        let insuredPersonType = this.riskObj.insuredPersonDetails.insuredPersonType;
        if ((forceChange == true || forceChange == false && (insuredPersonType.name == null || insuredPersonType.name == "") && (insuredPersonType.nric == null || insuredPersonType.nric == "")) && this.clientDetails.client.genericDetails.clienttype == "P" && this.clientDetails.client.personalClientDetails != null) {
            insuredPersonType.name = this.clientDetails.client.personalClientDetails.Name;
            insuredPersonType.nric = this.clientDetails.client.personalClientDetails.NRICNo;
            insuredPersonType.ICPassport = this.clientDetails.client.personalClientDetails.IdNumber;
            // insuredPersonType.DOB = this.clientDetails.client.personalClientDetails.dateOfBirth;
            let clientDOB = ApplicationUtilService.getFormattedDate(this.clientDetails.client.personalClientDetails.dateOfBirth, "YYYY-MM-DD", "YYYYMMDD");
            insuredPersonType.DOB = (clientDOB) ? clientDOB : '';
            insuredPersonType.address = this.clientDetails.client.personalClientDetails.address.address1;
            insuredPersonType.occupationCode = this.clientDetails.client.personalClientDetails.occupationCode;
            insuredPersonType.occupationDescription = this.clientDetails.client.personalClientDetails.occupationDescription;
            insuredPersonType.gender = this.clientDetails.client.personalClientDetails.gender;
            insuredPersonType.terminationDate = this.clientDetails.client.personalClientDetails.terminationDate;

            if (this.riskObj.riskType != "OSI" && this.riskObj.riskType != "OSS" && this.riskObj.riskType != "PAX") {
                // MO001: Override the Occupation code and Description when the fields are empty.
                if (!this.validateEmpty(this.riskObj.occupationCode)) {
                    this.riskObj.occupationCode = this.clientDetails.client.personalClientDetails.occupationCode;
                    this.riskObj.occupationDescription = this.clientDetails.client.personalClientDetails.occupationDescription;
                } else {
                    this.isOccupationCodeChanged = false;
                }
                if (this.validateEmpty(this.riskObj.occupationCode))
                    this.setOccDesc(this.riskObj.occupationCode);
            }
        }
    }

    validateEmpty(field) {
        if (field != undefined && field != "")
            return true;
        else
            return false;
    }

    onChangeNRIC(event) {
        let eVal = event.target.value;
		/*if(value != "") {
			if(!this.validateNRICFormat(value)){
				// this.riskObj.insuredPersonDetails.insuredPersonType.nric = "";
				this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Enter valid NRIC number in format XXXXXX-XX-XXXX" , 3000));
			}*/
        // Divek commented this code
        /*  let count = this.riskObj.insuredPersonDetails.insuredPersonType.nric.split("-").length - 1;
          if(this.riskObj.insuredPersonDetails.insuredPersonType.nric.length > 0 && this.riskObj.insuredPersonDetails.insuredPersonType.nric.length != 14 && count != 2)
              this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Please fill Valid format for field NRIC. Please enter NRIC in format xxxxxx-xx-xxxx.",-1));*/
        if (eVal != null && eVal != "") {
            let isValidFormat = new RegExp("[0-9]{6}-[0-9]{2}-[0-9]{4}$").test(eVal);
            if (isValidFormat == false) {
                this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Invalid NRIC format. Correct format is YYMMDD-XX-XXXX.", 5000));
                this.riskObj.insuredPersonDetails.insuredPersonType.nric = "";
            }

            else {
                let date = eVal.substring(0, 6);
                let century = eVal.substring(0, 2)
                if (Number(century) > 29)
                    date = '19' + date;
                else
                    date = '20' + date;
                let dob = moment(date, "YYYYMMDD");
                let curDate = moment(new Date().toISOString(), "YYYYMMDD");
                if (curDate.diff(dob, 'days') < 0)
                    date = '19' + date.substring(2, 6);
                if (this.DOBCtrl != null) {
                    this.DOBCtrl.setter(moment(date, "YYYYMMDD").format("YYYY-MM-DD"), "YYYY-MM-DD", this.DOBCtrl.comp);
                    this.validateAge(date);
                    this.setInsuredAge();
                }
            }
            // Divek -0555 changes Start
            let gender = eVal.substr(13, 13);
            if ((gender % 2) == 0) {

                this.riskObj.insuredPersonDetails.insuredPersonType.gender = "F"
            }
            else {
                this.riskObj.insuredPersonDetails.insuredPersonType.gender = "M"
            }

            // Divek -0555 changes END
        }
    }

    validateDOB() {
        if (this.riskObj.insuredPersonDetails.insuredPersonType.nric != undefined && this.riskObj.insuredPersonDetails.insuredPersonType.nric != "") {
            let date = this.riskObj.insuredPersonDetails.insuredPersonType.nric.substring(0, 6);
            let century = this.riskObj.insuredPersonDetails.insuredPersonType.nric.substring(0, 2)
            if (Number(century) > 29)
                date = '19' + date;
            else
                date = '20' + date;
            let dob = moment(date, "YYYYMMDD");
            let curDate = moment(new Date().toISOString(), "YYYYMMDD");
            if (curDate.diff(dob, 'days') < 0)
                date = '19' + date.substring(2, 6);
            if (date != moment(this.riskObj.insuredPersonDetails.insuredPersonType.DOB, "YYYY-MM-DD").format("YYYYMMDD")) {
                if (this.DOBCtrl != null) {
                    this.DOBCtrl.setter(moment(date, "YYYYMMDD").format("YYYY-MM-DD"), "YYYY-MM-DD", this.DOBCtrl.comp);
                    this.validateAge(date);
                }
            }
        }
        else if (this.riskObj.insuredPersonDetails.insuredPersonType.DOB) {
            this.validateAge(this.riskObj.insuredPersonDetails.insuredPersonType.DOB);
        }

        let flag = this.checkRefferedRisksConditions();//GA001
        if ("L" == flag) {
            return;
        }
    }

    validateAge(date) {
        if (date == '99999999' || date == '')
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Insured Age is invalid.", 5000));
        else {
            // let curDate = moment(new Date().toISOString(), "YYYY-MM-DD");
            var _effectiveDate = moment(this.headerInfo.effectiveDate, "YYYY-MM-DD");
            date = moment(date, "YYYYMMDD").format("YYYY-MM-DD");
            // let insuredAge = curDate.diff(date, 'year');

            let diffDuration = moment.duration(_effectiveDate.diff(date));
            let _years = diffDuration.years();
            let _months = diffDuration.months();
            let _days = diffDuration.days();

			/* if((this.riskObj.riskType=='OSI' || this.riskObj.riskType=='OSS') && !(_years > 15 && (_years < 55 || (_years == 55 && _months==0 && _days==0) ) ) ){
				this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Insured Age is not between 16 and 55 limit." , 5000));
			}
			else if( this.riskObj.riskType!='OSI' && this.riskObj.riskType!='OSS' && this.riskObj.riskType!='PAX' && !(_years > 15 && (_years < 65 || (_years == 65 && _months ==0 && _days ==0) ) ) ){
				if(BMSConstants.getBMSType()== BMSType.Renewal || BMSConstants.getBMSType()== BMSType.RenewalRerate){
					return;
				}
				this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Insured Age is not between 16 and 65 limit." , 5000));
			}
			else if(this.riskObj.riskType=='PAX' && !(_years > 5 && (_years < 70 || (_years == 70 && _months ==0 && _days ==0) ) ) ){
				this.riskObj.riskClassification="Referred";
				this.riskObj.symRiskClassification="Referred";
				this.setRiskClassification(this);
			} */
        }
    }

    validateNRICFormat(val) {
        if (val.match(/^\d{6}\-\d{2}\-\d{4}/g)) {
            return true;
        }
        return false;
    }

    getTotalByProperty(prop, ary) {
        let total = numeral(0);
        for (let eachItem of ary) {
            if (eachItem[prop] != null && eachItem[prop] != "")
                total = total.add(numeral().unformat(eachItem[prop]));
        }
        total = numeral(total).format('0.00');
        return total;
    }

    setAdditionalPremiumForEach(coverage) {
        let rate = (coverage.additionalLoading == null || coverage.additionalLoading == "") ? 0 : coverage.additionalLoading;
        coverage.addditionalPremium = (numeral().unformat(this.riskObj.basicPremium) * (numeral().unformat(rate) * 0.01));
        coverage.addditionalPremium = numeral(coverage.addditionalPremium).format('0.00');
    }

    resetAdditionalPremiumForEach() {
        for (let adCover of this.riskObj.additionalCoverDetails.additionalCover) {
            this.setAdditionalPremiumForEach(adCover);
        }
        this.getAdditionalPremiumTotal();
        this.setLoadAndPremium();
        this.setTotalPremium();
    }

    getAdditionalPremiumTotal() {
        let total = this.getTotalByProperty("addditionalPremium", this.riskObj.additionalCoverDetails.additionalCover);
        this.riskObj.addditionalPremium = total;
        return total;
    }

    setTotalPremium() {
        this.riskObj.originalTotalPremium = numeral().unformat(this.riskObj.basicPremium) + numeral().unformat(this.riskObj.addditionalPremium);
        this.riskObj.discountedPremium = numeral().unformat(this.riskObj.basicPremium) + numeral().unformat(this.riskObj.addditionalPremium) - numeral().unformat(this.riskObj.rebateAmount);
        if (this.riskObj.riskType == 'OSI' || this.riskObj.riskType == 'OSS') {
            this.riskObj.gstAmount = 0;
            this.riskObj.sstAmount = 0;//SST Code
        } else {
            //this.riskObj.gstAmount = 0; //Number(this.riskObj.discountedPremium / 100 * 6); //SAF MYS-2018-0629
            //SST Code
            let tempGSTAmount = (Number(this.riskObj.GST) > 0) ? numeral(numeral((this.riskObj.discountedPremium * Number(this.riskObj.GST)) / 100).format('0.00')).value() : 0;
            this.riskObj.gstAmount = (tempGSTAmount > 0) ? numeral(numeral(BMSUtilService.calculatePremiumAmount(tempGSTAmount, "G")).format('0.00')).value() : 0;

            let tempSSTAmount = (Number(this.riskObj.SST) > 0) ? numeral(numeral((this.riskObj.discountedPremium * Number(this.riskObj.SST)) / 100).format('0.00')).value() : 0;
            this.riskObj.sstAmount = (tempSSTAmount > 0) ? numeral(numeral(BMSUtilService.calculatePremiumAmount(tempSSTAmount, "S")).format('0.00')).value() : 0;
        }
        //this.riskObj.totalPremium = numeral().unformat(this.riskObj.discountedPremium) + numeral().unformat(this.riskObj.gstAmount);
        this.riskObj.totalPremium = numeral().unformat(this.riskObj.discountedPremium) + numeral().unformat(this.riskObj.gstAmount) + numeral().unformat(this.riskObj.sstAmount);
        this.riskObj.sstAmount = numeral(this.riskObj.sstAmount).format('0.00');
        //End
        this.riskObj.gstAmount = numeral(this.riskObj.gstAmount).format('0.00');
        this.riskObj.totalPremium = numeral(this.riskObj.totalPremium).format('0.00');
        if (this.riskObj.riskType == 'OSI' || this.riskObj.riskType == 'OSS') { //Redmine-2010
            this.riskObj.postedPremium = this.riskObj.totalPremium;
        }
        this.onPremiumChange.emit(this.riskObj.totalPremium);
    }

    setCapitalSI(capSI) {
        this.riskObj.capitalSumInsured = capSI;
        this.riskObj.capitalSumInsured = numeral(this.riskObj.capitalSumInsured).format('0.00');

        this.validateSumInsured();
    }

    validateSumInsured() {
        if (this.riskObj.RIRetentionCode && this.riskObj.isRIOverWrittenByUW == 'N') {

            this._bmsUtilService.getTotalGrossCapacity(this.riskObj.RIRetentionCode).subscribe((data) => this.compareSIWithTotGrossCap(data));
			/*let _totalGrossCapacity = this._bmsUtilService.getNetRetentionAmountDetails(this.riskObj.RIRetentionCode);
			_totalGrossCapacity = (!_totalGrossCapacity) ? 0 : parseFloat(""+_totalGrossCapacity);
			this.riskObj.totalGrossCapacity = _totalGrossCapacity;
			let _capitalSumInsured = parseFloat(""+this.riskObj.capitalSumInsured);
			
			if( _totalGrossCapacity > 0 && _capitalSumInsured > _totalGrossCapacity && (this.riskObj.RIMethod == null || this.riskObj.RIMethod == "" || parseFloat(""+this.riskObj.RIMethod) != 8) ){
				this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Total Sum Insured is greater than Total Gross Capacity: "+_totalGrossCapacity+",  RI is Required." , 10000));
				
				this.riskObj.RIRequired = "Yes";
				this.riskObj.RIMethod = "8";
			} 
			else if(_capitalSumInsured <= _totalGrossCapacity){
				this.riskObj.RIRequired = "No";
				this.riskObj.RIMethod = this.riskObj.RIMethodSys;
			}*/
        }
        else
            this.setRIMethodEditableFlag();
    }

    compareSIWithTotGrossCap(totGrossCap) {

        let _totalGrossCapacity = (!totGrossCap) ? 0 : parseFloat("" + totGrossCap);
        this.riskObj.totalGrossCapacity = _totalGrossCapacity;
        let _capitalSumInsured = parseFloat("" + this.riskObj.capitalSumInsured);

        if (_totalGrossCapacity > 0 && _capitalSumInsured > _totalGrossCapacity && (this.riskObj.RIMethod == null || this.riskObj.RIMethod == "" || parseFloat("" + this.riskObj.RIMethod) != 8)) {
            this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Total Sum Insured is greater than Total Gross Capacity: " + _totalGrossCapacity + ",  RI is Required.", 10000));

            this.riskObj.RIRequired = "Yes";
            this.riskObj.RIMethod = "8";
        }
        else if (_capitalSumInsured <= _totalGrossCapacity) {
            this.riskObj.RIRequired = "No";
            this.riskObj.RIMethod = this.riskObj.RIMethodSys;
        }
        this._riService.setRI().subscribe();
        this.setRIMethodEditableFlag();
    }

    setLoadAndPremium() {
        let rebatePercent = 0;
        if (this.riskObj.rebate != undefined && Number(this.riskObj.rebate) <= 25) {
            rebatePercent = numeral().unformat(this.riskObj.rebate);
            let tempAmount = numeral().unformat(this.riskObj.basicPremium) + numeral().unformat(this.riskObj.addditionalPremium);
            this.riskObj.rebateAmount = Number(tempAmount * (rebatePercent / 100));
            this.riskObj.rebateAmount = numeral(this.riskObj.rebateAmount).format('0.00');
        }
        this.setTotalPremium();
    }

    validateRebatePctg() {
        if (Number(this.riskObj.rebate) > 25) {
            this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Max. Allowed Value for Rebate is 25% only", -1));
            this.riskObj.rebate = 0;
        }
    }

    validateComncmtDate() {
        if (this.comncmtDateCtrl != null) {
            // this.comncmtDateCtrl.setMinDate(moment(this.headerInfo.effectiveDate,"YYYYMMDD").format("YYYY-MM-DD"),"YYYY-MM-DD",this.comncmtDateCtrl.comp);
            // this.comncmtDateCtrl.setMaxDate(moment(this.headerInfo.endDate,"YYYYMMDD").format("YYYY-MM-DD"),"YYYY-MM-DD",this.comncmtDateCtrl.comp);
        }
    }

    validateOSEDetTermDate() {
        if (this.OSEDetTermDateCtrl != null) {
            // this.OSEDetTermDateCtrl.setMinDate(moment(this.headerInfo.effectiveDate,"YYYYMMDD").format("YYYY-MM-DD"),"YYYY-MM-DD",this.OSEDetTermDateCtrl.comp);
            // this.OSEDetTermDateCtrl.setMaxDate(moment(this.headerInfo.endDate,"YYYYMMDD").format("YYYY-MM-DD"),"YYYY-MM-DD",this.OSEDetTermDateCtrl.comp);
        }
    }

    validateTextInput(ev) {
        let eVal = ev.target.value;
        ev.target.value = eVal.replace(/\s\s+/g, ' ');
    }
    // MO001 - Start
    setInsuredPersonOccDesc(ev) {
        this.validateTextInput(ev);
        this.riskObj.insuredPersonDetails.insuredPersonType.occupationDescription = ev.target.value;
    }
    // MO001 - end

    validateActualCommencementDate() {
        if (this.riskObj.overseasEducationDetails.actualCommencementDate != null && this.riskObj.overseasEducationDetails.actualCommencementDate != "") {
            let _actualCommencementDate = moment(this.riskObj.overseasEducationDetails.actualCommencementDate, "YYYY-MM-DD");
            let _effectiveDate = moment(this.headerInfo.effectiveDate, "YYYY-MM-DD");
            let _endDate = moment(this.headerInfo.endDate, "YYYY-MM-DD");

            if (_actualCommencementDate < _effectiveDate || _actualCommencementDate > _endDate) {
                if (this.comncmtDateCtrl != null)
                    this.comncmtDateCtrl.setter('EMPTY', "YYYY-MM-DD", this.comncmtDateCtrl.comp);
                this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Actual Commencement Date should be with in Policy period date range", 3000));
            }
        }
    }

    validateTerminationDate() {
        if (this.riskObj.overseasEducationDetails.terminationDate != null && this.riskObj.overseasEducationDetails.terminationDate != "") {
            let _terminationDate = moment(this.riskObj.overseasEducationDetails.terminationDate, "YYYY-MM-DD");
            let _effectiveDate = moment(this.headerInfo.effectiveDate, "YYYY-MM-DD");
            let _endDate = moment(this.headerInfo.endDate, "YYYY-MM-DD");

            if (_terminationDate < _effectiveDate || _terminationDate > _endDate) {
                if (this.OSEDetTermDateCtrl != null)
                    this.OSEDetTermDateCtrl.setter('EMPTY', "YYYY-MM-DD", this.OSEDetTermDateCtrl.comp);
                this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Termination Date should be with in Policy period date range", 3000));
            }
        }
    }

    setRIMethodEditableFlag() {
        let _capitalSumInsured = parseFloat("" + this.riskObj.capitalSumInsured);
        let _totalGrossCapacity = parseFloat("" + this.riskObj.totalGrossCapacity);
        if (_totalGrossCapacity > 0 && _capitalSumInsured > _totalGrossCapacity && this.isUnderWriter == "N") {
            this.isRIMethodEditable = "N";
        }
        else {
            this.isRIMethodEditable = "Y";
        }
    }

    // added below code for SAF MYS-2017-1108
    emitFlagChange() {
        this.onRtngFlgChange.emit("");
    }

    //GA001 START
    checkRefferedRisksConditions() {
        let caseInfo = BMSConstants.getBMSCaseInfo();
        let _ageLimitRec = this.lovDropDownService.lovDataList.referralAgeLimits.find((_data) => _data.DESCITEM == this.riskObj.riskType);

        this.checkReferredRiskConditions(this.riskObj, this.headerInfo.contractType, _ageLimitRec, this.lovDropDownService.lovDataList.Occupation, this.lovDropDownService.lovDataList.referralReasons, this.referralReasons, caseInfo);

        if (this.riskObj.ageLimitFlag == "G") {
            this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Insured Age is exceeded maximum age.", 6000));
        }
        else if (this.riskObj.ageLimitFlag == "L") {
            this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Insured Age is less than minimum age.", 6000));
            //return this.riskObj.ageLimitFlag;
        }

        this.handleRiskClassification(this);

        return this.riskObj.ageLimitFlag;
    }

    checkReferredRiskConditions(riskObj, contractType, _ageLimitRec, occCodeList, referralReasonList, selectableReasonsList, caseInfo) {
        let _reasons = new Reasons();
        let isReferredRisk = false;
        let isDeclinedRisk: any = "false";

        // if(contractType=='HIG'){
        // isReferredRisk = true;
        // _reasons.reason.push("Referred Product.");
        // }

        if (riskObj.hasClaimExperience == 'Y') {
            isReferredRisk = true;
            _reasons.reason.push("With Claim Experience.");
            this.addReferralReason(riskObj, '11', true, referralReasonList, selectableReasonsList);
        }
        else {
            this.deleteReferralReason(riskObj, '11', true);
        }

        //this.riskObj.insuredPersonDetails.insuredPersonType.insuredAge = this.calculateAge(this.riskObj.insuredPersonDetails.insuredPersonType.DOB);
        this.setInsuredAge();

        riskObj.ageLimitFlag = "";
        if (_ageLimitRec && riskObj.insuredPersonDetails.insuredPersonType.DOB && riskObj.occupationCode) {
            let _minAgeLimit = 0;
            let _maxAgeLimit = 0;
            let _minAgeLimitInd = 'Y';
            let _maxAgeLimitInd = 'Y';

            let _adultMinAgeLimit = (_ageLimitRec.ZAGELMT03) ? parseInt("" + _ageLimitRec.ZAGELMT03) : 0;
            let _adultMaxAgeLimit = 0;
            if ("Renewal" == caseInfo.businessFunction) {
                _adultMaxAgeLimit = (_ageLimitRec.ZAGELMT07) ? parseInt("" + _ageLimitRec.ZAGELMT07) : 0;
            } else {
                _adultMaxAgeLimit = (_ageLimitRec.ZAGELMT05) ? parseInt("" + _ageLimitRec.ZAGELMT05) : 0;
            }

            let _chidldMinAgeLimit = (_ageLimitRec.ZAGELMT04) ? parseInt("" + _ageLimitRec.ZAGELMT04) : 0;
            let _chidldMaxAgeLimit = (_ageLimitRec.ZAGELMT06) ? parseInt("" + _ageLimitRec.ZAGELMT06) : 0;


            //if( _chidldMinAgeLimit > 0 && _chidldMaxAgeLimit > 0 && (riskObj.insuredOccCode == '7STU' || riskObj.insuredOccCode == '7CLD') ){
            if (_chidldMinAgeLimit > 0 && _chidldMaxAgeLimit > 0 && (riskObj.occupationCode == '7STU' || riskObj.occupationCode == '7CLD')) {
                _minAgeLimit = _chidldMinAgeLimit;
                _maxAgeLimit = _chidldMaxAgeLimit;
                _minAgeLimitInd = (_ageLimitRec.ZAGEIND02) ? _ageLimitRec.ZAGEIND02 : "Y";
                _maxAgeLimitInd = (_ageLimitRec.ZAGEIND03) ? _ageLimitRec.ZAGEIND03 : "Y";
            }
            else {

                _minAgeLimit = _adultMinAgeLimit;
                _maxAgeLimit = _adultMaxAgeLimit;
                if (_chidldMinAgeLimit == 0 || _chidldMaxAgeLimit == 0) {
                    _minAgeLimitInd = (_ageLimitRec.ZAGEIND02) ? _ageLimitRec.ZAGEIND02 : "Y";
                    _maxAgeLimitInd = (_ageLimitRec.ZAGEIND03) ? _ageLimitRec.ZAGEIND03 : "Y";
                }
            }

            if (_maxAgeLimitInd == 'D') {
                if (riskObj && riskObj.dateOfAttachment && riskObj.insuredPersonDetails.insuredPersonType.DOB) {
                    let _inclusionDate = moment(riskObj.dateOfAttachment, "YYYY-MM-DD");
                    let _insuredDOB = moment(riskObj.insuredPersonDetails.insuredPersonType.DOB, "YYYY-MM-DD");

                    let _ageInDays = moment.duration(_inclusionDate.diff(_insuredDOB)).asDays();
                    if (_ageInDays > _maxAgeLimit) {
                        riskObj.ageLimitFlag = "G";
                    }
                }
            }
            else if (Number(riskObj.insuredPersonDetails.insuredPersonType.insuredAge) > _maxAgeLimit) {
                riskObj.ageLimitFlag = "G";
            }

            if (riskObj.ageLimitFlag != "G") {
                if (_minAgeLimitInd == 'D') {
                    if (riskObj && riskObj.dateOfAttachment && riskObj.insuredPersonDetails.insuredPersonType.DOB) {
                        let _inclusionDate = moment(riskObj.dateOfAttachment, "YYYY-MM-DD");
                        let _insuredDOB = moment(riskObj.insuredPersonDetails.insuredPersonType.DOB, "YYYY-MM-DD");

                        let _ageInDays = moment.duration(_inclusionDate.diff(_insuredDOB)).asDays();
                        if (_ageInDays < _minAgeLimit) {
                            riskObj.ageLimitFlag = "L";
                        }
                    }
                }
                else if (Number(riskObj.insuredPersonDetails.insuredPersonType.insuredAge) < _minAgeLimit) {
                    riskObj.ageLimitFlag = "L";
                }
            }

            riskObj.ageMin = _minAgeLimit;
            riskObj.ageMax = _maxAgeLimit;

			/*if(Number(riskObj.insuredAge) > _maxAgeLimit) {
				isReferredRisk = true;
				riskObj.ageLimitFlag = "G";
				_reasons.reason.push("Insured Age greater than maximum allowed age "+_maxAgeLimit);
				
				this.addReferralReason(riskObj, '01', true, referralReasonList, selectableReasonsList);
			}
			else if(Number(riskObj.insuredAge) < _minAgeLimit) {
				
				riskObj.ageLimitFlag = "L";
			}
			else {
				riskObj.ageLimitFlag = "VALID";
			}*/

            if (riskObj.ageLimitFlag == "G") {
                isReferredRisk = true;
                _reasons.reason.push("Insured (" + riskObj.riskNumber + ") Age greater than maximum allowed age " + _maxAgeLimit);
                this.addReferralReason(riskObj, '01', true, referralReasonList, selectableReasonsList);
            }
            else if (riskObj.ageLimitFlag == "L") {
                isReferredRisk = true;
                _reasons.reason.push("Insured (" + riskObj.riskNumber + ") Age Less than minimum allowed age " + _minAgeLimit);
                this.addReferralReason(riskObj, '01', true, referralReasonList, selectableReasonsList);
            }
            else if (riskObj.ageLimitFlag == "") {
                riskObj.ageLimitFlag = "VALID";
            }
        }

        //if( riskObj.ageLimitFlag != 'G' ){
        //this.deleteReferralReason(riskObj, '01', true);
        /*let _ageRefReason = riskObj.referralReasons.referralReason.find((_data1)=> _data1.code=='01');
        if(_ageRefReason && _ageRefReason.isSysReferred == 'Y'){
            _ageRefReason.isSysReferred = 'N';
        }*/
        //}

		/* if(riskObj.occupationCode){
			let _rec = occCodeList.find((_data)=> _data.VALUE == riskObj.occupationCode);
						
			if(_rec && _rec.REFERREDRISK && _rec.REFERREDRISK=='Y'){
				isReferredRisk = true;
				riskObj.occRiskClassification="Referred";
				_reasons.reason.push("Occupation code of type Referred selected");
				this.addReferralReason(riskObj, '05', true, referralReasonList, selectableReasonsList);
			}
			else if(_rec && _rec.REFERREDRISK && _rec.REFERREDRISK=='D'){
				isDeclinedRisk = true;
				riskObj.occRiskClassification="Declined";
				_reasons.reason.push("Declined : Occupation code of type Declined selected");
			}
			else {
				riskObj.occRiskClassification="Standard";
			}
			
			if(riskObj.occRiskClassification != 'Referred'){
				this.deleteReferralReason(riskObj, '05', true);
				/*let _occRefReason = riskObj.referralReasons.referralReason.find((_data1)=> _data1.code=='05');
				if(_occRefReason && _occRefReason.isSysReferred == 'Y'){
					_occRefReason.isSysReferred = 'N';
				}
			}			
		} */

        if (riskObj.referralReasons.referralReason && riskObj.referralReasons.referralReason.length > 0 && riskObj.referralReasons.referralReason.find((_data1) => _data1.isSysReferred != 'Y')) {
            isReferredRisk = true;
            _reasons.reason.push("Referral Reason added");
        }

        riskObj.riskClassificationReasons.reasons = _reasons;

        if (isDeclinedRisk == "true") {
            riskObj.symRiskClassification = "Declined";
        }
        else if (isReferredRisk == true) {
            riskObj.symRiskClassification = "Referred";
        }
        else riskObj.symRiskClassification = "Standard";

        // this.handleRiskClassification();
    }

    addReferralReason(riskObj, refCode, isSysRef, refrlReasonsList, selectableReflReasonsList) {

        let refReasonRecord = refrlReasonsList.find(_data => (_data.code === refCode));

        if (!refReasonRecord) {
            let _refReasons = [];
            let request: GetLOVData = new GetLOVData().getRequest('ALL', 'MED', 'ALL', 'ALL', 'ALL', 'ALL', 'Referral Reasons', 'LOV');
            request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
            request.ADVANCE_CONFIG_XML.FILTERS = new Filter();

            this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, null, null, false, null).success((data) => {
                if (data.tuple) {
                    if (Array.prototype.isPrototypeOf(data.tuple)) {
                        for (let _rec of data.tuple) {
                            _refReasons.push(_rec.old.DESCPF);
                        }
                    }
                    else if (data.tuple && data.tuple.old && data.tuple.old.DESCPF) {
                        _refReasons.push(data.tuple.old.DESCPF);
                    }
                }
            }).error((response, status, errorText) => {
                this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error while getting Referral Reasons ", 5000));
            });

            if (_refReasons && _refReasons.length > 0) {
                refReasonRecord = _refReasons.find(_data => (_data.code === refCode));
            }
        }

        if (refReasonRecord) {
            if (riskObj.referralReasons.referralReason && (riskObj.referralReasons.referralReason.length == 0 || !riskObj.referralReasons.referralReason.find((_data1) => _data1.code == refCode))) {
                let _referralReason = new ReferralReason();
                _referralReason.seqNumber = riskObj.referralReasons.referralReason.length + 1;
                _referralReason.code = refReasonRecord.code;
                _referralReason.description = refReasonRecord.description;
                _referralReason.isSysReferred = (isSysRef) ? 'Y' : 'N';

                riskObj.referralReasons.referralReason.push(_referralReason);

                // this.removeRefrlReasonFromSelectionList(refCode, selectableReflReasonsList);
            }
            else if (riskObj.referralReasons.referralReason && riskObj.referralReasons.referralReason.find((_data1) => _data1.code == refCode)) {
                let _refReason = riskObj.referralReasons.referralReason.find((_data1) => _data1.code == refCode);
                _refReason.isSysReferred = (isSysRef) ? 'Y' : 'N';

                // this.removeRefrlReasonFromSelectionList(refCode, selectableReflReasonsList);
            }
        }
    }

    removeRefrlReasonFromSelectionList(refCode, selectableReflReasonsList) {
        if (selectableReflReasonsList) {
            let _selectedRefReason = selectableReflReasonsList.find(item => item.code == refCode);
            if (_selectedRefReason) {
                selectableReflReasonsList.splice(selectableReflReasonsList.indexOf(_selectedRefReason), 1);
            }
        }
    }

    deleteReferralReason(riskObj, refCode, sysRef) {
        let refReasonRecord = riskObj.referralReasons.referralReason.find((_data1) => _data1.code == refCode);
        if (refReasonRecord && (!sysRef || (sysRef && refReasonRecord.isSysReferred == 'Y'))) {
            riskObj.referralReasons.referralReason.splice(riskObj.referralReasons.referralReason.indexOf(refReasonRecord), 1);
        }
    }

    callbackForReferralReasons(scopeObject) {
        for (let _refReason of scopeObject.lovDropDownService.lovDataList.referralReasons) {
            // let hasRefReason = scopeObject.referralReasons.some( _data => _data.code === _refReason.code );
            let hasRefReason = scopeObject.riskObj.referralReasons.referralReason.some(_data => _data.code == _refReason.code);
            if (!hasRefReason) {
                scopeObject.referralReasons.push(_refReason);
            }
        }
    }

    callbackReferralAgeLimits(scopeObject) {
        if (this.riskObj.insuredPersonDetails.insuredPersonType.insuredAge == 0 || (!this.riskObj.ageLimitFlag && this.riskObj.insuredPersonDetails.insuredPersonType.DOB && this.riskObj.occupationCode)) {
            this.checkRefferedRisksConditions();
        }
    }

    calculateAge(dob) {
        let calAge: number = 0;
        if (dob != null && dob != "") {
            let curDate = moment(new Date().toISOString(), "YYYY-MM-DD");
            let date = moment(dob, "YYYYMMDD").format("YYYY-MM-DD");
            calAge = curDate.diff(date, 'year');
        }
        else
            calAge = 0;
        return calAge;
    }

    handleRiskClassification(comp) {

        if (comp.riskObj.symRiskClassification == "Declined")
            comp.riskObj.riskClassification = "Declined";
        else if (comp.riskObj.symRiskClassification == "Referred" || comp.riskObj.riRiskClassification == "Referred")
            comp.riskObj.riskClassification = "Referred";
        else if (comp.isManuallyReferred)
            comp.riskObj.riskClassification = "Referred";
        else
            comp.riskObj.riskClassification = "Standard";

        comp.setRiskClassification(comp);
    }

	/*setRisksClassification(comp) {
        if (comp.riskObj.symRiskClassification != null && comp.riskObj.symRiskClassification != "" && (comp.riskObj.symRiskClassification == "Referred" || comp.riskObj.symRiskClassification == "Declined")) {
            let statusTxt = (comp.riskObj.symRiskClassification != null && comp.riskObj.symRiskClassification != "") ? comp.riskObj.symRiskClassification : comp.riskObj.riskClassification;
            comp.riskObj.riskClassificationReason = "System marked as " + statusTxt;
        }
        else {
            if (comp.riskObj.riskClassificationReason != null && comp.riskObj.riskClassificationReason != "" && (comp.riskObj.riskClassificationReason != "System marked as Standard"
                && comp.riskObj.riskClassificationReason.indexOf("System marked as ") != -1)) {
                comp.riskObj.riskClassificationReason = "";
            }
        }
        comp.onRiskClsChange.emit('');
	} */

    // GA001 End
    // Divek -0555 Start
    setInsuredAge() {
        if (this.riskObj.insuredPersonDetails.insuredPersonType.DOB != null && this.riskObj.insuredPersonDetails.insuredPersonType.DOB != "") {
            let curDate = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.effectiveDate;
            let date = moment(this.riskObj.insuredPersonDetails.insuredPersonType.DOB, "YYYY-MM-DD").format("YYYY-MM-DD");
            let dobYear = date.substring(0, 4);
            let inclDtYear = curDate.substring(0, 4);
            let age = inclDtYear - dobYear;
            this.riskObj.insuredPersonDetails.insuredPersonType.insuredAge = age;

        }
        else {
            this.riskObj.insuredPersonDetails.insuredPersonType.insuredAge = 0;
            //this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "DOB can not be empty.", 5000));            
        }
    }
    // END
}
