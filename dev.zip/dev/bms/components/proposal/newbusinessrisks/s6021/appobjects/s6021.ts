import { Clause } from '../../appobjects/clause';
import { FinancialInterest } from '../../../../../../common/components/financialinterest/appobjects/financialInterest';
import { GSTDetails } from '../../appobjects/gstDetails';
import { AppUtil } from '../../../../../../common/components/utility/apputil/app.util';
import { Survey } from '../../appobjects/survey';
import { NBRisk } from '../../../appobjects/nbrisk';
import { PostedPrem } from '../../../proposalheader/appobjects/postedprem';

export class S6021 implements NBRisk {
    public sequenceNumber: string;
    public effectiveDate: string;
    public dateOfAttachment: string;
    public contractNumber: string;
    public contractType: string;
    public riskNumber: string;
    public riskType: string;
    public riskName: string;
    public ratingFlag: string = "M";
    public RIRetentionCode: string = "MLL";
    public prmClass: string = "24A";
    public businessCode: string;
    public businessCodeDesc: string;
    public tLimit: string = "";
    public turnoverCode: string = "";
    public turnoverAmount: number = 0;
    public totalAOA: number = 0;
    public totalAOP: number = 0;
    public minimumPremium: number = 0;
    public basicPremium: number = 0;
    public originalTotalPremium: number = 0;
    public postedPremium: number = 0;
    public basePostedPremiumAdj: number = 0;
    public discountedPremium: number = 0;
    public grossPremium: number = 0;
    public totalPremium: number = 0;
    public capitalSumInsured: number = 0;
    public relatedSumInsured: number = 0;
    public totalGrossCapacity: number = 0;
    public totalSI: number = 0;
    public GST: number = 0//6;//SST Code
    public gstAmount: number = 0;
    public rebate: number = 0;
    public rebateAmount: number = 0;
    public areaCode: string = "DO";
    public situationLine1: string;
    public situationLine2: string;
    public situationLine3: string;
    public situationLine4: string;
    public situationLine5: string;
    public situationLine6: string;
    public situationLine7: string;

    public riskCoverageDetails: RiskCoverageDetails;
    public clauses: Clause;
    public financialInterest: FinancialInterest;
    public GSTDetails: GSTDetails;
    public survey: Survey;

    public riskClassification: string = "Referred";
    public riskClassificationReason: string = "System marked as Referred";
    public symRiskClassification: string = "Referred";
    public riRiskClassification: string = "Standard";

    public RIMethod: string = "0";
    public RIMethodSys: string = "0";
    public RIRequired: string = "No";
    public isRIOverWrittenByUW: string = "N";
    public isSurveyNeeded: string = "N";
    public hasClaimExperience: string = "N";
    public GT: string;
    public GP: string;
    public FI: string = 'N';
    public DS: string;
    public CL: string;
    public MI: string;
    public isPOIConsidered: string = "N";
    public priority: string;
    public postedPremDetails: PostedPrem;

    public SST: number = 0; //SST
    public sstAmount: number = 0;//SST
    constructor() {
        this.riskCoverageDetails = new RiskCoverageDetails();
        this.clauses = new Clause();
        this.financialInterest = new FinancialInterest();
        this.GSTDetails = new GSTDetails();
    }

    public getInstance(valObj: S6021) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
            this.riskCoverageDetails = new RiskCoverageDetails().getInstance(valObj.riskCoverageDetails);
            this.clauses = new Clause().getInstance(valObj.clauses);
            if (valObj.FI == "Y") {
                this.financialInterest = new FinancialInterest().getInstance(valObj.financialInterest);
            }
            this.GSTDetails = new GSTDetails().getInstance(valObj.GSTDetails);
            if (valObj.isSurveyNeeded == "Y") {
                this.survey = new Survey().getInstance(valObj.survey);
            }
        }
        return this;
    }

    public getNewInstanceByCriteria(criteria: any) {

        return this;
    }

    public getValidator() {
        return null;
    }
}

export class RiskCoverageDetails {

    public riskCoverage: RiskCoverage[] = [];

    public getInstance(valObj: RiskCoverageDetails) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
            new AppUtil().handleArray(this, valObj, "riskCoverage");
        }
        return this;
    }
}

export class RiskCoverage {
    public seqNumber: number;
    public limit: number;
    public rate: number;
    public load: number;
    public premium: number;
    public excessType: string;
    public excessPercentage: number;
    public excessAmount: number;
    public aoa: number;
    public aop: number;

    constructor() {
    }

    public getInstance(valObj: RiskCoverage) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
        }
        return this;
    }
}
