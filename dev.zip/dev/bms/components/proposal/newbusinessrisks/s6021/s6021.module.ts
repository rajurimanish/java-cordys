import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BasicUIModule } from '../../../../../common/components/utility/basicui.module';
import { FIModule } from '../../../../../common/components/financialinterest/fi.module';
import { LovModule } from "../../../../../common/services/lovdropdown/lov.module";
import { SurveyModule } from '../uimodules/survey.module';
import { ClausesModule } from '../uimodules/clauses.module';
import { GSTModule } from '../uimodules/gst.module';

import { S6021Component } from './s6021.component';

@NgModule({
    imports: [CommonModule, FormsModule, ReactiveFormsModule, BasicUIModule, FIModule, LovModule, ClausesModule, GSTModule, SurveyModule],
    declarations: [S6021Component],
    exports: [S6021Component]
})
export class S6021Module { }