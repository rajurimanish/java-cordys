import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BasicUIModule } from '../../../../../common/components/utility/basicui.module';
import { LovModule } from "../../../../../common/services/lovdropdown/lov.module";
import { ClausesModule } from '../uimodules/clauses.module';
import { GSTModule } from '../uimodules/gst.module';
import { FIModule } from '../../../../../common/components/financialinterest/fi.module';
import { SurveyModule } from '../uimodules/survey.module';
import { GeneralPageModule } from '../uimodules/generalpage.module'; //VK004
import { S4851Component } from './s4851.component';

@NgModule({
    imports: [
        CommonModule, FormsModule, ReactiveFormsModule, BasicUIModule, LovModule,
        ClausesModule, GSTModule, FIModule, SurveyModule, GeneralPageModule],
    declarations: [S4851Component],
    exports: [S4851Component]
})
export class S4851Module { }