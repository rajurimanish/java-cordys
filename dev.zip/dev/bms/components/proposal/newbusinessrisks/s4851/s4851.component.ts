/*
 * Change History:
 * 
 * No      Date          Description                                         Changed By
 * ====    ==========    ===========                                         ==========
 * GA001   18/10/2018   MYS-2018-1259 - EAR - Case turned Referred 
 * 						when Testing Period more than 4 weeks    				KGA
 * GA002   07/05/2019   MYS-2019-0041 - To enhance the module of Occupation (update: 0094: MP > 36 months) and
 * 						maintenance period referred risk validation    			KGA		
 * YPK001 23/09/2019       MYS-2019-0675 Document Validation for Co-outwards            PKU1
 *                         case before sending to PPHO					   
*/
import { Component, OnInit, ViewChild, ElementRef, EventEmitter, AfterViewInit, ViewContainerRef } from '@angular/core';
import { DCLInput, CustomDCLService } from '../../../../../common/services/customdcl.service';
import { LOV_Field, LOVDropDownService, SearchFilter } from "../../../../../common/services/lovdropdown/lovdropdown.service";
import { CordysSoapWService } from "../../../../../common/components/utility/cordys-soap-ws";
import { GetLOVData, SearchAdvancedConfig, Filter } from '../../../../../common/components/utility/search/search.requests';
import { ProposalHeader } from '../../proposalheader/appobjects/proposalheader';
import { AlertMessagesService } from '../../../../../common/components/utility/alertmessage/alertmessages.service';
import { AlertMessage } from '../../../../../common/components/utility/alertmessage/alertmessages.model';
import { S4851, MaterialDamageCover } from './appobjects/s4851';
import { Survey } from '../appobjects/survey';
import { Clause } from "../appobjects/clause";
import { FinancialInterest } from '../../../../../common/components/financialinterest/appobjects/financialInterest';
import { BMSConstants } from '../../../common/constants/bms_constants';
import { CaseInfo } from '../../../../../common/components/appobjects/caseinfo';
import { ApplicationUtilService } from "../../../../../common/services/application.util.service";
import { BMSUtilService } from "../../../../services/bms.util.service";
import { AppUtil } from '../../../../../common/components/utility/apputil/app.util';
import { RIService } from '../services/ri.service';
import { ReferredReason, Reasons } from '../../proposalheader/appobjects/referredreason';
import { RiskClassificationService } from "../services/riskcls.service";
import { ActivatedRoute } from '@angular/router';
import { ClausesComponent } from "../uimodules/clauses.component";

declare var jQuery: any;
declare var moment: any;
declare var numeral: any;

@Component({
    selector: 's4851-risk-component',
    templateUrl: 'app/bms/components/proposal/newbusinessrisks/s4851/s4851.template.html',
    inputs: ['riskObj', 'clientDetails', "headerInfo", "caseInfo"],
    outputs: ["onPremiumChange", "onRiskClsChange", "onRtngFlgChange"]
})

export class S4851Component implements OnInit {
    private el: HTMLElement;
    public riskObj: S4851;
    public headerInfo: ProposalHeader;
    public caseInfo: CaseInfo;
    private isCollapsedMode: boolean = false;
    private clCBIInfoCollapse: boolean = true;
    private coverageInfoCollapse: boolean = false;
    private surInfoCollapse: boolean = false;
    private isGeneralPageCollapsed: boolean = false;

    public siFormat: string = "0,00";
    public premiumFormat: string = "0,00.00";
    public rateFormat: string = "0.00000";
    public percentFormat: string = "0.00";
    public loadFormat: string = "0.00";

    public contractPeriodFromCtrl: any;
    public contractPeriodToCtrl: any;
    public maintenancePeriodFromCtrl: any;
    public maintenancePeriodToCtrl: any;
    public testingPeriodFromCtrl: any;
    public testingPeriodToCtrl: any;

    private basicPremiumCtrl: any;
    private coverPremiumCtrl: any = [];
    private coverRateCtrl: any = [];

    // private isReferredContractPeriod="N";
    // private isReferredMaintncePeriod="N";

    private isUnderWriter = "N";
    private isRIMethodEditable = "Y";
    private disableBasicPrem: string = 'N';
    private contractWorkSIFlag: string = 'N';

    onPremiumChange = new EventEmitter<any>();
    onRiskClsChange = new EventEmitter<any>();
    onRtngFlgChange = new EventEmitter<any>();

    @ViewChild(ClausesComponent) private clausesComp: ClausesComponent;

    constructor(private lovDropDownService: LOVDropDownService, private _soapService: CordysSoapWService, public _alertMsgService: AlertMessagesService, el: ElementRef, public dcl: CustomDCLService, private _appUtilService: ApplicationUtilService, private _bmsUtilService: BMSUtilService, private _riService: RIService, private riskClassificationService: RiskClassificationService, private _activatedRoute: ActivatedRoute) {
        this.el = el.nativeElement;
    }

    ngOnInit() {
        this.populateLOVs();

        this._appUtilService.isUnderWriterUser().subscribe((data) => {
            this.isUnderWriter = data;
            this.setRIMethodEditableFlag();
        });

        // this.setContractPeriodDefaults(true);
        // this.setMaintcePeriodDefaults(true);

        this.populateMaterialDamage();
        if (this.riskObj.premAllocPercentage == 0) {
            this.populatePremAllocationPercentage();
        }
        this.disableBasicPrem = (this.riskObj.ratingFlag == 'A') ? "Y" : "N";

        this.setContractWorkSIFlag();

        //SST Code
        if (["MyTasks", "MyDrafts"].indexOf(this._activatedRoute.snapshot.params['component']) >= 0 || Object.keys(this._activatedRoute.snapshot.params).length == 0) {
            let respObj = this._bmsUtilService.getTAXDetails();
            if (respObj != undefined && respObj != "") {
                this.headerInfo.SSTTaxRate = Number(respObj[0].old.ITEMPF.GST);
                this.headerInfo.GSTTaxRate = Number(respObj[1].old.ITEMPF.GST);

                this.riskObj.SST = Number(this.headerInfo.SSTTaxRate);
                this.riskObj.GST = Number(this.headerInfo.GSTTaxRate);
            }

            this.headerInfo = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo;
            this.riskObj.SSTLiveDate = (this.riskObj.SSTLiveDate == undefined) ? this.headerInfo.SSTLiveDate : this.riskObj.SSTLiveDate;
            if (this.riskObj.SSTLiveDate == undefined || this.riskObj.SSTLiveDate == "") {
                let tempRespObj = this._bmsUtilService.getLiveDate();
                this.riskObj.GSTLiveDate = tempRespObj[0].old.ITEMPF.LIVEDATE;
                this.riskObj.SSTLiveDate = tempRespObj[1].old.ITEMPF.LIVEDATE;
                if (this.headerInfo.SSTLiveDate == undefined || this.headerInfo.SSTLiveDate == "") {
                    this.headerInfo.SSTLiveDate = this.riskObj.SSTLiveDate;
                }
                if (this.headerInfo.GSTLiveDate == undefined || this.headerInfo.GSTLiveDate == "") {
                    this.headerInfo.GSTLiveDate = this.riskObj.GSTLiveDate;
                }
            }
            if (moment(this.headerInfo.effectiveDate, "YYYY-MM-DD").format("YYYYMMDD") >= moment(this.riskObj.SSTLiveDate, "YYYY-MM-DD").format("YYYYMMDD")) {
                this.riskObj.isGSTApplicable = false;
            } else {
                this.riskObj.isGSTApplicable = true;
            }
        }
        //End
    }

    ngAfterViewInit() {
        this.initRatingFlagChange();
        //START YPK001
        let rIndex = 0;
        if ((this.headerInfo.CoInsurance == 'Y' && this.riskObj.riskNumber == '1') && (["MyTasks", "MyDrafts"].indexOf(this._activatedRoute.snapshot.params['component']) >= 0 || Object.keys(this._activatedRoute.snapshot.params).length == 0)) {
            if (this.headerInfo.coInsuranceDetails.coInsurance.length == 1) {
                if (!(this.headerInfo.coInsuranceDetails.coInsurance[0].coInsuranceindicator == 'L' && this.headerInfo.coInsuranceDetails.coInsurance[0].sharePercentage == '100')) {
                    rIndex = this.riskObj.clauses.clause.map(function (item) { return item.clauseCode; }).indexOf("COIN");
                    if (rIndex == -1)
                        this.setClauses(["COIN"], false);
                }
            }
            else {
                rIndex = this.riskObj.clauses.clause.map(function (item) { return item.clauseCode; }).indexOf("COIN");
                if (rIndex == -1)
                    this.setClauses(["COIN"], false);
            }
        }
    }
    setClauses(clausesList, flag) {
        if (this.clausesComp)
            this.clausesComp.addClause(clausesList, '', flag);
        //END YPK001
    }

    populateLOVs() {
        this.lovDropDownService.createLOVDataList(["riCode", "riskOcc", "state", "Occupation"]);

        let riCodeFilterDetails = [new SearchFilter("LONGDESC", this.riskObj.riskType, "STARTSWITH", "AND")];
        let riCodeFilterNodes = this.lovDropDownService.createFilter(riCodeFilterDetails);

        let riskFilter = (this.riskObj.riskType.length == 2) ? this.riskObj.riskType + ' ' : this.riskObj.riskType;
        let riskTypeFilterDetails = [new SearchFilter("DESCITEM", riskFilter, "STARTSWITH", "AND")];
        let riskTypeFilterNodes = this.lovDropDownService.createFilter(riskTypeFilterDetails);


        let lovFields = [
            new LOV_Field("ALL", "MOTOR", "NEW BUSINESS", "ALL", "NEW", "PRIVATE_MOTOR", "RI Retention Code", "LOV", riCodeFilterNodes, "DESCPF", "riCode", null),
            new LOV_Field("ALL", "ALL", "MOTOR_VPMS", "MTR", "ALL", "MOTOR_SCREEN", "State", "LOV", [], "DESCPF", "state", null),
            new LOV_Field("ALL", "MIS", "ALL", "ALL", "ALL", "ALL", "Occupation", "LOV", riskTypeFilterNodes, "T9109", "Occupation", null)
        ];
        // new LOV_Field("ALL", "ALL", "NEW BUSINESS", "ALL", "NEW", "ALL", "Risk Occupancy Code", "LOV", [], "DESCPF", "riskOcc", null),
        this.lovDropDownService.util_populateLOV(lovFields, this);
    }

    populateMaterialDamage() {
        if (this.riskObj.materialDamageCoverDetails.materialDamageCover.length == 0) {
            let request: GetLOVData = new GetLOVData().getRequest('ALL', 'ENG', 'ALL', 'ALL', 'ALL', 'ALL', 'MaterialDamageCoverage', 'LOV');
            request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
            request.ADVANCE_CONFIG_XML.FILTERS = new Filter();
            request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({ "@FIELD_NAME": "DESCITEM", "@FIELD_VALUE": this.riskObj.riskType, "@OPERATION": "EQ", "@CONDITION": "AND" });

            this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, null, null, false, null).success((data) => {
                let results = [];
                if (data.tuple) {
                    if (Array.prototype.isPrototypeOf(data.tuple)) {
                        results = data.tuple;
                    }
                    else if (data.tuple.old && data.tuple.old.T4991) {
                        results = [data.tuple];
                    }
                }
                if (results && results.length > 0) {
                    let counter = 1;
                    for (let _row of results) {
                        let coverDesc = _row.old.T4991.SCVR;
                        let coverageItem = new MaterialDamageCover();
                        if (coverDesc.indexOf('1.') == 0) {
                            coverageItem.isContractWork = 'Y';
                        }
                        else {
                            counter++;
                            coverageItem.seqNumber = counter;
                        }

                        if (coverDesc == 'Construction Plant & Equipment' || coverDesc == 'Construction Machinery') {
                            coverageItem.isConstruction = 'Y';
                        }

                        coverageItem.insured = coverDesc;
                        coverageItem.rowNumber = this.riskObj.materialDamageCoverDetails.materialDamageCover.length + 1;
                        this.riskObj.materialDamageCoverDetails.materialDamageCover.push(coverageItem);
                    }
                }

            }).error((response, status, errorText) => {
                this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error while getting Material damage coverage items.", 5000));
            });
        }
    }

    populatePremAllocationPercentage() {
        let polEffDate = ApplicationUtilService.getFormattedDate(this.headerInfo.effectiveDate, "YYYY-MM-DD", "YYYYMMDD");

        let request: GetLOVData = new GetLOVData().getRequest('ALL', 'ENG', 'ALL', 'ALL', 'ALL', 'ALL', 'Personal Premium Allocation', 'LOV');
        request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        request.ADVANCE_CONFIG_XML.FILTERS = new Filter();

        request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({ "@FIELD_NAME": "DESCITEM", "@FIELD_VALUE": this.headerInfo.contractType, "@OPERATION": "EQ", "@CONDITION": "AND" },
            { "@FIELD_NAME": "ITMFRM", "@FIELD_VALUE": polEffDate, "@OPERATION": "LTEQ", "@CONDITION": "AND" },
            { "@FIELD_NAME": "ITMTO", "@FIELD_VALUE": polEffDate, "@OPERATION": "GTEQ", "@CONDITION": "AND" });

        this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, null, null, false, null).success((data) => {

            if (data.tuple) {
                this.riskObj.premAllocPercentage = 0;
                let _ZNCBLPER: any;

                if (Array.prototype.isPrototypeOf(data.tuple)) {
                    _ZNCBLPER = data.tuple[0].old.T4949.ZNCBLPER;
                }
                else if (data.tuple.old && data.tuple.old.T4949) {
                    _ZNCBLPER = data.tuple.old.T4949.ZNCBLPER;
                }

                if (_ZNCBLPER) {
                    _ZNCBLPER = (_ZNCBLPER == null || _ZNCBLPER == "") ? 0 : parseFloat("" + _ZNCBLPER);
                    if (_ZNCBLPER > 0) {
                        this.riskObj.premAllocPercentage = (_ZNCBLPER * 0.001);
                    }
                }
            }
        }).error((response, status, errorText) => {
            this.riskObj.premAllocPercentage = 0;
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error while getting Personal Premium Allocation", 5000));
        });
    }

    calculateCoverPremium(cover, fld) {
        let _si: any = cover.sumInsured;
        let _rate: any = cover.basicRate;
        let _premium: any = cover.premium;
        _si = (_si == null || _si == "") ? 0 : parseFloat("" + _si);
        _rate = (_rate == null || _rate == "") ? 0 : parseFloat("" + _rate);
        _premium = (_premium == null || _premium == "") ? 0 : parseFloat("" + _premium);

		/*if(_si > 0 && _rate > 0 && _premium ==0){
			_premium = _si * _rate * 0.01;
			cover.premium = _premium;
		}
		else if(_si > 0 && _rate == 0 && _premium >0){
			_rate = (_premium * 100)/_si;
			cover.basicRate = _rate;
		}*/


        if (_si > 0 && fld == 'premium') {
            _rate = (_premium > 0) ? (_premium * 100) / _si : 0;
            this.setCoverRate(cover, _rate);
        }
        else if (_si > 0 && fld == 'rate') {
            _premium = (_rate > 0) ? (_si * _rate * 0.01) : 0;
            this.setCoverPremium(cover, _premium);
        }
        else if (_si > 0) {
            _rate = (_premium > 0) ? ((_premium * 100) / _si) : 0;
            this.setCoverRate(cover, _rate);
        }
        else {
            _premium = 0;
            _rate = 0;
            this.setCoverPremium(cover, _premium);
            this.setCoverRate(cover, _rate);
        }
        // cover.premium = numeral(numeral(_premium).format(this.premiumFormat)).value();
        // cover.basicRate = numeral(numeral(_rate).format(this.rateFormat)).value();

        this.calculateTotalPremium();
    }

    setCoverPremium(cover, val) {
        cover.premium = numeral(numeral(val).format(this.premiumFormat)).value();

        let prmCtrl = this.coverPremiumCtrl[cover.rowNumber];
        if (prmCtrl != null) prmCtrl.setter(val, prmCtrl.comp);
    }

    setCoverRate(cover, val) {
        cover.basicRate = numeral(numeral(val).format(this.rateFormat)).value();

        let rateCtrl = this.coverRateCtrl[cover.rowNumber];
        if (rateCtrl != null) rateCtrl.setter(val, rateCtrl.comp);
    }

    calculateTotalPremium() {
        let _premium = 0;
        this.riskObj.iplPremium = 0;
        this.riskObj.totalSISection1 = this.getTotalByProperty("sumInsured", this.riskObj.materialDamageCoverDetails.materialDamageCover, this.siFormat);
        this.riskObj.totalDeductiblesSection1 = this.getTotalByProperty("deductibles", this.riskObj.materialDamageCoverDetails.materialDamageCover, this.siFormat);

        _premium = this.getTotalByProperty("premium", this.riskObj.materialDamageCoverDetails.materialDamageCover, this.premiumFormat);

        this.riskObj.capitalSumInsured = this.riskObj.totalSISection1;
        this.riskObj.totalSI = this.riskObj.totalSISection1;

        // if(this.riskObj.ratingFlag == 'A'){

        /*for(let _coverItem of this.riskObj.materialDamageCoverDetails.materialDamageCover){
            let si:any = _coverItem.sumInsured;
            let basicRate:any = _coverItem.basicRate;
            si = (si == null || si == "") ? 0 : si;
            basicRate = (basicRate == null || basicRate == "") ? 0 : basicRate;

            _premium = _premium + (si * basicRate * 0.01);
        }*/
        // }

        _premium = _premium + parseFloat("" + this.riskObj.totalPremiumSection2);

        this.riskObj.premium = numeral(numeral(_premium).format(this.premiumFormat)).value();

        this.riskObj.basicPremium = this.riskObj.premium;
        this.riskObj.originalTotalPremium = this.riskObj.premium;
        this.riskObj.totalPremium = this.riskObj.premium;

        if (this.riskObj.premium > 0 && this.riskObj.premAllocPercentage > 0) {
            let _iplPremium = this.riskObj.premium * this.riskObj.premAllocPercentage * 0.01;
            this.riskObj.iplPremium = numeral(numeral(_iplPremium).format(this.premiumFormat)).value();
        }

		/*if(this.riskObj.premium > 0){
			let _bmsRisks = BMSConstants.getRisks();
			if(_bmsRisks && _bmsRisks['s4810'] && _bmsRisks['s4810'].length > 0){
				for(let _risk of _bmsRisks['s4810']){
					if(_risk.ratingFlag == 'M'){
						let _rsk_premium = _risk.premium;
						let _rsk_basicPremium = _rsk_premium * this.riskObj.premAllocPercentage * 0.01;
						_risk.basicPremium = numeral(numeral(_rsk_basicPremium).format(this.premiumFormat)).value();
					}
				}
			}
		}*/

        let _contractWorkSI = 0;

        let _sharePercentage = 0;
        let _contractWorkSITotal = 0;
        let _contractWorkPremiumTotal = 0;

        for (let _md of this.riskObj.materialDamageCoverDetails.materialDamageCover) {
            if (_md.isContractWork == 'Y') {
                let _prem: any = _md.premium;
                _prem = (_prem == null || _prem == "") ? 0 : parseFloat("" + _prem);
                _contractWorkPremiumTotal += _prem;

                let _si: any = _md.sumInsured;
                _si = (_si == null || _si == "") ? 0 : parseFloat("" + _si);
                _contractWorkSITotal += _si;
            }
        }

        if (this.headerInfo.businessChannel == '08') {
            this.contractWorkSIFlag = 'Y';
            _contractWorkSI = _contractWorkSITotal;
        }
        else if (this.headerInfo.businessChannel == '06' && this.headerInfo.CoInsurance == 'Y' && this.headerInfo.coInsuranceDetails && this.headerInfo.coInsuranceDetails.coInsurance && this.headerInfo.coInsuranceDetails.coInsurance.length > 0) {
            let _coIns = this.headerInfo.coInsuranceDetails.coInsurance.find((_data) => _data.accountNumber == 'OurShare' && _data.coInsuranceindicator == 'F');
            if (_coIns) {
                let _sPrcnt: any = _coIns.sharePercentage;
                _sharePercentage = (_sPrcnt == null || _sPrcnt == "") ? 0 : parseFloat("" + _sPrcnt);
                this.contractWorkSIFlag = 'Y';

                // if( _contractWorkPremiumTotal > 0 && _sharePercentage > 0 ){
                // _contractWorkSI = _contractWorkPremiumTotal * _sharePercentage * 100;
                // }
                if (_contractWorkSITotal > 0 && _contractWorkSITotal > 0) {
                    _contractWorkSI = _contractWorkSITotal * _sharePercentage * 0.01;
                }
            }
        }
        else {
            this.contractWorkSIFlag = 'N';
            _contractWorkSI = _contractWorkSITotal;
            // if(_contractWorkPremiumTotal > 150000000 ){
            // this.riskObj.lsr = 'Y';
            // }
        }

        if (_contractWorkSI > 150000000)
            this.riskObj.lsr = 'Y';
        else
            this.riskObj.lsr = 'N';

        this.riskObj.contractWorkSI = _contractWorkSI;

        //SST Code
        if (this.headerInfo.contractType == 'CAR' || this.headerInfo.contractType == 'EAR') {
            let contractFrm = (this.headerInfo.contractType == 'CAR') ? this.riskObj.contractPeriodFrom : this.riskObj.erectPeriodFrom;
            let contractTo = (this.headerInfo.contractType == 'CAR') ? this.riskObj.contractPeriodTo : this.riskObj.erectPeriodTo;
            if (contractFrm != undefined && contractFrm != "" && contractTo != undefined && contractTo != "") {
                let respObj = this._bmsUtilService.getTAXDetailsInfo(moment(contractFrm, "YYYY-MM-DD").format("YYYYMMDD"), moment(contractTo, "YYYY-MM-DD").format("YYYYMMDD"));

                if (respObj != undefined && respObj != "") {
                    this.headerInfo.SSTTaxRate = Number(respObj[0].old.ITEMPF.GST);
                    this.headerInfo.GSTTaxRate = Number(respObj[1].old.ITEMPF.GST);

                    this.riskObj.SST = Number(this.headerInfo.SSTTaxRate);
                    this.riskObj.GST = Number(this.headerInfo.GSTTaxRate);
                }
                let tempSSTAmount = (Number(this.riskObj.SST) > 0) ? numeral(numeral((this.riskObj.originalTotalPremium * Number(this.riskObj.SST)) / 100).format(this.premiumFormat)).value() : 0;
                this.riskObj.sstAmount = (tempSSTAmount > 0) ? numeral(numeral(BMSUtilService.calculatePremiumAmt(tempSSTAmount, "S", moment(contractFrm, "YYYY-MM-DD").format("YYYYMMDD"), moment(contractTo, "YYYY-MM-DD").format("YYYYMMDD"))).format(this.premiumFormat)).value() : 0;
            }
        }
        else {
            let tempSSTAmount = (Number(this.riskObj.SST) > 0) ? numeral(numeral((this.riskObj.originalTotalPremium * Number(this.riskObj.SST)) / 100).format(this.premiumFormat)).value() : 0;
            this.riskObj.sstAmount = (tempSSTAmount > 0) ? numeral(numeral(BMSUtilService.calculatePremiumAmount(tempSSTAmount, "S")).format(this.premiumFormat)).value() : 0;
        }

        this.riskObj.totalPremium = this.riskObj.totalPremium + parseFloat("" + numeral(this.riskObj.sstAmount).value());
        //End

        this.onPremiumChange.emit(this.riskObj.totalPremium);

        this.checkReferredRiskConditions();
        this.validateSumInsured();
    }

    setContractWorkSIFlag() {
        if (this.headerInfo.businessChannel == '08' || (this.headerInfo.businessChannel == '06' && this.headerInfo.CoInsurance == 'Y' && this.headerInfo.coInsuranceDetails && this.headerInfo.coInsuranceDetails.coInsurance && this.headerInfo.coInsuranceDetails.coInsurance.length > 0 && this.headerInfo.coInsuranceDetails.coInsurance.find((_data) => _data.accountNumber == 'OurShare' && _data.coInsuranceindicator == 'F'))) {
            this.contractWorkSIFlag = 'Y';
        }
        else this.contractWorkSIFlag = 'N';
    }

    validateSumInsured() {
        if (this.riskObj.riRetentionCode && this.riskObj.isRIOverWrittenByUW == 'N') {
            this._bmsUtilService.getTotalGrossCapacity(this.riskObj.riRetentionCode).subscribe((data) => this.compareSIWithTotGrossCap(data));
        }
        else
            this.setRIMethodEditableFlag();
    }

    compareSIWithTotGrossCap(totGrossCap) {

        let _totalGrossCapacity = (!totGrossCap) ? 0 : parseFloat("" + totGrossCap);
        this.riskObj.totalGrossCapacity = _totalGrossCapacity;

        let _capitalSumInsured = parseFloat("" + this.riskObj.capitalSumInsured);

        if (_totalGrossCapacity > 0 && _capitalSumInsured > _totalGrossCapacity && (this.riskObj.RIMethod == null || this.riskObj.RIMethod == "" || parseFloat("" + this.riskObj.RIMethod) != 8)) {
            this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Capital Sum Insured is greater than Total Gross Capacity: " + _totalGrossCapacity + ",  RI is Required.", 10000));

            this.riskObj.RIRequired = "Yes";
            this.riskObj.RIMethod = "8";
        }
        else if (_capitalSumInsured <= _totalGrossCapacity) {
            this.riskObj.RIRequired = "No";
            this.riskObj.RIMethod = this.riskObj.RIMethodSys;
        }
        this._riService.setRI().subscribe();
        this.setRIMethodEditableFlag();
    }

    getTotalByProperty(prop, ary, format: string) {
        let total = 0;
        for (let eachItem of ary) {
            if (eachItem[prop] != null && eachItem[prop] != "")
                total = total + parseFloat(numeral(eachItem[prop]).value());
        }
        if (format != null)
            return numeral(numeral(total).format(format)).value();
        else
            return total;
    }

    validateContractDate(dateCtrlName) {

        if ((this.riskObj.contractPeriodFrom != null || this.riskObj.contractPeriodFrom != "") && (this.riskObj.contractPeriodTo != null || this.riskObj.contractPeriodTo != "")) {
            let _contractPeriodFrom = moment(this.riskObj.contractPeriodFrom, "YYYY-MM-DD");
            let _contractPeriodTo = moment(this.riskObj.contractPeriodTo, "YYYY-MM-DD");

            if (_contractPeriodFrom > _contractPeriodTo) {
                if (dateCtrlName == 'contractPeriodFrom') {
                    if (this.contractPeriodFromCtrl != null)
                        this.contractPeriodFromCtrl.setter('EMPTY', "YYYY-MM-DD", this.contractPeriodFromCtrl.comp);
                    this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Contract Period: From must be before Contract Period:To", 2000));
                } else if (dateCtrlName == 'contractPeriodTo') {
                    if (this.contractPeriodToCtrl != null)
                        this.contractPeriodToCtrl.setter('EMPTY', "YYYY-MM-DD", this.contractPeriodToCtrl.comp);
                    this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Contract Period: TO must be after Contract Period:From", 2000));
                }
            }
        }

        if (dateCtrlName == 'contractPeriodTo' && this.riskObj.contractPeriodTo && this.riskObj.maintenancePeriodFrom) {

            let _contractPeriodTo = moment(this.riskObj.contractPeriodTo, "YYYY-MM-DD");
            let _maintenancePeriodFrom = moment(this.riskObj.maintenancePeriodFrom, "YYYY-MM-DD");
            if (_contractPeriodTo >= _maintenancePeriodFrom) {
                let _mPeriodStartDate = moment(this.riskObj.contractPeriodTo, "YYYY-MM-DD").add(1, 'days').format("YYYY-MM-DD");
                this.setMaintenacePeriodFrom(_mPeriodStartDate);
            }
        }

        this.setMaintenacePeriod();
    }

    validateMaintenaceDate(dateCtrlName) {
        if (dateCtrlName == 'maintenancePeriodFrom' && this.riskObj.contractPeriodTo && this.riskObj.maintenancePeriodFrom && this.riskObj.riskType == 'CAR') {
            let _contractPeriodTo = moment(this.riskObj.contractPeriodTo, "YYYY-MM-DD");
            let _maintenancePeriodFrom = moment(this.riskObj.maintenancePeriodFrom, "YYYY-MM-DD");
            if (_maintenancePeriodFrom <= _contractPeriodTo) {
                if (this.maintenancePeriodFromCtrl != null)
                    this.maintenancePeriodFromCtrl.setter('EMPTY', "YYYY-MM-DD", this.maintenancePeriodFromCtrl.comp);
                this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Maintenance Period: From must be after the Contract Period:To", 4000));
            }
        }

        if (this.riskObj.maintenancePeriodFrom && this.riskObj.maintenancePeriodTo) {
            let _maintenancePeriodFrom = moment(this.riskObj.maintenancePeriodFrom, "YYYY-MM-DD");
            let _maintenancePeriodTo = moment(this.riskObj.maintenancePeriodTo, "YYYY-MM-DD");

            if (_maintenancePeriodFrom > _maintenancePeriodTo) {
                if (dateCtrlName == 'maintenancePeriodFrom') {
                    if (this.maintenancePeriodFromCtrl != null)
                        this.maintenancePeriodFromCtrl.setter(this.riskObj.maintenancePeriodTo, "YYYY-MM-DD", this.maintenancePeriodFromCtrl.comp);
                    this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Maintenance Period: From must be before the Maintenance Period:To", 4000));
                } else if (dateCtrlName == 'maintenancePeriodTo') {
                    if (this.maintenancePeriodToCtrl != null)
                        this.maintenancePeriodToCtrl.setter(this.riskObj.maintenancePeriodFrom, "YYYY-MM-DD", this.maintenancePeriodToCtrl.comp);
                    this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Maintenance Period: TO must be after Maintenance Period:From", 4000));

                    this.riskObj.maintenancePeriodCode = 0;
                    this.riskObj.maintenancePeriodFreq = '';
                }
            }
        }

        this.setMaintenacePeriod();
        // this.setMaintcePeriodDefaults(false);
    }

	/*setContractPeriodDefaults(isOnLoad){
		let shouldRefer = false;
		if( this.riskObj.contractPeriodFrom && this.riskObj.contractPeriodTo ){
			let _contractPeriodFrom = moment(this.riskObj.contractPeriodFrom,"YYYY-MM-DD");
			let _contractPeriodTo = moment(this.riskObj.contractPeriodTo,"YYYY-MM-DD");					
			
			let difference  = moment(_contractPeriodTo).diff(_contractPeriodFrom);
			let _m = moment.duration(difference).asMonths();
			let _d = moment.duration(difference).asDays();
			let _y = moment.duration(difference).asYears();
			
			if( _m >=60 || (_m > 59 && _d >= 1825) ){
				shouldRefer = true;
			}
		}
		
		if(shouldRefer){
			if(!isOnLoad && this.riskObj.riskClassification != "Referred" && this.riskObj.riskClassification !="Declined" && this.riskObj.symRiskClassification != "Referred" && this.riskObj.symRiskClassification != "Declined" && this.isReferredMaintncePeriod=='N'){
				this.setReferredFromUI("Referred");
				this.riskObj.riskClassificationReason = "System marked as Referred";
			}
			
			this.isReferredContractPeriod = 'Y';
			
		} else if(this.isReferredContractPeriod == 'Y'){
			
			this.isReferredContractPeriod = 'N';
			if(!isOnLoad && this.riskObj.riskClassification !="Declined" && this.riskObj.symRiskClassification != "Referred" && this.riskObj.symRiskClassification != "Declined" && this.isReferredMaintncePeriod=='N'){
				this.riskObj.riskClassificationReason = "";
				this.setReferredFromUI("Standard");
			}
		}
	}
	
	setMaintcePeriodDefaults(isOnLoad){
		let shouldRefer = false;
		if(this.riskObj.maintenancePeriodFrom && this.riskObj.maintenancePeriodTo){
			let _maintenancePeriodFrom = moment(this.riskObj.maintenancePeriodFrom, "YYYY-MM-DD");
			let _maintenancePeriodTo = moment(this.riskObj.maintenancePeriodTo, "YYYY-MM-DD");
			
			let difference  = moment(_maintenancePeriodTo).diff(_maintenancePeriodFrom);
			let _m = moment.duration(difference).asMonths();
			let _d = moment.duration(difference).asDays();
			let _y = moment.duration(difference).asYears();
			
			if( _m >=24 || (_m > 23 && _d >= 729) ){
				shouldRefer = true;
			}
		}
		
		if(shouldRefer){
			if(!isOnLoad && this.riskObj.riskClassification != "Referred" && this.riskObj.riskClassification !="Declined" && this.riskObj.symRiskClassification != "Referred" && this.riskObj.symRiskClassification != "Declined" && this.isReferredContractPeriod=='N'){
				this.setReferredFromUI("Referred");
				this.riskObj.riskClassificationReason = "System marked as Referred";
			}
			
			this.isReferredMaintncePeriod = 'Y';
			
		} else if(this.isReferredMaintncePeriod == 'Y'){
			
			this.isReferredMaintncePeriod = 'N';
			if(!isOnLoad && this.riskObj.riskClassification !="Declined" && this.riskObj.symRiskClassification != "Referred" && this.riskObj.symRiskClassification != "Declined" && this.isReferredContractPeriod=='N'){
				this.riskObj.riskClassificationReason = "";
				this.setReferredFromUI("Standard");
			}
		}
	}
	*/

    setMaintenacePeriodFrom(_date) {
        this.riskObj.maintenancePeriodFrom = _date;
        let _ctrlDate = (_date == "" || _date == "EMPTY") ? "EMPTY" : _date;
        if (this.maintenancePeriodFromCtrl != null)
            this.maintenancePeriodFromCtrl.setter(_ctrlDate, "YYYY-MM-DD", this.maintenancePeriodFromCtrl.comp);
    }

    setMaintenacePeriod() {
        let _duration: any = this.riskObj.maintenancePeriodCode;
        _duration = (_duration == null || _duration == "") ? 0 : _duration;
        if (this.riskObj.maintenancePeriodFreq && _duration > 0) {

            let _mPeriodStartDate = '';
            if (this.riskObj.riskType == 'CAR' && this.riskObj.contractPeriodTo) {
                _mPeriodStartDate = moment(this.riskObj.contractPeriodTo, "YYYY-MM-DD").add(1, 'days').format("YYYY-MM-DD");
            }
            else if (this.riskObj.riskType == 'EAR' && this.riskObj.testingPeriodTo) {
                _mPeriodStartDate = moment(this.riskObj.testingPeriodTo, "YYYY-MM-DD").add(1, 'days').format("YYYY-MM-DD");
            }

            if (_mPeriodStartDate) {
                this.setMaintenacePeriodFrom(_mPeriodStartDate);
            }

			/*
			let _refDate='';
			if( this.riskObj.riskType=='CAR' && this.riskObj.contractPeriodTo){
				
				let _contractPeriodTo = moment(this.riskObj.contractPeriodTo, "YYYY-MM-DD");
				
				let _setMaintFromDate = false;
				if(!this.riskObj.maintenancePeriodFrom){
					_setMaintFromDate = true;
				}
				else {
					let _maintenancePeriodFrom = moment(this.riskObj.maintenancePeriodFrom, "YYYY-MM-DD");
					if( _contractPeriodTo >= _maintenancePeriodFrom ){
						_setMaintFromDate = true;
					}
				}
				
				if(_setMaintFromDate){
					let _mPeriodStartDate = moment(this.riskObj.contractPeriodTo, "YYYY-MM-DD").add(1,'days').format("YYYY-MM-DD");
					this.setMaintenacePeriodFrom(_mPeriodStartDate);
				}
				
			}
			else if( this.riskObj.riskType=='EAR' && this.riskObj.testingPeriodTo){
				let _testingPeriodTo = moment(this.riskObj.testingPeriodTo, "YYYY-MM-DD");
				let _setMaintFromDate = false;
				if(!this.riskObj.maintenancePeriodFrom){
					_setMaintFromDate = true;
				}
				else {
					let _maintenancePeriodFrom = moment(this.riskObj.maintenancePeriodFrom, "YYYY-MM-DD");
					if( _testingPeriodTo >= _maintenancePeriodFrom ){
						_setMaintFromDate = true;
					}
				}
				if(_setMaintFromDate){
					let _mPeriodStartDate = moment(this.riskObj.testingPeriodTo, "YYYY-MM-DD").add(1,'days').format("YYYY-MM-DD");
					this.setMaintenacePeriodFrom(_mPeriodStartDate);
				}
			}*/

            if (this.riskObj.maintenancePeriodFrom) {
                let _maintnPeriodFromPrevDate = moment(this.riskObj.maintenancePeriodFrom, "YYYY-MM-DD").subtract(1, 'days').format("YYYY-MM-DD");
                let _mPeriodEndDate = 'EMPTY';
                if (this.riskObj.maintenancePeriodFreq == 'W') {
                    _mPeriodEndDate = moment(_maintnPeriodFromPrevDate, "YYYY-MM-DD").add((_duration * 7), 'days').format("YYYY-MM-DD");
                }
                else if (this.riskObj.maintenancePeriodFreq == 'M') {
                    _mPeriodEndDate = moment(_maintnPeriodFromPrevDate, "YYYY-MM-DD").add(_duration, 'months').format("YYYY-MM-DD");
                }
                else if (this.riskObj.maintenancePeriodFreq == 'Y') {
                    _mPeriodEndDate = moment(_maintnPeriodFromPrevDate, "YYYY-MM-DD").add(_duration, 'years').format("YYYY-MM-DD");
                }

                this.riskObj.maintenancePeriodTo = (_mPeriodEndDate == 'EMPTY') ? "" : _mPeriodEndDate;
                if (this.maintenancePeriodToCtrl != null)
                    this.maintenancePeriodToCtrl.setter(_mPeriodEndDate, "YYYY-MM-DD", this.maintenancePeriodToCtrl.comp);
            }
        }
        this.setOccMaintenancePeriod();//GA002
        this.checkReferredRiskConditions();
    }

    //GA001 START
    validateTestingDate(dateCtrlName) {
        if (this.riskObj.riskType == 'EAR' && this.riskObj.testingPeriodFrom && this.riskObj.testingPeriodTo) {
            let _testingPeriodFrom = moment(this.riskObj.testingPeriodFrom, "YYYY-MM-DD");
            let _testingPeriodTo = moment(this.riskObj.testingPeriodTo, "YYYY-MM-DD");

            if (_testingPeriodFrom > _testingPeriodTo) {
                if (dateCtrlName == 'testingPeriodFrom') {
                    if (this.testingPeriodFromCtrl != null)
                        this.testingPeriodFromCtrl.setter(this.riskObj.testingPeriodTo, "YYYY-MM-DD", this.testingPeriodFromCtrl.comp);
                    this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Testing Period: From must be before the Testing Period:To", 4000));
                } else if (dateCtrlName == 'testingPeriodTo') {
                    if (this.testingPeriodToCtrl != null)
                        this.testingPeriodToCtrl.setter(this.riskObj.testingPeriodFrom, "YYYY-MM-DD", this.testingPeriodToCtrl.comp);
                    this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Testing Period: TO must be after Testing Period:From", 4000));

                    this.riskObj.testingPeriodCode = 0;
                    this.riskObj.testingPeriodFreq = '';
                }
            }
        }
        this.setTestingPeriod();
    }
    //GA001 END

    setTestingPeriod() {
        let _duration: any = this.riskObj.testingPeriodCode;
        _duration = (_duration == null || _duration == "") ? 0 : _duration;
        if (this.riskObj.testingPeriodFreq && _duration > 0 && this.riskObj.testingPeriodFrom) {

            let _testingPeriodFromPrevDate = moment(this.riskObj.testingPeriodFrom, "YYYY-MM-DD").subtract(1, 'days').format("YYYY-MM-DD");

            let _testPeriodEndDate = 'EMPTY';
            if (this.riskObj.testingPeriodFreq == 'D') {
                _testPeriodEndDate = moment(_testingPeriodFromPrevDate, "YYYY-MM-DD").add(_duration, 'days').format("YYYY-MM-DD");
            }
            else if (this.riskObj.testingPeriodFreq == 'W') {
                _testPeriodEndDate = moment(_testingPeriodFromPrevDate, "YYYY-MM-DD").add((_duration * 7), 'days').format("YYYY-MM-DD");
            }
            else if (this.riskObj.testingPeriodFreq == 'M') {
                _testPeriodEndDate = moment(_testingPeriodFromPrevDate, "YYYY-MM-DD").add(_duration, 'months').format("YYYY-MM-DD");
            }

            this.riskObj.testingPeriodTo = (_testPeriodEndDate == 'EMPTY') ? "" : _testPeriodEndDate;
            if (this.testingPeriodToCtrl != null)
                this.testingPeriodToCtrl.setter(_testPeriodEndDate, "YYYY-MM-DD", this.testingPeriodToCtrl.comp);
        }

        this.checkReferredRiskConditions();
    }

    handleError(response, status, errorText, prms) {
        prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, response.responseJSON.faultstring.text, -1));
    }

    setReferredFromUI(riskClass) {
        this.riskObj.riskClassification = riskClass;
        this.emitRiskClass(this);
    }

    /*setReferredFromUI(){
        if(event.target !=null){
            let riskClass = jQuery(event.target).find("option:selected").text();
            this.riskObj.riskClassification = riskClass;
            this.setReferredByRiskClass(this,riskClass);
        }       
    }*/

    setReferredByRiskClass(comp, riskClass) {
        if (riskClass != null && riskClass == "Referred") {
            comp.setReferred(comp, true);
        }
        else {
            comp.setReferredByRI(comp, comp.riskObj.riRetentionCode);
        }
    }

    setReferred(comp, toRefer) {
        comp.onRiskClsChange.emit("");
    }

    setReferredByRI(comp, riCode) {
        // if(this.leastPreferredRI.indexOf(riCode) != -1){
        // comp.riskObj.riskClassification = "Referred";
        // comp.riskObj.symRiskClassification = "Referred";
        // comp.setReferred(comp,true);
        // }
        // else{
        comp.setReferred(comp, false);
        // }
    }

    setReferredByRIFromUI() {
        if (event.target != null) {
            let riCode = jQuery(event.target).find("option:selected").text();
            this.setReferredByRI(this, riCode);
        }
    }

    emitRiskClass(comp) {
        comp.onRiskClsChange.emit("");
    }

    resetFI(value) {
        if (value == "Y")
            this.riskObj.financialInterest = new FinancialInterest();
        else
            this.riskObj.financialInterest = null;
    }

    onRIRtnChange(value) {
        this.riskObj.riRetentionCode = value;
        // this.setSurveyNeed();
    }

    private onTextChange(ev) {
        if (ev.target.value == ' ') {
            ev.target.value = '';
        }
    }

    validateTextInput(ev) {
        let eVal = ev.target.value;
        ev.target.value = eVal.replace(/\s\s+/g, ' ');
        ev.target.value = ev.target.value.trim();
    }

    validateAlphaValue(ev) {
        let eVal = ev.target.value;
        if (!/^[a-zA-Z]*$/g.test(eVal)) {
            ev.target.value = '';
        }
    }

    private onKeyPressHandler(ev, limit) {
        if (ev.keyCode == 13 || ev.target.value.length == limit) {
            this.setFocusToNext(ev.target);
        } else if (ev.keyCode == 32) {
            ev.target.value = ev.target.value.trim();
        }
    }

    setFocusToNext(elmnt) {
        let locationElmnts = jQuery(this.el).find("input");
        jQuery(locationElmnts[locationElmnts.index(elmnt) + 1]).focus();
    }

    setRIMethod(val) {

        this.riskObj.RIMethod = (val == "Yes") ? "8" : this.riskObj.RIMethodSys;

        if (this.isUnderWriter == "Y" || val == "Yes")
            this.riskObj.isRIOverWrittenByUW = "Y";
        else if (val == "No") {
            this.riskObj.isRIOverWrittenByUW = "N";
            this.validateSumInsured();
        }

        this._riService.setRI().subscribe();
    }

    handleRiskClassification() {
        this.riskClassificationService.setRiskClassification(this.riskObj.riskNumber, "N", "", "").subscribe();
		/*
		if(this.riskObj.symRiskClassification == "Declined")
			this.riskObj.riskClassification = "Declined";
		else if(this.riskObj.symRiskClassification == "Referred" || this.riskObj.riRiskClassification == "Referred")
			this.riskObj.riskClassification = "Referred";
		else
			this.riskObj.riskClassification = "Standard";
		this.setRiskClassification();
		this.emitRiskClass(this);
		*/
    }

    setRiskClassification() {
        if (this.riskObj.symRiskClassification != null && this.riskObj.symRiskClassification != "" && (this.riskObj.symRiskClassification == "Referred" || this.riskObj.symRiskClassification == "Declined")) {
            this.riskObj.riskClassificationReason = "System marked as " + this.riskObj.symRiskClassification;
        }
        else if (this.riskObj.riRiskClassification != null && this.riskObj.riRiskClassification != "" && this.riskObj.riRiskClassification == "Referred") {
            this.riskObj.riskClassificationReason = "System marked as " + this.riskObj.riRiskClassification;
        }
        else {
            if (this.riskObj.riskClassificationReason != null && this.riskObj.riskClassificationReason != "" && (this.riskObj.riskClassificationReason != "System marked as Standard" && this.riskObj.riskClassificationReason.indexOf("System marked as ") != -1)) {
                this.riskObj.riskClassificationReason = "";
            }
        }
    }

    setRIMethodEditableFlag() {
        let _capitalSumInsured = parseFloat("" + this.riskObj.capitalSumInsured);
        let _totalGrossCapacity = parseFloat("" + this.riskObj.totalGrossCapacity);
        if (_totalGrossCapacity > 0 && _capitalSumInsured > _totalGrossCapacity && this.isUnderWriter == "N") {
            this.isRIMethodEditable = "N";
        }
        else {
            this.isRIMethodEditable = "Y";
        }
    }

    emitFlagChange() {
        this.initRatingFlagChange();

        this.calculateTotalPremium();
        this.onRtngFlgChange.emit("");
    }

    initRatingFlagChange() {

        if (this.riskObj.ratingFlag == 'A') {
            // // this.disablePremium ='Y';
            if (this.basicPremiumCtrl != null) this.basicPremiumCtrl.setDisable('Y', this.basicPremiumCtrl.comp);
        } else {
            // // this.disablePremium ='N';
            if (this.basicPremiumCtrl != null) this.basicPremiumCtrl.setDisable('N', this.basicPremiumCtrl.comp);
        }
    }

    resetSurvey(value) {
        if ("Y" == value) {
            this.riskObj.survey = new Survey();
        }
        else {
            this.riskObj.survey = null;
        }
    }

    onLSRChange() {
        this.checkReferredRiskConditions();
    }

    checkReferredRiskConditions() {
        let _reasons = new Reasons();
        let isReferredRisk = false;
        let isDeclinedRisk = false;
        // this.riskObj.isReferredContractPeriod = 'N';
        // this.riskObj.isReferredMaintncePeriod = 'N';

		/*if(this.riskObj.riskType=='CAR'){
			let _isReferredContractPeriod = false;
			if( this.riskObj.contractPeriodFrom && this.riskObj.contractPeriodTo ){
				let _contractPeriodFrom = moment(this.riskObj.contractPeriodFrom,"YYYY-MM-DD");
				let _contractPeriodTo = moment(this.riskObj.contractPeriodTo,"YYYY-MM-DD");					
				
				let difference  = moment(_contractPeriodTo).diff(_contractPeriodFrom);
				let _m = moment.duration(difference).asMonths();
				let _d = moment.duration(difference).asDays();
				let _y = moment.duration(difference).asYears();
				
				if( _m >=60 || (_m > 59 && _d >= 1825) ){
					_isReferredContractPeriod = true;
					_reasons.reason.push("Contract Period is greater than 5 years");
				}
			}
			if(_isReferredContractPeriod){
				this.riskObj.isReferredContractPeriod='Y';
				isReferredRisk = true;
			}
			else
				this.riskObj.isReferredContractPeriod='N';			
		}*/

		/*
		let _polEffDate = moment(this.headerInfo.effectiveDate, "YYYY-MM-DD");
		let _polEndDate = moment(this.headerInfo.endDate, "YYYY-MM-DD");
		let _diffMnths = _polEndDate.diff(_polEffDate,'months');
		if(_diffMnths >= 84){
			isReferredRisk = true;
			_reasons.reason.push("POI is greater than 84 months");
		}*/



		/*
		let _isReferredMantPeriod = false;
		if(this.riskObj.maintenancePeriodFrom && this.riskObj.maintenancePeriodTo) {
			let _maintenancePeriodFrom = moment(this.riskObj.maintenancePeriodFrom, "YYYY-MM-DD");
			let _maintenancePeriodTo = moment(this.riskObj.maintenancePeriodTo, "YYYY-MM-DD");
			
			let difference  = moment(_maintenancePeriodTo).diff(_maintenancePeriodFrom);
			let _m = moment.duration(difference).asMonths();
			let _d = moment.duration(difference).asDays();
			let _y = moment.duration(difference).asYears();
			
			if( _y>2 && (_m >=24 || (_m > 23 && _d >= 729)) ){
				_isReferredMantPeriod = true;
				_reasons.reason.push("Maintenance Period is greater than 24 months");
			}
		}
		
		if(_isReferredMantPeriod){
			// this.riskObj.isReferredMaintncePeriod = 'Y';
			isReferredRisk = true;
		}
		
		let _isReferredTestPeriod = false;
		if(this.riskObj.testingPeriodFrom && this.riskObj.testingPeriodTo) {
			let _testingPeriodFrom 	= moment(this.riskObj.testingPeriodFrom, "YYYY-MM-DD");
			let _testingPeriodTo 	= moment(this.riskObj.testingPeriodTo, "YYYY-MM-DD");
			
			let difference  = moment(_testingPeriodTo).diff(_testingPeriodFrom);
			let _m = moment.duration(difference).asMonths();
			let _d = moment.duration(difference).asDays();
			let _y = moment.duration(difference).asYears();
			
			if(_d > 28){
				_isReferredTestPeriod = true;
				_reasons.reason.push("Testing Period is greater than 4 Weeks");
			}
		}
		
		if(_isReferredTestPeriod){
			isReferredRisk = true;
		}
		
		if(this.riskObj.occRiskClassification == 'Y'){
			isReferredRisk = true;
			_reasons.reason.push("Occupation Code of type Referred is selected");
		}
		
		if(this.riskObj.lsr=='Y' && this.headerInfo.businessChannel != "08"){
			isReferredRisk = true;
			_reasons.reason.push("Large and Specialized Risk (LSR)");
		}
		
		this.riskObj.riskClassificationReasons.reasons = _reasons;
		
		if(isDeclinedRisk){
			this.riskObj.symRiskClassification = "Declined";
		}
		else if(isReferredRisk){
			this.riskObj.symRiskClassification = "Referred";
		}
		else this.riskObj.symRiskClassification = "Standard";
		
		this.handleRiskClassification();
		*/

        this.riskClassificationService.setRiskClassification(this.riskObj.riskNumber, "N", "", "").subscribe();
    }

    validatePremium(cover) {
        let _si: any = 0;
        _si = (cover.sumInsured == null || cover.sumInsured == '') ? 0 : cover.sumInsured;
        if (_si == 0) {
            cover.premium = 0;
            let prmCtrl = this.coverPremiumCtrl[cover.rowNumber];

            if (prmCtrl != null) prmCtrl.setter(0, prmCtrl.comp);
        }
        this.calculateCoverPremium(cover, 'premium');
    }

    onPIAMCodeChange(ev) {
        this.riskObj.occupationCode = ev.value;
        this.riskObj.occupationDesc = ev.record.DESCRIPTION;
        this.riskObj.occRiskClassification = (ev.record.REFERREDRISK) ? ev.record.REFERREDRISK : '';

        this.checkReferredRiskConditions();
    }

    //GA002 START
    setOccMaintenancePeriod() {
        if (this.riskObj.riskType == 'CAR' || this.riskObj.riskType == 'EAR' && (this.riskObj.maintenancePeriodFrom && this.riskObj.maintenancePeriodTo)) {
            let difference = moment(this.riskObj.maintenancePeriodTo, "YYYY-MM-DD").diff(moment(this.riskObj.maintenancePeriodFrom, "YYYY-MM-DD"));
            let _m = moment.duration(difference).asMonths();
            if (_m > 36 && this.riskObj.occupationCode != 'O094') {
                let rec = this.lovDropDownService.lovDataList.Occupation.filter((item) => item.VALUE == 'O094');
                if (rec != undefined && rec.length == 1) {
                    let ev = {
                        "description": rec[0].LONG_DESC,
                        "value": rec[0].VALUE,
                        "record": rec[0]
                    }
                    this.onPIAMCodeChange(ev);
                    this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Maintenance Period is greater than 36 months then Occupation Code changed as O094 : MP > 36 months.", 5000));
                }
            }
            if (this.headerInfo == undefined) {
                this.headerInfo = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo;
            }
            if (_m > 36 && this.riskObj.occupationCode == 'O094') {
                this.headerInfo.isReferredToUW = 'Y';
                this.headerInfo.isReferredToUWMP = 'Y';
            } else {
                this.headerInfo.isReferredToUW = 'N';
                this.headerInfo.isReferredToUWMP = 'N';
            }
        }
    }
    //GA002 END

}
