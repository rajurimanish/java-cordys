import { Clause } from '../../appobjects/clause';
import { FinancialInterest } from '../../../../../../common/components/financialinterest/appobjects/financialInterest';
import { GSTDetails } from '../../appobjects/gstDetails';
import { Survey } from '../../appobjects/survey';
import { AppUtil } from '../../../../../../common/components/utility/apputil/app.util';
import { NBRisk } from '../../../appobjects/nbrisk';
import { PostedPrem } from '../../../proposalheader/appobjects/postedprem';
import { RiskHelper } from '../../../appobjects/riskhelper';
import { ReferredReason } from '../../../proposalheader/appobjects/referredreason';
import { S4851Validator } from '../../../validation/s4851.validator';

export class S4851 extends RiskHelper implements NBRisk {
    public sequenceNumber: string;
    public effectiveDate: string;
    public dateOfAttachment: string;
    public contractNumber: string;
    public contractType: string;
    public riskNumber: string;
    public riskType: string;
    public riskName: string;
    public ratingFlag: string = "A";

    public occupationCode: string;
    public occupationDesc: string;
    public contractWorkSI: number = 0;

    public riskOccupancyCode: string = "99";
    public riRetentionCode: string;
    public insuredLine1: string;
    public insuredLine2: string;
    public insuredLine3: string;
    public insuredLine4: string;
    public contractTitleLine1: string;
    public contractTitleLine2: string;
    public contractTitleLine3: string;
    public contractTitleLine4: string;
    public contractTitleLine5: string;
    public contractSiteLine1: string;
    public contractSiteLine2: string;
    public contractSiteLine3: string;
    public contractPeriodFrom: string;
    public contractPeriodTo: string;
    // public isReferredContractPeriod:string="N";
    public maintenancePeriodFrom: string;
    public maintenancePeriodTo: string;
    public maintenancePeriodCode: number = 0;
    public maintenancePeriodFreq: string;
    // public isReferredMaintncePeriod:string="N";
    public testingPeriodFrom: string;
    public testingPeriodTo: string;
    public testingPeriodCode: number = 0;
    public testingPeriodFreq: string;
    public erectPeriodFrom: string;
    public erectPeriodTo: string;
    public state: string;
    public contractRefNumber: string;
    public totalSISection1: number = 0;
    public totalDeductiblesSection1: number = 0;
    public premium: number = 0;
    public premiumClass: string;

    public limitOfIndemnity1: number = 0;
    public deducitbles1: number = 0;
    public anyOneLimitIndemnity: number = 0;
    public anyOnePremium: number = 0;
    public anyOneDeductibles: number = 0;
    // public anyOneLeftIndicator:string;
    // public anyOneRightIndicator:string;
    public totalLimitIndemnitySection2: number = 0;
    public totalPremiumSection2: number = 0;
    public totalDeductiblesSection2: number = 0;
    // public totalLeftIndicator:string;
    // public totalRightIndicator:string;

    public propDamageLimitIndemnity: number = 0;
    public propDamagePremium: number = 0;
    public propDamageDeductibles: number = 0;
    // public propDamageLeftIndicator:string;
    // public propDamageRightIndicator:string;

    public minimumPremium: number = 0;
    public originalTotalPremium: number = 0;
    public postedPremium: number = 0;
    public basePostedPremiumAdj: number = 0;
    public discountedPremium: number = 0;
    public grossPremium: number = 0;
    public basicPremium: number = 0;
    public totalPremium: number = 0;
    public capitalSumInsured: number = 0;
    public relatedSumInsured: number = 0;
    public totalGrossCapacity: number = 0;
    public totalSI: number = 0;
    public GST: number = 0;
    public gstAmount: number = 0;
    public rebate: number = 0;
    public rebateAmount: number = 0;

    public materialDamageCoverDetails: MaterialDamageCoverDetails;
    public clauses: Clause;
    public GSTDetails: GSTDetails;
    public financialInterest: FinancialInterest;
    public survey: Survey;

    public gpText: string;
    public gpTextCount:string;
    public lsr: string = "N";

    public riskClassification: string = "Standard";
    public riskClassificationReason: string = "";
    public symRiskClassification: string = "";
    public riRiskClassification: string = "Standard";
    public occRiskClassification: string = "";
    public RIMethod: string = "0";
    public RIMethodSys: string = "0";
    public RIRequired: string = "No";
    public isRIOverWrittenByUW: string = "N";
    public isSurveyNeeded: string = "N";
    public hasClaimExperience: string = "N";
    public GT: string;
    public GP: string;
    public FI: string = 'N';
    public DS: string;
    public CL: string;
    public MI: string;
    public isLeastPreferred: string = "N";
    public isPOIConsidered: string = "Y";
    public priority: string;
    public postedPremDetails: PostedPrem;

    public premAllocPercentage: number = 0;

    public childRiskPath: string;
    public childRiskIdentity: string;
    public riskClassificationReasons: ReferredReason;

    public iplPremium: number = 0;
    public iplContractNumber: string;

    public SST: number = 0; //SST Code
    public sstAmount: number = 0;//SST Code
    public SSTLiveDate: string;//SST Code
    public GSTLiveDate: string;//SST Code
    public isGSTApplicable: boolean = true;//SST Code
    constructor() {
        super();
        this.clauses = new Clause();
        this.GSTDetails = new GSTDetails();
        this.financialInterest = new FinancialInterest();
        this.survey = new Survey();
        this.materialDamageCoverDetails = new MaterialDamageCoverDetails();
        this.riskClassificationReasons = new ReferredReason();
    }

    public getInstance(valObj: S4851) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
            this.clauses = new Clause().getInstance(valObj.clauses);
            this.GSTDetails = new GSTDetails().getInstance(valObj.GSTDetails);
            if (valObj.FI == "Y") {
                this.financialInterest = new FinancialInterest().getInstance(valObj.financialInterest);
            }
            if (valObj.isSurveyNeeded == "Y") {
                this.survey = new Survey().getInstance(valObj.survey);
            }
            this.materialDamageCoverDetails = new MaterialDamageCoverDetails().getInstance(valObj.materialDamageCoverDetails);
            this.riskClassificationReasons.refresh(valObj.riskClassificationReasons);
            if (valObj.isGSTApplicable != undefined && JSON.stringify(valObj.isGSTApplicable) != JSON.stringify("") && typeof (valObj.isGSTApplicable) == "string") {
                this.isGSTApplicable = Boolean(JSON.parse(valObj.isGSTApplicable));
            }
        }
        return this;
    }

    public getNewInstanceByCriteria(criteria: any) {
        let riskType = criteria.riskType;

        if (riskType == "CAR") {
            this.ratingFlag = "M";
            // this.riskOccupancyCode = "14";
            this.premiumClass = "17";
            this.riRetentionCode = "CRA";
        } else if (riskType == "EAR") {
            this.ratingFlag = "M";
            this.premiumClass = "15";
            this.riRetentionCode = "ERA";
        }

        return this;
    }

    public getValidator() {
        return new S4851Validator(this);
    }
}

export class MaterialDamageCoverDetails {
    public materialDamageCover: MaterialDamageCover[] = [];

    public getInstance(valObj: MaterialDamageCoverDetails) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
            new AppUtil().handleArray(this, valObj, "materialDamageCover");
        }
        return this;
    }
}

export class MaterialDamageCover {
    public seqNumber: number;
    public rowNumber: number;
    public insured: string;
    public sumInsured: number = 0;
    public premium: number = 0;
    public basicRate: number = 0;
    // public rightIndicator:string;
    // public leftIndicator:string;
    public deductibles: number = 0;
    public isContractWork = 'N';
    public isConstruction = 'N';

    public getInstance(valObj: MaterialDamageCover) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
        }
        return this;
    }

}
