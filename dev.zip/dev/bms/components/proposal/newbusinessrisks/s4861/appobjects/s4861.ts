import { Clause } from '../../appobjects/clause';
import { GSTDetails } from '../../appobjects/gstDetails';
import { AppUtil } from '../../../../../../common/components/utility/apputil/app.util';
import { NBRisk } from '../../../appobjects/nbrisk';
import { PostedPrem } from '../../../proposalheader/appobjects/postedprem';
import { S4861Validator } from '../../../validation/s4861.validator';
import { RiskHelper } from '../../../appobjects/riskhelper';
import { ReferredReason } from '../../../proposalheader/appobjects/referredreason';

export class S4861 extends RiskHelper implements NBRisk {
    public sequenceNumber: string;
    public effectiveDate: string;
    public dateOfAttachment: string;
    public contractNumber: string;
    public contractType: string;
    public riskNumber: string;
    public riskType: string;
    public riskName: string;
    public ratingFlag: string = "A";
    public businessCode: string;
    public businessCodeDesc: string;
    public RIRetentionCode: string = "FG";
    public occupancyCode: string;
    public occupancyCodeDesc: string;
    public premiumClass: string = "61";
    public excessType: string = "";
    public excessPercentage: number = 0;
    public excessAmount: number = 0;
    public rate: number = 0;
    public limitAggregate: number = 0;
    public basicPremium: number = 0;
    public perCapital: number = 0;
    public totalNoEmps: number = 0;
    public perCapitalPremium: number = 0;
    public totalSI: number = 0;
    public capitalSumInsured: number = 0;
    public totalGrossCapacity: number = 0;
    public totalBasePremium: number = 0;
    public totalWages: number = 0;
    public totalPremium: number = 0;
    public minimumPremium: number = 0;
    public originalTotalPremium: number = 0;
    public postedPremium: number = 0;
    public basePostedPremiumAdj: number = 0;
    public discountedPremium: number = 0;
    public rebate: number = 0;
    public rebateAmount: number = 0;
    public GST: number = 0; //6;//SAF MYS-2018-0629
    public gstAmount: number = 0;

    public riskCoverageDetails: RiskCoverageDetails;
    public clauses: Clause;
    public GSTDetails: GSTDetails;
    public RIMethod: string = "1";
    public RIRequired: string = "No";
    public RIMethodSys: string = "0";
    public isRIOverWrittenByUW: string = "N";
    public FI: string = 'N';
    public isSurveyNeeded: string = "N";
    public addRelatedCases: string = "N";
    public hasClaimExperience: string = "N";
    public riskClassification: string = "Standard";
    public riskClassificationReason: string = "";
    public symRiskClassification: string = "";
    public riRiskClassification: string = "Standard";
    public identity: string = "";
    public isPOIConsidered: string = "N";
    public priority: string;
    public postedPremDetails: PostedPrem;

    public childRiskPath: string;
    public childRiskIdentity: string;
    public riskClassificationReasons: ReferredReason;

    public occRiskClassification: string;
    public gpText: string;
    public gpTextCount:string;//VK004
    public SST: number = 0; //SST Code
    public sstAmount: number = 0;//SST Code
    public SSTLiveDate: string;//SST Code
    public GSTLiveDate: string;//SST Code
    public isGSTApplicable: boolean = true;//SST Code
    constructor() {
        super();
        this.riskCoverageDetails = new RiskCoverageDetails();
        this.clauses = new Clause();
        this.GSTDetails = new GSTDetails();
        this.riskClassificationReasons = new ReferredReason();
    }

    public getInstance(valObj: S4861) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
            this.riskCoverageDetails = new RiskCoverageDetails().getInstance(valObj.riskCoverageDetails);
            this.clauses = new Clause().getInstance(valObj.clauses);
            this.GSTDetails = new GSTDetails().getInstance(valObj.GSTDetails);
            this.riskClassificationReasons = new ReferredReason().getInstance(valObj.riskClassificationReasons);
            if (valObj.isGSTApplicable != undefined && JSON.stringify(valObj.isGSTApplicable) != JSON.stringify("") && typeof (valObj.isGSTApplicable) == "string") {
                this.isGSTApplicable = Boolean(JSON.parse(valObj.isGSTApplicable));
            }
        }
        return this;
    }


    public getNewInstanceByCriteria(criteria: any) {
        return this;
    }

    public getValidator() {
        return new S4861Validator(this);
    }
}

export class RiskCoverageDetails {

    public riskCoverage: RiskCoverage[] = [];

    public getInstance(valObj: RiskCoverageDetails) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
            new AppUtil().handleArray(this, valObj, "riskCoverage");
        }
        return this;
    }
}

export class RiskCoverage {
    public seqNumber: number;
    public insuredDetails: string;
    public occupationCode: string;
    public limitGuaranteePerEmp: number = 0;
    public extraText: string = "";
    public etPostingStatus = "N";
    // public xtComments:XTComments;

    constructor() {
        // this.xtComments = new XTComments();
    }

    public getInstance(valObj: RiskCoverage) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
            // //this.xtComments = new XTComments().getInstance(valObj.xtComments);
        }
        return this;
    }
}
