/*
 * Change History:
 * 
 * No      Date          Description                                         Changed By
 * ====    ==========    ===========                                         ==========	
 * YPK001 23/09/2019       MYS-2019-0675 Document Validation for Co-outwards            PKU1
 *                         case before sending to PPHO			   
*/
import { Component, OnInit, ViewChild, ElementRef, EventEmitter, AfterViewInit, ViewContainerRef } from '@angular/core';
declare var Observer: any;
import { DCLInput, CustomDCLService } from "../../../../../common/services/customdcl.service";
import { LOV_Field, LOVDropDownService, SearchFilter } from "../../../../../common/services/lovdropdown/lovdropdown.service";
import { CordysSoapWService } from "../../../../../common/components/utility/cordys-soap-ws";
import { GetLOVData, SearchAdvancedConfig, Filter } from '../../../../../common/components/utility/search/search.requests';
import { AlertMessagesService } from '../../../../../common/components/utility/alertmessage/alertmessages.service';
import { AlertMessage } from '../../../../../common/components/utility/alertmessage/alertmessages.model';
import { S4861, RiskCoverage } from './appobjects/s4861';
import { Clause } from "../appobjects/clause";
import { BMSConstants } from '../../../common/constants/bms_constants';
import { ExtraTextDialogData } from "../dialogs/extratext.dialog.data";
import { ModalInput } from "../../../../../common/components/utility/modal/modal";
import { SearchInput } from "../../../../../common/components/utility/search/genericsearch";
import { ApplicationUtilService } from "../../../../../common/services/application.util.service";
import { BMSUtilService } from "../../../../services/bms.util.service";
import { RIService } from '../services/ri.service';
import { RiskClassificationService } from "../services/riskcls.service";
import { ProposalHeader } from '../../proposalheader/appobjects/proposalheader';
import { ActivatedRoute } from '@angular/router';
import { ClausesComponent } from '../uimodules/clauses.component';

declare var jQuery: any;
declare var moment: any;
declare var numeral: any;

@Component({
    selector: 's4861-component',
    templateUrl: 'app/bms/components/proposal/newbusinessrisks/s4861/s4861.template.html',
    inputs: ['riskObj', 'clientDetails', "headerInfo"],
    outputs: ["onPremiumChange", "onRiskClsChange", "onRtngFlgChange"],
    providers: [RiskClassificationService]
})

export class S4861Component implements OnInit {
    private el: HTMLElement;
    private isCoverInfoCollapsed: boolean = false;
    private clCBIInfoCollapse: boolean = true;
    // private surInfoCollapse:boolean = false;	
    public riskObj: S4861;
    public siFormat: string = "0,00";
    public premiumFormat: string = "0,00.00";
    public rateFormat: string = "0.00000";
    public percentFormat: string = "0.00";
    public accRegCtrl: any;
    private isExcessPercentMandatory: string = 'N';
    private isExcessAmountMandatory: string = 'N';

    public position = 1;
    public sizeObj = { length: 0, orglength: 0 };
    public contentSizeObs: any;
    public itemPerPage = 5;
    public maxPageCount = 10;
    private isUnderWriter = "N";
    private isRIMethodEditable = "Y";
    private isGeneralPageCollapsed: boolean = false;
    @ViewChild(ClausesComponent) private clausesComp: ClausesComponent;
    @ViewChild('xtModal', { read: ViewContainerRef }) contentArea: ViewContainerRef;
    onPremiumChange = new EventEmitter<any>();
    onRiskClsChange = new EventEmitter<any>();
    onRtngFlgChange = new EventEmitter<any>();

    public headerInfo: ProposalHeader;//SST Code

    constructor(private lovDropDownService: LOVDropDownService, private _soapService: CordysSoapWService, public _alertMsgService: AlertMessagesService, el: ElementRef, public dcl: CustomDCLService, private _appUtilService: ApplicationUtilService, private _bmsUtilService: BMSUtilService, private _riService: RIService, public riskClassificationService: RiskClassificationService, private _activatedRoute: ActivatedRoute) {
        this.el = el.nativeElement;
    }

    ngOnInit() {
        this.populateLOVs();

        this._appUtilService.isUnderWriterUser().subscribe((data) => {
            this.isUnderWriter = data;
            this.setRIMethodEditableFlag();
        });
        //SST Code
        if (["MyTasks", "MyDrafts"].indexOf(this._activatedRoute.snapshot.params['component']) >= 0 || Object.keys(this._activatedRoute.snapshot.params).length == 0) {
            let respObj = this._bmsUtilService.getTAXDetails();
            if (respObj != undefined && respObj != "") {
                this.headerInfo.SSTTaxRate = Number(respObj[0].old.ITEMPF.GST);
                this.headerInfo.GSTTaxRate = Number(respObj[1].old.ITEMPF.GST);

                this.riskObj.SST = Number(this.headerInfo.SSTTaxRate);
                this.riskObj.GST = Number(this.headerInfo.GSTTaxRate);
            }

            this.headerInfo = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo;
            this.riskObj.SSTLiveDate = (this.riskObj.SSTLiveDate == undefined) ? this.headerInfo.SSTLiveDate : this.riskObj.SSTLiveDate;
            if (this.riskObj.SSTLiveDate == undefined || this.riskObj.SSTLiveDate == "") {
                let tempRespObj = this._bmsUtilService.getLiveDate();
                this.riskObj.GSTLiveDate = tempRespObj[0].old.ITEMPF.LIVEDATE;
                this.riskObj.SSTLiveDate = tempRespObj[1].old.ITEMPF.LIVEDATE;
                if (this.headerInfo.SSTLiveDate == undefined || this.headerInfo.SSTLiveDate == "") {
                    this.headerInfo.SSTLiveDate = this.riskObj.SSTLiveDate;
                }
                if (this.headerInfo.GSTLiveDate == undefined || this.headerInfo.GSTLiveDate == "") {
                    this.headerInfo.GSTLiveDate = this.riskObj.GSTLiveDate;
                }
            }
            if (moment(this.headerInfo.effectiveDate, "YYYY-MM-DD").format("YYYYMMDD") >= moment(this.riskObj.SSTLiveDate, "YYYY-MM-DD").format("YYYYMMDD")) {
                this.riskObj.isGSTApplicable = false;
            } else {
                this.riskObj.isGSTApplicable = true;
            }
        }
        //End
    }
    //START YPK001
    ngAfterViewInit() {
        let rIndex = 0;
        if ((this.headerInfo.CoInsurance == 'Y' && this.riskObj.riskNumber == '1') && (["MyTasks", "MyDrafts"].indexOf(this._activatedRoute.snapshot.params['component']) >= 0 || Object.keys(this._activatedRoute.snapshot.params).length == 0)) {
            if (this.headerInfo.coInsuranceDetails.coInsurance.length == 1) {
                if (!(this.headerInfo.coInsuranceDetails.coInsurance[0].coInsuranceindicator == 'L' && this.headerInfo.coInsuranceDetails.coInsurance[0].sharePercentage == '100')) {
                    rIndex = this.riskObj.clauses.clause.map(function (item) { return item.clauseCode; }).indexOf("COIN");
                    if (rIndex == -1)
                        this.setClauses(["COIN"], false);
                }
            }
            else {
                rIndex = this.riskObj.clauses.clause.map(function (item) { return item.clauseCode; }).indexOf("COIN");
                if (rIndex == -1)
                    this.setClauses(["COIN"], false);
            }
        }
    }
    setClauses(clausesList, flag) {
        if (this.clausesComp)
            this.clausesComp.addClause(clausesList, '', flag);
    }
    //END YPK001

    populateLOVs() {
        this.lovDropDownService.createLOVDataList(["postCode", "Occupation", "piamcode", "excessType", "riCode", "section"]);

        let excessTypeFilter = (this.riskObj.riskType.length == 2) ? this.riskObj.riskType + ' ' : this.riskObj.riskType;
        let excessTypeFilterDetails = [new SearchFilter("DESCITEM", excessTypeFilter, "STARTSWITH", "AND")];
        let excessTypeFilterNodes = this.lovDropDownService.createFilter(excessTypeFilterDetails);

        let lovFields = [
            new LOV_Field("ALL", "FIRE", "NEW BUSINESS", "ALL", "NEW", "FIRE_IDC", "PostCode", "LOV", [], "DESCPF", "postCode", null),
            new LOV_Field("ALL", "MIS", "ALL", "ALL", "ALL", "ALL", "Occupation", "LOV", excessTypeFilterNodes, "T9109", "Occupation", null),
            new LOV_Field("ALL", "FIRE", "NEW BUSINESS", "ALL", "NEW", "FIRE_IDC", "RiskOccupationCode", "LOV", [], "DESCPF", "piamcode", null),
            new LOV_Field("ALL", "MIS", "NEW BUSINESS", "ALL", "ALL", "ALL", "Excess Type", "LOV", excessTypeFilterNodes, "T9107", "excessType", "callbackForExcessTypesLoad"),
            new LOV_Field("ALL", "MOTOR", "NEW BUSINESS", "ALL", "NEW", "PRIVATE_MOTOR", "RI Retention Code", "LOV", [], "DESCPF", "riCode", null),
            new LOV_Field("ALL", "ALL", "NEW BUSINESS", "ALL", "NEW", "ALL", "MIT Section", "LOV", [], "DESCPF", "section", null)
        ];
        this.lovDropDownService.util_populateLOV(lovFields, this);
        // new LOV_Field("ALL", "MOTOR", "NEW BUSINESS", "ALL", "NEW", "NAMED_DRIVER", "Occupation", "LOV", [], "DESCPF", "Occupation",null),
        // new LOV_Field("ALL", "ALL", "NEW BUSINESS", "ALL", "NEW", "S4805", "Excess Type", "LOV", [], "DESCPF", "excessType",null),
        // new LOV_Field("ALL", "ALL", "ALL", "ALL", "ALL", "ALL", "PIAM Code", "LOOKUP", [] , "DESCPF", "piamcode",null),			
    }

    addRiskCover() {
        if (this.riskObj.businessCode) {
            let coverageItem = new RiskCoverage();
            coverageItem.seqNumber = this.riskObj.riskCoverageDetails.riskCoverage.length + 1;
            coverageItem.occupationCode = this.riskObj.businessCode;

            this.riskObj.riskCoverageDetails.riskCoverage.push(coverageItem);
        } else {
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Select Business Code in Risk Header.", 5000));
        }
    }

    removeRiskCover(coverItem) {
        let _idx = this.riskObj.riskCoverageDetails.riskCoverage.indexOf(coverItem);
        this.riskObj.riskCoverageDetails.riskCoverage.splice(_idx, 1);
        this.resetItemNumber();
        this.resetTotal();
    }

    resetItemNumber() {
        for (let _riskCoverage of this.riskObj.riskCoverageDetails.riskCoverage) {
            let index = this.riskObj.riskCoverageDetails.riskCoverage.indexOf(_riskCoverage);
            _riskCoverage.seqNumber = (index + 1);
        }
    }

    setPremium() {
        this.resetTotal();
    }

    resetTotal() {
        let rate: any = this.riskObj.rate;
        let perCapital: any = this.riskObj.perCapital;
        let totalNoEmps: any = this.riskObj.totalNoEmps;

        rate = (rate == null || rate == "") ? 0 : parseFloat(rate);
        perCapital = (perCapital == null || perCapital == "") ? 0 : parseFloat(perCapital);
        totalNoEmps = (totalNoEmps == null || totalNoEmps == "") ? 0 : parseFloat(totalNoEmps);

        this.riskObj.limitAggregate = this.getTotalByProperty("limitGuaranteePerEmp", this.riskObj.riskCoverageDetails.riskCoverage, null);
        this.riskObj.capitalSumInsured = this.riskObj.limitAggregate;

        if (rate > 0 && this.riskObj.limitAggregate > 0) {
            let _basicPremium = (this.riskObj.limitAggregate * rate) / 100;
            this.riskObj.basicPremium = numeral(numeral(_basicPremium).format(this.premiumFormat)).value();
        } else this.riskObj.basicPremium = 0;

        if (perCapital > 0 && totalNoEmps > 0) {
            let _perCapitalPremium = perCapital * totalNoEmps;
            this.riskObj.perCapitalPremium = numeral(numeral(_perCapitalPremium).format(this.premiumFormat)).value();
        } else this.riskObj.perCapitalPremium = 0;

        let _totalBasePrem = parseFloat("" + this.riskObj.basicPremium) + parseFloat("" + this.riskObj.perCapitalPremium);
        this.riskObj.originalTotalPremium = numeral(numeral(_totalBasePrem).format(this.premiumFormat)).value();

        this.riskObj.rebateAmount = numeral(numeral((parseFloat("" + numeral(_totalBasePrem).value()) * parseFloat("" + this.riskObj.rebate)) / 100).format(this.premiumFormat)).value();
        let discountedPrem = numeral(numeral(parseFloat("" + numeral(_totalBasePrem).value()) - parseFloat("" + numeral(this.riskObj.rebateAmount).value())).format(this.premiumFormat)).value();
        this.riskObj.discountedPremium = discountedPrem;

        //this.riskObj.gstAmount = (parseInt(""+this.riskObj.GST) > 0 && discountedPrem > 0)?numeral(numeral((discountedPrem*parseInt(""+this.riskObj.GST))/100).format(this.premiumFormat)).value():0; //SAF MYS-2018-0629
        //SST Code
        let tempGSTAmount = (parseInt("" + this.riskObj.GST) > 0 && discountedPrem > 0) ? numeral(numeral((discountedPrem * parseInt("" + this.riskObj.GST)) / 100).format(this.premiumFormat)).value() : 0;
        this.riskObj.gstAmount = (tempGSTAmount > 0) ? numeral(numeral(BMSUtilService.calculatePremiumAmount(tempGSTAmount, "G")).format(this.premiumFormat)).value() : 0;

        let tempSSTAmount = (parseInt("" + this.riskObj.SST) > 0 && discountedPrem > 0) ? numeral(numeral((discountedPrem * parseInt("" + this.riskObj.SST)) / 100).format(this.premiumFormat)).value() : 0;
        this.riskObj.sstAmount = (tempSSTAmount > 0) ? numeral(numeral(BMSUtilService.calculatePremiumAmount(tempSSTAmount, "S")).format(this.premiumFormat)).value() : 0;
        //let _totalPremium = parseFloat(""+numeral(discountedPrem).value()) + parseFloat(""+numeral(this.riskObj.gstAmount).value());
        let _totalPremium = parseFloat("" + numeral(discountedPrem).value()) + parseFloat("" + numeral(this.riskObj.gstAmount).value()) + parseFloat("" + numeral(this.riskObj.sstAmount).value());
        //End
        this.riskObj.totalPremium = numeral(numeral(_totalPremium).format(this.premiumFormat)).value();

        this.onPremiumChange.emit(this.riskObj.totalPremium);

        this.validateSumInsured();
    }

    validateSumInsured() {
        if (this.riskObj.RIRetentionCode && this.riskObj.isRIOverWrittenByUW == 'N') {

            this._bmsUtilService.getTotalGrossCapacity(this.riskObj.RIRetentionCode).subscribe((data) => this.compareSIWithTotGrossCap(data));
			/*let _totalGrossCapacity = this._bmsUtilService.getNetRetentionAmountDetails(this.riskObj.RIRetentionCode);
			_totalGrossCapacity = (!_totalGrossCapacity) ? 0 : parseFloat(""+_totalGrossCapacity);
			this.riskObj.totalGrossCapacity = _totalGrossCapacity;
			let _limitAggregate = parseFloat(""+this.riskObj.limitAggregate);
			
			if( _totalGrossCapacity > 0 && _limitAggregate > _totalGrossCapacity && (this.riskObj.RIMethod == null || this.riskObj.RIMethod == "" || parseFloat(""+this.riskObj.RIMethod) != 8) ){
				this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Limit of Guarantee in the Aggregate is greater than Total Gross Capacity: "+_totalGrossCapacity+",  RI is Required." , 10000));
				
				this.riskObj.RIRequired = "Yes";
				this.riskObj.RIMethod = "8";
			} 
			else if(_limitAggregate <= _totalGrossCapacity){
				this.riskObj.RIRequired = "No";
				this.riskObj.RIMethod = this.riskObj.RIMethodSys;
			}*/

        }
        else
            this.setRIMethodEditableFlag();
    }

    compareSIWithTotGrossCap(totGrossCap) {
        let _totalGrossCapacity = (!totGrossCap) ? 0 : parseFloat("" + totGrossCap);
        this.riskObj.totalGrossCapacity = _totalGrossCapacity;
        let _limitAggregate = parseFloat("" + this.riskObj.limitAggregate);

        if (_totalGrossCapacity > 0 && _limitAggregate > _totalGrossCapacity && (this.riskObj.RIMethod == null || this.riskObj.RIMethod == "" || parseFloat("" + this.riskObj.RIMethod) != 8)) {
            this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Limit of Guarantee in the Aggregate is greater than Total Gross Capacity: " + _totalGrossCapacity + ",  RI is Required.", 10000));

            this.riskObj.RIRequired = "Yes";
            this.riskObj.RIMethod = "8";
        }
        else if (_limitAggregate <= _totalGrossCapacity) {
            this.riskObj.RIRequired = "No";
            this.riskObj.RIMethod = this.riskObj.RIMethodSys;
        }
        this._riService.setRI().subscribe();
        this.setRIMethodEditableFlag();
    }

    getTotalByProperty(prop, ary, format: string) {
        let total = 0;
        for (let eachItem of ary) {
            if (eachItem[prop] != null && eachItem[prop] != "")
                total = total + parseFloat(numeral(eachItem[prop]).value());
        }
        if (format != null)
            return numeral(numeral(total).format(format)).value();
        else
            return total;
    }

    onExcessTypeChange(ev) {
        this.riskObj.excessType = ev.value;
        this.setExcessValidationFiels();
    }

    setExcessValidationFiels() {
        if (this.riskObj.excessType && this.riskObj.excessType != '') {
            for (let _etItem of this.lovDropDownService.lovDataList.excessType) {
                if (_etItem.VALUE == this.riskObj.excessType) {
                    this.isExcessPercentMandatory = (_etItem.ACTN02 == 'Y') ? 'Y' : 'N';
                    this.isExcessAmountMandatory = (_etItem.ACTN01 == 'Y') ? 'Y' : 'N';
                    BMSConstants.setExcessTypeRecord(this.riskObj.riskType + this.riskObj.excessType, _etItem);
                }
            }
        }
        else {
            this.isExcessPercentMandatory = 'N';
            this.isExcessAmountMandatory = 'N';
            this.riskObj.excessPercentage = 0;
            this.riskObj.excessAmount = 0;
        }
    }

    callbackForExcessTypesLoad(scopeObject) {
        if (scopeObject.excessType && scopeObject.excessType != '') {
            scopeObject.setExcessValidationFiels();
        }
    }

    setReferredFromUI(riskClass) {
        this.riskObj.riskClassification = riskClass;
        this.emitRiskClass(this);
    }

    emitRiskClass(comp) {
        comp.onRiskClsChange.emit("");
    }

    handleRiskClassification(comp) {
        this.riskClassificationService.setRiskClassification(comp.riskObj.riskNumber, "N", "", "").subscribe();
		/*if(this.riskObj.symRiskClassification == "Declined")
			this.riskObj.riskClassification = "Declined";
		else if(this.riskObj.symRiskClassification == "Referred" || this.riskObj.riRiskClassification == "Referred")
			this.riskObj.riskClassification = "Referred";
		else
			this.riskObj.riskClassification = "Standard";
		this.setRiskClassification();
		this.emitRiskClass(this);*/
    }

    setRiskClassification() {
        if (this.riskObj.symRiskClassification != null && this.riskObj.symRiskClassification != "" && (this.riskObj.symRiskClassification == "Referred" || this.riskObj.symRiskClassification == "Declined")) {
            this.riskObj.riskClassificationReason = "System marked as " + this.riskObj.symRiskClassification;
        }
        else if (this.riskObj.riRiskClassification != null && this.riskObj.riRiskClassification != "" && this.riskObj.riRiskClassification == "Referred") {
            this.riskObj.riskClassificationReason = "System marked as " + this.riskObj.riRiskClassification;
        }
        else {
            if (this.riskObj.riskClassificationReason != null && this.riskObj.riskClassificationReason != "" && (this.riskObj.riskClassificationReason != "System marked as Standard" && this.riskObj.riskClassificationReason.indexOf("System marked as ") != -1)) {
                this.riskObj.riskClassificationReason = "";
            }
        }
    }

    onBusinessCodeChange(ev) {
        this.riskObj.businessCode = ev.value;
        this.riskObj.businessCodeDesc = ev.record.DESCRIPTION; //ev.record.DESCRIPTION.slice(0, 40);
        this.riskObj.occRiskClassification = ev.record.REFERREDRISK;

		/*if(!ev.record.REFERREDRISK || ev.record.REFERREDRISK == 'N'){
			this.riskObj.symRiskClassification = "Standard";
		}
		else if(ev.record.REFERREDRISK && ev.record.REFERREDRISK == 'Y'){
			this.riskObj.symRiskClassification = "Referred";
		}
		else if(ev.record.REFERREDRISK && ev.record.REFERREDRISK == 'D'){
			this.riskObj.symRiskClassification = "Declined";
		}*/

        this.handleRiskClassification(this);

        if (this.riskObj.riskCoverageDetails && this.riskObj.riskCoverageDetails.riskCoverage && this.riskObj.riskCoverageDetails.riskCoverage.length > 0) {
            for (let _item of this.riskObj.riskCoverageDetails.riskCoverage) {
                _item.occupationCode = this.riskObj.businessCode;
            }
        }
    }

	/*resetSurvey(value){
        if("Y" == value){
            this.riskObj.survey = new Survey();
        }
        else{
            this.riskObj.survey = null;
        }
    }
	
	resetFI(value){
		if(value == "Y")
			this.riskObj.financialInterest = new FinancialInterest();
		else
			this.riskObj.financialInterest = null;
	}*/

    setRIMethod(val) {

        this.riskObj.RIMethod = (val == "Yes") ? "8" : this.riskObj.RIMethodSys;

        if (this.isUnderWriter == "Y" || val == "Yes")
            this.riskObj.isRIOverWrittenByUW = "Y";
        else if (val == "No") {
            this.riskObj.isRIOverWrittenByUW = "N";
            this.validateSumInsured();
        }
        this._riService.setRI().subscribe();
    }

    validateTextInput(ev) {
        let eVal = ev.target.value;
        ev.target.value = eVal.replace(/\s\s+/g, ' ');
    }

    addXT(coverItem) {
        var dialogData = new ExtraTextDialogData("ExtraTextDialogComponent", "app/bms/components/proposal/newbusinessrisks/dialogs/extratext.dialog.module", "ExtraTextDialogModule", "Extra Text", "ExtraText", "fa fa-comment", coverItem, this.extraTextCallBack);
        this.openExtraTextCommentsDialog(dialogData);
    }

    public openExtraTextCommentsDialog(dialogData: ExtraTextDialogData, response?: any) {
        let lookup = new ModalInput();
        lookup.component = [dialogData.component, dialogData.moduleAbsPath, dialogData.moduleName];
        lookup.datainput = {
            dialogName: dialogData.dialogName,
            areCommentsMandatory: false,
            coverageItem: dialogData.coverageItem
        };
        lookup.outputCallback = dialogData.callBackHandler;
        lookup.parentCompPRMS = {
            comp: this,
            response: response
        };
        lookup.heading = dialogData.dialogTitle;
        lookup.icon = dialogData.icon;
        lookup.containerRef = this.contentArea;
        this.dcl.openLookup(lookup);
    }

    private extraTextCallBack(data, prms) {
        if (data.isDialogCancelled) {
            return;
        } else if (!data.isDialogCancelled && data.coverageItem && data.coverageItem.extraText) {
        }
    }

    setRIMethodEditableFlag() {
        let _limitAggregate = parseFloat("" + this.riskObj.limitAggregate);
        let _totalGrossCapacity = parseFloat("" + this.riskObj.totalGrossCapacity);
        if (_totalGrossCapacity > 0 && _limitAggregate > _totalGrossCapacity && this.isUnderWriter == "N") {
            this.isRIMethodEditable = "N";
        }
        else {
            this.isRIMethodEditable = "Y";
        }
    }

    emitFlagChange() {
        this.onRtngFlgChange.emit("");
    }

	/*validateUnits(){
		if(this.riskObj.units < 0 || this.riskObj.units > 1){
			this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Units should be 0 or 1" , 5000));
		} else this.setPAExtensionAmount();
	}

	setPAExtensionAmount(){
		let _units  = (this.riskObj.units == null) ? 0 : parseInt(""+this.riskObj.units);
		let _totalNoEmps=parseInt(""+this.riskObj.totalNoEmps);
		let _perCapital:any  = this.riskObj.perCapital;		
		_perCapital = (_perCapital == null || _perCapital == "") ? 0 : _perCapital;
		let _paExtAmount =0;
		if(_totalNoEmps > 0 && _perCapital > 0) {
			_paExtAmount = _totalNoEmps * _perCapital;
			if(_units > 0)
				_paExtAmount = _units * _paExtAmount;
		}
		
		if(this.riskObj.totalBasePremium > 0)
			_paExtAmount = _paExtAmount + this.riskObj.totalBasePremium;
		this.riskObj.paExtAmount = _paExtAmount;
	}*/

}
