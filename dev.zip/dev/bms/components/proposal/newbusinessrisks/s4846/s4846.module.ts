import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FIModule } from '../../../../../common/components/financialinterest/fi.module';
import { BasicUIModule } from '../../../../../common/components/utility/basicui.module';
import { PaginationModule } from '../../../../../common/components/utility/pagination/pagination.module';
import { MultiSelectModule } from '../../../../../common/components/utility/selectbox/multi-selectbox.module';
import { LovModule } from "../../../../../common/services/lovdropdown/lov.module";
import { AccRegisterModule } from '../uimodules/accregister.module';
import { ClausesModule } from '../uimodules/clauses.module';
import { GSTModule } from '../uimodules/gst.module';
import { PerilModule } from '../uimodules/perils.module';
import { RateableClauseModule } from '../uimodules/rateableclause.module';
import { RelatedCaseModule } from '../uimodules/relatedcase.module';
import { SurveyModule } from '../uimodules/survey.module';
import { WarrantyClausesModule } from '../uimodules/warrantyclauses.module';
import { S4846Component } from './s4846.component';

@NgModule({
    imports: [
        CommonModule, FormsModule, ReactiveFormsModule,
        BasicUIModule, FIModule, LovModule, MultiSelectModule,
        SurveyModule, RateableClauseModule,
        ClausesModule, RelatedCaseModule, GSTModule, PaginationModule, AccRegisterModule, PerilModule, WarrantyClausesModule],
    declarations: [S4846Component],
    exports: [S4846Component]
})
export class S4846Module { }