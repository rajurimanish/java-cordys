import { Clause } from '../../appobjects/clause';
import { RateableClassIndicator } from '../../appobjects/RateableClassIndicator';
import { RateableClassCode } from '../../appobjects/RateableClassCode';
import { FinancialInterest } from '../../../../../../common/components/financialinterest/appobjects/financialInterest';
import { GSTDetails } from '../../appobjects/gstDetails';
import { Survey } from '../../appobjects/survey';
import { FireRelatedCases } from '../../appobjects/relatedCase';
import { AppUtil } from '../../../../../../common/components/utility/apputil/app.util';
import { NBRisk } from '../../../appobjects/nbrisk';
import { PostedPrem } from '../../../proposalheader/appobjects/postedprem';
import { AccRegister } from '../../appobjects/accregister'; // AccRegister code
import { S4846Validator } from '../../../validation/s4846.validator';
import { RiskHelper } from '../../../appobjects/riskhelper';
import { ReferredReason } from '../../../proposalheader/appobjects/referredreason';
import { Peril } from '../../appobjects/peril';
import { WarrantyClassCode } from '../../appobjects/warrantyClassCodes';

export class S4846 extends RiskHelper implements NBRisk {
    public sequenceNumber: string;
    public effectiveDate: string;
    public dateOfAttachment: string;
    public contractNumber: string;
    public contractType: string;
    public riskNumber: string;
    public riskType: string;
    public ratingFlag: string = "A";
    public situation1: string;
    public situation2: string;
    public situationLine1: string;
    public situationLine2: string;
    public situationLine3: string;
    public situationLine4: string;
    public situationLine5: string;
    public situationLine6: string;
    public situationLine7: string;
    public situationLine8: string;
    public postCode: string;
    public city: string;
    public cityName: string;
    public accumulationRegister: string;
    public locality: string;
    public construction: string;
    public constructionName: string;
    public townClass: string = "1";
    public RIRetentionCode: string = "DOM";
    public rateBasis: string = "T";
    public rateBasisName: string;
    public yearOfConstruction: string;
    public storeys: number;
    public surveyNumber: string;
    public surveyDate: string;
    public ReSurveyDate: string;
    public clauses: Clause;
    public rateableClassCode: RateableClassCode;
    public riskCoverageDetails: RiskCoverageDetails;
    public financialInterest: FinancialInterest;
    public GSTDetails: GSTDetails;
    public survey: Survey;
    public relatedCases: FireRelatedCases;
    public originalTotalPremium: number = 0;
    public increasedTPLimitToSI: number = 0;
    public increasedTPLimitToAmount: number = 0;
    public postedPremium: number = 0;
    public basePostedPremiumAdj: number = 0;
    public discountedPremium: number = 0;
    public rebate: number = 0;
    public rebateAmount: number = 0;
    public GST: number = 0;//6; //SAF MYS-2018-0629
    public gstAmount: number = 0;
    public basicPremium: number = 0;
    public totalBasicPremium: number = 0;
    public totalPremium: number = 0;
    public minimumPremium: number = 0;
    public totalSI: number = 0;
    public capitalSumInsured: number = 0;
    public relatedSumInsured: number = 0;
    public totalGrossCapacity: number = 0;
    public terminationDate: string;
    public RIMethod: string = "0";
    public RIMethodSys: string = "0";
    public RIRequired: string = "No";
    public isRIOverWrittenByUW: string = "N";
    public riskClassification: string = "Standard";
    public riskClassificationReason: string = "";
    public symRiskClassification: string = "";
    public riRiskClassification: string = "Standard";
    public isSurveyNeeded: string = "N";
    public addRelatedCases: string = "N";
    public hasClaimExperience: string = "N";
    public FI: string = "N";
    public identity: string = "";
    public identityFiller: string = "";
    public isPOIConsidered: string = "N";
    public priority: string;
    public postedPremDetails: PostedPrem;
    public accRegister: AccRegister; // AccRegister code

    public childRiskPath: string;
    public childRiskIdentity: string;
    public riskClassificationReasons: ReferredReason;

    public SST: number = 0; //SST Code
    public sstAmount: number = 0;//SST Code 
    public SSTLiveDate: string;//SST Code
    public GSTLiveDate: string;//SST Code
    public isGSTApplicable: boolean = true;//SST Code
    public perils: Peril; // SAF MYS-2018-1249 start
    public perilsRate: number = 0;
    public warrantyClassCodes: WarrantyClassCode;
    public wcRate: number = 0;// End
    constructor() {
        super();
        this.clauses = new Clause();
        this.rateableClassCode = new RateableClassCode();
        this.riskCoverageDetails = new RiskCoverageDetails();
        this.financialInterest = new FinancialInterest();
        this.GSTDetails = new GSTDetails();
        this.relatedCases = new FireRelatedCases();
        this.accRegister = new AccRegister(); // AccRegister code		
        this.riskClassificationReasons = new ReferredReason();
        this.perils = new Peril();// SAF MYS-2018-1249
        this.warrantyClassCodes = new WarrantyClassCode();// SAF MYS-2018-1249
    }

    public getInstance(valObj: S4846) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
            this.riskCoverageDetails = new RiskCoverageDetails().getInstance(valObj.riskCoverageDetails);
            this.clauses = new Clause().getInstance(valObj.clauses);
            this.rateableClassCode = new RateableClassCode().getInstance(valObj.rateableClassCode);
            this.GSTDetails = new GSTDetails().getInstance(valObj.GSTDetails);
            if (valObj.FI == "Y") {
                this.financialInterest = new FinancialInterest().getInstance(valObj.financialInterest);
            }
            if (valObj.isSurveyNeeded == "Y") {
                this.survey = new Survey().getInstance(valObj.survey);
            }
            if (valObj.addRelatedCases == "Y") {
                this.relatedCases = new FireRelatedCases().getInstance(valObj.relatedCases);
            }
            this.accRegister = new AccRegister().getInstance(valObj.accRegister); // AccRegister code
            this.riskClassificationReasons.refresh(valObj.riskClassificationReasons);
            this.perils = new Peril().getInstance(valObj.perils);// SAF MYS-2018-1249
            this.warrantyClassCodes = new WarrantyClassCode().getInstance(valObj.warrantyClassCodes);// SAF MYS-2018-1249
            if (valObj.isGSTApplicable != undefined && JSON.stringify(valObj.isGSTApplicable) != JSON.stringify("") && typeof (valObj.isGSTApplicable) == "string") {
                this.isGSTApplicable = Boolean(JSON.parse(valObj.isGSTApplicable));
            }		
        }
        return this;
    }

    public getNewInstanceByCriteria(criteria: any) {
        return this;
    }

    public getValidator() {
        return new S4846Validator(this);
    }

    // SAF MYS-2018-1249 start
    public refershRiskObj(valObj: S4846) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
            this.riskCoverageDetails = new RiskCoverageDetails().getInstance(valObj.riskCoverageDetails);
            this.clauses = new Clause().getInstance(valObj.clauses);
            this.rateableClassCode = new RateableClassCode().getInstance(valObj.rateableClassCode);
            this.GSTDetails = new GSTDetails().getInstance(valObj.GSTDetails);
            if (valObj.FI == "Y") {
                this.financialInterest = new FinancialInterest().getInstance(valObj.financialInterest);
            }
            if (valObj.isSurveyNeeded == "Y") {
                this.survey = new Survey().getInstance(valObj.survey);
            }
            if (valObj.addRelatedCases == "Y") {
                this.relatedCases = new FireRelatedCases().getInstance(valObj.relatedCases);
            }
            this.accRegister = new AccRegister().getInstance(valObj.accRegister); // AccRegister code
            this.riskClassificationReasons.refresh(valObj.riskClassificationReasons);
            this.perils = new Peril().getInstance(valObj.perils);// SAF MYS-2018-1249
            this.warrantyClassCodes = new WarrantyClassCode().getInstance(valObj.warrantyClassCodes);// SAF MYS-2018-1249
            if (valObj.isGSTApplicable != undefined && JSON.stringify(valObj.isGSTApplicable) != JSON.stringify("") && typeof (valObj.isGSTApplicable) == "string") {
                this.isGSTApplicable = Boolean(JSON.parse(valObj.isGSTApplicable));
            }		
        }
        return this;
    } //End
}


export class RiskCoverageDetails {

    public riskCoverage: RiskCoverage[] = [];

    public getInstance(valObj: RiskCoverageDetails) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
            new AppUtil().handleArray(this, valObj, "riskCoverage");
        }
        return this;
    }

    // SAF MYS-2018-1249 --start
    public refreshRiskCoverageDetails(valObj: RiskCoverageDetails) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
            new AppUtil().handleArray(this, valObj, "riskCoverage");
            valObj.riskCoverage.forEach(coverItem => {
                let item: RiskCoverage = new RiskCoverage;
                coverItem = item.refreshRiskCoverage(coverItem);
            });
        }
        return this;
    } //End
}

export class RiskCoverage {
    public seqNumber: number;
    public PIAMCode: string;
    public PIAMCodeDesc: string;
    public sumInsured: number;
    public rate: number;
    public extRate: number;
    public totalRate: number;
    public premium: number;
    public premiumClass: string;
    public rateableClassCodes: RateableClassCode;
    public extraText: string = "";
    public etPostingStatus = "N";
    // public xtComments:XTComments;
    public perilClassCodes: Peril;// SAF MYS-2018-1249
    public wcClassCodes: WarrantyClassCode;// SAF MYS-2018-1249

    constructor() {
        this.rateableClassCodes = new RateableClassCode();
        // this.xtComments = new XTComments();
        this.perilClassCodes = new Peril();// SAF MYS-2018-1249
        this.wcClassCodes = new WarrantyClassCode();// SAF MYS-2018-1249
    }

    public getInstance(valObj: RiskCoverage) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
            this.rateableClassCodes = new RateableClassCode().getInstance(valObj.rateableClassCodes);
            // //this.xtComments = new XTComments().getInstance(valObj.xtComments);
            this.perilClassCodes = new Peril().getInstance(valObj.perilClassCodes);// SAF MYS-2018-1249
            this.wcClassCodes = new WarrantyClassCode().getInstance(valObj.wcClassCodes);// SAF MYS-2018-1249
        }
        return this;
    }

    // SAF MYS-2018-1249 --start
    public refreshRiskCoverage(valObj: RiskCoverage) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
            valObj.rateableClassCodes = new RateableClassCode().refreshRateableClassCode(valObj.rateableClassCodes);
            valObj.perilClassCodes = new Peril().refreshPerils(valObj.perilClassCodes);
            valObj.wcClassCodes = new WarrantyClassCode().refreshWarrantyClassCodes(valObj.wcClassCodes);
        }
        return this;
    }//End
}
