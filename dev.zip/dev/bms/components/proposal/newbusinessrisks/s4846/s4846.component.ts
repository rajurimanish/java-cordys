/* 
 *
 * Change History:		
 * 
 * No      Date				Description												Changed By
 * ====    ==========		===========												==========
 * 
 * E1003   19/12/2018		MYS-2017-1096 : New default clauses for MIS channel			SRE1
 * 
 * SR001   11/01/2019		MYS-2018-0211 : To enhancement the filtering criteria		VSR
 * 							for Fire Accum Code & Prompt message
 * 
 * SR002   18/01/2019		MYS-2018-0682 : HD Log: POI Date not passed correctly to	VSR
 * 							check as Referred Risk for Fire products in BMS
 * 
 * YPK001 23/09/2019       MYS-2019-0675 Document Validation for Co-outwards            PKU1
 *                         case before sending to PPHO		
 */

import { Component, ElementRef, EventEmitter, OnInit, ViewChild, ViewContainerRef } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CaseInfo } from '../../../../../common/components/appobjects/caseinfo';
import { ClientDetails } from '../../../../../common/components/client/appobjects/client';
import { FinancialInterest } from '../../../../../common/components/financialinterest/appobjects/financialInterest';
import { AlertMessage } from '../../../../../common/components/utility/alertmessage/alertmessages.model';
import { AlertMessagesService } from '../../../../../common/components/utility/alertmessage/alertmessages.service';
import { AppUtil } from '../../../../../common/components/utility/apputil/app.util';
import { CordysSoapWService } from "../../../../../common/components/utility/cordys-soap-ws";
import { ModalInput } from "../../../../../common/components/utility/modal/modal";
import { ProgressBarComponent } from '../../../../../common/components/utility/progressbar/progressbar.component';
import { Filter, GetLOVData, SearchAdvancedConfig } from '../../../../../common/components/utility/search/search.requests';
import { ApplicationUtilService } from "../../../../../common/services/application.util.service";
import { CustomDCLService } from '../../../../../common/services/customdcl.service';
import { LOVDropDownService, LOV_Field, SearchFilter } from "../../../../../common/services/lovdropdown/lovdropdown.service";
import { BMSUtilService } from "../../../../services/bms.util.service";
import { BMSAppObjService } from '../../../../services/bmsappobj.service';
import { BMSConstants } from '../../../common/constants/bms_constants';
import { ProposalHeader } from '../../proposalheader/appobjects/proposalheader';
import { AccRegister } from '../appobjects/accregister';
import { Clause } from "../appobjects/clause";
import { Peril, PerilDetail } from '../appobjects/peril';
import { RateableClassCode, RateableClassCodeDetail } from '../appobjects/rateableClassCode';
import { FireRelatedCases } from '../appobjects/relatedCase';
import { Survey } from '../appobjects/survey';
import { WarrantyClassCode } from '../appobjects/warrantyClassCodes';
import { ExtraTextDialogData } from "../dialogs/extratext.dialog.data";
import { RIService } from '../services/ri.service';
import { RiskClassificationService } from "../services/riskcls.service"; // added code for AccRegister
import { ClausesComponent } from "../uimodules/clauses.component";
import { RiskCoverage, S4846 } from './appobjects/s4846';
import { RateableClausesComponent } from '../uimodules/rateableclause.component';
declare var jQuery: any;
declare var moment: any;
declare var numeral: any;

@Component({
    selector: "s4846-component",
    templateUrl: "app/bms/components/proposal/newbusinessrisks/s4846/s4846.template.html",
    inputs: ["riskObj", "clientDetails", "headerInfo", "caseInfo"],
    outputs: ["onPremiumChange", "onRiskClsChange", "onRtngFlgChange"],
    providers: [RiskClassificationService]// added code for AccRegister
})
export class S4846Component implements OnInit {
    private el: HTMLElement;
    private isCoverInfoCollapsed: boolean = false;
    private clCBIInfoCollapse: boolean = true;
    private relatedCollapse: boolean = false;
    private surInfoCollapse: boolean = false;
    private accRegisterInfoCollapse: boolean = false;
    public riskObj: S4846;
    public AccRegList: AccumulationRegister[];
    public clientDetails: ClientDetails;
    public headerInfo: ProposalHeader;
    public caseInfo: CaseInfo;
    public clientId: string = "";
    public siFormat: string = "0,00";
    public premiumFormat: string = "0,00.00";
    public rateFormat: string = "0.00000";
    public percentFormat: string = "0.00";
    public multiSelectListern: any = { value: "" }
    public disableRate = 'N';
    public accRegCtrl: any;
    private basicRateCoverItem: string;
    private tpLimitClauseCodesRespData: any;

    public position = 1;
    public sizeObj = { length: 0, orglength: 0 };
    public contentSizeObs: any;
    public itemPerPage = 5//4;
    public maxPageCount = 10;
    private piamCodes = [];
    private isUnderWriter = "N";
    private isRIMethodEditable = "Y";
    public emailType: string;
    public tempSysReferred: boolean;
    public tempAccuSysReferred: boolean;
    @ViewChild('xtModal', { read: ViewContainerRef }) contentArea: ViewContainerRef;
    @ViewChild(ClausesComponent) private clausesComp: ClausesComponent;
    @ViewChild(RateableClausesComponent) rateClauseComp: RateableClausesComponent;
    onPremiumChange = new EventEmitter<any>();
    onRiskClsChange = new EventEmitter<any>();
    onRtngFlgChange = new EventEmitter<any>();
    public _defaultProductClauses = new Clause(); // E1003
    private productclauseCodes: string = ""; // E1003

    constructor(public dcl: CustomDCLService, private lovDropDownService: LOVDropDownService, private _soapService: CordysSoapWService, public _alertMsgService: AlertMessagesService, el: ElementRef, private _appUtilService: ApplicationUtilService, private _bmsUtilService: BMSUtilService, public riskClassificationService: RiskClassificationService, private _appObjService: BMSAppObjService, private _riService: RIService, private _activatedRoute: ActivatedRoute) {
        this.el = el.nativeElement;
    }

    ngOnInit() {
        this.populateLOVs();
        this.setClientInfo();
        this.disableRate = (this.riskObj.ratingFlag == 'M' || this.riskObj.rateBasis == 'G' || this.riskObj.rateBasis == 'S' || this.riskObj.rateBasis == 'L') ? 'N' : 'Y';

        this.triggerMulSelListern();

        this._appUtilService.isUnderWriterUser().subscribe((data) => {
            this.isUnderWriter = data;
            this.setRIMethodEditableFlag();
        });

        // AccRegister code
        if (this.riskObj.accRegister == undefined) {
            this.riskObj.accRegister = new AccRegister();
        } else {
            this.tempSysReferred = this.riskObj.accRegister.isSystemReferred;
            this.tempAccuSysReferred = this.riskObj.accRegister.isAccuSystemReferredFlag;
        }
        //SST Code
        if (["MyTasks", "MyDrafts"].indexOf(this._activatedRoute.snapshot.params['component']) >= 0 || Object.keys(this._activatedRoute.snapshot.params).length == 0) {
            let respObj = this._bmsUtilService.getTAXDetails();
            if (respObj != undefined && respObj != "") {
                this.headerInfo.SSTTaxRate = Number(respObj[0].old.ITEMPF.GST);
                this.headerInfo.GSTTaxRate = Number(respObj[1].old.ITEMPF.GST);

                this.riskObj.SST = Number(this.headerInfo.SSTTaxRate);
                this.riskObj.GST = Number(this.headerInfo.GSTTaxRate);
            }

            this.headerInfo = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo;
            this.riskObj.SSTLiveDate = (this.riskObj.SSTLiveDate == undefined) ? this.headerInfo.SSTLiveDate : this.riskObj.SSTLiveDate;
            if (this.riskObj.SSTLiveDate == undefined || this.riskObj.SSTLiveDate == "") {
                let tempRespObj = this._bmsUtilService.getLiveDate();
                this.riskObj.GSTLiveDate = tempRespObj[0].old.ITEMPF.LIVEDATE;
                this.riskObj.SSTLiveDate = tempRespObj[1].old.ITEMPF.LIVEDATE;
                if (this.headerInfo.SSTLiveDate == undefined || this.headerInfo.SSTLiveDate == "") {
                    this.headerInfo.SSTLiveDate = this.riskObj.SSTLiveDate;
                }
                if (this.headerInfo.GSTLiveDate == undefined || this.headerInfo.GSTLiveDate == "") {
                    this.headerInfo.GSTLiveDate = this.riskObj.GSTLiveDate;
                }
            }
            if (moment(this.headerInfo.effectiveDate, "YYYY-MM-DD").format("YYYYMMDD") >= moment(this.riskObj.SSTLiveDate, "YYYY-MM-DD").format("YYYYMMDD")) {
                this.riskObj.isGSTApplicable = false;
            } else {
                this.riskObj.isGSTApplicable = true;
            }
        }
        //End

        // SAF MYS-2018-1249 start
        for (let pItem of this.riskObj.perils.peril) {
            if (pItem.coverItems == undefined) {
                pItem.coverItems = [];
            }
        }
        //End
    }
    //START YPK001
    ngAfterViewInit() {
        let rIndex = 0;
        if ((this.headerInfo.CoInsurance == 'Y' && this.riskObj.riskNumber == '1') && (["MyTasks", "MyDrafts"].indexOf(this._activatedRoute.snapshot.params['component']) >= 0 || Object.keys(this._activatedRoute.snapshot.params).length == 0)) {
            if (this.headerInfo.coInsuranceDetails.coInsurance.length == 1) {
                if (!(this.headerInfo.coInsuranceDetails.coInsurance[0].coInsuranceindicator == 'L' && this.headerInfo.coInsuranceDetails.coInsurance[0].sharePercentage == '100')) {
                    rIndex = this.riskObj.clauses.clause.map(function (item) { return item.clauseCode; }).indexOf("COIN");
                    if (rIndex == -1)
                        this.setClauses(["COIN"], false);
                }
            }
            else {
                rIndex = this.riskObj.clauses.clause.map(function (item) { return item.clauseCode; }).indexOf("COIN");
                if (rIndex == -1)
                    this.setClauses(["COIN"], false);
            }
        }
    }
    //END YPK001

    ngAfterViewChecked() {
        this.setHoverForAllCover();
    }
    // Added for new default class setup E1003
    getProductClauseCodes(key: string) {
        let prom = this._soapService.callCordysSoapService("GetMsigPropertiesObject", "http://schemas.cordys.com/msig/masterdata/1.0", { "KEY": key }, null, null, false, null);
        prom.success((resp) => {
            this.productclauseCodes = resp.tuple.old.MSIG_PROPERTIES.VALUE.toString();
        });
        prom.error((error) => {
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error while fetching Default Clauses.", -1));
        });
    }
    // End E1003
    populateLOVs() {
        // Added for new default class setup E1003
        if (this.headerInfo.bancaChannel == 'FI' && (this.caseInfo.status == 'Draft' || Object.keys(this._activatedRoute.snapshot.params).length == 0)) {
            if (this._defaultProductClauses.clause.length == 0 && this.riskObj.clauses.clause.length == 0) {
                if (["HHO", "FHO"].indexOf(this.headerInfo.contractType) >= 0) {
                    this.getProductClauseCodes("hhoOrfhoDefaultClauses");
                    if (this.productclauseCodes != null && this.productclauseCodes != "") {
                        this.getNewDefaultClauses(this.productclauseCodes);
                    }
                }
            }
        }
        // End E1003
        let lovRefFields = ["piamcode", "construction", "rateBasis", "constructionYearList", "premiumclass", "riCode", "tpLimit"];
        this.lovDropDownService.createLOVDataList(lovRefFields);

        let riTypeFilterDetails = [new SearchFilter("DESCITEM", this.riskObj.riskType, "STARTSWITH", "AND")];
        let riTypeSearchFilterNodes = this.lovDropDownService.createFilter(riTypeFilterDetails);

        let polEndDate = ApplicationUtilService.getFormattedDate(this.headerInfo.endDate, "YYYY-MM-DD", "YYYYMMDD");
        let piamCodesFilterDetails = [new SearchFilter("A.DESCITEM", this.riskObj.riskType, "STARTSWITH", "AND"),
        new SearchFilter("A.ITMFRM", polEndDate, "LTEQ", "AND"),
        new SearchFilter("A.ITMTO", polEndDate, "GTEQ", "AND")];
        let piamCodesFilterNodes = this.lovDropDownService.createFilter(piamCodesFilterDetails);

        let tpLimitFilterDetails = [new SearchFilter("B.DESCITEM", this.riskObj.riskType, "STARTSWITH", "AND"),
        new SearchFilter("A.ITMFRM", polEndDate, "LTEQ", "AND"),
        new SearchFilter("A.ITMTO", polEndDate, "GTEQ", "AND")];
        let tpLimitFilterNodes = this.lovDropDownService.createFilter(tpLimitFilterDetails);

        let lovFields = [
            new LOV_Field("ALL", "FIRE", "NEW BUSINESS", "ALL", "ALL", "ALL", "PIAM Codes List", "LOV", piamCodesFilterNodes, "T9115", "piamCodesList", "callbackForPIAMCodesList"),
            new LOV_Field("ALL", "FIRE", "CLAIMS", "ALL", "NEW", "CLAIMS_FIRE", "Construction Code", "LOV", [], "DESCPF", "construction", null),
            new LOV_Field("ALL", "FIRE", "NEW BUSINESS", "ALL", "NEW", "FIRE_IDC", "RateBasis", "LOV", [], "DESCPF", "rateBasis", "callbackForRateBasis"),
            new LOV_Field("ALL", "FIRE", "NEW BUSINESS", "ALL", "NEW", "FIRE", "YearOfConst", "LOV", [], "DESCPF", "constructionYearList", null),
            new LOV_Field("ALL", "MOTOR", "NEW BUSINESS", "ALL", "NEW", "PRIVATE_MOTOR", "RI Retention Code", "LOV", [], "DESCPF", "riCode", null),
            new LOV_Field("ALL", "FIRE", "NEW BUSINESS", "ALL", "NEW", "HHO", "TP Limit Details", "LOV", tpLimitFilterNodes, "T7210", "tpLimit", null)];

        // new LOV_Field("ALL", "FIRE", "NEW BUSINESS", "ALL", "NEW", "HHO", "TP Limit", "LOV", [], "T7210", "tpLimit",null)	
        //new LOV_Field("ALL", "FIRE", "NEW BUSINESS", "ALL", "NEW", "FIRE_IDC", "PremiumClass", "LOV", riTypeSearchFilterNodes, "T4688", "premiumclass",null),	
        //new LOV_Field("ALL", "FIRE", "NEW BUSINESS", "ALL", "NEW", "FIRE_IDC", "PremiumClass", "LOV", riTypeSearchFilterNodes, "DESCPF", "premiumclass",null),
        // new LOV_Field("ALL", "ALL", "ALL", "ALL", "ALL", "ALL", "PIAM Code", "LOOKUP", [] , "DESCPF", "piamcode",null),
        if (this.riskObj.accumulationRegister != null && this.riskObj.accumulationRegister != "") {
            this.setAccumulationRegister();
        }
        this.lovDropDownService.util_populateLOV(lovFields, this);
        // this.setBasicRate();
    }

    setClientInfo() {
        this.clientId = this.headerInfo.insuredNumber;
    }

    callbackForPIAMCodesList(scopeObject) {
        for (let _rec of scopeObject.lovDropDownService.lovDataList.piamCodesList) {
            let hasPiamCode = scopeObject.piamCodes.some(_item => _item['VALUE'] === _rec.VALUE);
            if (!hasPiamCode) {
                scopeObject.piamCodes.push(_rec);
            }
        }

        if (scopeObject.piamCodes.length > 0) {
            scopeObject.sortArray(scopeObject.piamCodes, 'VALUE');
        }

    }

    callbackForRateBasis(scopeObject) {
        if (scopeObject.riskObj.rateBasis) {
            for (let rateBasisItem of scopeObject.lovDropDownService.lovDataList.rateBasis) {
                if (rateBasisItem.VALUE != scopeObject.riskObj.rateBasis) {
                    scopeObject.riskObj.rateBasisName = rateBasisItem.DESCRIPTION;
                    break;
                }
            }
        }
    }


    addRiskCover() {
        let _isValid: boolean = true;
        if (!this.riskObj.townClass) {
            _isValid = false;
            this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Town Class cannot be blank", 2000));
        }
        if (!this.riskObj.construction) {
            _isValid = false;
            this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Construction cannot be blank", 2000));
        }
        if (_isValid) {
            this.disableRate = (this.riskObj.ratingFlag == 'M' || this.riskObj.rateBasis == 'G' || this.riskObj.rateBasis == 'S' || this.riskObj.rateBasis == 'L') ? 'N' : 'Y';

            let covertageItem = new RiskCoverage();
            covertageItem.seqNumber = this.riskObj.riskCoverageDetails.riskCoverage.length + 1;

            this.riskObj.riskCoverageDetails.riskCoverage.push(covertageItem);

            // SAF MYS-2018-1249 start
            if (this.headerInfo.VPMSProduct == "Y" || this.headerInfo.firePostingScreen == 'NEW') {
                this.resetAllPremiumInfo(event, this.riskObj.riskCoverageDetails.riskCoverage);
                // Below code to add Peril clauses into Coverage Items.
                for (let perilItem of this.riskObj.perils.peril) {
                    if (perilItem.nature == '**') {
                        let isItemExists = covertageItem.perilClassCodes.peril.find(_item => _item.perilCode == perilItem.perilCode);
                        if (isItemExists == undefined) {
                            covertageItem.perilClassCodes.peril.push(perilItem);
                            if (!Array.prototype.isPrototypeOf(perilItem.coverItems)) {
                                let temp: any = [perilItem.coverItems];
                                perilItem.coverItems = temp;
                            }
                            perilItem.coverItems.push(covertageItem.seqNumber.toString());
                        }
                        perilItem.nominatedSumInsured = numeral(this.riskObj.totalSI).value();
                        perilItem.amount = (numeral(perilItem.nominatedSumInsured).value() > 0) ? numeral((numeral(perilItem.nominatedSumInsured).value() * parseFloat(perilItem.perilRate)) / 100).format(this.premiumFormat) : 0;
                        perilItem.unFormattedAmount = numeral().unformat(perilItem.amount);
                    }
                }
                // Below code to add Ratable clauses into Coverage Items.
                for (let rcItem of this.riskObj.rateableClassCode.rateableClassCode) {
                    if (rcItem.nature == '**') {
                        let isItemExists = covertageItem.rateableClassCodes.rateableClassCode.find(_item => _item.classCode == rcItem.classCode);
                        if (isItemExists == undefined) {
                            covertageItem.rateableClassCodes.rateableClassCode.push(rcItem);
                            if (!Array.prototype.isPrototypeOf(rcItem.coverItems)) {
                                let temp: any = [rcItem.coverItems];
                                rcItem.coverItems = temp;
                            }
                            rcItem.coverItems.push(covertageItem.seqNumber.toString());
                        }
                        rcItem.nominatedSumInsured = numeral(this.riskObj.totalSI).value();
                        rcItem.amount = (numeral(rcItem.nominatedSumInsured).value() > 0) ? numeral((numeral(rcItem.nominatedSumInsured).value() * parseFloat(rcItem.rate)) / 100).format(this.premiumFormat) : 0;
                        rcItem.unFormattedAmount = numeral().unformat(rcItem.amount);
                    }
                }
                // Below code to add Warranty clauses into Coverage Items.
                for (let wcItem of this.riskObj.warrantyClassCodes.warrantyClassCode) {
                    if (wcItem.nature == '**') {
                        let isItemExists = covertageItem.wcClassCodes.warrantyClassCode.find(_item => _item.classCode == wcItem.classCode);
                        if (isItemExists == undefined) {
                            covertageItem.wcClassCodes.warrantyClassCode.push(wcItem);
                            if (!Array.prototype.isPrototypeOf(wcItem.coverItems)) {
                                let temp: any = [wcItem.coverItems];
                                wcItem.coverItems = temp;
                            }
                            wcItem.coverItems.push(covertageItem.seqNumber.toString());
                        }
                        wcItem.nominatedSumInsured = numeral(this.riskObj.totalSI).value();
                        wcItem.amount = (numeral(wcItem.nominatedSumInsured).value() > 0) ? numeral((numeral(wcItem.nominatedSumInsured).value() * parseFloat(wcItem.rate)) / 100).format(this.premiumFormat) : 0;
                        wcItem.unFormattedAmount = numeral().unformat(wcItem.amount);
                    }
                }
            }
            //End
        }
    }

    removeRiskCover(coverItem) {
        let _idx = this.riskObj.riskCoverageDetails.riskCoverage.indexOf(coverItem);
        this.riskObj.riskCoverageDetails.riskCoverage.splice(_idx, 1);
        this.resetItemNumber();
        // SAF MYS-2018-1249 start			
        if (this.headerInfo.VPMSProduct == "Y" || this.headerInfo.firePostingScreen == 'NEW') {
            this.resetAllPremiumInfo(event, this.riskObj.riskCoverageDetails.riskCoverage);
            this.clearAllClausesData("");//Clear values for all Peril, Ratable & Warranty Clauses.	
        }
        this.resetTotal();
    }

    resetItemNumber() {
        for (let _riskCoverage of this.riskObj.riskCoverageDetails.riskCoverage) {
            let index = this.riskObj.riskCoverageDetails.riskCoverage.indexOf(_riskCoverage);
            _riskCoverage.seqNumber = (index + 1);
        }
    }

    setPremium(coverItem) {
        this.resetTotal();
    }

    setCoverBasicRate(coverItem) {
        coverItem.rate = '';
        if (coverItem.PIAMCode != undefined && this.riskObj.construction != undefined && this.riskObj.townClass != undefined) {
            let _recordsArr = this.lovDropDownService.lovDataList.piamCodesList.filter(_item => (_item.VALUE === coverItem.PIAMCode && _item.CONSTN === this.riskObj.construction && _item.TOWNCLS === this.riskObj.townClass));
            if (_recordsArr && _recordsArr.length > 0) {
                coverItem.rate = numeral(_recordsArr[0].RATE).format(this.rateFormat);
                coverItem.premiumClass = _recordsArr[0].PREMCLS;
                // _recordsArr[0].ZRIRETN
            }
        }
    }

    setCoveragesBasicRate() {
        if (this.riskObj.riskCoverageDetails.riskCoverage && this.riskObj.riskCoverageDetails.riskCoverage.length > 0) {
            for (let _cover of this.riskObj.riskCoverageDetails.riskCoverage) {
                this.setCoverBasicRate(_cover);
            }

            this.reInitialiseCoverageItems();
        }
    }

    setBasicRate(coverItem) {
        if (coverItem.PIAMCode != undefined && this.riskObj.construction != undefined && this.riskObj.townClass != undefined) {
            //this.riskObj.PIAMCodeBREdit = "N";
            coverItem.rate = '';
            let request: GetLOVData = new GetLOVData();
            request.BRANCH = 'ALL';
            request.LOB = 'FIRE';
            request.BUSINESS_FUNCTION = 'NEW BUSINESS';
            request.PRODUCT = 'ALL';
            request.OPERATION = 'NEW';
            request.FORM_NAME = 'FIRE_IDC';
            request.FORM_FIELD_NAME = 'Basic Rate';
            request.FIELD_TYPE = 'LOV';
            request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
            request.ADVANCE_CONFIG_XML.FILTERS = new Filter();
            //SR002 - Passed header effective date instead of Date of Attachment for Referred Risk Check
            request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({ "@FIELD_NAME": 'DESCITEM', "@FIELD_VALUE": coverItem.PIAMCode, '@OPERATION': 'EQ', '@CONDITION': 'AND' },
                { "@FIELD_NAME": 'CONSTRUCTIONCLS', "@FIELD_VALUE": this.riskObj.construction, '@OPERATION': 'EQ', '@CONDITION': 'AND' },
                { "@FIELD_NAME": 'TWNCLS', "@FIELD_VALUE": this.riskObj.townClass, '@OPERATION': 'EQ', '@CONDITION': 'AND' },
                { "@FIELD_NAME": 'ITMFRM', "@FIELD_VALUE": moment(this.headerInfo.effectiveDate, "YYYY-MM-DD").format("YYYYMMDD"), '@OPERATION': 'LT', '@CONDITION': 'AND' },
                { "@FIELD_NAME": 'ITMTO', "@FIELD_VALUE": moment(this.headerInfo.effectiveDate, "YYYY-MM-DD").format("YYYYMMDD"), '@OPERATION': 'GT', '@CONDITION': 'AND' });

            this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.successHandler, this.handleError, false, { comp: this });

            coverItem.rate = this.basicRateCoverItem;
        }

    }

    successHandler(response, prms) {
        if (response.tuple != null) {
            prms.comp.basicRateCoverItem = numeral(response.tuple.old.T8799.BASICRATE).format(prms.comp.rateFormat);
        }
    }

    onPIAMCodeChange(ev, coverItem) {
        let _idx = this.riskObj.riskCoverageDetails.riskCoverage.indexOf(coverItem);
        coverItem.PIAMCode = ev.value;
        coverItem.PIAMCodeDesc = (ev.record.LONGDESC) ? ev.record.LONGDESC.slice(0, 18) : "";
        coverItem.premiumClass = ev.record.PREMCLS;

		/*if(coverItem.PIAMCode == '4001' || coverItem.PIAMCode == '4005'){
			coverItem.premiumClass = '12B';
		}
		else if(coverItem.PIAMCode == '4006' || coverItem.PIAMCode == '4006A' || coverItem.PIAMCode == '4008'){
			coverItem.premiumClass = '12C';
		}*/

        // this.setBasicRate(coverItem);
        coverItem.rate = '';
        let _recordsArr = this.lovDropDownService.lovDataList.piamCodesList.filter(_item => (_item.VALUE === coverItem.PIAMCode && _item.CONSTN === this.riskObj.construction && _item.TOWNCLS === this.riskObj.townClass));
        if (_recordsArr && _recordsArr.length > 0) {
            coverItem.rate = numeral(_recordsArr[0].RATE).format(this.rateFormat);
            coverItem.premiumClass = _recordsArr[0].PREMCLS;
            // _recordsArr[0].ZRIRETN
        }

        if (this.riskObj.ratingFlag != 'M' && (this.headerInfo.VPMSProduct == "Y" || this.headerInfo.firePostingScreen == 'NEW')) {
            this.resetAllPremiumInfo(ev, coverItem)
        } else {
            this.resetTotal();
        }
        this.setHoverForCover(_idx, coverItem.PIAMCodeDesc);
    }


    onIncrTPLimitChange(eVal) {

        for (let _tpLimit of this.lovDropDownService.lovDataList.tpLimit) {
            let _clauseCode = _tpLimit.SCLS;
            if (this.headerInfo.VPMSProduct == "Y" || this.headerInfo.firePostingScreen == 'NEW') {
                if (_tpLimit.SUMINSURED == eVal) {
                    this.addDefaultRatableClauses(_clauseCode);
                } else {
                    this.removeDefaultRatableClauses(_clauseCode);
                }
            } else {
                if (_tpLimit.SUMINSURED == eVal) {
                    this.addClause(_clauseCode);
                } else {
                    this.removeClause(_clauseCode);
                }
            }
        }

        this.resetTotal();

		/*
		let tpLimit = ev.target.value;
		let request:GetLOVData = new GetLOVData();
		request.BRANCH ='ALL';
		request.LOB = 'FIRE';
		request.BUSINESS_FUNCTION = 'NEW BUSINESS';
		request.PRODUCT = 'ALL';
		request.OPERATION = 'NEW';
		request.FORM_NAME = 'HHO';        
		request.FORM_FIELD_NAME = 'TP Limit Clauses';
		request.FIELD_TYPE = 'LOV';
		request.ADVANCE_CONFIG_XML= new SearchAdvancedConfig(); 
		request.ADVANCE_CONFIG_XML.FILTERS = new Filter();			
		
		for(let tLmt of this.lovDropDownService.lovDataList.tpLimit){
			let tpLmtVal = tLmt.DESCITEM;
			request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({"@FIELD_NAME":'DESCITEM',"@FIELD_VALUE": this.riskObj.riskType+''+tpLmtVal.substring(0,3) ,'@OPERATION':'LIKE','@CONDITION':'OR'});
		}														
		this._soapService.callCordysSoapService("GetLOVData","http://schemas.opentext.com/lovhandler/v1.0", request , this.tpLimitClauseSuccessHandler, this.handleError, false, {comp:this});
		
		let tpLimtRespDataTupleArr:any = [];
		if(this.tpLimitClauseCodesRespData && this.tpLimitClauseCodesRespData.tuple){
			if(Array.prototype.isPrototypeOf(this.tpLimitClauseCodesRespData.tuple))
				tpLimtRespDataTupleArr = this.tpLimitClauseCodesRespData.tuple;
			else 
				tpLimtRespDataTupleArr = [this.tpLimitClauseCodesRespData.tuple];
		}
		
		this.addDefaultTpLimitClause(tpLimtRespDataTupleArr, tpLimit);
		this.resetTotal();
		*/
    }

    tpLimitClauseSuccessHandler(response, prms) {
        if (response.tuple != null) {
            prms.comp.tpLimitClauseCodesRespData = response;
        } else
            prms.comp.tpLimitClauseCodesRespData = null;
    }

    setIncreaseTpLimitAmount(mulPremClas) {
        let tpLimit = parseFloat("" + this.riskObj.increasedTPLimitToSI);

        let _tpLimitRec = this.lovDropDownService.lovDataList.tpLimit.filter((_item) => _item.SUMINSURED == tpLimit);
        if (_tpLimitRec && _tpLimitRec.length > 0) {
            let _amount = parseInt("" + _tpLimitRec[0].AMOUNT);
            this.riskObj.increasedTPLimitToAmount = (mulPremClas) ? (_amount * 2) : _amount;
        } else {
            this.riskObj.increasedTPLimitToAmount = 0;
        }

		/*
		let tpLimitVal = '';
		// if(tpLimit == '100K'){
		if(tpLimit == 100000){
			tpLimitVal = '100K';
			this.riskObj.increasedTPLimitToAmount=(mulPremClas) ? 20 : 10;
			// this.removeClause('OB7A');
			// this.addClause('OB7');
			
		// } else if(tpLimit == '250K'){
		} else if(tpLimit == 250000){
			tpLimitVal = '250K';
			this.riskObj.increasedTPLimitToAmount=(mulPremClas) ? 40 : 20;
			// this.removeClause('OB7');
			// this.addClause('OB7A');
		} else {
			this.riskObj.increasedTPLimitToAmount=0;
			// this.removeClause('OB7');
			// this.removeClause('OB7A');			
		}*/
    }

    addDefaultTpLimitClause(tpLimtRespDataTupleArr, tpLimit) {
        if (tpLimtRespDataTupleArr.length > 0) {
            for (let tuple of tpLimtRespDataTupleArr) {
                let clauseCode = tuple.old.T7382.SCLS;
                if (tpLimit && tuple.old.T7382.DESCITEM == this.riskObj.riskType + '' + tpLimit.substring(0, 3)) {
                    this.addClause(clauseCode);
                }
                else this.removeClause(clauseCode);
            }
        }
    }

    addClause(clauseCode) {
        let isClausePresent = false;

        if (this.riskObj.clauses && this.riskObj.clauses.clause && this.riskObj.clauses.clause.length > 0) {
            for (let clause of this.riskObj.clauses.clause) {
                if (clause.clauseCode == clauseCode) {
                    isClausePresent = true;
                }
            }
        }

        if (!isClausePresent) {
            // this.addClausesInfo(clauseCode);
            this.setClauses([clauseCode], false);
        }

    }

    setClauses(clausesList, flag) {
        if (this.clausesComp)
            this.clausesComp.addClause(clausesList, '', flag);
    }

    deleteClause(ary, clauseCode, prop) {
        let val = undefined;
        if (ary && ary.length > 0) {
            for (var index = 0, assoLength = ary.length; index < assoLength; index++) {
                if (ary[index][prop] != null && ary[index][prop] != "" && ary[index][prop] == clauseCode) {
                    val = index;
                    break;
                }
            }
        }
        if (val != undefined)
            this.clausesComp.removeClause(val, clauseCode);
    }

    removeClause(clauseCode) {

        this.deleteClause(this.riskObj.clauses.clause, clauseCode, "clauseCode");
    }
    // Added for new default class setup E1003
    getNewDefaultClauses(clsSearch) {
        let request: GetLOVData = new GetLOVData();
        request.BRANCH = 'ALL';
        request.LOB = 'FIRE';
        request.BUSINESS_FUNCTION = 'NEW BUSINESS';
        request.PRODUCT = 'ALL';
        request.OPERATION = 'ALL';
        request.FORM_NAME = 'ALL';
        request.FORM_FIELD_NAME = 'PIAMClause';
        request.FIELD_TYPE = 'LOOKUP';
        request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        request.ADVANCE_CONFIG_XML.FILTERS = new Filter();
        let clauseCodes = "";
        request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({ "@FIELD_NAME": "C.DESCITEM", "@FIELD_VALUE": this.headerInfo.contractType, '@OPERATION': 'STARTSWITH', '@CONDITION': 'AND' });
        request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({ "@FIELD_NAME": "SUBSTRING(C.SCLS,1,4)", "@FIELD_VALUE": clsSearch, '@OPERATION': 'IN', '@CONDITION': 'AND' });
        this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.addNewDefaultClauses, this.handleError, false, { comp: this });
    }
    // End E1003
    // Added for new default class setup E1003
    addNewDefaultClauses(response, prms) {
        let ary = [];
        if (response.tuple != null && !Array.prototype.isPrototypeOf(response.tuple)) {
            ary = [response.tuple];
        }
        else if (response.tuple != null) {
            ary = response.tuple;
        }
        for (let clause of ary) {
            let newClause = { clauseCode: clause.old.T7382.CODE, description: clause.old.T7382.LONGDESC, isDefaultClause: 'N' };
            prms.comp.riskObj.clauses.clause.push(newClause);
        }
    }

    // End E1003
    setCoverPremium(coverItem) {
        let si: any = coverItem.sumInsured;
        let rate: any = coverItem.rate;
        let extRate: any = coverItem.extRate;
        let extPRate: any = coverItem.perilRate;
        si = (si == null || si == "") ? 0 : si;
        rate = (rate == null || rate == "") ? 0 : parseFloat(rate);
        extRate = (extRate == null || extRate == "") ? 0 : parseFloat(extRate);
        extPRate = (extPRate == null || extPRate == "") ? 0 : parseFloat(extPRate);
        let _totalRate = rate + extRate; // + extPRate;
        if (this.headerInfo.VPMSProduct == "Y" || this.headerInfo.firePostingScreen == "NEW") { // SAF MYS-2018-1249 start
            _totalRate = _totalRate + extPRate;
        } //End
        coverItem.totalRate = numeral(numeral(_totalRate).format(this.rateFormat)).value();
        if (si != 0) {
            let discPremium = (si * (rate + extRate)) / 100;
            coverItem.premium = numeral(numeral(discPremium).format(this.premiumFormat)).value();
        }
    }

    resetTotal() {
        let isMultiplePremClassAdded: boolean = false;
        let prevPremCls: string = '';
        for (let coverItem of this.riskObj.riskCoverageDetails.riskCoverage) {
            if (coverItem.premiumClass) {
                if (this.riskObj.ratingFlag == 'M' || this.headerInfo.VPMSProduct != "Y") {
                    this.setCoverPremium(coverItem);
                }
                if (prevPremCls != '' && prevPremCls != coverItem.premiumClass) {
                    isMultiplePremClassAdded = true;
                }
                prevPremCls = coverItem.premiumClass;
            }
        }
        this.setIncreaseTpLimitAmount(isMultiplePremClassAdded);

        this.riskObj.totalSI = this.getTotalByProperty("sumInsured", this.riskObj.riskCoverageDetails.riskCoverage, null);
        this.riskObj.basicPremium = this.getTotalByProperty("premium", this.riskObj.riskCoverageDetails.riskCoverage, this.premiumFormat);
        this.riskObj.capitalSumInsured = this.riskObj.totalSI;

        let _totalBasePrem = parseFloat("" + this.riskObj.basicPremium) + parseFloat("" + this.riskObj.increasedTPLimitToAmount);
        this.riskObj.totalBasicPremium = numeral(numeral(_totalBasePrem).format(this.premiumFormat)).value();
        this.riskObj.originalTotalPremium = this.riskObj.totalBasicPremium;

        this.riskObj.rebateAmount = numeral(numeral((parseFloat("" + numeral(_totalBasePrem).value()) * parseFloat("" + this.riskObj.rebate)) / 100).format(this.premiumFormat)).value();
        let discountedPrem = numeral(numeral(parseFloat("" + numeral(_totalBasePrem).value()) - parseFloat("" + numeral(this.riskObj.rebateAmount).value())).format(this.premiumFormat)).value();
        this.riskObj.discountedPremium = discountedPrem;
        //this.riskObj.gstAmount = (parseInt(""+this.riskObj.GST) > 0 && discountedPrem > 0)?numeral(numeral((discountedPrem*parseInt(""+this.riskObj.GST))/100).format(this.premiumFormat)).value():0; //SAF MYS-2018-0629;
        //SST Code
        let tempGSTAmount = (parseInt("" + this.riskObj.GST) > 0 && discountedPrem > 0) ? numeral(numeral((discountedPrem * parseInt("" + this.riskObj.GST)) / 100).format(this.premiumFormat)).value() : 0;
        this.riskObj.gstAmount = (tempGSTAmount > 0) ? numeral(numeral(BMSUtilService.calculatePremiumAmount(tempGSTAmount, "G")).format(this.premiumFormat)).value() : 0;

        let tempSSTAmount = (parseInt("" + this.riskObj.SST) > 0 && discountedPrem > 0) ? numeral(numeral((discountedPrem * parseInt("" + this.riskObj.SST)) / 100).format(this.premiumFormat)).value() : 0;
        this.riskObj.sstAmount = (tempSSTAmount > 0) ? numeral(numeral(BMSUtilService.calculatePremiumAmount(tempSSTAmount, "S")).format(this.premiumFormat)).value() : 0;

        let _totalPremium = parseFloat("" + numeral(discountedPrem).value()) + parseFloat("" + numeral(this.riskObj.gstAmount).value()) + parseFloat("" + numeral(this.riskObj.sstAmount).value());
        //End
        this.riskObj.totalPremium = numeral(numeral(_totalPremium).format(this.premiumFormat)).value();

        this.onPremiumChange.emit(this.riskObj.totalPremium);

        this.validateSumInsured();


        // SAF MYS-2018-1249 start
        if (this.headerInfo.VPMSProduct == "Y" || this.headerInfo.firePostingScreen == 'NEW') {
            if (JSON.stringify(this.riskObj.rateableClassCode) != JSON.stringify("") && this.riskObj.rateableClassCode.rateableClassCode != undefined) {
                this.clearCoverItemsInfo(this.riskObj.rateableClassCode.rateableClassCode.filter((item) => item.nature == '**'));
            }
            if (this.riskObj.perils.peril != undefined) {
                this.clearCoverItemsInfo(this.riskObj.perils.peril.filter((item) => item.nature == '**'));
            }
            if (this.riskObj.warrantyClassCodes.warrantyClassCode != undefined) {
                this.clearCoverItemsInfo(this.riskObj.warrantyClassCodes.warrantyClassCode.filter((item) => item.nature == '**'));
            }

            for (let cover of this.riskObj.riskCoverageDetails.riskCoverage) {
                // Default Peril Clauses
                if (this.riskObj.perils.peril != undefined && cover.perilClassCodes != undefined) {
                    if (cover.perilClassCodes.peril != undefined && !Array.prototype.isPrototypeOf(cover.perilClassCodes.peril)) {//MKU1
                        cover.perilClassCodes.peril = new AppUtil().getArray(cover.perilClassCodes.peril);
                    }
                    let defaultPItems = this.riskObj.perils.peril.filter((item) => item.nature == '**');
                    for (let perilItem of defaultPItems) {
                        if (perilItem.nature == '**') {
                            let isItemExists = cover.perilClassCodes.peril.find(_item => _item.perilCode == perilItem.perilCode);
                            if (isItemExists == undefined) {
                                cover.perilClassCodes.peril.push(perilItem);
                            }
                            perilItem.nominatedSumInsured = numeral(this.riskObj.totalSI).value();
                            perilItem.nominatedSumInsuredNew = perilItem.nominatedSumInsured;
                            if (this.headerInfo.VPMSProduct != "Y") {
                                perilItem.amount = numeral((numeral(perilItem.nominatedSumInsured).value() * parseFloat(perilItem.perilRate)) / 100).format(this.premiumFormat);
                            }
                            perilItem.unFormattedAmount = numeral().unformat(perilItem.amount);
                            if (perilItem.coverItems == undefined) {
                                perilItem.coverItems = [];
                            } else if (!Array.prototype.isPrototypeOf(perilItem.coverItems)) {
                                let temp: any = [perilItem.coverItems];
                                perilItem.coverItems = temp;
                            }
                            perilItem.coverItems.push(cover.seqNumber.toString());
                        }
                    }
                }
                // Defaulting Ratable Clauses 
                if (JSON.stringify(this.riskObj.rateableClassCode) != JSON.stringify("") && this.riskObj.rateableClassCode.rateableClassCode != undefined && JSON.stringify(cover.rateableClassCodes) != JSON.stringify("")) {
                    if (cover.rateableClassCodes.rateableClassCode != undefined && !Array.prototype.isPrototypeOf(cover.rateableClassCodes.rateableClassCode)) {//MKU1
                        cover.rateableClassCodes.rateableClassCode = new AppUtil().getArray(cover.rateableClassCodes.rateableClassCode);
                    }
                    let defaultRItems = this.riskObj.rateableClassCode.rateableClassCode.filter((item) => item.nature == '**');
                    for (let rItem of defaultRItems) {
                        if (rItem.nature == '**') {
                            let isItemExists = cover.rateableClassCodes.rateableClassCode.find(_item => _item.classCode == rItem.classCode);
                            if (isItemExists == undefined) {
                                cover.rateableClassCodes.rateableClassCode.push(rItem);
                            }
                            rItem.nominatedSumInsured = numeral(this.riskObj.totalSI).value();
                            rItem.nominatedSumInsuredNew = rItem.nominatedSumInsured;
                            if (this.headerInfo.VPMSProduct != "Y") {
                                rItem.amount = numeral((numeral(rItem.nominatedSumInsured).value() * parseFloat(rItem.rate)) / 100).format(this.premiumFormat);
                            }
                            rItem.unFormattedAmount = numeral().unformat(rItem.amount);
                            if (rItem.coverItems == undefined) {
                                rItem.coverItems = [];
                            } else if (!Array.prototype.isPrototypeOf(rItem.coverItems)) {
                                let temp: any = [rItem.coverItems];
                                rItem.coverItems = temp;
                            }
                            rItem.coverItems.push(cover.seqNumber.toString());
                        }
                    }
                }
                // Default Warranty Clauses
                if (this.riskObj.warrantyClassCodes.warrantyClassCode != undefined && cover.wcClassCodes != undefined && JSON.stringify(this.riskObj.warrantyClassCodes) != JSON.stringify("") && JSON.stringify(cover.wcClassCodes) != JSON.stringify("")) {//MKU1
                    if (cover.wcClassCodes.warrantyClassCode != undefined && !Array.prototype.isPrototypeOf(cover.wcClassCodes.warrantyClassCode)) {//MKU1
                        cover.wcClassCodes.warrantyClassCode = new AppUtil().getArray(cover.wcClassCodes.warrantyClassCode);
                    }
                    let defaultWCItems = this.riskObj.warrantyClassCodes.warrantyClassCode.filter((item) => item.nature == '**');
                    for (let wcItem of defaultWCItems) {
                        if (wcItem.nature == '**') {
                            let isItemExists = cover.wcClassCodes.warrantyClassCode.find(_item => _item.classCode == wcItem.classCode);
                            if (isItemExists == undefined) {
                                cover.wcClassCodes.warrantyClassCode.push(wcItem);
                            }
                            wcItem.nominatedSumInsured = numeral(this.riskObj.totalSI).value();
                            wcItem.nominatedSumInsuredNew = wcItem.nominatedSumInsured;
                            if (this.headerInfo.VPMSProduct != "Y") {
                                wcItem.amount = numeral((numeral(wcItem.nominatedSumInsured).value() * parseFloat(wcItem.rate)) / 100).format(this.premiumFormat);
                            }
                            wcItem.unFormattedAmount = numeral().unformat(wcItem.amount);
                            if (wcItem.coverItems == undefined) {
                                wcItem.coverItems = [];
                            } else if (!Array.prototype.isPrototypeOf(wcItem.coverItems)) {
                                let temp: any = [wcItem.coverItems];
                                wcItem.coverItems = temp;
                            }
                            wcItem.coverItems.push(cover.seqNumber.toString());
                        }
                    }
                }
            }
        }
        //End

    }

    private clearCoverItemsInfo(defaultItems: any) {
        for (let item of defaultItems) {
            if (item.nature == '**') {
                item.coverItems = [];
            }
            if (this.riskObj.riskCoverageDetails.riskCoverage.length == 0) {
                item.nominatedSumInsured = 0;
                item.amount = numeral(0).format(this.premiumFormat);
                item.unFormattedAmount = numeral(0);
            }
        }
    } //End

    validateSumInsured() {
        if (this.riskObj.RIRetentionCode && this.riskObj.isRIOverWrittenByUW == 'N') {

            this._bmsUtilService.getTotalGrossCapacity(this.riskObj.RIRetentionCode).subscribe((data) => this.compareSIWithTotGrossCap(data));

			/*let _totalGrossCapacity = this._bmsUtilService.getNetRetentionAmountDetails(this.riskObj.RIRetentionCode);
			_totalGrossCapacity = (!_totalGrossCapacity) ? 0 : parseFloat(""+_totalGrossCapacity);
			this.riskObj.totalGrossCapacity = _totalGrossCapacity;
			let _totalSI = parseFloat(""+this.riskObj.totalSI);
			
			if( _totalGrossCapacity > 0 && _totalSI > _totalGrossCapacity && (this.riskObj.RIMethod == null || this.riskObj.RIMethod == "" || parseFloat(""+this.riskObj.RIMethod) != 8) ){
				this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Total Sum Insured is greater than Total Gross Capacity: "+_totalGrossCapacity+",  RI is Required." , 10000));
				
				this.riskObj.RIRequired = "Yes";
				this.riskObj.RIMethod = "8";
			} 
			else if(_totalSI <= _totalGrossCapacity){
				this.riskObj.RIRequired = "No";
				this.riskObj.RIMethod = this.riskObj.RIMethodSys;
			}*/
        }
        else
            this.setRIMethodEditableFlag();
    }

    compareSIWithTotGrossCap(totGrossCap) {

        let _totalGrossCapacity = (!totGrossCap) ? 0 : parseFloat("" + totGrossCap);
        this.riskObj.totalGrossCapacity = _totalGrossCapacity;
        let _totalSI = parseFloat("" + this.riskObj.totalSI);

        if (_totalGrossCapacity > 0 && _totalSI > _totalGrossCapacity && (this.riskObj.RIMethod == null || this.riskObj.RIMethod == "" || parseFloat("" + this.riskObj.RIMethod) != 8)) {
            this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Total Sum Insured is greater than Total Gross Capacity: " + _totalGrossCapacity + ",  RI is Required.", 10000));

            this.riskObj.RIRequired = "Yes";
            this.riskObj.RIMethod = "8";
        }
        else if (_totalSI <= _totalGrossCapacity) {
            this.riskObj.RIRequired = "No";
            this.riskObj.RIMethod = this.riskObj.RIMethodSys;
        }
        this._riService.setRI().subscribe();
        this.setRIMethodEditableFlag();
    }

    getTotalByProperty(prop, ary, format: string) {
        let total = 0;
        for (let eachItem of ary) {
            if (eachItem[prop] != null && eachItem[prop] != "")
                total = total + parseFloat(numeral(eachItem[prop]).value());
        }
        if (format != null)
            return numeral(numeral(total).format(format)).value();
        else
            return total;
    }

    getPostCodeInfo(postcode) {
        this.riskObj.postCode = isNaN(parseInt(postcode)) ? postcode.toUpperCase() : postcode;
        // Accumulation register code --start
        this.tempSysReferred = this.riskObj.accRegister.isSystemReferred;
        this.tempAccuSysReferred = this.riskObj.accRegister.isAccuSystemReferredFlag;
        this.riskObj.accRegister = new AccRegister();
        this.riskObj.accRegister.isSystemReferred = this.tempSysReferred;
        this.riskObj.accRegister.isAccuSystemReferredFlag = this.tempAccuSysReferred;
        this.handleRiskClassification(this);
        //this.setReferredRiskFlag(false,"Standard",false); // End

        let request: GetLOVData = new GetLOVData().getRequest('ALL', 'FIRE', 'NEW BUSINESS', 'ALL', 'NEW', 'FIRE_IDC', 'PostCode', 'LOV');
        request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        request.ADVANCE_CONFIG_XML.FILTERS = new Filter();

        request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({ "@FIELD_NAME": 'DESCITEM', "@FIELD_VALUE": this.riskObj.postCode, '@OPERATION': 'EQ', '@CONDITION': 'AND' });
        this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.setPostCodeInfo, this.handleError, true, { comp: this, postCode: this.riskObj.postCode });
    }

    setPostCodeInfo(response, prms) {
        if (response.tuple != null) {
            prms.comp.riskObj.city = response.tuple.old.DESCPF.SHORTDESC;
            prms.comp.riskObj.cityName = response.tuple.old.DESCPF.LONGDESC;
            prms.comp.setAccRegInfo();
            prms.comp.setGSTInfo();
        }
        else {
            prms.comp.riskObj.city = "";
            prms.comp.riskObj.cityName = "";
            prms.comp.clearAccReg();
        }
    }

    setAccRegInfo() {
        this.clearAccReg();
        this.setAccumulationRegister();
    }

    clearAccReg() {
        this.riskObj.accumulationRegister = "";
        this.AccRegList = [];
        if (this.accRegCtrl != null) {
            this.accRegCtrl.setter("", this.accRegCtrl.comp);
        }
        this.setAccReg({ record: { locality: "" }, value: "" });
    }

    setGSTInfo() {
        this.setGST(this.riskObj.postCode);
    }

    setGST(postCode) {
        if (isNaN(parseInt(postCode))) {
            this.riskObj.GSTDetails.riskLocation = "OS";
        }
        else {
            this.validateGSTForPCA(postCode);
        }
    }

    validateGSTForPCA(postCode) {
        let request: GetLOVData = new GetLOVData();
        request.BRANCH = 'ALL';
        request.LOB = 'ALL';
        request.BUSINESS_FUNCTION = 'ALL';
        request.PRODUCT = 'ALL';
        request.OPERATION = 'ALL';
        request.FORM_NAME = 'GST';
        request.FORM_FIELD_NAME = 'GST_PCA_POSTCODE';
        request.FIELD_TYPE = 'LOV';
        request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        request.ADVANCE_CONFIG_XML.FILTERS = new Filter();

        request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({ "@FIELD_NAME": 'DESCITEM', "@FIELD_VALUE": postCode, '@OPERATION': 'EQ', '@CONDITION': 'AND' });
        this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.setISPCA, this.handleError, true, { comp: this, postCode: postCode });
    }

    setISPCA(response, prms) {
        if (response.tuple != null && response.tuple.old.DESCPF.SHORTDESC != "LLB") {
            prms.comp.riskObj.GSTDetails.riskLocation = "PCA";
            // prms.comp.riskObj.GST = 6;
        }// Adding below code for SAF MYS-2017-0846 -- start
        else if (response.tuple != null && response.tuple.old.DESCPF.SHORTDESC == "LLB") {
            prms.comp.riskObj.GSTDetails.riskLocation = "DA";
            prms.comp.riskObj.GST = 0;
            prms.comp.riskObj.SST = Number(0);//SST Code
        } // End
        else {
            prms.comp.validateGSTForDA(prms.postCode, prms.comp)
        }
    }

    validateGSTForDA(postCode, comp) {
        let request: GetLOVData = new GetLOVData();
        request.BRANCH = 'ALL';
        request.LOB = 'ALL';
        request.BUSINESS_FUNCTION = 'ALL';
        request.PRODUCT = 'ALL';
        request.OPERATION = 'ALL';
        request.FORM_NAME = 'GST';
        request.FORM_FIELD_NAME = 'GST_DA_POSTCODE';
        request.FIELD_TYPE = 'LOV';
        request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        comp._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, comp.setISDA, comp.handleError, true, { comp: comp, postCode: postCode });
    }

    setISDA(response, prms) {
        if (response.tuple != null) {
            let postCodes = response.tuple.old.ITEMPF.POSTCODES;
            let postCodesList = postCodes.split(",");
            let hasPostCode = false;
            let isSameCode = false;
            for (let pCode of postCodesList) {
                // if (!isNaN(parseInt(pCode))) // SAF MYS-2017-0846
                if (pCode != undefined && pCode != "") {
                    hasPostCode = true;
                    if (pCode == prms.postCode) {
                        isSameCode = true;
                    }
                }
            }

            if (hasPostCode == false || isSameCode == true) {
                prms.comp.riskObj.GSTDetails.riskLocation = "DA";
                prms.comp.riskObj.GST = 0;
                prms.comp.riskObj.SST = Number(0); //SST Code
            }
            else {
                prms.comp.riskObj.GSTDetails.riskLocation = "PCA";
                //prms.comp.riskObj.GST = 0;// 6; //SAF MYS-2018-0629
                prms.comp.riskObj.GST = Number(prms.comp.headerInfo.GSTTaxRate);//SST Code
                prms.comp.riskObj.SST = Number(prms.comp.headerInfo.SSTTaxRate);//SST Code
            }
        }
    }

    setAccReg(values) {
        this.riskObj.locality = values.record.locality;
		/*if(this.riskObj.addRelatedCases == "Y" && this.riskObj.relatedCases.relatedCases.relatedCase.length > 0){
			this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Related cases are removed as accumulation register is changed." , -1));
		}
		if(this.relatedComp != null){
			this.relatedComp.setAccumulationRegister(values.value);
		}*/

        // added code for AccRegister - start
        if (values.value == "0") {
            this.riskObj.locality = "0";
            this.tempSysReferred = this.riskObj.accRegister.isSystemReferred;
            this.tempAccuSysReferred = this.riskObj.accRegister.isAccuSystemReferredFlag;
            this.riskObj.accRegister = new AccRegister();
            this.riskObj.accRegister.isSystemReferred = this.tempSysReferred;
            this.riskObj.accRegister.isAccuSystemReferredFlag = this.tempAccuSysReferred;
            this.handleRiskClassification(this);
            //this.setReferredRiskFlag(false,"Standard",false);
            this.emailType = "1";
            let inputObj = {
                "Message": "No accumulation register for the selected postal code, Do you want to send Email to RI Treaty ?",
                "Action": ""
            };
            let input = inputObj;
            let lookup = new ModalInput().get("Confirm");
            lookup.datainput = input;
            lookup.outputCallback = this.openConfirmPopUpCallBack;
            lookup.parentCompPRMS = { comp: this };
            lookup.heading = "Confirm Send Email to RI Treaty";
            lookup.icon = "fa fa-hand-paper-o";
            lookup.containerRef = this.contentArea;
            this.dcl.openLookup(lookup);
        } else if (values.value != "" && values.value != "0") {
            this._appObjService.saveData().subscribe((data) => {
                this.callAccRegisterFunction();
            });
        }
    }

    // AccRegister code -- start
    private openConfirmPopUpCallBack(data, prms) {
        if (data.value == 'Y') {

			/*if(prms.comp.caseInfo.caseId == "" || prms.comp.caseInfo.caseId == undefined){
				prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Please Save the case before sending an Email for Accumulation Register Creation." ,8000));
				return;
			}*/
            prms.comp._appObjService.saveData().subscribe((data) => {
                prms.comp.riskClassificationService.sendMailtoTreaty(prms.comp.riskObj, prms.comp.caseInfo.caseId, prms.comp.emailType);
            });
        }
    }

    private callAccRegisterFunction() {
        this._soapService.callCordysSoapService("GetCurrentExposerAccuRegister", "http://schemas.insurance.com/businessobject/1.0/",
            {
                "caseID": this.caseInfo.caseId,
                "snedmail": "",
                "AccumulationReg": this.riskObj.accumulationRegister,
                "PostCode": this.riskObj.postCode,
                "LocationCode": this.riskObj.locality,
                "TotalSI": this.riskObj.totalSI,
                "Branch": BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.servicingBranch,
                "cslAmount": "0",
                "city": this.riskObj.city
            },
            this.setAccRegisterInfoSuccess, this.setAccRegisterInfoError, true, { comp: this });
    }

    setAccRegisterInfoSuccess(response, prms) {
        if (!response.fault) {
            prms.comp.riskObj.accRegister.ExposerQuotAccepted = response.ExposerQuotAccepted.text;
            prms.comp.riskObj.accRegister.HoldCoverExposer = response.HoldCoverExposer.text;
            prms.comp.riskObj.accRegister.GAL = response.GAL.text;
            prms.comp.riskObj.accRegister.P400InforcedExposer = response.P400InforcedExposer.text;
            prms.comp.riskObj.accRegister.TotalExposer = response.TotalExposer.text;
            prms.comp.riskObj.accRegister.Outstanding = response.Outstanding.text;
            prms.comp.riskObj.accRegister.cessionOutwords = response.cessionOutwords.text;
            prms.comp.riskObj.accRegister.totalPercentage = (Number(response.TotalExposer.text) * 100) / Number(response.GAL.text);

            prms.comp.riskObj.accRegister.TOTGR = response.TOTGR.text
            prms.comp.riskObj.accRegister.TOTMNR = response.TOTMNR.text
            prms.comp.riskObj.accRegister.TOTFAC = response.TOTFAC.text
            prms.comp.riskObj.accRegister.TOTTREATY = response.TOTTREATY.text
            prms.comp.riskObj.accRegister.LIMITMNR = response.LIMITMNR.text
            prms.comp.riskObj.accRegister.LIMITFAC = response.LIMITFAC.text
            prms.comp.riskObj.accRegister.LIMITTREATY = response.LIMITTREATY.text
            prms.comp.riskObj.accRegister.LIMITNET = response.LIMITNET.text
            if (prms.comp.riskObj.accRegister.totalPercentage < 0) {
                prms.comp.riskObj.accRegister.totalPercentage = -(Number(prms.comp.riskObj.accRegister.totalPercentage));
            }

            prms.comp.riskObj.accRegister.cessionOutwordsPercentage = (Number(response.cessionOutwords.text) * 100) / Number(response.Outstanding.text);
            if (prms.comp.riskObj.accRegister.cessionOutwordsPercentage < 0) {
                prms.comp.riskObj.accRegister.cessionOutwordsPercentage = -(Number(prms.comp.riskObj.accRegister.cessionOutwordsPercentage));
            }

            // formatted values
            prms.comp.riskObj.accRegister.formattedExposerQuotAccepted = numeral(prms.comp.riskObj.accRegister.ExposerQuotAccepted).format("0,0");
            prms.comp.riskObj.accRegister.formattedHoldCoverExposer = numeral(prms.comp.riskObj.accRegister.HoldCoverExposer).format("0,0");
            prms.comp.riskObj.accRegister.formattedGAL = numeral(prms.comp.riskObj.accRegister.GAL).format("0,0");
            prms.comp.riskObj.accRegister.formattedP400InforcedExposer = numeral(prms.comp.riskObj.accRegister.P400InforcedExposer).format("0,0");
            prms.comp.riskObj.accRegister.formattedTotalExposer = numeral(prms.comp.riskObj.accRegister.TotalExposer).format("0,0");
            prms.comp.riskObj.accRegister.formattedOutstanding = numeral(prms.comp.riskObj.accRegister.Outstanding).format("0,0");
            prms.comp.riskObj.accRegister.formattedcessionOutwords = numeral(prms.comp.riskObj.accRegister.cessionOutwords).format("0,0");
            prms.comp.riskObj.accRegister.formattedGALPercentage = isNaN(prms.comp.riskObj.accRegister.totalPercentage) ? numeral(0).format("00.00") : numeral(prms.comp.riskObj.accRegister.totalPercentage).format("00.00");
            prms.comp.riskObj.accRegister.formattedcessionOutPercentage = isNaN(prms.comp.riskObj.accRegister.cessionOutwordsPercentage) ? numeral(0).format("00.00") : numeral(prms.comp.riskObj.accRegister.cessionOutwordsPercentage).format("00.00");

            prms.comp.riskObj.accRegister.formattedtotGR = numeral(prms.comp.riskObj.accRegister.TOTGR).format("0,0");
            prms.comp.riskObj.accRegister.formattedtotMNR = numeral(prms.comp.riskObj.accRegister.TOTMNR).format("0,0");
            prms.comp.riskObj.accRegister.formattedtotFAC = numeral(prms.comp.riskObj.accRegister.TOTFAC).format("0,0");
            prms.comp.riskObj.accRegister.formattedtotTREATY = numeral(prms.comp.riskObj.accRegister.TOTTREATY).format("0,0");
            prms.comp.riskObj.accRegister.formattedLimitMNR = numeral(prms.comp.riskObj.accRegister.LIMITMNR).format("0,0");
            prms.comp.riskObj.accRegister.formattedLimitFAC = numeral(prms.comp.riskObj.accRegister.LIMITFAC).format("0,0");
            prms.comp.riskObj.accRegister.formattedLimitTREATY = numeral(prms.comp.riskObj.accRegister.LIMITTREATY).format("0,0");
            prms.comp.riskObj.accRegister.formattedLimitNet = numeral(prms.comp.riskObj.accRegister.LIMITNET).format("0,0");

            prms.comp.accRegisterValidations();

        } else {
            prms.comp.tempSysReferred = prms.comp.riskObj.accRegister.isSystemReferred;
            prms.comp.tempAccuSysReferred = prms.comp.riskObj.accRegister.isAccuSystemReferredFlag;
            prms.comp.riskObj.accRegister = new AccRegister();
            prms.comp.riskObj.accRegister.isSystemReferred = prms.comp.tempSysReferred;
            prms.comp.riskObj.accRegister.isAccuSystemReferredFlag = prms.comp.tempAccuSysReferred;

            prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error while Calling Accumulation Register service.", 8000));
        }
    }

    setAccRegisterInfoError(response, status, errorText, prms) {
        prms.comp.tempSysReferred = prms.comp.riskObj.accRegister.isSystemReferred;
        prms.comp.tempAccuSysReferred = prms.comp.riskObj.accRegister.isAccuSystemReferredFlag;
        prms.comp.riskObj.accRegister = new AccRegister();
        prms.comp.riskObj.accRegister.isSystemReferred = prms.comp.tempSysReferred;
        prms.comp.riskObj.accRegister.isAccuSystemReferredFlag = prms.comp.tempAccuSysReferred;

        prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error while Calling Accumulation Register service.", 8000));
    }

    accRegisterValidations() {
        this.riskObj.accRegister.totalPercentage = 0;
        if (this.riskObj.accRegister.GAL != "0" && this.riskObj.accRegister.GAL != "") {
            this.riskObj.accRegister.totalPercentage = (Number(this.riskObj.accRegister.TotalExposer) * 100) / Number(this.riskObj.accRegister.GAL);

            if (this.riskObj.accRegister.totalPercentage >= 90 && this.riskObj.accRegister.totalPercentage <= 100) {
                if (BMSConstants.getBMSObj().ApplicationBusinessObject.caseInfo.status != "Draft") {
                    this.emailType = "2";
                    //this.setReferredRiskFlag(false,"Standard",false);
                    this.handleRiskClassification(this);
                    let inputObj = {
                        "Message": "Total exposure percentage is more than 90 % against GAL, Do you want to send email to under writer?",
                        "Action": ""
                    };
                    let input = inputObj;
                    let lookup = new ModalInput().get("Confirm");
                    lookup.datainput = input;
                    lookup.outputCallback = this.openConfirmPopUpCallBack;
                    lookup.parentCompPRMS = { comp: this };
                    lookup.heading = "Confirm Send Email to Underwriter";
                    lookup.icon = "fa fa-hand-paper-o";
                    lookup.containerRef = this.contentArea;
                    this.dcl.openLookup(lookup);
                }
            } else {
                this.handleRiskClassification(this);
            }
			/*if(this.riskObj.accRegister.totalPercentage > 100){
				this.setReferredRiskFlag(true,"Referred",true);
				this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Total Exposure percentage is more than 100 % against GAL and Risk has been changed to Referred." ,8000));
			} else {
				if((this.riskObj.accRegister.isSystemReferred == false) && (this.riskObj.accRegister.isAccuSystemReferredFlag == true)) {
					this.setReferredRiskFlag(true,"Referred",true);
				} else {
					this.setReferredRiskFlag(false,"Standard",false);
				}
			}*/
        } else {
            this.handleRiskClassification(this);
            //this.setReferredRiskFlag(false,"Standard",false);
        }
    }

    private setReferredRiskFlag(referredFlag, riskClassification, defaultFlag) {
        let refRiskUIFlag = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.isReferredRiskUI;
        if ((refRiskUIFlag == true || this.riskObj.accRegister.isSystemReferred == true) && (this.riskObj.accRegister.isAccuSystemReferredFlag == false)) {
            this.riskObj.accRegister.isSystemReferred = true;
            this.riskObj.accRegister.isAccuSystemReferredFlag = false;
            if (this.riskObj.accRegister.totalPercentage > 100)
                BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.isReferredToUW = 'Y'
            else
                BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.isReferredToUW = 'N'

        } else {
            this.riskObj.accRegister.isSystemReferred = false;
            this.riskObj.accRegister.isAccuSystemReferredFlag = defaultFlag;
            this.riskObj.symRiskClassification = riskClassification;
            BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.isReferredRiskUI = referredFlag;
            if (defaultFlag)
                BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.isReferredToUW = 'Y'
            else
                BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.isReferredToUW = 'N'
            this.handleRiskClassification(this);
        }
    }   // AccRegister code -- End

    setAccumulationRegister() {
        let request: GetLOVData = new GetLOVData();
        request.BRANCH = 'ALL';
        request.LOB = 'FIRE';
        request.BUSINESS_FUNCTION = 'NEW BUSINESS';
        request.PRODUCT = 'ALL';
        request.OPERATION = 'NEW';
        request.FORM_NAME = 'FIRE_IDC';
        request.FORM_FIELD_NAME = 'ACCREG';
        request.FIELD_TYPE = 'LOV';
        request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        request.ADVANCE_CONFIG_XML.FILTERS = new Filter();

        request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push(
            { "@FIELD_NAME": 'ZTOWNCODE', "@FIELD_VALUE": this.riskObj.city, '@OPERATION': 'EQ', '@CONDITION': 'AND' },
            { "@FIELD_NAME": 'PCODE', "@FIELD_VALUE": this.riskObj.postCode, '@OPERATION': 'EQ', '@CONDITION': 'AND' },
            { "@FIELD_NAME": '', "@FIELD_VALUE": '', '@OPERATION': 'OPNPRNTHS', '@CONDITION': '' },
            { "@FIELD_NAME": 'ZCIDTETER', "@FIELD_VALUE": "0", '@OPERATION': 'EQ', '@CONDITION': 'OR' },
            { "@FIELD_NAME": 'ZCIDTETER', "@FIELD_VALUE": '99999999', '@OPERATION': 'EQ', '@CONDITION': 'OR' },
            { "@FIELD_NAME": 'ZCIDTETER', "@FIELD_VALUE": moment(new Date()).format("YYYYMMDD"), '@OPERATION': 'GT', '@CONDITION': '' },
            { "@FIELD_NAME": '', "@FIELD_VALUE": '', '@OPERATION': 'CLSPRNTHS', '@CONDITION': '' }
        );
        this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.setAccuRegHandler, this.handleError, true, { comp: this });
    }

    setAccuRegHandler(response, prms) {
        let ary = [];
        let currentDate = moment(new Date()).format("YYYYMMDD");
        let registerNotExpired = true;
        if (response.tuple != null && !Array.prototype.isPrototypeOf(response.tuple)) {
            ary = [response.tuple];
        }
        else if (response.tuple != null) {
            ary = response.tuple;
        }
        prms.comp.AccRegList = [];
        for (let item of ary) {
            // SR001 Added the condition to check if Acc Reg is expired or not
            if (item.old.FACM.ZCIDTETER > currentDate || item.old.FACM.ZCIDTETER == '0') {
                let accReg: AccumulationRegister = {
                    "accRegCode": item.old.FACM.FREG,
                    "accRegDesc": item.old.FACM.FDESC,
                    "locality": item.old.FACM.LOCREG
                };
                // SR001 Added below the Condition to check if the accumulation register is expired on Renewal
                if (item.old.FACM.FREG == prms.comp.riskObj.accumulationRegister) {
                    registerNotExpired = false;
                }
                prms.comp.AccRegList.push(accReg);
            }
        }
        //Added code for AccRegister --start
        let accReg: AccumulationRegister = {
            "accRegCode": "0",
            "accRegDesc": "Register Not Found",
            "locality": ""
        };
        // SR001 Added the alert if the accumulation register expires on Renewal
        if (registerNotExpired && prms.comp.riskObj.accumulationRegister != "" && prms.comp.riskObj.accumulationRegister != undefined && prms.comp.riskObj.accumulationRegister != null) {
            prms.comp.riskObj.accumulationRegister = "";
            prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Accumulation Register Expired. Please select the correct Fire Accumulation Code. ", 5000));
        }
        prms.comp.AccRegList.push(accReg);
        //End
    }

    setTownClass(value) {
        this.riskObj.townClass = value;
        // this.setBasicRate();
        this.setCoveragesBasicRate();
    }

    setConstruction(ev) {
        /*  this.riskObj.construction = value;
         let evt: any = event;
         this.riskObj.constructionName = jQuery(evt.target.selectedOptions[0]).text(); */

        this.riskObj.construction = ev.value;
        this.riskObj.constructionName = ev.record.DESCRIPTION;

        // this.setBasicRate();
        this.setCoveragesBasicRate();
    }

    onRIRtnChange(value) {
        this.riskObj.RIRetentionCode = value;
        this.riskObj.riRiskClassification = "Standard";
        this.handleRiskClassification(this);
        // this.setSurveyNeed();
    }

    handleRiskClassification(comp) {
        this.riskClassificationService.setRiskClassification(comp.riskObj.riskNumber, "N", "", "").subscribe();
		/*if(comp.riskObj.symRiskClassification == "Declined")
			comp.riskObj.riskClassification = "Declined";
		else if(comp.riskObj.symRiskClassification == "Referred" || comp.riskObj.riRiskClassification == "Referred")
			comp.riskObj.riskClassification = "Referred";
		else
			comp.riskObj.riskClassification = "Standard";
		comp.setRiskClassification(comp);
		comp.emitRiskClass(comp);*/
    }

    setRiskClassification(comp) {
        if (comp.riskObj.symRiskClassification != null && comp.riskObj.symRiskClassification != "" && (comp.riskObj.symRiskClassification == "Referred" || comp.riskObj.symRiskClassification == "Declined")) {
            comp.riskObj.riskClassificationReason = "System marked as " + comp.riskObj.symRiskClassification;
        }
        else if (comp.riskObj.riRiskClassification != null && comp.riskObj.riRiskClassification != "" && comp.riskObj.riRiskClassification == "Referred") {
            comp.riskObj.riskClassificationReason = "System marked as " + comp.riskObj.riRiskClassification;
        }
        else {
            if (comp.riskObj.riskClassificationReason != null && comp.riskObj.riskClassificationReason != "" && (comp.riskObj.riskClassificationReason != "System marked as Standard" && comp.riskObj.riskClassificationReason.indexOf("System marked as ") != -1)) {
                comp.riskObj.riskClassificationReason = "";
            }
        }
    }

    resetFI(value) {
        if (value == "Y")
            this.riskObj.financialInterest = new FinancialInterest();
        else
            this.riskObj.financialInterest = null;
    }

    handleError(response, status, errorText, prms) {
        prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, response.responseJSON.faultstring.text, -1));
    }

    private onTextChange(ev) {
        if (ev.target.value == ' ') {
            ev.target.value = '';
        }
    }

    onKeyPressHandler(ev) {
        if (ev.keyCode == 13 || ev.target.value.length == 47) {
            this.setFocusToNext(ev.target);
        } else if (ev.keyCode == 32) {
            ev.target.value = ev.target.value.trim();
        }
    }

    setFocusToNext(elmnt) {
        let locationElmnts = jQuery(this.el).find("input");
        jQuery(locationElmnts[locationElmnts.index(elmnt) + 1]).focus();
    }

    resetSurvey(value) {
        if ("Y" == value) {
            this.riskObj.survey = new Survey();
        }
        else {
            this.riskObj.survey = null;
        }
    }

    resetRelatedCase(value) {
        if ("Y" == value) {
            this.riskObj.relatedCases = new FireRelatedCases();
        }
        else {
            this.riskObj.relatedCases = null;
            this.riskObj.relatedSumInsured = 0;
        }
    }

    resetExtRate(value) {
        if ((this.headerInfo.VPMSProduct == "Y" || this.headerInfo.firePostingScreen == 'NEW') && this.riskObj.riskCoverageDetails.riskCoverage.length > 0) {
            this.resetAllPremiumInfo(event, this.riskObj.riskCoverageDetails.riskCoverage);
        }
        this.triggerMulSelListern();
    }

    triggerMulSelListern() {
        this.multiSelectListern.value = new Date().getTime();
    }

    setExtRate(selectedClauseDetail: RateableClassCodeDetail[], coverItem) {
        let total = 0;
        for (let clauseDetail of selectedClauseDetail) {
            if (clauseDetail.isPercent && clauseDetail.isPercent == "Y") {
                let _rate = parseFloat("" + coverItem.rate) * parseFloat("" + clauseDetail.rate) / 100;
                total = total + _rate;
            }
            else
                total = total + ((clauseDetail.rate != "") ? parseFloat(clauseDetail.rate) : 0);
        }
        coverItem.extRate = numeral(total).format(this.rateFormat);
        this.resetTotal();
    }

    setReferredFromUI(riskClass) {
        this.riskObj.riskClassification = riskClass;
        this.emitRiskClass(this);
    }

    emitRiskClass(comp) {
        comp.onRiskClsChange.emit("");
    }

    setIdentity(isIdentityChange) {
        if (isIdentityChange == true && (this.riskObj.identityFiller == null || this.riskObj.identityFiller == "")) {
            if (this.riskObj.situation1 != null) {
                this.riskObj.identity = this.riskObj.situation1.slice(0, 15);
                this.riskObj.identityFiller = this.riskObj.situation1.slice(0, 15);
            }
        }
        else {
            if (isIdentityChange == false && this.riskObj.situation1 != null) {
                this.riskObj.identity = this.riskObj.situation1.slice(0, 15);
                this.riskObj.identityFiller = this.riskObj.situation1.slice(0, 15);
            }
            else if (this.riskObj.identityFiller != null)
                this.riskObj.identity = this.riskObj.identityFiller.slice(0, 15);
        }
    }

    setRIMethod(val) {

        this.riskObj.RIMethod = (val == "Yes") ? "8" : this.riskObj.RIMethodSys;

        if (this.isUnderWriter == "Y" || val == "Yes")
            this.riskObj.isRIOverWrittenByUW = "Y";
        else if (val == "No") {
            this.riskObj.isRIOverWrittenByUW = "N";
            this.validateSumInsured();
        }
        this._riService.setRI().subscribe();
    }

    // setFinalSI(){
    // this.riskObj.capitalSumInsured = this.riskObj.totalSI;
    // }

    onRatingFlagChange(eVal) {

        this.reInitialiseCoverageItems();
        this.onRtngFlgChange.emit("");
    }

    onRateBasisChange(ev) {
        this.riskObj.rateBasis = ev.target.value;
        // this.riskObj.rateBasisName = ev.record.DESCRIPTION;		

        this.reInitialiseCoverageItems();
    }

    reInitialiseCoverageItems() {
        let rateBasis = this.riskObj.rateBasis;
        let ratingFlag = this.riskObj.ratingFlag;
        this.disableRate = (this.riskObj.ratingFlag == 'M' || this.riskObj.rateBasis == 'G' || this.riskObj.rateBasis == 'S' || this.riskObj.rateBasis == 'L') ? 'N' : 'Y';

        let riskCoverageItemsArr: any = [];
        if (Array.prototype.isPrototypeOf(this.riskObj.riskCoverageDetails.riskCoverage)) {
            riskCoverageItemsArr = this.riskObj.riskCoverageDetails.riskCoverage;
        } else {
            riskCoverageItemsArr = [this.riskObj.riskCoverageDetails.riskCoverage];
        }
        if (riskCoverageItemsArr.length > 0) {
            this.riskObj.riskCoverageDetails.riskCoverage = [];
            for (let _coverItem of riskCoverageItemsArr) {
                this.riskObj.riskCoverageDetails.riskCoverage.push(_coverItem);
            }
        }
        if (this.headerInfo.VPMSProduct == "Y" || this.headerInfo.firePostingScreen == 'NEW') {
            this.resetAllPremiumInfo("", "");
        } else {
            this.resetTotal();
        }
    }

    validateTextInput(ev) {
        let eVal = ev.target.value;
        ev.target.value = eVal.replace(/\s\s+/g, ' ');
    }

    addXT(coverItem) {
        var dialogData = new ExtraTextDialogData("ExtraTextDialogComponent", "app/bms/components/proposal/newbusinessrisks/dialogs/extratext.dialog.module", "ExtraTextDialogModule", "Extra Text", "ExtraText", "fa fa-comment", coverItem, this.extraTextCallBack);
        this.openExtraTextCommentsDialog(dialogData);
    }

    public openExtraTextCommentsDialog(dialogData: ExtraTextDialogData, response?: any) {
        let lookup = new ModalInput();
        lookup.component = [dialogData.component, dialogData.moduleAbsPath, dialogData.moduleName];
        lookup.datainput = {
            dialogName: dialogData.dialogName,
            areCommentsMandatory: false,
            coverageItem: dialogData.coverageItem
        };
        lookup.outputCallback = dialogData.callBackHandler;
        lookup.parentCompPRMS = {
            comp: this,
            response: response
        };
        lookup.heading = dialogData.dialogTitle;
        lookup.icon = dialogData.icon;
        lookup.containerRef = this.contentArea;
        this.dcl.openLookup(lookup);
    }

    private extraTextCallBack(data, prms) {
        if (data.isDialogCancelled) {
            return;
        } else if (!data.isDialogCancelled && data.coverageItem && data.coverageItem.extraText) {
        }
    }

    setHoverForAllCover() {
        let _elIdx = 0;
        for (let _coverItem of this.riskObj.riskCoverageDetails.riskCoverage) {
            this.setHoverForCover(_elIdx, _coverItem.PIAMCodeDesc);
            _elIdx++;
        }
    }

    setHoverForCover(elIdx, coverVal) {
        let _el = jQuery("input[id='hhoCoverItem" + elIdx + "']");
        if (_el) {
            _el.popover();
            _el.attr("data-content", coverVal);
        }
    }

    sortArray(arryObjs, name) {
        if (arryObjs.length > 0) {
            arryObjs.sort(function (obj1, obj2) {
                if (obj1[name] < obj2[name]) {
                    return -1;
                } else if (obj1[name] > obj2[name]) {
                    return 1;
                } else {
                    return 0;
                }
            });
        }
    }

    setRIMethodEditableFlag() {
        let _totalSI = parseFloat("" + this.riskObj.totalSI);
        let _totalGrossCapacity = parseFloat("" + this.riskObj.totalGrossCapacity);
        if (_totalGrossCapacity > 0 && _totalSI > _totalGrossCapacity && this.isUnderWriter == "N") {
            this.isRIMethodEditable = "N";
        }
        else {
            this.isRIMethodEditable = "Y";
        }
    }

	/*onClausesEmit(eVal){
		if(eVal){
			let filterTpLimitNodes = this.lovDropDownService.lovDataList.tpLimit.filter((_item)=> _item.SCLS == eVal);
			if(filterTpLimitNodes && filterTpLimitNodes.length > 0){
				this.riskObj.increasedTPLimitToSI = 0
				this.resetTotal();
			}			
		} else {
			let firstClauseCode = '';
			let tpLimitVal = ''
			for(let _tpLimit of this.lovDropDownService.lovDataList.tpLimit){
				let _clauseCode = _tpLimit.SCLS;
				if(this.riskObj.clauses && this.riskObj.clauses.clause && this.riskObj.clauses.clause.length > 0){
					let _clsNodes = this.riskObj.clauses.clause.filter((_item)=> _item.clauseCode == _clauseCode);
					if(_clsNodes && _clsNodes.length > 0){
						firstClauseCode = _clauseCode;
						tpLimitVal = _tpLimit.SUMINSURED;
						break;
					}
				}
			}
			
			if(firstClauseCode){
				this.riskObj.increasedTPLimitToSI = parseInt(""+tpLimitVal);
				this.resetTotal();
			}
		}
		
	}*/

    // SAF MYS-2018-1249 start
    setPerilsRate(perilRate) {
        this.riskObj.perilsRate = perilRate;
    }

    resetPerilRate(perilRate: number) {
        if (this.riskObj.riskCoverageDetails.riskCoverage.length > 0) {
            this.resetAllPremiumInfo(event, this.riskObj.riskCoverageDetails.riskCoverage);
        }
        this.triggerMulSelListern();
        //this.resetTotal();
    }
    setPerilRate(selectedPerilDetail: PerilDetail[], coverItem) {
        let total = 0;
        for (let clauseDetail of selectedPerilDetail) {
            total = total + parseFloat(clauseDetail.perilRate);
        }
        coverItem.perilRate = numeral(coverItem.perilRate).format(this.rateFormat);
        if (!isNaN(total) && total != coverItem.perilRate) {
            coverItem.perilRate = numeral(total).format(this.rateFormat);
        }
        this.resetTotal();
    }

    onClickPerilItem(selectedPerilItem, coverItem, perilCodes) {
        let elmnt: any = selectedPerilItem.target;
        if (elmnt.value != undefined && elmnt.value != "") {
            let selectedItem: PerilDetail = perilCodes.find(_item => _item.perilCode == elmnt.value);
            if (selectedItem != undefined && selectedItem.perilCode == elmnt.value && elmnt.checked == true) {
                selectedItem.nominatedSumInsured = numeral(selectedItem.nominatedSumInsured).value() + numeral(coverItem.sumInsured).value();
                selectedItem.nominatedSumInsuredNew = selectedItem.nominatedSumInsured;
                if (selectedItem.coverItems == undefined || selectedItem.coverItems.toString() == "") {
                    selectedItem.coverItems = [];
                } else if (!Array.prototype.isPrototypeOf(selectedItem.coverItems)) {
                    let temp: any = [selectedItem.coverItems];
                    selectedItem.coverItems = temp;
                }
                selectedItem.coverItems.push(coverItem.seqNumber.toString());
            } else if (selectedItem != undefined && selectedItem.perilCode == elmnt.value && elmnt.checked == false) {
                let tempSI = (numeral(selectedItem.nominatedSumInsured).value() != numeral(selectedItem.nominatedSumInsuredNew).value()) ? numeral(selectedItem.nominatedSumInsuredNew).value() : numeral(selectedItem.nominatedSumInsured).value();
                if (tempSI > 0) {
                    selectedItem.nominatedSumInsured = numeral(tempSI).value() - numeral(coverItem.sumInsured).value();
                    selectedItem.nominatedSumInsuredNew = selectedItem.nominatedSumInsured;
                }
                selectedItem.coverItems = (selectedItem.coverItems == undefined || selectedItem.coverItems.toString() == "") ? [] : selectedItem.coverItems;
                if (!Array.prototype.isPrototypeOf(selectedItem.coverItems)) {
                    let temp: any = [selectedItem.coverItems];
                    selectedItem.coverItems = temp;
                }
                selectedItem.coverItems = selectedItem.coverItems.filter((item) => item != coverItem.seqNumber);
            }
            if (this.riskObj.ratingFlag == 'M' || this.headerInfo.VPMSProduct != "Y") {
                selectedItem.amount = (numeral(selectedItem.nominatedSumInsured).value() > 0) ? numeral((numeral(selectedItem.nominatedSumInsured).value() * parseFloat(selectedItem.perilRate)) / 100).format(this.premiumFormat) : 0;
            } else {
                selectedItem.amount = numeral(0).format(this.premiumFormat);
            }
            selectedItem.unFormattedAmount = numeral().unformat(selectedItem.amount);
            if (this.riskObj.ratingFlag != 'M' && this.headerInfo.VPMSProduct == "Y") {
                this.riskObj.riskCoverageDetails.riskCoverage.forEach(item => {
                    item.rate = numeral(0).format(this.premiumFormat);
                    //item.totalRate = numeral(0).format(this.premiumFormat);
                    item.premium = numeral(0).format(this.premiumFormat);
                    this.setPremium(item);
                });
            }
        }
    }

    onClickRCItem(selectedRCItem, coverItem, rcCodes) {
        let elmnt: any = selectedRCItem.target;
        if (elmnt.value != undefined && elmnt.value != "") {
            let selectedItem: RateableClassCodeDetail = rcCodes.find(_item => _item.classCode == elmnt.value);
            if (selectedItem != undefined && selectedItem.classCode == elmnt.value && elmnt.checked == true) {
                selectedItem.nominatedSumInsured = numeral(selectedItem.nominatedSumInsured).value() + numeral(coverItem.sumInsured).value();
                selectedItem.nominatedSumInsuredNew = selectedItem.nominatedSumInsured;
                if (selectedItem.coverItems == undefined || selectedItem.coverItems.toString() == "") {
                    selectedItem.coverItems = [];
                } else if (!Array.prototype.isPrototypeOf(selectedItem.coverItems)) {
                    let temp: any = [selectedItem.coverItems];
                    selectedItem.coverItems = temp;
                }
                selectedItem.coverItems.push(coverItem.seqNumber.toString());
            } else if (selectedItem != undefined && selectedItem.classCode == elmnt.value && elmnt.checked == false) {
                let tempSI = (numeral(selectedItem.nominatedSumInsured).value() != numeral(selectedItem.nominatedSumInsuredNew).value()) ? numeral(selectedItem.nominatedSumInsuredNew).value() : numeral(selectedItem.nominatedSumInsured).value();
                if (tempSI > 0) {
                    selectedItem.nominatedSumInsured = numeral(tempSI).value() - numeral(coverItem.sumInsured).value();
                    selectedItem.nominatedSumInsuredNew = selectedItem.nominatedSumInsured;
                }
                selectedItem.coverItems = (selectedItem.coverItems == undefined || selectedItem.coverItems.toString() == "") ? [] : selectedItem.coverItems;
                if (!Array.prototype.isPrototypeOf(selectedItem.coverItems)) {
                    let temp: any = [selectedItem.coverItems];
                    selectedItem.coverItems = temp;
                }
                selectedItem.coverItems = selectedItem.coverItems.filter((item) => item != coverItem.seqNumber);
            }
            if (this.riskObj.ratingFlag == 'M' || this.headerInfo.VPMSProduct != "Y") {
                selectedItem.amount = (selectedItem != undefined && numeral(selectedItem.nominatedSumInsured).value() > 0) ? numeral((numeral(selectedItem.nominatedSumInsured).value() * parseFloat(selectedItem.rate)) / 100).format(this.premiumFormat) : 0;
            } else {
                selectedItem.amount = numeral(0).format(this.premiumFormat);
            }
            selectedItem.unFormattedAmount = numeral().unformat(selectedItem.amount);
            if (this.riskObj.ratingFlag != 'M' && this.headerInfo.VPMSProduct == "Y") {
                this.riskObj.riskCoverageDetails.riskCoverage.forEach(item => {
                    item.rate = numeral(0).format(this.premiumFormat);
                    //item.totalRate = numeral(0).format(this.premiumFormat);
                    item.premium = numeral(0).format(this.premiumFormat);
                    this.setPremium(item);
                });
            }
        }
    }

    setWCClausesRate(wcRate) {
        this.riskObj.wcRate = wcRate;
        //this.resetTotal();
        if (this.riskObj.riskCoverageDetails.riskCoverage.length > 0) {
            this.resetAllPremiumInfo(event, this.riskObj.riskCoverageDetails.riskCoverage);
        }
    }

    private clearAllClausesData(flag) {
        let selectedPItems = ("ClearAll" == flag) ? this.riskObj.perils.peril : this.riskObj.perils.peril.filter(function (val) { return val.nature != '**'; });
        this.resetAllClausesInfo(selectedPItems, flag);
        let selectedRItems = ("ClearAll" == flag) ? this.riskObj.rateableClassCode.rateableClassCode : this.riskObj.rateableClassCode.rateableClassCode.filter(function (val) { return val.nature != '**'; });
        this.resetAllClausesInfo(selectedRItems, flag);
        let selectedWCItems = ("ClearAll" == flag) ? this.riskObj.warrantyClassCodes.warrantyClassCode : this.riskObj.warrantyClassCodes.warrantyClassCode.filter(function (val) { return val.nature != '**'; });
        this.resetAllClausesInfo(selectedWCItems, flag);

        //reset clauses data.
        for (let cover of this.riskObj.riskCoverageDetails.riskCoverage) {
            if (JSON.stringify(cover.perilClassCodes) != JSON.stringify("") && cover.perilClassCodes.peril != undefined) {
                let selectedPItems = ("ClearAll" == flag) ? cover.perilClassCodes.peril : cover.perilClassCodes.peril.filter(function (val) { return val.nature != '**' });
                this.clearAllClausesInfo(selectedPItems, flag, cover);
            }
            if (JSON.stringify(cover.rateableClassCodes) != JSON.stringify("") && cover.rateableClassCodes.rateableClassCode != undefined) {
                let selectedRItems = ("ClearAll" == flag) ? cover.rateableClassCodes.rateableClassCode : cover.rateableClassCodes.rateableClassCode.filter(function (val) { return val.nature != '**' });
                this.clearAllClausesInfo(selectedRItems, flag, cover);
            }
            if (JSON.stringify(cover.wcClassCodes) != JSON.stringify("") && cover.wcClassCodes.warrantyClassCode != undefined) {
                let selectedWCItems = ("ClearAll" == flag) ? cover.wcClassCodes.warrantyClassCode : cover.wcClassCodes.warrantyClassCode.filter(function (val) { return val.nature != '**' });
                this.clearAllClausesInfo(selectedWCItems, flag, cover);
            }

        }
    }

    private resetAllClausesInfo(selectedItems: any, flag: any) {
        if (selectedItems != undefined) {
            for (let item of selectedItems) {
                item.nominatedSumInsured = 0;
                if ("SIChanged" != flag) {
                    item.nominatedSumInsuredNew = item.nominatedSumInsured;
                    item.amount = "0.00";
                    item.unFormattedAmount = 0;
                    item.coverItems = [];
                }
            }
        }
    }

    private clearAllClausesInfo(selectedItems: any, flag: any, cover: RiskCoverage) {
        if (selectedItems != undefined) {
            for (let item of selectedItems) {
                item.rate = (item.rate != "") ? item.rate : 0;
                let rateVal = (item.perilRate != undefined) ? item.perilRate : item.rate;
                if ("SIChanged" != flag) {
                    if (!Array.prototype.isPrototypeOf(item.coverItems)) {
                        item.coverItems = new AppUtil().getArray(item.coverItems);
                    }
                    item.coverItems.push(cover.seqNumber.toString());
                }
                item.nominatedSumInsured = numeral(item.nominatedSumInsured).value() + numeral(cover.sumInsured).value();
                item.nominatedSumInsuredNew = item.nominatedSumInsured;
                if (this.riskObj.ratingFlag == 'M' || this.headerInfo.VPMSProduct != "Y") {
                    item.amount = (numeral(item.nominatedSumInsured).value() > 0) ? numeral((numeral(item.nominatedSumInsured).value() * parseFloat(rateVal)) / 100).format(this.premiumFormat) : 0;
                }
                else {
                    item.amount = numeral(0).format(this.premiumFormat);
                }
                item.unFormattedAmount = numeral().unformat(item.amount);
            }
        }
    } //End

    resetClausesInfo(coverSI: number, coverItem) {
        this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Cover " + coverItem.seqNumber + " - Sum Insured has been changed and All Clauses's data will be refereshed.", 5000));
        this.clearAllClausesData("SIChanged");
        this.resetTotal();
    }

    public getQuote() {
        ProgressBarComponent.show('Premium Calculation is in Progress', { dialogSize: 'm', progressType: 'primary' });
        this._appObjService.saveData().subscribe((data) => this.calculate(this.riskObj));
    }

    public calculate(eachRisk) {
        let caseID = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.caseId;
        let respProm = this._soapService.callCordysSoapService("CalculatePremiumProcessFireVPMS", "http://schemas.insurance.com/businessobject/1.0/",
            { caseId: caseID, riskno: eachRisk.riskNumber, requestType: "", vpmsReqId: "1" }
            , null, null, false, null);
        respProm.success((response) => {
            //debugger;
            let caseInfo = BMSConstants.getBMSCaseInfo();
            caseInfo.lastModifiedOn = response.success.ApplicationBusinessObject.caseInfo.lastModifiedOn;
            let tempRiskObjs = response.success.ApplicationBusinessObject.businessObject.bms.newBusiness.risks.s4846;//BMSConstants.getRisks().getRisksByPriority();
            let currentObj: S4846;
            if (tempRiskObjs.length > 1) {
                for (let i = 0; i < tempRiskObjs.length; i++) {
                    if (tempRiskObjs[i].riskNumber == eachRisk.riskNumber) {
                        currentObj = tempRiskObjs[i];
                        break;
                    }
                }
            } else {
                currentObj = response.success.ApplicationBusinessObject.businessObject.bms.newBusiness.risks.s4846;
            }
            this.riskObj = this.riskObj.refershRiskObj(currentObj);

            this.riskObj.riskCoverageDetails = this.riskObj.riskCoverageDetails.refreshRiskCoverageDetails(this.riskObj.riskCoverageDetails);
            this.riskObj.rateableClassCode = this.riskObj.rateableClassCode.refreshRateableClassCode(this.riskObj.rateableClassCode);
            this.riskObj.perils = this.riskObj.perils.refreshPerils(this.riskObj.perils);
            this.riskObj.warrantyClassCodes = this.riskObj.warrantyClassCodes.refreshWarrantyClassCodes(this.riskObj.warrantyClassCodes);

            if (JSON.stringify(this.riskObj.riskCoverageDetails) != JSON.stringify("") && this.riskObj.riskCoverageDetails.riskCoverage != undefined) {
                for (let i = 0; i < this.riskObj.riskCoverageDetails.riskCoverage.length; i++) {
                    this.riskObj.clauses = this.riskObj.clauses.refreshClause(this.riskObj.clauses);
                    this.resetTotal();
                }
            }
            this._appObjService.saveData().subscribe((data) => this._alertMsgService.add(new AlertMessage(AlertMessage.SUCCESS, "Premium Calculation is completed.", 5000)));
            ProgressBarComponent.hide();
        });
        respProm.error((error) => {
            if (error.responseJSON.faultstring.text != undefined) {
                this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Premium Calculation service is down. Error occurred while getting premium calculation info." + " <br> Error Description :: <br> " + error.responseJSON.faultstring.text, -1));
            } else {
                this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Premium Calculation service is down. Error occurred while getting premium calculation info." + error, -1));
            }
            ProgressBarComponent.hide();
        });
    }

    resetAllPremiumInfo(event, coverItem) {
        if (this.headerInfo.VPMSProduct == 'Y' && this.riskObj.ratingFlag != 'M') {
            this._alertMsgService.add(new AlertMessage(AlertMessage.WARN, "Fire Cover Related Item data has been modified, please click on GetQuotation button and proceed.", 5000));
            this.riskObj.riskCoverageDetails.riskCoverage.forEach(item => {
                item.rate = numeral(0).format(this.premiumFormat);
                item.totalRate = numeral(0).format(this.premiumFormat);
                item.premium = numeral(0).format(this.premiumFormat);
                //this.setPremium(item);
                let _peril: Peril = new Peril;
                item.perilClassCodes = _peril.refreshPerils(item.perilClassCodes);
                let _rateableClause: RateableClassCode = new RateableClassCode;
                item.rateableClassCodes = _rateableClause.refreshRateableClassCode(item.rateableClassCodes);
                let _wcClause: WarrantyClassCode = new WarrantyClassCode;
                item.wcClassCodes = _wcClause.refreshWarrantyClassCodes(item.wcClassCodes);
            });
            this.riskObj.totalPremium = 0;
            this.riskObj.totalSI = 0;
            this.clearAllClausesData("ClearAll");
            this.resetTotal();
        }
        if (this.headerInfo.firePostingScreen == "NEW") {
            this.clearAllClausesData("ClearAll");
            //this.riskObj.totalSI = this.getTotalByProperty("sumInsured", this.riskObj.riskCoverageDetails.riskCoverage, null);
            this.resetTotal();
        }
    }

    //below code to add Default OB7 / OB7A clause into RatableClauses section.
    addDefaultRatableClauses(_clauseCode) {
        let request: GetLOVData = new GetLOVData();
        request.BRANCH = 'ALL';
        request.LOB = 'FIRE';
        request.BUSINESS_FUNCTION = 'NEW_BUSINESS';
        request.PRODUCT = 'ALL';
        request.OPERATION = 'ALL';
        request.FORM_NAME = 'FIRE';
        request.FORM_FIELD_NAME = 'RatableClauses';
        request.FIELD_TYPE = 'LOOKUP';
        request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        request.ADVANCE_CONFIG_XML.FILTERS = new Filter();
        request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push(
            { "@FIELD_NAME": 'DESCITEM', "@FIELD_VALUE": this.riskObj.riskType, '@OPERATION': 'STARTSWITH', '@CONDITION': 'AND' },
            { "@FIELD_NAME": 'CLAUSECODE', "@FIELD_VALUE": _clauseCode, '@OPERATION': 'EQ', '@CONDITION': 'AND' }
        );
        this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.addDefaultRCSuccessHandler, this.handleError, false, { comp: this });
    }

    addDefaultRCSuccessHandler(response, prms) {
        let ary = [];
        if (response.tuple != undefined && response.tuple != null && !Array.prototype.isPrototypeOf(response.tuple)) {
            ary = [response.tuple];
        } else if (response.tuple != undefined && response.tuple != null) {
            ary = response.tuple;
        }
        prms.comp.rateClauseComp.addClause(ary, "", true);
    }

    removeDefaultRatableClauses(clauseCode) {
        let idx = this.riskObj.rateableClassCode.rateableClassCode.map(function (item) { return item.classCode }).indexOf(clauseCode);
        if (idx != -1) {
            this.rateClauseComp.removeClause(idx);
        }
    }
    //End
}

export class AccumulationRegister {
    constructor(
        public accRegCode: string,
        public accRegDesc: string,
        public locality: string
    ) { }
}