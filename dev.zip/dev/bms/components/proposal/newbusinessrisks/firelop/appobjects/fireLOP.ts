import { Peril } from '../../appobjects/peril';
import { Clause, SpecialClauses } from '../../appobjects/clause';
import { RateableClassIndicator } from '../../appobjects/RateableClassIndicator';
import { RateableClassCode } from '../../appobjects/RateableClassCode';
import { FinancialInterest } from '../../../../../../common/components/financialinterest/appobjects/financialInterest';
import { FireItems } from '../../appobjects/fireItems';
import { CBIItems } from '../../appobjects/cbi';
import { GSTDetails } from '../../appobjects/gstDetails';
import { Survey } from '../../appobjects/survey';
import { FireRelatedCases } from '../../appobjects/relatedCase';
import { MDRisks } from './md';
import { AppUtil, ChangeImpact } from '../../../../../../common/components/utility/apputil/app.util';
import { NBRisk } from '../../../appobjects/nbrisk';
import { PostedPrem } from '../../../proposalheader/appobjects/postedprem';
import { RiskHelper } from '../../../appobjects/riskhelper';
import { ReferredReason } from '../../../proposalheader/appobjects/referredreason';
import { AccRegister } from '../../appobjects/accregister'; // AccRegister code
import { LOPValidator } from '../../../validation/lop.validator';

export class FireLOP extends RiskHelper implements NBRisk {
    public sequenceNumber: string;
    public effectiveDate: string;
    public dateOfAttachment: string;
    public contractNumber: string;
    public contractType: string;
    public riskNumber: string;
    public riskType: string;
    public ratingFlag: string = "A";
    public situation1: string;
    public situation2: string;
    public situationLine1: string;
    public situationLine2: string;
    public situationLine3: string;
    public situationLine4: string;
    public situationLine5: string;
    public situationLine6: string;
    public situationLine7: string;
    public situationLine8: string;
    public postCode: string;
    public city: string;
    public cityName: string;
    public occupationCode: string = "99";
    public occupiedAs: string;
    public RIMethod: string = "0";
    public RIMethodSys: string = "0";
    public RIRequired: string = "No";
    public riskClassification: string = "Standard";
    public riskClassificationReason: string = '';
    public symRiskClassification: string = "";
    public riRiskClassification: string = "Standard";
    public piamRiskClassification: string = "Standard";
    public PIAMCode: string;
    public PIAMCodeBREdit: string = "N";
    public PIAMDescription: string;
    public construction: string;
    public constructionName: string;
    public accumulationRegister: string;
    public locality: string;
    public RIRetentionCode: string;
    public rateBasis: string = "T";
    public rateBasisName: string = "";
    public townClass: string = "1";
    public premiumClass: string;
    public indPeriodNo: number;
    public indPeriod: string = "M";
    public timeExcessNo: string;
    public timeExcess: string;
    public basicRate: number = 0;
    public basicRateOriginal: number = 0;
    public cover100Percent: string;
    public remainingWeeksPercentage: string;
    public dwMultiplierPercentage: string;
    public totalSI: number = 0;
    public totalPremium: number = 0;
    public perils: Peril;
    public clauses: Clause;
    public rateableClassCode: RateableClassCode;
    public rateableClassIndicator: RateableClassIndicator;
    public dateTermination: string;
    public MD: string;
    public GP: string;
    public FI: string = 'N';
    public ML: string;
    public infectiousLimit: string;
    public infectiousPremium: string;
    public rate: string;
    public timeXSD1: string;
    public custSupLimit: string;
    public timeXSD2: string;
    public timeXSD3: string;
    public preventionLimit: string;
    public MI: string;
    public subTotal: string;
    public CBI: CBIItems;
    public GT: string;
    public ReSurvey: string;
    public surveyDate: string;
    public perilsRate: number = 0;
    public FEARate: number = 0;
    public surveyNumber: string;
    public terminationDate: string;
    public fireItems: FireItems;
    public financialInterest: FinancialInterest;
    public GSTDetails: GSTDetails;
    public survey: Survey;
    public relatedCases: FireRelatedCases;
    public capitalSumInsured: number = 0;
    public relatedSumInsured: number = 0;
    public isSurveyNeeded: string = "N";
    public isLeastPreferred: string = "N";
    public addRelatedCases: string = "N";
    public mdRisks: MDRisks;
    public defaultClauses: Clause;
    public minimumPremium: number = 0;
    public originalTotalPremium: number = 0;
    public postedPremium: number = 0;
    public basePostedPremiumAdj: number = 0;
    public discountedPremium: number = 0;
    public rebate: number = 0;
    public rebateAmount: number = 0;
    public GST: number = 0;// 6; //SAF MYS-2018-0629
    public gstAmount: number = 0;
    public identity: string = "";
    public identityFiller: string = "";
    public specialClauses: SpecialClauses;
    public surveyStatus: string;
    public isSurveyDisabled: string = "N";
    public surveyType: string;
    public isPOIConsidered: string = "N";
    public priority: string;
    public postedPremDetails: PostedPrem;
    public childRiskPath: string;
    public childRiskIdentity: string;
    public riskClassificationReasons: ReferredReason;
    public accRegister: AccRegister; // AccRegister code
    public gpText: string;
    public gpTextCount:string;//VK004

    public SST: number = 0; //SST Code
    public sstAmount: number = 0;//SST Code
    public SSTLiveDate: string;//SST Code
    public GSTLiveDate: string;//SST Code
    public isGSTApplicable: boolean = true;//SST Code

    constructor() {
        super();
        this.clauses = new Clause();
        this.fireItems = new FireItems();
        this.perils = new Peril();
        this.rateableClassCode = new RateableClassCode();
        this.GSTDetails = new GSTDetails();
        this.CBI = new CBIItems();
        this.relatedCases = new FireRelatedCases();
        this.mdRisks = new MDRisks();
        this.defaultClauses = new Clause();
        this.specialClauses = new SpecialClauses();
        this.riskClassificationReasons = new ReferredReason();
        this.accRegister = new AccRegister(); // AccRegister code
    }

    public getInstance(valObj: FireLOP) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
            this.perils = new Peril().getInstance(valObj.perils);
            this.clauses = new Clause().getInstance(valObj.clauses);
            this.specialClauses = new SpecialClauses().getInstance(valObj.specialClauses);
            this.rateableClassCode = new RateableClassCode().getInstance(valObj.rateableClassCode);
            this.CBI = new CBIItems().getInstance(valObj.CBI);
            this.fireItems = new FireItems().getInstance(valObj.fireItems);
            if (valObj.FI == "Y") {
                this.financialInterest = new FinancialInterest().getInstance(valObj.financialInterest);
            }
            this.GSTDetails = new GSTDetails().getInstance(valObj.GSTDetails);
            if (valObj.isSurveyNeeded == "Y") {
                this.survey = new Survey().getInstance(valObj.survey);
            }
            if (valObj.addRelatedCases == "Y") {
                this.relatedCases = new FireRelatedCases().getInstance(valObj.relatedCases);
            }
            this.mdRisks = new MDRisks().getInstance(valObj.mdRisks);
            this.defaultClauses = new Clause().getInstance(valObj.defaultClauses);
            this.riskClassificationReasons = new ReferredReason().getInstance(valObj.riskClassificationReasons);
            this.accRegister = new AccRegister().getInstance(valObj.accRegister); // AccRegister code
            if (valObj.isGSTApplicable != undefined && JSON.stringify(valObj.isGSTApplicable) != JSON.stringify("") && typeof (valObj.isGSTApplicable) == "string") {
                this.isGSTApplicable = Boolean(JSON.parse(valObj.isGSTApplicable));
            }
        }
        return this;
    }

    public getNewInstanceByCriteria(criteria: any) {
        return this;
    }

    public handleInsuredChange(changeImpact: ChangeImpact) {
        this.mdRisks.clearMDRisk(changeImpact);
    }

    public handleInceptionChange(changeImpact: ChangeImpact) {
        this.mdRisks.clearMDRisk(changeImpact);
    }

    public getValidator() {
        return new LOPValidator(this);
    }
}