import { AppUtil, ChangeImpact, ItemChange } from '../../../../../../common/components/utility/apputil/app.util';

export class MDRisks {
    public mdRisk: MDRisk[] = [];
    public getInstance(valObj: MDRisks) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().handleArray(this, valObj, "mdRisk");
        }
        return this;
    }

    public clearMDRisk(changeImpact: ChangeImpact) {
        if (this.mdRisk.length > 0) {
            this.mdRisk = [];
            let itmChange: ItemChange = new ItemChange();
            itmChange.item = "Material Damage";
            itmChange.itemChanged = true;
            itmChange.message = "Material Damage risks list is cleared.";
            changeImpact.itemChanged.push(itmChange);
            changeImpact.isChanged = true;
        }
    }
}

export class MDRisk {
    public mdRisk: string = "";
    public riskNo: string = "";
    public riskType: string = "";
}