/* 
 *
 * Change History:		
 * 
 * No      Date				Description												Changed By
 * ====    ==========		===========												==========
 * 
 * SR001   11/01/2019		MYS-2018-0211 : To enhancement the filtering criteria		VSR
 * 							for Fire Accum Code & Prompt message
 * 
 * SR002   18/01/2019		MYS-2018-0682 : HD Log: POI Date not passed correctly to	VSR
 * 							check as Referred Risk for Fire products in BMS * 
 * 
 * SU001   12/07/2019		MYS-2019-0772 -- Unable to edit Basic Rate field 	        MSU
 * 							when Base Rate is Tariff in BMS
 * 
 *  YPK001 23/09/2019       MYS-2019-0675 Document Validation for Co-outwards            PKU1
 *                         case before sending to PPHO			
 */

import { Component, OnInit, ViewChild, ElementRef, EventEmitter, AfterViewInit, ViewContainerRef } from '@angular/core';
import { DCLInput, CustomDCLService } from '../../../../../common/services/customdcl.service';
import { FireLOP } from './appobjects/fireLOP';
import { MDRisks } from './appobjects/md';
import { LOV_Field, LOVDropDownService, SearchFilter } from "../../../../../common/services/lovdropdown/lovdropdown.service";
import { FireCoverageComponent } from '../uimodules/firecoverage.component';
import { PerilsComponent } from "../uimodules/perils.component";
import { RateableClausesComponent } from "../uimodules/rateableclause.component";
import { RateableClassCode } from "../appobjects/rateableClassCode";
import { Peril } from "../appobjects/peril";
import { Clause } from "../appobjects/clause";
import { FireItems } from '../appobjects/fireItems';
import { CordysSoapWService } from "../../../../../common/components/utility/cordys-soap-ws";
import { GetLOVData, SearchAdvancedConfig, Filter } from '../../../../../common/components/utility/search/search.requests';
import { RelatedCaseComponent } from "../uimodules/relatedcase.component";
import { CBIItems } from '../appobjects/cbi';
import { ClientDetails } from '../../../../../common/components/client/appobjects/client';
import { ProposalHeader } from '../../proposalheader/appobjects/proposalheader';
import { FireRelatedCases, RelatedCases } from '../appobjects/relatedCase';
import { Survey } from '../appobjects/survey';
import { AlertMessagesService } from '../../../../../common/components/utility/alertmessage/alertmessages.service';
import { AlertMessage } from '../../../../../common/components/utility/alertmessage/alertmessages.model';
import { FinancialInterest } from '../../../../../common/components/financialinterest/appobjects/financialInterest';
import { AppUtil } from '../../../../../common/components/utility/apputil/app.util';
import { CaseInfo } from '../../../../../common/components/appobjects/caseinfo';
import { BMSConstants } from '../../../common/constants/bms_constants';
import { ModalInput } from "../../../../../common/components/utility/modal/modal";
import { RiskClassificationService } from "../services/riskcls.service"; // added code for AccRegister
import { AccRegister } from '../appobjects/accregister';
import { BMSAppObjService } from '../../../../services/bmsappobj.service';
import { RIService } from '../services/ri.service';
import { BMSUtilService } from '../../../../services/bms.util.service';
import { ActivatedRoute } from '@angular/router';
import { ClausesComponent } from '../uimodules/clauses.component';

declare var jQuery: any;
declare var moment: any;
declare var numeral: any;

@Component({
    selector: 'firelop-component',
    templateUrl: 'app/bms/components/proposal/newbusinessrisks/firelop/firelop.template.html',
    inputs: ["riskObj", 'clientDetails', "headerInfo", "caseInfo"],
    outputs: ["onPremiumChange", "onRiskClsChange", "onRtngFlgChange"],
    providers: [RiskClassificationService]// added code for AccRegister
})
export class FireLOPRiskComponent implements OnInit {
    private el: HTMLElement;
    private covInfoCollapse: boolean = false;
    private popInfoCollapse: boolean = false;
    private clCBIInfoCollapse: boolean = true;
    private surInfoCollapse: boolean = false;
    private relatedCollapse: boolean = false;
    private accRegisterInfoCollapse: boolean = false;
    private mdCollapse: boolean = false;
    public riskObj: FireLOP;
    public AccRegList: AccumulationRegister[];
    public clientDetails: ClientDetails;
    public headerInfo: ProposalHeader;
    public clientId: string = "";
    public caseInfo: CaseInfo;
    public rateFormat: string = "0.00000";
    public thiscomp: any;
    public isAssessment: boolean = false;
    public emailType: string;
    public tempSysReferred: boolean;
    public tempAccuSysReferred: boolean;

    public leastPreferredRI = ['D1E1', 'D1E2', 'D1E3', 'D2E1', 'D2E2', 'D2E3', 'D3E1', 'D3E2', 'D3E3'];
    public maxSIForSurvey = { "D1A1": "10000000", "D1A2": "10000000", "D1A3": "6000000", "D1B1": "10000000", "D1B2": "10000000", "D1B3": "6000000", "D1C1": "10000000", "D1C2": "10000000", "D1C3": "6000000", "D1D1": "10000000", "D1D2": "8000000", "D1D3": "6000000", "D1E1": "5000000", "D1E2": "5000000", "D1E3": "5000000" };

    @ViewChild(ClausesComponent) private clausesComp: ClausesComponent;
    @ViewChild(FireCoverageComponent) coverComp: FireCoverageComponent;
    @ViewChild(PerilsComponent) private perilsComp: PerilsComponent;
    @ViewChild(RelatedCaseComponent) relatedComp: RelatedCaseComponent;
    @ViewChild(RateableClausesComponent) rateClauseComp: RateableClausesComponent;
    onPremiumChange = new EventEmitter<any>();
    onRiskClsChange = new EventEmitter<any>();
    onRtngFlgChange = new EventEmitter<any>();

    public accRegCtrl: any;
    private isGeneralPageCollapsed: boolean = false;

    @ViewChild('fireLopModal', { read: ViewContainerRef }) contentArea: ViewContainerRef;

    constructor(private lovDropDownService: LOVDropDownService, public dcl: CustomDCLService, private _soapService: CordysSoapWService, public _alertMsgService: AlertMessagesService, el: ElementRef, public riskClassificationService: RiskClassificationService, private _appObjService: BMSAppObjService, private _riService: RIService, public _bmsUtilService: BMSUtilService, private _activatedRoute: ActivatedRoute) {
        this.el = el.nativeElement;
    }

    ngOnInit() {
        this.thiscomp = this;
        this.populateLOVs();
        this.handleReAssessment();

        // AccRegister code
        if (this.riskObj.accRegister == undefined) {
            this.riskObj.accRegister = new AccRegister();
        } else {
            this.tempSysReferred = this.riskObj.accRegister.isSystemReferred;
            this.tempAccuSysReferred = this.riskObj.accRegister.isAccuSystemReferredFlag;
        }

        //SST Code
        //if(this.riskObj.GST == 0 || this.riskObj.SST == 0) {
        if (["MyTasks", "MyDrafts"].indexOf(this._activatedRoute.snapshot.params['component']) >= 0 || Object.keys(this._activatedRoute.snapshot.params).length == 0) {
            let respObj = this._bmsUtilService.getTAXDetails();
            if (respObj != undefined && respObj != "") {
                this.headerInfo.SSTTaxRate = Number(respObj[0].old.ITEMPF.GST);
                this.headerInfo.GSTTaxRate = Number(respObj[1].old.ITEMPF.GST);

                this.riskObj.SST = Number(this.headerInfo.SSTTaxRate);
                this.riskObj.GST = Number(this.headerInfo.GSTTaxRate);
            }
            if (isNaN(parseInt(this.riskObj.postCode))) {
                this.riskObj.SST = Number(0);
                this.headerInfo.SSTTaxRate = this.riskObj.SST;
            }

            this.headerInfo = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo;
            this.riskObj.SSTLiveDate = (this.riskObj.SSTLiveDate == undefined) ? this.headerInfo.SSTLiveDate : this.riskObj.SSTLiveDate;
            if (this.riskObj.SSTLiveDate == undefined || this.riskObj.SSTLiveDate == "") {
                let tempRespObj = this._bmsUtilService.getLiveDate();
                this.riskObj.GSTLiveDate = tempRespObj[0].old.ITEMPF.LIVEDATE;
                this.riskObj.SSTLiveDate = tempRespObj[1].old.ITEMPF.LIVEDATE;
                if (this.headerInfo.SSTLiveDate == undefined || this.headerInfo.SSTLiveDate == "") {
                    this.headerInfo.SSTLiveDate = this.riskObj.SSTLiveDate;
                }
                if (this.headerInfo.GSTLiveDate == undefined || this.headerInfo.GSTLiveDate == "") {
                    this.headerInfo.GSTLiveDate = this.riskObj.GSTLiveDate;
                }
            }
            if (moment(this.headerInfo.effectiveDate, "YYYY-MM-DD").format("YYYYMMDD") >= moment(this.riskObj.SSTLiveDate, "YYYY-MM-DD").format("YYYYMMDD")) {
                this.riskObj.isGSTApplicable = false;
            } else {
                this.riskObj.isGSTApplicable = true;
            }
        }
        //End

    }

    /*  ngAfterViewInit (){
         this.setBasicRate();
     }
      */

    //START YPK001
    ngAfterViewInit() {
        let rIndex = 0;
        if ((this.headerInfo.CoInsurance == 'Y' && this.riskObj.riskNumber == '1') && (["MyTasks", "MyDrafts"].indexOf(this._activatedRoute.snapshot.params['component']) >= 0 || Object.keys(this._activatedRoute.snapshot.params).length == 0)) {
            if (this.headerInfo.coInsuranceDetails.coInsurance.length == 1) {
                if (!(this.headerInfo.coInsuranceDetails.coInsurance[0].coInsuranceindicator == 'L' && this.headerInfo.coInsuranceDetails.coInsurance[0].sharePercentage == '100')) {
                    rIndex = this.riskObj.clauses.clause.map(function (item) { return item.clauseCode; }).indexOf("COIN");
                    if (rIndex == -1)
                        this.setClauses(["COIN"], false);
                }
            }
            else {
                rIndex = this.riskObj.clauses.clause.map(function (item) { return item.clauseCode; }).indexOf("COIN");
                if (rIndex == -1)
                    this.setClauses(["COIN"], false);
            }
        }
    }
    setClauses(clausesList, flag) {
        if (this.clausesComp)
            this.clausesComp.addClause(clausesList, '', flag);
    }
    //END YPK001

    handleReAssessment() {
        if ((BMSConstants.getBMSObj().ApplicationBusinessObject.caseInfo.businessFunction != 'NewBusiness' && BMSConstants.getBMSObj().ApplicationBusinessObject.caseInfo.businessFunction != 'CoverNote')) {
            if (BMSConstants.getBMSObj().ApplicationBusinessObject.caseInfo.status == 'Rerate Reviewed' || BMSConstants.getBMSObj().ApplicationBusinessObject.caseInfo.status == 'Draft' || BMSConstants.getBMSObj().ApplicationBusinessObject.caseInfo.status == 'Assessment')
                this.isAssessment = true;
        } else {
            this.isAssessment = true;
        }

    }
    populateLOVs() {
        let lovRefFields = ["piamcode", "construction", "rateBasis", "constructionYearList", "sprinkler", "premiumclass", "riCode", "spClause"];
        this.lovDropDownService.createLOVDataList(lovRefFields);

        let riTypeFilterDetails = [new SearchFilter("DESCITEM", this.riskObj.riskType, "STARTSWITH", "AND")];
        let riTypeSearchFilterNodes = this.lovDropDownService.createFilter(riTypeFilterDetails);

        let lovFields = [
            new LOV_Field("ALL", "ALL", "ALL", "ALL", "ALL", "ALL", "PIAM Code", "LOOKUP", [], "DESCPF", "piamcode", null),
            new LOV_Field("ALL", "FIRE", "CLAIMS", "ALL", "NEW", "CLAIMS_FIRE", "Construction Code", "LOV", [], "DESCPF", "construction", null),
            new LOV_Field("ALL", "FIRE", "NEW BUSINESS", "ALL", "NEW", "FIRE_IDC", "RateBasis", "LOV", [], "DESCPF", "rateBasis", "setRateBasisName"),
            new LOV_Field("ALL", "FIRE", "NEW BUSINESS", "ALL", "NEW", "FIRE", "YearOfConst", "LOV", [], "DESCPF", "constructionYearList", null),
            new LOV_Field("ALL", "FIRE", "NEW BUSINESS", "ALL", "NEW", "FIRE_IDC", "Sprinkler", "LOV", [], "DESCPF", "sprinkler", null),
            new LOV_Field("ALL", "FIRE", "NEW BUSINESS", "ALL", "NEW", "FIRE_IDC", "PremiumClass", "LOV", riTypeSearchFilterNodes, "T4688", "premiumclass", null),
            new LOV_Field("ALL", "MOTOR", "NEW BUSINESS", "ALL", "NEW", "PRIVATE_MOTOR", "RI Retention Code", "LOV", [], "DESCPF", "riCode", null),
            new LOV_Field("ALL", "FIRE", "NEW_BUSINESS", "ALL", "ALL", "LOP", "SPClause", "LOV", [], "DESCPF", "spClause", "setSPClause")];

        if (this.riskObj.accumulationRegister != null && this.riskObj.accumulationRegister != "") {
            this.setAccumulationRegister();
        }
        this.lovDropDownService.util_populateLOV(lovFields, this);
    }

    setSPClause(comp) {
        comp.riskObj.specialClauses.clause = [];
        for (let clause of comp.lovDropDownService.lovDataList.spClause) {
            comp.riskObj.specialClauses.clause.push({ clauseCode: clause.CLAUSE_CODE });
        }
    }

    setAccReg(values) {
        this.riskObj.locality = values.record.locality;
        if (this.riskObj.addRelatedCases == "Y" && this.riskObj.relatedCases.relatedCases.relatedCase.length > 0) {
            this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Related cases are removed as accumulation register is changed.", -1));
        }
        if (this.relatedComp != null) {
            this.relatedComp.setAccumulationRegister(values.value);
        }

        // added code for AccRegister - start
        if (values.value == "0") {
            this.riskObj.locality = "0";
            this.tempSysReferred = this.riskObj.accRegister.isSystemReferred;
            this.tempAccuSysReferred = this.riskObj.accRegister.isAccuSystemReferredFlag;
            this.riskObj.accRegister = new AccRegister();
            this.riskObj.accRegister.isSystemReferred = this.tempSysReferred;
            this.riskObj.accRegister.isAccuSystemReferredFlag = this.tempAccuSysReferred;
            this.setReferredRiskFlag(false, "Standard", false);

            this.emailType = "1";
            let inputObj = {
                "Message": "No accumulation register for the selected postal code, Do you want to send Email to RI Treaty ?",
                "Action": ""
            };
            let input = inputObj;
            let lookup = new ModalInput().get("Confirm");
            lookup.datainput = input;
            lookup.outputCallback = this.openConfirmPopUpCallBack;
            lookup.parentCompPRMS = { comp: this };
            lookup.heading = "Confirm Send Email to RI Treaty";
            lookup.icon = "fa fa-hand-paper-o";
            lookup.containerRef = this.contentArea;
            this.dcl.openLookup(lookup);
        } else if (values.value != "" && values.value != "0") {
            this._appObjService.saveData().subscribe((data) => {
                this.callAccRegisterFunction();
            });
        }
    }

    // AccRegister code -- start
    private openConfirmPopUpCallBack(data, prms) {
        if (data.value == 'Y') {
			/*if(prms.comp.caseInfo.caseId == "" || prms.comp.caseInfo.caseId == undefined){
				prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Please Save the case before sending an Email for Accumulation Register Creation." ,8000));
				return;
			} */
            prms.comp._appObjService.saveData().subscribe((data) => {
                prms.comp.riskClassificationService.sendMailtoTreaty(prms.comp.riskObj, prms.comp.caseInfo.caseId, prms.comp.emailType);
            });
        }
    }

    private callAccRegisterFunction() {
        this._soapService.callCordysSoapService("GetCurrentExposerAccuRegister", "http://schemas.insurance.com/businessobject/1.0/",
            {
                "caseID": this.caseInfo.caseId,
                "snedmail": "",
                "AccumulationReg": this.riskObj.accumulationRegister,
                "PostCode": this.riskObj.postCode,
                "LocationCode": this.riskObj.locality,
                "TotalSI": this.riskObj.totalSI,
                "Branch": BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.servicingBranch,
                "cslAmount": "0",
                "city": this.riskObj.city
            },
            this.setAccRegisterInfoSuccess, this.setAccRegisterInfoError, true, { comp: this });
    }

    setAccRegisterInfoSuccess(response, prms) {
        if (!response.fault) {
            prms.comp.riskObj.accRegister.ExposerQuotAccepted = response.ExposerQuotAccepted.text;
            prms.comp.riskObj.accRegister.HoldCoverExposer = response.HoldCoverExposer.text;
            prms.comp.riskObj.accRegister.GAL = response.GAL.text;
            prms.comp.riskObj.accRegister.P400InforcedExposer = response.P400InforcedExposer.text;
            prms.comp.riskObj.accRegister.TotalExposer = response.TotalExposer.text;
            prms.comp.riskObj.accRegister.Outstanding = response.Outstanding.text;
            prms.comp.riskObj.accRegister.cessionOutwords = response.cessionOutwords.text;
            prms.comp.riskObj.accRegister.totalPercentage = (Number(response.TotalExposer.text) * 100) / Number(response.GAL.text);

            prms.comp.riskObj.accRegister.TOTGR = response.TOTGR.text
            prms.comp.riskObj.accRegister.TOTMNR = response.TOTMNR.text
            prms.comp.riskObj.accRegister.TOTFAC = response.TOTFAC.text
            prms.comp.riskObj.accRegister.TOTTREATY = response.TOTTREATY.text
            prms.comp.riskObj.accRegister.LIMITMNR = response.LIMITMNR.text
            prms.comp.riskObj.accRegister.LIMITFAC = response.LIMITFAC.text
            prms.comp.riskObj.accRegister.LIMITTREATY = response.LIMITTREATY.text
            prms.comp.riskObj.accRegister.LIMITNET = response.LIMITNET.text
            if (prms.comp.riskObj.accRegister.totalPercentage < 0) {
                prms.comp.riskObj.accRegister.totalPercentage = -(Number(prms.comp.riskObj.accRegister.totalPercentage));
            }

            prms.comp.riskObj.accRegister.cessionOutwordsPercentage = (Number(response.cessionOutwords.text) * 100) / Number(response.Outstanding.text);
            if (prms.comp.riskObj.accRegister.cessionOutwordsPercentage < 0) {
                prms.comp.riskObj.accRegister.cessionOutwordsPercentage = -(Number(prms.comp.riskObj.accRegister.cessionOutwordsPercentage));
            }

            // formatted values
            prms.comp.riskObj.accRegister.formattedExposerQuotAccepted = numeral(prms.comp.riskObj.accRegister.ExposerQuotAccepted).format("0,0");
            prms.comp.riskObj.accRegister.formattedHoldCoverExposer = numeral(prms.comp.riskObj.accRegister.HoldCoverExposer).format("0,0");
            prms.comp.riskObj.accRegister.formattedGAL = numeral(prms.comp.riskObj.accRegister.GAL).format("0,0");
            prms.comp.riskObj.accRegister.formattedP400InforcedExposer = numeral(prms.comp.riskObj.accRegister.P400InforcedExposer).format("0,0");
            prms.comp.riskObj.accRegister.formattedTotalExposer = numeral(prms.comp.riskObj.accRegister.TotalExposer).format("0,0");
            prms.comp.riskObj.accRegister.formattedOutstanding = numeral(prms.comp.riskObj.accRegister.Outstanding).format("0,0");
            prms.comp.riskObj.accRegister.formattedcessionOutwords = numeral(prms.comp.riskObj.accRegister.cessionOutwords).format("0,0");
            prms.comp.riskObj.accRegister.formattedGALPercentage = numeral(prms.comp.riskObj.accRegister.totalPercentage).format("00.00");
            prms.comp.riskObj.accRegister.formattedcessionOutPercentage = numeral(prms.comp.riskObj.accRegister.cessionOutwordsPercentage).format("00.00");

            prms.comp.riskObj.accRegister.formattedtotGR = numeral(prms.comp.riskObj.accRegister.TOTGR).format("0,0");
            prms.comp.riskObj.accRegister.formattedtotMNR = numeral(prms.comp.riskObj.accRegister.TOTMNR).format("0,0");
            prms.comp.riskObj.accRegister.formattedtotFAC = numeral(prms.comp.riskObj.accRegister.TOTFAC).format("0,0");
            prms.comp.riskObj.accRegister.formattedtotTREATY = numeral(prms.comp.riskObj.accRegister.TOTTREATY).format("0,0");
            prms.comp.riskObj.accRegister.formattedLimitMNR = numeral(prms.comp.riskObj.accRegister.LIMITMNR).format("0,0");
            prms.comp.riskObj.accRegister.formattedLimitFAC = numeral(prms.comp.riskObj.accRegister.LIMITFAC).format("0,0");
            prms.comp.riskObj.accRegister.formattedLimitTREATY = numeral(prms.comp.riskObj.accRegister.LIMITTREATY).format("0,0");
            prms.comp.riskObj.accRegister.formattedLimitNet = numeral(prms.comp.riskObj.accRegister.LIMITNET).format("0,0");

            prms.comp.accRegisterValidations();

        } else {
            prms.comp.tempSysReferred = prms.comp.riskObj.accRegister.isSystemReferred;
            prms.comp.tempAccuSysReferred = prms.comp.riskObj.accRegister.isAccuSystemReferredFlag;
            prms.comp.riskObj.accRegister = new AccRegister();
            prms.comp.riskObj.accRegister.isSystemReferred = prms.comp.tempSysReferred;
            prms.comp.riskObj.accRegister.isAccuSystemReferredFlag = prms.comp.tempAccuSysReferred;

            prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error while Calling Accumulation Register service.", 8000));
        }
    }

    setAccRegisterInfoError(response, status, errorText, prms) {
        prms.comp.tempSysReferred = prms.comp.riskObj.accRegister.isSystemReferred;
        prms.comp.tempAccuSysReferred = prms.comp.riskObj.accRegister.isAccuSystemReferredFlag;
        prms.comp.riskObj.accRegister = new AccRegister();
        prms.comp.riskObj.accRegister.isSystemReferred = prms.comp.tempSysReferred;
        prms.comp.riskObj.accRegister.isAccuSystemReferredFlag = prms.comp.tempAccuSysReferred;

        prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error while Calling Accumulation Register service.", 8000));
    }

    accRegisterValidations() {
        this.riskObj.accRegister.totalPercentage = 0;
        if (this.riskObj.accRegister.GAL != "0" && this.riskObj.accRegister.GAL != "") {
            this.riskObj.accRegister.totalPercentage = (Number(this.riskObj.accRegister.TotalExposer) * 100) / Number(this.riskObj.accRegister.GAL);

            if (this.riskObj.accRegister.totalPercentage >= 90 && this.riskObj.accRegister.totalPercentage <= 100) {
                if (BMSConstants.getBMSObj().ApplicationBusinessObject.caseInfo.status != "Draft") {
                    this.emailType = "2";
                    this.setReferredRiskFlag(false, "Standard", false);
                    let inputObj = {
                        "Message": "Total exposure percentage is more than 90 % against GAL, Do you want to send email to under writer?",
                        "Action": ""
                    };
                    let input = inputObj;
                    let lookup = new ModalInput().get("Confirm");
                    lookup.datainput = input;
                    lookup.outputCallback = this.openConfirmPopUpCallBack;
                    lookup.parentCompPRMS = { comp: this };
                    lookup.heading = "Confirm Send Email to Underwriter";
                    lookup.icon = "fa fa-hand-paper-o";
                    lookup.containerRef = this.contentArea;
                    this.dcl.openLookup(lookup);
                }
            } else if (this.riskObj.accRegister.totalPercentage > 100) {
                this.setReferredRiskFlag(true, "Referred", true);
                this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Total Exposure percentage is more than 100 % against GAL and Risk has been changed to Referred.", 8000));
            } else {
                if ((this.riskObj.accRegister.isSystemReferred == false) && (this.riskObj.accRegister.isAccuSystemReferredFlag == true)) {
                    this.setReferredRiskFlag(true, "Referred", true);
                } else {
                    this.setReferredRiskFlag(false, "Standard", false);
                }
            }
        } else {
            this.setReferredRiskFlag(false, "Standard", false);
        }
    }

    private setReferredRiskFlag(referredFlag, riskClassification, defaultFlag) {
        let refRiskUIFlag = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.isReferredRiskUI;
        if ((refRiskUIFlag == true || this.riskObj.accRegister.isSystemReferred == true) && (this.riskObj.accRegister.isAccuSystemReferredFlag == false)) {
            this.riskObj.accRegister.isSystemReferred = true;
            this.riskObj.accRegister.isAccuSystemReferredFlag = false;
            if (this.riskObj.accRegister.totalPercentage > 100)
                BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.isReferredToUW = 'Y'
            else
                BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.isReferredToUW = 'N'
        } else {
            this.riskObj.accRegister.isSystemReferred = false;
            this.riskObj.accRegister.isAccuSystemReferredFlag = defaultFlag;
            this.riskObj.symRiskClassification = riskClassification;
            BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.isReferredRiskUI = referredFlag;
            if (defaultFlag)
                BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.isReferredToUW = 'Y'
            else
                BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.isReferredToUW = 'N'
            this.handleRiskClassification(this);
        }
    } // AccRegister code -- End

    getPostCodeInfo(postcode) {
        this.riskObj.postCode = isNaN(parseInt(postcode)) ? postcode.toUpperCase() : postcode;
        // Accumulation register code --start
        this.tempSysReferred = this.riskObj.accRegister.isSystemReferred;
        this.tempAccuSysReferred = this.riskObj.accRegister.isAccuSystemReferredFlag;
        this.riskObj.accRegister = new AccRegister();
        this.riskObj.accRegister.isSystemReferred = this.tempSysReferred;
        this.riskObj.accRegister.isAccuSystemReferredFlag = this.tempAccuSysReferred;

        this.setReferredRiskFlag(false, "Standard", false); // End

        let request: GetLOVData = new GetLOVData().getRequest('ALL', 'FIRE', 'NEW BUSINESS', 'ALL', 'NEW', 'FIRE_IDC', 'PostCode', 'LOV');
        request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        request.ADVANCE_CONFIG_XML.FILTERS = new Filter();

        request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({ "@FIELD_NAME": 'DESCITEM', "@FIELD_VALUE": this.riskObj.postCode, '@OPERATION': 'EQ', '@CONDITION': 'AND' });
        this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.setPostCodeInfo, this.handleError, true, { comp: this, postCode: this.riskObj.postCode });
    }

    setPostCodeInfo(response, prms) {
        if (response.tuple != null) {
            prms.comp.riskObj.city = response.tuple.old.DESCPF.SHORTDESC;
            prms.comp.riskObj.cityName = response.tuple.old.DESCPF.LONGDESC;
            prms.comp.setAccRegInfo();
            prms.comp.setGSTInfo();
        }
        else {
            prms.comp.riskObj.city = "";
            prms.comp.riskObj.cityName = "";
            prms.comp.clearAccReg();
        }
    }

    setAccRegInfo() {
        this.clearAccReg();
        this.setAccumulationRegister();
    }

    clearAccReg() {
        this.riskObj.accumulationRegister = "";
        this.AccRegList = [];
        if (this.accRegCtrl != null) {
            this.accRegCtrl.setter("", this.accRegCtrl.comp);
        }
        this.setAccReg({ record: { locality: "" }, value: "" });
    }

    setGSTInfo() {
        this.setGST(this.riskObj.postCode);
    }

    setGST(postCode) {
        if (isNaN(parseInt(postCode))) {
            this.riskObj.GSTDetails.riskLocation = "OS";
            this.riskObj.GST = Number(this.headerInfo.GSTTaxRate); //0;// 6; //SAF MYS-2018-0629
            this.riskObj.SST = Number(0);//Number(this.headerInfo.SSTTaxRate); // SST code
            this.headerInfo.SSTTaxRate = this.riskObj.SST//SST Code
            this.headerInfo.GSTTaxRate = this.riskObj.GST;//SST Code
            this.resetCoverTotal();
        }
        else {
            if (this.riskObj.GST == 0 || this.riskObj.SST == 0) {
                let respObj = this._bmsUtilService.getTAXDetails();
                if (respObj != undefined && respObj != "") {
                    this.headerInfo.SSTTaxRate = Number(respObj[0].old.ITEMPF.GST);
                    this.headerInfo.GSTTaxRate = Number(respObj[1].old.ITEMPF.GST);

                    this.riskObj.SST = Number(this.headerInfo.SSTTaxRate);
                    this.riskObj.GST = Number(this.headerInfo.GSTTaxRate);
                }
            }//SST Code
            this.validateGSTForPCA(postCode);
        }
    }

    validateGSTForPCA(postCode) {
        let request: GetLOVData = new GetLOVData();
        request.BRANCH = 'ALL';
        request.LOB = 'ALL';
        request.BUSINESS_FUNCTION = 'ALL';
        request.PRODUCT = 'ALL';
        request.OPERATION = 'ALL';
        request.FORM_NAME = 'GST';
        request.FORM_FIELD_NAME = 'GST_PCA_POSTCODE';
        request.FIELD_TYPE = 'LOV';
        request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        request.ADVANCE_CONFIG_XML.FILTERS = new Filter();

        request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({ "@FIELD_NAME": 'DESCITEM', "@FIELD_VALUE": postCode, '@OPERATION': 'EQ', '@CONDITION': 'AND' });
        this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.setISPCA, this.handleError, true, { comp: this, postCode: postCode });
    }

    setISPCA(response, prms) {
        if (response.tuple != null && response.tuple.old.DESCPF.SHORTDESC != "LLB") {
            prms.comp.riskObj.GSTDetails.riskLocation = "PCA";
            prms.comp.riskObj.GST = Number(prms.comp.headerInfo.GSTTaxRate); //0;// 6; //SAF MYS-2018-0629
            prms.comp.riskObj.SST = Number(prms.comp.headerInfo.SSTTaxRate); // SST code
            if (prms.comp.riskObj.GST == 0 || prms.comp.riskObj.SST == 0) {
                let respObj = prms.comp._bmsUtilService.getTAXDetails();
                if (respObj != undefined && respObj != "") {
                    prms.comp.headerInfo.SSTTaxRate = Number(respObj[0].old.ITEMPF.GST);
                    prms.comp.headerInfo.GSTTaxRate = Number(respObj[1].old.ITEMPF.GST);

                    prms.comp.riskObj.SST = Number(prms.comp.headerInfo.SSTTaxRate);
                    prms.comp.riskObj.GST = Number(prms.comp.headerInfo.GSTTaxRate);
                }
            }
            prms.comp.resetCoverTotal();
        }// Adding below code for SAF MYS-2017-0846 -- start
        else if (response.tuple != null && response.tuple.old.DESCPF.SHORTDESC == "LLB") {
            prms.comp.riskObj.GSTDetails.riskLocation = "DA";
            prms.comp.riskObj.GST = 0;
            prms.comp.riskObj.SST = Number(0);//SST Code
            prms.comp.headerInfo.SSTTaxRate = Number(prms.comp.riskObj.SST);//SST Code
            prms.comp.headerInfo.GSTTaxRate = Number(prms.comp.riskObj.GST);//SST Code
            prms.comp.resetCoverTotal();
        } // End
        else {
            prms.comp.validateGSTForDA(prms.postCode, prms.comp)
        }
    }

    validateGSTForDA(postCode, comp) {
        let request: GetLOVData = new GetLOVData();
        request.BRANCH = 'ALL';
        request.LOB = 'ALL';
        request.BUSINESS_FUNCTION = 'ALL';
        request.PRODUCT = 'ALL';
        request.OPERATION = 'ALL';
        request.FORM_NAME = 'GST';
        request.FORM_FIELD_NAME = 'GST_DA_POSTCODE';
        request.FIELD_TYPE = 'LOV';
        request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        comp._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, comp.setISDA, comp.handleError, true, { comp: comp, postCode: postCode });
    }

    setISDA(response, prms) {
        if (response.tuple != null) {
            let postCodes = response.tuple.old.ITEMPF.POSTCODES;
            let postCodesList = postCodes.split(",");
            let hasPostCode = false;
            let isSameCode = false;
            for (let pCode of postCodesList) {
                // if (!isNaN(parseInt(pCode))) // SAF MYS-2017-0846
                if (pCode != undefined && pCode != "") {
                    hasPostCode = true;
                    if (pCode == prms.postCode) {
                        isSameCode = true;
                    }
                }
            }

            if (hasPostCode == false || isSameCode == true) {
                prms.comp.riskObj.GSTDetails.riskLocation = "DA";
                prms.comp.riskObj.GST = 0;
                prms.comp.riskObj.SST = Number(0);//SST Code
                prms.comp.headerInfo.SSTTaxRate = Number(prms.comp.riskObj.SST);//SST Code
                prms.comp.headerInfo.GSTTaxRate = Number(prms.comp.riskObj.GST);//SST Code
                prms.comp.resetCoverTotal();
            }
            else {
                prms.comp.riskObj.GSTDetails.riskLocation = "PCA";
                prms.comp.riskObj.GST = Number(prms.comp.headerInfo.GSTTaxRate); //0;// 6; //SAF MYS-2018-
                prms.comp.riskObj.SST = Number(prms.comp.headerInfo.SSTTaxRate); // SST code
                if (prms.comp.riskObj.GST == 0 || prms.comp.riskObj.SST == 0) {
                    let respObj = prms.comp._bmsUtilService.getTAXDetails();
                    if (respObj != undefined && respObj != "") {
                        prms.comp.headerInfo.SSTTaxRate = Number(respObj[0].old.ITEMPF.GST);
                        prms.comp.headerInfo.GSTTaxRate = Number(respObj[1].old.ITEMPF.GST);

                        prms.comp.riskObj.SST = Number(prms.comp.headerInfo.SSTTaxRate);
                        prms.comp.riskObj.GST = Number(prms.comp.headerInfo.GSTTaxRate);
                    }
                }
                prms.comp.resetCoverTotal();
            }
        }
    }

    resetCoverTotal() {
        if (this.coverComp != null) {
            this.coverComp.resetTotal();
        }
    }

    setAccumulationRegister() {
        let request: GetLOVData = new GetLOVData();
        request.BRANCH = 'ALL';
        request.LOB = 'FIRE';
        request.BUSINESS_FUNCTION = 'NEW BUSINESS';
        request.PRODUCT = 'ALL';
        request.OPERATION = 'NEW';
        request.FORM_NAME = 'FIRE_IDC';
        request.FORM_FIELD_NAME = 'ACCREG';
        request.FIELD_TYPE = 'LOV';
        request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        request.ADVANCE_CONFIG_XML.FILTERS = new Filter();

        request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push(
            { "@FIELD_NAME": 'ZTOWNCODE', "@FIELD_VALUE": this.riskObj.city, '@OPERATION': 'EQ', '@CONDITION': 'AND' },
            { "@FIELD_NAME": 'PCODE', "@FIELD_VALUE": this.riskObj.postCode, '@OPERATION': 'EQ', '@CONDITION': 'AND' },
            { "@FIELD_NAME": '', "@FIELD_VALUE": '', '@OPERATION': 'OPNPRNTHS', '@CONDITION': '' },
            { "@FIELD_NAME": 'ZCIDTETER', "@FIELD_VALUE": "0", '@OPERATION': 'EQ', '@CONDITION': 'OR' },
            { "@FIELD_NAME": 'ZCIDTETER', "@FIELD_VALUE": '99999999', '@OPERATION': 'EQ', '@CONDITION': 'OR' },
            { "@FIELD_NAME": 'ZCIDTETER', "@FIELD_VALUE": moment(new Date()).format("YYYYMMDD"), '@OPERATION': 'GT', '@CONDITION': '' },
            { "@FIELD_NAME": '', "@FIELD_VALUE": '', '@OPERATION': 'CLSPRNTHS', '@CONDITION': '' }
        );
        this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.setAccuRegHandler, this.handleError, true, { comp: this });
    }

    setAccuRegHandler(response, prms) {
        let ary = [];
        let currentDate = moment(new Date()).format("YYYYMMDD");
        let registerNotExpired = true;
        if (response.tuple != null && !Array.prototype.isPrototypeOf(response.tuple)) {
            ary = [response.tuple];
        }
        else if (response.tuple != null) {
            ary = response.tuple;
        }
        prms.comp.AccRegList = [];
        for (let item of ary) {
            // SR001 Added the condition to check if Acc Reg is expired or not
            if (item.old.FACM.ZCIDTETER > currentDate || item.old.FACM.ZCIDTETER == '0') {
                let accReg: AccumulationRegister = {
                    "accRegCode": item.old.FACM.FREG,
                    "accRegDesc": item.old.FACM.FDESC,
                    "locality": item.old.FACM.LOCREG
                };
                // SR001 Added below the Condition to check if the accumulation register is expired on Renewal
                if (item.old.FACM.FREG == prms.comp.riskObj.accumulationRegister) {
                    registerNotExpired = false;
                }
                prms.comp.AccRegList.push(accReg);
            }
        }
        //Added code for AccRegister --start
        let accReg: AccumulationRegister = {
            "accRegCode": "0",
            "accRegDesc": "Register Not Found",
            "locality": ""
        };
        // SR001 Added the alert if the accumulation register expires on Renewal
        if (registerNotExpired && prms.comp.riskObj.accumulationRegister != "" && prms.comp.riskObj.accumulationRegister != undefined && prms.comp.riskObj.accumulationRegister != null) {
            prms.comp.riskObj.accumulationRegister = "";
            prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Accumulation Register Expired. Please select the correct Fire Accumulation Code. ", 5000));
        }
        prms.comp.AccRegList.push(accReg);
        //End
    }

    setTownClass(value) {
        this.riskObj.townClass = value;
        this.setBasicRate();
    }

    setConstruction(value) {
        this.riskObj.construction = value;
        let evt: any = event;
        this.riskObj.constructionName = jQuery(evt.target.selectedOptions[0]).text();
        this.setBasicRate();
    }

    onModeChange(rateBasis, ratingFlag, brByPIAM) {
        if (this.perilsComp)
            this.perilsComp.evaluatePerilRateNeeded(rateBasis, ratingFlag);

        //if (rateBasis == "G" || rateBasis == "S" || rateBasis == "L" || ratingFlag == "M" || brByPIAM == "Y") {
        if (rateBasis == "V" || rateBasis == "G" || rateBasis == "S" || rateBasis == "L" || ratingFlag == "M" || brByPIAM == "Y") {
            // SU001 Added condition to make Basic Rate editable when Rate Basis is Avg Base Rate - for Tariff in BMS
            if (this.coverComp != null)
                this.coverComp.setBaseRateEnable("Y");
        }
        else {
            this.riskObj.basicRate = this.riskObj.basicRateOriginal;
            if (this.coverComp != null)
                this.coverComp.setBaseRateEnable("N");
        }
        //if(this.rateClauseComp != null)
        //this.rateClauseComp.setItEditMode(value);
    }

    setRateBasisName(comp, value) {
        let rbVal = (value == null) ? comp.riskObj.rateBasis : value;
        let rbs = comp.lovDropDownService.lovDataList.rateBasis.filter((item) => item.VALUE == rbVal);
        if (rbs.length > 0)
            comp.riskObj.rateBasisName = rbs[0].DESCRIPTION;
    }

    resetFireCoverage(clause) {
        if (this.coverComp != null) {
            this.coverComp.resetClauseRate();
        }
    }

    resetBasicRate(basicRate: number) {
        if (this.coverComp != null) {
            this.coverComp.resetBasicRate(basicRate);
        }
        if (this.rateClauseComp != null) {
            this.rateClauseComp.resetBasicRate(basicRate);
        }
    }

    resetPerilRate(perilRate: number) {
        this.riskObj.perilsRate = perilRate;
        if (this.coverComp != null) {
            this.coverComp.resetPerilRate(perilRate);
        }
    }

    setBasicRate() {
        if (this.riskObj.PIAMCode != undefined && this.riskObj.construction != undefined && this.riskObj.townClass != undefined) {
            this.riskObj.PIAMCodeBREdit = "N";
            let request: GetLOVData = new GetLOVData();
            request.BRANCH = 'ALL';
            request.LOB = 'FIRE';
            request.BUSINESS_FUNCTION = 'NEW BUSINESS';
            request.PRODUCT = 'ALL';
            request.OPERATION = 'NEW';
            request.FORM_NAME = 'FIRE_IDC';
            request.FORM_FIELD_NAME = 'Basic Rate';
            request.FIELD_TYPE = 'LOV';
            request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
            request.ADVANCE_CONFIG_XML.FILTERS = new Filter();
            //SR002 - Passed header effective date instead of Date of Attachment for Referred Risk Check
            request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({ "@FIELD_NAME": 'DESCITEM', "@FIELD_VALUE": this.riskObj.PIAMCode, '@OPERATION': 'EQ', '@CONDITION': 'AND' },
                { "@FIELD_NAME": 'CONSTRUCTIONCLS', "@FIELD_VALUE": this.riskObj.construction, '@OPERATION': 'EQ', '@CONDITION': 'AND' },
                { "@FIELD_NAME": 'TWNCLS', "@FIELD_VALUE": this.riskObj.townClass, '@OPERATION': 'EQ', '@CONDITION': 'AND' },
                { "@FIELD_NAME": 'ITMFRM', "@FIELD_VALUE": moment(this.headerInfo.effectiveDate, "YYYY-MM-DD").format("YYYYMMDD"), '@OPERATION': 'LT', '@CONDITION': 'AND' },
                { "@FIELD_NAME": 'ITMTO', "@FIELD_VALUE": moment(this.headerInfo.effectiveDate, "YYYY-MM-DD").format("YYYYMMDD"), '@OPERATION': 'GT', '@CONDITION': 'AND' });
            this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.successHandler, this.handleError, false, { comp: this });
        }
    }

    successHandler(response, prms) {
        prms.comp.riskObj.piamRiskClassification = "";
        if (response.tuple != null) {
            prms.comp.riskObj.basicRate = numeral(response.tuple.old.T8799.BASICRATE).format(prms.comp.rateFormat);
            prms.comp.riskObj.basicRateOriginal = numeral(response.tuple.old.T8799.BASICRATE).format(prms.comp.rateFormat);
            prms.comp.riskObj.piamRiskClassification = response.tuple.old.T8799.REFERREDRISK;
            if (numeral(prms.comp.riskObj.basicRate).value() < 0) {
                prms.comp.riskObj.basicRate = 0;
                prms.comp.riskObj.basicRateOriginal = 0;
            }

            //SAF MYS-2018-0143 --start
            if (!response.tuple.old.T8799.REFERREDRISK || response.tuple.old.T8799.REFERREDRISK == 'N') {
                prms.comp.riskObj.symRiskClassification = "Standard";
            }
            else if (response.tuple.old.T8799.REFERREDRISK && response.tuple.old.T8799.REFERREDRISK == 'Y') {
                prms.comp.riskObj.symRiskClassification = "Referred";
            }
            else if (response.tuple.old.T8799.REFERREDRISK && response.tuple.old.T8799.REFERREDRISK == 'D') {
                prms.comp.riskObj.symRiskClassification = "Declined";
            }
            else if (response.tuple.old.T8799.REFERREDRISK && response.tuple.old.T8799.REFERREDRISK == 'C') {
                prms.comp.riskObj.symRiskClassification = "ReferredCEO";//SAF MYS-2018-0143 
                //prms.comp.riskObj.symRiskClassification = "Referred";
            } else if (response.tuple.old.T8799.REFERREDRISK && response.tuple.old.T8799.REFERREDRISK == 'R') {
                prms.comp.riskObj.symRiskClassification = "ReferredRHC";//SAF MYS-2018-0143 
                //prms.comp.riskObj.symRiskClassification = "Referred";
            }//End

            prms.comp.setBREditByPIAM(prms.comp, response);
            prms.comp.onRIRtnChange(response.tuple.old.T8799.RIRETNCODE);
            prms.comp.resetBasicRate(prms.comp.riskObj.basicRate);
        }
    }

    setBREditByPIAM(comp, resp) {
        if (resp.tuple.old.T8799.TRDDESCR != null && (resp.tuple.old.T8799.TRDDESCR == "REFER TO ASSOCIATION" || resp.tuple.old.T8799.TRDDESCR == "UNCLASSIFIED RISK" || numeral(comp.riskObj.basicRate).value() == 0))
            comp.riskObj.PIAMCodeBREdit = "Y";
        else
            comp.riskObj.PIAMCodeBREdit = "N";

        comp.onModeChange(comp.riskObj.rateBasis, comp.riskObj.ratingFlag, comp.riskObj.PIAMCodeBREdit);
    }

    handleRiskClassification(comp) {
        comp.riskClassificationService.setRiskClassification(comp.riskObj.riskNumber, "N", "", "").subscribe();
    }

    handleError(response, status, errorText, prms) {
        prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, response.responseJSON.faultstring.text, -1));
    }

    setTotalPremium(premium) {
        this.onPremiumChange.emit(premium);
    }

    setTotalSI(si) {
        this.setFinalSI();
    }

    resetSurvey(value) {
        if ("Y" == value) {
            this.riskObj.survey = new Survey();
            this.riskObj.surveyType = "";
        }
        else {
            this.riskObj.survey = null;
            this.riskObj.surveyType = "";
        }
    }

    resetRelatedCase(value) {
        if ("Y" == value) {
            this.riskObj.relatedCases = new FireRelatedCases();
        }
        else {
            this.riskObj.relatedCases = null;
            this.riskObj.relatedSumInsured = 0;
            this.setFinalSI();
        }
    }

    setFinalSI() {
        this.riskObj.capitalSumInsured = this.riskObj.totalSI;
    }

    isLeastPreferredRI() {
        if (this.riskObj.RIRetentionCode != null) {
            if (this.leastPreferredRI.indexOf(this.riskObj.RIRetentionCode) != -1) {
                return true;
            }
        }
        return false;
    }

    setDefaultClause(piamCode) {
        this.removeDefaultClauses();
        this.getDefaultClauses(piamCode);

        // accumulationRegister code start
        if (this.riskObj.accRegister.isSystemReferred == false &&
            (this.riskObj.accRegister.isAccuSystemReferredFlag != undefined && this.riskObj.accRegister.isAccuSystemReferredFlag == true)) {
            this.setReferredRiskFlag(true, "Referred", true);
        }
        //End
    }

    getDefaultClauses(piamCode) {
        let clsSearch = this.riskObj.riskType + piamCode;
        let request: GetLOVData = new GetLOVData();
        request.BRANCH = 'ALL';
        request.LOB = 'FIRE';
        request.BUSINESS_FUNCTION = 'NEW BUSINESS';
        request.PRODUCT = 'ALL';
        request.OPERATION = 'ALL';
        request.FORM_NAME = 'ALL';
        request.FORM_FIELD_NAME = 'PIAMClause';
        request.FIELD_TYPE = 'LOOKUP';
        request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        request.ADVANCE_CONFIG_XML.FILTERS = new Filter();

        request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({ "@FIELD_NAME": 'C.DESCITEM', "@FIELD_VALUE": clsSearch, '@OPERATION': 'EQ', '@CONDITION': 'AND' });
        this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.addDefaultClauses, this.handleError, false, { comp: this });
    }

    addDefaultClauses(response, prms) {
        let ary = [];

        if (response.tuple != null && !Array.prototype.isPrototypeOf(response.tuple)) {
            ary = [response.tuple];
        }
        else if (response.tuple != null) {
            ary = response.tuple;
        }
        for (let clause of ary) {
            let newClause = { clauseCode: clause.old.T7382.CODE, description: clause.old.T7382.LONGDESC, isDefaultClause: 'Y' };
            prms.comp.riskObj.defaultClauses.clause.push(newClause);
            prms.comp.riskObj.clauses.clause.push(newClause);
        }
    }

    removeDefaultClauses() {
        for (let clause of this.riskObj.defaultClauses.clause) {
            let clsFrmClause = this.riskObj.clauses.clause.filter((item) => item.clauseCode == clause.clauseCode);
            for (let cls of clsFrmClause) {
                this.riskObj.clauses.clause.splice(this.riskObj.clauses.clause.indexOf(cls), 1);
            }
        }
        this.riskObj.defaultClauses.clause = [];
    }

    setReferredFromUI(riskClass) {
        this.riskObj.riskClassification = riskClass;
        this.riskClassificationService.setRiskClassification(this.riskObj.riskNumber, "N", "", "").subscribe();
    }

    emitRiskClass(comp) {
        comp.onRiskClsChange.emit("");
    }

    setIdentity(isIdentityChange) {
        if (isIdentityChange == true && (this.riskObj.identityFiller == null || this.riskObj.identityFiller == "")) {
            if (this.riskObj.situation1 != null) {
                this.riskObj.identity = this.riskObj.situation1.slice(0, 15);
                this.riskObj.identityFiller = this.riskObj.situation1.slice(0, 15);
            }
        }
        else {
            if (isIdentityChange == false && this.riskObj.situation1 != null) {
                this.riskObj.identity = this.riskObj.situation1.slice(0, 15);
                this.riskObj.identityFiller = this.riskObj.situation1.slice(0, 15);
            }
            else if (this.riskObj.identityFiller != null)
                this.riskObj.identity = this.riskObj.identityFiller.slice(0, 15);
        }
    }

    setRIMethod(value) {
        this.riskObj.RIMethod = (value == "Yes") ? "8" : "1";
        this._riService.setRI().subscribe();
    }

    setSurveyNeed() {
        let maxSI = this.maxSIForSurvey[this.riskObj.RIRetentionCode];
        if (maxSI && maxSI != "") {
            if (this.riskObj.surveyNumber && this.riskObj.surveyNumber != "" && this.riskObj.surveyStatus == "Survey Initiated") {
                this.riskObj.isSurveyDisabled = "Y";
            }
            else {
                if (parseFloat(this.riskObj.totalSI.toString()) > parseFloat(maxSI)) {
                    if (this.riskObj.isSurveyNeeded != 'N') {
                        if (!this.riskObj.survey) {
                            this.riskObj.survey = new Survey();
                        }
                        this.riskObj.isSurveyNeeded = 'Y';
                        this.validatorforSurveyDetails();
                    }
                }

            }
        }
    }

    validatorforSurveyDetails() {
        if (this.riskObj.surveyNumber != null && this.riskObj.surveyNumber != undefined) {
            if (this.riskObj.surveyType != null && this.riskObj.surveyType != undefined) {
            }
            else {
                this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Please select the Survey Type ", -1));
            }

        }
    }
    onRIRtnChange(value) {
        this.riskObj.RIRetentionCode = value;
        if (this.isLeastPreferredRI()) {
            this.riskObj.isLeastPreferred = "Y";
        }
        else {
            this.riskObj.isLeastPreferred = "N";
        }
        this.handleRiskClassification(this);
        this.setSurveyNeed();
    }

    validateIndPeriod() {
        if (this.riskObj.indPeriodNo != null && (("" + this.riskObj.indPeriodNo).indexOf(".") != -1 || ("" + this.riskObj.indPeriodNo).indexOf("-") != -1)) {
            this.riskObj.indPeriodNo = 0;
            this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Negative value, decimal point are not allowed.", -1));
        }
        else if (this.riskObj.indPeriodNo != null) {
            if (isNaN(this.riskObj.indPeriodNo) == true) {
                this.riskObj.indPeriodNo = 0;
                this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Only number value is allowed.", -1));
            }
            else {
                if (parseInt("" + this.riskObj.indPeriodNo) > 999) {
                    this.riskObj.indPeriodNo = 0;
                    this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Ind period value cannot be more than 999.", -1));
                }
                if (parseInt("" + this.riskObj.indPeriodNo) < 0) {
                    this.riskObj.indPeriodNo = 0;
                    this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Ind period value cannot be less than 0.", -1));
                }
            }
        }
        else if (this.riskObj.indPeriodNo == null) {
            this.riskObj.indPeriodNo = 0;
        }
    }

    resetFI(value) {
        if (value == "Y")
            this.riskObj.financialInterest = new FinancialInterest();
        else
            this.riskObj.financialInterest = null;
    }

    setFocusToNext(elmnt) {
        let sutuationElmnts = jQuery(this.el).find("input");
        jQuery(sutuationElmnts[sutuationElmnts.index(elmnt) + 1]).focus();
    }

    emitFlagChange() {
        this.onRtngFlgChange.emit("");
    }
}

export class AccumulationRegister {
    constructor(
        public accRegCode: string,
        public accRegDesc: string,
        public locality: string
    ) { }
}