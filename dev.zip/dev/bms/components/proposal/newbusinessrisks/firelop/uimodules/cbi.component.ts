import { Component, OnInit, EventEmitter, ViewChild, ViewContainerRef } from '@angular/core';
import { DCLInput, CustomDCLService } from '../../../../../../common/services/customdcl.service';
import { GenericSearchComponent } from "../../../../../../common/components/utility/search/genericsearch.component";
import { SearchInput } from "../../../../../../common/components/utility/search/genericsearch";
import { ModalInput } from "../../../../../../common/components/utility/modal/modal";
import { CordysSoapWService } from "../../../../../../common/components/utility/cordys-soap-ws";
import { CBIItems } from '../../appobjects/cbi';
import { AlertMessagesService } from '../../../../../../common/components/utility/alertmessage/alertmessages.service';
import { AlertMessage } from '../../../../../../common/components/utility/alertmessage/alertmessages.model';

@Component({
    selector: 'cbi-component',
    templateUrl: 'app/bms/components/proposal/newbusinessrisks/firelop//uimodules/cbi.template.html',
    inputs: ['_cbi']
})

export class CBIComponent implements OnInit {
    private _cbi: CBIItems;
    @ViewChild('cbiModal', { read: ViewContainerRef }) contentArea: ViewContainerRef;
    constructor(public dcl: CustomDCLService, private _soapService: CordysSoapWService, public _alertMsgService: AlertMessagesService) { }

    ngOnInit() {
        this.handleSingleRecord();
    }

    handleSingleRecord() {
        if (this._cbi == null || (this._cbi != null && typeof (this._cbi) === "string")) {
            this._cbi = new CBIItems();
        }
        else if (this._cbi != null && this._cbi.cbiItems != null && !Array.prototype.isPrototypeOf(this._cbi.cbiItems)) {
            let tempAry: any = this._cbi.cbiItems;
            this._cbi.cbiItems = [tempAry];
        }
        else if (this._cbi.cbiItems == null) {
            this._cbi.cbiItems = [];
        }
    }

    addCBI(listOfCBIs, prms) {
        for (let cbi of listOfCBIs) {
            if (!prms.comp._cbi.cbiItems)
                prms.comp._cbi.cbiItems = [];
            let cbiCode = cbi.old.DESCPF.DESCITEM;
            while (cbiCode.length < 5) {
                cbiCode = " " + cbiCode;
            }

            prms.comp._cbi.cbiItems.push({
                "cbiCode": cbiCode,
                "cbiDescription": cbi.old.DESCPF.LONGDESC
            });
        }
    }

    openCBIDialog() {
        let searchInput = new SearchInput();
        searchInput.isSingleSelect = false;
        searchInput.BRANCH = 'ALL';
        searchInput.BUSINESS_FUNCTION = 'NEW BUSINESS';
        searchInput.FIELD_TYPE = 'LOOKUP';
        searchInput.FORM_FIELD_NAME = 'CBI';
        searchInput.FORM_NAME = 'FIRE';
        searchInput.LOB = 'FIRE';
        searchInput.OPERATION = 'ALL';
        searchInput.PRODUCT = 'ALL';

        let newArr = [];
        for (let item of this._cbi.cbiItems) {
            newArr.push(item["cbiCode"]);
        }
        let cbiCodes = "'" + newArr.join("', '") + "'";
        searchInput.condition = { "DESCITEM": cbiCodes };

        let input = new ModalInput();
        input = input.get("GenericSearchComponent");
        input.datainput = searchInput;
        input.outputCallback = this.addCBI;
        input.parentCompPRMS = { comp: this };
        input.heading = "List of CBI";
        input.icon = "fa fa-link";
        input.containerRef = this.contentArea;
        this.dcl.openLookup(input);
    }

    removeCBI(idx: number) {
        this._cbi.cbiItems.splice(idx, 1);
    }
}