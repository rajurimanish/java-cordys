import { Component, OnInit, EventEmitter, ViewChild, ViewContainerRef } from '@angular/core';
import { DCLInput, CustomDCLService } from '../../../../../../common/services/customdcl.service';
import { GenericSearchComponent } from "../../../../../../common/components/utility/search/genericsearch.component";
import { SearchInput } from "../../../../../../common/components/utility/search/genericsearch";
import { ModalInput } from "../../../../../../common/components/utility/modal/modal";
import { CordysSoapWService } from "../../../../../../common/components/utility/cordys-soap-ws";
import { MDRisks, MDRisk } from '../appobjects/md';
import { GetLOVData, SearchAdvancedConfig, Filter } from '../../../../../../common/components/utility/search/search.requests';
import { AlertMessagesService } from '../../../../../../common/components/utility/alertmessage/alertmessages.service';
import { AlertMessage } from '../../../../../../common/components/utility/alertmessage/alertmessages.model';
import { ClientDetails } from '../../../../../../common/components/client/appobjects/client';
import { ProposalHeader } from '../../../proposalheader/appobjects/proposalheader';

declare var moment: any;

@Component({
    selector: 'md-component',
    templateUrl: 'app/bms/components/proposal/newbusinessrisks/firelop//uimodules/md.template.html',
    inputs: ['_md', "headerInfo"]
})

export class MDComponent implements OnInit {
    private _md: MDRisks;
    public headerInfo: ProposalHeader;
    @ViewChild('mdModal', { read: ViewContainerRef }) contentArea: ViewContainerRef;
    constructor(public dcl: CustomDCLService, private _soapService: CordysSoapWService, public _alertMsgService: AlertMessagesService) { }

    ngOnInit() {

    }

    openMDLookup() {
        let searchInput = new SearchInput();
        searchInput.isSingleSelect = false;
        searchInput.BRANCH = 'ALL';
        searchInput.BUSINESS_FUNCTION = 'NEW BUSINESS';
        searchInput.FIELD_TYPE = 'LOOKUP';
        searchInput.FORM_FIELD_NAME = 'MD Policy';
        searchInput.FORM_NAME = 'LOP';
        searchInput.LOB = 'FIRE';
        searchInput.OPERATION = 'ALL';
        searchInput.PRODUCT = 'ALL';

        searchInput.condition = { "C.COWNNUM": this.headerInfo.insuredNumber, "C.CRDATE": this.headerInfo.effectiveDate.replace(/-/g, ""), "INSURED_NO": this.headerInfo.insuredNumber, "DTETER": this.headerInfo.effectiveDate.replace(/-/g, "") };
        let input = new ModalInput();
        input = input.get("GenericSearchComponent");
        input.datainput = searchInput;
        input.outputCallback = this.addMdToList;
        input.parentCompPRMS = { comp: this };
        input.heading = "List of Material Damage Risks";
        input.icon = "fa fa-link";
        input.containerRef = this.contentArea;
        this.dcl.openLookup(input);
    }

    addMdToList(mdRisksList, prms) {
        if (mdRisksList != null) {
            for (let eachRisk of mdRisksList) {
                let riskList = [];
                if (prms.View == "MD Policy") {
                    riskList = prms.comp._md.mdRisk.filter((item) => item.mdRisk == eachRisk.old.CHDRPF.CHDRNUM && item.riskNo == eachRisk.old.CHDRPF.RSKNO && item.riskType == eachRisk.old.CHDRPF.RSKTYP);
                    if (riskList.length == 0)
                        prms.comp._md.mdRisk.push({ mdRisk: eachRisk.old.CHDRPF.CHDRNUM, riskNo: eachRisk.old.CHDRPF.RSKNO, riskType: eachRisk.old.CHDRPF.RSKTYP });
                }
                else {
                    riskList = prms.comp._md.mdRisk.filter((item) => item.mdRisk == eachRisk.old.FIRE_CASE_DETAILS.CASE_ID && item.riskNo == eachRisk.old.FIRE_CASE_DETAILS.RISK_NO && item.riskType == eachRisk.old.FIRE_CASE_DETAILS.RISK_TYPE);
                    if (riskList.length == 0)
                        prms.comp._md.mdRisk.push({ mdRisk: eachRisk.old.FIRE_CASE_DETAILS.CASE_ID, riskNo: eachRisk.old.FIRE_CASE_DETAILS.RISK_NO, riskType: eachRisk.old.FIRE_CASE_DETAILS.RISK_TYPE });
                }
            }
        }
    }

    removeMD(idx: number) {
        this._md.mdRisk.splice(idx, 1);
    }
}