import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BasicUIModule } from '../../../../../common/components/utility/basicui.module';

import { FIModule } from '../../../../../common/components/financialinterest/fi.module';
import { LovModule } from "../../../../../common/services/lovdropdown/lov.module";
import { MultiSelectModule } from '../../../../../common/components/utility/selectbox/multi-selectbox.module';

import { FireCoverageModule } from '../uimodules/firecoverage.module';
import { SurveyModule } from '../uimodules/survey.module';
import { PerilModule } from '../uimodules/perils.module';
import { RateableClauseModule } from '../uimodules/rateableclause.module';
import { ClausesModule } from '../uimodules/clauses.module';
import { RelatedCaseModule } from '../uimodules/relatedcase.module';
import { GSTModule } from '../uimodules/gst.module';
import { CBIModule } from './uimodules/cbi.module';
import { MDModule } from './uimodules/md.module';

import { FireLOPRiskComponent } from './firelop.component';
import { AccRegisterModule } from '../uimodules/accregister.module';
import { GeneralPageModule } from '../uimodules/generalpage.module'; //VK004

@NgModule({
    imports: [CommonModule, FormsModule, ReactiveFormsModule, BasicUIModule, FIModule, LovModule,
        MultiSelectModule, FireCoverageModule, SurveyModule, PerilModule, RateableClauseModule, ClausesModule,
	RelatedCaseModule,GSTModule,CBIModule,MDModule,AccRegisterModule, GeneralPageModule],
    declarations: [FireLOPRiskComponent],
    exports: [FireLOPRiskComponent]
})
export class FireLOPRiskModule { }