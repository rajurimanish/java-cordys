import { Component, ElementRef, OnInit, NgZone } from "@angular/core";
import { CordysSoapWService } from '../../../../../../common/components/utility/cordys-soap-ws';
import { ApplicationUtilService } from "../../../../../../common/services/application.util.service";
import { AlertMessagesService } from '../../../../../../common/components/utility/alertmessage/alertmessages.service';
import { AlertMessage } from '../../../../../../common/components/utility/alertmessage/alertmessages.model';
import { S6271, S6272ItemDetails, Benefit, BenefitItem, AdditionalCoverageDetails, AdditionalCoverage } from '../appobjects/s6271';
import { LOV_Field, LOVDropDownService, SearchFilter } from "../../../../../../common/services/lovdropdown/lovdropdown.service";
import { GetLOVData, SearchAdvancedConfig, Filter } from '../../../../../../common/components/utility/search/search.requests';

declare var jQuery: any;
declare var moment: any;
declare var numeral: any;

@Component({
    selector: "s6272-additional-benefits",
    templateUrl: "app/bms/components/proposal/newbusinessrisks/s6271/dialogs/s6272additionalbenefits.template.html",
    inputs: ['datainput', 'closeDialog', 'parentCompPRMS']
})
export class S6272AdditionalBenefits implements OnInit {

    public datainput: any;
    public closeDialog: Function;
    public parentCompPRMS: any;

    private elementRef: ElementRef;
    private attachmentName;
    private type;
    public records: any;
    private _additioanlBeneRecord: AdditionalCoverage;

    public siFormat: string = "0,00";
    public premiumFormat: string = "0,00.00";
    public rateFormat: string = "0.00000";
    public loadFormat: string = "0.00";
    public percentFormat: string = "0.00";
    private benefitCategoryPlans = [];
    private viewMode: string = 'N';

    constructor(private _elRef: ElementRef, private lovDropDownService: LOVDropDownService, private _soapService: CordysSoapWService, private _cordysService: CordysSoapWService, private _appUtilService: ApplicationUtilService, public _alertMsgService: AlertMessagesService) { }

    ngOnInit() {
        if (this.datainput.isNew) {
            this._additioanlBeneRecord = new AdditionalCoverage();
            this._additioanlBeneRecord.category = "";
            this._additioanlBeneRecord.categoryDescription = "";
            this._additioanlBeneRecord.plan = "";
            this._additioanlBeneRecord.planDescription = "";
            this._additioanlBeneRecord.premium = 0;
            this._additioanlBeneRecord.loading = 0;
            this._additioanlBeneRecord.discount = 0;
            this._additioanlBeneRecord.effectiveDate = "";
            this._additioanlBeneRecord.terminationDate = "";
            this._additioanlBeneRecord.totalPremium = 0;
            this._additioanlBeneRecord.benefitsText = "";
        }
        else {
            this.viewMode = 'Y';
            this._additioanlBeneRecord = new AdditionalCoverage();
            this._additioanlBeneRecord.category = this.datainput.benefitData.category;
            this._additioanlBeneRecord.categoryDescription = this.datainput.benefitData.categoryDescription;
            this._additioanlBeneRecord.plan = this.datainput.benefitData.plan;
            this._additioanlBeneRecord.planDescription = this.datainput.benefitData.planDescription;
            this._additioanlBeneRecord.premium = this.datainput.benefitData.premium;
            this._additioanlBeneRecord.loading = this.datainput.benefitData.loading;
            this._additioanlBeneRecord.discount = this.datainput.benefitData.discount;
            this._additioanlBeneRecord.effectiveDate = this.datainput.benefitData.effectiveDate;
            this._additioanlBeneRecord.terminationDate = this.datainput.benefitData.terminationDate;
            this._additioanlBeneRecord.totalPremium = this.datainput.benefitData.totalPremium;
            this._additioanlBeneRecord.benefitsText = this.datainput.benefitData.benefitsText;

            this.getPlansForCategoryOnEdit();
        }

        this.populateABCategoryForFSIProduct();
    }

    populateABCategoryForFSIProduct() {
        this.lovDropDownService.createLOVDataList(["ABCategory"]);
        let riskFilterNodes = [];
        let riskFilter = (this.parentCompPRMS.comp.riskObj.riskType == 2) ? this.parentCompPRMS.comp.riskObj.riskType + ' ' : this.parentCompPRMS.comp.riskObj.riskType;
        let riskFilterDetails = [new SearchFilter("DESCITEM", riskFilter, "STARTSWITH", "AND")];
        riskFilterNodes = this.lovDropDownService.createFilter(riskFilterDetails);
        let lovFields = [
            new LOV_Field("ALL", "ALL", "ALL", "ALL", "ALL", "S6816", "ABCategory", "LOV", riskFilterNodes, "DESCPF", "ABCategory", null)
        ];
        this.lovDropDownService.util_populateLOV(lovFields, this);
    }

    private getPlansForCategoryOnEdit() {
        //this._additioanlBeneRecord.categoryDescription=event.record.COMB_DESC;    
        this.lovDropDownService.createLOVDataList(["ABPlan"]);
        let riskFilterNodes = [];
        let riskFilter = (this.parentCompPRMS.comp.riskObj.riskType == 2) ? this.parentCompPRMS.comp.riskObj.riskType + ' ' + this._additioanlBeneRecord.category : this.parentCompPRMS.comp.riskObj.riskType + this._additioanlBeneRecord.category;
        let riskFilterDetails = [new SearchFilter("DESCITEM", riskFilter, "STARTSWITH", "AND")];
        riskFilterNodes = this.lovDropDownService.createFilter(riskFilterDetails);
        let lovFields = [
            new LOV_Field("ALL", "ALL", "ALL", "ALL", "ALL", "S6816", "ABPlan", "LOV", riskFilterNodes, "DESCPF", "ABPlan", "callbackForBenefitCategoryPlans")
        ];
        this.lovDropDownService.util_populateLOV(lovFields, this);

    }

    private callbackForBenefitCategoryPlans(scopeObject) {
        scopeObject.benefitCategoryPlans = [];
        let _abPlansArray = scopeObject.lovDropDownService.lovDataList.ABPlan.filter((_data) => _data.DESCITEM.length == 7);

        if (scopeObject._additioanlBeneRecord.category == 'OS') {//Redmine#2649 - OS category should show FSIOS01 option only for plan FS1.
            let _filter = '';
            if (this.parentCompPRMS.comp.riskObj.plan == 'FS1') {
                _filter = scopeObject.parentCompPRMS.comp.riskObj.riskType + 'OS01';
            }
            else if (this.parentCompPRMS.comp.riskObj.plan == 'FS2') {
                _filter = scopeObject.parentCompPRMS.comp.riskObj.riskType + 'OS02';
            }
            else if (this.parentCompPRMS.comp.riskObj.plan == 'FS3') {
                _filter = scopeObject.parentCompPRMS.comp.riskObj.riskType + 'OS03';
            }
            else if (this.parentCompPRMS.comp.riskObj.plan == 'FS4') {
                _filter = scopeObject.parentCompPRMS.comp.riskObj.riskType + 'OS04';
            }

            if (_filter) {
                let _osArry = scopeObject.lovDropDownService.lovDataList.ABPlan.filter((_data) => (_data.DESCITEM == _filter));
                if (_osArry && _osArry.length > 0) _abPlansArray = _osArry;
            }
        }

        ApplicationUtilService.sortArray(_abPlansArray, 'VALUE');
        scopeObject.benefitCategoryPlans = _abPlansArray;
    }

    private getPlansForCategory(event) {
        this._additioanlBeneRecord.categoryDescription = event.record.COMB_DESC;
        this._additioanlBeneRecord.plan = "";
        this._additioanlBeneRecord.planDescription = ""
        this._additioanlBeneRecord.premium = 0;
        this._additioanlBeneRecord.loading = 0;
        this._additioanlBeneRecord.discount = 0;
        this._additioanlBeneRecord.effectiveDate = "";
        this._additioanlBeneRecord.terminationDate = "";
        this._additioanlBeneRecord.totalPremium = 0;
        this._additioanlBeneRecord.benefitsText = "";
        this.benefitCategoryPlans = [];

        this.lovDropDownService.createLOVDataList(["ABPlan"]);
        let riskFilterNodes = [];
        let riskFilter = (this.parentCompPRMS.comp.riskObj.riskType == 2) ? this.parentCompPRMS.comp.riskObj.riskType + ' ' + event.value : this.parentCompPRMS.comp.riskObj.riskType + event.value;
        let riskFilterDetails = [new SearchFilter("DESCITEM", riskFilter, "STARTSWITH", "AND")];
        riskFilterNodes = this.lovDropDownService.createFilter(riskFilterDetails);
        let lovFields = [
            new LOV_Field("ALL", "ALL", "ALL", "ALL", "ALL", "S6816", "ABPlan", "LOV", riskFilterNodes, "DESCPF", "ABPlan", "callbackForBenefitCategoryPlans")
        ];
        this.lovDropDownService.util_populateLOV(lovFields, this);

    }
    onAdditionalBenefitPlanChange(event) {
        this._additioanlBeneRecord.planDescription = event.record.COMB_DESC;
        this._additioanlBeneRecord.premium = 0;
        this._additioanlBeneRecord.loading = 0;
        this._additioanlBeneRecord.discount = (this._additioanlBeneRecord.category == 'OS') ? this.parentCompPRMS.comp.riskObj.deductiblePercentage : 0;
        this._additioanlBeneRecord.effectiveDate = "";
        this._additioanlBeneRecord.terminationDate = "";
        this._additioanlBeneRecord.totalPremium = 0;
        this._additioanlBeneRecord.benefitsText = "";

        let request: GetLOVData = new GetLOVData().getRequest('ALL', 'ALL', 'ALL', 'ALL', 'ALL', 'S6816', 'AdditionalPremium', 'LOV');
        request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        request.ADVANCE_CONFIG_XML.FILTERS = new Filter();
        let riskFilter = (this.parentCompPRMS.comp.riskObj.riskType.length == 2) ? this.parentCompPRMS.comp.riskObj.riskType + ' ' : this.parentCompPRMS.comp.riskObj.riskType;

        request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push(
            { "@FIELD_NAME": "DESCITEM", "@FIELD_VALUE": riskFilter + this._additioanlBeneRecord.category + this._additioanlBeneRecord.plan, "@OPERATION": "EQ", "@CONDITION": "AND" },
            { "@FIELD_NAME": "cast(AGE as int) ", "@FIELD_VALUE": this.parentCompPRMS.comp.riskObj.insuredAge, "@OPERATION": "GTEQ", "@CONDITION": "AND" },
            { "@FIELD_NAME": "ITMFRM", "@FIELD_VALUE": moment(this.parentCompPRMS.comp.headerInfo.effectiveDate, "YYYY-MM-DD").format("YYYYMMDD"), "@OPERATION": "LT", "@CONDITION": "AND" },
            { "@FIELD_NAME": "ITMTO", "@FIELD_VALUE": moment(this.parentCompPRMS.comp.headerInfo.effectiveDate, "YYYY-MM-DD").format("YYYYMMDD"), "@OPERATION": "GT", "@CONDITION": "AND" }
        );
        this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, null, null, false, null).success((data) => {
            if (data.tuple) {
                this._additioanlBeneRecord.premium = numeral(Number(data.tuple.old.T9023.BASPRM) / 100).format('0.00');
                this._additioanlBeneRecord.benefitsText = data.tuple.old.T9023.ADBDES;
                this.calcualteTotalABPremiumForCover();
            }
        }).error((response, status, errorText) => {
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error while getting basic premium for Plan - " + this.parentCompPRMS.comp.plan, 5000));
        });
    }
    calcualteTotalABPremiumForCover() {
        let _premium = 0;
        let _loadingPercent = 0;
        let _loadingAmount = 0;
        let _discountPercent = 0;
        let _discountAmount = 0;
        _premium = numeral().unformat(this._additioanlBeneRecord.premium);
        _loadingPercent = numeral().unformat(this._additioanlBeneRecord.loading);
        _discountPercent = numeral().unformat(this._additioanlBeneRecord.discount);
        _loadingAmount = ((_premium) * (_loadingPercent / 100));
        _discountAmount = ((_premium + _loadingAmount) * (_discountPercent / 100));
        this._additioanlBeneRecord.totalPremium = (_premium + _loadingAmount) - _discountAmount;
        this._additioanlBeneRecord.totalPremium = numeral(Number(this._additioanlBeneRecord.totalPremium)).format('0.00')
    }

    getDate() {
        return moment(new Date().toISOString(), "YYYY-MM-DD").format("YYYYMMDD");
    }
    getRiskType() {
        let riskType = this.parentCompPRMS.comp.riskObj.riskType;
        while (riskType != undefined && riskType.length < 3) {
            riskType = riskType + " ";
        }
        return riskType;
    }

    private CloseDialog() {
        this.closeDialog(this._additioanlBeneRecord, this.parentCompPRMS);
    }

    private confirmdata() {

        if (this.datainput.isNew && !this.checkIfCategoryAlreadyAdded(this.parentCompPRMS.comp)) {

            this.parentCompPRMS.comp.riskObj.additionalCoverDetails.additionalCover.push(this._additioanlBeneRecord);
            this.CloseDialog();
        }
        else if (!this.datainput.isNew) {

            this.parentCompPRMS.comp.riskObj.additionalCoverDetails.additionalCover[this.datainput.beneIndex].category = this._additioanlBeneRecord.category;
            this.parentCompPRMS.comp.riskObj.additionalCoverDetails.additionalCover[this.datainput.beneIndex].categoryDescription = this._additioanlBeneRecord.categoryDescription;
            this.parentCompPRMS.comp.riskObj.additionalCoverDetails.additionalCover[this.datainput.beneIndex].plan = this._additioanlBeneRecord.plan;
            this.parentCompPRMS.comp.riskObj.additionalCoverDetails.additionalCover[this.datainput.beneIndex].planDescription = this._additioanlBeneRecord.planDescription;
            this.parentCompPRMS.comp.riskObj.additionalCoverDetails.additionalCover[this.datainput.beneIndex].premium = this._additioanlBeneRecord.premium;
            this.parentCompPRMS.comp.riskObj.additionalCoverDetails.additionalCover[this.datainput.beneIndex].loading = this._additioanlBeneRecord.loading;
            this.parentCompPRMS.comp.riskObj.additionalCoverDetails.additionalCover[this.datainput.beneIndex].discount = this._additioanlBeneRecord.discount;
            this.parentCompPRMS.comp.riskObj.additionalCoverDetails.additionalCover[this.datainput.beneIndex].effectiveDate = this._additioanlBeneRecord.effectiveDate;
            this.parentCompPRMS.comp.riskObj.additionalCoverDetails.additionalCover[this.datainput.beneIndex].terminationDate = this._additioanlBeneRecord.terminationDate;
            this.parentCompPRMS.comp.riskObj.additionalCoverDetails.additionalCover[this.datainput.beneIndex].totalPremium = this._additioanlBeneRecord.totalPremium;
            this.parentCompPRMS.comp.riskObj.additionalCoverDetails.additionalCover[this.datainput.beneIndex].benefitsText = this._additioanlBeneRecord.benefitsText;
            this.CloseDialog();
        }
    }

    private checkIfCategoryAlreadyAdded(comp) {
        for (let item of comp.riskObj.additionalCoverDetails.additionalCover) {
            if (item.category == this._additioanlBeneRecord.category) {
                this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Category " + this._additioanlBeneRecord.category + " already added", 5000));
                return true;
            }
        }
        return false;
    }
}