import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BasicUIModule } from '../../../../../../common/components/utility/basicui.module';
import { LovModule } from "../../../../../../common/services/lovdropdown/lov.module";

import { S6272AdditionalBenefits } from './s6272additionalbenefits.component';

@NgModule({
    imports: [CommonModule, FormsModule, ReactiveFormsModule, BasicUIModule, LovModule],
    declarations: [S6272AdditionalBenefits],
    exports: [S6272AdditionalBenefits]
})
export class S6272AdditionalBenefitsModule { }