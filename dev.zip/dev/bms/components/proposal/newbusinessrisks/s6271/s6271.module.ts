import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RelatedCaseModule } from '../uimodules/relatedcase.module';
import { BasicUIModule } from '../../../../../common/components/utility/basicui.module';
import { FIModule } from '../../../../../common/components/financialinterest/fi.module';
import { LovModule } from "../../../../../common/services/lovdropdown/lov.module";
import { ClausesModule } from '../uimodules/clauses.module';
import { GSTModule } from '../uimodules/gst.module';
import { S6272Module } from './s6272.module';
import { PaginationModule } from '../../../../../common/components/utility/pagination/pagination.module';
import { S6271Component } from './s6271.component';
import { GeneralPageModule } from '../uimodules/generalpage.module'; //VK004

@NgModule({
    imports: [ CommonModule, FormsModule, ReactiveFormsModule, BasicUIModule, FIModule, LovModule, ClausesModule, GSTModule, S6272Module, PaginationModule, RelatedCaseModule, GeneralPageModule],
    declarations: [S6271Component],
    exports: [S6271Component]
})
export class S6271Module { }