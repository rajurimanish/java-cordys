/*
 * Change History:
 * 
 * No      Date          Description                                         Changed By
 * ====    ==========    ===========                                         ==========	
 * YPK001 23/09/2019       MYS-2019-0675 Document Validation for Co-outwards            PKU1
 *                         case before sending to PPHO			   
*/
import { Component, OnInit, ViewChild, ElementRef, EventEmitter, AfterViewInit, ViewContainerRef } from '@angular/core';
import { DCLInput, CustomDCLService } from '../../../../../common/services/customdcl.service';
import { S6271, S6272ItemDetails, S6272Item } from './appObjects/s6271';
import { LOV_Field, LOVDropDownService, SearchFilter } from "../../../../../common/services/lovdropdown/lovdropdown.service";
import { GetLOVData, SearchAdvancedConfig, Filter } from '../../../../../common/components/utility/search/search.requests';
declare var Observer: any;
import { PaginationPipe } from '../../../../../common/components/utility/pagination/filtertable.pipe';
import { FilterTableContentPipe } from '../../../../../common/components/utility/pagination/filtercontent.pipe';
import { ProposalHeader } from '../../proposalheader/appobjects/proposalheader';
import { ClientDetails } from '../../../../../common/components/client/appobjects/client';
import { CordysSoapWService } from "../../../../../common/components/utility/cordys-soap-ws";
import { AlertMessagesService } from '../../../../../common/components/utility/alertmessage/alertmessages.service';
import { AlertMessage } from '../../../../../common/components/utility/alertmessage/alertmessages.model';
import { ModalInput } from "../../../../../common/components/utility/modal/modal";
import { Clause } from "../appobjects/clause";
import { ClausesComponent } from "../uimodules/clauses.component";
import { RelatedCaseComponent } from "../uimodules/relatedcase.component";
import { FireRelatedCases, RelatedCases } from '../appobjects/relatedCase';
import { ApplicationUtilService } from "../../../../../common/services/application.util.service";
import { BMSUtilService } from "../../../../services/bms.util.service";
import { RIService } from '../services/ri.service';
import { ReferredReason, Reasons } from '../../proposalheader/appobjects/referredreason';
import { BMSConstants } from '../../../common/constants/bms_constants';
import { ActivatedRoute } from '@angular/router';

declare var jQuery: any;
declare var numeral: any;
declare var moment: any;

@Component({
    selector: 'S6271-component',
    templateUrl: 'app/bms/components/proposal/newbusinessrisks/s6271/s6271.template.html',
    inputs: ['riskObj', 'clientDetails', 'headerInfo'],
    outputs: ["onPremiumChange", 'onSIChange', 'onRiskClsChange', 'onRtngFlgChange']
})
export class S6271Component implements OnInit {
    @ViewChild(ClausesComponent) private clausesComp: ClausesComponent;
    private isCollapsedMode: boolean = true;
    private isGeneralPageCollapsed: boolean = false;
    private collapseClausesInfo: boolean = true;
    private relatedCollapse: boolean = false;
    public defaultClauseCode: string = "";

    public riskObj: S6271;
    public clientDetails: ClientDetails;
    public headerInfo: ProposalHeader;
    public currentRiskObj: any;
    private el: HTMLElement;
    public selectedRiskComponent: any;
    onPremiumChange = new EventEmitter<any>();
    onRiskClsChange = new EventEmitter<any>();
    onSIChange = new EventEmitter<any>();
    private inclusionDateCtrl: any = [];
    private memberEffectiveDateCtrl: any = [];
    onRtngFlgChange = new EventEmitter<any>();
    public search: String = "";
    public position = 1;
    public sizeObj = { length: 0, orglength: 0 };
    public contentSizeObs: any;
    public itemPerPage = 5;
    public maxPageCount = 50;
    public disableForm = 'N';

    public siFormat: string = "000";
    public premiumFormat: string = "000.00";
    public rateFormat: string = "0.00000";
    public percentFormat: string = "0.00";

    private isUnderWriter = "N";
    private isRIMethodEditable = "Y";

    public isAnyInsuredReferred: boolean = false;
    public isAnyInsuredDeclined: boolean = false;
    public isManuallyReferred: boolean = false;
    public caseInfo: any;//KA001 - Renewal
    public collapsableObject = {
        "isCollapsedMode": false,
        "collapseClausesInfo": false
    }

    @ViewChild('S6272RisksModal', { read: ViewContainerRef }) contentArea: ViewContainerRef;


    constructor(private lovDropDownService: LOVDropDownService, private _soapService: CordysSoapWService, public _alertMsgService: AlertMessagesService, el: ElementRef, private _dcl: CustomDCLService, private _appUtilService: ApplicationUtilService, private _bmsUtilService: BMSUtilService, private _riService: RIService, private _activatedRoute: ActivatedRoute) {
        this.el = el.nativeElement;
    }

    ngAfterViewInit() {
        //this.setFormDisabled();
        if (this.headerInfo.asyncPostingStatus == "InProgress") {
            this.disableForm = "Y";
        } else if (this.riskObj.contractNumber != "") {
            this.disableForm = "Y";
        }
        else {
            this.disableForm = "N";
        }
        //START YPK001
        let rIndex = 0;
        if ((this.headerInfo.CoInsurance == 'Y' && this.riskObj.riskNumber == '1') && (["MyTasks", "MyDrafts"].indexOf(this._activatedRoute.snapshot.params['component']) >= 0 || Object.keys(this._activatedRoute.snapshot.params).length == 0)) {
            if (this.headerInfo.coInsuranceDetails.coInsurance.length == 1) {
                if (!(this.headerInfo.coInsuranceDetails.coInsurance[0].coInsuranceindicator == 'L' && this.headerInfo.coInsuranceDetails.coInsurance[0].sharePercentage == '100')) {
                    rIndex = this.riskObj.clauses.clause.map(function (item) { return item.clauseCode; }).indexOf("COIN");
                    if (rIndex == -1)
                        this.setClauses(["COIN"], false);
                }
            }
            else {
                rIndex = this.riskObj.clauses.clause.map(function (item) { return item.clauseCode; }).indexOf("COIN");
                if (rIndex == -1)
                    this.setClauses(["COIN"], false);
            }
        }
    }
    setClauses(clausesList, flag) {
        if (this.clausesComp)
            this.clausesComp.addClause(clausesList, '', flag);
    }
    //END YPK001

    setFormDisabled() {
        if (jQuery("#bmsForm").prop("disabled") == true) {
            this.disableForm = "Y";
        }
    }

    ngOnInit() {
        this.defaultOccupationAndInsuredName();
        this.populateLovs();
        if (this.riskObj.contractNumber != "") {
            this.disableForm = "Y";
        }
        this._appUtilService.isUnderWriterUser().subscribe((data) => {
            this.isUnderWriter = data;
            this.setRIMethodEditableFlag();
        });
        this.caseInfo = BMSConstants.getBMSCaseInfo();	//KA001 - Renewal
        //SST Code
        if (["MyTasks", "MyDrafts"].indexOf(this._activatedRoute.snapshot.params['component']) >= 0 || Object.keys(this._activatedRoute.snapshot.params).length == 0) {
            let respObj = this._bmsUtilService.getTAXDetails();
            if (respObj != undefined && respObj != "") {
                this.headerInfo.SSTTaxRate = Number(respObj[0].old.ITEMPF.GST);
                this.headerInfo.GSTTaxRate = Number(respObj[1].old.ITEMPF.GST);

                this.riskObj.SST = Number(this.headerInfo.SSTTaxRate);
                this.riskObj.GST = Number(this.headerInfo.GSTTaxRate);
            }

            this.headerInfo = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo;
            this.riskObj.SSTLiveDate = (this.riskObj.SSTLiveDate == undefined) ? this.headerInfo.SSTLiveDate : this.riskObj.SSTLiveDate;
            if (this.riskObj.SSTLiveDate == undefined || this.riskObj.SSTLiveDate == "") {
                let tempRespObj = this._bmsUtilService.getLiveDate();
                this.riskObj.GSTLiveDate = tempRespObj[0].old.ITEMPF.LIVEDATE;
                this.riskObj.SSTLiveDate = tempRespObj[1].old.ITEMPF.LIVEDATE;
                if (this.headerInfo.SSTLiveDate == undefined || this.headerInfo.SSTLiveDate == "") {
                    this.headerInfo.SSTLiveDate = this.riskObj.SSTLiveDate;
                }
                if (this.headerInfo.GSTLiveDate == undefined || this.headerInfo.GSTLiveDate == "") {
                    this.headerInfo.GSTLiveDate = this.riskObj.GSTLiveDate;
                }
            }
            if (moment(this.headerInfo.effectiveDate, "YYYY-MM-DD").format("YYYYMMDD") >= moment(this.riskObj.SSTLiveDate, "YYYY-MM-DD").format("YYYYMMDD")) {
                this.riskObj.isGSTApplicable = false;
            } else {
                this.riskObj.isGSTApplicable = true;
            }
        }
        //End
        ////MYS-2018-0878 - SST FIX FOR MEDICAL
        if (this.headerInfo.caseId.substring(0, 1) == 'R' && this.clientDetails.client.genericDetails.clienttype == "P") {
            this.riskObj.SST = 0;
            this.riskObj.sstAmount = 0;
            this.headerInfo.SSTTaxRate = 0;
            this.riskObj.noOfPersons = this.riskObj.s6272Items.s6272Item.length;
            if (this.riskObj.noOfPersons > 2) {
                for (let _insObj of this.riskObj.s6272Items.s6272Item) {
                    if (this.caseInfo.businessFunction == 'Renewal' && _insObj.isInsuredTerminated != 'Y') {
                        _insObj.familyDiscountPercentage = 10;
                        this._bmsUtilService.s6272SetPremium(_insObj);
                    }
                }
                this.setTotalPremium();
                if (this.caseInfo.status == 'Assessment') {
                    this._alertMsgService.add(new AlertMessage(AlertMessage.WARN, "Family Discount of 10% has been added for each insured", 10000));
                }
            }
            else {
                for (let _insObj of this.riskObj.s6272Items.s6272Item) {
                    if (_insObj.isInsuredTerminated != 'Y') { this._bmsUtilService.s6272SetPremium(_insObj); }
                }
                this.setTotalPremium();
            }
        }
    }

    /************
    *Collapse and Expand related operations
    ************/
    private expandContent(part) {

        this.collapsableObject[part] = false;
        event.stopPropagation();
    }

    private collapseContent(part) {
        this.collapsableObject[part] = true;
        event.stopPropagation();
    }

    public expandOrCollapse(part) {
        if (this.collapsableObject[part] == false) {
            this.collapsableObject[part] = true;
        } else {
            this.collapsableObject[part] = false;
        }
    }

    defaultOccupationAndInsuredName() {
        if (this.riskObj.occupationCode == undefined || this.riskObj.occupationCode == "") {
            if (this.clientDetails.client.genericDetails.clienttype == 'P') {
                this.riskObj.insuredPerson = this.clientDetails.client.personalClientDetails.Name;
                this.riskObj.occupationCode = this.clientDetails.client.personalClientDetails.occupationCode;
                this.riskObj.dateOfBirth = moment(this.clientDetails.client.personalClientDetails.dateOfBirth, "YYYYMMDD").format("YYYY-MM-DD");
            }
            else {
                this.riskObj.insuredPerson = this.clientDetails.client.corporateClientDetails.corporation;
                this.riskObj.occupationCode = this.clientDetails.client.corporateClientDetails.BusinessSec;
                this.riskObj.occupationDescription = "";
                this.riskObj.dateOfBirth = "";
            }
        }
    }

	/*
    pupulateOccupationDescription(iOccCode){
        let request:GetLOVData = new GetLOVData().getRequest('ALL','ALL','NEW BUSINESS','ALL','NEW','ALL','Occupation','LOV');
        request.ADVANCE_CONFIG_XML= new SearchAdvancedConfig(); 
        request.ADVANCE_CONFIG_XML.FILTERS = new Filter();
        
        request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push(
            {"@FIELD_NAME":'DESCITEM',"@FIELD_VALUE": iOccCode ,'@OPERATION':'EQ','@CONDITION':'AND'});
        this._soapService.callCordysSoapService("GetLOVData","http://schemas.opentext.com/lovhandler/v1.0", request , this.OccDescSuccessHandler, this.handleError, true, {comp:this});
        
    }
    OccDescSuccessHandler(response, prms){
        let ary = [];
        let occDesc = "";
        if(response.tuple != null && !Array.prototype.isPrototypeOf(response.tuple)){
            ary = [response.tuple];
        }
        else if(response.tuple != null){
            ary = response.tuple;
        }
        for(let item of ary) {
            prms.comp.riskObj.occupationDescription=item.old.T3644.DESCRIPTION;
        }
        prms.comp.occupationSuccessHandler(response,prms);
    }
    
	
    setOccDesc(occupation){
        this.riskObj.occupationDescription = occupation.record.DESCRIPTION;
        let request:GetLOVData = new GetLOVData();
        request.BRANCH ='ALL';
        request.LOB = 'ALL';
        request.BUSINESS_FUNCTION = 'NEW BUSINESS';
        request.PRODUCT = 'ALL';
        request.OPERATION = 'NEW';
        request.FORM_NAME = 'ALL';        
        request.FORM_FIELD_NAME = 'Occupation';
        request.FIELD_TYPE = 'LOV';
        request.ADVANCE_CONFIG_XML= new SearchAdvancedConfig(); 
        request.ADVANCE_CONFIG_XML.FILTERS = new Filter();
        
        request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({"@FIELD_NAME":'DESCITEM',"@FIELD_VALUE":this.riskObj.occupationCode ,'@OPERATION':'EQ','@CONDITION':'AND'});
        this._soapService.callCordysSoapService("GetLOVData","http://schemas.opentext.com/lovhandler/v1.0", request , this.occupationSuccessHandler, this.handleError, true, {comp:this});
    }
    occupationSuccessHandler(response, prms) {
        if(response.tuple.old.T3644.REFERREDRISK == '' || response.tuple.old.T3644.REFERREDRISK == 'N') {
            prms.comp.riskObj.occRiskClassification= "Standard";
        }
        else if(response.tuple.old.T3644.REFERREDRISK == 'Y') {
            prms.comp.riskObj.occRiskClassification= "Referred";
        }
        else if(response.tuple.old.T3644.REFERREDRISK == 'D') {
            prms.comp.riskObj.occRiskClassification= "Declined";
        }
        prms.comp.checkReferredRisk(prms.comp);
    }*/

    setRIMethod(val) {

        this.riskObj.RIMethod = (val == "Yes") ? "8" : this.riskObj.RIMethodSys;

        if (this.isUnderWriter == "Y" || val == "Yes")
            this.riskObj.isRIOverWrittenByUW = "Y";
        else if (val == "No") {
            this.riskObj.isRIOverWrittenByUW = "N";
            this.validateCapitalSumInsured();
        }
        this._riService.setRI().subscribe();
    }

    changeRiskClassification(event) {
        this.riskObj.riskClassification = event.target.value;
        this.onRiskClsChange.emit('');
    }

    checkSingleRecord() {
        if (this.riskObj.s6272Items != null && this.riskObj.s6272Items.s6272Item != null) {
            if (!Array.prototype.isPrototypeOf(this.riskObj.s6272Items.s6272Item)) {
                let tempItem: any = this.riskObj.s6272Items.s6272Item;
                this.riskObj.s6272Items.s6272Item = [tempItem];
            }
        }
        else {
            this.riskObj.s6272Items = new S6272Item();
        }

    }
    /*resetSurvey(value){
        if("Y" == value){
            this.riskObj.survey = new Survey();
        }
        else{
            this.riskObj.survey = null;
        }
    }*/
    validateInput(event, dType, allowedLength) {
        // console.log(dType + ", " + event.target.value);

        if ([46, 8, 9, 27, 13, 110].indexOf(event.keyCode) !== -1 ||
            // Allow: Ctrl+A, Command+A
            (event.keyCode === 65 && (event.ctrlKey === true || event.metaKey === true)) ||
            // Allow: home, end, left, right, down, up
            (event.keyCode >= 35 && event.keyCode <= 40)) {
            // let it happen, don't do anything
            return;
        }
        // Ensure that it is a number and stop the keypress
        if (dType = "integer") {
            let result = (event.target.value + "").match(/[^0-9]/g);
            if (event.key == ".") {
                //console.log("not allowed");
                return false;
            }
            if (event.target.value != undefined && event.target.value.length >= allowedLength) {
                //console.log("length failed");
                return false;
            }
        } else if (dType = "double") {
            let result = (event.target.value + "").match(/[^0-9]/g);
            if (result && event.key == ".") {
                //console.log("not allowed");
                return false;
            }
        }
        if ((event.shiftKey || (event.keyCode < 48 || event.keyCode > 57)) && (event.keyCode < 96 || event.keyCode > 105)) {
            event.preventDefault();
        }

    }

    addRisk() {
        if (this.clientDetails.client.genericDetails.clienttype == 'P' && !(this.riskObj.s6272Items != null && this.riskObj.s6272Items.s6272Item != null && this.riskObj.s6272Items.s6272Item.length > 0))
            this.setClientInfo();
        else {
            let news6272Item = new S6272ItemDetails();
            news6272Item.itemNo = this.riskObj.s6272Items.s6272Item.length + 1;
            news6272Item.dateStart = this.headerInfo.effectiveDate;
            news6272Item.lastDateEnd = this.headerInfo.endDate;
            news6272Item.inclusionDate = this.headerInfo.effectiveDate;
            news6272Item.memberEffectiveDate = this.headerInfo.effectiveDate;
            news6272Item.riskType = this.riskObj.riskType;
            news6272Item.riskName = this.riskObj.riskName;

            news6272Item.nationality = "MAL";
            news6272Item.homeCity = "MAL";
            news6272Item.residence = "MAL";
            news6272Item.areaCode = "01";

            this.riskObj.s6272Items.s6272Item.push(news6272Item);
        }

        this.riskObj.noOfPersons = this.riskObj.s6272Items.s6272Item.length;

        if (this.clientDetails.client.genericDetails.clienttype == 'P' && this.riskObj.noOfPersons > 2) { //Redmine#2648, 2736
            for (let _insObj of this.riskObj.s6272Items.s6272Item) {
                if (this.caseInfo.businessFunction == 'NewBusiness') {
                    _insObj.familyDiscountPercentage = 10;
                    this._bmsUtilService.s6272SetPremium(_insObj);
                }
                if (this.caseInfo.businessFunction == 'Renewal' && _insObj.isInsuredTerminated != 'Y') {
                    _insObj.familyDiscountPercentage = 10;
                    this._bmsUtilService.s6272SetPremium(_insObj);
                }
            }
            this.setTotalPremium();
            this._alertMsgService.add(new AlertMessage(AlertMessage.WARN, "Family Discount of 10% has been added for each insured", 10000));
        }
    }

    onInclusionDateChange(riskItem, evt, idx) {
        if (!riskItem.inclusionDate) {
            this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Date Inclusion cannot be Empty", 5000));
            this.inclusionDateCtrl[idx].setter(this.headerInfo.effectiveDate, "YYYY-MM-DD", this.inclusionDateCtrl[idx].comp);
            this.memberEffectiveDateCtrl[idx].setter(riskItem.inclusionDate, "YYYY-MM-DD", this.memberEffectiveDateCtrl[idx].comp);
            return;
        }
        let _dateDiff = moment(riskItem.inclusionDate, "YYYY-MM-DD").diff(moment(this.headerInfo.effectiveDate, "YYYY-MM-DD").format("YYYY-MM-DD"), "days");
        if (_dateDiff < 0) {
            this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Date Inclusion cannot be less than Policy Effective Date", 5000));
            this.inclusionDateCtrl[idx].setter(this.headerInfo.effectiveDate, "YYYY-MM-DD", this.inclusionDateCtrl[idx].comp);
            this.memberEffectiveDateCtrl[idx].setter(riskItem.inclusionDate, "YYYY-MM-DD", this.memberEffectiveDateCtrl[idx].comp);
            return;
        }
        _dateDiff = moment(this.headerInfo.endDate, "YYYY-MM-DD").diff(moment(riskItem.inclusionDate, "YYYY-MM-DD").format("YYYY-MM-DD"), "days");
        if (_dateDiff < 0) {
            this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Date Inclusion cannot be more than Policy End Date", 5000));
            this.inclusionDateCtrl[idx].setter(this.headerInfo.effectiveDate, "YYYY-MM-DD", this.inclusionDateCtrl[idx].comp);
            this.memberEffectiveDateCtrl[idx].setter(riskItem.inclusionDate, "YYYY-MM-DD", this.memberEffectiveDateCtrl[idx].comp);
            return;
        }
        this.memberEffectiveDateCtrl[idx].setter(riskItem.inclusionDate, "YYYY-MM-DD", this.memberEffectiveDateCtrl[idx].comp);
        //riskItem.memberEffectiveDate = riskItem.inclusionDate;
    }

    selectRisk(risk) {
        this.removeRiskContent();
        if (risk != null) {
            //SST Code
            this.riskObj.SST = Number(this.riskObj.SST);
            this.riskObj.GST = Number(this.riskObj.GST);
            let tempClientObj = BMSConstants.getClientObj();
            if (tempClientObj.client.genericDetails.clienttype == "P") {
                this.riskObj.SST = Number(0);
                this.headerInfo.SSTTaxRate = this.riskObj.SST;
                this.riskObj.sstAmount = 0;
            } else {
                if (this.riskObj.SST == 0) {
                    let respObj = this._bmsUtilService.getTAXDetails();
                    if (respObj != undefined && respObj != "") {
                        this.headerInfo.SSTTaxRate = Number(respObj[0].old.ITEMPF.GST);
                        this.headerInfo.GSTTaxRate = Number(respObj[1].old.ITEMPF.GST);

                        this.riskObj.SST = Number(this.headerInfo.SSTTaxRate);
                        this.riskObj.GST = Number(this.headerInfo.GSTTaxRate);
                    }
                }
            }
            //End
            let idx = this.riskObj.s6272Items.s6272Item.indexOf(risk);
            this.currentRiskObj = risk;
            this.loadComponent(["S6272Component", "app/bms/components/proposal/newbusinessrisks/s6271/s6272.module", "S6272Module"], null);
        }
    }

    removeRisk(risk, idx) {
        if (this.currentRiskObj != null && this.currentRiskObj.itemNo == risk.itemNo) {
            this.removeRiskContent();
            this.currentRiskObj = null;
        }
        this.riskObj.s6272Items.s6272Item.splice(this.riskObj.s6272Items.s6272Item.indexOf(risk), 1);

        //Redmine#2648, 2736
        if (this.clientDetails.client.genericDetails.clienttype == 'P' && this.riskObj.s6272Items.s6272Item.length == 2) {
            for (let _insObj of this.riskObj.s6272Items.s6272Item) {
                _insObj.familyDiscountPercentage = 0;
                this._bmsUtilService.s6272SetPremium(_insObj);
            }
            this._alertMsgService.add(new AlertMessage(AlertMessage.WARN, "Family Discount of 10% has been removed since only allowed when more than 2 insured added", 10000));
        }

        this.inclusionDateCtrl.splice(idx, 1);
        this.memberEffectiveDateCtrl.splice(idx, 1);
        this.resetItmNumber();
        this.setTotalPremium();
        this.setTotalSI();
        this.riskObj.noOfPersons = this.riskObj.s6272Items.s6272Item.length;
        this.isManuallyReferred = (this.riskObj.symRiskClassification != "Referred" && this.riskObj.riskClassification == "Referred") ? true : false;
        this.checkReferredRisk(this);
    }

    resetItmNumber() {
        for (let risk of this.riskObj.s6272Items.s6272Item) {
            let index = this.riskObj.s6272Items.s6272Item.indexOf(risk);
            risk.itemNo = (index + 1);
        }
    }

    populateLovs() {
        let riskFilter = (this.riskObj.riskType.length == 2) ? this.riskObj.riskType + ' ' : this.riskObj.riskType;
        let riskTypeFilterDetails = [new SearchFilter("DESCITEM", riskFilter, "STARTSWITH", "AND")];
        let riskTypeFilterNodes = this.lovDropDownService.createFilter(riskTypeFilterDetails);

        let referralAgeLimitNodes = this.lovDropDownService.createFilter([new SearchFilter("DESCITEM", this.headerInfo.contractType, "EQ", "AND")]);

        this.lovDropDownService.createLOVDataList(["Occupation"]);
        let lovFields = [
            new LOV_Field("ALL", "ALL", "NEW BUSINESS", "ALL", "NEW", "ALL", "Occupation", "LOV", [], "T3644", "Occupation", "callbackForOccListLoad"),
            new LOV_Field("ALL", "MED", "ALL", "ALL", "ALL", "ALL", "Referral Age Limits", "LOV", referralAgeLimitNodes, "T7253", "referralAgeLimits", "callbackReferralAgeLimits")
        ];

        this.lovDropDownService.util_populateLOV(lovFields, this);
    }

    callbackReferralAgeLimits(scopeObject) {
        if (this.riskObj.insuredAge == 0) {
            this.calculateInsuredAge();
            this.checkReferredRiskConditions();
        }
    }

    callbackForOccListLoad(scopeObject) {
        if (scopeObject.riskObj.occupationCode) {
            let _occRec = scopeObject.lovDropDownService.lovDataList.Occupation.find((_item) => _item.VALUE == scopeObject.riskObj.occupationCode);
            if (_occRec) {
                if (!scopeObject.riskObj.occupationDescription)
                    scopeObject.riskObj.occupationDescription = _occRec.DESCRIPTION;
            }
            else {
                scopeObject.riskObj.occupationCode = '';
                scopeObject.riskObj.occupationDescription = '';
            }
        }
    }

    calculateInsuredAge() {
        if (this.riskObj && this.headerInfo.effectiveDate && this.riskObj.dateOfBirth) {
            let _effectiveDate = moment(this.headerInfo.effectiveDate, "YYYY-MM-DD");
            let _insuredDOB = moment(this.riskObj.dateOfBirth, "YYYY-MM-DD");

            let dobYear = _insuredDOB.year();
            let effectiveYear = _effectiveDate.year();
            let age = effectiveYear - dobYear;

            this.riskObj.insuredAge = age;
        }
        else {
            this.riskObj.insuredAge = 0;
            // this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Date of Birth or Inclusion Date cannot be empty or age cannot be zero.", 5000));
        }
    }

    onOccChange(ev) {
        this.riskObj.occupationCode = ev.value;
        this.riskObj.occupationDescription = (ev.record.DESCRIPTION) ? ev.record.DESCRIPTION.slice(0, 40) : "";
    }

    /*checkReferredRisk(comp) {
        //check if insured classification is referred
        comp.checkIfAnyofInsuredAreReferred(comp);
        if(comp.isAnyInsuredReferred){
            comp.riskObj.symRiskClassification="Referred"; 
            comp.riskObj.riskClassification = comp.riskObj.symRiskClassification;
        }else if(comp.isAnyInsuredDeclined){
            comp.riskObj.symRiskClassification="Declined";         
            comp.riskObj.riskClassification = comp.riskObj.symRiskClassification;
        }else{
            if(comp.riskObj.occRiskClassification=="Referred"){
                comp.riskObj.symRiskClassification="Referred";
            }else if(comp.riskObj.occRiskClassification=="Declined"){
                comp.riskObj.symRiskClassification="Declined";
            }else{
                if(comp.riskObj.conveyanceRiskClassification=="Referred")
                    comp.riskObj.symRiskClassification="Referred";
                else
                    comp.riskObj.symRiskClassification="Standard";                    
            }
            comp.riskObj.riskClassification = comp.riskObj.symRiskClassification;
        }
        comp.setRiskClassification(comp);
    }
    
    checkIfAnyofInsuredAreReferred(comp){
        if(comp.riskObj.s6272Items != null && comp.riskObj.s6272Items.s6272Item != null && comp.riskObj.s6272Items.s6272Item.length > 0) {
            for(let insured of comp.riskObj.s6272Items.s6272Item)
            {
                if(insured.riskClassification == 'Referred') {
                    comp.isAnyInsuredReferred=true;
                    comp.isAnyInsuredDeclined=false;
                    break;
                }
                else if(insured.riskClassification == 'Declined') {
                    comp.isAnyInsuredReferred=false;
                    comp.isAnyInsuredDeclined=true;
                    break;
                }else{
                    comp.isAnyInsuredReferred=false;
                    comp.isAnyInsuredDeclined=false;
                }
            }
        }        
    }*/

    checkReferredRisk(comp) {
        //check if insured classification is referred
        comp.checkIfAnyofInsuredAreReferred(comp);

        // let _isManuallyReferred = (comp.riskObj.symRiskClassification !="Referred" && comp.riskObj.riskClassification=="Referred") ? true : false;

        if (comp.isAnyInsuredDeclined) {
            comp.riskObj.symRiskClassification = "Declined";
        }
        else if (comp.riskObj.occRiskClassification == "Declined") {
            comp.riskObj.symRiskClassification = "Declined";
        }
        else if (comp.riskObj.occRiskClassification == "Referred" || comp.riskObj.ageLimitFlag == "G" || comp.riskObj.hasClaimExperience == "Y") {
            comp.riskObj.symRiskClassification = "Referred";
        }
        else if (comp.isAnyInsuredReferred) {
            comp.riskObj.symRiskClassification = "Referred";
        }
        else {
            comp.riskObj.symRiskClassification = "Standard";
        }

        comp.handleRiskClassification(comp);
    }

    checkIfAnyofInsuredAreReferred(comp) {
        comp.isAnyInsuredReferred = false;
        comp.isAnyInsuredDeclined = false;
        if (comp.riskObj.s6272Items != null && comp.riskObj.s6272Items.s6272Item != null && comp.riskObj.s6272Items.s6272Item.length > 0) {
            for (let insured of comp.riskObj.s6272Items.s6272Item) {
                if (insured.riskClassification == 'Referred') {
                    comp.isAnyInsuredReferred = true;
                }
                else if (insured.riskClassification == 'Declined') {
                    comp.isAnyInsuredDeclined = true;
                }
            }

            if (comp.isAnyInsuredDeclined) {
                comp.isAnyInsuredReferred = false;
            }
        }
    }

    setReferredRisk() {
        this.isManuallyReferred = (this.riskObj.symRiskClassification != "Referred" && this.riskObj.riskClassification == "Referred") ? true : false;
        this.checkReferredRisk(this);
        // this.setRiskClassification(this);
        // this.onRiskClsChange.emit('');
    }

    setRiskClassification(comp) {
        if (comp.riskObj.symRiskClassification != null && comp.riskObj.symRiskClassification != "" && (comp.riskObj.symRiskClassification == "Referred" || comp.riskObj.symRiskClassification == "Declined")) {
            let statusTxt = (comp.riskObj.symRiskClassification != null && comp.riskObj.symRiskClassification != "") ? comp.riskObj.symRiskClassification : comp.riskObj.riskClassification;
            comp.riskObj.riskClassificationReason = "System marked as " + statusTxt;
        }
        else {
            if (comp.riskObj.riskClassificationReason != null && comp.riskObj.riskClassificationReason != "" && (comp.riskObj.riskClassificationReason != "System marked as Standard"
                && comp.riskObj.riskClassificationReason.indexOf("System marked as ") != -1)) {
                comp.riskObj.riskClassificationReason = "";
            }
        }
        comp.onRiskClsChange.emit('');
    }

    handleError(response, status, errorText, prms) {
        prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, response.responseJSON.faultstring.text, -1));
    }

    getTotalByProperty(prop, ary) {
        let total = numeral(0);
        let counter = 1;
        //console.log("before entering loop : "+prop + "--------------");
        for (let eachItem of ary) {
            if (eachItem[prop] != null && eachItem[prop] != "") {
                //console.log(">>>>> eachItem["+prop+"]: "+eachItem[prop]+ "");
                total = total.add(numeral().unformat(eachItem[prop]));
            }
        }
        if (total)
            total = numeral(total).format('0.00');
        else
            total = 0;
        return total;
    }
    getTotalByPropertyForSumInsured(prop, ary) {
        let total = numeral(0);
        let counter = 1;
        //console.log("before entering loop : "+prop + "--------------");
        for (let eachItem of ary) {
            if (eachItem[prop] != null && eachItem[prop] != "") {
                //console.log(">>>>> eachItem["+prop+"]: "+eachItem[prop]+ "");
                total = total.add(numeral().unformat(eachItem[prop]));
            }
        }
        if (total)
            total = numeral(total).format('0');
        else
            total = 0;
        return total;
    }

    setClientInfo() {
        let news6272Details = new S6272ItemDetails();
        if (this.clientDetails.client.personalClientDetails) {
            news6272Details.insuredPerson = this.clientDetails.client.personalClientDetails.Name;
            news6272Details.insuredSalutation = this.clientDetails.client.personalClientDetails.saluation;
            if (this.clientDetails.client.personalClientDetails.NRICNo) {
                news6272Details.IdProofNo = this.clientDetails.client.personalClientDetails.NRICNo;
            } else {
                news6272Details.IdProofNo = this.clientDetails.client.personalClientDetails.IdNumber;
            }
            news6272Details.dateOfBirth = moment(this.clientDetails.client.personalClientDetails.dateOfBirth, "YYYYMMDD").format("YYYY-MM-DD");
            news6272Details.maritalStatus = this.clientDetails.client.personalClientDetails.maritalStatus;
            news6272Details.gender = this.clientDetails.client.personalClientDetails.gender;
            news6272Details.occupationCode = this.clientDetails.client.personalClientDetails.occupationCode;
            // news6272Details.occupationDescription = this.clientDetails.client.personalClientDetails.occupationDescription;
            news6272Details.terminationDate = this.clientDetails.client.personalClientDetails.terminationDate;
            news6272Details.itemNo = this.riskObj.s6272Items.s6272Item.length + 1;
            news6272Details.dateStart = this.headerInfo.effectiveDate;
            news6272Details.lastDateEnd = this.headerInfo.endDate;
            news6272Details.riskType = this.riskObj.riskType;
            news6272Details.riskName = this.riskObj.riskName;
            news6272Details.inclusionDate = this.headerInfo.effectiveDate;
            news6272Details.memberEffectiveDate = this.headerInfo.effectiveDate;

            news6272Details.nationality = "MAL";
            news6272Details.homeCity = "MAL";
            news6272Details.residence = "MAL";
            news6272Details.areaCode = "01";

            this.setInsuredGenderFromNRIC(news6272Details);

            this.riskObj.s6272Items.s6272Item.push(news6272Details);
        }
    }

    setInsuredGenderFromNRIC(riskObj) {
        if (riskObj.IdProofNo) {
            let isValidNRICFormat = new RegExp("[0-9]{6}-[0-9]{2}-[0-9]{4}$").test(riskObj.IdProofNo);
            if (isValidNRICFormat == true) {
                if (riskObj.IdProofNo) {
                    let lastDigit = riskObj.IdProofNo.substring(riskObj.IdProofNo.length - 1);
                    if (/^-?\d*[02468]$/.test(lastDigit)) {
                        riskObj.gender = 'F';
                    } else if (/^-?\d*[13579]$/.test(lastDigit)) {
                        riskObj.gender = 'M';
                    }
                }
            }
        }
    }

    setTotalPremium() {
        this.riskObj.originalTotalPremium = this.getTotalByProperty("totalAnnualPremium", this.riskObj.s6272Items.s6272Item);
        this.riskObj.rebate = this.headerInfo.rebate;
        this.riskObj.rebateAmount = Number(numeral().unformat(this.riskObj.originalTotalPremium) / 100 * numeral().unformat(this.riskObj.rebate));
        this.riskObj.discountedPremium = numeral().unformat(this.riskObj.originalTotalPremium) - numeral().unformat(this.riskObj.rebateAmount);
        //SST Code
        if (parseFloat("" + this.riskObj.GST) > 0 && this.riskObj.discountedPremium > 0) {
            let tempGSTAmount = numeral(numeral((this.riskObj.discountedPremium * parseFloat("" + this.riskObj.GST)) * 0.01).format(this.premiumFormat)).value();
            this.riskObj.gstAmount = numeral(numeral(BMSUtilService.calculatePremiumAmount(tempGSTAmount, "G")).format(this.premiumFormat)).value();
        }
        else {
            this.riskObj.gstAmount = 0;
        }
        let tempClientObj = BMSConstants.getClientObj();
        if (tempClientObj.client.genericDetails.clienttype != "P" && parseFloat("" + this.riskObj.SST) > 0 && this.riskObj.discountedPremium > 0) {
            let tempSSTAmount = numeral(numeral((this.riskObj.discountedPremium * parseFloat("" + this.riskObj.SST)) * 0.01).format(this.premiumFormat)).value();
            this.riskObj.sstAmount = (tempSSTAmount > 0) ? numeral(numeral(BMSUtilService.calculatePremiumAmount(tempSSTAmount, "S")).format(this.premiumFormat)).value() : 0;
        }
        else {
            this.riskObj.sstAmount = 0;
            this.riskObj.SST = Number(0);
        }

        //this.riskObj.totalPremium = numeral().unformat(this.riskObj.discountedPremium) + numeral().unformat(this.riskObj.gstAmount);
        this.riskObj.totalPremium = numeral().unformat(this.riskObj.discountedPremium) + numeral().unformat(this.riskObj.gstAmount) + numeral().unformat(this.riskObj.sstAmount);
        //End
        this.riskObj.gstAmount = numeral(this.riskObj.gstAmount).format('0.00');
        this.riskObj.totalPremium = numeral(this.riskObj.totalPremium).format('0.00');
        this.riskObj.rebateAmount = numeral(this.riskObj.rebateAmount).format('0.00');
        this.riskObj.discountedPremium = numeral(this.riskObj.discountedPremium).format('0.00');
        this.setTotalPP();
        this.onPremiumChange.emit(this.riskObj.totalPremium);
    }

    setTotalSI() {
        this.setBigSI();
        this.riskObj.capitalSumInsured = this.riskObj.bigCapitalSumInsured;
        this.validateCapitalSumInsured();
        //this.onSIChange.emit(this.riskObj.capitalSumInsured);
    }

    getHighestCRIISI() {
        let bigCRIISI = 0;
        for (let eachItem of this.riskObj.s6272Items.s6272Item) {
            if (eachItem.CRIISI != null && "" + eachItem.CRIISI != "") {
                bigCRIISI = (parseFloat("" + eachItem.CRIISI) > bigCRIISI) ? parseFloat("" + eachItem.sumInsured) : bigCRIISI;
            }
        }
        this.riskObj.CRIISI = bigCRIISI;
        return bigCRIISI;
    }

    setBigSI() {
        let bigSI = 0;
        for (let eachItem of this.riskObj.s6272Items.s6272Item) {
            if (eachItem.sumInsured != null && "" + eachItem.sumInsured != "") {
                bigSI = (parseFloat("" + eachItem.sumInsured) > bigSI) ? parseFloat("" + eachItem.sumInsured) : bigSI;
            }
        }
        this.riskObj.bigCapitalSumInsured = bigSI;
    }

    setTotalPP() {
        //this.riskObj.postingPremium = this.getTotalByProperty("postingPremium",this.riskObj.s6272Items.s6272Item);
        this.riskObj.postingPremium = ((this.riskObj.totalPremium) / 365) * this.calcDays();
    }

    calcDays() {
        let date1 = moment(this.headerInfo.effectiveDate, "YYYY-MM-DD");
        let date2 = moment(this.headerInfo.endDate, "YYYY-MM-DD");
        return date2.diff(date1, 'days') + 1;//added +1 to always include endDate for calculation
        //return Math.ceil(timeDiff / (1000 * 3600 * 24));
    }

    loadComponent(component, prms) {
        let input = new DCLInput();
        input.component = component;
        input.viewContainerRef = this.contentArea;
        input.inputs = { parentRiskObj: this.riskObj, riskObj: this.currentRiskObj, headerInfo: this.headerInfo, clientDetails: this.clientDetails };
        input.callback = this.setOutputHandle;
        input.prms = { comp: this, prms: prms };
        this._dcl.loadComponent(input);
    }

    setOutputHandle(compRef, prms) {
        prms.prms.comp.selectedRiskComponent = compRef;
        if (compRef.instance.onPremiumChange != null) {
            compRef.instance.onPremiumChange.subscribe(() => {
                prms.prms.comp.setTotalPremium();
            });
        }
        if (compRef.instance.onSIChange != null) {
            compRef.instance.onSIChange.subscribe(() => {
                prms.prms.comp.setTotalSI();
            });
        }
        if (compRef.instance.onRiskClsChange != null) {
            compRef.instance.onRiskClsChange.subscribe(() => {
                prms.prms.comp.setReferredRisk();
            });
        }
        if (compRef.instance.emitonPlanChangeHandler != null) {
            compRef.instance.emitonPlanChangeHandler.subscribe((plancode) => { prms.prms.comp.onPlanChangeHandler(plancode); });
        }

        if (compRef.instance.prms != null) {
            compRef.instance.prms = prms.prms.prms;
        }
    }

    duplicateCheck() {
        // debugger;
    }

    onPlanChangeHandler(plancode1) {
        if (this.clausesComp)
            this.clausesComp.setDefaultClause(plancode1);

    }

    removeRiskContent() {
        if (this.selectedRiskComponent != null)
            this._dcl.unloadComponent(this.selectedRiskComponent);
        this.currentRiskObj = null;
        jQuery(this.el).find("#S6272RiskComponent").empty();
    }

    validateCapitalSumInsured() {
        if (this.riskObj.RIRetentionCode && this.riskObj.isRIOverWrittenByUW == 'N') {

            this._bmsUtilService.getTotalGrossCapacity(this.riskObj.RIRetentionCode).subscribe((data) => this.compareSIWithTotGrossCap(data));

        }
        else
            this.setRIMethodEditableFlag();
    }

    compareSIWithTotGrossCap(totGrossCap) {

        let _totalGrossCapacity = (!totGrossCap) ? 0 : parseFloat("" + totGrossCap);
        this.riskObj.totalGrossCapacity = _totalGrossCapacity;
        //let _capitalSumInsured = parseFloat(""+this.riskObj.capitalSumInsured);
        let _sumInsuredAmount = 0;
        _sumInsuredAmount = parseFloat("" + this.riskObj.capitalSumInsured);
        if (_totalGrossCapacity > 0 && _sumInsuredAmount > _totalGrossCapacity && (this.riskObj.RIMethod == null || this.riskObj.RIMethod == "" || parseFloat("" + this.riskObj.RIMethod) != 8)) {
            this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Total Sum Insured is greater than Total Gross Capacity: " + _totalGrossCapacity + ",  RI is Required.", 10000));
            this.riskObj.RIRequired = "Yes";
            this.riskObj.RIMethod = "8";
        }
        else if (_sumInsuredAmount <= _totalGrossCapacity) {
            this.riskObj.RIRequired = "No";
            this.riskObj.RIMethod = this.riskObj.RIMethodSys;
        }
        this._riService.setRI().subscribe();
        this.setRIMethodEditableFlag();
    }

    setRIMethodEditableFlag() {
        let _sumInsuredAmount = 0;
        _sumInsuredAmount = parseFloat("" + this.riskObj.capitalSumInsured);
        let _totalGrossCapacity = parseFloat("" + this.riskObj.totalGrossCapacity);
        if (_sumInsuredAmount > _totalGrossCapacity && this.isUnderWriter == "N") {
            this.isRIMethodEditable = "N";
        }
        else {
            this.isRIMethodEditable = "Y";
        }
    }

    checkReferredRiskConditions() {
        this.isManuallyReferred = (this.riskObj.symRiskClassification != "Referred" && this.riskObj.riskClassification == "Referred") ? true : false;
        let _reasons = new Reasons();
        let isReferredRisk = false;
        let isDeclinedRisk = false;

        if (this.riskObj.hasClaimExperience == 'Y') {
            isReferredRisk = true;
            _reasons.reason.push("With Claim Experience.");
        }

		/*
		let _ageLimitRec = this.lovDropDownService.lovDataList.referralAgeLimits.find((_data)=> _data.DESCITEM == this.headerInfo.contractType);
		if (_ageLimitRec && this.riskObj.dateOfBirth && this.riskObj.occupationCode) {
			let _minAgeLimit = 0;
			let _maxAgeLimit = 0;			
			let _minAgeLimitInd = 'Y';
			let _maxAgeLimitInd = 'Y';			
			
			let _adultMinAgeLimit = (_ageLimitRec.ZAGELMT03) ? parseInt(""+_ageLimitRec.ZAGELMT03) : 0;
			let _adultMaxAgeLimit = (_ageLimitRec.ZAGELMT05) ? parseInt(""+_ageLimitRec.ZAGELMT05) : 0;
			
			let _chidldMinAgeLimit = (_ageLimitRec.ZAGELMT04) ? parseInt(""+_ageLimitRec.ZAGELMT04) : 0;	
			let _chidldMaxAgeLimit = (_ageLimitRec.ZAGELMT06) ? parseInt(""+_ageLimitRec.ZAGELMT06) : 0;
						
			
			if( _chidldMinAgeLimit > 0 && _chidldMaxAgeLimit > 0 && (this.riskObj.occupationCode == '7STU' || this.riskObj.occupationCode == '7CLD') ){
				_minAgeLimit = _chidldMinAgeLimit;
				_maxAgeLimit = _chidldMaxAgeLimit;
				_minAgeLimitInd = (_ageLimitRec.ZAGEIND02) ? _ageLimitRec.ZAGEIND02 : "Y";
				_maxAgeLimitInd = (_ageLimitRec.ZAGEIND03) ? _ageLimitRec.ZAGEIND03 : "Y";
			}
			else {
				
				_minAgeLimit = _adultMinAgeLimit;
				_maxAgeLimit = _adultMaxAgeLimit;
				if( _chidldMinAgeLimit == 0 || _chidldMaxAgeLimit == 0){
					_minAgeLimitInd = (_ageLimitRec.ZAGEIND02) ? _ageLimitRec.ZAGEIND02 : "Y";
					_maxAgeLimitInd = (_ageLimitRec.ZAGEIND03) ? _ageLimitRec.ZAGEIND03 : "Y";
				}				
			}
			
			if(_maxAgeLimitInd == 'D'){
				if(this.headerInfo.effectiveDate && this.riskObj.dateOfBirth){
					let _effectiveDate = moment(this.headerInfo.effectiveDate, "YYYY-MM-DD");
					let _insuredDOB = moment(this.riskObj.dateOfBirth, "YYYY-MM-DD");
					
					let _ageInDays = moment.duration(_effectiveDate.diff(_insuredDOB)).asDays();
					if( _ageInDays > _maxAgeLimit){
						this.riskObj.ageLimitFlag = "G";
					}
				}
			}
			else if(Number(this.riskObj.insuredAge) > _maxAgeLimit) {	
				this.riskObj.ageLimitFlag = "G";
			}
			
			if(this.riskObj.ageLimitFlag != "G"){
				if(_minAgeLimitInd == 'D'){
					if(this.headerInfo.effectiveDate && this.riskObj.dateOfBirth){
						let _effectiveDate = moment(this.headerInfo.effectiveDate, "YYYY-MM-DD");
						let _insuredDOB = moment(this.riskObj.dateOfBirth, "YYYY-MM-DD");					
						
						let _ageInDays = moment.duration(_effectiveDate.diff(_insuredDOB)).asDays();
						if( _ageInDays < _minAgeLimit){
							this.riskObj.ageLimitFlag = "L";
						}
					}
				}
				else if(Number(this.riskObj.insuredAge) < _minAgeLimit) {
					this.riskObj.ageLimitFlag = "L";
				}
			}
		
			if(this.riskObj.ageLimitFlag == "G"){
				isReferredRisk = true;
				_reasons.reason.push(" Main Insured ("+this.riskObj.riskNumber+") Age greater than maximum allowed age "+_maxAgeLimit);				
			}
			else if(this.riskObj.ageLimitFlag == ""){
				this.riskObj.ageLimitFlag = "VALID";
			}
		}
		*/

        this.riskObj.riskClassificationReasons.reasons = _reasons;

        if (isDeclinedRisk) {
            this.riskObj.symRiskClassification = "Declined";
        }
        else if (isReferredRisk) {
            this.riskObj.symRiskClassification = "Referred";
        }
        else this.riskObj.symRiskClassification = "Standard";

        // this.handleRiskClassification(this);
        this.checkReferredRisk(this);
    }

    handleRiskClassification(comp) {
        if (comp.riskObj.symRiskClassification == "Declined")
            comp.riskObj.riskClassification = "Declined";
        else if (comp.riskObj.symRiskClassification == "Referred" || comp.riskObj.riRiskClassification == "Referred")
            comp.riskObj.riskClassification = "Referred";
        else
            comp.riskObj.riskClassification = "Standard";

        comp.setRiskClassification(comp);
    }
    emitFlagChange() { //MYS-2018-0878 Rating flag changes 
        this.onRtngFlgChange.emit("");
    }

}