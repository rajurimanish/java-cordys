/**
    No      Date            Description                                     Changed By
	====    ==========      ===========                                     ==========
	KA001   31/07/2019      MYS-2018-0878- Medical Renewals                 DKA
    VK013   12/08/2019   	MYS-2019-0595- General Page(Print) alignment    VKR                
 */
import { Component, OnInit, ViewChild, ElementRef, EventEmitter, AfterViewInit, ViewContainerRef } from '@angular/core';
declare var Observer: any;
import { DCLInput, CustomDCLService } from '../../../../../common/services/customdcl.service';
import { LOV_Field, LOVDropDownService, SearchFilter } from "../../../../../common/services/lovdropdown/lovdropdown.service";
import { S6271, S6272ItemDetails, Benefit, BenefitItem, AdditionalCoverageDetails, AdditionalCoverage } from './appobjects/s6271';
import { ModalInput } from '../../../../../common/components/utility/modal/modal';
import { SearchInput } from "../../../../../common/components/utility/search/genericsearch";
import { Clause } from "../appobjects/clause";
import { ClausesComponent } from "../uimodules/clauses.component";
import { NomineeDetails } from "../appobjects/nomineeslist";
import { GetLOVData, SearchAdvancedConfig, Filter } from '../../../../../common/components/utility/search/search.requests';
import { CordysSoapWService } from "../../../../../common/components/utility/cordys-soap-ws";
import { ProposalHeader } from '../../proposalheader/appobjects/proposalheader';
import { ClientDetails } from '../../../../../common/components/client/appobjects/client';
import { AlertMessagesService } from '../../../../../common/components/utility/alertmessage/alertmessages.service';
import { AlertMessage } from '../../../../../common/components/utility/alertmessage/alertmessages.model';
import { ExtraTextDialogData } from "../dialogs/extratext.dialog.data";
import { BMSConstants } from '../../../common/constants/bms_constants';
declare var Rx: any;
import { S6272AdditionalBenefits } from './dialogs/s6272additionalbenefits.component';
import { ReferredReason, Reasons } from '../../proposalheader/appobjects/referredreason';
import { ReferralReasons, ReferralReason } from '../appobjects/referralReasons';
import { BMSUtilService } from "../../../../services/bms.util.service";
import { CaseInfo } from '../../../../../common/components/appobjects/caseinfo';

declare var moment: any;
declare var jQuery: any;
declare var numeral: any;

@Component({
    selector: 's6272-component',
    templateUrl: 'app/bms/components/proposal/newbusinessrisks/s6271/s6272.template.html',
    inputs: ["parentRiskObj", "riskObj", 'clientDetails', 'headerInfo'],
    outputs: ['onPremiumChange', 'onSIChange', 'onpostedpremiumchange', 'onRiskClsChange', 'emitDuplicateCheck', 'emitonPlanChangeHandler', 'onRtngFlgChange']
})
export class S6272Component implements OnInit {
    @ViewChild(ClausesComponent) private clausesComp: ClausesComponent;
    @ViewChild('xtModal', { read: ViewContainerRef }) contentArea: ViewContainerRef;
    @ViewChild('paCompModal', { read: ViewContainerRef }) compContentArea: ViewContainerRef;

    private el: HTMLElement;
    private isCollapsedMode: boolean = false;
    private collapseInsuredInfo: boolean = false;
    private isNomineeInfoCollapsed: boolean = false;
    private isCoverInfoCollapsed: boolean = false;
    private collapseClausesInfo: boolean = false;
    private isExclusionPageCollapsed: boolean = false;
    private isAdditionalBenefitsCollapsed: boolean = false;
    private isGeneralPageCollapsed: boolean = false;
    private isLoadingSectionCollapsed: boolean = false;
    private isDeductibleSectionCollapsed: boolean = false;
    private isDiscountSectionCollapsed: boolean = false;
    private isOptionalCISectionCollapsed: boolean = false;
    private isOptionalMaternitySectionCollapsed: boolean = false;

    private DOBCtrl: any;
    private MaternityDateCtrl: any;
    private CRIIDateCtrl: any;
    public defaultClauseCode: string = "";

    public riskObj: S6272ItemDetails;
    public parentRiskObj: S6271;
    public disableForm = 'N';
    public clientDetails: ClientDetails;
    public headerInfo: ProposalHeader;
    onPremiumChange = new EventEmitter<any>();
    onSIChange = new EventEmitter<any>();
    onpostedpremiumchange = new EventEmitter<any>();
    onRiskClsChange = new EventEmitter<any>();
    emitDuplicateCheck = new EventEmitter<any>();
    emitonPlanChangeHandler = new EventEmitter<any>();
    onRtngFlgChange = new EventEmitter<any>();

    public siFormat: string = "0,00";
    public premiumFormat: string = "0,00.00";
    public rateFormat: string = "0.00000";
    public loadFormat: string = "0.00";
    public percentFormat: string = "0.00";

    public search: String = "";
    public position = 1;
    public sizeObj = { length: 0, orglength: 0 };
    public contentSizeObs: any;
    public itemPerPage = 5;
    public maxPageCount = 10;

    private renewalBonusAmountCtrl: any;
    private renewalBonusPercentageCtrl: any;
    private disableRenewalBonusAmount = "N";
    private disableRenewalBonusPercentage = "N";
    public minimumAge = 16;
    public coverageObj: any;
    public coverageName: string;
    public total: number = 0;
    public _ABPlansList: LocalABPlans[];
    private referralReasons = [];

    private caseInfo: CaseInfo;

    constructor(public dcl: CustomDCLService, private lovDropDownService: LOVDropDownService, private _soapService: CordysSoapWService, public _alertMsgService: AlertMessagesService, private _bmsUtilService: BMSUtilService) {

    }

    ngAfterViewInit() {

        if (this.headerInfo.asyncPostingStatus == "InProgress") {
            this.disableForm = "Y";
        } else if (this.riskObj.contractNumber != "") {
            this.disableForm = "Y";
        }
        else {
            this.disableForm = "N";
        }
    }

    setFormDisabled() {
        if (jQuery("#bmsForm").prop("disabled") == true) {
            this.disableForm = "Y";
        }
    }

    ngOnInit() {
        this.populateLOVs();
        // if (this.clientDetails)
        // this.setClientInfo();
        if (this.riskObj.riskType == 'FSI') {
            this.clearFHISpecificDataForFSI();
        }
        this.caseInfo = BMSConstants.getBMSObj().ApplicationBusinessObject.caseInfo;
        if(this.caseInfo.businessFunction == 'Renewal' && (['FSI','FHG','FHI'].indexOf(this.riskObj.riskType) != -1) ){ //Medical Renewals - KA001
            this.setPremium();
        }
    }

    clearFHISpecificDataForFSI() {
        this.riskObj.MATRPlanCode = "";
        this.riskObj.MATRNorm = 0;
        this.riskObj.MATRComp = 0;
        this.riskObj.MaternityDate = "";
        //this.MaternityDateCtrl.setter("EMPTY", "YYYY-MM-DD", this.MaternityDateCtrl.comp);
        this.riskObj.maternityPremium = 0;
        this.riskObj.CRIIPlanCode = "";
        this.riskObj.CRIISI = 0;
        this.riskObj.CRIIDate = "";
        //this.CRIIDateCtrl.setter("EMPTY", "YYYY-MM-DD", this.CRIIDateCtrl.comp);
    }

    private populateLOVs(): void {

        // this.lovDropDownService.createLOVDataList(["Salutation", "Occupation", "ratingClass", "Gender", "category", "MaritalStatus", "nationality", "residence", "areaCode","PlanCodes"]);
        // this.lovDropDownService.createLOVDataList(["Salutation", "Occupation", "ratingClass", "Gender", "MaritalStatus", "nationality", "residence", "areaCode","Plans","DeductibleType","MATRPlans","CRIIPlan","TPA"]);
        this.lovDropDownService.createLOVDataList(["Salutation", "Occupation", "ratingClass", "Gender", "MaritalStatus", "nationality", "residence", "areaCode", "Plans", "DeductibleType", "MATRPlans", "CRIIPlan", "referralReasons", "referralAgeLimits"]);
		/*let categoryFilterNodes =[];
		if(this.riskObj.riskType=='FHI'){
            let riskFilter = (this.riskObj.riskType.length==2) ? this.riskObj.riskType+' ' : this.riskObj.riskType;
			let categoryFilterDetails = [new SearchFilter("DESCITEM", riskFilter, "STARTSWITH", "AND")];
			categoryFilterNodes = this.lovDropDownService.createFilter(categoryFilterDetails);
		}*/
        let riskFilterNodes = [];
        let riskFilter = (this.riskObj.riskType.length == 2) ? this.riskObj.riskType + ' ' : this.riskObj.riskType;
        let riskFilterDetails = [new SearchFilter("DESCITEM", riskFilter, "STARTSWITH", "AND")];
        riskFilterNodes = this.lovDropDownService.createFilter(riskFilterDetails);

        let referralAgeLimitNodes = this.lovDropDownService.createFilter([new SearchFilter("DESCITEM", riskFilter, "EQ", "AND")]);
        let lovFields = [
            new LOV_Field("ALL", "CLIENT", "ALL", "ALL", "NEW", "CLIENT_DETAILS", "Salutation", "LOV", [], "DESCPF", "Salutation", null),
            new LOV_Field("ALL", "MIS", "ALL", "ALL", "ALL", "ALL", "Occupation", "LOV", riskFilterNodes, "T9109", "Occupation", "callbackForOccListLoad"),
            // new LOV_Field("ALL", "ALL", "NEW BUSINESS", "ALL", "NEW", "ALL", "Occupation", "LOV", [], "T3644", "Occupation", null),
            new LOV_Field("ALL", "PERSONAL ACCIDENT", "NEW BUSINESS", "ALL", "NEW", "PERSONAL ACCIDENT", "RatingClass", "LOV", [], "DESCPF", "ratingClass", null),
            new LOV_Field("ALL", "MOTOR", "NEW BUSINESS", "ALL", "NEW", "NAMED_DRIVER", "Sex", "LOV", [], "DESCPF", "Gender", null),
            //new LOV_Field("ALL", "ALL", "ALL", "ALL", "ALL", "ALL", "Category", "LOV", categoryFilterNodes, "DESCPF", "category", null),
            new LOV_Field("ALL", "CLIENT", "ALL", "ALL", "NEW", "CLIENT_DETAILS", "Marital Status", "LOV", [], "DESCPF", "MaritalStatus", null),
            new LOV_Field("ALL", "ALL", "ALL", "ALL", "ALL", "ALL", "Nationality", "LOV", [], "DESCPF", "nationality", null),
            new LOV_Field("ALL", "ALL", "ALL", "ALL", "ALL", "ALL", "Residence", "LOV", [], "DESCPF", "residence", null),
            new LOV_Field("ALL", "ALL", "ALL", "ALL", "ALL", "ALL", "AreaCode", "LOV", [], "DESCPF", "areaCode", null),
            new LOV_Field("ALL", "ALL", "ALL", "ALL", "ALL", "S6272", "PlanCodes", "LOV", riskFilterNodes, "T7402", "Plans", null),
            new LOV_Field("ALL", "ALL", "ALL", "ALL", "ALL", "S6272", "Deductible", "LOV", riskFilterNodes, "T7399", "DeductibleType", "deductible_LOVSuccessHandler"),
            new LOV_Field("ALL", "ALL", "ALL", "ALL", "ALL", "S6272", "MATRPlan", "LOV", riskFilterNodes, "T7404", "MATRPlans", "MATRPlans_LOVSuccessHandler"),
            new LOV_Field("ALL", "ALL", "ALL", "ALL", "ALL", "S6272", "CRIIPlan", "LOV", riskFilterNodes, "T7403", "CRIIPlan", "CRIIPlan_LOVSuccessHandler"),
            new LOV_Field("ALL", "MED", "ALL", "ALL", "ALL", "ALL", "Referral Reasons", "LOV", [], "DESCPF", "referralReasons", "callbackForReferralReasons"),
            new LOV_Field("ALL", "MED", "ALL", "ALL", "ALL", "ALL", "Referral Age Limits", "LOV", referralAgeLimitNodes, "T7253", "referralAgeLimits", "callbackReferralAgeLimits")
        ];
        this.lovDropDownService.util_populateLOV(lovFields, this);

        //new LOV_Field("ALL", "ALL", "ALL", "ALL", "ALL", "S6272", "TPA", "LOV", [], "T7398", "TPA", "TPA_LOVSuccessHandler")

        if (this.riskObj.riskType == "FSI") {
            this.populateABCategoryForFSIProduct();
            this.populateABPlans();
        }
    }

    callbackForOccListLoad(scopeObject) {
        if (scopeObject.riskObj.occupationCode && !scopeObject.riskObj.occupationDescription) {
            let _occRec = scopeObject.lovDropDownService.lovDataList.Occupation.find((_item) => _item.VALUE == scopeObject.riskObj.occupationCode);
            if (_occRec) {
                scopeObject.riskObj.occupationDescription = _occRec.DESCRIPTION;
            }
            else {
                scopeObject.riskObj.occupationCode = '';
                scopeObject.riskObj.occupationDescription = '';
            }
        }
    }

    callbackReferralAgeLimits(scopeObject) {
        if (this.riskObj.insuredAge == 0) {
            this.checkReferredRiskConditions();
        }
    }

    populateABCategoryForFSIProduct() {
        this.lovDropDownService.createLOVDataList(["ABCategory"]);
        let riskFilterNodes = [];
        let riskFilter = (this.riskObj.riskType.length == 2) ? this.riskObj.riskType + ' ' : this.riskObj.riskType;
        let riskFilterDetails = [new SearchFilter("DESCITEM", riskFilter, "STARTSWITH", "AND")];
        riskFilterNodes = this.lovDropDownService.createFilter(riskFilterDetails);
        let lovFields = [
            new LOV_Field("ALL", "ALL", "ALL", "ALL", "ALL", "S6816", "ABCategory", "LOV", riskFilterNodes, "DESCPF", "ABCategory", null)
        ];
        this.lovDropDownService.util_populateLOV(lovFields, this);
    }

    populateABPlans() {
        let request: GetLOVData = new GetLOVData().getRequest('ALL', 'ALL', 'ALL', 'ALL', 'ALL', 'S6816', 'ABPlan', 'LOV');
        request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        request.ADVANCE_CONFIG_XML.FILTERS = new Filter();
        request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push(
            { "@FIELD_NAME": "DESCITEM", "@FIELD_VALUE": this.riskObj.riskType, "@OPERATION": "STARTSWITH", "@CONDITION": "AND" }
        );
        this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, null, null, false, null).success((data) => {
            if (data.tuple) {
                let ary = [];

                if (data.tuple != null && !Array.prototype.isPrototypeOf(data.tuple)) {
                    ary = [data.tuple];
                }
                else if (data.tuple != null) {
                    ary = data.tuple;
                }
                this._ABPlansList = [];
                for (let item of ary) {
                    let vBenefit: LocalABPlans = {
                        "COMB_DESC": item.old.DESCPF.COMB_DESC,
                        "DESCITEM": item.old.DESCPF.DESCITEM,
                        "VALUE": item.old.DESCPF.VALUE,
                        "DESCRIPTION": item.old.DESCPF.DESCRIPTION
                    };
                    this._ABPlansList.push(vBenefit);
                }

            }
        }).error((response, status, errorText) => {
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error while getting Additional Benefit Plans", 5000));
        });
    }

    deductible_LOVSuccessHandler(scopeObj) {
        /*let temp1 = scopeObj.lovDropDownService.lovDataList.DeductibleType;
        let temp2 = [{"VALUE": "", "DESCRIPTION":"--Select Value--","EXPERC": "","EXCESS": ""}];
        scopeObj.lovDropDownService.lovDataList.DeductibleType = [].concat(temp2,temp1);*/
    }

    MATRPlans_LOVSuccessHandler(scopeObj) {
        // let temp1 = scopeObj.lovDropDownService.lovDataList.MATRPlans;
        // let temp2 = [{"VALUE": "", "COMB_DESC":"--Select Value--","DESCRIPTION": "","SHORTDESC": "","ZMPAID_01":"0","ZMPAID_02":""}];
        // scopeObj.lovDropDownService.lovDataList.MATRPlans = [].concat(temp2,temp1);        
    }

    CRIIPlan_LOVSuccessHandler(scopeObj) {
        let temp1 = scopeObj.lovDropDownService.lovDataList.CRIIPlan;
        let temp2 = [{ "VALUE": "", "COMB_DESC": "--Select Value--", "DESCRIPTION": "", "SHORTDESC": "" }];
        scopeObj.lovDropDownService.lovDataList.CRIIPlan = [].concat(temp2, temp1);

    }

    TPA_LOVSuccessHandler(scopeObj) {
        let temp1 = scopeObj.lovDropDownService.lovDataList.TPA;
        let temp2 = [{ "VALUE": "", "COMB_DESC": "--Select Value--", "DESCRIPTION": "", "SHORTDESC": "" }];
        scopeObj.lovDropDownService.lovDataList.TPA = [].concat(temp2, temp1);
    }

    callbackForReferralReasons(scopeObject) {
        for (let _refReason of scopeObject.lovDropDownService.lovDataList.referralReasons) {
            // let hasRefReason = scopeObject.referralReasons.some( _data => _data.code === _refReason.code );
            let hasRefReason = scopeObject.riskObj.referralReasons.referralReason.some(_data => _data.code == _refReason.code);
            if (!hasRefReason) {
                scopeObject.referralReasons.push(_refReason);
            }
        }
    }

    getRiskType() {
        let riskType = this.riskObj.riskType;
        while (riskType != undefined && riskType.length < 3) {
            riskType = riskType + " ";
        }
        return riskType;
    }

    onChangeNRIC() {
        if (this.riskObj.IdProofNo != null && this.riskObj.IdProofNo != "") {
            let isValidNRICFormat = new RegExp("[0-9]{6}-[0-9]{2}-[0-9]{4}$").test(this.riskObj.IdProofNo);
            if (isValidNRICFormat == true) {
				/*
                let givenDate = this.riskObj.IdProofNo.substr(0, 6);
                let finalDate = givenDate;
                if (moment(givenDate, "YYMMDD").toDate() == "Invalid Date") {
                    finalDate = "";
                    this.riskObj.IdProofNo = "";
                    this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Invalid date in NRIC.", 5000));
                } else {
                    finalDate = moment(givenDate, "YYMMDD").format("YYYYMMDD");
                }

                if (this.DOBCtrl != null && finalDate != "")
                    this.DOBCtrl.setter(moment(finalDate, "YYYYMMDD").format("YYYY-MM-DD"), "YYYY-MM-DD", this.DOBCtrl.comp);
                else if (this.DOBCtrl != null && finalDate == "")
                    this.DOBCtrl.setter("EMPTY", "YYYY-MM-DD", this.DOBCtrl.comp);
				*/
                this.setDOB();

                if (this.riskObj.IdProofNo) {
                    let lastDigit = this.riskObj.IdProofNo.substring(this.riskObj.IdProofNo.length - 1);
                    if (/^-?\d*[02468]$/.test(lastDigit)) {
                        this.riskObj.gender = 'F';
                    } else if (/^-?\d*[13579]$/.test(lastDigit)) {
                        this.riskObj.gender = 'M';
                    }
                }
            }
        }
    }

    setDOB() {
        let givenDate = this.riskObj.IdProofNo.substring(0, 6);
        let finalDate = givenDate;
        if (moment(givenDate, "YYMMDD").toDate() == "Invalid Date") {
            finalDate = "";
            this.riskObj.IdProofNo = "";
            this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Invalid date in NRIC.", 5000));
        }
        else {
            let century = this.riskObj.IdProofNo.substring(0, 2);
            if (Number(century) > 29)
                givenDate = '19' + givenDate;
            else
                givenDate = '20' + givenDate;

            // finalDate = moment(givenDate, "YYYYMMDD").format("YYYYMMDD");
            finalDate = moment(givenDate, "YYYYMMDD").format("YYYY-MM-DD");
        }

        this.riskObj.dateOfBirth = finalDate;

        if (this.DOBCtrl != null && finalDate != "") {
            // this.DOBCtrl.setter(moment(finalDate, "YYYYMMDD").format("YYYY-MM-DD"), "YYYY-MM-DD", this.DOBCtrl.comp);
            this.DOBCtrl.setter(finalDate, "YYYY-MM-DD", this.DOBCtrl.comp);
        }
        else if (this.DOBCtrl != null && finalDate == "")
            this.DOBCtrl.setter("EMPTY", "YYYY-MM-DD", this.DOBCtrl.comp);

        if (this.riskObj.plan && this.riskObj.dateOfBirth) {
            this.setPremium();
        }

        this.checkReferredRiskConditions();
    }

    onPlanChange() {

        if (this.riskObj.additionalCoverDetails.additionalCover && this.riskObj.additionalCoverDetails.additionalCover.length > 0) {
            this.riskObj.additionalCoverDetails.additionalCover.length = 0;
        }

        // this.setInsuredAge();
        this.calculateInsuredAge();
        if (this.riskObj.insuredAge <= 0) {
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Insured Age cannot be less than zero. Please provide Date of Birth.", -1));
            this.riskObj.plan = "";
            this.riskObj.planBenefits.benefit = [];
            this.clearAllPremiumData();
            return false;
        }
        if ((this.riskObj.ratingClass == undefined || this.riskObj.ratingClass == "") || (this.riskObj.areaCode == undefined || this.riskObj.areaCode == "")) {
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Please select Occupation Class & Area Code before selecting plan.", -1));
            this.riskObj.plan = "";
            this.riskObj.planBenefits.benefit = [];
            this.clearAllPremiumData();
            return false;
        }
        this.riskObj.planBenefits.benefit = [];
        let request: GetLOVData = new GetLOVData();
        request.BRANCH = 'ALL';
        request.LOB = 'ALL';
        request.BUSINESS_FUNCTION = 'ALL';
        request.PRODUCT = 'ALL';
        request.OPERATION = 'ALL';
        request.FORM_NAME = 'S6272';
        request.FORM_FIELD_NAME = 'Coverage Information';
        request.FIELD_TYPE = 'LOV';
        request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        request.ADVANCE_CONFIG_XML.FILTERS = new Filter();
        let dateString = this.getDate();
        request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({ "@FIELD_NAME": 'DESCITEM', "@FIELD_VALUE": this.getRiskType() + "" + this.riskObj.plan, '@OPERATION': 'EQ', '@CONDITION': 'AND' },
            { "@FIELD_NAME": 'ITMFRM', "@FIELD_VALUE": dateString, '@OPERATION': 'LT', '@CONDITION': 'AND' },
            { "@FIELD_NAME": 'ITMTO', "@FIELD_VALUE": dateString, '@OPERATION': 'GT', '@CONDITION': 'AND' });
        this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.successHandler, this.handleError, true, { comp: this });
        //this.emitPlanChange(data.value);
    }
    clearAllPremiumData() {
        this.riskObj.sumInsured = 0;
        this.setSI(0);
        this.riskObj.lifeTime = 0;
        this.riskObj.areaMultiplier = 0;
        this.riskObj.occupationClassRate = 0;
        this.riskObj.premiumFromPlan = 0;
        this.riskObj.basicPremium = 0;
        this.setPremium();
    }
    getDate() {
        return moment(new Date().toISOString(), "YYYY-MM-DD").format("YYYYMMDD");
    }

    successHandler(response, prms) {
        let ary = [];
        let contitem = '';

        if (response.tuple != null && !Array.prototype.isPrototypeOf(response.tuple)) {
            ary = [response.tuple];
        }
        else if (response.tuple != null) {
            ary = response.tuple;
        }
        let capSI = 0;
        let _lifeLimit = 0;
        let planAge = 0;
        let seqNum = 1;
        for (let coverage of ary) {
            let coverageInfo: BenefitItem = {
                "seqNumber": seqNum,
                "coverageCode": coverage.old.T7402.ZGMCDE,
                "coverageDescription": coverage.old.T7402.ZGMDSC,
                "sumInsured": parseFloat(coverage.old.T7402.SUMIN),
                "otherSumInsured": parseFloat(coverage.old.T7402.ZPTDSI),
                "indicator": coverage.old.T7402.IND,
                "extraText": "",
                "etPostingStatus": "N"
            };
            capSI = parseFloat(coverage.old.T7402.TOTSI);
            _lifeLimit = parseFloat(coverage.old.T7402.TOTSIL);
            planAge = coverage.old.T7402.AGE;
            prms.comp.riskObj.planBenefits.benefit.push(coverageInfo);
            seqNum++;
        }
        prms.comp.setSI(capSI);
        prms.comp.riskObj.lifeTime = _lifeLimit;
        prms.comp.onAreaCodeChange();
        prms.comp.onOccupationClassChange();
        prms.comp.getPremiumForPlan();
    }

    setPremium() {

        this._bmsUtilService.s6272SetPremium(this.riskObj);
        this.onPremiumChange.emit(this.riskObj.totalAnnualPremium);
        /*if(this.riskObj.plan){
            let _areaMultiplier = 0;
            let _occupRate = 0;
            let _basicPremium = 0;
            let _premiumFromPlan = 0;
            let _deductiblePercent = 0;
            let _deductibleAmount = 0;
            let _renewalDiscountPercent = 0;
            let _renewalDiscountAmount = 0;
            let _loadingDiscountPercent = 0;
            let _loadingDiscountAmount = 0;
            let _familyDiscountPercent = 0;
            let _familyDiscountAmount = 0;
            let _maternityPremium=0;
            let _CRIIPremium=0;
            let _additionalBenefitPremium=0;
            let _totalAnnualPremium=0;
			let _postingPremium=0;
            
            _areaMultiplier = numeral().unformat(this.riskObj.areaMultiplier);
            _occupRate = numeral().unformat(this.riskObj.occupationClassRate);
            _premiumFromPlan = numeral().unformat(this.riskObj.premiumFromPlan);
            _deductiblePercent = numeral().unformat(this.riskObj.deductiblePercentage);
            _renewalDiscountPercent = numeral().unformat(this.riskObj.renewalDiscountPercentage);
            _loadingDiscountPercent = numeral().unformat(this.riskObj.loadingDiscountPercentage);
            _familyDiscountPercent = numeral().unformat(this.riskObj.familyDiscountPercentage);
            _maternityPremium = numeral().unformat(this.riskObj.maternityPremium);
            _CRIIPremium = numeral().unformat(this.riskObj.CRIIPremium);

            if(this.riskObj.ratingFlag=="A"){
                _basicPremium = (_premiumFromPlan * (_occupRate/100)) + (_premiumFromPlan * (_areaMultiplier - 100.00)/100);
                this.riskObj.basicPremium = numeral(Number(_basicPremium)).format('0.00');
            }else{
                _basicPremium = numeral().unformat(this.riskObj.basicPremium);
            }

            _deductibleAmount = (_basicPremium * (_deductiblePercent/100));
            this.riskObj.deductibleAmount = numeral(Number(_deductibleAmount)).format('0.00');
            _deductibleAmount = _deductibleAmount * (-1);
            
            _renewalDiscountAmount = ((_basicPremium + _deductibleAmount) * (_renewalDiscountPercent/100));
            this.riskObj.renewalDiscountAmount = numeral(Number(_renewalDiscountAmount)).format('0.00');
            _renewalDiscountAmount = _renewalDiscountAmount * (-1);

            _loadingDiscountAmount = ((_basicPremium + _deductibleAmount + _renewalDiscountAmount) * (_loadingDiscountPercent/100));
            this.riskObj.loadingDiscountAmount = numeral(Number(_loadingDiscountAmount)).format('0.00');

            _familyDiscountAmount = ((_basicPremium + _deductibleAmount + _renewalDiscountAmount + _loadingDiscountAmount) * (_familyDiscountPercent/100));
            this.riskObj.familyDiscountAmount =  numeral(Number(_familyDiscountAmount)).format('0.00');
            _familyDiscountAmount = _familyDiscountAmount * (-1);

            if(this.riskObj.riskType=="FSI"){
                _maternityPremium=0;
                _CRIIPremium=0;
                _additionalBenefitPremium = this.getTotalByProperty("totalPremium",this.riskObj.additionalCoverDetails.additionalCover);
                _additionalBenefitPremium = numeral().unformat(_additionalBenefitPremium);
            }
            _totalAnnualPremium = ( _basicPremium + _deductibleAmount  + _renewalDiscountAmount + _loadingDiscountAmount + _familyDiscountAmount + _maternityPremium + _CRIIPremium + _additionalBenefitPremium);
            this.riskObj.totalAnnualPremium = numeral(Number(_totalAnnualPremium)).format('0.00');
            this.onPremiumChange.emit(this.riskObj.totalAnnualPremium);
			
			// if(this.riskObj.ratingFlag=="A"){
                // _postingPremium = ((_totalAnnualPremium) / 365) * this.calcDays();
                // this.riskObj.postingPremium = numeral(Number(_postingPremium)).format('0.00');
            // }else{
                // //this._alertMsgService.add(new AlertMessage(AlertMessage.INFO,"Rating flag is Manual, Please fill in Basic Premium and Posted Premium.", 5000));                
                // this.riskObj.postingPremium = numeral(Number()).format('0.00');
            // }
			this.riskObj.postingPremium = this.riskObj.totalAnnualPremium;
        }*/
    }

    onFamilyDiscoutChange() {
        if (this.clientDetails.client.genericDetails.clienttype == 'P' && this.parentRiskObj.noOfPersons < 3) {
            this._alertMsgService.add(new AlertMessage(AlertMessage.WARN, "Family discount is only allowed when more than 2 Insured Persons", 5000));
        }

        this.setPremium();
    }

    getPremiumForPlan() {
        let premiumFromPlan = 0;
        let request: GetLOVData = new GetLOVData().getRequest('ALL', 'ALL', 'ALL', 'ALL', 'ALL', 'S6272', 'BasicPremium', 'LOV');
        request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        request.ADVANCE_CONFIG_XML.FILTERS = new Filter();
        request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push(
            { "@FIELD_NAME": "DESCITEM", "@FIELD_VALUE": this.riskObj.riskType + this.riskObj.plan, "@OPERATION": "EQ", "@CONDITION": "AND" },
            { "@FIELD_NAME": "cast(AGE as int) ", "@FIELD_VALUE": this.riskObj.insuredAge, "@OPERATION": "GTEQ", "@CONDITION": "AND" },
            { "@FIELD_NAME": "ITMFRM", "@FIELD_VALUE": moment(this.headerInfo.effectiveDate, "YYYY-MM-DD").format("YYYYMMDD"), "@OPERATION": "LT", "@CONDITION": "AND" },
            { "@FIELD_NAME": "ITMTO", "@FIELD_VALUE": moment(this.headerInfo.effectiveDate, "YYYY-MM-DD").format("YYYYMMDD"), "@OPERATION": "GT", "@CONDITION": "AND" }
        );
        this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, null, null, false, null).success((data) => {
            if (data.tuple) {
                if (Array.prototype.isPrototypeOf(data.tuple)) {
                    premiumFromPlan = data.tuple[0].old.T7405.ZCOMM;
                }
                else if (data.tuple.old && data.tuple.old.T7405) {
                    premiumFromPlan = data.tuple.old.T7405.ZCOMM;
                }
            }
        }).error((response, status, errorText) => {
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error while getting basic premium for Plan - " + this.riskObj.plan, 5000));
        });
        this.riskObj.premiumFromPlan = numeral(Number(premiumFromPlan) / 100).format('0.00');
        this.setPremium();
    }

    onAreaCodeChange() {
        if (this.riskObj.plan) {
            this.getAreaCodeMultiplierRate(this.riskObj.plan + this.riskObj.areaCode, this.headerInfo.effectiveDate);
            this.setPremium();
        }
    }

    onOccupationClassChange() {
        if (this.riskObj.plan) {
            this.getOccClassRate(this.riskObj.plan + this.riskObj.ratingClass, this.headerInfo.effectiveDate);
            this.setPremium();
        }
    }

    getAreaCodeMultiplierRate(areaCodeDescItemsStr, effectiveDate) {
        let load = 0;
        if (areaCodeDescItemsStr) {
            let request: GetLOVData = new GetLOVData().getRequest('ALL', 'ALL', 'ALL', 'ALL', 'ALL', 'ALL', 'AreaCodeRate', 'LOV');
            request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
            request.ADVANCE_CONFIG_XML.FILTERS = new Filter();
            request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push(
                { "@FIELD_NAME": "DESCITEM", "@FIELD_VALUE": areaCodeDescItemsStr, "@OPERATION": "EQ", "@CONDITION": "AND" },
                { "@FIELD_NAME": "ITMFRM", "@FIELD_VALUE": moment(effectiveDate, "YYYY-MM-DD").format("YYYYMMDD"), "@OPERATION": "LT", "@CONDITION": "AND" },
                { "@FIELD_NAME": "ITMTO", "@FIELD_VALUE": moment(effectiveDate, "YYYY-MM-DD").format("YYYYMMDD"), "@OPERATION": "GT", "@CONDITION": "AND" });
            this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, null, null, false, null).success((data) => {
                if (data.tuple) {
                    if (Array.prototype.isPrototypeOf(data.tuple)) {
                        load = data.tuple[0].old.T7090.ZCRYLOAD;
                    }
                    else if (data.tuple.old && data.tuple.old.T7090) {
                        load = data.tuple.old.T7090.ZCRYLOAD;
                    }
                }
            }).error((response, status, errorText) => {
                this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error while getting multiplier rate for Area Codes - " + areaCodeDescItemsStr, 5000));
            });
        }
        this.riskObj.areaMultiplier = load;
    }

    getOccClassRate(occClassCodeDescItemStr, effectiveDate) {
        let occupationClassRate = 0;
        if (occClassCodeDescItemStr) {
            let request: GetLOVData = new GetLOVData().getRequest('ALL', 'MED', 'ALL', 'ALL', 'ALL', 'ALL', 'Occupation Class Rate', 'LOV');
            request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
            request.ADVANCE_CONFIG_XML.FILTERS = new Filter();
            request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push(
                { "@FIELD_NAME": "DESCITEM", "@FIELD_VALUE": occClassCodeDescItemStr, "@OPERATION": "EQ", "@CONDITION": "AND" },
                { "@FIELD_NAME": "ITMFRM", "@FIELD_VALUE": moment(effectiveDate, "YYYY-MM-DD").format("YYYYMMDD"), "@OPERATION": "LT", "@CONDITION": "AND" },
                { "@FIELD_NAME": "ITMTO", "@FIELD_VALUE": moment(effectiveDate, "YYYY-MM-DD").format("YYYYMMDD"), "@OPERATION": "GT", "@CONDITION": "AND" });
            this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, null, null, false, null).success((data) => {
                if (data.tuple) {
                    if (Array.prototype.isPrototypeOf(data.tuple)) {
                        occupationClassRate = data.tuple[0].old.T7091.ZCRYLOAD;
                    }
                    else if (data.tuple.old && data.tuple.old.T7091) {
                        occupationClassRate = data.tuple.old.T7091.ZCRYLOAD;
                    }
                }
            }).error((response, status, errorText) => {
                this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error while getting rate for Occupation Class Codes - " + occClassCodeDescItemStr, 5000));
            });
        }
        this.riskObj.occupationClassRate = occupationClassRate;
    }

    populateCRIIDetails(evt) {
        if (evt.record) {
            if (evt.value) {
                this.riskObj.CRIISI = evt.record.SUMIN;
                if (this.riskObj.ratingFlag == 'A') {
                    this.getCRIIPremium();
                }

                this.riskObj.CRIIDate = '';
                this.CRIIDateCtrl.setter("EMPTY", "YYYY-MM-DD", this.CRIIDateCtrl.comp);
                // this.riskObj.CRIIDate = this.headerInfo.effectiveDate;
                // this.CRIIDateCtrl.setter(this.riskObj.CRIIDate, "YYYY-MM-DD", this.CRIIDateCtrl.comp);
            }
            else {
                this.riskObj.CRIIDate = '';
                this.CRIIDateCtrl.setter("EMPTY", "YYYY-MM-DD", this.CRIIDateCtrl.comp);
                this.riskObj.CRIISI = 0;
                this.riskObj.CRIIPremium = 0;
            }

            this.setPremium();
        }
    }
    getCRIIPremium() {
        let _CRIIPremium = 0;
        let request: GetLOVData = new GetLOVData().getRequest('ALL', 'ALL', 'ALL', 'ALL', 'ALL', 'S6272', 'BasicPremium', 'LOV');
        request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        request.ADVANCE_CONFIG_XML.FILTERS = new Filter();

        request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push(
            { "@FIELD_NAME": "DESCITEM", "@FIELD_VALUE": this.riskObj.riskType + this.riskObj.CRIIPlanCode, "@OPERATION": "EQ", "@CONDITION": "AND" },
            { "@FIELD_NAME": "cast(AGE as int) ", "@FIELD_VALUE": this.riskObj.insuredAge, "@OPERATION": "GTEQ", "@CONDITION": "AND" },
            { "@FIELD_NAME": "ITMFRM", "@FIELD_VALUE": moment(this.headerInfo.effectiveDate, "YYYY-MM-DD").format("YYYYMMDD"), "@OPERATION": "LT", "@CONDITION": "AND" },
            { "@FIELD_NAME": "ITMTO", "@FIELD_VALUE": moment(this.headerInfo.effectiveDate, "YYYY-MM-DD").format("YYYYMMDD"), "@OPERATION": "GT", "@CONDITION": "AND" }
        );
        this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, null, null, false, null).success((data) => {
            if (data.tuple) {
                if (Array.prototype.isPrototypeOf(data.tuple)) {
                    _CRIIPremium = data.tuple[0].old.T7405.ZCOMM;
                }
                else if (data.tuple.old && data.tuple.old.T7405) {
                    _CRIIPremium = data.tuple.old.T7405.ZCOMM;
                }
            }
        }).error((response, status, errorText) => {
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error while getting basic premium for Plan - " + this.riskObj.plan, 5000));
        });

        this.riskObj.CRIIPremium = numeral(Number(_CRIIPremium) / 100).format('0.00');
        this.setPremium();
    }

    onMaternityPlanChange(ev) {
        this.riskObj.MATRPlanCode = (ev.value) ? ev.value : '';
        this.populateMATRPremiums(ev);
    }

    populateMATRPremiums(evt) {
        if (evt.record) {
            if (evt.value) {
                this.riskObj.MATRNorm = Number(evt.record.ZMPAID_01);
                this.riskObj.MATRComp = Number(evt.record.ZMPAID_02);
                if (this.riskObj.ratingFlag == 'A') {
                    this.getMaternityPremium();
                }
            }
            else {
                this.riskObj.MATRNorm = 0;
                this.riskObj.MATRComp = 0;
                this.riskObj.maternityPremium = 0;
                this.MaternityDateCtrl.setter("EMPTY", "YYYY-MM-DD", this.MaternityDateCtrl.comp);
            }
            this.setPremium();
        }
    }
    getMaternityPremium() {
        let _maternityPremium = 0;
        let request: GetLOVData = new GetLOVData().getRequest('ALL', 'ALL', 'ALL', 'ALL', 'ALL', 'S6272', 'BasicPremium', 'LOV');
        request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        request.ADVANCE_CONFIG_XML.FILTERS = new Filter();

        request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push(
            { "@FIELD_NAME": "DESCITEM", "@FIELD_VALUE": this.riskObj.riskType + this.riskObj.MATRPlanCode, "@OPERATION": "EQ", "@CONDITION": "AND" },
            { "@FIELD_NAME": "cast(AGE as int) ", "@FIELD_VALUE": this.riskObj.insuredAge, "@OPERATION": "GTEQ", "@CONDITION": "AND" },
            { "@FIELD_NAME": "ITMFRM", "@FIELD_VALUE": moment(this.headerInfo.effectiveDate, "YYYY-MM-DD").format("YYYYMMDD"), "@OPERATION": "LT", "@CONDITION": "AND" },
            { "@FIELD_NAME": "ITMTO", "@FIELD_VALUE": moment(this.headerInfo.effectiveDate, "YYYY-MM-DD").format("YYYYMMDD"), "@OPERATION": "GT", "@CONDITION": "AND" }
        );
        this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, null, null, false, null).success((data) => {
            if (data.tuple) {
                if (Array.prototype.isPrototypeOf(data.tuple)) {
                    _maternityPremium = data.tuple[0].old.T7405.ZCOMM;
                }
                else if (data.tuple.old && data.tuple.old.T7405) {
                    _maternityPremium = data.tuple.old.T7405.ZCOMM;
                }
            }
        }).error((response, status, errorText) => {
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error while getting basic premium for Plan - " + this.riskObj.plan, 5000));
        });

        this.riskObj.maternityPremium = numeral(Number(_maternityPremium) / 100).format('0.00');
        this.setPremium();
    }
    populateDeductiblePercAmount(evt) {
        if (evt.record) {
            if (evt.value) {
                this.riskObj.deductiblePercentage = numeral(Number(evt.record.EXPERC) / 100).format('0.00');
            }
            else {
                this.riskObj.deductiblePercentage = 0;
            }
            //set deductible in Additional benefits if added
            if (this.riskObj.additionalCoverDetails.additionalCover && this.riskObj.additionalCoverDetails.additionalCover.length > 0) {
                for (let _addCover of this.riskObj.additionalCoverDetails.additionalCover) {
                    if (_addCover.category == 'OS') {
                        _addCover.discount = this.riskObj.deductiblePercentage;
                        this.calcualteTotalABPremiumForCover(_addCover);
                        this._alertMsgService.add(new AlertMessage(AlertMessage.WARN, "Total Premium has been changed due to the selection of Deductible Plan", 6000));
                        break;
                    }
                }
            }

            if (this.riskObj.plan)
                this.setPremium();
        }
    }

    onRenewalDiscountPercentageChange(evt) {
        this.riskObj.renewalDiscountAmount = ((this.riskObj.basicPremium - this.riskObj.deductibleAmount) * (this.riskObj.renewalDiscountPercentage / 100));
        this.setPremium();
    }
    onRenewalBonusPercentageChange(evt) {
        if (parseFloat("" + evt.target.value) > 0) {
            if (this.renewalBonusAmountCtrl != null)
                this.renewalBonusAmountCtrl.setDisable("Y", this.renewalBonusAmountCtrl.comp);
        } else {
            if (this.renewalBonusAmountCtrl != null)
                this.renewalBonusAmountCtrl.setDisable("N", this.renewalBonusAmountCtrl.comp);
        }
    }

    onRenewalBonusAmountChange(evt) {
        if (parseFloat("" + evt.target.value) > 0) {
            if (this.renewalBonusPercentageCtrl != null)
                this.renewalBonusPercentageCtrl.setDisable("Y", this.renewalBonusPercentageCtrl.comp);
        } else {
            if (this.renewalBonusPercentageCtrl != null)
                this.renewalBonusPercentageCtrl.setDisable("N", this.renewalBonusPercentageCtrl.comp);
        }
    }

    addNewAdditionalBenefits() {
        if (this.riskObj.ratingClass && this.riskObj.plan && this.riskObj.insuredAge > 0) {
            let lookup = new ModalInput();
            //lookup.component = ["NomineeDetailsDialogComponent", "app/bms/components/proposal/newbusinessrisks/dialogs/nomineeDetailDialog.module", "NomineeDetailsDialogModule"];
            lookup.component = ["S6272AdditionalBenefits", "app/bms/components/proposal/newbusinessrisks/s6271/dialogs/s6272additionalbenefits.module", "S6272AdditionalBenefitsModule"];
            lookup.outputCallback = this.addNewAB;
            lookup.datainput = { isNew: true, benefitData: this.riskObj.additionalCoverDetails, beneIndex: -1 };
            lookup.parentCompPRMS = { comp: this };
            lookup.heading = "Additional Benefit - New";
            lookup.icon = "fa fa-user";
            lookup.containerRef = this.contentArea;
            this.dcl.openLookup(lookup);
        } else {
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Please provide Occupation Class, Date of Birth and Plan before selecting additional benefit.", -1));
        }
    }
    addNewAB(aBenefit, prms) {
        prms.comp.setPremium();
    }
    viewABDetails(idx) {
        let lookup = new ModalInput();
        //lookup.component = ["NomineeDetailsDialogComponent", "app/bms/components/proposal/newbusinessrisks/dialogs/nomineeDetailDialog.module", "NomineeDetailsDialogModule"];
        lookup.component = ["S6272AdditionalBenefits", "app/bms/components/proposal/newbusinessrisks/s6271/dialogs/s6272additionalbenefits.module", "S6272AdditionalBenefitsModule"];
        lookup.outputCallback = this.addNewAB;
        lookup.datainput = { isNew: false, benefitData: this.riskObj.additionalCoverDetails.additionalCover[idx], beneIndex: idx };
        lookup.parentCompPRMS = { comp: this };
        lookup.heading = "Additional Benefits - Edit";
        lookup.icon = "fa fa-user";
        lookup.containerRef = this.contentArea;
        this.dcl.openLookup(lookup);

    }
    removeAdditionalBenefit(additionalBenefit) {
        this.riskObj.additionalCoverDetails.additionalCover.splice(this.riskObj.additionalCoverDetails.additionalCover.indexOf(additionalBenefit), 1);
        this.setPremium();
    }
    // onAdditionalBenefitPlanChange(cover){
    //     let additionalPremiumFromPlan = 0;
    //     let additionalBenefitDescription="";
    //     let request:GetLOVData = new GetLOVData().getRequest('ALL','ALL','ALL','ALL','ALL','S6816','AdditionalPremium','LOV');
    //     request.ADVANCE_CONFIG_XML= new SearchAdvancedConfig(); 
    //     request.ADVANCE_CONFIG_XML.FILTERS = new Filter();
    //     let riskFilter = (this.riskObj.riskType.length==2) ? this.riskObj.riskType+' ' : this.riskObj.riskType;

    //     request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push(
    //         {"@FIELD_NAME":"DESCITEM", "@FIELD_VALUE":riskFilter + cover.category + cover.plan, "@OPERATION":"EQ", "@CONDITION":"AND"},
    //         {"@FIELD_NAME":"cast(AGE as int) ", "@FIELD_VALUE":this.riskObj.insuredAge , "@OPERATION":"GTEQ", "@CONDITION":"AND"},
    //         {"@FIELD_NAME":"ITMFRM", "@FIELD_VALUE": moment(this.headerInfo.effectiveDate, "YYYY-MM-DD").format("YYYYMMDD"), "@OPERATION":"LT", "@CONDITION":"AND"},
    //         {"@FIELD_NAME":"ITMTO", "@FIELD_VALUE": moment(this.headerInfo.effectiveDate, "YYYY-MM-DD").format("YYYYMMDD"), "@OPERATION":"GT", "@CONDITION":"AND"}
    //         );
    //     this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request , null, null, false, null).success((data)=> {
    //         if(data.tuple){
    //             additionalPremiumFromPlan = numeral(Number(data.tuple.old.T9023.BASPRM)/100).format('0.00');
    //             additionalBenefitDescription = data.tuple.old.T9023.ADBDES;
    //         }
    //     }).error((response, status, errorText)=> {
    //         this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR,"Error while getting basic premium for Plan - "+this.riskObj.plan, 5000));
    //     });
    //     cover.premium = additionalPremiumFromPlan;
    //     cover.benefitsText = additionalBenefitDescription;
    //     this.calcualteTotalABPremiumForCover(cover);
    // }
    calcualteTotalABPremiumForCover(cover) {
        let _premium = 0;
        let _loadingPercent = 0;
        let _loadingAmount = 0;
        let _discountPercent = 0;
        let _discountAmount = 0;
        _premium = numeral().unformat(cover.premium);
        _loadingPercent = numeral().unformat(cover.loading);
        _discountPercent = numeral().unformat(cover.discount);
        _loadingAmount = ((_premium) * (_loadingPercent / 100));
        _discountAmount = ((_premium + _loadingAmount) * (_discountPercent / 100));
        cover.totalPremium = (_premium + _loadingAmount) - _discountAmount;
        cover.totalPremium = numeral(Number(cover.totalPremium)).format('0.00')
        // this.setPremium();
        // this.calculateAdditionalBenefitTotalPremium();
    }
    // calculateAdditionalBenefitTotalPremium(){
    //     let _ABTotalPremium=0;
    //     _ABTotalPremium = this.getTotalByProperty("totalPremium",this.riskObj.additionalCoverDetails.additionalCover);
    // }

	/*setClientInfo() {
        // this.setInsuredAge();        
		this.calculateInsuredAge();
        if(this.riskObj.occupationCode != undefined && this.riskObj.occupationCode != ""){
            this.setOccDesForClient(this.riskObj.occupationCode);
        }
    }
	
    setOccDesc(occupation) {
        if (occupation != undefined || occupation != "") {
            let request: GetLOVData = new GetLOVData().getRequest('ALL', 'ALL', 'NEW BUSINESS', 'ALL', 'NEW', 'ALL', 'Occupation', 'LOV');
            request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
            request.ADVANCE_CONFIG_XML.FILTERS = new Filter();
            request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({ "@FIELD_NAME": 'DESCITEM', "@FIELD_VALUE": this.riskObj.occupationCode, '@OPERATION': 'EQ', '@CONDITION': 'AND' });
            this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.occupationSuccessHandler, this.handleError, true, { comp: this });
        }
        //this.riskObj.occupationDescription = occupation.description;
    }

    setOccDesForClient(occupation) {
        if (occupation != undefined || occupation != "") {
            if (this.riskObj.occupationDescription == undefined || this.riskObj.occupationDescription == "") {
                let request: GetLOVData = new GetLOVData().getRequest('ALL', 'ALL', 'NEW BUSINESS', 'ALL', 'NEW', 'ALL', 'Occupation', 'LOV');
                request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
                request.ADVANCE_CONFIG_XML.FILTERS = new Filter();
                request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({ "@FIELD_NAME": 'DESCITEM', "@FIELD_VALUE": this.riskObj.occupationCode, '@OPERATION': 'EQ', '@CONDITION': 'AND' });
                this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.occupationSuccessHandler, this.handleError, true, { comp: this });
            }
        }
        //this.riskObj.occupationDescription = occupation.description;
    }
    validateRebatePctg() {
        if (Number(this.riskObj.rebatePercentage) > 25) {
            this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Max. Allowed Value for Rebate is 25% only", 5000));
            this.riskObj.rebatePercentage = 0;
        }
    }

    occupationSuccessHandler(response, prms) {
        prms.comp.riskObj.occupationDescription = response.tuple.old.T3644.DESCRIPTION;
        prms.comp.riskObj.occRiskClassification = "";
        if (response.tuple.old.T3644.REFERREDRISK == '' || response.tuple.old.T3644.REFERREDRISK == 'N') {
            prms.comp.riskObj.occRiskClassification = "Standard";
        }
        else if (response.tuple.old.T3644.REFERREDRISK == 'Y') {
            prms.comp.riskObj.occRiskClassification = "Referred";
        }
        else if (response.tuple.old.T3644.REFERREDRISK == 'D') {
            prms.comp.riskObj.occRiskClassification = "Declined";
        }
        prms.comp.riskObj.symRiskClassification=prms.comp.riskObj.occRiskClassification;
        prms.comp.checkReferredRisk(prms.comp);
    }
	
    checkReferredRisk(comp) {
        //validate date of birth and age range to identify referred risk. if not check on occupation
        if (comp.riskObj.dateOfBirth && comp.isItInAgeRange() == false) {
            comp.riskObj.symRiskClassification = "Referred";
            comp.riskObj.riskClassification = comp.riskObj.symRiskClassification;
        } else {
            if(comp.riskObj.occRiskClassification != null && comp.riskObj.occRiskClassification == "Referred"){
                comp.riskObj.symRiskClassification = "Referred";
                comp.riskObj.riskClassification = comp.riskObj.symRiskClassification;
            }else {//if(comp.riskObj.occRiskClassification != null && comp.riskObj.occRiskClassification != ""){
                if (comp.riskObj.dateOfBirth && comp.isItInAgeRange() == false) {
                    comp.riskObj.symRiskClassification = "Referred";
                    comp.riskObj.riskClassification = comp.riskObj.symRiskClassification;
                } else {
                    comp.riskObj.symRiskClassification = comp.riskObj.occRiskClassification;
                    comp.riskObj.riskClassification = comp.riskObj.symRiskClassification;
                }
            }
        }
        comp.setRiskClassification(comp);
    }
	checkAgeValidation(value) {
        this.riskObj.planAgeLimit = Number(value);
        // this.setInsuredAge();
		this.calculateInsuredAge();
        this.checkReferredRisk(this);
    }*/

    setRiskClassification(comp) {
        if (comp.riskObj.symRiskClassification != null && comp.riskObj.symRiskClassification != "" && (comp.riskObj.symRiskClassification == "Referred" || comp.riskObj.symRiskClassification == "Declined")) {
            let statusTxt = (comp.riskObj.symRiskClassification != null && comp.riskObj.symRiskClassification != "") ? comp.riskObj.symRiskClassification : comp.riskObj.riskClassification;
            comp.riskObj.riskClassificationReason = "System marked as " + statusTxt;
        }
        else {
            if (comp.riskObj.riskClassificationReason != null && comp.riskObj.riskClassificationReason != "" && (comp.riskObj.riskClassificationReason != "System marked as Standard"
                && comp.riskObj.riskClassificationReason.indexOf("System marked as ") != -1)) {
                comp.riskObj.riskClassificationReason = "";
            }
        }
        comp.onRiskClsChange.emit('');
    }

    changeRiskClassification(event) {
        this.riskObj.riskClassification = event.target.value;
        this.onRiskClsChange.emit('');
    }
    validateCRIIDate(value) {
        //Maternity date should be within POI
        if (value != null && value != "") {
            let _polStartDate = moment(this.headerInfo.effectiveDate, "YYYY-MM-DD").format("YYYYMMDD");
            let _polEndDate = moment(this.headerInfo.endDate, "YYYY-MM-DD").format("YYYYMMDD");
            let _currMATDate = moment(value, "YYYY-MM-DD").format("YYYYMMDD");
            if (_currMATDate < _polStartDate || _currMATDate > _polEndDate) {
                //throw error
                this.CRIIDateCtrl.setter("EMPTY", "YYYY-MM-DD", this.CRIIDateCtrl.comp);
                this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Critical Illness Date must be within POI.", 5000));
            }
        }

    }
    validateMaternityDate(value) {
        //Maternity date should be within POI
        if (value != null && value != "") {
            let _polStartDate = moment(this.headerInfo.effectiveDate, "YYYY-MM-DD").format("YYYYMMDD");
            let _polEndDate = moment(this.headerInfo.endDate, "YYYY-MM-DD").format("YYYYMMDD");
            let _currMATDate = moment(value, "YYYY-MM-DD").format("YYYYMMDD");
            if (_currMATDate < _polStartDate || _currMATDate > _polEndDate) {
                //throw error
                this.MaternityDateCtrl.setter("EMPTY", "YYYY-MM-DD", this.MaternityDateCtrl.comp);
                this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Maternity Date must be within POI.", 5000));
            }
        }
    }

    validateDOB(value) {
        if (value != null && value != "") {
            let curDate = moment().format("YYYYMMDD");
            if (Number(curDate) < Number(moment(value, "YYYY-MM-DD").format("YYYYMMDD"))) {
                this.DOBCtrl.setter("EMPTY", "YYYY-MM-DD", this.DOBCtrl.comp);
                this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "DOB can not be future date.", 5000));
            }
        }
        // this.checkReferredRisk(this);
    }

    setInsuredAge() {
        if (this.riskObj.dateOfBirth != null && this.riskObj.dateOfBirth != "") {
            let curDate = moment(new Date().toISOString(), "YYYY-MM-DD");
            let date = moment(this.riskObj.dateOfBirth, "YYYY-MM-DD").format("YYYY-MM-DD");
            this.riskObj.insuredAge = curDate.diff(date, 'year') + 1;
        }
        else {
            this.riskObj.insuredAge = 0;
            this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Date of Birth cannot be empty or age cannot be zero.", 5000));
        }
    }
    isItInAgeRange() {
        //Other products Age above 70 to be treated as Referred
        if (Number(this.riskObj.insuredAge) > 70) {
            return false;
        }
        else {
            return true;
        }
    }
    calcDays() {
        let date1 = moment(this.riskObj.dateStart, "YYYY-MM-DD");
        let date2 = moment(this.riskObj.lastDateEnd, "YYYY-MM-DD");
        return date2.diff(date1, 'days') + 1;
    }
    getTotalByProperty(prop, ary) {
        let total = numeral(0);
        for (let eachItem of ary) {
            if (eachItem[prop] != null && eachItem[prop] != "")
                total = total.add(numeral().unformat(eachItem[prop]));
        }
        total = numeral(total).format('0.00');
        return total;
    }
    setSI(siValue) {
        let si = parseInt(siValue);
        this.riskObj.sumInsured = si;
        this.onSIChange.emit(si);
    }

    addXT(coverItem) {
        var dialogData = new ExtraTextDialogData("ExtraTextDialogComponent", "app/bms/components/proposal/newbusinessrisks/dialogs/extratext.dialog.module", "ExtraTextDialogModule", "Extra Text", "ExtraText", "fa fa-comment", coverItem, this.extraTextCallBack);
        this.openExtraTextCommentsDialog(dialogData);
    }

    public openExtraTextCommentsDialog(dialogData: ExtraTextDialogData, response?: any) {
        let lookup = new ModalInput();
        lookup.component = [dialogData.component, dialogData.moduleAbsPath, dialogData.moduleName];
        lookup.datainput = {
            dialogName: dialogData.dialogName,
            areCommentsMandatory: false,
            coverageItem: dialogData.coverageItem
        };
        lookup.outputCallback = dialogData.callBackHandler;
        lookup.parentCompPRMS = {
            comp: this,
            response: response
        };
        lookup.heading = dialogData.dialogTitle;
        lookup.icon = dialogData.icon;
        lookup.containerRef = this.contentArea;
        this.dcl.openLookup(lookup);
    }

    private extraTextCallBack(data, prms) {
        if (data.isDialogCancelled) {
            return;
        } else if (!data.isDialogCancelled && data.coverageItem && data.coverageItem.extraText) {
        }
    }
    emitFlagChange() {
        if (this.riskObj.ratingFlag == "A") {
            this.onPlanChange();
        }
        this.onRtngFlgChange.emit("");
    }

    handleError(response, status, errorText, prms) {
        prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, response.responseJSON.faultstring.text, 5000));
    }


    addReferralReason(refCode, isSysRef) {

        if (!refCode) {
            refCode = jQuery("#referralReason").val();
        }

        if (!isSysRef && this.lovDropDownService.lovDataList.referralReasons && this.lovDropDownService.lovDataList.referralReasons.length > 0 && this.riskObj.referralReasons.referralReason.find((_data1) => _data1.code == refCode)) {
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Referral Reason is added already.", 3000));
        }
        else {
            let refReasonRecord = this.lovDropDownService.lovDataList.referralReasons.find(_data => (_data.code === refCode));

            if (!refReasonRecord) {
                let _refReasons = [];
                let request: GetLOVData = new GetLOVData().getRequest('ALL', 'MED', 'ALL', 'ALL', 'ALL', 'ALL', 'Referral Reasons', 'LOV');
                request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
                request.ADVANCE_CONFIG_XML.FILTERS = new Filter();

                this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, null, null, false, null).success((data) => {
                    if (data.tuple) {
                        if (Array.prototype.isPrototypeOf(data.tuple)) {
                            for (let _rec of data.tuple) {
                                _refReasons.push(_rec.old.DESCPF);
                            }
                        }
                        else if (data.tuple && data.tuple.old && data.tuple.old.DESCPF) {
                            _refReasons.push(data.tuple.old.DESCPF);
                        }
                    }
                }).error((response, status, errorText) => {
                    this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error while getting Referral Reasons ", 5000));
                });

                if (_refReasons && _refReasons.length > 0) {
                    refReasonRecord = _refReasons.find(_data => (_data.code === refCode));
                }
            }

            if (refReasonRecord) {
                if (this.riskObj.referralReasons.referralReason && (this.riskObj.referralReasons.referralReason.length == 0 || !this.riskObj.referralReasons.referralReason.find((_data1) => _data1.code == refCode))) {
                    let _referralReason = new ReferralReason();
                    _referralReason.seqNumber = this.riskObj.referralReasons.referralReason.length + 1;
                    _referralReason.code = refReasonRecord.code;
                    _referralReason.description = refReasonRecord.description;
                    _referralReason.isSysReferred = (isSysRef) ? 'Y' : 'N';

                    this.riskObj.referralReasons.referralReason.push(_referralReason);
                }
                else if (this.riskObj.referralReasons.referralReason && this.riskObj.referralReasons.referralReason.find((_data1) => _data1.code == refCode)) {
                    let _refReason = this.riskObj.referralReasons.referralReason.find((_data1) => _data1.code == refCode);
                    _refReason.isSysReferred = (isSysRef) ? 'Y' : 'N';
                }
            }
        }

        if (!isSysRef && this.riskObj.referralReasons.referralReason.length == 1) {
            this.checkReferredRiskConditions();
        }

        jQuery("#referralReason").val('');
    }

    deleteReferralReason(refCode, sysRef) {
        let refReasonRecord = this.riskObj.referralReasons.referralReason.find((_data1) => _data1.code == refCode);
        if (refReasonRecord && (!sysRef || (sysRef && refReasonRecord.isSysReferred == 'Y'))) {
            this.riskObj.referralReasons.referralReason.splice(this.riskObj.referralReasons.referralReason.indexOf(refReasonRecord), 1);
        }
    }

    removeReferralReason(refItem) {
        let _idx = this.riskObj.referralReasons.referralReason.indexOf(refItem);
        let _refCode = refItem.code;
        this.riskObj.referralReasons.referralReason.splice(_idx, 1);
        this.resetItemNumber();

        let _refReasonRecord = this.lovDropDownService.lovDataList.referralReasons.find(_data => (_data.code === _refCode));
        if (_refReasonRecord)
            this.referralReasons.push(_refReasonRecord);

        if (this.riskObj.referralReasons.referralReason.length == 0) {
            this.checkReferredRiskConditions();
        }
    }

    resetItemNumber() {
        for (let _refItem of this.riskObj.referralReasons.referralReason) {
            let index = this.riskObj.referralReasons.referralReason.indexOf(_refItem);
            _refItem.seqNumber = (index + 1);
        }
    }

    checkReferredRiskConditions() {

        let _ageLimitRec = this.lovDropDownService.lovDataList.referralAgeLimits.find((_data) => _data.DESCITEM == this.riskObj.riskType);

        let _reasons = new Reasons();
        let isReferredRisk = false;
        let isDeclinedRisk = false;

        if (this.riskObj.hasClaimExperience == 'Y') {
            isReferredRisk = true;
            _reasons.reason.push("With Claim Experience.");
            this.addReferralReason('11', true);
        }
        else {
            this.deleteReferralReason('11', true);
        }

        this.calculateInsuredAge();

        // let reflAgeLimits = this.lovDropDownService.lovDataList.referralAgeLimits.find((_data)=> _data.DESCITEM == this.riskObj.riskType);
        this.riskObj.ageLimitFlag = "";
        if (_ageLimitRec && this.riskObj.dateOfBirth && this.riskObj.occupationCode) {
            let _minAgeLimit = 0;
            let _maxAgeLimit = 0;
            let _minAgeLimitInd = 'Y';
            let _maxAgeLimitInd = 'Y';

            let _adultMinAgeLimit = (_ageLimitRec.ZAGELMT03) ? parseInt("" + _ageLimitRec.ZAGELMT03) : 0;
            let _adultMaxAgeLimit = (_ageLimitRec.ZAGELMT05) ? parseInt("" + _ageLimitRec.ZAGELMT05) : 0;

            let _chidldMinAgeLimit = (_ageLimitRec.ZAGELMT04) ? parseInt("" + _ageLimitRec.ZAGELMT04) : 0;
            let _chidldMaxAgeLimit = (_ageLimitRec.ZAGELMT06) ? parseInt("" + _ageLimitRec.ZAGELMT06) : 0;


            if (_chidldMinAgeLimit > 0 && _chidldMaxAgeLimit > 0 && (this.riskObj.occupationCode == '7STU' || this.riskObj.occupationCode == '7CLD')) {
                _minAgeLimit = _chidldMinAgeLimit;
                _maxAgeLimit = _chidldMaxAgeLimit;
                _minAgeLimitInd = (_ageLimitRec.ZAGEIND02) ? _ageLimitRec.ZAGEIND02 : "Y";
                _maxAgeLimitInd = (_ageLimitRec.ZAGEIND03) ? _ageLimitRec.ZAGEIND03 : "Y";
            }
            else {

                _minAgeLimit = _adultMinAgeLimit;
                _maxAgeLimit = _adultMaxAgeLimit;
                if (_chidldMinAgeLimit == 0 || _chidldMaxAgeLimit == 0) {
                    _minAgeLimitInd = (_ageLimitRec.ZAGEIND02) ? _ageLimitRec.ZAGEIND02 : "Y";
                    _maxAgeLimitInd = (_ageLimitRec.ZAGEIND03) ? _ageLimitRec.ZAGEIND03 : "Y";
                }
            }

            if (_maxAgeLimitInd == 'D') {
                if (this.riskObj.inclusionDate && this.riskObj.dateOfBirth) {
                    let _inclusionDate = moment(this.riskObj.inclusionDate, "YYYY-MM-DD");
                    let _insuredDOB = moment(this.riskObj.dateOfBirth, "YYYY-MM-DD");

                    let _ageInDays = moment.duration(_inclusionDate.diff(_insuredDOB)).asDays();
                    if (_ageInDays > _maxAgeLimit) {
                        this.riskObj.ageLimitFlag = "G";
                    }
                }
            }
            else if (Number(this.riskObj.insuredAge) > _maxAgeLimit) {
                this.riskObj.ageLimitFlag = "G";
            }

            if (this.riskObj.ageLimitFlag != "G") {
                if (_minAgeLimitInd == 'D') {
                    if (this.riskObj.inclusionDate && this.riskObj.dateOfBirth) {
                        let _inclusionDate = moment(this.riskObj.inclusionDate, "YYYY-MM-DD");
                        let _insuredDOB = moment(this.riskObj.dateOfBirth, "YYYY-MM-DD");

                        let _ageInDays = moment.duration(_inclusionDate.diff(_insuredDOB)).asDays();
                        if (_ageInDays < _minAgeLimit) {
                            this.riskObj.ageLimitFlag = "L";
                        }
                    }
                }
                else if (Number(this.riskObj.insuredAge) < _minAgeLimit) {
                    this.riskObj.ageLimitFlag = "L";
                }
            }

            if (this.riskObj.ageLimitFlag == "G") {
                isReferredRisk = true;
                _reasons.reason.push("Insured (" + this.riskObj.itemNo + ") Age greater than maximum allowed age " + _maxAgeLimit);
                this.addReferralReason('01', true);
            }
            else if (this.riskObj.ageLimitFlag == "") {
                this.riskObj.ageLimitFlag = "VALID";
            }
        }

        if (this.riskObj.ageLimitFlag != 'G') {
            this.deleteReferralReason('01', true);
        }

        if (this.riskObj.occupationCode) {
            let _rec = this.lovDropDownService.lovDataList.Occupation.find((_data) => _data.VALUE == this.riskObj.occupationCode);

            if (_rec && _rec.REFERREDRISK && _rec.REFERREDRISK == 'Y') {
                isReferredRisk = true;
                this.riskObj.occRiskClassification = "Referred";
                _reasons.reason.push("Occupation code of type Referred selected");
                this.addReferralReason('05', true);
            }
            else if (_rec && _rec.REFERREDRISK && _rec.REFERREDRISK == 'D') {
                isDeclinedRisk = true;
                this.riskObj.occRiskClassification = "Declined";
                _reasons.reason.push("Declined : Occupation code of type Declined selected");
            }
            else {
                this.riskObj.occRiskClassification = "Standard";
            }

            if (this.riskObj.occRiskClassification != 'Referred') {
                this.deleteReferralReason('05', true);
            }
        }

        if (this.riskObj.referralReasons.referralReason && this.riskObj.referralReasons.referralReason.length > 0 && this.riskObj.referralReasons.referralReason.find((_data1) => _data1.isSysReferred != 'Y')) {
            isReferredRisk = true;
            _reasons.reason.push("Referral Reason added");
        }

        this.riskObj.riskClassificationReasons.reasons = _reasons;

        if (isDeclinedRisk == true) {
            this.riskObj.symRiskClassification = "Declined";
        }
        else if (isReferredRisk == true) {
            this.riskObj.symRiskClassification = "Referred";
        }
        else this.riskObj.symRiskClassification = "Standard";

        this.handleRiskClassification();
    }

    handleRiskClassification() {
        if (this.riskObj.symRiskClassification == "Declined")
            this.riskObj.riskClassification = "Declined";
        else if (this.riskObj.symRiskClassification == "Referred" || this.riskObj.riRiskClassification == "Referred")
            this.riskObj.riskClassification = "Referred";
        else
            this.riskObj.riskClassification = "Standard";

        this.setRiskClassification(this);
        // this.emitRiskClass(this);
    }

    onOccChange(ev) {
        this.riskObj.occupationCode = ev.value;
        this.riskObj.occupationDescription = (ev.record.DESCRIPTION) ? ev.record.DESCRIPTION.slice(0, 40) : "";

        this.checkReferredRiskConditions();
    }

    onDOBChange(ev) {
        // riskObj.dateOfBirth=$event;
        // setInsuredAge();
        this.riskObj.dateOfBirth = ev;

        this.validateDOB(ev);
        this.calculateInsuredAge();

        if (this.riskObj.dateOfBirth) {
            let dobDate = moment(this.riskObj.dateOfBirth, "YYYY-MM-DD");
            var _inclusionDate = moment(this.riskObj.inclusionDate, "YYYY-MM-DD");

            if (dobDate._i != _inclusionDate._i && dobDate > _inclusionDate) {
                this.riskObj.dateOfBirth = '';
                if (this.DOBCtrl != null) {
                    this.DOBCtrl.setter("EMPTY", "YYYY-MM-DD", this.DOBCtrl.comp);
                }
                this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Date of Birth must be before the policy Expiry date.", 3000));
            } else {

                if (this.riskObj.plan && this.riskObj.dateOfBirth) {
                    this.getPremiumForPlan();
                }
            }
        }

        this.checkReferredRiskConditions();
    }

    calculateInsuredAge() {
        if (this.riskObj && this.riskObj.inclusionDate && this.riskObj.dateOfBirth) {
            let _inclusionDate = moment(this.riskObj.inclusionDate, "YYYY-MM-DD");
            let _insuredDOB = moment(this.riskObj.dateOfBirth, "YYYY-MM-DD");
            // let age = _inclusionDate.diff(_insuredDOB, 'years');
            let dobYear = _insuredDOB.year();
            let inclDtYear = _inclusionDate.year();
            let age = inclDtYear - dobYear;

            this.riskObj.insuredAge = age;
        }
        else {
            this.riskObj.insuredAge = 0;
            // this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Date of Birth or Inclusion Date cannot be empty or age cannot be zero.", 5000));
        }
    }
    //VK013
    public formatText(event) {
        var value = event.target.value;
        var valid = true;
        var maxLineChars = 60;
        var result = "";
        var finalLines = [];
        var lines = value.split(/\r\n|\r|\n/g);
        var length = lines.length;
        var str1: String,str2: String,strn: String,temp_str: String;
        var x = false;
        
        for (var i = 0; i < length; i++) {
            if (lines[i].length > maxLineChars) {
                    strn = lines[i];
                        while( strn.length > maxLineChars ){
                        str1 = strn.substring(0, maxLineChars);
						str2 = strn.substring(maxLineChars);
						
						if( !str1.endsWith(" ") && !str2.startsWith(" ") && str1.lastIndexOf(" ") != -1) {
							
							str1 = str1.substring(0, str1.lastIndexOf(" "));
							temp_str = strn.substring(str1.length);
							if(temp_str.startsWith(" ")) {
								strn = strn.substring(str1.length+1);
							} else { 
								strn = temp_str;
							}
						}
						else {
							strn = str2;
                        }
                        finalLines[finalLines.length] = str1;
                    }
                    if(strn != "" && strn.length <= maxLineChars) {
                        finalLines[finalLines.length] = strn;
                    }
                } else {
                finalLines[finalLines.length] = lines[i];
            }
        }
        
        for (var i = 0; i < finalLines.length; i++) {
            result += finalLines[i];
            if (i + 1 < finalLines.length) {
                result += "\n";
            }
        }
        event.target.value = result;
        this.riskObj.exclusionText = result;
    }

}

export class LocalABPlans {
    constructor(
        public COMB_DESC: string,
        public DESCITEM: string,
        public VALUE: string,
        public DESCRIPTION: string
    ) { }
}