import { Clause } from "../../appobjects/clause"
import { AppUtil } from '../../../../../../common/components/utility/apputil/app.util';
import { Nominee, NomineeDetails } from "../../appobjects/nomineeslist";
import { FinancialInterest } from '../../../../../../common/components/financialinterest/appobjects/financialInterest';
import { GSTDetails } from '../../appobjects/gstDetails';
import { DoctorDetails } from '../../appobjects/doctorDetails';
import { NBRisk } from '../../../appobjects/nbrisk';
import { PostedPrem } from '../../../proposalheader/appobjects/postedprem';
import { RiskHelper } from '../../../appobjects/riskhelper';
import { ReferredReason } from '../../../proposalheader/appobjects/referredreason';
import { ReferralReasons } from '../../appobjects/referralReasons';
import { S6271Validator } from '../../../validation/s6271.validator';
import { S6272Validator } from '../../../validation/s6272.validator';

export class S6271 extends RiskHelper implements NBRisk {
    /**** BPM Common Fields   *****/
    public RIRequired: string = "No";
    public hasClaimExperience: string = "N";
    public RIMethodSys: string = "0";
    public isRIOverWrittenByUW: string = "N";
    public identity: string = "";
    public minimumPremium: number = 0;
    public isSurveyNeeded: string = "N";

    /***Defaulted and Hidden****/
    public sequenceNumber: string;
    public effectiveDate: string;
    public dateOfAttachment: string;
    public memberEffectiveDate: string;
    public contractNumber: string = "";
    public contractType: string;
    public riskNumber: string;
    public riskType: string;
    public riskName: string;
    public terminationDate: string;
    public RIRetentionCode: string;
    public SICurrency: string = "RM";
    public currencyRate: string = "1.0000000";
    public premiumClass: string = "";
    public searchCode: string;
    public searchDescription: string;
    public RIMethod: string = "0";
    public ratingFlag: string = "A";

    /*****Risk Header Fields***/
    public insuredPerson: string;
    public occupationCode: string;
    public occupationDescription: string;
    public dateOfBirth: string;
    public insuredAge: number = 0;
    public CRIISI: number = 0;//capture Critical Illness Sum Insured from insured info
    public CRIIPremium: number = 0;//capture Critical Illness Premium from insured info

    public ageLimitFlag: string = "";

    public bigCapitalSumInsured: number = 0;
    public riskClassification: string = "Standard";
    public symRiskClassification: string = "";
    public conveyanceRiskClassification: string = "Standard";
    public riskClassificationReason: string = "";
    public occRiskClassification: string = "Standard";
    public noOfPersons: number = 0;
    public s6272Items: S6272Item;

    public rebate: number = 0;
    public rebateAmount: number = 0;
    public discountedPremium: number = 0;
    public GSTDetails: GSTDetails;
    public GST: number = 0;
    public gstAmount: number = 0;
    public totalPremium: number = 0;
    public clauses: Clause;
    public financialInterest: FinancialInterest;
    public relatedSumInsured: number = 0;

    public capitalSumInsured: number = 0;
    public totalGrossCapacity: number = 0;
    public postingPremium: number = 0;
    public originalTotalPremium: number = 0;
    public basePostedPremiumAdj: number = 0;
    public isPOIConsidered: string = "N";
    public priority: string;
    public postedPremium: number = 0;
    public GT: string;
    public FI: string = "Y";
    public GP: string;
    public CL: string;
    public addRelatedCases: string = "Y";

    public postingMessage: string = "";
    public gpText: string = "";
    public gpTextCount:string="";//VK004
    //public survey:Survey;
    public postedPremDetails: PostedPrem;

    public childRiskPath: string = "s6272Items.s6272Item";
    public childRiskIdentity: string;
    public riskClassificationReasons: ReferredReason;

    public s6273PostingStatus: string = "N";

    public SST: number = 0; //SST Code
    public sstAmount: number = 0;//SST Code
    public SSTLiveDate: string;//SST Code
    public GSTLiveDate: string;//SST Code
    public isGSTApplicable: boolean = true;//SST Code
    constructor() {
        super();
        this.s6272Items = new S6272Item();
        this.financialInterest = new FinancialInterest();
        this.GSTDetails = new GSTDetails();
        // this.relatedCases = new FireRelatedCases();
        this.clauses = new Clause();
        this.riskClassificationReasons = new ReferredReason();
    }

    public getInstance(valObj: S6271) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
            this.s6272Items = new S6272Item().getInstance(valObj.s6272Items);
            this.clauses = new Clause().getInstance(valObj.clauses);
            this.GSTDetails = new GSTDetails().getInstance(valObj.GSTDetails);
            if (valObj.FI == "Y") {
                this.financialInterest = new FinancialInterest().getInstance(valObj.financialInterest);
            }
            this.riskClassificationReasons.refresh(valObj.riskClassificationReasons);
            /*if(valObj.addRelatedCases == "Y"){
                this.relatedCases = new FireRelatedCases().getInstance(valObj.relatedCases);
            }           
            if(valObj.isSurveyNeeded == "Y"){
                this.survey = new Survey().getInstance(valObj.survey);
            }*/
            if (valObj.isGSTApplicable != undefined && JSON.stringify(valObj.isGSTApplicable) != JSON.stringify("") && typeof (valObj.isGSTApplicable) == "string") {
                this.isGSTApplicable = Boolean(JSON.parse(valObj.isGSTApplicable));
            }
        }

        return this;
    }

    public getNewInstanceByCriteria(criteria: any) {
        let riskType = criteria.riskType;
        let contractType = criteria.contractType;
        this.RIRetentionCode = "HI01";
        //this.ratingFlag = "A"; MYS-2018-0878
        this.SICurrency = "RM";
        this.currencyRate = "1.0000000";
        if (riskType == "FSI") {
            this.premiumClass = "47O";
        } else if (riskType == "FHI") {
            this.premiumClass = "47J";
        } else if (riskType == "FHG") {
            this.premiumClass = "47K";
        }

        return this;
    }

    public getValidator() {
        return new S6271Validator(this);
    }
}

export class S6272Item {
    public s6272Item: S6272ItemDetails[] = [];
    public getInstance(valObj: S6272Item) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().handleArray(this, valObj, "s6272Item");
            for (let eachs6272Itm of this.s6272Item) {
                let s6272ItemObj = new S6272ItemDetails().getInstance(eachs6272Itm);
                this.s6272Item[this.s6272Item.indexOf(eachs6272Itm)] = s6272ItemObj;
            }
        }
        return this;
    }
}

export class S6272ItemDetails extends RiskHelper implements NBRisk {
    public contractNumber: string = "";
    public riskType: string;
    public riskName: string = "";
    public dateStart: string;
    public effectiveDate: string;
    public lastDateEnd: string;
    public indicator: string;
    public inclusionDate: string;
    public memberEffectiveDate: string;
    public endorsmentEndDate: string;
    public terminationDate: string;
    public GP: string;
    public NO: string;
    public FI: string;
    public CL: string;
    public DD: string;

    public noOfUnits: number = 1;
    public printCI: string = "Y";

    public itemNo: number;
    public riskClassification: string = "Standard";
    public category: string = "";
    public nationality: string;
    public homeCity: string;
    public residence: string;
    public areaCode: string;
    public areaMultiplier: number = 0;
    public ratingFlag: string = "A";

    public basis: string = "NAMED";
    public noOfPerson: string = "1";
    public seatNo: number = 0;
    public insuredPerson: string = "";
    public insuredSalutation: string;
    public occupationCode: string;
    public occupationDescription: string;
    public ratingClass: string;
    public occupationClassRate: number = 0;
    public IdProofNo: string = "";
    public dateOfBirth: string;
    public gender: string;
    public maritalStatus: string;
    public symRiskClassification: string = "";
    public riskClassificationReason: string = "";
    public insuredAge: number = 0;
    public planAgeLimit: number;
    public occRiskClassification: string = "Standard";
    public riRiskClassification: string = "Standard";
    public renewalBonusAmount: number;
    public renewalBonusPercentage: number;

    public rbpCode: string = "";
    public rbpDesc: string = "";
    public rbpMethod: string = "";
    public rbpSIAdjustment: string = "";
    public rbpMaxYears: string = "";
    public rbpRestartRBPlan: string = "";

    public exclusionText: string;
    public EXPostingStatus: string = "N";
    public plan: string;
    //public additionalCode:string;

    public planBenefits: Benefit;
    public additionalCoverDetails: AdditionalCoverageDetails;
    public nomineeDetails: NomineeDetails;
    public doctorDetails: DoctorDetails;
    public clauses: Clause;
    public MATRPlanCode: string = "";
    public MATRNorm: number = 0;
    public MATRComp: number = 0;
    public MaternityDate: string = "";
    public CRIIPlanCode: string = "";
    public CRIISI: number = 0;
    public CRIIDate: string = "";
    public TPA: string = "";
    public SERV: string = "";

    public gpText: string = "";

    public entryBonusPercentage: number = 0;
    public entryBonusAmount: number = 0;
    public premiumFromPlan: number = 0;
    public basicPremium: number = 0;
    public seatPremium: number = 0;
    public totalPremium: number = 0;
    public deductibleType: string = "";
    public deductiblePercentage: number = 0;
    public deductibleAmount: number = 0;
    public renewalDiscountPercentage: number = 0;
    public renewalDiscountAmount: number = 0;
    public loadingDiscountPercentage: number = 0;
    public loadingDiscountAmount: number = 0;
    public familyDiscountPercentage: number = 0;
    public familyDiscountAmount: number = 0;
    public maternityPremium: number = 0;
    public CRIIPremium: number = 0;
    public postingPremium: number = 0;
    public totalAnnualPremium: number;
    public additionalLoading: string;
    public addditionalPremium: number = 0;
    public discountedPremium: number = 0;
    public rebate: number = 0;
    public rebateAmount: number = 0;
    public GST: number = 0//6; //SST Code
    public gstAmount: number = 0;
    public originalTotalPremium: number = 0;
    public postedPremium: string;
    public sumInsured: number = 0;
    public lifeTime: number = 0;
    public rebatePercentage: number = 0;

    public hasClaimExperience: string = "N";
    public isPOIConsidered: string = "N";
    public priority: string;
    public basePostedPremiumAdj: number = 0;
    public postingMessage: string = "";
    public childRiskPath: string;
    public childRiskIdentity: string = "itemNo";
    public riskClassificationReasons: ReferredReason;
    public referralReasons: ReferralReasons;
    public ageLimitFlag: string = "";
    public isInsuredTerminated: string =""; //Renewals KA001  

    public SST: number = 0; //SST
    public sstAmount: number = 0;//SST
    constructor() {
        super();
        this.planBenefits = new Benefit();
        this.additionalCoverDetails = new AdditionalCoverageDetails();
        this.clauses = new Clause();
        this.nomineeDetails = new NomineeDetails();
        this.doctorDetails = new DoctorDetails();
        this.riskClassificationReasons = new ReferredReason();
        this.referralReasons = new ReferralReasons();
    }

    public getInstance(valObj: S6272ItemDetails) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
            this.planBenefits = new Benefit().getInstance(valObj.planBenefits);
            this.additionalCoverDetails = new AdditionalCoverageDetails().getInstance(valObj.additionalCoverDetails);
            this.clauses = new Clause().getInstance(valObj.clauses);
            this.nomineeDetails = new NomineeDetails().getInstance(valObj.nomineeDetails);
            this.doctorDetails = new DoctorDetails().getInstance(valObj.doctorDetails);
            this.riskClassificationReasons = new ReferredReason().getInstance(valObj.riskClassificationReasons);
            this.referralReasons = new ReferralReasons().getInstance(valObj.referralReasons);
        }
        return this;
    }

    public getNewInstanceByCriteria(criteria: any) {
        let riskType = criteria.riskType;
        let contractType = criteria.contractType;

        return this;
    }

    public getValidator() {
        return new S6272Validator(this);
    }
}

export class Benefit {
    public benefit: BenefitItem[] = [];

    public getInstance(valObj: Benefit) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().handleArray(this, valObj, "benefit");
        }
        return this;
    }
}

export class BenefitItem {
    public seqNumber: number;
    public coverageCode: string;
    public coverageDescription: string;
    public extraText: string = "";
    public etPostingStatus: string = "N";
    public sumInsured: number = 0;           //SUMIN
    public otherSumInsured: number = 0;        //ZPTDSI
    public indicator: string;                //IND
}

export class AdditionalCoverageDetails {

    public additionalCover: AdditionalCoverage[] = [];
    public additionalCoverTotal: number = 0;

    public getInstance(valObj: AdditionalCoverageDetails) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
            new AppUtil().handleArray(this, valObj, "additionalCover");
        }
        return this;
    }
}

export class AdditionalCoverage {

    public category: string = "";
    public categoryDescription: string = "";
    public plan: string = "";
    public planDescription: string = "";
    public premium: number = 0;;
    public loading: number = 0;;
    public discount: number = 0;
    public effectiveDate: string = "";
    public terminationDate: string = "";
    public totalPremium: number = 0;
    public benefitsText: string = "";
    constructor() { }
}
