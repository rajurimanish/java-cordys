/*
 * Change History:
 * 
 * No      Date          Description                                   Changed By
 * ====    ==========    ===========                                   ==========

 *KA0001  12/6/2018    MYS-2018-0555- To aupopulate DOB,age & gender    Divek 
 *GA001   01/10/2018   MYS-2018-0443 - Age Checking for PA Products (T7253)    KGA	
                                      										  							   
*/

import { Component, ElementRef, OnInit } from "@angular/core";
import { ChangeDetector } from '../../../../../common/services/changedetector.service';
import { LOV_Field, LOVDropDownService, SearchFilter } from "../../../../../common/services/lovdropdown/lovdropdown.service";
import { Insured, InsuredDetails } from "../appobjects/insuredlist";
import { InsuredValidator } from '../../validation/insured.validator';
import { Validator, ValidationResult } from '../../../../../common/components/validator/validator';
import { AlertMessagesService } from '../../../../../common/components/utility/alertmessage/alertmessages.service';
import { AlertMessage } from '../../../../../common/components/utility/alertmessage/alertmessages.model';
import { BMSConstants } from '../../../common/constants/bms_constants';
import { ApplicationUtilService } from '../../../../../common/services/application.util.service';
import { Travel } from "../travel/appobjects/travel";
declare var moment: any;
declare var jQuery: any;

@Component({
    selector: 'insuredDetails-dialog',
    templateUrl: 'app/bms/components/proposal/newbusinessrisks/dialogs/insuredDetailDialog.template.html',
    inputs: ['datainput', 'closeDialog', 'parentCompPRMS'],
    outputs: ['destroy']
})

export class InsuredDetailsDialogComponent implements OnInit {

    constructor(private lovDropDownService: LOVDropDownService, public _alertMsgService: AlertMessagesService, private _applicationUtilService: ApplicationUtilService) { }
    public riskObj: Travel;// Divek-0555
    public _insuredDetails: Insured;
    public insuredlist: InsuredDetails;
    private editItemIdx;
    private isViewPanel: boolean = false;

    public datainput: any;
    public closeDialog: Function;
    public parentCompPRMS: any;
    private termnDateCtrl: any;
    private DOBCtrl: any;
    private riskType: string;

    private CloseDialog() {
        let result = this.isInsuredValid();
        if (result.isValid) {
            if (this.isViewPanel)
                this.closeDialog({ "insured": this._insuredDetails, "editItem": this.editItemIdx }, this.parentCompPRMS);
            else
                this.closeDialog(this._insuredDetails, this.parentCompPRMS);
        }
        else
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, result.message, 3000));
    }

    ngOnInit(): any {
        this.isViewPanel = this.datainput.isView;
        this.populateLOVs();
        this.insuredlist = this.datainput.insuredAry;
        if (this.isViewPanel == true) {
            this._insuredDetails = new Insured();
            this._insuredDetails = jQuery.extend(true, {}, this.datainput.selectedInsured);//clone and assign
            this.editItemIdx = this.datainput.editItem;
        } else {
            this._insuredDetails = new Insured();
        }
        this.riskType = BMSConstants.getSelectedRiskType();
        this.setInsuredAge();//GA001
    }
    //Divek MYS-2018-0678 changes removed validation on Gender and Occupation Code
    private isInsuredValid() {
        let insuredDetailsResult: ValidationResult = new ValidationResult();
        insuredDetailsResult.isValid = true;
        insuredDetailsResult.message = "";
        if (!this._insuredDetails.name || this._insuredDetails.name == " " || (!this._insuredDetails.nric && !this._insuredDetails.ICPassport) || !this._insuredDetails.DOB) { // || !this._insuredDetails.gender   || !this._insuredDetails.occupationCode  -- removed 
            insuredDetailsResult.isValid = false;
            insuredDetailsResult.message = "<br>Enter all mandatory fields in Insured Information section.";
        }

        if (this._insuredDetails.ICPassport && (/[^a-zA-Z0-9/-]/g.test(this._insuredDetails.ICPassport) || (!/[^a-zA-Z0-9/-]/g.test(this._insuredDetails.ICPassport) && this._insuredDetails.ICPassport.length < 4))) {
            insuredDetailsResult.isValid = false;
            insuredDetailsResult.message = insuredDetailsResult.message + "<br>Enter valid Passport number.";
        }

        if (this._insuredDetails.nric) {
            if (/^\d{6}\-\d{2}\-\d{4}/g.test(this._insuredDetails.nric)) {
                if (this._insuredDetails.DOB) {
                    let date = this._insuredDetails.nric.substring(0, 6);
                    let century = this._insuredDetails.nric.substring(0, 2);
                    if (Number(century) > 29)
                        date = '19' + date;
                    else
                        date = '20' + date;
                    if (date != moment(this._insuredDetails.DOB, "YYYY-MM-DD").format("YYYYMMDD")) {
                        //this.DOBCtrl.setter(moment(date,"YYYYMMDD").format("YYYY-MM-DD"),"YYYY-MM-DD",this.DOBCtrl.comp);
                        insuredDetailsResult.isValid = false;
                        insuredDetailsResult.message = insuredDetailsResult.message + "<br> DOB doesn't match with NRIC number provided";
                    }
                }
            }
            else {
                insuredDetailsResult.isValid = false;
                insuredDetailsResult.message = insuredDetailsResult.message + "<br>NRIC entered is not in valid format, should be entered in XXXXXX-XX-XXXX format.";

            }
        }

        // let result = new InsuredValidator(this._insuredDetails).validate();
        if (insuredDetailsResult.isValid == true) {
            let total = 0;
            if (this.insuredlist && this.insuredlist.insured.length > 0) {
                for (var index = 0, assoLength = this.insuredlist.insured.length; index < assoLength; index++) {
                    if (((this.insuredlist.insured[index].ICPassport && this._insuredDetails.ICPassport == this.insuredlist.insured[index].ICPassport) || (this.insuredlist.insured[index].nric && this._insuredDetails.nric == this.insuredlist.insured[index].nric)) && this.editItemIdx != index) {
                        if (insuredDetailsResult.isValid) {
                            insuredDetailsResult.isValid = false;
                            insuredDetailsResult.message = "<br>A Insured already exists with the entered ICPassport Number";
                        } else {
                            insuredDetailsResult.message = insuredDetailsResult.message + "<br>A Insured already exists with the entered ICPassport Number";
                        }
                        break;
                    }

                }
            }
        }

        // this.validateDOB();

        return insuredDetailsResult;
    }

    private populateLOVs(): void {

        this.lovDropDownService.createLOVDataList(["Occupation", "Gender"]);
        let lovFields = [
            new LOV_Field("ALL", "MOTOR", "NEW BUSINESS", "ALL", "NEW", "NAMED_DRIVER", "Occupation", "LOV", [], "DESCPF", "Occupation", null),
            new LOV_Field("ALL", "ALL", "CLAIMS", "ALL", "ALL", "ALL", "Gender", "LOV", [], "DESCPF", "Gender", null)
        ];
        this.lovDropDownService.util_populateLOV(lovFields, this);
    }

    onChangeNRIC(event) {
        let value = event.target.value
        if (value != "") {
            if (isNaN(value))
                this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Please fill Valid Value for field NRIC", -1));
            else {
                let date = value.substring(0, 6);
                let century = value.substring(0, 2)
                if (Number(century) > 29)
                    date = '19' + date;
                else
                    date = '20' + date;
                if (this.DOBCtrl != null)
                    this.DOBCtrl.setter(moment(date, "YYYYMMDD").format("YYYY-MM-DD"), "YYYY-MM-DD", this.DOBCtrl.comp);
            }
        }
    }

    validateDOB() {
        if (this._insuredDetails.ICPassport != undefined && this._insuredDetails.ICPassport != "") {
            let date = this._insuredDetails.ICPassport.substring(0, 6);
            let century = this._insuredDetails.ICPassport.substring(0, 2)
            if (Number(century) > 29)
                date = '19' + date;
            else
                date = '20' + date;
            if (date != moment(this._insuredDetails.DOB, "YYYY-MM-DD").format("YYYYMMDD"))
                this.DOBCtrl.setter(moment(date, "YYYYMMDD").format("YYYY-MM-DD"), "YYYY-MM-DD", this.DOBCtrl.comp);
        }
    }

    validateTextInput(ev) {
        let eVal = ev.target.value;
        ev.target.value = eVal.replace(/\s\s+/g, ' ');
    }

    setMaxDateForDOBDate() {
        if (this.DOBCtrl != null) {
            // this.DOBCtrl.setMaxDate(moment.utc(new Date()).format("YYYY-MM-DD"), this.DOBCtrl.comp);
        }
    }

    setMinNdMaxForStartDate() {
        if (this.termnDateCtrl != null) {
            let effectiveDate = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.effectiveDate;
            let endDate = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.endDate;
            this.termnDateCtrl.setMinDate(moment(effectiveDate, "YYYY-MM-DD").format(this.getDateFormat()), this.termnDateCtrl.comp);
            this.termnDateCtrl.setMaxDate(moment(endDate, "YYYY-MM-DD").format(this.getDateFormat()), this.termnDateCtrl.comp);
        }
    }

    validateTermnDate() {
        let _effectiveDate = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.effectiveDate;
        let _endDate = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.endDate;

        _effectiveDate = moment(_effectiveDate, "YYYY-MM-DD");
        _endDate = moment(_endDate, "YYYY-MM-DD");

        if (this._insuredDetails.terminationDate != null && this._insuredDetails.terminationDate != "") {
            let _termnDate = moment(this._insuredDetails.terminationDate, "YYYY-MM-DD");

            if (_termnDate < _effectiveDate || _termnDate > _endDate) {
                if (this.termnDateCtrl != null)
                    this.termnDateCtrl.setter("EMPTY", "YYYY-MM-DD", this.termnDateCtrl.comp);
                this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Termination Date should be with in Period of Inusrance date range", 3000));
            }
        }
    }

    validateDOBDate() {
        if (this._insuredDetails.DOB != null && this._insuredDetails.DOB != "") {
            let _days = this._applicationUtilService.getDateDiffWithCurrentDate(moment(this._insuredDetails.DOB, "YYYY-MM-DD"), "YYYY-MM-DD", "days");
            // if(moment(this._insuredDetails.DOB,"YYYY-MM-DD") > moment.utc(new Date()).format("YYYY-MM-DD") ){
            if (_days < 0) {
                if (this.DOBCtrl != null)
                    this.DOBCtrl.setter('EMPTY', "YYYY-MM-DD", this.DOBCtrl.comp);
                this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "DOB can not be greater than Current date", 2000));
            }
        }
    }

    getDateFormat() {
        let dtFormat = ApplicationUtilService.DATE_TIME_FORMAT;
        return dtFormat.split(" ")[0];
    }

    onOccChange(ev) {
        if (ev.record.DESCRIPTION) {
            this._insuredDetails.occupationDescription = ev.record.DESCRIPTION.slice(0, 40);
        } else
            this._insuredDetails.occupationDescription = '';
    }

    validateNRICFormat() {
        let _nric = this._insuredDetails.nric;
        if (_nric.match(/^\d{6}\-\d{2}\-\d{4}/g)) {
            return true;
        }
        return false;
    }

    // Divek ---MYS-2018-0555 changes Start

    onChangeNRIC1(event) {
        let eVal = event.target.value;
        if (eVal != null && eVal != "") {
            let isValidFormat = new RegExp("[0-9]{6}-[0-9]{2}-[0-9]{4}$").test(eVal);
            if (isValidFormat == false) {
                this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Invalid NRIC format. Correct format is YYMMDD-XX-XXXX.", 5000));
                this._insuredDetails.nric = "";
            }
            else {
                let date = eVal.substring(0, 6);
                let century = eVal.substring(0, 2)
                if (Number(century) > 29)
                    date = '19' + date;
                else
                    date = '20' + date;
                let dob = moment(date, "YYYYMMDD");
                //	let curDate = moment(new Date().toISOString(), "YYYYMMDD");
                let curDate = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.effectiveDate;
                curDate = moment(curDate, "YYYYMMDD");
                if (curDate.diff(dob, 'days') < 0)
                    date = '19' + date.substring(2, 6);
                if (this.DOBCtrl != null) {
                    this.DOBCtrl.setter(moment(date, "YYYYMMDD").format("YYYY-MM-DD"), "YYYY-MM-DD", this.DOBCtrl.comp);
                    this.setInsuredAge();
                }
            }
            let gender = eVal.substr(13, 13);
            if ((gender % 2) == 0) {

                this._insuredDetails.gender = "F"
            }
            else {
                this._insuredDetails.gender = "M"
            }
        }
    }
    // KA0001 MYS-2018-0555 changes
    setInsuredAge() {
        if (this._insuredDetails.DOB != null && this._insuredDetails.DOB != "") {
            //   let curDate = moment(new Date().toISOString(), "YYYY-MM-DD");
            if (this.riskType != 'TDA') {
                let curDate = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.effectiveDate;
                curDate = moment(curDate, "YYYY-MM-DD");
                let date = moment(this._insuredDetails.DOB, "YYYY-MM-DD").format("YYYY-MM-DD");
                this._insuredDetails.insuredAge = curDate.diff(date, 'year');

            }
            else {
                let curDate = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.effectiveDate;
                let date = moment(this._insuredDetails.DOB, "YYYY-MM-DD").format("YYYY-MM-DD");
                let dobYear = date.substring(0, 4);
                let inclDtYear = curDate.substring(0, 4);
                let age = inclDtYear - dobYear;
                this._insuredDetails.insuredAge = age;
            }
        }
        else {
            this._insuredDetails.insuredAge = 0;
            //this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "DOB can not be empty.", 5000));            
        }
    }

    // Divek ---MYS-2018-0555 changes END

}