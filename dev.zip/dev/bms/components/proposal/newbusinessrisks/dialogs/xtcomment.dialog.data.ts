export class XTCommentDialogData {
    constructor(
        public component?: any,
        public moduleAbsPath?: any,
        public moduleName?: any,
        public dialogTitle?: string,
        public dialogName?: string,
        public icon?: string,
        public coverageItem?: any,
        public callBackHandler?: any
    ) {

    }
}