/*
Change History	:

	No      Date          Description                                 Changed By
	====    ==========    ===========                                 ==========	
    GA001   29/07/2019   MYS-2019-0857 - HD Log Incorrect validation 
                         Nominee Insured DOB for renewal cases in BMS     KGA
    GA002   11/09/2019    MYS-2019-0974 - BMS Enhancement on High Risk Vehicle & Client       KGA			               
 * 
 */
import { Component, ElementRef, OnInit } from "@angular/core";
import { ChangeDetector } from '../../../../../common/services/changedetector.service';
import { Nominee, NomineeDetails } from "../appobjects/nomineeslist";
import { LOV_Field, LOVDropDownService, SearchFilter } from "../../../../../common/services/lovdropdown/lovdropdown.service";
import { NomineeValidator } from '../../validation/nominee.validator';
import { AlertMessagesService } from '../../../../../common/components/utility/alertmessage/alertmessages.service';
import { AlertMessage } from '../../../../../common/components/utility/alertmessage/alertmessages.model';
import { ApplicationUtilService } from '../../../../../common/services/application.util.service';

declare var moment: any;
declare var jQuery: any;

@Component({
    selector: 'nomineeDetails-dialog',
    templateUrl: 'app/bms/components/proposal/newbusinessrisks/dialogs/nomineeDetaildialog.template.html',
    inputs: ['datainput', 'closeDialog', 'parentCompPRMS'],
    outputs: ['destroy']
})

export class NomineeDetailsDialogComponent implements OnInit {

    constructor(private _lovDropDownService: LOVDropDownService, public _alertMsgService: AlertMessagesService, private _applicationUtilService: ApplicationUtilService) { }

    public _nomineeDetails: Nominee;
    public nomineelist: NomineeDetails;
    private DOBCtrl: any;
    private editItemIdx;
    private isViewPanel: boolean = false;

    public datainput: any;
    public closeDialog: Function;
    public parentCompPRMS: any;

    private CloseDialog() {
        let result = this.isNomineeValid();
        if (result.isValid) {
            if (this.isViewPanel)
                this.closeDialog({ "nominee": this._nomineeDetails, "editItem": this.editItemIdx }, this.parentCompPRMS);
            else
                this.closeDialog(this._nomineeDetails, this.parentCompPRMS);
        }
        else
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, result.message, 3000));
    }

    ngOnInit(): any {
        this.isViewPanel = this.datainput.isView;
        this.populateLOVs();
        this.nomineelist = this.datainput.nomineeAry;
        if (this.isViewPanel == true) {
            this._nomineeDetails = new Nominee();
            this._nomineeDetails = jQuery.extend(true, {}, this.datainput.selectedNominee);//clone and assign
            if( this._nomineeDetails.DOB == "Invalid date" ){
                this._nomineeDetails.DOB = "";
            }
            this.editItemIdx = this.datainput.editItem;
        } else {
            this._nomineeDetails = new Nominee();
        }
    }

    private isNomineeValid() {
        let result = new NomineeValidator(this._nomineeDetails).validate();
        if (result.isValid == true) {

            let total = 0;
            if (this.nomineelist && this.nomineelist.nominee.length > 0) {
                for (var index = 0, assoLength = this.nomineelist.nominee.length; index < assoLength; index++) {
                    //GA002
                    if ( this._nomineeDetails.ICPassport.replace( /[-,/]/g, '' ) == this.nomineelist.nominee[index].ICPassport.replace(/[-,/]/g, '') && this.editItemIdx != index) {
                        result.message = "A Nominee already exists with the entered ICPassport Number";
                        result.isValid = false;
                        return result;
                    }
                    if (this.editItemIdx != index)
                        total = total + parseFloat('' + this.nomineelist.nominee[index].percentageOfShare);
                }
            }
            total = total + parseFloat('' + this._nomineeDetails.percentageOfShare)
            if (total > 100) {
                result.isValid = false;
                result.message = "Please make sure total percentage will be equal to 100.";
            }
        }
        return result;
    }

    private populateLOVs(): void {

        this._lovDropDownService.createLOVDataList(["Relationship"]);
        let lovFields = [
            new LOV_Field("ALL", "PERSONAL ACCIDENT", "NEW BUSINESS", "ALL", "NEW", "NOMINEE", "NomineeRelationship", "LOV", [], "DESCPF", "NomineeRelationship", null),
        ];
        this._lovDropDownService.util_populateLOV(lovFields, this);
    }

    onChangeNRIC(event) {
        let value = event.target.value;

        if (value != "") {
            if (isNaN(value))
                this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Please fill valid value for field NRIC", -1));
            else {
                let date = value.substring(0, 6);
                let century = value.substring(0, 2)
                if (Number(century) > 29)
                    date = '19' + date;
                else
                    date = '20' + date;
                if (this.DOBCtrl != null)
                    this.DOBCtrl.setter(moment(date, "YYYYMMDD").format("YYYY-MM-DD"), "YYYY-MM-DD", this.DOBCtrl.comp);
            }
        }
    }

    validateDOB() {
        if (this._nomineeDetails.ICPassport != undefined && this._nomineeDetails.ICPassport != "") {
            let date = this._nomineeDetails.ICPassport.substring(0, 6);
            let century = this._nomineeDetails.ICPassport.substring(0, 2)
            if (Number(century) > 29)
                date = '19' + date;
            else
                date = '20' + date;
            if (date != moment(this._nomineeDetails.DOB, "YYYY-MM-DD").format("YYYYMMDD"))
                this.DOBCtrl.setter(moment(date, "YYYYMMDD").format("YYYY-MM-DD"), "YYYY-MM-DD", this.DOBCtrl.comp);
        }
    }

    validateDOBDate() {
        if (this._nomineeDetails.DOB != null && this._nomineeDetails.DOB != "") {
            let _days = this._applicationUtilService.getDateDiffWithCurrentDate(moment(this._nomineeDetails.DOB, "YYYY-MM-DD"), "YYYY-MM-DD", "days");

            if (_days < 0) {
                if (this.DOBCtrl != null)
                    this.DOBCtrl.setter('EMPTY', "YYYY-MM-DD", this.DOBCtrl.comp);
                this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "DOB can not be greater than Current date", 2000));
            }
        }
    }

    validateTextInput(ev) {
        let eVal = ev.target.value;
        ev.target.value = eVal.replace(/\s\s+/g, ' ');
    }

    validateNRICFormat() {
        let _nric = this._nomineeDetails.ICPassport;
        if (_nric.match(/^\d{6}\-\d{2}\-\d{4}/g)) {
            return true;
        }
        return false;
    }
    //GA001 START
    onChangeNRICBC(event) {
        let eVal = event.target.value;
        
        if (eVal != null && eVal != "") {
            let isValidFormat = new RegExp("[0-9]{6}-[0-9]{2}-[0-9]{4}$").test(eVal);
            if (isValidFormat == true) {
                let date = eVal.substring(0, 6);
                let century = eVal.substring(0, 2)
                if (Number(century) > 29)
                    date = '19' + date;
                else
                    date = '20' + date;
                let dob = moment(date, "YYYYMMDD");
                let curDate = moment(new Date().toISOString(), "YYYYMMDD");
                if (curDate.diff(dob, 'days') < 0)
                    date = '19' + date.substring(2, 6);
                if (this.DOBCtrl != null) {
                    this.DOBCtrl.setter(moment(date, "YYYYMMDD").format("YYYY-MM-DD"), "YYYY-MM-DD", this.DOBCtrl.comp);
                }
            }
        }
    }
    //GA001 END

}