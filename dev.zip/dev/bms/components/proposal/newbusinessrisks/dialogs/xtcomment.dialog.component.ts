import { Component, OnInit, ElementRef } from "@angular/core";
import { XTComments, XTComment } from "../appobjects/xtComments";
import { AppUtil } from '../../../../../common/components/utility/apputil/app.util';
declare var jQuery: any;

@Component({
    selector: "xtcomment-component",
    templateUrl: "app/bms/components/proposal/newbusinessrisks/dialogs/xtcomment.dialog.template.html",
    inputs: ['datainput', 'closeDialog', 'parentCompPRMS']
})
export class XTCommentDialogComponent implements OnInit {
    private el: HTMLElement;
    private dialogName: string;
    // public comments: string;
    public parentCompParams: any;

    public datainput: any;
    public closeDialog: Function;
    public parentCompPRMS: any;
    public coverageItem: any;
    public xtCommentsArr: XTComment[] = [];

    constructor(el: ElementRef) {
        this.el = el.nativeElement;
    }

    ngOnInit() {
        this.dialogName = this.datainput.dialogName;
        this.parentCompParams = this.datainput.params;
        // this.comments = "";

        this.coverageItem = this.datainput.coverageItem;
        let _coverageItemXtComments = this.datainput.coverageItemXtComments;

        if (this.coverageItem && this.coverageItem.xtComments && this.coverageItem.xtComments.xtComment) {
            let _coverageItemXtComments = [];
            _coverageItemXtComments = new AppUtil().getArray(this.coverageItem.xtComments.xtComment);

            if (_coverageItemXtComments && _coverageItemXtComments.length > 0) {
                for (let item of _coverageItemXtComments) {
                    let _commentItem = new XTComment();
                    _commentItem.itemNo = item.itemNo;
                    _commentItem.comment = item.comment;
                    this.xtCommentsArr.push(_commentItem);
                }
            }
        }

        if (this.xtCommentsArr.length < 10) {
            let itrCnt = 10 - this.xtCommentsArr.length;
            let cnt = itrCnt;
            while (cnt > 0) {
                this.xtCommentsArr.push(new XTComment());
                cnt--;
            }
        }
    }

    private _closeDialog() {
        // if (this.hideReasons && this.comments.trim() === "") {
        // this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Please provide comments", 5000));
        // return;
        // }
        // this.CloseDialogWithComments();

        this.closeDialog({
            dialogName: this.dialogName,
            coverageItem: this.coverageItem,
            xtCommentsArr: this.xtCommentsArr,
            isDialogCancelled: true
        },
            this.parentCompPRMS
        );
    }

    private _saveDialog() {
        let _updatedXtCommentsArr: XTComment[] = [];
        let _prevXTCommentObj: XTComment;
        let _cnt = this.xtCommentsArr.length;
        let _itr = 1;

        for (let _xtComment of this.xtCommentsArr) {

            if (_itr != 1) {
                if (_prevXTCommentObj.comment || _xtComment.comment) {
                    _updatedXtCommentsArr.push(_prevXTCommentObj);
                }

                if (_itr == _cnt && _xtComment.comment) {
                    _updatedXtCommentsArr.push(_xtComment);
                }
            }

            _prevXTCommentObj = _xtComment;
            _itr++;
        }

        if (_updatedXtCommentsArr && _updatedXtCommentsArr.length > 0) {

            this.coverageItem.xtComments = new XTComments();
			/*
			if(!this.coverageItem.xtComments){
				this.coverageItem.xtComments = new XTComments();
			}
			else if(this.coverageItem.xtComments.xtComment == ""){
				let _xtCommentsArr:XTComment[]=[];
				this.coverageItem.xtComments.xtComment = _xtCommentsArr;
			}
			let _ary = [];
			_ary = new AppUtil().getArray(this.coverageItem.xtComments.xtComment);			
			this.coverageItem.xtComments.xtComment = _ary;
			this.coverageItem.xtComments.xtComment.length = 0;
			*/
            for (let _item of _updatedXtCommentsArr) {
                _item.itemNo = this.coverageItem.xtComments.xtComment.length + 1;
                this.coverageItem.xtComments.xtComment.push(_item);
            }
        }

        this.closeDialog({
            dialogName: this.dialogName,
            coverageItem: this.coverageItem,
            xtCommentsArr: _updatedXtCommentsArr,
            isDialogCancelled: false
        },
            this.parentCompPRMS
        );
    }

    /*private cancelDialog() {
        this.closeDialog({
            dialogName:this.dialogName,
            isDialogCancelled : true
            },
            this.parentCompPRMS
        );
    }*/

    private onKeyPressHandler(ev) {
        if (ev.keyCode == 13 || ev.target.value.length == 59) {
            this.setFocusToNext(ev.target);
        } else if (ev.keyCode == 32) {
            ev.target.value = ev.target.value.trim();
        }
    }

    private setFocusToNext(elmnt) {
        let locationElmnts = jQuery(this.el).find("input");
        jQuery(locationElmnts[locationElmnts.index(elmnt) + 1]).focus();
    }

    private addXTCommentRow() {
        let _commentItem = new XTComment();
        _commentItem.itemNo = this.xtCommentsArr.length + 1;

        this.xtCommentsArr.push(_commentItem);
    }
}