/*
Change History	:

	No      Date          Description                                 Changed By
	====    ==========    ===========                                 ==========
	GA001   20/12/2017    MYS-2017-0899 - BMS Nomination - 
						  Relationship Field's Drop Down List   	  KGA							   
*/
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DatePickerModule } from '../../../../../common/components/utility/date/datepicker.module';
import { SelectBoxModule } from "../../../../../common/components/utility/selectbox/selectbox.module";//GA001
import { NomineeDetailsDialogComponent } from "./nomineeDetailDialog.component";

@NgModule({
    imports: [CommonModule, FormsModule, ReactiveFormsModule, DatePickerModule, SelectBoxModule],//GA001
    declarations: [NomineeDetailsDialogComponent],
    exports: [NomineeDetailsDialogComponent]
})
export class NomineeDetailsDialogModule { }