import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { ExtraTextDialogComponent } from './extratext.dialog.component';

@NgModule({
    imports: [CommonModule, FormsModule, ReactiveFormsModule],
    declarations: [ExtraTextDialogComponent],
    exports: [ExtraTextDialogComponent]
})
export class ExtraTextDialogModule { }