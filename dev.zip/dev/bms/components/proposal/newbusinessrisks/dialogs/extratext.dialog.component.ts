/*
	No		Date			Description										Changed By
	====    ==========    	===========                                 	==========
	VK013   12/08/2019   	MYS-2019-0595- General Page(Print) alignment    VKR
                         
*/
import { Component, OnInit, ElementRef } from "@angular/core";
import { AppUtil } from '../../../../../common/components/utility/apputil/app.util';
declare var jQuery: any;

@Component({
    selector: "extratext-component",
    templateUrl: "app/bms/components/proposal/newbusinessrisks/dialogs/extratext.dialog.template.html",
    inputs: ['datainput', 'closeDialog', 'parentCompPRMS']
})
export class ExtraTextDialogComponent implements OnInit {
    private el: HTMLElement;
    private dialogName: string;
    public parentCompParams: any;

    public datainput: any;
    public closeDialog: Function;
    public parentCompPRMS: any;
    public coverageItem: any;

    public extraText: string = '';

    constructor(el: ElementRef) {
        this.el = el.nativeElement;
    }

    ngOnInit() {
        this.dialogName = this.datainput.dialogName;
        this.parentCompParams = this.datainput.params;

        this.coverageItem = this.datainput.coverageItem;

        this.extraText = (this.coverageItem.extraText) ? this.coverageItem.extraText : '';
    }

    private _closeDialog() {

        this.closeDialog({
            dialogName: this.dialogName,
            coverageItem: this.coverageItem,
            xtCommentsArr: '',
            isDialogCancelled: true
        },
            this.parentCompPRMS
        );
    }

    private _saveDialog() {

        this.coverageItem.extraText = this.extraText;

        this.closeDialog({
            dialogName: this.dialogName,
            coverageItem: this.coverageItem,
            isDialogCancelled: false
        },
            this.parentCompPRMS
        );
    }


    public formatText(event) {
        //VK013
        var value = event.target.value;
        var valid = true;
        var maxLineChars = 60;
        var result = "";
        var finalLines = [];
        var lines = value.split(/\r\n|\r|\n/g);
        var length = lines.length;
        var str1: String,str2: String,strn: String,temp_str: String;
        var x = false;
        
        for (var i = 0; i < length; i++) {
            if (lines[i].length > maxLineChars) {
                    strn = lines[i];
                        while( strn.length > maxLineChars ){
                        str1 = strn.substring(0, maxLineChars);
						str2 = strn.substring(maxLineChars);
						
						if( !str1.endsWith(" ") && !str2.startsWith(" ") && str1.lastIndexOf(" ") != -1) {
							
							str1 = str1.substring(0, str1.lastIndexOf(" "));
							temp_str = strn.substring(str1.length);
							if(temp_str.startsWith(" ")) {
								strn = strn.substring(str1.length+1);
							} else { 
								strn = temp_str;
							}
						}
						else {
							strn = str2;
                        }
                        finalLines[finalLines.length] = str1;
                    }
                    if(strn != "" && strn.length <= maxLineChars) {
                        finalLines[finalLines.length] = strn;
                    }
                } else {
                finalLines[finalLines.length] = lines[i];
            }
        }
        
        for (var i = 0; i < finalLines.length; i++) {
            result += finalLines[i];
            if (i + 1 < finalLines.length) {
                result += "\n";
            }
        }
        event.target.value = result;
        this.extraText = result;
    }

}