/* 
 *
 * Change History:		
 * 
 * No      Date				Description												Changed By
 * ====    ==========		===========												==========
 * 
 * E1003   19/12/2018		MYS-2017-1096 : New default clauses for MIS channel			SRE1
 * 
 * SR001   11/01/2019		MYS-2018-0211 : To enhancement the filtering criteria		VSR
 * 							for Fire Accum Code & Prompt message
 * 
 * SR002   18/01/2019		MYS-2018-0682 : HD Log: POI Date not passed correctly to	VSR
 * 							check as Referred Risk for Fire products in BMS
 * 
 *  YPK001 23/09/2019       MYS-2019-0675 Document Validation for Co-outwards            PKU1
 *                         case before sending to PPHO			
 * 
 * E1001  04/11/2019        MYS-2019-1280 : Incorrect Total Rate when user change rating 
 *                        flag from 'A' to 'M' for product type FC1 in BMS	             SRE1
 */

import { Component, ElementRef, EventEmitter, OnInit, ViewChild, ViewContainerRef } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CaseInfo } from '../../../../../common/components/appobjects/caseinfo';
import { ClientDetails } from '../../../../../common/components/client/appobjects/client';
import { FinancialInterest } from '../../../../../common/components/financialinterest/appobjects/financialInterest';
import { AlertMessage } from '../../../../../common/components/utility/alertmessage/alertmessages.model';
import { AlertMessagesService } from '../../../../../common/components/utility/alertmessage/alertmessages.service';
import { CordysSoapWService } from "../../../../../common/components/utility/cordys-soap-ws";
import { ModalInput } from "../../../../../common/components/utility/modal/modal";
import { SearchInput } from "../../../../../common/components/utility/search/genericsearch";
import { Filter, GetLOVData, SearchAdvancedConfig } from '../../../../../common/components/utility/search/search.requests';
import { ApplicationUtilService } from "../../../../../common/services/application.util.service";
import { CustomDCLService } from '../../../../../common/services/customdcl.service';
import { LOVDropDownService, LOV_Field, SearchFilter } from "../../../../../common/services/lovdropdown/lovdropdown.service";
import { BMSUtilService } from "../../../../services/bms.util.service";
import { BMSAppObjService } from '../../../../services/bmsappobj.service';
import { BMSConstants } from '../../../common/constants/bms_constants';
import { ProposalHeader } from '../../proposalheader/appobjects/proposalheader';
import { AccRegister } from '../appobjects/accregister';
import { Clause } from "../appobjects/clause";
import { FireRelatedCases } from '../appobjects/relatedCase';
import { Survey } from '../appobjects/survey';
import { RIService } from '../services/ri.service';
import { RiskClassificationService } from "../services/riskcls.service"; // added code for AccRegister
import { FireCoverageComponent } from '../uimodules/firecoverage.component';
import { PerilsComponent } from "../uimodules/perils.component";
import { RateableClausesComponent } from "../uimodules/rateableclause.component";
import { RelatedCaseComponent } from "../uimodules/relatedcase.component";
import { FEADetail, FireIDC } from './appobjects/fireIDC';
import { ClausesComponent } from '../uimodules/clauses.component';
import { AppUtil } from '../../../../../common/components/utility/apputil/app.util';

declare var jQuery: any;
declare var moment: any;
declare var numeral: any;

@Component({
    selector: 'fireidc-risk-component',
    templateUrl: 'app/bms/components/proposal/newbusinessrisks/fireidc/fireIDC.template.html',
    inputs: ['riskObj', 'clientDetails', "headerInfo"],
    outputs: ["onPremiumChange", "onRiskClsChange", "onRtngFlgChange"],
    providers: [RiskClassificationService]// added code for AccRegister
})

export class FireIDCRiskComponent implements OnInit {
    private el: HTMLElement;
    private isFEAInfo: boolean = false;
    private covInfoCollapse: boolean = false;
    private popInfoCollapse: boolean = false;
    private clCBIInfoCollapse: boolean = true;
    private surInfoCollapse: boolean = false;
    private relatedCollapse: boolean = false;
    private accRegisterInfoCollapse: boolean = false;
    // private basicPerilDetailsCollapse:boolean = false;
    public rateFormat: string = "0.00000";
    public thiscomp: any;
    public AccRegList: AccumulationRegister[];
    @ViewChild(ClausesComponent) private clausesComp: ClausesComponent;
    @ViewChild(PerilsComponent) private perilsComp: PerilsComponent;
    @ViewChild(FireCoverageComponent) coverComp: FireCoverageComponent;
    @ViewChild(RelatedCaseComponent) relatedComp: RelatedCaseComponent;
    @ViewChild(RateableClausesComponent) rateClauseComp: RateableClausesComponent;
    public riskObj: FireIDC;
    public clientDetails: ClientDetails;
    public headerInfo: ProposalHeader;
    onPremiumChange = new EventEmitter<any>();
    onRiskClsChange = new EventEmitter<any>();
    onRtngFlgChange = new EventEmitter<any>();
    public caseInfo: CaseInfo;
    public leastPreferredRI = ['D1E1', 'D1E2', 'D1E3', 'D2E1', 'D2E2', 'D2E3', 'D3E1', 'D3E2', 'D3E3'];
    public maxSIForSurvey = { "D1A1": "10000000", "D1A2": "10000000", "D1A3": "6000000", "D1B1": "10000000", "D1B2": "10000000", "D1B3": "6000000", "D1C1": "10000000", "D1C2": "10000000", "D1C3": "6000000", "D1D1": "10000000", "D1D2": "8000000", "D1D3": "6000000", "D1E1": "5000000", "D1E2": "5000000", "D1E3": "5000000" };
    public accRegCtrl: any;
    // private piamCodeRecords=[];
    private piamCodes = [];
    private townClassArr = [];
    private constructionClassArr = [];
    private riRetentionCodes = [];
    private cslTypesArr = [];
    private isUnderWriter = "N";
    private isRIMethodEditable = "Y";
    public isAssessment: boolean = false;
    public emailType: string;
    public tempSysReferred: boolean;
    public tempAccuSysReferred: boolean;
    private isGeneralPageCollapsed: boolean = false;
    private deductiblesTypesArr = []; // SAF MYS-2018-0666
    private excludedItemsArr = []; // SAF MYS-2018-0666
    public _defaultProductClauses = new Clause(); // E1003
    private productclauseCodes: string = ""; // E1003
    private dobCtrl: any;

    @ViewChild('fireIdcModal', { read: ViewContainerRef }) contentArea: ViewContainerRef;

    constructor(public dcl: CustomDCLService, private lovDropDownService: LOVDropDownService, private _soapService: CordysSoapWService, public _alertMsgService: AlertMessagesService, el: ElementRef, private _appUtilService: ApplicationUtilService, private _bmsUtilService: BMSUtilService, public riskClassificationService: RiskClassificationService, private _appObjService: BMSAppObjService, private _riService: RIService, private _activatedRoute: ActivatedRoute) {
        this.el = el.nativeElement;
    }

    ngOnInit() {
        this.thiscomp = this;
        this._defaultProductClauses.clause = this.riskObj.clauses.clause.filter( ( item ) => item.isDefaultClause == "N" );//E1003
        this.populateLOVs();

        this._appUtilService.isUnderWriterUser().subscribe((data) => {
            this.isUnderWriter = data;
            this.setRIMethodEditableFlag();
        });
        this.handleReAssessment();

        // AccRegister code
        if (this.riskObj.accRegister == undefined) {
            this.riskObj.accRegister = new AccRegister();
        } else {
            this.tempSysReferred = this.riskObj.accRegister.isSystemReferred;
            this.tempAccuSysReferred = this.riskObj.accRegister.isAccuSystemReferredFlag;
        }

        // SAF MYS-2018-0666 --start
        this.findFEADetailsDisableInfo();
        if (!this.headerInfo.disableFEAInfo)
            this.validateFEAClauses();
        this.headerInfo.disableFEAInfo = (this.headerInfo.disableFEAInfo.toString() == "" || this.headerInfo.disableFEAInfo == undefined) ? true : this.headerInfo.disableFEAInfo;
        this.headerInfo.disableDDInfo = (this.headerInfo.disableDDInfo.toString() == "" || this.headerInfo.disableDDInfo == undefined) ? true : this.headerInfo.disableDDInfo;
        //get Deductables Live date since its handled in findFEADetailsDisableInfo service.
        //this.findDeductablesDisableInfo();
        //End

        //SST Code
        if (["MyTasks", "MyDrafts"].indexOf(this._activatedRoute.snapshot.params['component']) >= 0 || Object.keys(this._activatedRoute.snapshot.params).length == 0) {
            let respObj = this._bmsUtilService.getTAXDetails();
            if (respObj != undefined && respObj != "") {
                this.headerInfo.SSTTaxRate = Number(respObj[0].old.ITEMPF.GST);
                this.headerInfo.GSTTaxRate = Number(respObj[1].old.ITEMPF.GST);

                this.riskObj.SST = Number(this.headerInfo.SSTTaxRate);
                this.riskObj.GST = Number(this.headerInfo.GSTTaxRate);
            }
            if (isNaN(parseInt(this.riskObj.postCode))) {
                this.riskObj.SST = Number(0);
                this.headerInfo.SSTTaxRate = this.riskObj.SST;
            }

            this.headerInfo = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo;
            this.riskObj.SSTLiveDate = (this.riskObj.SSTLiveDate == undefined) ? this.headerInfo.SSTLiveDate : this.riskObj.SSTLiveDate;
            if (this.riskObj.SSTLiveDate == undefined || this.riskObj.SSTLiveDate == "") {
                let tempRespObj = this._bmsUtilService.getLiveDate();
                this.riskObj.GSTLiveDate = tempRespObj[0].old.ITEMPF.LIVEDATE;
                this.riskObj.SSTLiveDate = tempRespObj[1].old.ITEMPF.LIVEDATE;
                if (this.headerInfo.SSTLiveDate == undefined || this.headerInfo.SSTLiveDate == "") {
                    this.headerInfo.SSTLiveDate = this.riskObj.SSTLiveDate;
                }
                if (this.headerInfo.GSTLiveDate == undefined || this.headerInfo.GSTLiveDate == "") {
                    this.headerInfo.GSTLiveDate = this.riskObj.GSTLiveDate;
                }
            }
            if (moment(this.headerInfo.effectiveDate, "YYYY-MM-DD").format("YYYYMMDD") >= moment(this.riskObj.SSTLiveDate, "YYYY-MM-DD").format("YYYYMMDD")) {
                this.riskObj.isGSTApplicable = false;
            } else {
                this.riskObj.isGSTApplicable = true;
            }

            this.riskObj.isValidBenefitProduct = this.checkProductIsLiveorValid();//SAF MYS-2019-0909
        }
        //End
    }

    /* ngAfterViewInit (){
        this.setBasicRate();
    } */
    //START YPK001
    ngAfterViewInit() {
        let rIndex = 0;
        if ((this.headerInfo.CoInsurance == 'Y' && this.riskObj.riskNumber == '1') && (["MyTasks", "MyDrafts"].indexOf(this._activatedRoute.snapshot.params['component']) >= 0 || Object.keys(this._activatedRoute.snapshot.params).length == 0)) {
            if (this.headerInfo.coInsuranceDetails.coInsurance.length == 1) {
                if (!(this.headerInfo.coInsuranceDetails.coInsurance[0].coInsuranceindicator == 'L' && this.headerInfo.coInsuranceDetails.coInsurance[0].sharePercentage == '100')) {
                    rIndex = this.riskObj.clauses.clause.map(function (item) { return item.clauseCode; }).indexOf("COIN");
                    if (rIndex == -1)
                        this.setClauses(["COIN"], false);
                }
            }
            else {
                rIndex = this.riskObj.clauses.clause.map(function (item) { return item.clauseCode; }).indexOf("COIN");
                if (rIndex == -1)
                    this.setClauses(["COIN"], false);
            }
        }
    }
    setClauses(clausesList, flag) {
        if (this.clausesComp)
            this.clausesComp.addClause(clausesList, '', flag);
    }
    //END YPK001

    handleReAssessment() {
        if ((BMSConstants.getBMSObj().ApplicationBusinessObject.caseInfo.businessFunction != 'NewBusiness' && BMSConstants.getBMSObj().ApplicationBusinessObject.caseInfo.businessFunction != 'CoverNote')) {
            if (BMSConstants.getBMSObj().ApplicationBusinessObject.caseInfo.status == 'Rerate Reviewed' || BMSConstants.getBMSObj().ApplicationBusinessObject.caseInfo.status == 'Draft' || BMSConstants.getBMSObj().ApplicationBusinessObject.caseInfo.status == 'Assessment')
                this.isAssessment = true;
        } else {
            this.isAssessment = true;
        }
    }
    // Added for new default class setup E1003
    getProductClauseCodes(key: string) {
        let prom = this._soapService.callCordysSoapService("GetMsigPropertiesObject", "http://schemas.cordys.com/msig/masterdata/1.0", { "KEY": key }, null, null, false, null);
        prom.success((resp) => {
            this.productclauseCodes = resp.tuple.old.MSIG_PROPERTIES.VALUE.toString();
        });
        prom.error((error) => {
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error while fetching Default Clauses.", -1));
        });
    }
    // End E1003
    populateLOVs() {
        // Added for new default class setup E1003
        if (this.headerInfo.bancaChannel == 'FI' && (this.caseInfo.status == 'Draft' || Object.keys(this._activatedRoute.snapshot.params).length == 0)) {
            if (this._defaultProductClauses.clause.length == 0 && this.riskObj.clauses.clause.length == 0) {
                if (this.headerInfo.contractType.startsWith('FC') || this.headerInfo.contractType.startsWith('FF') || this.headerInfo.contractType == 'FD1') {
                    this.getProductClauseCodes("fcOrffOrfd1DefaultClauses");
                }
                else if (["FD2", "FD3"].indexOf(this.headerInfo.contractType) >= 0) {
                    this.getProductClauseCodes("fdDefaultClauses");
                }
                if (this.productclauseCodes != null && this.productclauseCodes != "") {
                    this.getNewDefaultClauses(this.productclauseCodes);
                }
            }

        }
        // End E1003
        this.lovDropDownService.createLOVDataList(["piamcode", "construction", "rateBasis", "constructionYearList", "sprinkler", "premiumclass", "riCode", "cslTypes", "piamCodesList", "deductiblesList"]);//SAF MYS-2018-0666 added "deductiblesList" in array.
        // this.lovDropDownService.createLOVDataList(["rateBasis", "constructionYearList", "sprinkler", "premiumclass","riCode","cslTypes","piamCodesList"]);

        let riTypeFilterDetails = [new SearchFilter("DESCITEM", this.riskObj.riskType, "STARTSWITH", "AND")];
        let riTypeSearchFilterNodes = this.lovDropDownService.createFilter(riTypeFilterDetails);

        let polEndDate = ApplicationUtilService.getFormattedDate(this.headerInfo.endDate, "YYYY-MM-DD", "YYYYMMDD");
        let piamCodesFilterDetails = [new SearchFilter("A.DESCITEM", this.riskObj.riskType, "STARTSWITH", "AND"),
        new SearchFilter("A.ITMFRM", polEndDate, "LTEQ", "AND"),
        new SearchFilter("A.ITMTO", polEndDate, "GTEQ", "AND")];
        let piamCodesFilterNodes = this.lovDropDownService.createFilter(piamCodesFilterDetails);

        let lovFields = [
            new LOV_Field("ALL", "FIRE", "NEW BUSINESS", "ALL", "ALL", "ALL", "PIAM Codes List", "LOV", piamCodesFilterNodes, "T9115", "piamCodesList", "callbackForPIAMCodesList"),
            new LOV_Field("ALL", "FIRE", "NEW BUSINESS", "ALL", "NEW", "FIRE_IDC", "RateBasis", "LOV", [], "DESCPF", "rateBasis", "rateBasisCallback"),
            new LOV_Field("ALL", "FIRE", "NEW BUSINESS", "ALL", "NEW", "FIRE", "YearOfConst", "LOV", [], "DESCPF", "constructionYearList", null),
            new LOV_Field("ALL", "FIRE", "NEW BUSINESS", "ALL", "NEW", "FIRE_IDC", "Sprinkler", "LOV", [], "DESCPF", "sprinkler", null),
            new LOV_Field("ALL", "FIRE", "NEW BUSINESS", "ALL", "NEW", "FIRE_IDC", "PremiumClass", "LOV", riTypeSearchFilterNodes, "T4688", "premiumclass", null),
            new LOV_Field("ALL", "MOTOR", "NEW BUSINESS", "ALL", "NEW", "PRIVATE_MOTOR", "RI Retention Code", "LOV", [], "DESCPF", "riCode", null)];
        // new LOV_Field("ALL", "ALL", "ALL", "ALL", "ALL", "ALL", "PIAM Code", "LOOKUP", [] , "DESCPF", "piamcode","callbackPIAMCodesLoad"),
        // new LOV_Field("ALL", "FIRE", "CLAIMS", "ALL", "NEW", "CLAIMS_FIRE", "Construction Code", "LOV", [], "DESCPF", "construction","callbackConstructionLoad"),

        if (this.riskObj.riskType != 'ECP' && this.riskObj.riskType != 'PP1' && this.riskObj.riskType != 'ARI') {
            lovFields.push(new LOV_Field("ALL", "ALL", "ALL", "ALL", "ALL", "ALL", "PIAM Code", "LOOKUP", [], "DESCPF", "piamcode", null));
            lovFields.push(new LOV_Field("ALL", "FIRE", "CLAIMS", "ALL", "NEW", "CLAIMS_FIRE", "Construction Code", "LOV", [], "DESCPF", "construction", null));
        }
        if (this.riskObj.riskType == 'ARI') {
            let cslTypeFilterDetails = [new SearchFilter("A.DESCITEM", this.riskObj.riskType, "STARTSWITH", "AND")];
            let cslTypeFilterNodes = this.lovDropDownService.createFilter(cslTypeFilterDetails);

            lovFields.push(new LOV_Field("ALL", "FIR", "NEW BUSINESS", "ALL", "ALL", "ALL", "CSL Types", "LOV", cslTypeFilterNodes, "DESCPF", "cslTypes", "callbackCSLTypes"));
        }
        if (this.riskObj.accumulationRegister != null && this.riskObj.accumulationRegister != "") {
            this.setAccumulationRegister();
        }

        // SAF MYS-2018-0666 -start
        lovFields.push(new LOV_Field("ALL", "FIRE", "NEW BUSINESS", "ALL", "NEW", "FIRE", "DEDUCTIBLES_LIST", "LOV", [], "T9175", "deductiblesList", "callbackDeductiblesList")); // End

        this.lovDropDownService.util_populateLOV(lovFields, this);

        if ((this.riskObj.riskType == 'ECP' || this.riskObj.riskType == 'ARI') && this.riskObj.FEA.FEAeq.length == 0) {
            let request: GetLOVData = new GetLOVData();
            request.BRANCH = 'ALL';
            request.LOB = 'PA';
            request.BUSINESS_FUNCTION = 'NEW BUSINESS';
            request.PRODUCT = 'ALL';
            request.OPERATION = 'ALL';
            request.FORM_NAME = 'ALL';
            request.FORM_FIELD_NAME = 'FEA Details';
            request.FIELD_TYPE = 'LOV';
            request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
            request.ADVANCE_CONFIG_XML.FILTERS = new Filter();
            this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.feaDeatilsSuccessHandler, this.handleError, true, { comp: this });
        }

    }

    feaDeatilsSuccessHandler(response, prms) {
        if (response.tuple) {
            for (let _tuple of response.tuple) {
                if (_tuple.old.DESCPF.VALUE == "0") {
                    let _feaeq = new FEADetail();
                    _feaeq.code = _tuple.old.DESCPF.VALUE;
                    _feaeq.description = _tuple.old.DESCPF.DESCRIPTION;
                    prms.comp.riskObj.FEA.FEAeq.push(_feaeq);
                    break;
                }
            }
        }
    }

    callbackForPIAMCodesList(scopeObject) {
        for (let _rec of scopeObject.lovDropDownService.lovDataList.piamCodesList) {
            let hasPiamCode = scopeObject.piamCodes.some(_item => _item.VALUE === _rec.VALUE);
            if (!hasPiamCode) {
                scopeObject.piamCodes.push(_rec);
            }
        }

        if (scopeObject.piamCodes.length > 0) {
            scopeObject.sortArray(scopeObject.piamCodes, 'VALUE');
        }

        if (this.riskObj.PIAMCode) {
            scopeObject.populateConstructionClass(false);
        }
        // scopeObject.populateTownClass(false);
    }

    callbackPIAMCodesLoad(scopeObject) {
        let filteredPIAMCodesList = [];
        if (scopeObject.riskObj.riskType == "ECP") {
            for (let item of scopeObject.lovDropDownService.lovDataList.piamcode) {
                if (item.VALUE == '5002' || item.VALUE == '5004' || item.VALUE == '5006') {
                    filteredPIAMCodesList.push(item);
                }
            }
        }
        else if (scopeObject.riskObj.riskType == "PP1") {

            for (let item of scopeObject.lovDropDownService.lovDataList.piamcode) {
                if (item.VALUE == '1001' || item.VALUE == '1008') {
                    filteredPIAMCodesList.push(item);
                }
            }
        }
        if (filteredPIAMCodesList.length > 0) {
            scopeObject.lovDropDownService.lovDataList.piamcode = filteredPIAMCodesList;
        }
    }

    callbackConstructionLoad(scopeObject) {
        let filteredConstructionCodesList = [];
        if (scopeObject.riskObj.riskType == "PP1") {
            for (let item of scopeObject.lovDropDownService.lovDataList.construction) {
                if (item.VALUE == '1A' || item.VALUE == '1B' || item.VALUE == '2' || item.VALUE == '3') {
                    filteredConstructionCodesList.push(item);
                }
            }
        }
        if (filteredConstructionCodesList.length > 0) {
            scopeObject.lovDropDownService.lovDataList.construction = filteredConstructionCodesList;
        }
    }

    callbackCSLTypes(scopeObject) {
        for (let _rec of scopeObject.lovDropDownService.lovDataList.cslTypes) {
            let hasCSLCode = scopeObject.cslTypesArr.some(_item => _item.CSLTYPE === _rec.CSLTYPE);
            if (!hasCSLCode) {
                scopeObject.cslTypesArr.push(_rec);
            }
        }
    }

    setAccReg(values) {
        this.riskObj.locality = values.record.locality;
        if (this.riskObj.addRelatedCases == "Y" && this.riskObj.relatedCases.relatedCases.relatedCase.length > 0) {
            this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Related cases are removed as accumulation register is changed.", -1));
        }
        if (this.relatedComp != null) {
            this.relatedComp.setAccumulationRegister(values.value);
        }
        // added code for AccRegister - start
        if (values.value == "0") {
            this.riskObj.locality = "0";
            this.tempSysReferred = this.riskObj.accRegister.isSystemReferred;
            this.tempAccuSysReferred = this.riskObj.accRegister.isAccuSystemReferredFlag;
            this.riskObj.accRegister = new AccRegister();
            this.riskObj.accRegister.isSystemReferred = this.tempSysReferred;
            this.riskObj.accRegister.isAccuSystemReferredFlag = this.tempAccuSysReferred;
            this.setReferredRiskFlag(false, "Standard", false);
            this.emailType = "1";
            let inputObj = {
                "Message": "No accumulation register for the selected postal code, Do you want to send Email to RI Treaty ?",
                "Action": ""
            };
            let input = inputObj;
            let lookup = new ModalInput().get("Confirm");
            lookup.datainput = input;
            lookup.outputCallback = this.openConfirmPopUpCallBack;
            lookup.parentCompPRMS = { comp: this };
            lookup.heading = "Confirm Send Email to RI Treaty";
            lookup.icon = "fa fa-hand-paper-o";
            lookup.containerRef = this.contentArea;
            this.dcl.openLookup(lookup);
        } else if (values.value != "" && values.value != "0") {
            this._appObjService.saveData().subscribe((data) => {
                this.callAccRegisterFunction();
            });
        }

    }

    // AccRegister code -- start
    private openConfirmPopUpCallBack(data, prms) {
        if (data.value == 'Y') {

			/*if(prms.comp.caseInfo.caseId == "" || prms.comp.caseInfo.caseId == undefined){
				prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Please Save the case before sending an Email for Accumulation Register Creation." ,8000));
				return;
			} */
            prms.comp._appObjService.saveData().subscribe((data) => {
                prms.comp.riskClassificationService.sendMailtoTreaty(prms.comp.riskObj, prms.comp.caseInfo.caseId, prms.comp.emailType);
            });
        }
    }

    private callAccRegisterFunction() {
        this._soapService.callCordysSoapService("GetCurrentExposerAccuRegister", "http://schemas.insurance.com/businessobject/1.0/",
            {
                "caseID": this.caseInfo.caseId,
                "snedmail": "",
                "AccumulationReg": this.riskObj.accumulationRegister,
                "PostCode": this.riskObj.postCode,
                "LocationCode": this.riskObj.locality,
                "TotalSI": this.riskObj.totalSI,
                "Branch": BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.servicingBranch,
                "cslAmount": this.riskObj.cslAmount,
                "city": this.riskObj.city
            },
            this.setAccRegisterInfoSuccess, this.setAccRegisterInfoError, true, { comp: this });
    }

    setAccRegisterInfoSuccess(response, prms) {
        if (!response.fault) {
            prms.comp.riskObj.accRegister.ExposerQuotAccepted = response.ExposerQuotAccepted.text;
            prms.comp.riskObj.accRegister.HoldCoverExposer = response.HoldCoverExposer.text;
            prms.comp.riskObj.accRegister.GAL = response.GAL.text;
            prms.comp.riskObj.accRegister.P400InforcedExposer = response.P400InforcedExposer.text;
            prms.comp.riskObj.accRegister.TotalExposer = response.TotalExposer.text;
            prms.comp.riskObj.accRegister.Outstanding = response.Outstanding.text;
            prms.comp.riskObj.accRegister.cessionOutwords = response.cessionOutwords.text;
            prms.comp.riskObj.accRegister.totalPercentage = (Number(response.TotalExposer.text) * 100) / Number(response.GAL.text);

            prms.comp.riskObj.accRegister.TOTGR = response.TOTGR.text
            prms.comp.riskObj.accRegister.TOTMNR = response.TOTMNR.text
            prms.comp.riskObj.accRegister.TOTFAC = response.TOTFAC.text
            prms.comp.riskObj.accRegister.TOTTREATY = response.TOTTREATY.text
            prms.comp.riskObj.accRegister.LIMITMNR = response.LIMITMNR.text
            prms.comp.riskObj.accRegister.LIMITFAC = response.LIMITFAC.text
            prms.comp.riskObj.accRegister.LIMITTREATY = response.LIMITTREATY.text
            prms.comp.riskObj.accRegister.LIMITNET = response.LIMITNET.text
            if (prms.comp.riskObj.accRegister.totalPercentage < 0) {
                prms.comp.riskObj.accRegister.totalPercentage = -(Number(prms.comp.riskObj.accRegister.totalPercentage));
            }

            prms.comp.riskObj.accRegister.cessionOutwordsPercentage = (Number(response.cessionOutwords.text) * 100) / Number(response.Outstanding.text);
            if (prms.comp.riskObj.accRegister.cessionOutwordsPercentage < 0) {
                prms.comp.riskObj.accRegister.cessionOutwordsPercentage = -(Number(prms.comp.riskObj.accRegister.cessionOutwordsPercentage));
            }

            // formatted values
            prms.comp.riskObj.accRegister.formattedExposerQuotAccepted = numeral(prms.comp.riskObj.accRegister.ExposerQuotAccepted).format("0,0");
            prms.comp.riskObj.accRegister.formattedHoldCoverExposer = numeral(prms.comp.riskObj.accRegister.HoldCoverExposer).format("0,0");
            prms.comp.riskObj.accRegister.formattedGAL = numeral(prms.comp.riskObj.accRegister.GAL).format("0,0");
            prms.comp.riskObj.accRegister.formattedP400InforcedExposer = numeral(prms.comp.riskObj.accRegister.P400InforcedExposer).format("0,0");
            prms.comp.riskObj.accRegister.formattedTotalExposer = numeral(prms.comp.riskObj.accRegister.TotalExposer).format("0,0");
            prms.comp.riskObj.accRegister.formattedOutstanding = numeral(prms.comp.riskObj.accRegister.Outstanding).format("0,0");
            prms.comp.riskObj.accRegister.formattedcessionOutwords = numeral(prms.comp.riskObj.accRegister.cessionOutwords).format("0,0");
            prms.comp.riskObj.accRegister.formattedGALPercentage = isNaN(prms.comp.riskObj.accRegister.totalPercentage) ? numeral(0).format("00.00") : numeral(prms.comp.riskObj.accRegister.totalPercentage).format("00.00");
            prms.comp.riskObj.accRegister.formattedcessionOutPercentage = isNaN(prms.comp.riskObj.accRegister.cessionOutwordsPercentage) ? numeral(0).format("00.00") : numeral(prms.comp.riskObj.accRegister.cessionOutwordsPercentage).format("00.00");

            prms.comp.riskObj.accRegister.formattedtotGR = numeral(prms.comp.riskObj.accRegister.TOTGR).format("0,0");
            prms.comp.riskObj.accRegister.formattedtotMNR = numeral(prms.comp.riskObj.accRegister.TOTMNR).format("0,0");
            prms.comp.riskObj.accRegister.formattedtotFAC = numeral(prms.comp.riskObj.accRegister.TOTFAC).format("0,0");
            prms.comp.riskObj.accRegister.formattedtotTREATY = numeral(prms.comp.riskObj.accRegister.TOTTREATY).format("0,0");
            prms.comp.riskObj.accRegister.formattedLimitMNR = numeral(prms.comp.riskObj.accRegister.LIMITMNR).format("0,0");
            prms.comp.riskObj.accRegister.formattedLimitFAC = numeral(prms.comp.riskObj.accRegister.LIMITFAC).format("0,0");
            prms.comp.riskObj.accRegister.formattedLimitTREATY = numeral(prms.comp.riskObj.accRegister.LIMITTREATY).format("0,0");
            prms.comp.riskObj.accRegister.formattedLimitNet = numeral(prms.comp.riskObj.accRegister.LIMITNET).format("0,0");

            prms.comp.accRegisterValidations();

        } else {
            prms.comp.tempSysReferred = prms.comp.riskObj.accRegister.isSystemReferred;
            prms.comp.tempAccuSysReferred = prms.comp.riskObj.accRegister.isAccuSystemReferredFlag;
            prms.comp.riskObj.accRegister = new AccRegister();
            prms.comp.riskObj.accRegister.isSystemReferred = prms.comp.tempSysReferred;
            prms.comp.riskObj.accRegister.isAccuSystemReferredFlag = prms.comp.tempAccuSysReferred;

            prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error while Calling Accumulation Register service.", 8000));
        }
    }

    setAccRegisterInfoError(response, status, errorText, prms) {
        prms.comp.tempSysReferred = prms.comp.riskObj.accRegister.isSystemReferred;
        prms.comp.tempAccuSysReferred = prms.comp.riskObj.accRegister.isAccuSystemReferredFlag;
        prms.comp.riskObj.accRegister = new AccRegister();
        prms.comp.riskObj.accRegister.isSystemReferred = prms.comp.tempSysReferred;
        prms.comp.riskObj.accRegister.isAccuSystemReferredFlag = prms.comp.tempAccuSysReferred;

        prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error while Calling Accumulation Register service.", 8000));
    }

    accRegisterValidations() {
        this.riskObj.accRegister.totalPercentage = 0;
        if (this.riskObj.accRegister.GAL != "0" && this.riskObj.accRegister.GAL != "") {
            this.riskObj.accRegister.totalPercentage = (Number(this.riskObj.accRegister.TotalExposer) * 100) / Number(this.riskObj.accRegister.GAL);

            if (this.riskObj.accRegister.totalPercentage >= 90 && this.riskObj.accRegister.totalPercentage <= 100) {
                if (BMSConstants.getBMSObj().ApplicationBusinessObject.caseInfo.status != "Draft") {
                    this.emailType = "2";
                    this.setReferredRiskFlag(false, "Standard", false);
                    let inputObj = {
                        "Message": "Total exposure percentage is more than 90 % against GAL, Do you want to send email to under writer?",
                        "Action": ""
                    };
                    let input = inputObj;
                    let lookup = new ModalInput().get("Confirm");
                    lookup.datainput = input;
                    lookup.outputCallback = this.openConfirmPopUpCallBack;
                    lookup.parentCompPRMS = { comp: this };
                    lookup.heading = "Confirm Send Email to Underwriter";
                    lookup.icon = "fa fa-hand-paper-o";
                    lookup.containerRef = this.contentArea;
                    this.dcl.openLookup(lookup);
                }
            } else if (this.riskObj.accRegister.totalPercentage > 100) {
                this.setReferredRiskFlag(true, "Referred", true);
                this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Total Exposure percentage is more than 100 % against GAL and Risk has been changed to Referred.", 8000));
            } else {
                if ((this.riskObj.accRegister.isSystemReferred == false) && (this.riskObj.accRegister.isAccuSystemReferredFlag == true)) {
                    this.setReferredRiskFlag(true, "Referred", true);
                } else {
                    this.setReferredRiskFlag(false, "Standard", false);
                }
            }
        } else {
            this.setReferredRiskFlag(false, "Standard", false);
        }
    }

    private setReferredRiskFlag(referredFlag, riskClassification, defaultFlag) {
        let refRiskUIFlag = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.isReferredRiskUI;
        if ((refRiskUIFlag == true || this.riskObj.accRegister.isSystemReferred == true) && (this.riskObj.accRegister.isAccuSystemReferredFlag == false)) {
            this.riskObj.accRegister.isSystemReferred = true;
            this.riskObj.accRegister.isAccuSystemReferredFlag = false;
            if (this.riskObj.accRegister.totalPercentage > 100)
                BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.isReferredToUW = 'Y'
            else
                BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.isReferredToUW = 'N'


        } else {
            this.riskObj.accRegister.isSystemReferred = false;
            this.riskObj.accRegister.isAccuSystemReferredFlag = defaultFlag;
            this.riskObj.symRiskClassification = riskClassification;
            BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.isReferredRiskUI = referredFlag;
            if (defaultFlag)
                BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.isReferredToUW = 'Y'
            else
                BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.isReferredToUW = 'N'

            this.handleRiskClassification(this);
        }
    }   // AccRegister code -- End

    getPostCodeInfo(postcode) {
        this.riskObj.postCode = isNaN(parseInt(postcode)) ? postcode.toUpperCase() : postcode;
        // Accumulation register code --start
        this.tempSysReferred = this.riskObj.accRegister.isSystemReferred;
        this.tempAccuSysReferred = this.riskObj.accRegister.isAccuSystemReferredFlag;
        this.riskObj.accRegister = new AccRegister();
        this.riskObj.accRegister.isSystemReferred = this.tempSysReferred;
        this.riskObj.accRegister.isAccuSystemReferredFlag = this.tempAccuSysReferred;

        this.setReferredRiskFlag(false, "Standard", false); // End

        let request: GetLOVData = new GetLOVData().getRequest('ALL', 'FIRE', 'NEW BUSINESS', 'ALL', 'NEW', 'FIRE_IDC', 'PostCode', 'LOV');
        request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        request.ADVANCE_CONFIG_XML.FILTERS = new Filter();

        request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({ "@FIELD_NAME": 'DESCITEM', "@FIELD_VALUE": this.riskObj.postCode, '@OPERATION': 'EQ', '@CONDITION': 'AND' });
        this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.setPostCodeInfo, this.handleError, true, { comp: this, postCode: this.riskObj.postCode });

    }

    setPostCodeInfo(response, prms) {
        if (response.tuple != null) {
            prms.comp.riskObj.city = response.tuple.old.DESCPF.SHORTDESC;
            prms.comp.riskObj.cityName = response.tuple.old.DESCPF.LONGDESC;
            prms.comp.setAccRegInfo();
            prms.comp.setGSTInfo();
        }
        else {
            prms.comp.riskObj.city = "";
            prms.comp.riskObj.cityName = "";
            prms.comp.clearAccReg();
        }
    }

    setAccRegInfo() {
        this.clearAccReg();
        this.setAccumulationRegister();
    }

    clearAccReg() {
        this.riskObj.accumulationRegister = "";
        this.AccRegList = [];
        if (this.accRegCtrl != null) {
            this.accRegCtrl.setter("", this.accRegCtrl.comp);
        }
        this.setAccReg({ record: { locality: "" }, value: "" });
    }

    setGSTInfo() {
        this.setGST(this.riskObj.postCode);
    }

    setGST(postCode) {
        if (isNaN(parseInt(postCode))) {
            this.riskObj.GSTDetails.riskLocation = "OS";
            this.riskObj.GST = Number(this.headerInfo.GSTTaxRate); //0;//6; //SAF MYS-2018-0629
            this.riskObj.SST = Number(0);//Number(this.headerInfo.SSTTaxRate); // SST code
            this.headerInfo.SSTTaxRate = this.riskObj.SST//SST Code
            this.resetCoverTotal();
        }
        else {
            if (this.riskObj.GST == 0 || this.riskObj.SST == 0) {
                let respObj = this._bmsUtilService.getTAXDetails();
                if (respObj != undefined && respObj != "") {
                    this.headerInfo.SSTTaxRate = Number(respObj[0].old.ITEMPF.GST);
                    this.headerInfo.GSTTaxRate = Number(respObj[1].old.ITEMPF.GST);

                    this.riskObj.SST = Number(this.headerInfo.SSTTaxRate);
                    this.riskObj.GST = Number(this.headerInfo.GSTTaxRate);
                }
            }//SST Code
            this.validateGSTForPCA(postCode);
        }
    }

    validateGSTForPCA(postCode) {
        let request: GetLOVData = new GetLOVData();
        request.BRANCH = 'ALL';
        request.LOB = 'ALL';
        request.BUSINESS_FUNCTION = 'ALL';
        request.PRODUCT = 'ALL';
        request.OPERATION = 'ALL';
        request.FORM_NAME = 'GST';
        request.FORM_FIELD_NAME = 'GST_PCA_POSTCODE';
        request.FIELD_TYPE = 'LOV';
        request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        request.ADVANCE_CONFIG_XML.FILTERS = new Filter();

        request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({ "@FIELD_NAME": 'DESCITEM', "@FIELD_VALUE": postCode, '@OPERATION': 'EQ', '@CONDITION': 'AND' });
        this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.setISPCA, this.handleError, true, { comp: this, postCode: postCode });
    }

    setISPCA(response, prms) {
        if (response.tuple != null && response.tuple.old.DESCPF.SHORTDESC != "LLB") {
            prms.comp.riskObj.GSTDetails.riskLocation = "PCA";
            prms.comp.riskObj.GST = Number(prms.comp.headerInfo.GSTTaxRate); //0;// 6; //SAF MYS-2018-0629
            prms.comp.riskObj.SST = Number(prms.comp.headerInfo.SSTTaxRate); // SST code
            if (prms.comp.riskObj.GST == 0 || prms.comp.riskObj.SST == 0) {
                let respObj = prms.comp._bmsUtilService.getTAXDetails();
                if (respObj != undefined && respObj != "") {
                    prms.comp.headerInfo.SSTTaxRate = Number(respObj[0].old.ITEMPF.GST);
                    prms.comp.headerInfo.GSTTaxRate = Number(respObj[1].old.ITEMPF.GST);

                    prms.comp.riskObj.SST = Number(prms.comp.headerInfo.SSTTaxRate);
                    prms.comp.riskObj.GST = Number(prms.comp.headerInfo.GSTTaxRate);
                }
            }

            prms.comp.resetCoverTotal();
        }// Adding below code for SAF MYS-2017-0846 -- start
        else if (response.tuple != null && response.tuple.old.DESCPF.SHORTDESC == "LLB") {
            prms.comp.riskObj.GSTDetails.riskLocation = "DA";
            prms.comp.riskObj.GST = 0;
            prms.comp.riskObj.SST = Number(0);//SST Code
            prms.comp.headerInfo.SSTTaxRate = Number(prms.comp.riskObj.SST);//SST Code
            prms.comp.headerInfo.GSTTaxRate = Number(prms.comp.riskObj.GST);//SST Code
            prms.comp.resetCoverTotal();
        } // End
        else {
            prms.comp.validateGSTForDA(prms.postCode, prms.comp)
        }
    }

    validateGSTForDA(postCode, comp) {
        let request: GetLOVData = new GetLOVData();
        request.BRANCH = 'ALL';
        request.LOB = 'ALL';
        request.BUSINESS_FUNCTION = 'ALL';
        request.PRODUCT = 'ALL';
        request.OPERATION = 'ALL';
        request.FORM_NAME = 'GST';
        request.FORM_FIELD_NAME = 'GST_DA_POSTCODE';
        request.FIELD_TYPE = 'LOV';
        request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        comp._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, comp.setISDA, comp.handleError, true, { comp: comp, postCode: postCode });
    }

    setISDA(response, prms) {
        if (response.tuple != null) {
            let postCodes = response.tuple.old.ITEMPF.POSTCODES;
            let postCodesList = postCodes.split(",");
            let hasPostCode = false;
            let isSameCode = false;
            for (let pCode of postCodesList) {
                // if (!isNaN(parseInt(pCode))) // SAF MYS-2017-0846
                if (pCode != undefined && pCode != "") {
                    hasPostCode = true;
                    if (pCode == prms.postCode) {
                        isSameCode = true;
                    }
                }
            }

            if (hasPostCode == false || isSameCode == true) {
                prms.comp.riskObj.GSTDetails.riskLocation = "DA";
                prms.comp.riskObj.GST = 0;
                prms.comp.riskObj.SST = Number(0);//SST Code
                prms.comp.headerInfo.SSTTaxRate = prms.comp.riskObj.SST//SST Code
                prms.comp.headerInfo.GSTTaxRate = prms.comp.riskObj.GST;//SST Code
                prms.comp.resetCoverTotal();
            }
            else {
                prms.comp.riskObj.GSTDetails.riskLocation = "PCA";
                prms.comp.riskObj.GST = Number(prms.comp.headerInfo.GSTTaxRate); //0;// 6; //SAF MYS-2018-0629
                prms.comp.riskObj.SST = Number(prms.comp.headerInfo.SSTTaxRate); // SST code
                if (prms.comp.riskObj.GST == 0 || prms.comp.riskObj.SST == 0) {
                    let respObj = prms.comp._bmsUtilService.getTAXDetails();
                    if (respObj != undefined && respObj != "") {
                        prms.comp.headerInfo.SSTTaxRate = Number(respObj[0].old.ITEMPF.GST);
                        prms.comp.headerInfo.GSTTaxRate = Number(respObj[1].old.ITEMPF.GST);

                        prms.comp.riskObj.SST = Number(prms.comp.headerInfo.SSTTaxRate);
                        prms.comp.riskObj.GST = Number(prms.comp.headerInfo.GSTTaxRate);
                    }
                }
                prms.comp.resetCoverTotal();
            }
        }
    }

    resetCoverTotal() {
        if (this.coverComp != null) {
            this.coverComp.resetTotal();
        }
    }

    setAccumulationRegister() {
		/* let request: GetLOVData = new GetLOVData();
        request.BRANCH = 'ALL';
        request.LOB = 'FIRE';
        request.BUSINESS_FUNCTION = 'NEW BUSINESS';
        request.PRODUCT = 'ALL';
        request.OPERATION = 'NEW';
        request.FORM_NAME = 'FIRE_IDC';
        request.FORM_FIELD_NAME = 'ACCREG';
        request.FIELD_TYPE = 'LOV';
        request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        request.ADVANCE_CONFIG_XML.FILTERS = new Filter();

        request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push(
            { "@FIELD_NAME": 'ZTOWNCODE', "@FIELD_VALUE": this.riskObj.city, '@OPERATION': 'EQ', '@CONDITION': 'AND' },
            { "@FIELD_NAME": 'PCODE', "@FIELD_VALUE": this.riskObj.postCode, '@OPERATION': 'EQ', '@CONDITION': 'AND' },
            { "@FIELD_NAME": '', "@FIELD_VALUE": '', '@OPERATION': 'OPNPRNTHS', '@CONDITION': '' },
            { "@FIELD_NAME": 'ZCIDTETER', "@FIELD_VALUE": "0", '@OPERATION': 'EQ', '@CONDITION': 'OR' },
            { "@FIELD_NAME": 'ZCIDTETER', "@FIELD_VALUE": '99999999', '@OPERATION': 'EQ', '@CONDITION': 'OR' },
            { "@FIELD_NAME": 'ZCIDTETER', "@FIELD_VALUE": moment(new Date()).format("YYYYMMDD"), '@OPERATION': 'GT', '@CONDITION': '' },
            { "@FIELD_NAME": '', "@FIELD_VALUE": '', '@OPERATION': 'CLSPRNTHS', '@CONDITION': '' }
        );
		 */
        let filters = [
            { "@FIELD_NAME": 'ZTOWNCODE', "@FIELD_VALUE": this.riskObj.city, '@OPERATION': 'EQ', '@CONDITION': 'AND' },
            { "@FIELD_NAME": 'PCODE', "@FIELD_VALUE": this.riskObj.postCode, '@OPERATION': 'EQ', '@CONDITION': 'AND' },
            { "@FIELD_NAME": '', "@FIELD_VALUE": '', '@OPERATION': 'OPNPRNTHS', '@CONDITION': '' },
            { "@FIELD_NAME": 'ZCIDTETER', "@FIELD_VALUE": "0", '@OPERATION': 'EQ', '@CONDITION': 'OR' },
            { "@FIELD_NAME": 'ZCIDTETER', "@FIELD_VALUE": '99999999', '@OPERATION': 'EQ', '@CONDITION': 'OR' },
            { "@FIELD_NAME": 'ZCIDTETER', "@FIELD_VALUE": moment(new Date()).format("YYYYMMDD"), '@OPERATION': 'GT', '@CONDITION': '' },
            { "@FIELD_NAME": '', "@FIELD_VALUE": '', '@OPERATION': 'CLSPRNTHS', '@CONDITION': '' }
        ];
        let request: GetLOVData = new GetLOVData().getLovRequest('ALL', 'FIRE', 'NEW BUSINESS', 'ALL', 'NEW', 'FIRE_IDC', 'ACCREG', 'LOV', filters, {}, null);
        this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.setAccuRegHandler, this.handleError, true, { comp: this });
    }

    setAccuRegHandler(response, prms) {
        let ary = [];
        let currentDate = moment(new Date()).format("YYYYMMDD");
        let registerNotExpired = true;
        if (response.tuple != null && !Array.prototype.isPrototypeOf(response.tuple)) {
            ary = [response.tuple];
        }
        else if (response.tuple != null) {
            ary = response.tuple;
        }
        prms.comp.AccRegList = [];
        for (let item of ary) {
            // SR001 Added the condition to check if Acc Reg is expired or not
            if (item.old.FACM.ZCIDTETER > currentDate || item.old.FACM.ZCIDTETER == '0') {
                let accReg: AccumulationRegister = {
                    "accRegCode": item.old.FACM.FREG,
                    "accRegDesc": item.old.FACM.FDESC,
                    "locality": item.old.FACM.LOCREG
                };
                // SR001 Added below the Condition to check if the accumulation register is expired on Renewal
                if (item.old.FACM.FREG == prms.comp.riskObj.accumulationRegister) {
                    registerNotExpired = false;
                }
                prms.comp.AccRegList.push(accReg);
            }
        }
        //Added code for AccRegister --start
        let accReg: AccumulationRegister = {
            "accRegCode": "0",
            "accRegDesc": "Register Not Found",
            "locality": ""
        };
        // SR001 Added the alert if the accumulation register expires on Renewal
        if (registerNotExpired && prms.comp.riskObj.accumulationRegister != "" && prms.comp.riskObj.accumulationRegister != undefined && prms.comp.riskObj.accumulationRegister != null) {
            prms.comp.riskObj.accumulationRegister = "";
            prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Accumulation Register Expired. Please select the correct Fire Accumulation Code. ", 5000));
        }
        prms.comp.AccRegList.push(accReg);
        //End
    }

    setPerilsRate(perilRate) {
        this.riskObj.perilsRate = perilRate;
		/*if( (this.riskObj.riskType=='ECP' || this.riskObj.riskType=='PP1' || this.riskObj.riskType=='ARI') &&  (this.riskObj.rateBasis == 'G' || this.riskObj.rateBasis == 'S') ){
			let _basicRate =0;
			if(parseFloat(""+this.riskObj.perils.fireAndLightingRate) > 0){
				_basicRate = parseFloat(""+this.riskObj.perils.fireAndLightingRate) + perilRate;
			} else {
				_basicRate = perilRate;
			}
			_basicRate = numeral(_basicRate).format(this.rateFormat);
			this.riskObj.basicRate = _basicRate;
			this.coverComp.setBasicRate(_basicRate);
			this.resetBasicRate(_basicRate);
		}*/
    }

    setTownClass(value) {
        this.riskObj.townClass = value;
        if (this.riskObj.riskType == 'ECP' || this.riskObj.riskType == 'PP1' || this.riskObj.riskType == 'ARI') {
            this.populatePIMCodeDependencies();
        }
        else
            this.setBasicRate();
    }

    setConstruction(ev) {
		/* this.riskObj.construction = value;
        let evt: any = event;
		this.riskObj.constructionName = jQuery(evt.target.selectedOptions[0]).text(); */
        this.riskObj.construction = ev.value;
        this.riskObj.constructionName = ev.record.DESCRIPTION;
        this.setBasicRate();
        //set Construction Extension as 'N' SAF MYS-2018-1249 start
        this.riskObj.constructionClassInd = (this.riskObj.construction == '2' || this.riskObj.construction == '3') ? 'N' : '';//End
    }

    onConstructionChange(ev) {
        this.riskObj.construction = ev.value;
        this.riskObj.constructionName = ev.record.CONSTN_LDESC;
        this.townClassArr = [];
        // this.riskObj.townClass='';
        // this.populateTownClass(true);
        // this.setBasicRate();
        this.populatePIMCodeDependencies();
        //set Construction Extension as 'N' SAF MYS-2018-1249 start
        this.riskObj.constructionClassInd = (this.riskObj.construction == '2' || this.riskObj.construction == '3') ? 'N' : '';//End
    }

    onTownClassChange(ev) {
        this.riskObj.townClass = ev.value;

        let _townClassRecords = this.lovDropDownService.lovDataList.piamCodesList.filter(_item => _item.VALUE === this.riskObj.PIAMCode && _item.CONSTN === this.riskObj.construction && _item.TOWNCLS === this.riskObj.townClass);
        if (_townClassRecords && _townClassRecords.length > 0) {
            this.setPIAMCodeDependencies(_townClassRecords[0]);
        }
    }

    onPIAMCodeChange(ev) {
        this.riskObj.PIAMCode = ev.value;
        this.setDefaultClause(ev.value);
        // this.setOccDesc(ev);
        this.townClassArr = [];
        this.constructionClassArr = [];
        // this.riskObj.townClass='';
        this.riskObj.construction = '';
        this.riskObj.constructionName = '';
        // this.populateTownClass();
        this.populateConstructionClass(true);

    }

    populatePIMCodeDependencies() {
        if (this.riskObj.PIAMCode && this.riskObj.construction && this.riskObj.townClass) {
            let _townClassRecords = this.lovDropDownService.lovDataList.piamCodesList.filter(_item => _item.VALUE === this.riskObj.PIAMCode && _item.CONSTN === this.riskObj.construction && _item.TOWNCLS === this.riskObj.townClass);
            if (_townClassRecords && _townClassRecords.length > 0) {
                this.setPIAMCodeDependencies(_townClassRecords[0]);
            }
            else
                this.resetPIAMCodeDependencies();
        } else {
            this.resetPIAMCodeDependencies();
        }
    }

    setPIAMCodeDependencies(rec) {
        if (rec) {
            let _basicRate = rec.RATE;
            this.riskObj.basicRate = numeral(_basicRate).format(this.rateFormat);
            this.riskObj.basicRateOriginal = numeral(_basicRate).format(this.rateFormat);
            if (numeral(this.riskObj.basicRate).value() < 0) {
                this.riskObj.basicRate = 0;
                this.riskObj.basicRateOriginal = 0;
            }
            this.riskObj.isRatingCommitteRateRequired = (this.riskObj.basicRate == 0) ? true : false;//set this field value as true if Basic Rate = 0;
            if (!rec.REFERRED || rec.REFERRED == 'N') {
                this.riskObj.symRiskClassification = "Standard";
                this.riskObj.accRegister.isSystemReferred = false; // accumulation register code
            }
            else if (rec.REFERRED && rec.REFERRED == 'Y') {
                this.riskObj.symRiskClassification = "Referred";
                this.riskObj.accRegister.isSystemReferred = true; // accumulation register code
            }
            else if (rec.REFERRED && rec.REFERRED == 'D') {
                this.riskObj.symRiskClassification = "Declined";
            }// added below code for SAF MYS-2018-0143 -- start
            else if (rec.REFERRED && rec.REFERRED == 'C') {
                this.riskObj.symRiskClassification = "ReferredCEO";//SAF MYS-2018-0143 
                //this.riskObj.symRiskClassification = "Referred";
            } else if (rec.REFERRED && rec.REFERRED == 'R') {
                this.riskObj.symRiskClassification = "ReferredRHC";//SAF MYS-2018-0143 
                //this.riskObj.symRiskClassification = "Referred";
            }//End

            this.handleRiskClassification(this);

            this.riskObj.RIRetentionCode = rec.ZRIRETN;
            // this.onRIRtnChange(rec.ZRIRETN);

            if (rec.CLASSDESC && (rec.CLASSDESC == "REFER TO ASSOCIATION" || rec.CLASSDESC == "UNCLASSIFIED RISK" || numeral(this.riskObj.basicRate).value() == 0)) {
                this.riskObj.PIAMCodeBREdit = "Y";
            }
            else
                this.riskObj.PIAMCodeBREdit = "N";

            this.onModeChange(this.riskObj.rateBasis, this.riskObj.ratingFlag, this.riskObj.PIAMCodeBREdit);
            this.resetBasicRate(this.riskObj.basicRate);
        }
    }

    resetPIAMCodeDependencies() {
        this.riskObj.basicRate = 0;
        this.riskObj.isRatingCommitteRateRequired = (this.riskObj.basicRate == 0) ? true : false;//set this field value as true if Basic Rate = 0;
        this.coverComp.setBasicRate(this.riskObj.basicRate);
        this.resetBasicRate(this.riskObj.basicRate);
        this.riskObj.RIRetentionCode = '';// added below code for SAF MYS-2018-0143 -- start
        if (this.riskObj.symRiskClassification == "Referred" || this.riskObj.symRiskClassification == "ReferredCEO" || this.riskObj.symRiskClassification == "ReferredRHC") {
            this.riskObj.symRiskClassification = "Standard";
            this.handleRiskClassification(this);
        }

        this.riskObj.PIAMCodeBREdit = "Y";

        this.onModeChange(this.riskObj.rateBasis, this.riskObj.ratingFlag, this.riskObj.PIAMCodeBREdit);
    }

    populateTownClass(defaultingFlag) {
        if (this.lovDropDownService.lovDataList.piamCodesList && this.lovDropDownService.lovDataList.piamCodesList.length > 0) {
            let _selectedPIAMCodeRecords = this.lovDropDownService.lovDataList.piamCodesList.filter(_item => _item.VALUE === this.riskObj.PIAMCode && _item.CONSTN === this.riskObj.construction);
            for (let _piamRecord of _selectedPIAMCodeRecords) {
                let hasTownClass = this.townClassArr.some(_item => _item.TOWNCLS === _piamRecord.TOWNCLS);
                if (!hasTownClass) {
                    this.townClassArr.push(_piamRecord);
                }
            }

            if (this.townClassArr.length > 0) {
                this.sortArray(this.townClassArr, 'TOWNCLS');
            }

            if (defaultingFlag && _selectedPIAMCodeRecords && _selectedPIAMCodeRecords.length > 0 && this.riskObj.PIAMCode && this.riskObj.construction && this.riskObj.townClass) {
                let _townClassRecord = _selectedPIAMCodeRecords.filter(_item => _item.TOWNCLS === this.riskObj.townClass)
                if (_townClassRecord && _townClassRecord.length > 0) {
                    this.setPIAMCodeDependencies(_townClassRecord[0]);
                }
            }
        }
    }

    populateConstructionClass(defaultingFlag) {
        // let selectedPIAMCodeTwnClsRecords = this.lovDropDownService.lovDataList.piamCodesList.filter(_item => (_item.VALUE === this.riskObj.PIAMCode && _item.TOWNCLS === this.riskObj.townClass ) );
        let selectedPIAMCodeConstClsRecords = this.lovDropDownService.lovDataList.piamCodesList.filter(_item => (_item.VALUE === this.riskObj.PIAMCode && _item.TOWNCLS === this.riskObj.townClass));
        for (let _constClassRecord of selectedPIAMCodeConstClsRecords) {
            let hasConstructionClass = this.constructionClassArr.some(_item => _item.CONSTN === _constClassRecord.CONSTN);
            if (!hasConstructionClass) {
                this.constructionClassArr.push(_constClassRecord);
            }
        }

        if (this.constructionClassArr.length > 0) {
            this.sortArray(this.constructionClassArr, 'CONSTN');
        }

        if (this.riskObj.riskType == 'ECP' && !this.riskObj.construction) {
            this.riskObj.construction = '3';
            if (this.constructionClassArr.length > 0) {
                let defaultConstCls = this.constructionClassArr.find(_item => _item.CONSTN === this.riskObj.construction);
                if (defaultConstCls) {
                    this.riskObj.constructionName = defaultConstCls.CONSTN_LDESC;
                }
            }

            // this.populateTownClass(true);
            this.populatePIMCodeDependencies();
        }

        if (!defaultingFlag && this.riskObj.PIAMCode && this.riskObj.construction && this.riskObj.townClass && (this.riskObj.basicRate == 0 || !this.riskObj.RIRetentionCode)) {
            this.populatePIMCodeDependencies();
        }
    }

    onModeChange(rateBasis, ratingFlag, brByPIAM) {
        if (this.perilsComp)
            this.perilsComp.evaluatePerilRateNeeded(rateBasis, ratingFlag);

        if (rateBasis == "G" || rateBasis == "S" || rateBasis == "L" || ratingFlag == "M" || brByPIAM == "Y") {
            if (this.coverComp != null)
                this.coverComp.setBaseRateEnable("Y");
        }
        else {
            this.riskObj.basicRate = this.riskObj.basicRateOriginal;
            this.riskObj.isRatingCommitteRateRequired = (this.riskObj.basicRate == 0) ? true : false;//set this field value as true if Basic Rate = 0;//SAF MYS-2018-1249
            if (this.coverComp != null)
                this.coverComp.setBaseRateEnable("N");
        }


        if (this.riskObj.riskType == "ARI") {
            this.handleRiskClassification(this);
			/*
			let isReferredAlready = false;
			let isDeclinedAlready = false;
			if(this.riskObj.PIAMCode && this.riskObj.townClass && this.riskObj.construction){
				let _townClassRecords = this.lovDropDownService.lovDataList.piamCodesList.filter(_item => _item.VALUE === this.riskObj.PIAMCode && _item.CONSTN === this.riskObj.construction && _item.TOWNCLS === this.riskObj.townClass);
				if(_townClassRecords && _townClassRecords.length > 0){
					let _rec = _townClassRecords[0];
					if(_rec.REFERRED && _rec.REFERRED == 'Y'){						
						isReferredAlready = true;
					}
					else if(_rec.REFERRED && _rec.REFERRED == 'D'){
						isDeclinedAlready = true;
					}
				}
			}
			
			if(!isDeclinedAlready){
				
				if(rateBasis == "L"){
					
					if(this.riskObj.symRiskClassification != "Declined"){
						this.riskObj.symRiskClassification = "Referred";
						this.riskObj.riRiskClassification = "Referred";
						
						this.handleRiskClassification(this);
					}
					
				}
				else if(!isReferredAlready){
					this.riskObj.symRiskClassification = "Standard";
					this.riskObj.riRiskClassification = "Standard";
					
					this.handleRiskClassification(this);
				}
			}*/
        }

        if (this.riskObj.riskType == "PP1" && this.rateClauseComp != null)
            this.rateClauseComp.setItEditMode(rateBasis);
        this.riskObj.rateBasisInd = (this.riskObj.rateBasis == 'S') ? this.riskObj.rateBasisInd : '';//SAF MYS-2018-1249 
    }

    rateBasisCallback(scopeObject) {
        if (scopeObject.riskObj.riskType == "ARI") {
            let rateBasisList = [];
            rateBasisList = scopeObject.lovDropDownService.lovDataList.rateBasis.filter((_item) => (_item.VALUE === 'A' || _item.VALUE === 'L'));
            scopeObject.lovDropDownService.lovDataList.rateBasis = rateBasisList;
        }

        if (scopeObject.riskObj.rateBasis && !scopeObject.riskObj.rateBasisName) {
            scopeObject.setRateBasisName(scopeObject, null);
        }
    }

    setRateBasisName(comp, value) {
        let rbVal = (value == null) ? comp.riskObj.rateBasis : value;
        let rbs = comp.lovDropDownService.lovDataList.rateBasis.filter((item) => item.VALUE == rbVal);
        if (rbs.length > 0)
            comp.riskObj.rateBasisName = rbs[0].DESCRIPTION;
    }

    addFEA() {
        let searchInput = new SearchInput();
        searchInput.isSingleSelect = false;
        searchInput.BRANCH = 'ALL';
        searchInput.BUSINESS_FUNCTION = 'NEW BUSINESS';
        searchInput.FIELD_TYPE = 'LOOKUP';
        searchInput.FORM_FIELD_NAME = 'FEAEq';
        searchInput.FORM_NAME = 'FIRE_IDC';
        searchInput.LOB = 'FIRE';
        searchInput.OPERATION = 'NEW';
        searchInput.PRODUCT = 'ALL';

        if (this.riskObj.FEA.FEAeq.length > 0) {
            let newArr = [];
            for (let item of this.riskObj.FEA.FEAeq) {
                newArr = newArr.concat(item["code"]);
            }
            let feaCodes = "'" + newArr.toString().replace(/,/g, "\',\'") + "'";
            searchInput.condition = { "RTRIM(LTRIM(DESCITEM))": feaCodes };
        }
        else
            searchInput.condition = { "RTRIM(LTRIM(DESCITEM))": "''" };

        let input = new ModalInput();
        input = input.get("GenericSearchComponent");
        input.datainput = searchInput;
        input.outputCallback = this.addFEACallBack;
        input.parentCompPRMS = { comp: this };
        input.heading = "FEA Details";
        input.icon = "fa fa-file-pdf-o";
        input.containerRef = this.contentArea;
        this.dcl.openLookup(input);
    }

    addFEACallBack(listFEA, prms) {
        for (let item of listFEA) {
            if (!prms.comp.riskObj.FEA.FEAeq)
                prms.comp.riskObj.FEA.FEAeq = [];

            prms.comp.riskObj.FEA.FEAeq.push({
                "code": item.old.DESCPF.VALUE,
                "description": item.old.DESCPF.DESCRIPTION
            });
        }
    }

    removeFEA(idx: number) {
        this.riskObj.FEA.FEAeq.splice(idx, 1);
    }

    setBasicRate() {
        if (this.riskObj.PIAMCode != undefined && this.riskObj.construction != undefined && this.riskObj.townClass != undefined) {
            let request: GetLOVData = new GetLOVData();
            request.BRANCH = 'ALL';
            request.LOB = 'FIRE';
            request.BUSINESS_FUNCTION = 'NEW BUSINESS';
            request.PRODUCT = 'ALL';
            request.OPERATION = 'NEW';
            request.FORM_NAME = 'FIRE_IDC';
            request.FORM_FIELD_NAME = 'Basic Rate';
            request.FIELD_TYPE = 'LOV';
            request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
            request.ADVANCE_CONFIG_XML.FILTERS = new Filter();
            //SR002 - Passed header effective date instead of Date of Attachment for Referred Risk Check
            request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({ "@FIELD_NAME": 'DESCITEM', "@FIELD_VALUE": this.riskObj.PIAMCode, '@OPERATION': 'EQ', '@CONDITION': 'AND' },
                { "@FIELD_NAME": 'CONSTRUCTIONCLS', "@FIELD_VALUE": this.riskObj.construction, '@OPERATION': 'EQ', '@CONDITION': 'AND' },
                { "@FIELD_NAME": 'TWNCLS', "@FIELD_VALUE": this.riskObj.townClass, '@OPERATION': 'EQ', '@CONDITION': 'AND' },
                { "@FIELD_NAME": 'ITMFRM', "@FIELD_VALUE": moment(this.headerInfo.effectiveDate, "YYYY-MM-DD").format("YYYYMMDD"), '@OPERATION': 'LT', '@CONDITION': 'AND' },
                { "@FIELD_NAME": 'ITMTO', "@FIELD_VALUE": moment(this.headerInfo.effectiveDate, "YYYY-MM-DD").format("YYYYMMDD"), '@OPERATION': 'GT', '@CONDITION': 'AND' });
            this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.successHandler, this.handleError, false, { comp: this });
        }
    }

    successHandler(response, prms) {
        prms.comp.riskObj.piamRiskClassification = "";
        if (response.tuple != null) {
            prms.comp.riskObj.basicRate = numeral(response.tuple.old.T8799.BASICRATE).format(prms.comp.rateFormat);
            prms.comp.riskObj.basicRateOriginal = numeral(response.tuple.old.T8799.BASICRATE).format(prms.comp.rateFormat);
            prms.comp.riskObj.piamRiskClassification = response.tuple.old.T8799.REFERREDRISK;
            if (numeral(prms.comp.riskObj.basicRate).value() < 0) {
                prms.comp.riskObj.basicRate = 0;
                prms.comp.riskObj.basicRateOriginal = 0;
            }
            prms.comp.riskObj.isRatingCommitteRateRequired = (prms.comp.riskObj.basicRate == 0) ? true : false;//set this field value as true if Basic Rate = 0;
            if (response.tuple.old.T8799.REFERREDRISK == '' || response.tuple.old.T8799.REFERREDRISK == 'N') {
                //prms.comp.riskObj.symRiskClassification = "Standard";
                prms.comp.riskObj.accRegister.isSystemReferred = false; // accumulation register code
            }
            else if (response.tuple.old.T8799.REFERREDRISK == 'Y') {
                //prms.comp.riskObj.symRiskClassification = "Referred";//KA001
                prms.comp.riskObj.accRegister.isSystemReferred = true; // accumulation register code
            }
            else if (response.tuple.old.T8799.REFERREDRISK == 'D') {
                //prms.comp.riskObj.symRiskClassification = "Declined";//KA001
                prms.comp.riskObj.accRegister.isSystemReferred = false; // accumulation register code
            }// added below code for SAF MYS-2018-0143 -- start
            else if (response.tuple.old.T8799.REFERREDRISK == 'C') {
                //prms.comp.riskObj.symRiskClassification = "ReferredCEO";//SAF MYS-2018-0143 
                //prms.comp.riskObj.symRiskClassification = "Referred";
            } else if (response.tuple.old.T8799.REFERREDRISK == 'R') {
                //prms.comp.riskObj.symRiskClassification = "ReferredRHC";//SAF MYS-2018-0143 
                //prms.comp.riskObj.symRiskClassification = "Referred";
            } // End

            prms.comp.onRIRtnChange(response.tuple.old.T8799.RIRETNCODE);
            prms.comp.setBREditByPIAM(prms.comp, response);
            prms.comp.resetBasicRate(prms.comp.riskObj.basicRate);
        }
    }

    setBREditByPIAM(comp, resp) {
        if (resp.tuple.old.T8799.TRDDESCR != null && (resp.tuple.old.T8799.TRDDESCR == "REFER TO ASSOCIATION" || resp.tuple.old.T8799.TRDDESCR == "UNCLASSIFIED RISK" || numeral(comp.riskObj.basicRate).value() == 0)) {
            comp.riskObj.PIAMCodeBREdit = "Y";
        } else {
            comp.riskObj.PIAMCodeBREdit = "N";
        }
        comp.onModeChange(comp.riskObj.rateBasis, comp.riskObj.ratingFlag, comp.riskObj.PIAMCodeBREdit);
    }

    handleRiskClassification(comp) {
        comp.riskClassificationService.setRiskClassification(comp.riskObj.riskNumber, "N", "", "").subscribe((support) => {
            if (support == "NS") {
                if (comp.riskObj.symRiskClassification == "ReferredCEO") // added below code for SAF MYS-2018-0143 -- start
                    comp.riskObj.riskClassification = "ReferredCEO";
                else if (comp.riskObj.symRiskClassification == "ReferredRHC")
                    comp.riskObj.riskClassification = "ReferredRHC"; // End
                else if (comp.riskObj.symRiskClassification == "Declined")
                    comp.riskObj.riskClassification = "Declined";
                else if (comp.riskObj.symRiskClassification == "Referred" || comp.riskObj.riRiskClassification == "Referred")
                    comp.riskObj.riskClassification = "Referred";
                else
                    comp.riskObj.riskClassification = "Standard";
                comp.setRiskClassification(comp);
                comp.emitRiskClass(comp);
            }
        });

    }

    handleError(response, status, errorText, prms) {
        prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, response.responseJSON.faultstring.text, -1));
    }

    setRICode(riCode: string) {
        this.lovDropDownService.createLOVDataList(["riCode"]);

        let riTypeFilterDetails = [new SearchFilter("DESCITEM", riCode, "EQ", "AND")];
        let riTypeSearchFilterNodes = this.lovDropDownService.createFilter(riTypeFilterDetails);

        let lovFields = [new LOV_Field("ALL", "MOTOR", "NEW BUSINESS", "ALL", "NEW", "PRIVATE_MOTOR", "RI Retention Code", "LOV", riTypeSearchFilterNodes, "DESCPF", "riCode", null)];

        this.lovDropDownService.util_populateLOV(lovFields, this);
    }

    resetFireCoverage(clause) {
        if (this.coverComp != null) {
            this.coverComp.resetClauseRate();
        }
    }

    resetBasicRate(basicRate: number) {
        if (this.coverComp != null) {
            this.coverComp.resetBasicRate(basicRate);
        }
        if (this.rateClauseComp != null) {
            this.rateClauseComp.resetBasicRate(basicRate);
        }
    }

    resetPerilRate(perilRate: number) {
        if (this.coverComp != null) {
            this.coverComp.resetPerilRate(perilRate);
        }
    }

    setTotalPremium(premium) { //SAF MYS-2018-1249
        this.riskObj.totalPremium = premium;
        this.riskObj.originalTotalPremium = this.getTotalByProperty("premium", this.riskObj.fireItems.fireItems, "0,00.00");
        this.onPremiumChange.emit(premium);
    }

    setTotalSI(si) {
        this.riskObj.totalSI = si;//SAF MYS-2018-1249
        this.setFinalSI();
    }

    resetInceptionDate() {

    }

    resetSurvey(value) {
        if ("Y" == value) {
            this.riskObj.survey = new Survey();
            this.riskObj.surveyType = "";
        }
        else {
            this.riskObj.survey = null;
            this.riskObj.surveyType = "";
        }
    }

    resetRelatedCase(value) {
        if ("Y" == value) {
            this.riskObj.relatedCases = new FireRelatedCases();
        }
        else {
            this.riskObj.relatedCases = null;
            this.riskObj.relatedSumInsured = 0;
            this.setFinalSI();
        }
    }

    setFinalSI() {
        this.riskObj.capitalSumInsured = this.riskObj.totalSI;

        if (this.riskObj.RIRetentionCode && this.riskObj.isRIOverWrittenByUW == 'N') {

            this._bmsUtilService.getTotalGrossCapacity(this.riskObj.RIRetentionCode).subscribe((data) => this.compareSIWithTotGrossCap(data));
			/*let _totalGrossCapacity = this._bmsUtilService.getNetRetentionAmountDetails(this.riskObj.RIRetentionCode);
			_totalGrossCapacity = (!_totalGrossCapacity) ? 0 : parseFloat(""+_totalGrossCapacity);
			this.riskObj.totalGrossCapacity = _totalGrossCapacity;
			let _totalSI = parseFloat(""+this.riskObj.totalSI);
			
			if( _totalGrossCapacity > 0 && _totalSI > _totalGrossCapacity && (this.riskObj.RIMethod == null || this.riskObj.RIMethod == "" || parseFloat(""+this.riskObj.RIMethod) != 8) ){
				this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Total Sum Insured is greater than Total Gross Capacity: "+_totalGrossCapacity+",  RI is Required." , 10000));
				
				this.riskObj.RIRequired = "Yes";
				this.riskObj.RIMethod = "8";
			} 
			else if(_totalSI <= _totalGrossCapacity){
				this.riskObj.RIRequired = "No";
				this.riskObj.RIMethod = this.riskObj.RIMethodSys;
			}*/
        }
        else
            this.setRIMethodEditableFlag();
    }

    compareSIWithTotGrossCap(totGrossCap) {

        let _totalGrossCapacity = (!totGrossCap) ? 0 : parseFloat("" + totGrossCap);
        this.riskObj.totalGrossCapacity = _totalGrossCapacity;
        let _totalSI = parseFloat("" + this.riskObj.totalSI);

        if ((parseFloat("" + this.riskObj.RIMethod) == 8) || (this.riskObj.RIRequired == "Yes")) {
            this.riskObj.RIRequired = "Yes";
            this.riskObj.RIMethod = "8";
        }
        else if (_totalGrossCapacity > 0 && _totalSI > _totalGrossCapacity && (this.riskObj.RIMethod == null || this.riskObj.RIMethod == "" || parseFloat("" + this.riskObj.RIMethod) != 8)) {
            this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Total Sum Insured is greater than Total Gross Capacity: " + _totalGrossCapacity + ",  RI is Required.", 10000));

            this.riskObj.RIRequired = "Yes";
            this.riskObj.RIMethod = "8";
        }
        else if (_totalSI <= _totalGrossCapacity) {
            this.riskObj.RIRequired = "No";
            this.riskObj.RIMethod = this.riskObj.RIMethodSys;
        }
        this._riService.setRI().subscribe();
        this.setRIMethodEditableFlag();
    }

    isLeastPreferredRI() {
        if (this.riskObj.RIRetentionCode != null) {
            if (this.leastPreferredRI.indexOf(this.riskObj.RIRetentionCode) != -1) {
                return true;
            }
        }
        return false;
    }

    setDefaultClause(piamCode) {
        this._defaultProductClauses.clause = this.riskObj.clauses.clause.filter((item) => item.isDefaultClause == "N");//E1003
        this.removeDefaultClauses();
        this.getDefaultClauses(piamCode);
        // accumulationRegister code start
        if (this.riskObj.accRegister.isSystemReferred == false &&
            (this.riskObj.accRegister.isAccuSystemReferredFlag != undefined && this.riskObj.accRegister.isAccuSystemReferredFlag == true)) {
            this.setReferredRiskFlag(true, "Referred", true);
        }
        //End

        //SAF MYS-2019-0909
        if ( this.riskObj.isValidBenefitProduct == "Y" && this.riskObj.fireItems.addOnBenefitCode != undefined && this.riskObj.fireItems.addOnBenefitCode != "" ) {
            this._alertMsgService.add( new AlertMessage( AlertMessage.INFO, "Please reselect Addon Benefit in Coverage Information section.", 10000 ) );
            this.riskObj.fireItems.addOnBenefitCode = "";
            this.riskObj.fireItems.benefitSI = 0;
            this.riskObj.fireItems.benefitPremiumClass = "";  
        }
        //End
    }

    getDefaultClauses(piamCode) {
        let clsSearch = this.riskObj.riskType + piamCode;
        let request: GetLOVData = new GetLOVData();
        request.BRANCH = 'ALL';
        request.LOB = 'FIRE';
        request.BUSINESS_FUNCTION = 'NEW BUSINESS';
        request.PRODUCT = 'ALL';
        request.OPERATION = 'ALL';
        request.FORM_NAME = 'ALL';
        if (this.headerInfo.VPMSProduct == "Y" || this.headerInfo.firePostingScreen == "NEW") { //SAF MYS-2018-1249 start
            request.FORM_FIELD_NAME = 'PIAMStandardClauses';
        } else {
            request.FORM_FIELD_NAME = 'PIAMClause'; //Default
        } //End

        request.FIELD_TYPE = 'LOOKUP';
        request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        request.ADVANCE_CONFIG_XML.FILTERS = new Filter();

        request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({ "@FIELD_NAME": 'C.DESCITEM', "@FIELD_VALUE": clsSearch, '@OPERATION': 'EQ', '@CONDITION': 'AND' });
        this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.addDefaultClauses, this.handleError, false, { comp: this });

    }

    // Added for new default class setup E1003
    getNewDefaultClauses(clsSearch) {
        let request: GetLOVData = new GetLOVData();
        request.BRANCH = 'ALL';
        request.LOB = 'FIRE';
        request.BUSINESS_FUNCTION = 'NEW BUSINESS';
        request.PRODUCT = 'ALL';
        request.OPERATION = 'ALL';
        request.FORM_NAME = 'ALL';
        request.FORM_FIELD_NAME = 'PIAMClause';
        request.FIELD_TYPE = 'LOOKUP';
        request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        request.ADVANCE_CONFIG_XML.FILTERS = new Filter();
        let clauseCodes = "";
        request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({ "@FIELD_NAME": "C.DESCITEM", "@FIELD_VALUE": this.headerInfo.contractType, '@OPERATION': 'STARTSWITH', '@CONDITION': 'AND' });
        request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({ "@FIELD_NAME": "SUBSTRING(C.SCLS,1,4)", "@FIELD_VALUE": clsSearch, '@OPERATION': 'IN', '@CONDITION': 'AND' });
        this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.addNewDefaultClauses, this.handleError, false, { comp: this });
    }
    // End E1003
    addDefaultClauses(response, prms) {
        let ary = [];
        let wcAry = [];
        if (response.tuple != null && !Array.prototype.isPrototypeOf(response.tuple)) {
            ary = [response.tuple];
        }
        else if (response.tuple != null) {
            ary = response.tuple;
        }
        //filtering only SC or WC clauses from the list.//SAF MYS-2018-1249 start
        if (prms.comp.headerInfo.VPMSProduct == "Y" || prms.comp.headerInfo.firePostingScreen == "NEW") {
            let tempAry = ary;
            ary = ary.filter((_item) => _item.old.T7382.ZPRLGRP === 'SC' && _item.old.T7382.ZACTIND === 'Y');
            // adding warranty clauses into Warratny clauses section.
            wcAry = tempAry.filter((_item) => _item.old.T7382.ZPRLGRP === 'WC' && _item.old.T7382.ZACTIND === 'Y');
        }//End

        for (let clause of ary) {
            let newClause = { clauseCode: clause.old.T7382.CODE, description: clause.old.T7382.LONGDESC, isDefaultClause: 'Y' };
            prms.comp.riskObj.defaultClauses.clause.push(newClause);
            prms.comp.riskObj.clauses.clause.forEach(item => {
                if (item.clauseCode != newClause.clauseCode) {
                    prms.comp.riskObj.clauses.clause.push(newClause);
                }
            });
            if (prms.comp.riskObj.clauses.clause.length == 0) {
                prms.comp.riskObj.clauses.clause.push(newClause);
            }
        }
        prms.comp.riskObj.clauses.clause = prms.comp.removeAryDuplicates(prms.comp.riskObj.clauses.clause, "clauseCode");
        //E1003 start
        if (prms.comp._defaultProductClauses.clause != undefined && prms.comp._defaultProductClauses.clause.length > 0) {
            prms.comp.removeDuplicateClauses(prms.comp.riskObj.clauses.clause, prms.comp._defaultProductClauses.clause);
            prms.comp.riskObj.clauses.clause = prms.comp.riskObj.clauses.clause.concat(prms.comp._defaultProductClauses.clause);
            prms.comp.arrangeClauses(prms);
        } //End
        //SAF MYS-2018-1249 start
        if ((prms.comp.headerInfo.VPMSProduct == "Y" || prms.comp.headerInfo.firePostingScreen == "NEW") && wcAry.length > 0) {
            let wcCodesArr = [];
            for (let item of wcAry) {
                wcCodesArr = wcCodesArr.concat(item.old.T7382["CODE"]);
            }
            prms.comp.fetchDefaultWarrantyClauses("'" + wcCodesArr.toString().replace(/,/g, "\',\'") + "'");
        } else if (wcAry.length == 0) {
            //remove default warranty clauses for PIAM code
            prms.comp.riskObj.warrantyClassCodes.warrantyClassCode = prms.comp.riskObj.warrantyClassCodes.warrantyClassCode.filter((item) => item.isDefaultWCClause != "Y");
            prms.comp.riskObj.fireItems.fireItems.forEach(item => {
                item.wcClassCodes.warrantyClassCode = item.wcClassCodes.warrantyClassCode.filter((item) => item.isDefaultWCClause != "Y");
            });
        }
        //End
    }
    // Added for new default class setup E1003 start
    addNewDefaultClauses(response, prms) {
        let ary = [];
        if (response.tuple != null && !Array.prototype.isPrototypeOf(response.tuple)) {
            ary = [response.tuple];
        }
        else if (response.tuple != null) {
            ary = response.tuple;
        }
        for (let clause of ary) {
            let newClause = { clauseCode: clause.old.T7382.CODE, description: clause.old.T7382.LONGDESC, isDefaultClause: 'N' };
            prms.comp._defaultProductClauses.clause.push(newClause);
        }
        if (prms.comp._defaultProductClauses.clause != undefined && prms.comp._defaultProductClauses.clause.length > 0) {
            prms.comp.removeDuplicateClauses(prms.comp.riskObj.clauses.clause, prms.comp._defaultProductClauses.clause);
            prms.comp.riskObj.clauses.clause = prms.comp.riskObj.clauses.clause.concat(prms.comp._defaultProductClauses.clause);
            prms.comp.arrangeClauses(prms);
        }
    }
    private arrangeClauses(prms) {
        if (prms.comp.riskObj.clauses.clause.length !== 0) {
            let _defaultClause = prms.comp.riskObj.clauses.clause.filter((item) => item.isDefaultClause == "Y");
            let _selectedClause = prms.comp.riskObj.clauses.clause.filter((item) => item.isDefaultClause == undefined);
            let defaultProductClauses = prms.comp.riskObj.clauses.clause.filter((item) => item.isDefaultClause == "N");
            prms.comp.riskObj.clauses.clause = [];
            prms.comp.riskObj.clauses.clause = prms.comp.riskObj.clauses.clause
                .concat(_defaultClause != undefined ? _defaultClause : [], defaultProductClauses != undefined ? defaultProductClauses : [], _selectedClause != undefined ? _selectedClause : []);
        }
    }
    private removeDuplicateClauses(allClauses: Clause[], productClauses: Clause[]) {
        if (productClauses != undefined && allClauses != undefined) {
            productClauses.forEach((cl) => {
                allClauses.forEach((allCl, index) => {
                    if (cl["clauseCode"] == allCl["clauseCode"]) {
                        allClauses.splice(index, 1);
                    }
                });
            });
        }
    }
    // End E1003
    removeDefaultClauses() {
        this.riskObj.defaultClauses.clause = this.riskObj.defaultClauses.clause.concat(this._defaultProductClauses.clause);//E1003
        for (let clause of this.riskObj.defaultClauses.clause) {
            let clsFrmClause = this.riskObj.clauses.clause.filter((item) => item.clauseCode == clause.clauseCode);
            for (let cls of clsFrmClause) {
                this.riskObj.clauses.clause.splice(this.riskObj.clauses.clause.indexOf(cls), 1);
            }
        }
        this.riskObj.defaultClauses.clause = [];
    }

    setRiskClassification(comp) {
        if (comp.riskObj.symRiskClassification != null && comp.riskObj.symRiskClassification != "" && (comp.riskObj.symRiskClassification == "Referred" || comp.riskObj.symRiskClassification == "Declined" || comp.riskObj.symRiskClassification == "ReferredCEO" || comp.riskObj.symRiskClassification == "ReferredRHC"))//SAF MYS-2018-0143 
        {
            comp.riskObj.riskClassificationReason = "System marked as " + comp.riskObj.symRiskClassification;
        }
        else if (comp.riskObj.riRiskClassification != null && comp.riskObj.riRiskClassification != "" && comp.riskObj.riRiskClassification == "Referred") {
            comp.riskObj.riskClassificationReason = "System marked as " + comp.riskObj.riRiskClassification;
        }
        else {
            if (comp.riskObj.riskClassificationReason != null && comp.riskObj.riskClassificationReason != "" && (comp.riskObj.riskClassificationReason != "System marked as Standard" && comp.riskObj.riskClassificationReason.indexOf("System marked as ") != -1)) {
                comp.riskObj.riskClassificationReason = "";
            }
        }
    }

    setReferredFromUI(riskClass) {
        this.riskObj.riskClassification = riskClass;
        this.riskClassificationService.setRiskClassification(this.riskObj.riskNumber, "N", "", "").subscribe();
    }

    emitRiskClass(comp) {
        comp.onRiskClsChange.emit("");
    }

    setIdentity(isIdentityChange) {
        if (isIdentityChange == true && (this.riskObj.identityFiller == null || this.riskObj.identityFiller == "")) {
            if (this.riskObj.situation1 != null) {
                this.riskObj.identity = this.riskObj.situation1.slice(0, 15);
                this.riskObj.identityFiller = this.riskObj.situation1.slice(0, 15);
            }
        }
        else {
            if (isIdentityChange == false && this.riskObj.situation1 != null) {
                this.riskObj.identity = this.riskObj.situation1.slice(0, 15);
                this.riskObj.identityFiller = this.riskObj.situation1.slice(0, 15);
            }
            else if (this.riskObj.identityFiller != null)
                this.riskObj.identity = this.riskObj.identityFiller.slice(0, 15);
        }
    }

    setRIMethod(value) {
        this.riskObj.RIMethod = (value == "Yes") ? "8" : "1";

        if (this.isUnderWriter == "Y" || value == "Yes")
            this.riskObj.isRIOverWrittenByUW = "Y";
        else if (value == "No") {
            this.riskObj.isRIOverWrittenByUW = "N";
            this.setFinalSI();
        }
        this._riService.setRI().subscribe();
    }

    setSurveyNeed() {
        let maxSI = this.maxSIForSurvey[this.riskObj.RIRetentionCode];
        if (maxSI && maxSI != "") {
            if (this.riskObj.surveyNumber && this.riskObj.surveyNumber != "" && this.riskObj.surveyStatus == "Survey Initiated") {
                this.riskObj.isSurveyDisabled = "Y";
            }
            else {
                if (parseFloat(this.riskObj.totalSI.toString()) > parseFloat(maxSI)) {
                    if (this.riskObj.isSurveyNeeded != 'N') {
                        if (!this.riskObj.survey) {
                            this.riskObj.survey = new Survey();
                        }
                        this.riskObj.isSurveyNeeded = 'Y';
                        this.validatorforSurveyDetails();
                    }
                }

            }
        }
    }

    validatorforSurveyDetails() {
        if (this.riskObj.surveyNumber != null && this.riskObj.surveyNumber != undefined) {
            if (this.riskObj.surveyType != null && this.riskObj.surveyType != undefined) {
            } else {
                this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Please select the Survey Type ", -1));
            }

        }
    }

    onRIRtnChange(value) {
        this.riskObj.RIRetentionCode = value;
        if (this.isLeastPreferredRI()) {
            this.riskObj.isLeastPreferred = "Y";
            this.riskObj.riRiskClassification = "Referred";
        }
        else {
            this.riskObj.isLeastPreferred = "N";
            if (!(this.riskObj.riskType == "ARI" && this.riskObj.rateBasis == "L"))
                this.riskObj.riRiskClassification = "Standard";
        }
        this.handleRiskClassification(this);
        this.setSurveyNeed();
    }

    resetFI(value) {
        if (value == "Y")
            this.riskObj.financialInterest = new FinancialInterest();
        else
            this.riskObj.financialInterest = null;
    }

    setFocusToNext(elmnt) {
        let sutuationElmnts = jQuery(this.el).find("input");
        jQuery(sutuationElmnts[sutuationElmnts.index(elmnt) + 1]).focus();
    }

    setOccDesc(ev) {
        this.riskObj.occupiedAs = ev.record.DESCRIPTION;
    }

    sortArray(arryObjs, name) {
        if (arryObjs.length > 0) {
            arryObjs.sort(function (obj1, obj2) {
                if (obj1[name] < obj2[name]) {
                    return -1;
                } else if (obj1[name] > obj2[name]) {
                    return 1;
                } else {
                    return 0;
                }
            });
        }
    }

    setRIMethodEditableFlag() {
        let _totalSI = parseFloat("" + this.riskObj.totalSI);
        let _totalGrossCapacity = parseFloat("" + this.riskObj.totalGrossCapacity);
        if (_totalGrossCapacity > 0 && _totalSI > _totalGrossCapacity && this.isUnderWriter == "N") {
            this.isRIMethodEditable = "N";
        }
        else {
            this.isRIMethodEditable = "Y";
        }
    }

    emitFlagChange() {
        this.onRtngFlgChange.emit("");
    }

    // SAF MYS-2018-0666 --start
    callbackDeductiblesList(scopeObject) {
        scopeObject.deductiblesTypesArr = scopeObject.lovDropDownService.lovDataList.deductiblesList;
        if (scopeObject.headerInfo.disableFEAInfo != undefined && scopeObject.headerInfo.disableFEAInfo == false && scopeObject.riskObj.deductible != undefined && scopeObject.riskObj.deductible != "") {
            let isDeductibleValexists = scopeObject.deductiblesTypesArr.find(_item => _item.DESCITEM == scopeObject.riskObj.deductible);
            if (!isDeductibleValexists && scopeObject.headerInfo.VPMSProduct != "Y" && scopeObject.headerInfo.firePostingScreen != "NEW") {
                scopeObject._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Deductible amount is not exists in Deductibles field, Deductible amount is :" + scopeObject.riskObj.deductible + ". Please select appropriate Deductible amount.", 10000));
            }
        }
    }

    addFEAList() {
        let searchInput = new SearchInput();
        searchInput.isSingleSelect = false;
        searchInput.BRANCH = 'ALL';
        searchInput.LOB = 'FIRE';
        searchInput.BUSINESS_FUNCTION = 'NEW BUSINESS';
        searchInput.PRODUCT = 'ALL';
        searchInput.OPERATION = 'NEW';
        searchInput.FORM_NAME = 'FIRE';
        searchInput.FORM_FIELD_NAME = 'FEACLAUSES_LIST';
        searchInput.FIELD_TYPE = 'LOV';

        if (this.riskObj.FEA.FEAeq.length > 0) {
            let newArr = [];
            for (let item of this.riskObj.FEA.FEAeq) {
                let tempItem = item["code"].trim();
                newArr = newArr.concat(tempItem);
            }
            let feaCodes = "'" + newArr.toString().replace(/,/g, "\',\'") + "'";
            searchInput.condition = { "RTRIM(LTRIM(ZFIREQ))": feaCodes, "OPNPRNTHS": "", "DESCITEM": "E" + this.riskObj.riskType, "RTRIM(DESCITEM)": '', "CLSPRNTHS": "" };
        }
        else
            searchInput.condition = { "RTRIM(LTRIM(ZFIREQ))": "''", "OPNPRNTHS": "", "DESCITEM": "E" + this.riskObj.riskType, "RTRIM(DESCITEM)": '', "CLSPRNTHS": "" };

        let input = new ModalInput();
        input = input.get("GenericSearchComponent");
        input.datainput = searchInput;
        input.outputCallback = this.addFEAListCallBack;
        input.parentCompPRMS = { comp: this };
        input.heading = "FEA Details";
        input.icon = "fa fa-file-pdf-o";
        input.containerRef = this.contentArea;
        this.dcl.openLookup(input);
    }

    addFEAListCallBack(listFEA, prms) {

        if (prms.comp.headerInfo.disableFEAInfo) {
            for (let item of listFEA) {
                if (!prms.comp.riskObj.FEA.FEAeq)
                    prms.comp.riskObj.FEA.FEAeq = [];

                prms.comp.riskObj.FEA.FEAeq.push({
                    "code": item.old.TABLE.VALUE,
                    "description": item.old.TABLE.DESCRIPTION,
                    "exFEAClauses": item.old.TABLE.FEACLAUSES.split(","),
                    "feaRate": item.old.TABLE.FEARATE,
                    "indicator": item.old.TABLE.IND
                });
            }
            return;
        }
        let excludedItems: any = [];
        let excludedClausesList: any = [];
        let isExcludedItems: boolean = false;
        let indicatorArr: any = [];
        let maxFEAper: number = 0;
        let totalFEAPer: number = 0;

        if (numeral(prms.comp.riskObj.FEA.FEAeq.length).add(listFEA.length).value() > prms.comp.riskObj.FEAMaxlist) {
            prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "FEAList Maximum length exceeded, maximum allowed is : " + prms.comp.riskObj.FEAMaxlist, 20000));
            return;
        }

        totalFEAPer = prms.comp.riskObj.FEAPercentage;
        // below code to fill exculded items list for added items.
        if (prms.comp.riskObj.FEA.FEAeq.length > 0) {
            for (let item of prms.comp.riskObj.FEA.FEAeq) {
                //totalFEAPer = numeral(totalFEAPer).add(Number(item.feaRate));
                if (item.exFEAClauses != undefined && item.exFEAClauses != "" && excludedItems.indexOf(item.exFEAClauses) == -1) {
                    if (item.exFEAClauses.length > 0) {
                        for (let subItem of item.exFEAClauses)
                            excludedItems.push(subItem);
                    } else {
                        excludedItems.push(item.exFEAClauses);
                    }
                    indicatorArr.push(item.indicator);
                }
            }
        }
        // below code to fill exculded items list for selected items.
        if (listFEA.length > 0) {
            for (let item of listFEA) {
                let tempList = item.old.TABLE.FEACLAUSES.split(",");
                if (tempList != "" && excludedItems.indexOf(item.old.TABLE.FEACLAUSES) == -1) {
                    if (item.old.TABLE.FEACLAUSES.length > 0) {
                        for (let subItem of tempList)
                            excludedItems.push(subItem);
                    } else {
                        excludedItems.push(item.old.TABLE.FEACLAUSES);
                    }

                    indicatorArr.push(item.old.TABLE.IND);
                }
            }
        }

        //adding selected items into FEA list.
        if (listFEA.length > 0) {
            for (let item of listFEA) {
                if (excludedItems.indexOf(item.old.TABLE.FEACODE) == -1) {

					/* if ((indicatorArr.indexOf("I") == 0 && indicatorArr.indexOf("E") == 0) && indicatorArr.indexOf("O") == -1 && numeral(totalFEAPer).add(Number(item.old.TABLE.FEARATE)).value() > 25) {
						//prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "FEA percentage limit exceeded, only 25% allowed for FEA items (Internal and External). Please Remove some FEA items and proceed. FEA Item :"+item.old.TABLE.VALUE+" is not added.", 10000));
						prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "FEA percentage limit exceeded, only 25% allowed for FEA items (Internal and External).", 10000));
						//continue;
					}
					else if ((indicatorArr.indexOf("I") == 0 || indicatorArr.indexOf("E") == 0) && indicatorArr.indexOf("O") == -1 && numeral(totalFEAPer).add(Number(item.old.TABLE.FEARATE)).value() > 15) {
						//prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "FEA percentage limit exceeded, only 15% allowed for FEA items (Internal or External). Please Remove some FEA items and proceed, FEA Item :"+item.old.TABLE.VALUE+" is not added." , 10000));
						prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "FEA percentage limit exceeded, only 15% allowed for FEA items (Internal or External).", 10000));
						//continue;
					} 
					else if ((indicatorArr.indexOf("I") == 0 || indicatorArr.indexOf("E") == 0) && indicatorArr.indexOf("O") == 0 && numeral(totalFEAPer).add(Number(item.old.TABLE.FEARATE)).value() > 75) {
						//prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "FEA percentage limit exceeded, maximum 75% allowed for FEA items (OTHERS type).Please Remove some FEA items and proceed. FEA Item :"+item.old.TABLE.VALUE+" is not added.", 10000));
						prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "FEA percentage limit exceeded, maximum 75% allowed for FEA items (OTHERS type).", 10000));
						//continue;
					} */
                    //else {
                    if (!prms.comp.riskObj.FEA.FEAeq)
                        prms.comp.riskObj.FEA.FEAeq = [];

                    prms.comp.riskObj.FEA.FEAeq.push({
                        "code": item.old.TABLE.VALUE,
                        "description": item.old.TABLE.DESCRIPTION,
                        "exFEAClauses": item.old.TABLE.FEACLAUSES.split(","),
                        "feaRate": item.old.TABLE.FEARATE,
                        "indicator": item.old.TABLE.IND,
                        "feaCode": item.old.TABLE.FEACODE
                    });

                    maxFEAper = (maxFEAper == 75 || item.old.TABLE.IND == "O") ? 75 : 15;
                    totalFEAPer = numeral(totalFEAPer).add(parseFloat(item.old.TABLE.FEARATE)).value();

                    if (item.old.TABLE.FEACODE != "0" && item.old.TABLE.FEACODE != "") {
                        let newClause = { clauseCode: item.old.TABLE.FEACODE, description: item.old.TABLE.DESCRIPTION, isDefaultClause: 'Y' };
                        prms.comp.riskObj.clauses.clause.push(newClause);
                    }
                    prms.comp.riskObj.FEA.FEAeq = prms.comp.removeAryDuplicates(prms.comp.riskObj.FEA.FEAeq, "code");//new code to remove duplicate FEA.
                    prms.comp.riskObj.clauses.clause = prms.comp.removeAryDuplicates(prms.comp.riskObj.clauses.clause, "clauseCode");//new code to remove duplicate Clauses.
                    //}
                } else {
                    isExcludedItems = true;
                    excludedClausesList.push(item.old.TABLE.VALUE);
                }
            }
            prms.comp.riskObj.FEAPercentage = totalFEAPer;
            prms.comp.resetBasicRate(prms.comp.riskObj.basicRate);//new code
            if (prms.comp.headerInfo.VPMSProduct == "Y" && prms.comp.riskObj.fireItems.fireItems.length > 0) {
                prms.comp.coverComp.resetAllPremiumInfo("", prms.comp.riskObj.fireItems.fireItems[0]);
            }
        }

        if (isExcludedItems && !prms.comp.headerInfo.disableFEAInfo) {
            prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "There are some Excluded items in selected FEA list. List is : " + excludedClausesList, -1));
        }


		/* existing code
		for ( let item of listFEA ) {
            if(!prms.comp.riskObj.FEA.FEAeq)
                prms.comp.riskObj.FEA.FEAeq = [];			
			
			prms.comp.riskObj.FEA.FEAeq.push({
				"code" : item.old.TABLE.VALUE,
				"description" : item.old.TABLE.DESCRIPTION
			});
		} */
    }

    removeFEAList(idx: number) {
        if (this.headerInfo.disableFEAInfo) {
            this.riskObj.FEA.FEAeq.splice(idx, 1);
            return;
        }

        let totalFEAPer: number = 0;
        this.riskObj.FEA.FEAeq.splice(idx, 1);

        // removing related clause items.
        this.riskObj.clauses.clause.splice(idx, 1);

        //totalFEAPer = this.riskObj.FEAPercentage;
        for (let item of this.riskObj.FEA.FEAeq) {
            if (item.feaRate != undefined && item.feaRate != "")
                totalFEAPer = numeral(totalFEAPer).add(parseFloat(item.feaRate)).value();
        }
        this.riskObj.FEAPercentage = totalFEAPer;
        this.resetBasicRate(this.riskObj.basicRate);//new code
        if (this.headerInfo.VPMSProduct == "Y" && this.riskObj.fireItems.fireItems.length > 0) {
            this.coverComp.resetAllPremiumInfo("", "")
        }
    }

    validateFEAClauses() {
        let excludedClausesList: any = [];
        let isExcludedItems: boolean = false;

        if (this.riskObj.FEA.FEAeq.length > 0) {
            let newArr = [];
            for (let item of this.riskObj.FEA.FEAeq) {
                newArr = newArr.concat(item["code"].trim());
            }
            let feaCodes = "'" + newArr.toString().replace(/,/g, "\',\'") + "'";

            let request: GetLOVData = new GetLOVData();
            request.BRANCH = 'ALL';
            request.LOB = 'FIRE';
            request.BUSINESS_FUNCTION = 'NEW BUSINESS';
            request.PRODUCT = 'ALL';
            request.OPERATION = 'NEW';
            request.FORM_NAME = 'FIRE';
            request.FORM_FIELD_NAME = 'FEACLAUSES_LIST';
            request.FIELD_TYPE = 'LOV';
            request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
            request.ADVANCE_CONFIG_XML.FILTERS = new Filter();
            request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push(
                { "@FIELD_NAME": 'RTRIM(LTRIM(ZFIREQ))', "@FIELD_VALUE": feaCodes, '@OPERATION': 'IN', '@CONDITION': 'AND' },
                { "@FIELD_NAME": 'DESCITEM', "@FIELD_VALUE": "E" + this.riskObj.riskType, '@OPERATION': 'STARTSWITH', '@CONDITION': 'AND' }
            );
            this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.feaClausesInfoSuccessHandler, this.feaClausesInfoErrorHandler, false, { comp: this });

            // validate excludedItems with FEA item code.
            if (this.excludedItemsArr.length > 0) {
                for (let item of this.riskObj.FEA.FEAeq) {
                    if (item.feaCode != undefined && this.excludedItemsArr.indexOf(item.feaCode) != -1) {
                        isExcludedItems = true;
                        excludedClausesList.push(item.feaCode);
                    }
                }
            }
        }

        if (isExcludedItems) {
            this._alertMsgService.add(new AlertMessage(AlertMessage.WARN, "There are some Excluded items in selected FEA list. List is : " + excludedClausesList, -1));
        }
    }

    feaClausesInfoSuccessHandler(response, prms) {
        if (response.tuple) {
            // fill excludedItems list
            let ary = [];
            if (response.tuple != null && !Array.prototype.isPrototypeOf(response.tuple)) {
                ary = [response.tuple];
            } else {
                ary = response.tuple;
            }
            for (let item of ary) {
                let tempList = item.old.TABLE.FEACLAUSES.split(",");
                if (tempList != "" && prms.comp.excludedItemsArr.indexOf(item.old.TABLE.FEACLAUSES) == -1) {
                    if (item.old.TABLE.FEACLAUSES.length > 0) {
                        for (let subItem of tempList)
                            prms.comp.excludedItemsArr.push(subItem);
                    } else {
                        prms.comp.excludedItemsArr.push(item.old.TABLE.FEACLAUSES);
                    }
                }
            }
        }
    }

    feaClausesInfoErrorHandler(response, status, errorText, prms) {
        prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, response.responseJSON.faultstring.text, -1));
    }

    findFEADetailsDisableInfo() {
        this.headerInfo.disableFEAInfo = true;
        this.headerInfo.disableDDInfo = true;
        let request: GetLOVData = new GetLOVData();
        request.BRANCH = 'ALL';
        request.LOB = 'FIRE';
        request.BUSINESS_FUNCTION = 'NEW BUSINESS';
        request.PRODUCT = 'ALL';
        request.OPERATION = 'NEW';
        request.FORM_NAME = 'FIRE';
        request.FORM_FIELD_NAME = 'FEAACTIVATION_INFO';
        request.FIELD_TYPE = 'LOV';
        request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        request.ADVANCE_CONFIG_XML.FILTERS = new Filter();
        request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push(
            { "@FIELD_NAME": 'ITEMITEM', "@FIELD_VALUE": "'ZFEARATE','ZDDCT'", '@OPERATION': 'IN', '@CONDITION': 'AND' },
            { "@FIELD_NAME": 'SUBSTRING(GENAREA,1,8)', "@FIELD_VALUE": moment(new Date(), "YYYY-MM-DD").format("YYYYMMDD"), '@OPERATION': 'LT', '@CONDITION': 'AND' }
        );
        this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.feaDeatilsInfoSuccessHandler, this.feaDeatilsInfoErrorHandler, false, { comp: this });
    }

    feaDeatilsInfoSuccessHandler(response, prms) {
        if (response.tuple) {
            let ary = [];
            if (response.tuple != null && !Array.prototype.isPrototypeOf(response.tuple)) {
                ary = [response.tuple];
            } else {
                ary = response.tuple;
            }

            for (let item of ary) {
                if (item.old.ITEMPF.ITEMITEM == "ZDDCT") {
                    prms.comp.headerInfo.disableDDInfo = false;
                }
                else if (item.old.ITEMPF.ITEMITEM == "ZFEARATE") {
                    prms.comp.headerInfo.disableFEAInfo = false;
                }
            }
        } else {
            prms.comp.headerInfo.disableFEAInfo = true;
            prms.comp.headerInfo.disableDDInfo = true;
        }
    }

    feaDeatilsInfoErrorHandler(response, status, errorText, prms) {
        prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, response.responseJSON.faultstring.text, -1));
    }

	/* findDeductablesDisableInfo() {
		this.headerInfo.disableDDInfo = true;
		let request:GetLOVData = new GetLOVData();
		request.BRANCH ='ALL';
		request.LOB = 'FIRE';
		request.BUSINESS_FUNCTION = 'NEW BUSINESS';
		request.PRODUCT = 'ALL';
		request.OPERATION = 'NEW';
		request.FORM_NAME = 'FIRE';        
		request.FORM_FIELD_NAME = 'FEAACTIVATION_INFO';
		request.FIELD_TYPE = 'LOV';
		request.ADVANCE_CONFIG_XML= new SearchAdvancedConfig(); 
		request.ADVANCE_CONFIG_XML.FILTERS = new Filter();		
		request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push(
			{"@FIELD_NAME":'ITEMITEM',"@FIELD_VALUE":'ZDDCT' ,'@OPERATION':'EQ','@CONDITION':'AND'},
			{"@FIELD_NAME":'SUBSTRING(GENAREA,1,8)',"@FIELD_VALUE":moment(new Date(), "YYYY-MM-DD").format("YYYYMMDD") ,'@OPERATION':'LT','@CONDITION':'AND'}
		);
		this._soapService.callCordysSoapService("GetLOVData","http://schemas.opentext.com/lovhandler/v1.0", request , this.deductablesInfoSuccessHandler, this.feaDeatilsInfoErrorHandler, false, {comp:this});
	}

	deductablesInfoSuccessHandler(response, prms){
		if(response.tuple){
			prms.comp.headerInfo.disableDDInfo = false;
		} else {
			prms.comp.headerInfo.disableDDInfo = true;
		}
	} */

    // SAF MYS-2018-0666 start
    onChangeDDInfo(event) {
        if (this.headerInfo.disableDDInfo == false && this.riskObj.deductible != undefined && this.riskObj.deductible != "" && this.headerInfo.targetSumInsured != undefined && this.headerInfo.targetSumInsured != 0) {
            if (["10", "11", "12"].indexOf(this.riskObj.PIAMCode.substring(0, 2)) >= 0) {
                if (this.riskObj.fireItems.fireItems.length > 0) {
                    for (let i = 0; i < this.riskObj.fireItems.fireItems.length; i++) {
                        this.coverComp.setPremium(this.riskObj.fireItems.fireItems[i]);
                        //this.coverComp.getPremPercentage1(this.riskObj.deductible,this.riskObj.fireItems.fireItems[i]);
                    }
                }
            } else {
                if (this.riskObj.fireItems.fireItems.length > 0) {
                    for (let i = 0; i < this.riskObj.fireItems.fireItems.length; i++) {
                        this.coverComp.setPremium(this.riskObj.fireItems.fireItems[i]);
                        //this.coverComp.getPremPercentage1(this.riskObj.deductible,this.riskObj.fireItems.fireItems[i]);
                    }
                }
            }
        }
    }
    // SAF MYS-2018-1249 start
    setWCClausesRate(perilRate) {
        this.riskObj.wcRate = perilRate;
        if (this.coverComp != null) {
            this.coverComp.resetWCRate(perilRate);
        }
    }

    onChangeRewiringYear(event) {
        if (event.target.value != undefined && event.target.value != "" && moment(event.target.value, "YYYY").format("YYYY") > moment(this.headerInfo.effectiveDate, "YYYY-MM-DD").format("YYYY")) {
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Rewiring Year Shouldn't be greater than Effective Year.", -1));
        }
    }

    getTotalByProperty(prop, ary, format: string) {
        let total = 0;
        for (let eachItem of ary) {
            if (eachItem[prop] != null && eachItem[prop] != "")
                total = total + parseFloat(numeral(eachItem[prop]).value());
        }
        if (format != null)
            return numeral(numeral(total).format(format)).value();
        else
            return total;
    }

    fetchDefaultWarrantyClauses(wcCodes) {
        let request: GetLOVData = new GetLOVData();
        request.BRANCH = 'ALL';
        request.LOB = 'FIRE';
        request.BUSINESS_FUNCTION = 'NEW_BUSINESS';
        request.PRODUCT = 'ALL';
        request.OPERATION = 'ALL';
        request.FORM_NAME = 'FIRE';
        request.FORM_FIELD_NAME = 'WarrantyClauses';
        request.FIELD_TYPE = 'LOOKUP';
        request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        request.ADVANCE_CONFIG_XML.FILTERS = new Filter();
        request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push(
            { "@FIELD_NAME": 'RISKTYP', "@FIELD_VALUE": this.riskObj.riskType, '@OPERATION': 'EQ', '@CONDITION': 'AND' },
            { "@FIELD_NAME": 'ITMFRM', "@FIELD_VALUE": moment(this.headerInfo.effectiveDate, "YYYY-MM-DD").format("YYYYMMDD"), '@OPERATION': 'LT', '@CONDITION': 'AND' },
            { "@FIELD_NAME": 'ITMTO', "@FIELD_VALUE": moment(this.headerInfo.effectiveDate, "YYYY-MM-DD").format("YYYYMMDD"), '@OPERATION': 'GT', '@CONDITION': 'AND' },
            { "@FIELD_NAME": 'CLAUSECODE', "@FIELD_VALUE": wcCodes, '@OPERATION': 'IN', '@CONDITION': 'AND' }
        );
        this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.getDefaultWCSuccessHandler, this.handleError, false, { comp: this });
    }
    getDefaultWCSuccessHandler(response, prms) {
        //remove default warranty clauses for PIAM code
        prms.comp.riskObj.warrantyClassCodes.warrantyClassCode = prms.comp.riskObj.warrantyClassCodes.warrantyClassCode.filter((item) => item.isDefaultWCClause != "Y");
        prms.comp.riskObj.fireItems.fireItems.forEach(item => {
            item.wcClassCodes.warrantyClassCode = item.wcClassCodes.warrantyClassCode.filter((item) => item.isDefaultWCClause != "Y");
        });
        let ary = [];
        if (response.tuple != null && !Array.prototype.isPrototypeOf(response.tuple)) {
            ary = [response.tuple];
        }
        else if (response.tuple != null) {
            ary = response.tuple;
        }
        for (let item of ary) {
            if (!prms.comp.riskObj.warrantyClassCodes.warrantyClassCode)
                prms.comp.riskObj.warrantyClassCodes.warrantyClassCode = [];
            prms.comp.riskObj.warrantyClassCodes.warrantyClassCode.push({
                "classCode": item.old.TABLE.CLAUSECODE,
                "description": item.old.TABLE.HEAD,
                "rate": numeral(item.old.TABLE.RATE).format(prms.comp.wcRateFormat),
                "nature": item.old.TABLE.NATURE_01,
                "overrideInd": item.old.TABLE.ZOVRSI,
                "disableItem": (item.old.TABLE.NATURE_01 == '**') ? 'Y' : 'N',
                "amount": "0.00",
                "unFormattedAmount": "0",
                "coverItems": [],
                "prlPRT": item.old.TABLE.ZPRLPRT,
                "overrideIndRate": item.old.TABLE.ZOVRIND,
                "isDefaultWCClause": 'Y'
            });
        }
        prms.comp.riskObj.warrantyClassCodes.warrantyClassCode = prms.comp.removeAryDuplicates(prms.comp.riskObj.warrantyClassCodes.warrantyClassCode, "classCode");
        prms.comp.setWCClausesRate(prms.comp.getTotalByProperty("rate", prms.comp.riskObj.warrantyClassCodes.warrantyClassCode, "0,00.00"));
    }
    removeAryDuplicates(ary, code) {
        if (!Array.prototype.isPrototypeOf(ary)) {
            ary = [ary];
        }
        const uniqueArray = ary.filter((i, index) => {
            return index == ary.findIndex(obj => {
                return JSON.stringify(obj[code]) == JSON.stringify(i[code]);
            });
        });
        return uniqueArray;
    }
    onChangeRateBasisInd(evt) {
        this.riskObj.constructionClassInd = (evt.target.value == 'F') ? '' : this.riskObj.constructionClassInd;
    }
    //Start E1001
    onChangeRatingFlag(ratingFlag){
        if(ratingFlag == 'M')
        this.coverComp.setBasicRateValue();
    }
    //End E1001
    //End

    //SAF MYS-2019-0909
    checkProductIsLiveorValid() {
        let flag: string = "N";
        let replacefields = [
            { "@FIELD_NAME": 'RISKTYPE', "@FIELD_VALUE": "'%" + this.riskObj.riskType + "%'", '@OPERATION': 'PARAM' },
            { "@FIELD_NAME": 'LIVEDATE', "@FIELD_VALUE": moment().format( "YYYYMMDD" ), '@OPERATION': 'PARAM' }
        ];
        let request: GetLOVData = new GetLOVData().getLovRequest( "ALL", "FIRE", "NEW BUSINESS", "ALL", "NEW", "FIRE", "Fire_AddonLiveProducts", "LOV", [], {}, replacefields );
        var responsePromise = this._soapService.callCordysSoapService( "GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, null, null, false, { comp: this } );
        responsePromise.done( ( data ) => {
            let respArr: any;
            respArr = new AppUtil().getArray( data.tuple );
            flag = ( respArr.length == 2 ) ? "Y" : "N"; 
            /* if ( respArr.length == 1 && ( respArr[0].old.TABLE.TABLENAME == 'T7031' || respArr[0].old.TABLE.TABLENAME == 'T7274') ) {
                flag = "N";
            } */
            //flag = ( data.tuple ) ? "Y" : "N";
        });
        return flag;
    }
    //End

    private expandOrCollapseCovInfo() {
        this.covInfoCollapse = ( this.covInfoCollapse ) ? false : true;
    }

    private expandOrCollapseFEAInfo() {
        this.isFEAInfo = ( this.isFEAInfo ) ? false : true;
    }

    private expandOrCollapseAccReg() {
        this.accRegisterInfoCollapse = ( this.accRegisterInfoCollapse ) ? false : true;
    }
    
    private expandOrCollapseSurInfo() {
        this.surInfoCollapse = ( this.surInfoCollapse ) ? false : true;
    }

    private expandOrCollapseGenPage() {
        this.isGeneralPageCollapsed = ( this.isGeneralPageCollapsed ) ? false : true;
    }

    private expandOrCollapseCLInfo() {
        this.clCBIInfoCollapse = ( this.clCBIInfoCollapse ) ? false : true;
    }

    private expandOrCollapseRLInfo() {
        this.relatedCollapse = ( this.relatedCollapse ) ? false : true;
    }
}

export class AccumulationRegister {
    constructor(
        public accRegCode: string,
        public accRegDesc: string,
        public locality: string
    ) { }
}