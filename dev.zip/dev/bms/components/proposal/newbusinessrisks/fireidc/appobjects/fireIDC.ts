import { FinancialInterest } from '../../../../../../common/components/financialinterest/appobjects/financialInterest';
import { AppUtil } from '../../../../../../common/components/utility/apputil/app.util';
import { NBRisk } from '../../../appobjects/nbrisk';
import { RiskHelper } from '../../../appobjects/riskhelper';
import { PostedPrem } from '../../../proposalheader/appobjects/postedprem';
import { ReferredReason } from '../../../proposalheader/appobjects/referredreason';
import { IDCValidator } from '../../../validation/fire.validator';
import { AccRegister } from '../../appobjects/accregister'; // AccRegister code
import { Clause } from '../../appobjects/clause';
import { DeclarationDetails } from '../../appobjects/declarationDetails';
import { FireItems } from '../../appobjects/fireItems';
import { GSTDetails } from '../../appobjects/gstDetails';
import { Peril } from '../../appobjects/peril';
import { RateableClassCode } from '../../appobjects/RateableClassCode';
import { RateableClassIndicator } from '../../appobjects/RateableClassIndicator';
import { FireRelatedCases } from '../../appobjects/relatedCase';
import { SituationRiskDetails } from '../../appobjects/situationRiskDetails';
import { Survey } from '../../appobjects/survey';
import { WarrantyClassCode } from '../../appobjects/warrantyClassCodes';

export class FireIDC extends RiskHelper implements NBRisk {

    public sequenceNumber: string;
    public effectiveDate: string;
    public dateOfAttachment: string;
    public contractNumber: string;
    public contractType: string;
    public riskNumber: string;
    public riskType: string;
    public riskName: string;
    public ratingFlag: string = "A";
    public situation1: string;
    public situation2: string;
    public situationLine1: string;
    public situationLine2: string;
    public situationLine3: string;
    public situationLine4: string;
    public situationLine5: string;
    public situationLine6: string;
    public situationLine7: string;
    public situationLine8: string;
    public postCode: string;
    public city: string;
    public cityName: string;
    public PIAMCode: string;
    public PIAMCodeBREdit: string = "N";
    public PIAMDescription: string;
    public occupationCode: string = "99";
    public occupiedAs: string;
    public construction: string;
    public constructionName: string;
    public accumulationRegister: string;
    public locality: string;
    public RIRetentionCode: string;
    public RIMethod: string = "0";
    public RIMethodSys: string = "0";
    public RIRequired: string = "No";
    public isRIOverWrittenByUW: string = "N";
    public riskClassification: string = "Standard";
    public riskClassificationReason: string = '';
    public symRiskClassification: string = "";
    public riRiskClassification: string = "Standard";
    public piamRiskClassification: string = "Standard";
    public surveyDate: string;
    public surveyNumber: string;
    public rateBasis: string = "T";
    public rateBasisName: string = "";
    public storeys: string;
    public townClass: string = "1";
    public yearOfConstruction: string;
    public attached: string;
    public basicRate: number = 0;
    public basicRateOriginal: number = 0;
    public resurvey: string;
    public sprinkler: string;
    public FEAPercentage: number = 0;
    public deductible: string;
    public perilsRate: number = 0;
    public totalSI: number = 0;
    public totalPremium: number = 0;
    public FEADisAmount: number = 0;
    public FEARate: number = 0;
    public perils: Peril;
    public clauses: Clause;
    public rateableClassCode: RateableClassCode;
    public rateableClassIndicator: RateableClassIndicator;
    public terminationDate: string;
    public GP: string;
    public FI: string = 'N';
    public DS: string;
    public CL: string;
    public MI: string;
    public GT: string;
    public PR: string;
    public reviewDate: string;
    public fireItems: FireItems;
    public financialInterest: FinancialInterest;
    public GSTDetails: GSTDetails;
    public declarationDetails: DeclarationDetails;
    public situationOfRiskDetails: SituationRiskDetails;
    public FEA: FEA;
    public surveyor: string;
    public surveyType: string;
    public riskOccupationCode: string;
    public survey: Survey;
    public relatedCases: FireRelatedCases;
    public capitalSumInsured: number = 0;
    public totalGrossCapacity: number = 0;
    public relatedSumInsured: number = 0;
    public isSurveyNeeded: string = "N";
    public isSurveyNeededUI: string = "N";
    public isLeastPreferred: string = "N";
    public addRelatedCases: string = "N";
    public defaultClauses: Clause;
    public minimumPremium: number = 0;
    public originalTotalPremium: number = 0;
    public postedPremium: number = 0;
    public basePostedPremiumAdj: number = 0;
    public discountedPremium: number = 0;
    public rebate: number = 0;
    public rebateAmount: number = 0;
    public GST: number = 0; //6; //SAF MYS-2018-0629
    public gstAmount: number = 0;
    public identity: string = "";
    public identityFiller: string = "";
    public surveyStatus: string;
    public isSurveyDisabled: string = "N";
    public hasClaimExperience: string = "N";
    public basicPerils: Peril;
    public cslType: string;
    public cslAmount: number = 0;
    public isPOIConsidered: string = "N";
    public priority: string;
    public postedPremDetails: PostedPrem;
    public childRiskPath: string;
    public childRiskIdentity: string;
    public riskClassificationReasons: ReferredReason;
    public accRegister: AccRegister; // AccRegister code
    public gpText: string;
    public gpTextCount:string; //VK004
    public FEAMaxlist: number = 8; // SAF MYS-2018-0666
    public deductableRate: number = 0;// SAF MYS-2018-0666
    public deductableDisc: number = 0;// SAF MYS-2018-0666

    public SST: number = 0; //SST Code
    public sstAmount: number = 0;//SST Code
    public SSTLiveDate: string;//SST Code
    public GSTLiveDate: string;//SST Code
    public isGSTApplicable: boolean = true;//SST Code

    public warrantyClassCodes: WarrantyClassCode;// SAF MYS-2018-1249
    public wcRate: number = 0;// SAF MYS-2018-1249
    public rateBasisInd: string = "";// SAF MYS-2018-1249
    public rewiringYear: string;// SAF MYS-2018-1249
    public mdSI: string = "";// SAF MYS-2018-1249
    public constructionClassInd: string = "";// SAF MYS-2018-1249
    public isVPMS: string = 'N';
    public isRatingCommitteRateRequired: boolean = false;// SAF MYS-2018-1249

    public isValidBenefitPlan: string = "Y";//SAF MYS-2019-0909
    public isValidBenefitProduct: string = "N";//SAF MYS-2019-0909

    constructor() {
        super();
        this.financialInterest = new FinancialInterest();
        this.fireItems = new FireItems();
        this.clauses = new Clause();
        this.perils = new Peril();
        this.basicPerils = new Peril();
        this.GSTDetails = new GSTDetails();
        this.FEA = new FEA();
        this.rateableClassCode = new RateableClassCode();
        this.relatedCases = new FireRelatedCases();
        this.defaultClauses = new Clause();
        this.riskClassificationReasons = new ReferredReason();
        this.accRegister = new AccRegister(); // AccRegister code
        this.warrantyClassCodes = new WarrantyClassCode();// SAF MYS-2018-1249
    }

    public getInstance(valObj: FireIDC) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
            this.perils = new Peril().getInstance(valObj.perils);
            this.basicPerils = new Peril().getInstance(valObj.basicPerils);
            this.clauses = new Clause().getInstance(valObj.clauses);
            this.rateableClassCode = new RateableClassCode().getInstance(valObj.rateableClassCode);
            this.fireItems = new FireItems().getInstance(valObj.fireItems);
            if (valObj.FI == "Y") {
                this.financialInterest = new FinancialInterest().getInstance(valObj.financialInterest);
            }
            this.GSTDetails = new GSTDetails().getInstance(valObj.GSTDetails);
            if (valObj.isSurveyNeeded == "Y") {
                this.survey = new Survey().getInstance(valObj.survey);
            }
            if (valObj.addRelatedCases == "Y") {
                this.relatedCases = new FireRelatedCases().getInstance(valObj.relatedCases);
            }
            this.defaultClauses = new Clause().getInstance(valObj.defaultClauses);
            if (this.riskClassificationReasons != undefined && !AppUtil.isEmpty(this.riskClassificationReasons, true))
                this.riskClassificationReasons.refresh(valObj.riskClassificationReasons);
            else
                this.riskClassificationReasons = new ReferredReason();
            this.FEA = new FEA().getInstance(valObj.FEA);
            this.accRegister = new AccRegister().getInstance(valObj.accRegister); // AccRegister code
            this.warrantyClassCodes = new WarrantyClassCode().getInstance(valObj.warrantyClassCodes);// SAF MYS-2018-1249
            if (valObj.isGSTApplicable != undefined && JSON.stringify(valObj.isGSTApplicable) != JSON.stringify("") && typeof (valObj.isGSTApplicable) == "string") {
                this.isGSTApplicable = Boolean(JSON.parse(valObj.isGSTApplicable));
            }
            if (valObj.isRatingCommitteRateRequired != undefined && JSON.stringify(valObj.isRatingCommitteRateRequired) != JSON.stringify("") && typeof (valObj.isRatingCommitteRateRequired) == "string") {
                this.isRatingCommitteRateRequired = Boolean(JSON.parse(valObj.isRatingCommitteRateRequired))
            }            

            this.isValidBenefitPlan = ( this.isValidBenefitPlan == "Y" ) ? "Y" : "N";//SAF MYS-2019-0909
        }
        return this;
    }

    public getNewInstanceByCriteria(criteria: any) {
        let riskType = criteria.riskType;
        if (riskType == "ECP") {
            this.occupationCode = "";
            // this.construction="3";
            this.RIRetentionCode = "D1E3";
            this.rateBasis = "T";
            this.ratingFlag = "A";
            this.yearOfConstruction = "2000";
            this.storeys = "1";
            this.riskClassification = "Referred";
            this.symRiskClassification = "Referred";
            this.riskClassificationReason = "Referred Product";
        }
        else if (riskType == "PP1") {
            this.occupationCode = "";
            this.rateBasis = "T";
        }
        return this;
    }

    public getValidator() {
        return new IDCValidator(this);
    }

    // SAF MYS-2018-1249 start
    public refershRiskObj(valObj: FireIDC) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
            this.perils = new Peril().getInstance(valObj.perils);
            this.basicPerils = new Peril().getInstance(valObj.basicPerils);
            this.clauses = new Clause().getInstance(valObj.clauses);
            this.rateableClassCode = new RateableClassCode().getInstance(valObj.rateableClassCode);
            this.fireItems = new FireItems().getInstance(valObj.fireItems);
            if (valObj.FI == "Y") {
                this.financialInterest = new FinancialInterest().getInstance(valObj.financialInterest);
            }
            this.GSTDetails = new GSTDetails().getInstance(valObj.GSTDetails);
            if (valObj.isSurveyNeeded == "Y") {
                this.survey = new Survey().getInstance(valObj.survey);
            }
            if (valObj.addRelatedCases == "Y") {
                this.relatedCases = new FireRelatedCases().getInstance(valObj.relatedCases);
            }
            this.defaultClauses = new Clause().getInstance(valObj.defaultClauses);
            if (this.riskClassificationReasons != undefined && !AppUtil.isEmpty(this.riskClassificationReasons, true))
                this.riskClassificationReasons.refresh(valObj.riskClassificationReasons);
            else
                this.riskClassificationReasons = new ReferredReason();
            this.FEA = new FEA().getInstance(valObj.FEA);
            this.accRegister = new AccRegister().getInstance(valObj.accRegister); // AccRegister code
            this.warrantyClassCodes = new WarrantyClassCode().getInstance(valObj.warrantyClassCodes);// SAF MYS-2018-1249
            if (valObj.isGSTApplicable != undefined && JSON.stringify(valObj.isGSTApplicable) != JSON.stringify("") && typeof (valObj.isGSTApplicable) == "string") {
                this.isGSTApplicable = Boolean(JSON.parse(valObj.isGSTApplicable));
            }
            if (valObj.isRatingCommitteRateRequired != undefined && JSON.stringify(valObj.isRatingCommitteRateRequired) != JSON.stringify("") && typeof (valObj.isRatingCommitteRateRequired) == "string") {
                this.isRatingCommitteRateRequired = Boolean(JSON.parse(valObj.isRatingCommitteRateRequired))
            } 
        }
        return this;
    } //End
}

export class FEA {
    public FEAeq: FEADetail[] = [];

    constructor() { }

    public getInstance(valObj: FEA) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
            new AppUtil().handleArray(this, valObj, "FEAeq");
            for (let eachEq of this.FEAeq) {
                let cd = eachEq.code;
                while (cd.length < 5) {
                    cd = " " + cd;
                }
                eachEq.code = cd;
            }
        }
        return this;
    }
}

export class FEADetail {
    public code: string;
    public description: string;
    public exFEAClauses: any = [];  // SAF MYS-2018-0666 --start 
    public feaRate: string = "0";
    public indicator: string = "";
    public feaCode: string = ""; //End

    constructor() { }
}