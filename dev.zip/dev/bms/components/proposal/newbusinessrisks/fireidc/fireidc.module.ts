import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FIModule } from '../../../../../common/components/financialinterest/fi.module';
import { BasicUIModule } from '../../../../../common/components/utility/basicui.module';
import { MultiSelectModule } from '../../../../../common/components/utility/selectbox/multi-selectbox.module';
import { LovModule } from "../../../../../common/services/lovdropdown/lov.module";
import { AccRegisterModule } from '../uimodules/accregister.module';
import { ClausesModule } from '../uimodules/clauses.module';
import { FireCoverageModule } from '../uimodules/firecoverage.module';
import { FireSubCompModule } from '../uimodules/firesubcomp.module';
import { GSTModule } from '../uimodules/gst.module';
import { PerilModule } from '../uimodules/perils.module';
import { RateableClauseModule } from '../uimodules/rateableclause.module';
import { RelatedCaseModule } from '../uimodules/relatedcase.module';
import { SurveyModule } from '../uimodules/survey.module';
import { WarrantyClausesModule } from '../uimodules/warrantyclauses.module';
import { FireIDCRiskComponent } from './fireIDC.component';
import { GeneralPageModule } from '../uimodules/generalpage.module'; //VK004

@NgModule({
    imports: [
        CommonModule, FormsModule, ReactiveFormsModule,
        BasicUIModule, FIModule, LovModule, MultiSelectModule,
        SurveyModule, PerilModule, RateableClauseModule,
        ClausesModule, RelatedCaseModule, FireCoverageModule,
        FireSubCompModule, GSTModule, AccRegisterModule, WarrantyClausesModule, GeneralPageModule//VK004
    ],
    declarations: [FireIDCRiskComponent],
    exports: [FireIDCRiskComponent]
})
export class FireIDCRiskModule { }