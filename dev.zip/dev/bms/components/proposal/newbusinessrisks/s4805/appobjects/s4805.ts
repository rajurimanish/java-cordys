import { Clause } from '../../appobjects/clause';
import { DeclarationDetails } from '../../appobjects/declarationDetails';
import { FinancialInterest } from '../../../../../../common/components/financialinterest/appobjects/financialInterest';
import { GSTDetails } from '../../appobjects/gstDetails';
import { AppUtil } from '../../../../../../common/components/utility/apputil/app.util';
import { FireRelatedCases } from '../../appobjects/relatedCase';
import { Survey } from '../../appobjects/survey';
import { NBRisk } from '../../../appobjects/nbrisk';
import { PostedPrem } from '../../../proposalheader/appobjects/postedprem';
import { AccRegister } from '../../appobjects/accregister'; // AccRegister code
import { S4805Validator } from '../../../validation/s4805.validator';
import { RiskHelper } from '../../../appobjects/riskhelper';
import { ReferredReason } from '../../../proposalheader/appobjects/referredreason';

export class S4805 extends RiskHelper implements NBRisk {
    public sequenceNumber: string;
    public effectiveDate: string;
    public dateOfAttachment: string;
    public contractNumber: string;
    public contractType: string;
    public riskNumber: string;
    public riskType: string;
    public riskName: string;
    public ratingFlag: string = "A";
    public basisOfCover: string = "";
    public basisOfCoverDesc: string = "";
    public teritorialLimit: string = "";
    public situation1: string;
    public situation2: string;
    public situationLine1: string;
    public situationLine2: string;
    public situationLine3: string;
    public situationLine4: string;
    public situationLine5: string;
    public situationLine6: string;
    public situationLine7: string;
    public situationLine8: string;
    public postCode: string;
    public city: string;
    public cityName: string;
    public occupationCode: string;
    public occupationDesc: string;
    public occupancyCode: string = "99";
    public occupancyCodeDesc: string = "Others";
    // public occupiedAs: string="99";	
    public construction: string = "";
    public constructionName: string = "";
    public tLimit: string = "";
    public plan: string = "";
    public areaCode: string = "";
    public townClass: string = "1";
    public excessType: string = "";
    public excessPercentage: number;
    public excessAmount: number;
    public firePolicy: string;
    public RIRetentionCode: string = "";
    public accumulationRegister: string;
    // public locality: string;
    public localityRegister: string = "";
    public RFTRatePercentage: number = 0;
    public typeOfCover: string = "";
    public fullValue: number = 0;
    public ncdPercentage: string;
    public ncdAmount: number = 0;
    public minimumPremium: number = 0;
    public originalTotalPremium: number = 0;
    public postedPremium: number = 0;
    public basePostedPremiumAdj: number = 0;
    public discountedPremium: number = 0;
    public grossPremium: number = 0;
    public totalPremium: number = 0;
    public capitalSumInsured: number = 0;
    public relatedSumInsured: number = 0;
    public totalGrossCapacity: number = 0;
    public totalSI: number = 0;
    public GST: number = 0;//6; //SAF MYS-2018-0629
    public gstAmount: number = 0;
    public rebate: number = 0;
    public rebateAmount: number = 0;
    public terminationDate: string;

    public clauses: Clause;
    public riskCoverageDetails: RiskCoverageDetails;
    public relatedCases: FireRelatedCases;
    public financialInterest: FinancialInterest;
    public GSTDetails: GSTDetails;
    public defaultClauses: Clause;
    public survey: Survey;
    public mandatoryPolicies: MandatoryPolicyDetails;

    public riskClassification: string = "Standard";
    public riskClassificationReason: string = '';
    public symRiskClassification: string = "";
    public riRiskClassification: string = "Standard";
    public RIMethod: string = "0";
    public RIMethodSys: string = "0";
    public RIRequired: string = "No";
    public isRIOverWrittenByUW: string = "N";
    public isSurveyNeeded: string = "N";
    public addRelatedCases: string = "N";
    public hasClaimExperience: string = "N";
    public GT: string;
    public GP: string;
    public FI: string = 'N';
    public DS: string;
    public CL: string;
    public MI: string;
    public isLeastPreferred: string = "N";
    public identity: string = "";
    public identityFiller: string = "";
    public isPOIConsidered: string = "N";
    public priority: string;
    public postedPremDetails: PostedPrem;
    public accRegister: AccRegister; // AccRegister code

    public gpText: string;
    public gpTextCount:string;//VK004
    public childRiskPath: string;
    public childRiskIdentity: string;
    public riskClassificationReasons: ReferredReason;

    public piamRiskClassification: string;
    public occRiskClassification: string;
    public SST: number = 0; //SST Code
    public sstAmount: number = 0;//SST Code
    public SSTLiveDate: string;//SST Code
    public GSTLiveDate: string;//SST Code
    public isGSTApplicable: boolean = true;//SST Code
    constructor() {
        super();
        this.riskCoverageDetails = new RiskCoverageDetails();
        this.clauses = new Clause();
        this.financialInterest = new FinancialInterest();
        this.GSTDetails = new GSTDetails();
        this.relatedCases = new FireRelatedCases();
        this.mandatoryPolicies = new MandatoryPolicyDetails();
        this.accRegister = new AccRegister(); // AccRegister code		
        this.riskClassificationReasons = new ReferredReason();
    }

    public getInstance(valObj: S4805) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
            this.riskCoverageDetails = new RiskCoverageDetails().getInstance(valObj.riskCoverageDetails);
            this.clauses = new Clause().getInstance(valObj.clauses);
            if (valObj.FI == "Y") {
                this.financialInterest = new FinancialInterest().getInstance(valObj.financialInterest);
            }
            this.GSTDetails = new GSTDetails().getInstance(valObj.GSTDetails);
            if (valObj.isSurveyNeeded == "Y") {
                this.survey = new Survey().getInstance(valObj.survey);
            }
            if (valObj.addRelatedCases == "Y") {
                this.relatedCases = new FireRelatedCases().getInstance(valObj.relatedCases);
            }
            this.mandatoryPolicies = new MandatoryPolicyDetails().getInstance(valObj.mandatoryPolicies);
            this.accRegister = new AccRegister().getInstance(valObj.accRegister); // AccRegister code	
            this.riskClassificationReasons.refresh(valObj.riskClassificationReasons);
            if (valObj.isGSTApplicable != undefined && JSON.stringify(valObj.isGSTApplicable) != JSON.stringify("") && typeof (valObj.isGSTApplicable) == "string") {
                this.isGSTApplicable = Boolean(JSON.parse(valObj.isGSTApplicable));
            }
        }
        return this;
    }

    public getNewInstanceByCriteria(criteria: any) {
        let riskType = criteria.riskType;
        if (riskType == "AR") {
            this.RIRetentionCode = "AR";
            this.tLimit = "";
            this.plan = "";
        }
        else if (riskType == "BG") {
            // this.RIRetentionCode="BG";
            this.tLimit = "THE INSURED";
        }
        else if (riskType == "PG") {
            this.RIRetentionCode = "PG";
            this.tLimit = "Malaysia";
        }
        else if (riskType == "PP2") {
            this.RIRetentionCode = "PP2";
            this.tLimit = "Malaysia";
            this.plan = "1PP";
        }
        else if (riskType == "SR") {
            this.RIRetentionCode = "SR";
            this.riskClassification = "Referred";
            this.symRiskClassification = "Referred";
            this.riskClassificationReason = "Referred Product";
        }
        else if (riskType == "ARP") {
            this.RIRetentionCode = "ARP";
        }
        else if (riskType == "EP") {
            this.RIRetentionCode = "EP";
            this.hasClaimExperience = "";
        }
        else if (riskType == "ME") {
            this.RIRetentionCode = "ME02";
        }
        return this;
    }

    public getValidator() {
        return new S4805Validator(this);
    }
}

export class RiskCoverageDetails {

    public riskCoverage: RiskCoverage[] = [];

    public getInstance(valObj: RiskCoverageDetails) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
            new AppUtil().handleArray(this, valObj, "riskCoverage");
        }
        return this;
    }
}

export class RiskCoverage {
    public seqNumber: number;
    public interestInsured: string;
    public sumInsured: number;
    public rate: number;
    public load: number = 0;
    public premium: number;
    public premiumClass: string;
    public extraText: string = "";
    public etPostingStatus = "N";
    // public xtComments:XTComments;

    constructor() {
        // this.xtComments = new XTComments();
    }

    public getInstance(valObj: RiskCoverage) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
            //this.xtComments = new XTComments().getInstance(valObj.xtComments);
        }
        return this;
    }
}

export class MandatoryPolicyDetails {
    public mandatoryPolicy: MadatoryPolicy[] = [];

    public getInstance(valObj: MandatoryPolicyDetails) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
            new AppUtil().handleArray(this, valObj, "mandatoryPolicy");
        }
        return this;
    }
}

export class MadatoryPolicy {
    public seqNumber: number;
    public policyNumber: string;
    public effectiveDate: string;

    public getInstance(valObj: MadatoryPolicy) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
        }
        return this;
    }

}