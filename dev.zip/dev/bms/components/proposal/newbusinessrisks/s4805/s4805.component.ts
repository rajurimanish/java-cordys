/*
 * Change History:		
 * 
 * No      Date				Description												Changed By
 * ====    ==========		===========												==========
 * 
 * GA001   23/11/2018   MYS-2018-1441 - To default Premium Class 34C for EP policies	KGA
 * 
 * SR001   11/01/2019		MYS-2018-0211 : To enhancement the filtering criteria		VSR
 * 							for Fire Accum Code & Prompt message
 * YPK001 23/09/2019       MYS-2019-0675 Document Validation for Co-outwards            PKU1
 *                         case before sending to PPHO			
 * KA001   08/10/2019       MYS-2019-1024 - BMS Enhancement : AR screen to combine RAA  DKA
 *                          with Fire LOB
 */

import { Component, OnInit, ViewChild, ElementRef, EventEmitter, AfterViewInit, ViewContainerRef } from '@angular/core';
import { DCLInput, CustomDCLService } from '../../../../../common/services/customdcl.service';
import { LOV_Field, LOVDropDownService, SearchFilter } from "../../../../../common/services/lovdropdown/lovdropdown.service";
import { CordysSoapWService } from "../../../../../common/components/utility/cordys-soap-ws";
import { GetLOVData, SearchAdvancedConfig, Filter } from '../../../../../common/components/utility/search/search.requests';
import { ProposalHeader } from '../../proposalheader/appobjects/proposalheader';
import { AlertMessagesService } from '../../../../../common/components/utility/alertmessage/alertmessages.service';
import { AlertMessage } from '../../../../../common/components/utility/alertmessage/alertmessages.model';
import { S4805, RiskCoverage, MadatoryPolicy } from './appobjects/s4805';
import { Clause } from "../appobjects/clause";
import { Survey } from '../appobjects/survey';
import { FinancialInterest } from '../../../../../common/components/financialinterest/appobjects/financialInterest';
import { RelatedCaseComponent } from "../uimodules/relatedcase.component";
import { FireRelatedCases, RelatedCases } from '../appobjects/relatedCase';
import { ExtraTextDialogData } from "../dialogs/extratext.dialog.data";
// import {XTCommentDialogData} from "../dialogs/xtcomment.dialog.data";
import { ModalInput } from "../../../../../common/components/utility/modal/modal";
import { SearchInput } from "../../../../../common/components/utility/search/genericsearch";
import { BMSConstants } from '../../../common/constants/bms_constants';
import { CaseInfo } from '../../../../../common/components/appobjects/caseinfo';
import { PaginationModule } from '../../../../../common/components/utility/pagination/pagination.module';
import { PaginationPipe } from '../../../../../common/components/utility/pagination/filtertable.pipe';
import { FilterTableContentPipe } from '../../../../../common/components/utility/pagination/filtercontent.pipe';
import { ApplicationUtilService } from "../../../../../common/services/application.util.service";
import { BMSUtilService } from "../../../../services/bms.util.service";
import { AppUtil } from '../../../../../common/components/utility/apputil/app.util';
import { RiskClassificationService } from "../services/riskcls.service"; // added code for AccRegister
import { AccRegister } from '../appobjects/accregister';
import { BMSAppObjService } from '../../../../services/bmsappobj.service';
import { RIService } from '../services/ri.service';
import { ActivatedRoute } from '@angular/router';
import { ClausesComponent } from "../uimodules/clauses.component";

declare var jQuery: any;
declare var moment: any;
declare var numeral: any;
declare var Observer: any;

@Component({
    selector: 's4805-risk-component',
    templateUrl: 'app/bms/components/proposal/newbusinessrisks/s4805/s4805.template.html',
    inputs: ['riskObj', 'clientDetails', "headerInfo", "caseInfo"],
    outputs: ["onPremiumChange", "onRiskClsChange", "onRtngFlgChange"],
    providers: [RiskClassificationService]// added code for AccRegister
})

export class S4805Component implements OnInit {
    private el: HTMLElement;
    private clCBIInfoCollapse: boolean = true;
    private coverageInfoCollapse: boolean = false;
    private relatedCollapse: boolean = false;
    private surInfoCollapse: boolean = false;
    private mandPolDetCollapse: boolean = false;
    private accRegisterInfoCollapse: boolean = false;
    private isGeneralPageCollapsed: boolean = false;

    public riskObj: S4805;
    public headerInfo: ProposalHeader;
    public AccRegList: AccumulationRegister[];
    public caseInfo: CaseInfo;

    private plans = [];
    @ViewChild(ClausesComponent) private clausesComp: ClausesComponent;
    @ViewChild(RelatedCaseComponent) relatedComp: RelatedCaseComponent;
    @ViewChild('xtModal', { read: ViewContainerRef }) contentArea: ViewContainerRef;
    @ViewChild('mandPolicies', { read: ViewContainerRef }) mandatoryPolicyArea: ViewContainerRef;

    public accRegCtrl: any;

    public siFormat: string = "0,00";
    public premiumFormat: string = "0,00.00";
    public rateFormat: string = "0.00000";
    public percentFormat: string = "0.00";
    private isPP2Risk: string = "N";
    private isExcessPercentMandatory: string = 'N';
    private isExcessAmountMandatory: string = 'N';

    public position = 1;
    public sizeObj = { length: 0, orglength: 0 };
    public contentSizeObs: any;
    public itemPerPage = 3;
    public maxPageCount = 10;
    private piamCodes = [];
    private isUnderWriter = "N";
    private isRIMethodEditable = "Y";
    private isUsedMandatoryPolicy = false;
    public emailType: string;
    public tempSysReferred: boolean;
    public tempAccuSysReferred: boolean;

    onPremiumChange = new EventEmitter<any>();
    onRiskClsChange = new EventEmitter<any>();
    onRtngFlgChange = new EventEmitter<any>();
    constructor(private lovDropDownService: LOVDropDownService, private _soapService: CordysSoapWService, public _alertMsgService: AlertMessagesService, el: ElementRef, public dcl: CustomDCLService, private _appUtilService: ApplicationUtilService, private _bmsUtilService: BMSUtilService, public riskClassificationService: RiskClassificationService, private _appObjService: BMSAppObjService, private _riService: RIService, private _activatedRoute: ActivatedRoute) {
        this.el = el.nativeElement;
    }

    ngOnInit() {
        this.handleSingleRecord();
        this.populateLOVs();

        if (this.riskObj.riskType == 'PP2') this.isPP2Risk = 'Y';

        this._appUtilService.isUnderWriterUser().subscribe((data) => {
            this.isUnderWriter = data;
            this.setRIMethodEditableFlag();
        });

        // AccRegister code
        if (this.riskObj.accRegister == undefined) {
            this.riskObj.accRegister = new AccRegister();
        } else {
            this.tempSysReferred = this.riskObj.accRegister.isSystemReferred;
            this.tempAccuSysReferred = this.riskObj.accRegister.isAccuSystemReferredFlag;
        }

        //SST Code
        if (["MyTasks", "MyDrafts"].indexOf(this._activatedRoute.snapshot.params['component']) >= 0 || Object.keys(this._activatedRoute.snapshot.params).length == 0) {
            let respObj = this._bmsUtilService.getTAXDetails();
            if (respObj != undefined && respObj != "") {
                this.headerInfo.SSTTaxRate = Number(respObj[0].old.ITEMPF.GST);
                this.headerInfo.GSTTaxRate = Number(respObj[1].old.ITEMPF.GST);

                this.riskObj.SST = Number(this.headerInfo.SSTTaxRate);
                this.riskObj.GST = Number(this.headerInfo.GSTTaxRate);
            }

            this.headerInfo = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo;
            this.riskObj.SSTLiveDate = (this.riskObj.SSTLiveDate == undefined) ? this.headerInfo.SSTLiveDate : this.riskObj.SSTLiveDate;
            if (this.riskObj.SSTLiveDate == undefined || this.riskObj.SSTLiveDate == "") {
                let tempRespObj = this._bmsUtilService.getLiveDate();
                this.riskObj.GSTLiveDate = tempRespObj[0].old.ITEMPF.LIVEDATE;
                this.riskObj.SSTLiveDate = tempRespObj[1].old.ITEMPF.LIVEDATE;
                if (this.headerInfo.SSTLiveDate == undefined || this.headerInfo.SSTLiveDate == "") {
                    this.headerInfo.SSTLiveDate = this.riskObj.SSTLiveDate;
                }
                if (this.headerInfo.GSTLiveDate == undefined || this.headerInfo.GSTLiveDate == "") {
                    this.headerInfo.GSTLiveDate = this.riskObj.GSTLiveDate;
                }
            }
            if (moment(this.headerInfo.effectiveDate, "YYYY-MM-DD").format("YYYYMMDD") >= moment(this.riskObj.SSTLiveDate, "YYYY-MM-DD").format("YYYYMMDD")) {
                this.riskObj.isGSTApplicable = false;
            } else {
                this.riskObj.isGSTApplicable = true;
            }
        }
        //End
    }
    //START YPK001
    ngAfterViewInit() {
        let rIndex = 0;
        if ((this.headerInfo.CoInsurance == 'Y' && this.riskObj.riskNumber == '1') && (["MyTasks", "MyDrafts"].indexOf(this._activatedRoute.snapshot.params['component']) >= 0 || Object.keys(this._activatedRoute.snapshot.params).length == 0)) {
            if (this.headerInfo.coInsuranceDetails.coInsurance.length == 1) {
                if (!(this.headerInfo.coInsuranceDetails.coInsurance[0].coInsuranceindicator == 'L' && this.headerInfo.coInsuranceDetails.coInsurance[0].sharePercentage == '100')) {
                    rIndex = this.riskObj.clauses.clause.map(function (item) { return item.clauseCode; }).indexOf("COIN");
                    if (rIndex == -1)
                        this.setClauses(["COIN"], false);
                }
            }
            else {
                rIndex = this.riskObj.clauses.clause.map(function (item) { return item.clauseCode; }).indexOf("COIN");
                if (rIndex == -1)
                    this.setClauses(["COIN"], false);
            }
        }
    }
    setClauses(clausesList, flag) {
        if (this.clausesComp)
            this.clausesComp.addClause(clausesList, '', flag);
    }
    //END YPK001

    populateLOVs() {
        if (this.riskObj.riskType != 'AR') { //MYS-2019-1024 - KA001
            this.lovDropDownService.createLOVDataList(["basisOfCover", "Occupation", "construction", "riCode", "excessType", "planDetails", "NCDPercentage", "tLimit", "piamCodesList"]);
        } else {
            this.lovDropDownService.createLOVDataList(["basisOfCover", "Occupation", "construction", "excessType", "planDetails", "NCDPercentage", "tLimit", "piamCodesList"]);
        }

        let riskFilter = (this.riskObj.riskType.length == 2) ? this.riskObj.riskType + ' ' : this.riskObj.riskType;
        let excessTypeFilterDetails = [new SearchFilter("DESCITEM", riskFilter, "STARTSWITH", "AND")];
        let excessTypeFilterNodes = this.lovDropDownService.createFilter(excessTypeFilterDetails);

        let riCodeFilterNodes = [];
        if (this.riskObj.riskType == 'BG') {
            let riCodeFilterDetails = [new SearchFilter("DESCITEM", "'BGA','BGB','BGC'", "IN", "AND")];
            riCodeFilterNodes = this.lovDropDownService.createFilter(riCodeFilterDetails);
        }

        let lovFields = [//MYS-2019-1024 - KA001
            new LOV_Field("ALL", "ALL", "NEW BUSINESS", "ALL", "NEW", "S4805", "Basis of Cover", "LOV", [], "DESCPF", "basisOfCover", null),
            new LOV_Field("ALL", "FIRE", "CLAIMS", "ALL", "NEW", "CLAIMS_FIRE", "Construction Code", "LOV", [], "DESCPF", "construction", null), new LOV_Field("ALL", "MIS", "NEW BUSINESS", "ALL", "ALL", "ALL", "Excess Type", "LOV", excessTypeFilterNodes, "T9107", "excessType", "callbackForExcessTypesLoad")
        ];
        if (this.riskObj.riskType != 'AR') {//MYS-2019-1024 - KA001
            lovFields.push(new LOV_Field("ALL", "MOTOR", "NEW BUSINESS", "ALL", "NEW", "PRIVATE_MOTOR", "RI Retention Code", "LOV", riCodeFilterNodes, "DESCPF", "riCode", null));
        }

        if (this.riskObj.riskType == 'AR' || this.riskObj.riskType == 'PP2' || this.riskObj.riskType == 'ME') {
            let polEndDate = ApplicationUtilService.getFormattedDate(this.headerInfo.endDate, "YYYY-MM-DD", "YYYYMMDD");
            let piamCodesFilterDetails = [new SearchFilter("A.DESCITEM", riskFilter, "STARTSWITH", "AND"),
            new SearchFilter("A.ITMFRM", polEndDate, "LTEQ", "AND"),
            new SearchFilter("A.ITMTO", polEndDate, "GTEQ", "AND")];
            let piamCodesFilterNodes = this.lovDropDownService.createFilter(piamCodesFilterDetails);

            lovFields.push(new LOV_Field("ALL", "FIRE", "NEW BUSINESS", "ALL", "ALL", "ALL", "PIAM Codes List", "LOV", piamCodesFilterNodes, "T9115", "piamCodesList", "callbackForPIAMCodesList"));

        } else {
            lovFields.push(new LOV_Field("ALL", "MIS", "ALL", "ALL", "ALL", "ALL", "Occupation", "LOV", excessTypeFilterNodes, "T9109", "Occupation", null));
        }

        if (this.riskObj.riskType == 'PP2') {
            let _polEndDate = ApplicationUtilService.getFormattedDate(this.headerInfo.endDate, "YYYY-MM-DD", "YYYYMMDD");
            let planFilterDetails = [new SearchFilter("DESCITEM", this.riskObj.riskType, "STARTSWITH", "AND")];
            let planFilterNodes = this.lovDropDownService.createFilter(planFilterDetails);

            lovFields.push(new LOV_Field("ALL", "PA", "NEW BUSINESS", "ALL", "NEW", "ALL", "Plan Details", "LOV", planFilterNodes, "T7072", "planDetails", "callbackForPlanDataLoad"));
            lovFields.push(new LOV_Field("ALL", "MIS", "NEW BUSINESS", "ALL", "ALL", "ALL", "NCD Percentage", "LOV", planFilterNodes, "DESCPF", "NCDPercentage", null));

        }
        else if (this.riskObj.riskType == 'ARP') {
            lovFields.push(new LOV_Field("ALL", "ALL", "NEW BUSINESS", "ALL", "ALL", "ALL", "Territorial Limit", "LOV", [], "T9116", "tLimit", null));
        }

        // new LOV_Field("ALL", "ALL", "NEW BUSINESS", "ALL", "NEW", "S4805", "Excess Type", "LOV", [], "DESCPF", "excessType",null),
        // new LOV_Field("ALL", "FIRE", "NEW BUSINESS", "ALL", "NEW", "FIRE_IDC", "RiskOccupationCode", "LOV", [] , "DESCPF", "piamcode",null),
        // new LOV_Field("ALL", "FIRE", "NEW BUSINESS", "ALL", "NEW", "FIRE_IDC", "PremiumClass", "LOV", riTypeSearchFilterNodes, "T4688", "premiumclass",null),

        if (this.riskObj.accumulationRegister != null && this.riskObj.accumulationRegister != "") {
            this.setAccumulationRegister();
        }

        this.lovDropDownService.util_populateLOV(lovFields, this);
    }

    callbackForPlanDataLoad(scopeObject) {
        let prvPlanCode = '';
        for (let planItem of scopeObject.lovDropDownService.lovDataList.planDetails) {
            if (planItem.VALUE != prvPlanCode)
                scopeObject.plans.push(planItem);
            prvPlanCode = planItem.VALUE;
        }

        if (scopeObject.riskObj.plan && (!scopeObject.riskObj.riskCoverageDetails || !scopeObject.riskObj.riskCoverageDetails.riskCoverage || scopeObject.riskObj.riskCoverageDetails.riskCoverage.length == 0)) {
            scopeObject.populateRiskCoverageDetails(scopeObject);
        }
    }

    callbackForPIAMCodesList(scopeObject) {
        for (let _rec of scopeObject.lovDropDownService.lovDataList.piamCodesList) {
            let hasPiamCode = scopeObject.piamCodes.some(_item => _item.VALUE === _rec.VALUE);
            if (!hasPiamCode) {
                scopeObject.piamCodes.push(_rec);
            }
        }

        if (scopeObject.piamCodes.length > 0) {
            scopeObject.sortArray(scopeObject.piamCodes, 'VALUE');
        }
        // scopeObject.populateConstructionClass();
        // scopeObject.populateTownClass();
    }

    onPIAMCodeChange(ev) {
        this.riskObj.occupationCode = ev.value;
        this.riskObj.occupationDesc = ev.record.LONGDESC;
        this.riskObj.piamRiskClassification = ev.record.REFERRED;
		/*if(this.riskObj.riskType != 'SR'){ // SR is always referred risk
			if(!ev.record.REFERRED || ev.record.REFERRED == 'N'){
				this.riskObj.symRiskClassification = "Standard";
			}
			else if(ev.record.REFERRED && ev.record.REFERRED == 'Y'){
				this.riskObj.symRiskClassification = "Referred";
			}
			else if(ev.record.REFERRED && ev.record.REFERRED == 'D'){
				this.riskObj.symRiskClassification = "Declined";
			}
			// added below code for SAF MYS-2018-0143 -- start
			else if(ev.record.REFERRED && ev.record.REFERRED == 'C'){
				this.riskObj.symRiskClassification = "ReferredCEO";
			}else if(ev.record.REFERRED && ev.record.REFERRED == 'R'){
				this.riskObj.symRiskClassification = "ReferredRHC";
			}//End
		*/

        this.handleRiskClassification(this);
        //}

        if (this.riskObj.riskType != 'ARP')
            this.setPIAMDependentFields();

    }

    onConstructionClsChange(ev) {
        this.riskObj.construction = ev.value;
        this.riskObj.constructionName = ev.record.DESCRIPTION;
        this.setPIAMDependentFields();
        this.handleRiskClassification(this);
    }

    setPIAMDependentFields() {
        if ((this.riskObj.riskType == "AR" || this.riskObj.riskType == "ME") && this.riskObj.occupationCode && this.riskObj.construction && this.riskObj.townClass) {
            let _piamRecord = this.lovDropDownService.lovDataList.piamCodesList.find(_item => (_item.VALUE === this.riskObj.occupationCode && _item.TOWNCLS === this.riskObj.townClass && _item.CONSTN === this.riskObj.construction));
            if (_piamRecord) {
                let _basicRate = _piamRecord.RATE;
                _basicRate = (_basicRate == null || _basicRate == "" || _basicRate == "0E-8") ? 0 : parseFloat("" + _basicRate);
                this.riskObj.RFTRatePercentage = numeral(_basicRate).format(this.rateFormat);
            }
            else
                this.riskObj.RFTRatePercentage = 0;
        }
    }

    populateRiskCoverageDetails(scopeObject) {
        let _grossPremium = 0;
        for (let _planItem of scopeObject.lovDropDownService.lovDataList.planDetails) {
            if (_planItem.VALUE == scopeObject.riskObj.plan) {
                let coverageItem = new RiskCoverage();
                coverageItem.seqNumber = scopeObject.riskObj.riskCoverageDetails.riskCoverage.length + 1;
                coverageItem.interestInsured = _planItem.COVER_DESC;
                coverageItem.sumInsured = _planItem.SUMIN;
                coverageItem.rate = _planItem.SRAT;
                coverageItem.load = _planItem.SLOA;
                coverageItem.premium = _planItem.GPDPREM;
                coverageItem.premiumClass = _planItem.SPRC;

                scopeObject.riskObj.riskCoverageDetails.riskCoverage.push(coverageItem);
                if (coverageItem.seqNumber == 1) {
                    scopeObject.riskObj.capitalSumInsured = _planItem.ZSORIG;
                }
                _grossPremium = _grossPremium + parseFloat("" + _planItem.GPDPREM);
            }
        }
        scopeObject.riskObj.grossPremium = numeral(numeral(_grossPremium).format(scopeObject.premiumFormat)).value();

        // scopeObject.riskObj.totalPremium = _grossPremium + parseFloat(""+scopeObject.riskObj.ncdAmount);
        scopeObject.setTotalPremium();
    }

    setPremium(coverItem) {
        let si: any = coverItem.sumInsured;
        let rate: any = coverItem.rate;
        let iLoad: any = coverItem.load;

        si = (si == null || si == "") ? 0 : si;
        rate = (rate == null || rate == "") ? 0 : parseFloat(rate);
        // iLoad  = (iLoad == null || iLoad == "") ? 0 : parseFloat(iLoad);
        if (si != 0 && rate != 0) {
            let cpremium = (si * (rate)) / 100;
            coverItem.premium = numeral(numeral(cpremium).format(this.premiumFormat)).value();
            // coverItem.premium = ((coverItem.premium * iLoad)/100) + coverItem.premium; 			
        } else {
            coverItem.premium = 0.00;
        }

        this.setTotalPremium();
    }

    setNcdAmount() {
        this.setTotalPremium();
    }

    setTotalPremium() {
        this.riskObj.totalSI = this.getTotalByProperty("sumInsured", this.riskObj.riskCoverageDetails.riskCoverage, null);
        if (this.riskObj.riskType != 'PP2') {
            this.riskObj.capitalSumInsured = this.riskObj.totalSI;
            this.riskObj.grossPremium = this.getTotalByProperty("premium", this.riskObj.riskCoverageDetails.riskCoverage, this.premiumFormat);

        }

        let ncdPerct = (this.riskObj.ncdPercentage == null || this.riskObj.ncdPercentage == "") ? 0 : parseFloat("" + this.riskObj.ncdPercentage);
        this.riskObj.ncdAmount = (ncdPerct > 0) ? (this.riskObj.grossPremium * ncdPerct / 100) : 0;

        let _basePremium = this.riskObj.grossPremium - this.riskObj.ncdAmount;
        this.riskObj.originalTotalPremium = numeral(numeral(_basePremium).format(this.premiumFormat)).value();

        this.riskObj.rebateAmount = numeral(numeral((parseFloat("" + numeral(_basePremium).value()) * parseFloat("" + this.riskObj.rebate)) / 100).format(this.premiumFormat)).value();

        let discountedPrem = numeral(numeral(parseFloat("" + numeral(_basePremium).value()) - parseFloat("" + numeral(this.riskObj.rebateAmount).value())).format(this.premiumFormat)).value();
        this.riskObj.discountedPremium = discountedPrem;

        //this.riskObj.gstAmount = (parseInt(""+this.riskObj.GST) > 0 && discountedPrem > 0)?numeral(numeral((discountedPrem*parseInt(""+this.riskObj.GST))/100).format(this.premiumFormat)).value():0; //SAF MYS-2018-0629

        //SST Code
        let tempGSTAmount = (parseInt("" + this.riskObj.GST) > 0 && discountedPrem > 0) ? numeral(numeral((discountedPrem * parseInt("" + this.riskObj.GST)) / 100).format(this.premiumFormat)).value() : 0;
        this.riskObj.gstAmount = (tempGSTAmount > 0) ? numeral(numeral(BMSUtilService.calculatePremiumAmount(tempGSTAmount, "G")).format(this.premiumFormat)).value() : 0;
        let tempSSTAmount = (parseInt("" + this.riskObj.SST) > 0 && discountedPrem > 0) ? numeral(numeral((discountedPrem * parseInt("" + this.riskObj.SST)) / 100).format(this.premiumFormat)).value() : 0;
        this.riskObj.sstAmount = (tempSSTAmount > 0) ? numeral(numeral(BMSUtilService.calculatePremiumAmount(tempSSTAmount, "S")).format(this.premiumFormat)).value() : 0;


        //let _totalPremium = parseFloat(""+numeral(discountedPrem).value()) + parseFloat(""+numeral(this.riskObj.gstAmount).value());
        let _totalPremium = parseFloat("" + numeral(discountedPrem).value()) + parseFloat("" + numeral(this.riskObj.gstAmount).value()) + parseFloat("" + numeral(this.riskObj.sstAmount).value());
        //End
        this.riskObj.totalPremium = numeral(numeral(_totalPremium).format(this.premiumFormat)).value();

        this.onPremiumChange.emit(this.riskObj.totalPremium);

        this.validateSumInsured();

    }

    validateSumInsured() {
        if (this.riskObj.RIRetentionCode && this.riskObj.isRIOverWrittenByUW == 'N') {
            this._bmsUtilService.getTotalGrossCapacity(this.riskObj.RIRetentionCode).subscribe((data) => this.compareSIWithTotGrossCap(data));

			/*let _totalGrossCapacity = this._bmsUtilService.getNetRetentionAmountDetails(this.riskObj.RIRetentionCode);
			_totalGrossCapacity = (!_totalGrossCapacity) ? 0 : parseFloat(""+_totalGrossCapacity);
			this.riskObj.totalGrossCapacity = _totalGrossCapacity;
			
			let _capitalSumInsured = parseFloat(""+this.riskObj.capitalSumInsured);
			
			if( _totalGrossCapacity > 0 && _capitalSumInsured > _totalGrossCapacity && (this.riskObj.RIMethod == null || this.riskObj.RIMethod == "" || parseFloat(""+this.riskObj.RIMethod) != 8) ){
				this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Capital Sum Insured is greater than Total Gross Capacity: "+_totalGrossCapacity+",  RI is Required." , 10000));
				
				this.riskObj.RIRequired = "Yes";
				this.riskObj.RIMethod = "8";
			} 
			else if(_capitalSumInsured <= _totalGrossCapacity){
				this.riskObj.RIRequired = "No";
				this.riskObj.RIMethod = this.riskObj.RIMethodSys;
			}*/
        }
        else
            this.setRIMethodEditableFlag();
    }

    compareSIWithTotGrossCap(totGrossCap) {

        let _totalGrossCapacity = (!totGrossCap) ? 0 : parseFloat("" + totGrossCap);
        this.riskObj.totalGrossCapacity = _totalGrossCapacity;

        let _capitalSumInsured = parseFloat("" + this.riskObj.capitalSumInsured);

        if (_totalGrossCapacity > 0 && _capitalSumInsured > _totalGrossCapacity && (this.riskObj.RIMethod == null || this.riskObj.RIMethod == "" || parseFloat("" + this.riskObj.RIMethod) != 8)) {
            this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Capital Sum Insured is greater than Total Gross Capacity: " + _totalGrossCapacity + ",  RI is Required.", 10000));

            this.riskObj.RIRequired = "Yes";
            this.riskObj.RIMethod = "8";
        }
        else if (_capitalSumInsured <= _totalGrossCapacity) {
            this.riskObj.RIRequired = "No";
            this.riskObj.RIMethod = this.riskObj.RIMethodSys;
        }
        this._riService.setRI().subscribe();
        this.setRIMethodEditableFlag();
    }

    getTotalByProperty(prop, ary, format: string) {
        let total = 0;
        for (let eachItem of ary) {
            if (eachItem[prop] != null && eachItem[prop] != "")
                total = total + parseFloat(numeral(eachItem[prop]).value());
        }
        if (format != null)
            return numeral(numeral(total).format(format)).value();
        else
            return total;
    }

    onChangePostCode(values) {
        this.clearAccReg();
        this.riskObj.city = values.record.SHORTDESC;
        this.riskObj.cityName = values.record.LONGDESC;
        this.setGST(values.value);
    }

    getPostCodeInfo(postcode) {
        this.riskObj.postCode = isNaN(parseInt(postcode)) ? postcode.toUpperCase() : postcode;
        if (this.riskObj.riskType === 'AR') {
            // Accumulation register code --start
            this.tempSysReferred = this.riskObj.accRegister.isSystemReferred;
            this.tempAccuSysReferred = this.riskObj.accRegister.isAccuSystemReferredFlag;
            this.riskObj.accRegister = new AccRegister();
            this.riskObj.accRegister.isSystemReferred = this.tempSysReferred;
            this.riskObj.accRegister.isAccuSystemReferredFlag = this.tempAccuSysReferred;

            //this.setReferredRiskFlag(false,"Standard",false);
            this.handleRiskClassification(this); // End
        }

        let request: GetLOVData = new GetLOVData().getRequest('ALL', 'FIRE', 'NEW BUSINESS', 'ALL', 'NEW', 'FIRE_IDC', 'PostCode', 'LOV');
        request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        request.ADVANCE_CONFIG_XML.FILTERS = new Filter();

        request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({ "@FIELD_NAME": 'DESCITEM', "@FIELD_VALUE": this.riskObj.postCode, '@OPERATION': 'EQ', '@CONDITION': 'AND' });
        this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.setPostCodeInfo, this.handleError, true, { comp: this, postCode: this.riskObj.postCode });
    }
    handleError(response, status, errorText, prms) {
        prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, response.responseJSON.faultstring.text, -1));
    }
    setAccReg(values) {
        // this.riskObj.locality = values.record.locality;
        this.riskObj.localityRegister = values.record.locality;
        if (this.riskObj.addRelatedCases == "Y" && this.riskObj.relatedCases.relatedCases.relatedCase.length > 0) {
            this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Related cases are removed as accumulation register is changed.", 3000));
        }
        if (this.relatedComp != null) {
            this.relatedComp.setAccumulationRegister(values.value);
        }

        // added code for AccRegister - start
        if (values.value == "0") {
            this.riskObj.localityRegister = "0";
            this.tempSysReferred = this.riskObj.accRegister.isSystemReferred;
            this.tempAccuSysReferred = this.riskObj.accRegister.isAccuSystemReferredFlag;
            this.riskObj.accRegister = new AccRegister();
            this.riskObj.accRegister.isSystemReferred = this.tempSysReferred;
            this.riskObj.accRegister.isAccuSystemReferredFlag = this.tempAccuSysReferred;
            //this.setReferredRiskFlag(false,"Standard",false);
            this.handleRiskClassification(this);
            this.emailType = "1";
            let inputObj = {
                "Message": "No accumulation register for the selected postal code, Do you want to send Email to RI Treaty ?",
                "Action": ""
            };
            let input = inputObj;
            let lookup = new ModalInput().get("Confirm");
            lookup.datainput = input;
            lookup.outputCallback = this.openConfirmPopUpCallBack;
            lookup.parentCompPRMS = { comp: this };
            lookup.heading = "Confirm Send Email to RI Treaty";
            lookup.icon = "fa fa-hand-paper-o";
            lookup.containerRef = this.contentArea;
            this.dcl.openLookup(lookup);
        } else if (values.value != "" && values.value != "0") {
            this._appObjService.saveData().subscribe((data) => {
                this.callAccRegisterFunction();
            });
        }
    }
    // AccRegister code -- start
    private openConfirmPopUpCallBack(data, prms) {
        if (data.value == 'Y') {

			/*if(prms.comp.caseInfo.caseId == "" || prms.comp.caseInfo.caseId == undefined){
				prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Please Save the case before sending an Email for Accumulation Register Creation." ,8000));
				return;
			} */
            prms.comp._appObjService.saveData().subscribe((data) => {
                prms.comp.riskClassificationService.sendMailtoTreaty(prms.comp.riskObj, prms.comp.caseInfo.caseId, prms.comp.emailType);
            });
        }
    }

    private callAccRegisterFunction() {
        this._soapService.callCordysSoapService("GetCurrentExposerAccuRegister", "http://schemas.insurance.com/businessobject/1.0/",
            {
                "caseID": this.caseInfo.caseId,
                "snedmail": "",
                "AccumulationReg": this.riskObj.accumulationRegister,
                "PostCode": this.riskObj.postCode,
                "LocationCode": this.riskObj.localityRegister,
                "TotalSI": this.riskObj.totalSI,
                "Branch": BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.servicingBranch,
                "cslAmount": "0",
                "city": this.riskObj.city
            },
            this.setAccRegisterInfoSuccess, this.setAccRegisterInfoError, true, { comp: this });
    }

    setAccRegisterInfoSuccess(response, prms) {
        if (!response.fault) {
            prms.comp.riskObj.accRegister.ExposerQuotAccepted = response.ExposerQuotAccepted.text;
            prms.comp.riskObj.accRegister.HoldCoverExposer = response.HoldCoverExposer.text;
            prms.comp.riskObj.accRegister.GAL = response.GAL.text;
            prms.comp.riskObj.accRegister.P400InforcedExposer = response.P400InforcedExposer.text;
            prms.comp.riskObj.accRegister.TotalExposer = response.TotalExposer.text;
            prms.comp.riskObj.accRegister.Outstanding = response.Outstanding.text;
            prms.comp.riskObj.accRegister.cessionOutwords = response.cessionOutwords.text;
            prms.comp.riskObj.accRegister.totalPercentage = (Number(response.TotalExposer.text) * 100) / Number(response.GAL.text);

            prms.comp.riskObj.accRegister.TOTGR = response.TOTGR.text
            prms.comp.riskObj.accRegister.TOTMNR = response.TOTMNR.text
            prms.comp.riskObj.accRegister.TOTFAC = response.TOTFAC.text
            prms.comp.riskObj.accRegister.TOTTREATY = response.TOTTREATY.text
            prms.comp.riskObj.accRegister.LIMITMNR = response.LIMITMNR.text
            prms.comp.riskObj.accRegister.LIMITFAC = response.LIMITFAC.text
            prms.comp.riskObj.accRegister.LIMITTREATY = response.LIMITTREATY.text
            prms.comp.riskObj.accRegister.LIMITNET = response.LIMITNET.text
            if (prms.comp.riskObj.accRegister.totalPercentage < 0) {
                prms.comp.riskObj.accRegister.totalPercentage = -(Number(prms.comp.riskObj.accRegister.totalPercentage));
            }

            prms.comp.riskObj.accRegister.cessionOutwordsPercentage = (Number(response.cessionOutwords.text) * 100) / Number(response.Outstanding.text);
            if (prms.comp.riskObj.accRegister.cessionOutwordsPercentage < 0) {
                prms.comp.riskObj.accRegister.cessionOutwordsPercentage = -(Number(prms.comp.riskObj.accRegister.cessionOutwordsPercentage));
            }

            // formatted values
            prms.comp.riskObj.accRegister.formattedExposerQuotAccepted = numeral(prms.comp.riskObj.accRegister.ExposerQuotAccepted).format("0,0");
            prms.comp.riskObj.accRegister.formattedHoldCoverExposer = numeral(prms.comp.riskObj.accRegister.HoldCoverExposer).format("0,0");
            prms.comp.riskObj.accRegister.formattedGAL = numeral(prms.comp.riskObj.accRegister.GAL).format("0,0");
            prms.comp.riskObj.accRegister.formattedP400InforcedExposer = numeral(prms.comp.riskObj.accRegister.P400InforcedExposer).format("0,0");
            prms.comp.riskObj.accRegister.formattedTotalExposer = numeral(prms.comp.riskObj.accRegister.TotalExposer).format("0,0");
            prms.comp.riskObj.accRegister.formattedOutstanding = numeral(prms.comp.riskObj.accRegister.Outstanding).format("0,0");
            prms.comp.riskObj.accRegister.formattedcessionOutwords = numeral(prms.comp.riskObj.accRegister.cessionOutwords).format("0,0");
            prms.comp.riskObj.accRegister.formattedGALPercentage = numeral(prms.comp.riskObj.accRegister.totalPercentage).format("00.00");
            prms.comp.riskObj.accRegister.formattedcessionOutPercentage = numeral(prms.comp.riskObj.accRegister.cessionOutwordsPercentage).format("00.00");

            prms.comp.riskObj.accRegister.formattedtotGR = numeral(prms.comp.riskObj.accRegister.TOTGR).format("0,0");
            prms.comp.riskObj.accRegister.formattedtotMNR = numeral(prms.comp.riskObj.accRegister.TOTMNR).format("0,0");
            prms.comp.riskObj.accRegister.formattedtotFAC = numeral(prms.comp.riskObj.accRegister.TOTFAC).format("0,0");
            prms.comp.riskObj.accRegister.formattedtotTREATY = numeral(prms.comp.riskObj.accRegister.TOTTREATY).format("0,0");
            prms.comp.riskObj.accRegister.formattedLimitMNR = numeral(prms.comp.riskObj.accRegister.LIMITMNR).format("0,0");
            prms.comp.riskObj.accRegister.formattedLimitFAC = numeral(prms.comp.riskObj.accRegister.LIMITFAC).format("0,0");
            prms.comp.riskObj.accRegister.formattedLimitTREATY = numeral(prms.comp.riskObj.accRegister.LIMITTREATY).format("0,0");
            prms.comp.riskObj.accRegister.formattedLimitNet = numeral(prms.comp.riskObj.accRegister.LIMITNET).format("0,0");

            prms.comp.accRegisterValidations();

        } else {
            prms.comp.tempSysReferred = prms.comp.riskObj.accRegister.isSystemReferred;
            prms.comp.tempAccuSysReferred = prms.comp.riskObj.accRegister.isAccuSystemReferredFlag;
            prms.comp.riskObj.accRegister = new AccRegister();
            prms.comp.riskObj.accRegister.isSystemReferred = prms.comp.tempSysReferred;
            prms.comp.riskObj.accRegister.isAccuSystemReferredFlag = prms.comp.tempAccuSysReferred;

            prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error while Calling Accumulation Register service.", 8000));
        }
    }

    setAccRegisterInfoError(response, status, errorText, prms) {
        prms.comp.tempSysReferred = prms.comp.riskObj.accRegister.isSystemReferred;
        prms.comp.tempAccuSysReferred = prms.comp.riskObj.accRegister.isAccuSystemReferredFlag;
        prms.comp.riskObj.accRegister = new AccRegister();
        prms.comp.riskObj.accRegister.isSystemReferred = prms.comp.tempSysReferred;
        prms.comp.riskObj.accRegister.isAccuSystemReferredFlag = prms.comp.tempAccuSysReferred;

        prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error while Calling Accumulation Register service.", 8000));
    }

    accRegisterValidations() {
        this.riskObj.accRegister.totalPercentage = 0;
        if (this.riskObj.accRegister.GAL != "0" && this.riskObj.accRegister.GAL != "") {
            this.riskObj.accRegister.totalPercentage = (Number(this.riskObj.accRegister.TotalExposer) * 100) / Number(this.riskObj.accRegister.GAL);

            if (this.riskObj.accRegister.totalPercentage >= 90 && this.riskObj.accRegister.totalPercentage <= 100) {
                if (BMSConstants.getBMSObj().ApplicationBusinessObject.caseInfo.status != "Draft") {
                    this.emailType = "2";
                    //this.setReferredRiskFlag(false,"Standard",false);
                    this.handleRiskClassification(this);
                    let inputObj = {
                        "Message": "Total exposure percentage is more than 90 % against GAL, Do you want to send email to under writer?",
                        "Action": ""
                    };
                    let input = inputObj;
                    let lookup = new ModalInput().get("Confirm");
                    lookup.datainput = input;
                    lookup.outputCallback = this.openConfirmPopUpCallBack;
                    lookup.parentCompPRMS = { comp: this };
                    lookup.heading = "Confirm Send Email to Underwriter";
                    lookup.icon = "fa fa-hand-paper-o";
                    lookup.containerRef = this.contentArea;
                    this.dcl.openLookup(lookup);
                }
            }
            else {
                this.handleRiskClassification(this);
            }
			/*if(this.riskObj.accRegister.totalPercentage > 100) {
				this.setReferredRiskFlag(true,"Referred",true);
				this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Total Exposure percentage is more than 100 % against GAL and Risk has been changed to Referred." ,8000));
			} else {
				if((this.riskObj.accRegister.isSystemReferred == false) && (this.riskObj.accRegister.isAccuSystemReferredFlag == true)) {
					this.setReferredRiskFlag(true,"Referred",true);
				} else {
					this.setReferredRiskFlag(false,"Standard",false);
				}
			}*/
        } else {
            //	this.setReferredRiskFlag(false,"Standard",false);
            this.handleRiskClassification(this);
        }
    }

    private setReferredRiskFlag(referredFlag, riskClassification, defaultFlag) {
        let refRiskUIFlag = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.isReferredRiskUI;
        if ((refRiskUIFlag == true || this.riskObj.accRegister.isSystemReferred == true) && (this.riskObj.accRegister.isAccuSystemReferredFlag == false)) {
            this.riskObj.accRegister.isSystemReferred = true;
            this.riskObj.accRegister.isAccuSystemReferredFlag = false;
            if (this.riskObj.accRegister.totalPercentage > 100)
                BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.isReferredToUW = 'Y'
            else
                BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.isReferredToUW = 'N'
        } else {
            this.riskObj.accRegister.isSystemReferred = false;
            this.riskObj.accRegister.isAccuSystemReferredFlag = defaultFlag;
            this.riskObj.symRiskClassification = riskClassification;
            BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.isReferredRiskUI = referredFlag;
            if (defaultFlag)
                BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.isReferredToUW = 'Y'
            else
                BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.isReferredToUW = 'N'
            this.handleRiskClassification(this);
        }
    }   // AccRegister code -- End

    setPostCodeInfo(response, prms) {
        if (response.tuple != null) {
            prms.comp.riskObj.city = response.tuple.old.DESCPF.SHORTDESC;
            prms.comp.riskObj.cityName = response.tuple.old.DESCPF.LONGDESC;
            prms.comp.setAccRegInfo();
            prms.comp.setGSTInfo();
        }
        else {
            prms.comp.riskObj.city = "";
            prms.comp.riskObj.cityName = "";
            prms.comp.clearAccReg();
        }
    }
    setAccRegInfo() {
        this.clearAccReg();
        this.setAccumulationRegister();
    }
    setGSTInfo() {
        this.setGST(this.riskObj.postCode);
    }
    clearAccReg() {
        this.riskObj.accumulationRegister = "";
        this.AccRegList = [];
        if (this.accRegCtrl != null) {
            this.accRegCtrl.setter("", this.accRegCtrl.comp);
        }
        this.setAccReg({ record: { locality: "" }, value: "" });
    }
    setAccumulationRegister() {
        let request: GetLOVData = new GetLOVData();
        request.BRANCH = 'ALL';
        request.LOB = 'FIRE';
        request.BUSINESS_FUNCTION = 'NEW BUSINESS';
        request.PRODUCT = 'ALL';
        request.OPERATION = 'NEW';
        request.FORM_NAME = 'FIRE_IDC';
        request.FORM_FIELD_NAME = 'ACCREG';
        request.FIELD_TYPE = 'LOV';
        request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        request.ADVANCE_CONFIG_XML.FILTERS = new Filter();

        request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push(
            { "@FIELD_NAME": 'ZTOWNCODE', "@FIELD_VALUE": this.riskObj.city, '@OPERATION': 'EQ', '@CONDITION': 'AND' },
            { "@FIELD_NAME": 'PCODE', "@FIELD_VALUE": this.riskObj.postCode, '@OPERATION': 'EQ', '@CONDITION': 'AND' },
            { "@FIELD_NAME": '', "@FIELD_VALUE": '', '@OPERATION': 'OPNPRNTHS', '@CONDITION': '' },
            { "@FIELD_NAME": 'ZCIDTETER', "@FIELD_VALUE": "0", '@OPERATION': 'EQ', '@CONDITION': 'OR' },
            { "@FIELD_NAME": 'ZCIDTETER', "@FIELD_VALUE": '99999999', '@OPERATION': 'EQ', '@CONDITION': 'OR' },
            { "@FIELD_NAME": 'ZCIDTETER', "@FIELD_VALUE": moment(new Date()).format("YYYYMMDD"), '@OPERATION': 'GT', '@CONDITION': '' },
            { "@FIELD_NAME": '', "@FIELD_VALUE": '', '@OPERATION': 'CLSPRNTHS', '@CONDITION': '' }
        );
        this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.setAccuRegHandler, this.handleError, true, { comp: this });
    }

    setAccuRegHandler(response, prms) {
        let ary = [];
        let currentDate = moment(new Date()).format("YYYYMMDD");
        let registerNotExpired = true;
        if (response.tuple != null && !Array.prototype.isPrototypeOf(response.tuple)) {
            ary = [response.tuple];
        }
        else if (response.tuple != null) {
            ary = response.tuple;
        }
        prms.comp.AccRegList = [];
        for (let item of ary) {
            // SR001 Added the condition to check if Acc Reg is expired or not
            if (item.old.FACM.ZCIDTETER > currentDate || item.old.FACM.ZCIDTETER == '0') {
                let accReg: AccumulationRegister = {
                    "accRegCode": item.old.FACM.FREG,
                    "accRegDesc": item.old.FACM.FDESC,
                    "locality": item.old.FACM.LOCREG
                };
                // SR001 Added below the Condition to check if the accumulation register is expired on Renewal
                if (item.old.FACM.FREG == prms.comp.riskObj.accumulationRegister) {
                    registerNotExpired = false;
                }
                prms.comp.AccRegList.push(accReg);
            }
        }
        //Added code for AccRegister --start
        let accReg: AccumulationRegister = {
            "accRegCode": "0",
            "accRegDesc": "Register Not Found",
            "locality": ""
        };
        // SR001 Added the alert if the accumulation register expires on Renewal
        if (registerNotExpired && prms.comp.riskObj.accumulationRegister != "" && prms.comp.riskObj.accumulationRegister != undefined && prms.comp.riskObj.accumulationRegister != null) {
            prms.comp.riskObj.accumulationRegister = "";
            prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Accumulation Register Expired. Please select the correct Fire Accumulation Code. ", 5000));
        }
        prms.comp.AccRegList.push(accReg);
        //End
    }

    onChangeAccReg(values) {
        this.riskObj.localityRegister = values.record.locality;
        if (this.riskObj.addRelatedCases == "Y" && this.riskObj.relatedCases.relatedCases.relatedCase.length > 0) {
            this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Related cases are removed as accumulation register is changed.", 3000));
        }
        if (this.relatedComp != null) {
            this.relatedComp.setAccumulationRegister(values.value);
        }

        // added code for AccRegister - start
        if (values.value == "0") {
            this.riskObj.localityRegister = "0";
            this.tempSysReferred = this.riskObj.accRegister.isSystemReferred;
            this.tempAccuSysReferred = this.riskObj.accRegister.isAccuSystemReferredFlag;
            this.riskObj.accRegister = new AccRegister();
            this.riskObj.accRegister.isSystemReferred = this.tempSysReferred;
            this.riskObj.accRegister.isAccuSystemReferredFlag = this.tempAccuSysReferred;
            //this.setReferredRiskFlag(false,"Standard",false);
            this.handleRiskClassification(this);
            this.emailType = "1";
            let inputObj = {
                "Message": "No accumulation register for the selected postal code, Do you want to send Email to RI Treaty ?",
                "Action": ""
            };
            let input = inputObj;
            let lookup = new ModalInput().get("Confirm");
            lookup.datainput = input;
            lookup.outputCallback = this.openConfirmPopUpCallBack;
            lookup.parentCompPRMS = { comp: this };
            lookup.heading = "Confirm Send Email to RI Treaty";
            lookup.icon = "fa fa-hand-paper-o";
            lookup.containerRef = this.contentArea;
            this.dcl.openLookup(lookup);
        } else if (values.value != "" && values.value != "0") {
            this.callAccRegisterFunction();
        }
    }
    addRiskCoverage() {
        let riskCoverageItem = new RiskCoverage();
        riskCoverageItem.seqNumber = this.riskObj.riskCoverageDetails.riskCoverage.length + 1;
        if (this.riskObj.riskType == "AR") {
            riskCoverageItem.premiumClass = "65";
        } else if (this.riskObj.riskType == "BG") {
            riskCoverageItem.premiumClass = "59";
        } else if (this.riskObj.riskType == "PG") {
            riskCoverageItem.premiumClass = "55";
        } else if (this.riskObj.riskType == "PP2") {
            riskCoverageItem.premiumClass = "71";
        } else if (this.riskObj.riskType == "SR") {
            riskCoverageItem.premiumClass = "69";
        } else if (this.riskObj.riskType == "ARP") {
            riskCoverageItem.premiumClass = "08";
        } else if (this.riskObj.riskType == "EP") {
            //GA001 START
            //riskCoverageItem.premiumClass="34A";
            riskCoverageItem.premiumClass = "34C";
            //GA001 END
        } else if (this.riskObj.riskType == "ME") {
            riskCoverageItem.premiumClass = "64";
        }

        this.riskObj.riskCoverageDetails.riskCoverage.push(riskCoverageItem);
    }
    removeRiskCover(coverItem) {
        let _idx = this.riskObj.riskCoverageDetails.riskCoverage.indexOf(coverItem);
        this.riskObj.riskCoverageDetails.riskCoverage.splice(_idx, 1);
        this.resetItemNumber();
        this.setTotalPremium();
    }

    resetItemNumber() {
        for (let _riskCoverage of this.riskObj.riskCoverageDetails.riskCoverage) {
            let index = this.riskObj.riskCoverageDetails.riskCoverage.indexOf(_riskCoverage);
            _riskCoverage.seqNumber = (index + 1);
        }
    }

    handleSingleRecord() {

        if (this.riskObj.relatedCases == null || (this.riskObj.relatedCases != null && typeof (this.riskObj.relatedCases) === "string")) {
            this.riskObj.relatedCases = new FireRelatedCases();
        }
        else if (this.riskObj.relatedCases != null && this.riskObj.relatedCases.relatedCases != null && typeof (this.riskObj.relatedCases.relatedCases) === "string") {
            this.riskObj.relatedCases.relatedCases = new RelatedCases();
        }
        else if (this.riskObj.relatedCases.relatedCases != null && this.riskObj.relatedCases.relatedCases.relatedCase != null && !Array.prototype.isPrototypeOf(this.riskObj.relatedCases.relatedCases.relatedCase)) {
            let tempAry: any = this.riskObj.relatedCases.relatedCases.relatedCase;
            this.riskObj.relatedCases.relatedCases.relatedCase = [tempAry];
        }
        else if (this.riskObj.relatedCases.relatedCases.relatedCase == null) {
            this.riskObj.relatedCases.relatedCases.relatedCase = [];
        }
    }

    setGST(postCode) {
        if (isNaN(parseInt(postCode))) {
            this.riskObj.GSTDetails.riskLocation = "OS";
            this.riskObj.GST = Number(this.headerInfo.GSTTaxRate);//0;// 6; //SAF MYS-2018-0629
            this.riskObj.SST = Number(this.headerInfo.SSTTaxRate);//SST Code
            this.setTotalPremium();
        }
        else {
            this.validateGSTForPCA(postCode);
        }
    }

    validateGSTForPCA(postCode) {
        let request: GetLOVData = new GetLOVData();
        request.BRANCH = 'ALL';
        request.LOB = 'ALL';
        request.BUSINESS_FUNCTION = 'ALL';
        request.PRODUCT = 'ALL';
        request.OPERATION = 'ALL';
        request.FORM_NAME = 'GST';
        request.FORM_FIELD_NAME = 'GST_PCA_POSTCODE';
        request.FIELD_TYPE = 'LOV';
        request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        request.ADVANCE_CONFIG_XML.FILTERS = new Filter();

        request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({ "@FIELD_NAME": 'DESCITEM', "@FIELD_VALUE": postCode, '@OPERATION': 'EQ', '@CONDITION': 'AND' });
        this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.setISPCA, this.handleError, true, { comp: this, postCode: postCode });
    }

    setISPCA(response, prms) {
        if (response.tuple != null && response.tuple.old.DESCPF.SHORTDESC != "LLB") {
            prms.comp.riskObj.GSTDetails.riskLocation = "PCA";
            prms.comp.riskObj.GST = Number(prms.comp.headerInfo.GSTTaxRate);//0;//6; //SAF MYS-2018-0629
            prms.comp.riskObj.SST = Number(prms.comp.headerInfo.SSTTaxRate);//SST Code
            prms.comp.setTotalPremium();
        }// Adding below code for SAF MYS-2017-0846 -- start
        else if (response.tuple != null && response.tuple.old.DESCPF.SHORTDESC == "LLB") {
            prms.comp.riskObj.GSTDetails.riskLocation = "DA";
            prms.comp.riskObj.GST = 0;
            prms.comp.setTotalPremium();
        } // End
        else {
            prms.comp.validateGSTForDA(prms.postCode, prms.comp)
        }
    }

    validateGSTForDA(postCode, comp) {
        let request: GetLOVData = new GetLOVData();
        request.BRANCH = 'ALL';
        request.LOB = 'ALL';
        request.BUSINESS_FUNCTION = 'ALL';
        request.PRODUCT = 'ALL';
        request.OPERATION = 'ALL';
        request.FORM_NAME = 'GST';
        request.FORM_FIELD_NAME = 'GST_DA_POSTCODE';
        request.FIELD_TYPE = 'LOV';
        request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        comp._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, comp.setISDA, comp.handleError, true, { comp: comp, postCode: postCode });
    }

    setISDA(response, prms) {
        if (response.tuple != null) {
            let postCodes = response.tuple.old.ITEMPF.POSTCODES;
            let postCodesList = postCodes.split(",");
            let hasPostCode = false;
            let isSameCode = false;
            for (let pCode of postCodesList) {
                // if (!isNaN(parseInt(pCode))) // SAF MYS-2017-0846
                if (pCode != undefined && pCode != "") {
                    hasPostCode = true;
                    if (pCode == prms.postCode) {
                        isSameCode = true;
                    }
                }
            }

            if (hasPostCode == false || isSameCode == true) {
                prms.comp.riskObj.GSTDetails.riskLocation = "DA";
                prms.comp.riskObj.GST = 0;
                prms.comp.setTotalPremium();
            }
            else {
                prms.comp.riskObj.GSTDetails.riskLocation = "PCA";
                prms.comp.riskObj.GST = Number(prms.comp.headerInfo.GSTTaxRate);//0;//6; //SAF MYS-2018-0629
                prms.comp.riskObj.SST = Number(prms.comp.headerInfo.SSTTaxRate);//SST Code
                prms.comp.setTotalPremium();
            }
        }
    }

    setTownClass(value) {
        this.riskObj.townClass = value;
        //		this.setBasicRate();
    }

    setConstruction(value) {
        this.riskObj.construction = value;
        let evt: any = event;
        this.riskObj.constructionName = jQuery(evt.target.selectedOptions[0]).text();
        //		this.setBasicRate();
    }

    resetRelatedCase(value) {
        if ("Y" == value) {
            this.riskObj.relatedCases = new FireRelatedCases();
        }
        else {
            this.riskObj.relatedCases = null;
            this.riskObj.relatedSumInsured = 0;
            this.setFinalSI();
        }
    }

    setFinalSI() {
        if (this.isLeastPreferredRI()) {
            this.riskObj.isLeastPreferred = "Y";
        }
        else {
            this.riskObj.isLeastPreferred = "N";
        }
        this.riskObj.capitalSumInsured = this.riskObj.totalSI;
    }

    isLeastPreferredRI() {
        if (this.riskObj.RIRetentionCode != null) {
            // if(this.leastPreferredRI.indexOf(this.riskObj.RIRetentionCode) != -1){
            // return true;
            // }
        }
        return false;
    }

    setDefaultClause(piamCode) {
        this.removeDefaultClauses();
        this.getDefaultClauses(piamCode);

        // accumulationRegister code start
        this.handleRiskClassification(this);
		/*if(this.riskObj.accRegister.isSystemReferred == false && 
			(this.riskObj.accRegister.isAccuSystemReferredFlag != undefined && this.riskObj.accRegister.isAccuSystemReferredFlag == true)) {
			this.setReferredRiskFlag(true,"Referred",true);
		}*/
        //End
    }

    getDefaultClauses(piamCode) {
        let clsSearch = this.riskObj.riskType + piamCode;
        let request: GetLOVData = new GetLOVData();
        request.BRANCH = 'ALL';
        request.LOB = 'FIRE';
        request.BUSINESS_FUNCTION = 'NEW BUSINESS';
        request.PRODUCT = 'ALL';
        request.OPERATION = 'ALL';
        request.FORM_NAME = 'ALL';
        request.FORM_FIELD_NAME = 'PIAMClause';
        request.FIELD_TYPE = 'LOOKUP';
        request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        request.ADVANCE_CONFIG_XML.FILTERS = new Filter();

        request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({ "@FIELD_NAME": 'C.DESCITEM', "@FIELD_VALUE": clsSearch, '@OPERATION': 'EQ', '@CONDITION': 'AND' });
        this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.addDefaultClauses, this.handleError, false, { comp: this });
    }

    addDefaultClauses(response, prms) {
        let ary = [];

        if (response.tuple != null && !Array.prototype.isPrototypeOf(response.tuple)) {
            ary = [response.tuple];
        }
        else if (response.tuple != null) {
            ary = response.tuple;
        }
        for (let clause of ary) {
            let newClause = { clauseCode: clause.old.T7382.CODE, description: clause.old.T7382.LONGDESC, isDefaultClause: 'Y' };
            prms.comp.riskObj.defaultClauses.clause.push(newClause);
            prms.comp.riskObj.clauses.clause.push(newClause);
        }
    }

    removeDefaultClauses() {
        for (let clause of this.riskObj.defaultClauses.clause) {
            let clsFrmClause = this.riskObj.clauses.clause.filter((item) => item.clauseCode == clause.clauseCode);
            for (let cls of clsFrmClause) {
                this.riskObj.clauses.clause.splice(this.riskObj.clauses.clause.indexOf(cls), 1);
            }
        }
        this.riskObj.defaultClauses.clause = [];
    }

    // setRiskClassification(comp){
    // if(comp.riskObj.symRiskClassification != null && comp.riskObj.symRiskClassification != "" && (comp.riskObj.symRiskClassification == "Referred" || comp.riskObj.symRiskClassification == "Declined")){
    // let statusTxt = (comp.riskObj.symRiskClassification != null && comp.riskObj.symRiskClassification != "")?comp.riskObj.symRiskClassification:comp.riskObj.riskClassification;
    // comp.riskObj.riskClassificationReason = "System marked as "+statusTxt;  
    // }
    // else{
    // if(comp.riskObj.riskClassificationReason != null && comp.riskObj.riskClassificationReason != "" && (comp.riskObj.riskClassificationReason != "System marked as Standard" && comp.riskObj.riskClassificationReason.indexOf("System marked as ") != -1)){
    // comp.riskObj.riskClassificationReason = "";
    // }
    // }
    // }

    setReferredFromUI() {
        if (event.target != null) {
            let riskClass = jQuery(event.target).find("option:selected").text();
            this.riskObj.riskClassification = riskClass;
            this.setReferredByRiskClass(this, riskClass);
        }
    }

    setReferredByRiskClass(comp, riskClass) {
        if (riskClass != null && riskClass == "Referred") {
            comp.setReferred(comp, true);
        }
        else {
            comp.setReferredByRI(comp, comp.riskObj.RIRetentionCode);
        }
    }

    setReferred(comp, toRefer) {
        comp.onRiskClsChange.emit("");
    }

    setReferredByRI(comp, riCode) {
        // if(this.leastPreferredRI.indexOf(riCode) != -1){
        // comp.riskObj.riskClassification = "Referred";
        // comp.riskObj.symRiskClassification = "Referred";
        // comp.setReferred(comp,true);
        // }
        // else{
        comp.setReferred(comp, false);
        // }
    }

    setReferredByRIFromUI() {
        if (event.target != null) {
            let riCode = jQuery(event.target).find("option:selected").text();
            this.setReferredByRI(this, riCode);
        }
    }

    emitRiskClass(comp) {
        comp.onRiskClsChange.emit("");
    }

    resetFI(value) {
        if (value == "Y")
            this.riskObj.financialInterest = new FinancialInterest();
        else
            this.riskObj.financialInterest = null;
    }

    resetSurvey(value) {
        if ("Y" == value) {
            this.riskObj.survey = new Survey();
        }
        else {
            this.riskObj.survey = null;
        }
    }

    setSurveyNeed() {
		/*let maxSI = this.maxSIForSurvey[this.riskObj.RIRetentionCode];
		if(maxSI != null){
			if(parseFloat(""+this.riskObj.totalSI) > parseFloat(maxSI)){
				this.riskObj.survey = new Survey();
				this.riskObj.isSurveyNeeded = 'Y';
			}
			else{
				this.riskObj.survey = null;
				this.riskObj.isSurveyNeeded = 'N';
			}
		}
		else{
			this.riskObj.survey = null;
			this.riskObj.isSurveyNeeded = 'N';
		}*/
        this.riskObj.survey = null;
        this.riskObj.isSurveyNeeded = 'N';
    }

    onRIRtnChange(value) {
        this.riskObj.RIRetentionCode = value;
        this.setSurveyNeed();
    }

    onPlanChage(plan) {
        this.riskObj.riskCoverageDetails.riskCoverage = [];
        this.populateRiskCoverageDetails(this);
    }

	/*onExcessTypeChange(ev){
		this.riskObj.excessType=ev.value;
		this.setExcessValidationFiels();
	}*/

    onExcessTypeChange() {
        this.setExcessValidationFiels();
    }

    setExcessValidationFiels() {
        if (this.riskObj.excessType && this.riskObj.excessType != '') {
            for (let _etItem of this.lovDropDownService.lovDataList.excessType) {
                if (_etItem.VALUE == this.riskObj.excessType) {
                    this.isExcessPercentMandatory = (_etItem.ACTN02 == 'Y') ? 'Y' : 'N';
                    this.isExcessAmountMandatory = (_etItem.ACTN01 == 'Y') ? 'Y' : 'N';
                    BMSConstants.setExcessTypeRecord(this.riskObj.riskType + this.riskObj.excessType, _etItem);
                }
            }
        }
        else {
            this.isExcessPercentMandatory = 'N';
            this.isExcessAmountMandatory = 'N';
            this.riskObj.excessPercentage = 0;
            this.riskObj.excessAmount = 0;
        }
    }

    callbackForExcessTypesLoad(scopeObject) {
        if (scopeObject.riskObj.excessType && scopeObject.riskObj.excessType != '') {
            scopeObject.setExcessValidationFiels();
        }
    }

    setIdentity(isIdentityChange) {
        if (isIdentityChange == true && (this.riskObj.identityFiller == null || this.riskObj.identityFiller == "")) {
            if (this.riskObj.situation1 != null) {
                this.riskObj.identity = this.riskObj.situation1.slice(0, 15);
                this.riskObj.identityFiller = this.riskObj.situation1.slice(0, 15);
            }
        }
        else {
            if (isIdentityChange == false && this.riskObj.situation1 != null) {
                this.riskObj.identity = this.riskObj.situation1.slice(0, 15);
                this.riskObj.identityFiller = this.riskObj.situation1.slice(0, 15);
            }
            else if (this.riskObj.identityFiller != null)
                this.riskObj.identity = this.riskObj.identityFiller.slice(0, 15);
        }
    }

    private onTextChange(ev) {
        if (ev.target.value == ' ') {
            ev.target.value = '';
        }
    }

    private onKeyPressHandler(ev) {
        if (ev.keyCode == 13 || ev.target.value.length == 47) {
            this.setFocusToNext(ev.target);
        } else if (ev.keyCode == 32) {
            ev.target.value = ev.target.value.trim();
        }
    }

    setFocusToNext(elmnt) {
        let locationElmnts = jQuery(this.el).find("input");
        jQuery(locationElmnts[locationElmnts.index(elmnt) + 1]).focus();
    }

    validateTextInput(ev) {
        let eVal = ev.target.value;
        ev.target.value = eVal.replace(/\s\s+/g, ' ');
    }

    onFirePolcyChange(ev) {
        let eVal = ev.target.value;

        if (!(eVal.match(/^\d{8}/g))) {
            ev.target.value = '';
            this.riskObj.firePolicy = '';
        }
    }

	/*addXT(coverItem){		
		var dialogData = new XTCommentDialogData("XTCommentDialogComponent", "app/bms/components/proposal/newbusinessrisks/dialogs/xtcomment.dialog.module", "XTCommentDialogModule", "Extra Text", "XTComments", "fa fa-comment", coverItem, this.xtCommentCallBack);
		this.openXTCommentsDialog(dialogData);
	}
	
	public openXTCommentsDialog(dialogData: XTCommentDialogData, response?:any) {
        let lookup = new ModalInput();
        lookup.component = [dialogData.component,dialogData.moduleAbsPath,dialogData.moduleName];
        lookup.datainput = {
            dialogName: dialogData.dialogName,            
            areCommentsMandatory: false,
            coverageItem: dialogData.coverageItem
        };
        lookup.outputCallback = dialogData.callBackHandler;
        lookup.parentCompPRMS = {
            comp: this,
			response:response
        };
        lookup.heading = dialogData.dialogTitle;
        lookup.icon = dialogData.icon;
		lookup.containerRef = this.contentArea;
        this.dcl.openLookup(lookup);
    }
	
	private xtCommentCallBack(data, prms) {
		if(data.isDialogCancelled){
            return;
        } else if(!data.isDialogCancelled && data.coverageItem && data.xtCommentsArr && data.xtCommentsArr.length >0){			
		}
    }*/

    addXT(coverItem) {
        var dialogData = new ExtraTextDialogData("ExtraTextDialogComponent", "app/bms/components/proposal/newbusinessrisks/dialogs/extratext.dialog.module", "ExtraTextDialogModule", "Extra Text", "ExtraText", "fa fa-comment", coverItem, this.extraTextCallBack);
        this.openExtraTextCommentsDialog(dialogData);
    }

    public openExtraTextCommentsDialog(dialogData: ExtraTextDialogData, response?: any) {
        let lookup = new ModalInput();
        lookup.component = [dialogData.component, dialogData.moduleAbsPath, dialogData.moduleName];
        lookup.datainput = {
            dialogName: dialogData.dialogName,
            areCommentsMandatory: false,
            coverageItem: dialogData.coverageItem
        };
        lookup.outputCallback = dialogData.callBackHandler;
        lookup.parentCompPRMS = {
            comp: this,
            response: response
        };
        lookup.heading = dialogData.dialogTitle;
        lookup.icon = dialogData.icon;
        lookup.containerRef = this.contentArea;
        this.dcl.openLookup(lookup);
    }

    private extraTextCallBack(data, prms) {
        if (data.isDialogCancelled) {
            return;
        } else if (!data.isDialogCancelled && data.coverageItem && data.coverageItem.extraText) {
        }
    }

    setRIMethod(val) {

        this.riskObj.RIMethod = (val == "Yes") ? "8" : this.riskObj.RIMethodSys;

        if (this.isUnderWriter == "Y" || val == "Yes")
            this.riskObj.isRIOverWrittenByUW = "Y";
        else if (val == "No") {
            this.riskObj.isRIOverWrittenByUW = "N";
            this.validateSumInsured();
        }
        this._riService.setRI().subscribe();
    }

    openMandatoryPolicyDetailsDialog() {

        let _polEffDate = ApplicationUtilService.getFormattedDate(this.headerInfo.effectiveDate, "YYYY-MM-DD", "YYYYMMDD");
        let _polEndDate = ApplicationUtilService.getFormattedDate(this.headerInfo.endDate, "YYYY-MM-DD", "YYYYMMDD");
        let _statusCodes = "'CA','LA','PN','PR'";

        let searchInput = new SearchInput();
        searchInput.isSingleSelect = true;
        searchInput.BRANCH = 'ALL';
        searchInput.BUSINESS_FUNCTION = 'NEW BUSINESS';
        searchInput.FIELD_TYPE = 'LOOKUP';
        searchInput.FORM_FIELD_NAME = 'POLICY_NUMBER';
        searchInput.FORM_NAME = 'POLICY_DETAILS';
        searchInput.LOB = 'ALL';
        searchInput.OPERATION = 'NEW';
        searchInput.PRODUCT = 'ALL';
        searchInput.condition = { "CHD.CNTTYPE": "PP1", "CHD.COWNNUM": this.headerInfo.insuredNumber, "CHD.CCDATE": _polEffDate, "CHD.CRDATE": _polEndDate, "CHD.STATCODE": _statusCodes };
        // searchInput.condition = {"CCDATE": this.splitedLossDate, "CRDATE": this.splitedLossDate,"CNTBRANCH":this.caseInfo.servicingBranches};

        if (this.riskObj.mandatoryPolicies.mandatoryPolicy.length > 0) {
            let newArr = [];
            for (let item of this.riskObj.mandatoryPolicies.mandatoryPolicy) {
                newArr = newArr.concat(item["policyNumber"]);
            }
            let policyNumbers = "'" + newArr.toString().replace(/,/g, "\',\'") + "'";
            // searchInput.condition = {"CHD.CHDRNUM":policyNumbers};
        }

        let input = new ModalInput();
        input.component = ["GenericSearchComponent", "app/common/components/utility/search/genericsearch.module", "GenericSearchModule"];
        input.datainput = searchInput;
        input.outputCallback = this.setDataFromMandatoryPolicyDialog;
        input.parentCompPRMS = { comp: this };
        input.heading = "Mandatory Policy Details";
        input.icon = "fa fa-file-pdf-o";
        input.containerRef = this.mandatoryPolicyArea;
        this.dcl.openLookup(input);
    }

    setDataFromMandatoryPolicyDialog(policyData, prms) {
        if (policyData.length !== 0) {
            for (let _policyItem of policyData) {
                let _policyNum = _policyItem.old.CHDRPF.CHDRNUM;
                if (prms.comp.checkMandatoryPolicy(_policyNum)) {
                    prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Policy Number " + _policyNum + " is already used for another PP2 policy.", 4000));
                }
                else {
                    let _mandPolicy = new MadatoryPolicy();
                    _mandPolicy.seqNumber = prms.comp.riskObj.mandatoryPolicies.mandatoryPolicy.length + 1;
                    _mandPolicy.policyNumber = _policyItem.old.CHDRPF.CHDRNUM;
                    _mandPolicy.effectiveDate = _policyItem.old.CHDRPF.CCDATE;
                    prms.comp.riskObj.mandatoryPolicies.mandatoryPolicy.push(_mandPolicy);
                }

            }
        }
    }

    removePolicy(idx) {
        this.riskObj.mandatoryPolicies.mandatoryPolicy.splice(idx, 1);
        for (let _mandPolicy of this.riskObj.mandatoryPolicies.mandatoryPolicy) {
            let index = this.riskObj.mandatoryPolicies.mandatoryPolicy.indexOf(_mandPolicy);
            _mandPolicy.seqNumber = (index + 1);
        }
    }

    checkMandatoryPolicy(pp1PolicyNum) {
        let request: GetLOVData = new GetLOVData();
        request.BRANCH = 'ALL';
        request.LOB = 'ALL';
        request.BUSINESS_FUNCTION = 'NEW BUSINESS';
        request.PRODUCT = 'ALL';
        request.OPERATION = 'ALL';
        request.FORM_NAME = 'ALL';
        request.FORM_FIELD_NAME = 'Mandatory Policy';
        request.FIELD_TYPE = 'LOV';
        request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        request.ADVANCE_CONFIG_XML.FILTERS = new Filter();

        request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({ "@FIELD_NAME": "CNTTYPE", "@FIELD_VALUE": "PP2", '@OPERATION': 'EQ', '@CONDITION': 'AND' });
        request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({ "@FIELD_NAME": "ZMDCHDR", "@FIELD_VALUE": pp1PolicyNum, '@OPERATION': 'EQ', '@CONDITION': 'AND' });
        request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({ "@FIELD_NAME": "ZMDRISK", "@FIELD_VALUE": "0", '@OPERATION': 'EQ', '@CONDITION': 'AND' });
        request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({ "@FIELD_NAME": "DTETER", "@FIELD_VALUE": "99999999", '@OPERATION': 'EQ', '@CONDITION': 'AND' });

        this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.getMandatoryPoliciesHandler, this.handleError, false, { comp: this });

        return this.isUsedMandatoryPolicy;
    }

    getMandatoryPoliciesHandler(response, prms) {
        prms.comp.isUsedMandatoryPolicy = false;
        if (response.tuple) {
            let _ary = new AppUtil().getArray(response.tuple);
            if (_ary && _ary.length > 0) {
                prms.comp.isUsedMandatoryPolicy = true;
            }
        }
    }

    handleRiskClassification(comp) {
        this.riskClassificationService.setRiskClassification(comp.riskObj.riskNumber, "N", "", "").subscribe();
		/*
		if(this.riskObj.symRiskClassification == "ReferredCEO") // added below code for SAF MYS-2018-0143 -- start
			this.riskObj.riskClassification = "ReferredCEO";
		else if(this.riskObj.symRiskClassification == "ReferredRHC")
			this.riskObj.riskClassification = "ReferredRHC"; // End
		else if(this.riskObj.symRiskClassification == "Declined")
			this.riskObj.riskClassification = "Declined";
		else if(this.riskObj.symRiskClassification == "Referred" || this.riskObj.riRiskClassification == "Referred")
			this.riskObj.riskClassification = "Referred";
		else
			this.riskObj.riskClassification = "Standard";
		this.setRiskClassification();
		this.emitRiskClass(this);*/
    }

    setRiskClassification() {
        if (this.riskObj.symRiskClassification != null && this.riskObj.symRiskClassification != "" && (this.riskObj.symRiskClassification == "Referred" || this.riskObj.symRiskClassification == "Declined")) {
            this.riskObj.riskClassificationReason = "System marked as " + this.riskObj.symRiskClassification;
        }
        else if (this.riskObj.riRiskClassification != null && this.riskObj.riRiskClassification != "" && this.riskObj.riRiskClassification == "Referred") {
            this.riskObj.riskClassificationReason = "System marked as " + this.riskObj.riRiskClassification;
        }
        else {
            if (this.riskObj.riskClassificationReason != null && this.riskObj.riskClassificationReason != "" && (this.riskObj.riskClassificationReason != "System marked as Standard" && this.riskObj.riskClassificationReason.indexOf("System marked as ") != -1)) {
                this.riskObj.riskClassificationReason = "";
            }
        }
    }

    onOccCodeChange(ev) {
        this.riskObj.occupationCode = ev.value;
        this.riskObj.occupationDesc = ev.record.DESCRIPTION; //ev.record.DESCRIPTION.slice(0, 40);

        if (this.riskObj.riskType == 'AR' || this.riskObj.riskType == 'ARP') {
            let request: GetLOVData = new GetLOVData();
            request.BRANCH = 'ALL';
            request.LOB = 'ALL';
            request.BUSINESS_FUNCTION = 'NEW BUSINESS';
            request.PRODUCT = 'ALL';
            request.OPERATION = 'NEW';
            request.FORM_NAME = 'ALL';
            request.FORM_FIELD_NAME = 'Occupation';
            request.FIELD_TYPE = 'LOV';
            request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
            request.ADVANCE_CONFIG_XML.FILTERS = new Filter();

            request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({ "@FIELD_NAME": 'DESCITEM', "@FIELD_VALUE": this.riskObj.occupationCode, '@OPERATION': 'EQ', '@CONDITION': 'AND' });
            this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.occupationSuccessHandler, this.handleError, true, { comp: this });

        } else if (this.riskObj.riskType != 'SR') {
            this.riskObj.occRiskClassification = ev.record.REFERREDRISK;
            /*	if(!ev.record.REFERREDRISK || ev.record.REFERREDRISK == 'N'){
                    this.riskObj.symRiskClassification = "Standard";
                }
                else if(ev.record.REFERREDRISK && ev.record.REFERREDRISK == 'Y'){
                    this.riskObj.symRiskClassification = "Referred";
                }
                else if(ev.record.REFERREDRISK && ev.record.REFERREDRISK == 'D'){
                    this.riskObj.symRiskClassification = "Declined";
                }*/

            this.handleRiskClassification(this);

        }
    }

    occupationSuccessHandler(response, prms) {
        this.riskObj.occRiskClassification = response.tuple.old.T3644.REFERREDRISK;
        this.handleRiskClassification(prms.comp);
        /*	if(response.tuple.old.T3644.REFERREDRISK == '' || response.tuple.old.T3644.REFERREDRISK == 'N') {
                prms.comp.riskObj.symRiskClassification = "Standard";
            }
            else if(response.tuple.old.T3644.REFERREDRISK == 'Y') {
                prms.comp.riskObj.symRiskClassification = "Referred";
                prms.comp.headerInfo.isReferredRisk = "true";
                prms.comp.headerInfo.isReferredRiskUI = true;
            }
            else if(response.tuple.old.T3644.REFERREDRISK == 'D') {
                prms.comp.riskObj.symRiskClassification = "Declined";
            }
            prms.comp.riskObj.riskClassification = prms.comp.riskObj.symRiskClassification;		
            prms.comp.setRiskClassification(prms.comp);
                	
            prms.comp.setReferred(prms.comp, true);*/

    }

    onTLimitChange(ev) {
        this.riskObj.tLimit = ev.value;
		/*for(let _tLimitItem of this.lovDropDownService.lovDataList.tLimit){
			if(_tLimitItem.LONGDESC == ev.value){
				if(_tLimitItem.REFERRED &&  _tLimitItem.REFERRED == 'Y'){
					this.riskObj.riskClassification = "Referred";
					this.riskObj.symRiskClassification = "Referred"; 				
					this.riskObj.riskClassificationReason = "System marked as Referred";
				}
				else {
					this.riskObj.riskClassification = "Standard";
					this.riskObj.symRiskClassification = "Standard";
					this.riskObj.riskClassificationReason ="";
				}
				this.emitRiskClass(this);
				break;
			}
		}*/
    }

    sortArray(arryObjs, name) {
        if (arryObjs.length > 0) {
            arryObjs.sort(function (obj1, obj2) {
                if (obj1[name] < obj2[name]) {
                    return -1;
                } else if (obj1[name] > obj2[name]) {
                    return 1;
                } else {
                    return 0;
                }
            });
        }
    }

    setRIMethodEditableFlag() {
        let _capitalSumInsured = parseFloat("" + this.riskObj.capitalSumInsured);
        let _totalGrossCapacity = parseFloat("" + this.riskObj.totalGrossCapacity);
        if (_totalGrossCapacity > 0 && _capitalSumInsured > _totalGrossCapacity && this.isUnderWriter == "N") {
            this.isRIMethodEditable = "N";
        }
        else {
            this.isRIMethodEditable = "Y";
        }
    }

    emitFlagChange() {
        this.onRtngFlgChange.emit("");
    }
    //MYS-2019-1024 START - KA001
    setRIRetentionCode() {
        if (this.riskObj.riskType == 'AR' && (this.riskObj.occupationCode != '' && this.riskObj.occupationCode != undefined) && (this.riskObj.construction != '' && this.riskObj.construction != undefined)) {
            let polStartDate = ApplicationUtilService.getFormattedDate(this.headerInfo.effectiveDate, "YYYY-MM-DD", "YYYYMMDD");
            let polEndDate = ApplicationUtilService.getFormattedDate(this.headerInfo.endDate, "YYYY-MM-DD", "YYYYMMDD");
            let request: GetLOVData = new GetLOVData();
            request.BRANCH = 'ALL';
            request.LOB = 'MIS';
            request.BUSINESS_FUNCTION = 'NEW BUSINESS';
            request.PRODUCT = 'ALL';
            request.OPERATION = 'ALL';
            request.FORM_NAME = 'ALL';
            request.FORM_FIELD_NAME = 'RI Retention Code';
            request.FIELD_TYPE = 'LOV';
            request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
            request.ADVANCE_CONFIG_XML.FILTERS = new Filter();

            request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({ "@FIELD_NAME": 'DESCITEM', "@FIELD_VALUE": this.riskObj.riskType + ' ' + this.riskObj.occupationCode, '@OPERATION': 'EQ', '@CONDITION': 'AND' });
            request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({ "@FIELD_NAME": 'CONSTN', "@FIELD_VALUE": this.riskObj.construction, '@OPERATION': 'EQ', '@CONDITION': 'AND' });
            request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({ "@FIELD_NAME": 'TOWNCLS', "@FIELD_VALUE": this.riskObj.townClass, '@OPERATION': 'EQ', '@CONDITION': 'AND' });
            request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({ "@FIELD_NAME": 'ITMFRM', "@FIELD_VALUE": polStartDate, '@OPERATION': 'LTEQ', '@CONDITION': 'AND' });
            request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({ "@FIELD_NAME": 'ITMTO', "@FIELD_VALUE": polEndDate, '@OPERATION': 'GTEQ', '@CONDITION': 'AND' });
            this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.riRetentionSuccessHandler, this.handleError, true, { comp: this });
        }

    }
    riRetentionSuccessHandler(response, prms) {
        if (response.tuple != undefined) {
            prms.comp.riskObj.RIRetentionCode = response.tuple.old.T9115.ZRIRETN;
        }
    }// END
}

export class AccumulationRegister {
    constructor(
        public accRegCode: string,
        public accRegDesc: string,
        public locality: string
    ) { }
}