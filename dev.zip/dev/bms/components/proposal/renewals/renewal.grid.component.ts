
/*
 * Change History:
 * 
 * No      Date          Description                                   Changed By
 * ====    ==========    ===========                                   ==========
 * 
 * KA0001  27/02/2018    MYS-2018-1028 : To block the                   DKA
 *                       issuance of all Motor policy 
 *                       expired from BMS     
 * 
 * VK001   04/09/2018    MYS-2018-1026 - Security fix                   VKR
 * 
 * KA002   27/02/2019    MYS-2018-0360 - MPD Renewal                    DKA
 * VK006   20/03/2019    MYS-2019-0164 - MMP Product Configuration      VKR
 * MS001   29/08/2019    MYS-2019-0729 - MMF Product Configuration      MSU                    
*/

import { Component, OnInit } from '@angular/core';
import { ViewChild, ViewContainerRef } from "@angular/core";
import { Router, ActivatedRoute } from '@angular/router';
import { ApplicationUtilService } from '../../../../common/services/application.util.service';
import { CordysSoapWService } from '../../../../common/components/utility/cordys-soap-ws';
import { GetLOVData, SearchAdvancedConfig, Filter } from '../../../../common/components/utility/search/search.requests';
import { AlertMessagesService } from '../../../../common/components/utility/alertmessage/alertmessages.service';
import { AlertMessage } from '../../../../common/components/utility/alertmessage/alertmessages.model';
import { AdvancedSearchInput } from '../../../../common/components/advancedsearchgrid/advancedsearchgridinput';
import { RenewalServices } from '../../../services/renewal.service';
import { ProgressBarComponent } from '../../../../common/components/utility/progressbar/progressbar.component';
import { ModalInput } from "../../../../common/components/utility/modal/modal";
import { DCLInput } from "../../../../common/services/customdcl.service";
import { CommentDialogData } from "../../../components/proposal/process/appobjects/comment.dialog.data.component";
import { CustomDCLService } from "../../../../common/services/customdcl.service";
declare var numeral: any;
import { AppUtil } from '../../../../common/components/utility/apputil/app.util';

@Component({
    selector: 'myrenewal-comp',
    templateUrl: 'app/bms/components/proposal/renewals/renewal.grid.template.html'
})

export class MyRenewalComponent implements OnInit {

    private advancedSearchInput: AdvancedSearchInput = new AdvancedSearchInput();
    public initiated = true;
    public comments: string = '';
    public simplifiedProdList: any;
    @ViewChild('RenewalModal', { read: ViewContainerRef }) contentArea: ViewContainerRef;
    constructor(private _soapService: CordysSoapWService, private _appUtilService: ApplicationUtilService, public _alertMsgService: AlertMessagesService, private _router: Router,
        public renService: RenewalServices, public dcl: CustomDCLService) {
    }

    ngOnInit() {
        this.advancedSearchInput.advancedFilterOptnsArry = { "LIKE": "LIKE", "EQ": "EQ", ">": "GT", ">=": "GTEQ", "<": "LT", "<=": "LTEQ" };
        this.advancedSearchInput.isActionsHiddenFunction = this.checkHidden;
        this.advancedSearchInput.onColumnDataBind = this.onColumnDataBind;
        this.advancedSearchInput.bindHover = this.bindHover;
        this.advancedSearchInput.getRecordsCount = this.getTotalSearchRecordsCount;
        this.loadProductList();
    }

    loadProductList() {
        this._soapService.callCordysSoapService("GetXMLObject", "http://schemas.cordys.com/1.0/xmlstore", { "key": "com/msig/insurance/simplifiedprocess/productlist.xml" }, null, null, true, null)
            .success((data) => {
                if (data.tuple && data.tuple.old) {
                    this.simplifiedProdList = AppUtil.getValueByPath(data, "tuple.old.SimplifiedProductList.ProductList");
                    this.simplifiedProdList = (typeof (this.simplifiedProdList) == "string" && this.simplifiedProdList != "") ? [this.simplifiedProdList] : this.simplifiedProdList;
                }
            })
            .error((err) => {
                this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error while getting Product List XML" + err, -1));
            });
    }

    private getTotalSearchRecordsCount(input, prm) {
        var requestObj = new GetLOVData();
        requestObj.BRANCH = 'ALL';
        requestObj.LOB = 'ALL';
        requestObj.BUSINESS_FUNCTION = 'NEW BUSINESS';
        requestObj.PRODUCT = 'ALL';
        requestObj.OPERATION = 'ALL';
        requestObj.FORM_NAME = 'Renewal';
        requestObj.FORM_FIELD_NAME = 'Renewal Count';
        requestObj.FIELD_TYPE = 'LOOKUP';
        requestObj.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        requestObj.ADVANCE_CONFIG_XML.FILTERS = new Filter();
        requestObj.ADVANCE_CONFIG_XML.FILTERS.FILTER = [];
        requestObj.ADVANCE_CONFIG_XML = input.ADVANCE_CONFIG_XML;

        let recordsCountResponse = prm._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", requestObj, null, null, true, null);
        recordsCountResponse.success((data) => {
            if (data.tuple) {
                prm.recordsCount = data.tuple.old.TABLE.VALUE;
            }
        });
        recordsCountResponse.error((response, status, errorText) =>
            prm._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error while calling LOV service " + errorText, -1)));

    }

    private getUserId(data) {
        let ZPRODUCER = "";
        /* let ZUSERID =  data.substring(3, data.indexOf(","));
        let producerCodeResponsePromise = this._soapService.callCordysSoapService("GetMsigUsersMasterObject", "http://schemas.opentext.com/msig/persistancedb/1.0", {"USER_ID" : ZUSERID}, null, null, false, null);
        */
        //VK001 Changed the service call from getMsigUsersMasterObject to GetLoggedInUserInfo 
        let producerCodeResponsePromise = this._soapService.callCordysSoapService("GetLoggedInUserInfo", "http://schemas.opentext.com/msig/persistancedb/1.0", null, null, null, false, null);

        /*  END VK001 */
        producerCodeResponsePromise.success((data) => ZPRODUCER = (data.tuple != undefined ? data.tuple.old.MSIG_USERS_MASTER.PRODUCER_CODE : ""));
        producerCodeResponsePromise.error((response, status, errorText) => this.handleLOVError(response, status, errorText));
        //Set Advanced Filter COnfig
        if (ZPRODUCER.length > 0) {

            let searchDefinitionForAdvancedFilter = this.createSearchDef();
            searchDefinitionForAdvancedFilter.FILTER["@FIELD_NAME"] = "ZPRODUCER";
            searchDefinitionForAdvancedFilter.FILTER["@FIELD_VALUE"] = ZPRODUCER;
            searchDefinitionForAdvancedFilter.FILTER["@OPERATION"] = "EQ";
            // this.getAllAdvancedSearchInput["ADVANCE_CONFIG_XML"].FILTERS.FILTER.push(searchDefinitionForAdvancedFilter);
            this.advancedSearchInput.searchFilter = searchDefinitionForAdvancedFilter;
            this.initiated = true;
        }

    }
    private handleLOVError(response, status, errorText) {
        this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error while calling LOV service " + errorText, -1));
    }
    private createSearchDef() {
        let searchDef = {
            "FILTER": {
                "@FIELD_NAME": "",
                "@FIELD_VALUE": "",
                "@OPERATION": "LIKE",
                "@CONDITION": "AND"
            }
        };
        return searchDef;
    }
    // KA0001 Divek added this function
    public getServerDate(): string {
        var server_date;
        var responsePromise = this._soapService.callCordysSoapService("GetCurrentDate", "http://schemas.opentext.com/msig/persistancedb/1.0", null, null, null, false, null);
        responsePromise.done((data) => {
            server_date = data.tuple.old.getCurrentDate.getCurrentDate;
        });
        server_date = ApplicationUtilService.getFormattedDate(server_date, "YYYY-MM-DD", "YYYYMMDD");
        return server_date;
    }

    private onActionClick(event) {
        switch (event.action) {
            case "dblclick":
                if (this.simplifiedProdList.indexOf(event.item.CNTTYPE) != -1) {
                    this._router.navigate(["SimplifiedProposal/Edit", { policyNo: event.item.CHDRNUM, component: "MyRenewal" }]);
                }
                else {
                    this._router.navigate(["Proposal/Edit", { policyNo: event.item.CHDRNUM, component: "MyRenewal" }]);
                }
                break;
            case "Renew":
                this.renService.checkDuplicate(event.item.CHDRNUM, "RN").subscribe((data) => {
                    if (!data) {
                        // Divek KA0001
                        let current_date = this.getServerDate();
                        let Expiry_Date = event.item.CRDATE01;
                        let Inception_Date = ApplicationUtilService.addDaysToDate(Expiry_Date, 'YYYY-MM-DD', '1')
                        let days = ApplicationUtilService.getDateDiff(Inception_Date, current_date, 'YYYY-MM-DD', 'days');
                        if (days < 0 && (['HVT', 'MCF', 'MCT', 'MCY', 'MPC', 'MPF', 'MPT', 'MTC', 'MTF', 'MTT', 'MPD', 'MPD', 'CV', 'CVF', 'CVT', 'DPA', 'HVC', 'MSW', 'MWP', 'MWP', 'MPA', 'MMP','MMF'].indexOf(event.item.CNTTYPE) != -1)) { //VK006 //MS001
                            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Policy has already expired. Please proceed with ‘Convert to New Business’ ", 5000));
                            return;
                        }
                        // Divek
                        ProgressBarComponent.show('Creating Renewal Case', { dialogSize: 'm', progressType: 'primary' });
                        //let isSimplifiedprocess =(this.simplifiedProdList.indexOf(event.item.CNTTYPE)!=-1)?'Y':'N';
                        let isSimplifiedprocess = (this.simplifiedProdList.indexOf("'" + event.item.CNTTYPE + "'") != -1) ? 'Y' : 'N';//MD00_
                        this.renService.createRenewalRerateTaskForAH(event.item.CHDRNUM, "Renewal", "Renewal", null, isSimplifiedprocess).subscribe((data) => { //KA002
                            if (!data) {
                                this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error while fetching the policy info from P400", -1));
                                ProgressBarComponent.hide();
                                return;
                            }
                            else ProgressBarComponent.hide();
                        });
                    }
                    else ProgressBarComponent.hide();
                });
                break;
            case "View Comment":
                let request = {
                    "cursor": {
                        "@id": "0",
                        "@position": "",
                        "@numRows": "",
                        "@maxRows": "100",
                        "@sameConnection": "false"
                    },
                    "BRANCH": "ALL",
                    "LOB": "ALL",
                    "BUSINESS_FUNCTION": "RENEWAL",
                    "PRODUCT": "ALL",
                    "OPERATION": "ALL",
                    "FORM_NAME": "RERATE",
                    "FORM_FIELD_NAME": "View Comments",
                    "FIELD_TYPE": "LOV",
                    "ADVANCE_CONFIG_XML": {
                        "FILTERS": {
                            "FILTER": [
                                {
                                    "@FIELD_NAME": "CHDRNO",
                                    "@FIELD_VALUE": event.item.CHDRNUM,
                                    "@OPERATION": "EQ",
                                    "@CONDITION": "AND"
                                },
                                {
                                    "@FIELD_NAME": "DTEEFF ",
                                    "@FIELD_VALUE": event.item.CRDATE01,
                                    "@OPERATION": "GTEQ",
                                    "@CONDITION": "AND"
                                }
                            ]
                        }
                    }
                };

                let viewComentsPromise = this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, null, null, true, { comp: this });
                viewComentsPromise.success((data) => {
                    let dateEffective = "";
                    if (data.tuple) {
                        if (Array.prototype.isPrototypeOf(data.tuple)) {
                            this.comments = data.tuple[0].old.GENPPF.GENPLNE;
                            dateEffective = data.tuple[0].old.GENPPF.DTEEFF;
                        }
                        else {
                            this.comments = data.tuple.old.GENPPF.GENPLNE;
                            dateEffective = data.tuple.old.GENPPF.DTEEFF;
                        }

                        var dialogData = new CommentDialogData("CommonCommentDialogComponent", "app/bms/components/proposal/process/common.comment.dialog.module", "CommonCommentDialogModule", "View Comments", "DNComments", "fa fa-comment", null);
                        ProgressBarComponent.hide();
                        this.openCommentsDialog(dialogData, event.item.CHDRNUM, dateEffective);
                    }
                    else {
                        this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "No Comments found ", 6000));
                    }
                });
                viewComentsPromise.error((response, status, errorText) => this.handleLOVError(response, status, errorText));
                break;
            case "Renew as MMF":        //MS001   
            case "Renew as MPF":        //MS001     
            case "Renew as MMP":        //VK006
            case "Renew as MPD":       // MYS-2018-0360  KA002- Added below cases for MPC to MPD and vice versa coversion
            case "Renew as MPC":       // MYS-2018-0360  KA002
                // let Action = "Renew as MPC";
                let isSimplifiedprocess = (this.simplifiedProdList.indexOf(event.item.CNTTYPE) != -1) ? 'Y' : 'N'; this.renService.policyValidator(event.item.CHDRNUM, "NewBusiness", event.action, isSimplifiedprocess, null).subscribe((data) => {
                    if (data.CaseId != undefined && data.CaseId.text) {
                        let compName = this._appUtilService.getNavigationComponent('BMS', data.CaseId.text, isSimplifiedprocess);
                        this._router.navigate([compName, { caseID: data.CaseId.text, component: "MyDrafts" }]);
                        ProgressBarComponent.hide()
                        // return;
                    }
                    else if (data.fault) {
                        this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error while fetching the policy info from P400", -1));
                        ProgressBarComponent.hide();
                        return;
                    }
                    else ProgressBarComponent.hide();
                });
                break;
            case "Convert to New Business":       // MYS-2019-0433  KA002
                {
                    let isSimplifiedprocess = (this.simplifiedProdList.indexOf(event.item.CNTTYPE) != -1) ? 'Y' : 'N'; this.renService.policyValidator(event.item.CHDRNUM, "NewBusiness", event.action, isSimplifiedprocess, null).subscribe((data) => {
                        if (data.CaseId != undefined && data.CaseId.text) {
                            let compName = this._appUtilService.getNavigationComponent('BMS', data.CaseId.text, isSimplifiedprocess);
                            this._router.navigate([compName, { caseID: data.CaseId.text, component: "MyDrafts" }]);
                            ProgressBarComponent.hide()
                            // return;
                        }
                        else if (data.fault) {
                            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error while fetching the policy info from P400", -1));
                            ProgressBarComponent.hide();
                            return;
                        }
                        else ProgressBarComponent.hide();
                    });
                }
                break;
            default:
        }
    }

    private checkHidden(application, action, report) {
        if (action.enableWhen == undefined) {
            return false;
        } else if (action.enableWhen.indexOf(report["STATCODE"]) != -1) {
            if (report["STATCODE"] == "") return false;
            else return true;
        } else if (action.enableWhen.indexOf(report.CNTTYPE) != -1) {
            return false;
        } else {
            return true;
        }
    }

    public onColumnDataBind(value, columnName) {
        if ((columnName == 'Inception date' || columnName == 'Expiry Date') && value != "" && value != undefined) {
            return value.substring(6) + "/" + value.substring(4, 6) + "/" + value.substring(0, 4);
        }
        else if ((columnName == 'Premium') && (columnName == 'Sum Insured') && value != "" && value != undefined) {
            return numeral(value).format("0,0.00");
        }
        else return value;
    }

    public bindHover(report, listItem) {
        let value = report[listItem.onhover];
        if (value == '0.00' || value == '0' || value == '99999999' || value == report[listItem.id])
            return '';
        else {
            return this.onColumnDataBind(value, listItem.name);
        }
    }

    public openCommentsDialog(dialogData: CommentDialogData, response?: any, dateEffective?: any) {
        let lookup = new ModalInput();
        lookup.component = [dialogData.component, dialogData.moduleAbsPath, dialogData.moduleName];
        lookup.datainput = {
            dialogName: dialogData.dialogName,
            userList: null,
            areCommentsMandatory: true,
            registerResponse: null,
            DNComments: this.comments,
            commentDate: dateEffective
        };
        lookup.outputCallback = dialogData.callBackHandler;
        lookup.parentCompPRMS = {
            comp: this,
            response: response
        };
        lookup.heading = dialogData.dialogTitle;
        lookup.icon = dialogData.icon;
        lookup.containerRef = this.contentArea;
        this.dcl.openLookup(lookup);
    }
}
