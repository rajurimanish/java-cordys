import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { LovModule } from '../../../common/services/lovdropdown/lov.module';

import { ProposalComponent } from './proposal.component';
import { CAMailServiceModule } from './process/services/camail.service.module';

import { RIServiceModule } from './newbusinessrisks/services/ri.module';
import { RiskClassificationServiceModule } from './newbusinessrisks/services/riskcls.module';

import { BMSEventHandler } from './events/bms.events';
import { BMSServiceModule } from '../../services/bmsservice.module';
import { NCDModule } from './newbusinessrisks/motorcommercial/handler/ncd.module';

const routerConfig: Routes = [
    { path: "Edit", component: ProposalComponent },
    { path: "", component: ProposalComponent }
];

@NgModule({
    imports: [CommonModule, FormsModule, ReactiveFormsModule, RouterModule.forChild(routerConfig), LovModule, BMSServiceModule, NCDModule, RiskClassificationServiceModule, RIServiceModule, CAMailServiceModule],
    declarations: [ProposalComponent],
    exports: [RouterModule, ProposalComponent]
})
export class BMSProductsRouteModule {
    constructor() {
        new BMSEventHandler();
    }
}