import * as core from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TaskServiceModule } from "../../../../../common/services/taskservice.module";
import { ControlAreaComponent } from './controlarea.component';
import { BasicUIModule } from '../../../../../common/components/utility/basicui.module';


@core.NgModule({
    imports: [CommonModule, FormsModule, ReactiveFormsModule, BasicUIModule, TaskServiceModule],
    declarations: [ControlAreaComponent],
    exports: [ControlAreaComponent]
})
export class ControlAreaModule { }

