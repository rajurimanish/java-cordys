import * as common from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CoInsuranceModule } from '../../../../../common/components/coinsurance/coinsurance.module';
import { BasicUIModule } from '../../../../../common/components/utility/basicui.module';
import { ProposalHeaderComponent } from './proposalheader.component';
import { BancaServiceModule } from '../../proposalheader/service/banca.service.module';
import { CoinsuranceServiceModule } from '../../proposalheader/service/coi.service.module';
import { ReferenceServiceModule } from '../../proposalheader/service/reference.service.module';
import { RiskTableServiceModule } from '../../proposalheader/service/riskTable.service.module';
import { BancaModule } from '../../proposalheader/uimodules/banca.module';
import { ReferenceModule } from '../../proposalheader/uimodules/reference.module';

@NgModule({
    imports: [common.CommonModule, FormsModule, ReactiveFormsModule, BasicUIModule, BancaModule, ReferenceModule, CoInsuranceModule, BancaServiceModule, CoinsuranceServiceModule, RiskTableServiceModule, ReferenceServiceModule],
    declarations: [ProposalHeaderComponent],
    exports: [ProposalHeaderComponent]
})
export class ProposalHeaderModule { }