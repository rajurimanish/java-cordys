
import * as core from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CaseInfo } from '../../../../../common/components/appobjects/caseinfo';
import { ClientDetails } from '../../../../../common/components/client/appobjects/client';
import { AlertMessage } from '../../../../../common/components/utility/alertmessage/alertmessages.model';
import { AlertMessagesService } from '../../../../../common/components/utility/alertmessage/alertmessages.service';
import { AppUtil } from '../../../../../common/components/utility/apputil/app.util';
import { CordysSoapWService } from "../../../../../common/components/utility/cordys-soap-ws";
import { ModalInput } from "../../../../../common/components/utility/modal/modal";
import { Filter, GetLOVData, SearchAdvancedConfig } from '../../../../../common/components/utility/search/search.requests';
import { ApplicationUtilService } from '../../../../../common/services/application.util.service';
import { CustomDCLService } from '../../../../../common/services/customdcl.service';
import { LOVDropDownService, LOV_Field, SearchFilter } from "../../../../../common/services/lovdropdown/lovdropdown.service";
import { BMSUtilService } from "../../../../services/bms.util.service";
import { BMSAppObjService } from '../../../../services/bmsappobj.service';
import { BMSObject } from '../../../common/appobjects/bmsobject';
import { BMSConstants } from '../../../common/constants/bms_constants';
import { BMSType } from '../../../common/constants/bms_types';
import { BMSLOVRequest } from '../../../common/service/lov/bms.lovrequest';
import { RiskClassificationService } from '../../newbusinessrisks/services/riskcls.service';
import { MTIItems } from '../../proposalheader/appobjects/mti';
import { ProposalHeader } from '../../proposalheader/appobjects/proposalheader';
import { BancaService } from '../../proposalheader/service/banca.service';
import { CoinsuranceService } from '../../proposalheader/service/coi.service';
import { RiskTableService } from '../../proposalheader/service/riskTable.service';
import { BancaComponent } from '../../proposalheader/uimodules/banca.component';
import { RisksValidator } from '../../validation/risks.validator';
import { Reason, Reasons } from '../../proposalheader/appobjects/referredreason';
import { SearchInput } from '../../../../../common/components/utility/search/genericsearch';

declare var moment: any;
declare var jQuery: any;

@core.Component({
    selector: 'proposal-header',
    templateUrl: 'app/bms/components/proposal/endorsements/proposalheader/proposalheader.template.html',
    inputs: ['proposal', 'proposalHeader', 'caseInfo'],
    outputs: ['onproductchange', 'oninsuredchange', 'onpoichange']
})
export class ProposalHeaderComponent implements core.OnInit {

    public proposal: BMSObject;
    public proposalHeader: ProposalHeader;
    public caseInfo: CaseInfo;
    private isCollapsedMode: boolean = false;
    private collapseAddlInfo: boolean = false;
    private collapseBancalInfo: boolean = false;
    private isReferredRiskUI: boolean = false;
    private channelConflictIndicatorUI: boolean = false;
    private duplicateIndicatorUI: boolean = false;
    onproductchange = new core.EventEmitter<string>();
    oninsuredchange = new core.EventEmitter<string>();
    onpoichange = new core.EventEmitter<string>();
    private ahList: AHInfo[] = [];
    private payPlanList: PayPlanInfo[] = [];
    private rnlTypeList: RenewalTypeInfo[] = [];
    private notificationTypeList: NotificatTypeInfo[] = [];
    public insuredDOB: string = "";
    private endDateCtrl: any;
    private startDateCtrl: any;
    private productCtrl: any;
    public disableForm = 'N';
    public disableDocReceivedDate = 'N';
    public poiDisable = 'N';
    public insuredPersonType: string = '';
    public inceptionDateChanged: boolean = false;
    public entDateChanged: boolean = false;
    public thiscomp: any;
    private orgDN: string;
    private notifDisplayed: boolean = false;
    private loggedInUser: string = "";
    public uobSectorList = [{ code: "CS", description: "Consumer Loan" }, { code: "MR", description: "Retail Loan" }, { code: "MM", description: "Middle Market Loan" }, { code: "MC", description: "Large Corporation" }, { code: "ML", description: "Listed Corporations" }, { code: "MB", description: "Bumi Development Unit" }, { code: "IP", description: "Corporate Banking" }, { code: "IS", description: "Specialised Financing" }, { code: "CM", description: "Business Banking" }, { code: "CV", description: "Privilege Banking" }]
    public isRerate: boolean = false;
    public isRerateOnly: boolean = false;
    public isRerateCSE: boolean = false;
    public checkBoxRef: any;
    public isITUW: string = "N";
    public disableManuscript: boolean = false;
    public isRIMethodEditable: string = 'Y';
    public isAgentEditMode;
    public isBancaBranch: boolean = false;
    public bancaBranch: string;
    public isQuotationCompleted: string = "N";
    public tempObj: any;
    public isProductChanged: boolean = false;


    @core.ViewChild(BancaComponent) private bancaComp: BancaComponent;
    @core.ViewChild('proposalHeaderModal', { read: core.ViewContainerRef }) contentArea: core.ViewContainerRef;
       
    constructor(public dcl: CustomDCLService, private _cordysService: CordysSoapWService, private lovDropDownService: LOVDropDownService, private _aus: ApplicationUtilService, public _alertMsgService: AlertMessagesService, private _appObjService: BMSAppObjService, private _bancaService: BancaService, private _coiService: CoinsuranceService, private _rtService: RiskTableService, private _rcls: RiskClassificationService, public _bus: BMSUtilService, private _activatedRoute: ActivatedRoute) { }

    // KU001 Start
    public OldAgentType: boolean = false;
    public NewAgentType: boolean = false;
    // KU001 End


    ngOnInit() {
        this.handleIndicatorCheckBox();
        //this.handleRenewal();
        //this.handlePOIForCoverNote();
        this.setTempObj();
        if ( this.caseInfo.status != "Endorsements Draft" && this.caseInfo.status != "Cancellations Draft" && this.caseInfo.status != "Reinstatement Draft") {
            this.populateLovs();
            this.getAccountHandlerByBranchAndApplication(this, true);
            if (this.proposal.newBusiness.clientDetails && this.proposalHeader.effectiveDate && this.proposalHeader.endDate && this.proposalHeader.contractType) {
                this.notifDisplayed = false;
                this.checkChannelConflict();
            } 
            this.setPayPlan(false);
            this.setInsuredPersonType(this.proposal.newBusiness.clientDetails);
            this.setRenewalType();
            if (AppUtil.isEmpty(this.proposalHeader.renewalType, false) == false)
                this.setNotificationType();
            this.thiscomp = this;
            
            //this.resetRTInfo();
            this.handleManuScriptFld();

            /* //SST code
            let tempRespObj = this._bus.getLiveDate();
            if (tempRespObj != undefined && tempRespObj != "") {
                this.proposalHeader.GSTLiveDate = tempRespObj[0].old.ITEMPF.LIVEDATE;
                this.proposalHeader.SSTLiveDate = tempRespObj[1].old.ITEMPF.LIVEDATE;
            }
            //End */
            this.checkBancaInfo( false );
            
            if ( this.proposalHeader.isClaimExists != undefined && this.proposalHeader.isClaimExists == "true" ) {
                this._alertMsgService.add( new AlertMessage( AlertMessage.INFO, "There is Claim Exists for selected Policy. Please check and get your SMT approval if required.", -1 ) );
            }
        }
        
     }

    setTempObj() {
        this.tempObj = BMSConstants.getTempObj();
    }

    handleManuScriptFld() {
        this._aus.isUnderWriterUser().subscribe((isUW) => {
            this.isITUW = isUW;
            this.checkDisableManuscript();
            this.checkRIFieldEditable();
        })
    }

    checkDisableManuscript() {
        if (BMSConstants.getBMSType() == BMSType.NewBusiness || BMSConstants.getBMSType() == BMSType.CoverNote) {
            if (this.caseInfo.status == 'Draft' || this.caseInfo.status == 'Assessment' || this.caseInfo.status == 'Assessment Approval') {
                this.disableManuscript = false;
            }
            else if (this.caseInfo.status == 'Referral Approval') {
                if (this.isITUW == 'Y')
                    this.disableManuscript = false;
                else
                    this.disableManuscript = true;
            }
            //Redmine 2890,2891
            else if (this.caseInfo.status == 'RHC Referral Approval') {
                this.disableManuscript = false;
            }
            else
                this.disableManuscript = true;
        }
        else
            this.disableManuscript = false;
    }

    checkRIFieldEditable() {
        if (BMSConstants.getBMSType() == BMSType.NewBusiness || BMSConstants.getBMSType() == BMSType.CoverNote) {
            if (this.caseInfo.status == 'Draft' || this.caseInfo.status == 'Assessment' || this.caseInfo.status == 'Assessment Approval') {
                this.isRIMethodEditable = "Y";
            }
            else if (this.caseInfo.status == 'Referral Approval') {
                if (this.isITUW == 'Y')
                    this.isRIMethodEditable = "Y";
                else
                    this.isRIMethodEditable = "N";
            }
            else
                this.isRIMethodEditable = "N";
        }
        else
            this.isRIMethodEditable = "Y";
    }

    public onPolicyTypeChange(value) {
        this.proposalHeader.renewalType = value;
        this.setNotificationType();
        this.checkUOBInfo();
        //Capture comments
        this.openCommentsPopupForPolicyTypeChange();
    }

    openCommentsPopupForPolicyTypeChange() {
        let lookup = new ModalInput();
        lookup.component = ["CommonCommentDialogComponent", "app/bms/components/proposal/process/common.comment.dialog.module", "CommonCommentDialogModule"];
        lookup.datainput = { dialogName: "renewal-type-change" };
        lookup.outputCallback = this.commonCommentDialogCallback;
        lookup.parentCompPRMS = { comp: this };
        lookup.heading = "Enter Reason for Renewal Type Change";
        lookup.icon = "fa fa-comment";
        lookup.containerRef = this.contentArea;
        this.dcl.openLookup(lookup);
    }

    public resetRTInfo() {
        //this._rtService.refreshVPMSRebateByAgent().subscribe();
    }

    public getOrgDn(data, scopeObject) {
        scopeObject.orgDN = data;
    }

    handleIndicatorCheckBox() {
        this.duplicateIndicatorUI = (this.proposal.newBusiness.headerInfo.duplicateIndicator === "true") ? true : false;
        this.channelConflictIndicatorUI = (this.proposal.newBusiness.headerInfo.channelConflictIndicator === "true") ? true : false;
    }

    populateLovs() {
        let mFilter = [];
        this.lovDropDownService.createLOVDataList( ["HandlingBranch", "CampignCode", "UOBSector", "ProductList"] );
        let lovFields = [
            new LOV_Field("ALL", "ALL", "ALL", "ALL", "ALL", "ALL", "BranchList", "LOV", [], "MSIG_BRANCH_MASTER", "HandlingBranch", null),            
            new LOV_Field("ALL", "ALL", "NEW BUSINESS", "ALL", "ALL", "ALL", "Campign Code", "LOV", [], "DESCPF", "CampignCode", "callbackCampignCodes"),
            new LOV_Field( "ALL", "ALL", "NEW BUSINESS", "ALL", "ALL", "ALL", "UOB", "LOV", [], "TABLE", "UOBSector", null )];
           
        this.lovDropDownService.util_populateLOV(lovFields, this);
    }

    setFormDisabled(set: boolean) {
        if (set == true) {
            this.disableForm = "Y";
            this.disableDocReceivedDate = "Y";
        }
        else {
            this.disableForm = "N";
            this.disableDocReceivedDate = "N";
        }

        this.setDocRecDateDisabled();
    }

    ngAfterViewInit() {
        this.setDocRecDateDisabled();
        //jQuery( '.showPopover' ).popover();
        jQuery( '#policyHeaderForm .showPopover' ).tooltip();
    }

    setDocRecDateDisabled() {
        if (this.disableForm == 'N' && this.caseInfo.status != null && (["Draft", "Assessment", "Assessment Approval"].indexOf(this.caseInfo.status) != -1)) {
            this.disableDocReceivedDate = 'N';
        }
        else {
            this.disableDocReceivedDate = 'Y';
        }
    }

    onHBranchInit(ctrl) {
        this.setDefaultBranch(ctrl);
    }

    setDefaultBranch(ctrl) {
        this.getLoggedInUserId(ctrl);
    }

    getLoggedInUserId(ctrl) {
        this._aus.getUserDn().subscribe((data) => this.setBranchByUserId(data, ctrl));
    }

    setBranchByUserId(data, ctrl) {
        if (data != null && ((this.proposalHeader.handlingBranch == null || this.proposalHeader.handlingBranch == "") || (this.caseInfo.handlingBranchId == null || this.caseInfo.handlingBranchId == ""))) {
            let branch;
            // Defaulting Handling branch if user have Banca role - SAF-2017-0921 -- start
            this.isBancaBranch = false;
            this._aus.getUserRoles().subscribe((roleData) => {
                for (let item of roleData) {
                    if (item.includes("cn=Banca")) {
                        branch = item.split("cn=")[1].split("_")[0];
                        this.bancaBranch = branch;
                        this.isBancaBranch = true;
                    }
                }
            });
            if (!this.isBancaBranch) {
                branch = data.substr(5, 2).toUpperCase();
            }  // End
            this.proposalHeader.handlingBranch = branch;
            this.caseInfo.handlingBranchId = branch;
            ctrl.setter(branch, ctrl.comp);
        }
    }

    setProductDetails(values) {
        let product = values.record;
        if ( product == undefined ) {
            product = values;
        }
        this.proposalHeader.contractDescription = product.PRODUCT_NAME;
        this.proposalHeader.lobName = product.LOB_NAME;
        this.proposalHeader.lineOfBusiness = product.LOB_CODE;
        this.proposalHeader.riskScreen = product.RISK_SCREEN_NM;
        //this._rtService.resetRiskList(true);
        //this.onproductchange.emit();
        //this._rtService.setListLock();
        //this.triggerProductChange(this.proposalHeader.contractType);
        this.caseInfo.lineOfBusiness = product.LOB_CODE;
        this.caseInfo.requestType = product.PRODUCT_TYPE;
        if (product.LOB_CODE == 'MTR')
            this.proposalHeader.renewalType = 'M1';
        else
            this.proposalHeader.renewalType = '';
        this.notifDisplayed = false;
        this.checkChannelConflict();
        //this.setMinForStartDate();
        this.setPayPlan(true);
        /* let prom = this.setRenewalType();
        if (prom != null) {
            prom.done(() => this.setNotificationType());
        } */
        
        this.checkMTIAvailability();
        /* this.validateEndDate();
        if (this.proposalHeader.isSimplifiedProcess == 'Y')
            this.setReferred(this);

        // SAF MYS-2018-1249 start
        if (this.proposalHeader.lineOfBusiness == "FIR" && this.proposalHeader.contractType != "LOP" && (["MyTasks", "MyDrafts"].indexOf(this._activatedRoute.snapshot.params['component']) >= 0 || Object.keys(this._activatedRoute.snapshot.params).length == 0)) {
            this._rtService.setRiskScreenActivationInfo(this.proposalHeader.contractType);
        } //End */
    }

    public checkMTIAvailability() {
        let request: GetLOVData = new GetLOVData();
        request.BRANCH = 'ALL';
        request.LOB = 'ALL';
        request.BUSINESS_FUNCTION = 'NEW BUSINESS';
        request.PRODUCT = 'ALL';
        request.OPERATION = 'NEW';
        request.FORM_NAME = 'ALL';
        request.FORM_FIELD_NAME = 'MTI';
        request.FIELD_TYPE = 'LOV';
        request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        request.ADVANCE_CONFIG_XML.FILTERS = new Filter();

        let filter: any = {};

        request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push(filter, { "@FIELD_NAME": 'SUBSTRING(ITEMITEM, 1, 3)', "@FIELD_VALUE": this.proposalHeader.contractType, '@OPERATION': 'EQ', '@CONDITION': 'AND' });
        this._cordysService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.mtiSuccessHandler, this.handleError, true, { comp: this });
    }

    private mtiSuccessHandler(response, prms) {
        if (response.tuple) {
            // Show MTI Component
            prms.comp.proposalHeader.MTI = "Y";
            if (prms.comp.proposalHeader.mtiItems != null)
                prms.comp.proposalHeader.mtiItems.clearMTI();
            else
                prms.comp.proposalHeader.mtiItems = new MTIItems();
        } else {
            prms.comp.proposalHeader.MTI = "N";
            prms.comp.proposalHeader.mtiItems = null;
        }
    }

    openClientLookup() {
        let input = new ModalInput();
        input.parentCompPRMS = { comp: this };
        if (AppUtil.isEmpty(this.proposal.newBusiness.clientDetails.client.clientNumber, false) == false) {
            input.heading = "Client Details";
            input.datainput = { isViewMode: true, clienttype: 'C', clientNumber: this.proposal.newBusiness.clientDetails.client.clientNumber, isReadOnly: 'Y' };
        }
        else if (AppUtil.isEmpty(this.proposal.newBusiness.clientDetails.client.itemNo, false) == false) {
            input.heading = "Prospect Details";
            input.datainput = { isViewMode: true, clienttype: 'P', clientNumber: this.proposal.newBusiness.clientDetails.client.itemNo, isReadOnly: 'Y' };
        }
        if (this.proposal.newBusiness.clientDetails.client.genericDetails.clienttype == "P") {
            input = input.get("PersonalClientComponent");
        }
        else if (this.proposal.newBusiness.clientDetails.client.genericDetails.clienttype == "C") {
            input = input.get("CorporateClientComponent");
        }
        input.icon = "fa fa-file-pdf-o";
        input.containerRef = this.contentArea;

        //Start	E1005
        let resp = this._cordysService.callCordysSoapService("GetClientDetailsRequest", "http://schemas.insurance.com/businessobject/1.0/", { "itemNo": input.datainput.clientNumber, "type": input.datainput.clienttype }, null, this.handleError, false, { comp: this });
        this.proposal.newBusiness.clientDetails.client.clientNumber = resp.responseJSON.success.client.clientNumber;
        //End E1005
        this.dcl.openLookup(input);
    }

    triggerProductChange(product) {
        this.isProductChanged = true;
        this.proposalHeader.marineOpenCover = "";
        this.proposalHeader.setMP("");
        this.mergePOIContractChange();
    }

    mergePOIContractChange() {
        if (AppUtil.isEmpty([this.proposalHeader.contractType, this.proposalHeader.effectiveDate, this.proposalHeader.endDate], true) == false) {
            this._rtService.refreshContractInfo().subscribe((data) => {
                if (this.isProductChanged == true) {
                    this.isProductChanged = false;
                }
                this._rtService.releaseListLock();

                if (this.caseInfo.businessFunction == 'CoverNote' && BMSConstants.getSatus() != "Cover Note Accepted") {
                    BMSConstants.getNewBusinessInfo().risks.clearVPMSCalculation();
                    BMSConstants.getNewBusinessInfo().resetAllPremCalc();
                }
            });
        }

        if (this.caseInfo.businessFunction == 'CoverNote' && BMSConstants.getSatus() != "Cover Note Accepted") {
            BMSConstants.getNewBusinessInfo().risks.clearVPMSCalculation();
            BMSConstants.getNewBusinessInfo().resetAllPremCalc();
        }
    }

    setBranchCode( resp ) {
        if (resp.tuple != null)
            this.proposalHeader.branchCodeForBanca = resp.tuple.old.DESCPF.BRANCH_CODE;
        this.proposalHeader.bancaRequired = "Y";
        this.proposalHeader.bancaRequiredUI = true;
        if (this.bancaComp != null)
            this.bancaComp.defaultBranch(null, true);
    }

    onChangeBlackList(e) {
        if (e.target.checked == false) {
            this.proposalHeader.blackListIndicator = "false";
            this.proposalHeader.blackListIndicatorUI = false;
        }
        else {
            this.proposalHeader.blackListIndicator = "true";
            this.proposalHeader.blackListIndicatorUI = true;
        }
        this.setReferred(this);
    }

    setClientDetails( comp, type, clientNumber ) {
        return comp._cordysService.callCordysSoapService("GetClientDetailsRequest", "http://schemas.insurance.com/businessobject/1.0/", { "itemNo": clientNumber, "type": type }, this.getClientDataCallBack, this.handleError, true, { comp: comp });
    }

    getClientDataCallBack(response, prms) {
        prms.comp.proposal.newBusiness.clientDetails.refresh(response.success);
        prms.comp.setInsuredPersonType(prms.comp.proposal.newBusiness.clientDetails);
    }

    setInsuredPersonType(clientDetails: ClientDetails) {
        this.insuredPersonType = "";
        if (AppUtil.isEmpty(AppUtil.getValueByPath(clientDetails, "client.genericDetails.clienttype"), false) == false) {
            if (AppUtil.isEmpty(clientDetails.client.clientNumber, false) == false) {
                this.insuredPersonType = "Client";
            }
            else if (AppUtil.isEmpty(clientDetails.client.itemNo, false) == false) {
                this.insuredPersonType = "Prospect";
            }
        }
    }

    handleError(response, status, errorText, prms) {
        prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, response.responseJSON.faultstring.text, -1));
    }

    showError(response) {
        this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, response.responseJSON.faultstring.text, -1));
    }

    openAgentLookup() {
        let si = new SearchInput();
        let input = new ModalInput().get( "GenericSearchComponent" );
        si.BRANCH = 'ALL',
            si.LOB = 'ALL';
        si.BUSINESS_FUNCTION = 'ALL';
        si.PRODUCT = 'ALL';
        si.OPERATION = 'ALL';
        si.FORM_NAME = 'ALL';
        //MRA001 chnages start 
        if ( BMSConstants.getBMSType() == BMSType.Renewal ) {

            si.FORM_FIELD_NAME = 'AGENT_CODE';// MRA001
            si.FIELD_TYPE = 'LOOKUP';
            si.isSingleSelect = true;

            si.condition = { "DATEEND": moment( new Date() ).format( "YYYYMMDD" ) };

            if ( AppUtil.isEmpty( this.proposalHeader.servicingBranch, false ) == false )
                si.condition["AGENT_CODE"] = this.proposalHeader.servicingBranch;


            input.datainput = si;
            input.heading = "Agent Details";
            input.icon = "fa fa-file-pdf-o";
            input.containerRef = this.contentArea;
        }
        else {
            si.FORM_FIELD_NAME = 'AGENT_CODE_NEW';// MRA001
            si.FIELD_TYPE = 'LOOKUP';
            si.isSingleSelect = true;
            si.replaceField = { "value5": moment( new Date() ).format( "YYYYMMDD" ) };//MRA001
            si.isDefaultFilterRequired = false;
            //si.condition = { "DATEEND": moment(new Date()).format("YYYYMMDD") };// MRA001



            input.datainput = si;
            input.heading = "Agent Details(transferred agent will be displayed if agent is terminated)";//MRA001
            input.icon = "fa fa-file-pdf-o";
            input.containerRef = this.contentArea;

        }
        this.dcl.openLookup( input ).subscribe( ( data ) => {
            this.setAgent( data.data[0].old.AGNTPF );
            this.checkBancaInfo( false );
        });
    }
    setAgent( data ) {
        let agent = data;
        if ( BMSConstants.getBMSType() == BMSType.Renewal ) {
            this.setReferred( this );

        }

        this.proposalHeader.agentCode = agent.AGENT_CODE;
        this._coiService.checkCOIRequired( this.proposalHeader.agentCode ).subscribe();
        this.proposalHeader.agentName = agent.AGENT_NAME;
        this.proposalHeader.servicingBranch = agent.AGENT_BRANCH;
        this.proposalHeader.serviceBranchName = agent.BRANCH_DESC;
        this.proposalHeader.businessChannel = agent.BUSINESS_CHANNEL;
        this.proposalHeader.agentPhone1 = agent.CLTPHONE01;
        this.proposalHeader.agentPhone2 = agent.CLTPHONE02;
        this._rtService.resetRebateByAgent().subscribe();
        this.proposalHeader.bancaChannel = agent.ZMISCHNL;
        this.proposalHeader.businessChannelName = agent.BUS_CHN_DESC;
        this.proposalHeader.producerCode = agent.PRODUCER_CODE;
        this.proposalHeader.misSubTier = agent.SUBTIER;
        this.proposalHeader.isJapaneseChannel = this.checkForJapaneseChannel( agent.ZMISCHNL, this.proposalHeader.misSubTier );
        this.caseInfo.division = agent.BRANCH_DESC;
        //AL001 START
        //prms.comp.getAccountHandler(prms.comp,false);
        this.getAccountHandlerByBranchAndApplication( this, false );
        //AL001 END
        this.notifDisplayed = false;
        this.checkChannelConflict();
        //prms.comp.checkPayPlan(prms.comp,"Y");
        //Divek MYS-2018-0582 changes Start       
        this.proposalHeader.rebate = ( this.proposalHeader.businessChannel == '04' && this.proposalHeader.isVPMS == 'N' ) ? this.proposalHeader.maxRebate : 0;
        //END
        // SAF MYS-2018-0146	
        this.proposalHeader.agentClientNum = agent.CLIENT_NUM;
        this.proposalHeader.agentClientSurName = agent.CLIENT_SURNAME;
        this.proposalHeader.agentClientGivName = agent.CLIENT_GIVNAME;
        this.proposalHeader.agentClientPhone = agent.CLIENT_PHONE;
        //MRA001 Changes END
        // KU001 Start
        this.OldAgentType = this.NewAgentType;
        // KU001 End
    }

    setAgentEditMode() {
        if ( BMSConstants.getBMSType() == BMSType.Renewal && ( this.caseInfo.status == 'Draft' || this.caseInfo.status == 'Assessment' || this.caseInfo.status == 'Assessment Approval' ) ) {
            this.isAgentEditMode = true;
        }
        else {
            if ( this.caseInfo.status == 'Draft' )
                this.isAgentEditMode = true;
            else
                this.isAgentEditMode = false;
        }
    }

    private viewAgentDetails(control, agentCode) {
        let input = new ModalInput();
        input.component = ["AgentDetailsComponent", "app/bms/components/proposal/proposalheader/dialogs/agent.details.module", "AgentDetailsModule"];
        input.datainput = {
            agentCode: agentCode
        };
        input.parentCompPRMS = { comp: this };
        input.heading = "Agent Details";
        input.icon = "fa fa-eye";
        input.containerRef = this.contentArea;
        this.dcl.openLookup(input);
    }

    checkBlackList() {
        let code: string = this.getIdNo();
        let IdNumber: string = "";

        if (this.proposal.newBusiness.clientDetails.client.genericDetails.clienttype == 'P' && this.proposal.newBusiness.clientDetails.client.personalClientDetails.IdNumber != undefined &&
            this.proposal.newBusiness.clientDetails.client.personalClientDetails.IdNumber != "") {
            IdNumber = this.proposal.newBusiness.clientDetails.client.personalClientDetails.IdNumber;
        }
        if ((code || IdNumber) && this.proposalHeader.effectiveDate) {
            let request: GetLOVData = new GetLOVData();
            request.BRANCH = 'ALL';
            request.LOB = 'ALL';
            request.BUSINESS_FUNCTION = 'NEW BUSINESS';
            request.PRODUCT = 'ALL';
            request.OPERATION = 'NEW';
            request.FORM_NAME = 'ALL';
            request.FORM_FIELD_NAME = 'Blacklisted Client';
            request.FIELD_TYPE = 'LOV';
            request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
            request.ADVANCE_CONFIG_XML.FILTERS = new Filter();

            if (this.proposal.newBusiness.clientDetails.client.genericDetails.clienttype == 'P' && this.proposal.newBusiness.clientDetails.client.personalClientDetails.IdNumber != undefined &&
                this.proposal.newBusiness.clientDetails.client.personalClientDetails.IdNumber != "") {
                IdNumber = this.proposal.newBusiness.clientDetails.client.personalClientDetails.IdNumber;
            }

            let filter: any = {};
            if (code != undefined && code != "")
                filter = { "@FIELD_NAME": 'ZNRICBSRG', "@FIELD_VALUE": code, '@OPERATION': 'EQ', '@CONDITION': 'AND' }
            //else if (this.proposal.newBusiness.clientDetails.client.personalClientDetails.IdNumber) //GA004
            else if (IdNumber != undefined && IdNumber != "")
                filter = { "@FIELD_NAME": 'ZOLDICPAS', "@FIELD_VALUE": IdNumber, '@OPERATION': 'EQ', '@CONDITION': 'AND' }
            //GA004
            //this.proposal.newBusiness.clientDetails.client.personalClientDetails.IdNumber, '@OPERATION': 'EQ', '@CONDITION': 'AND' }

            request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push(filter, { "@FIELD_NAME": 'ZBLOCKDTE', "@FIELD_VALUE": moment(this.proposalHeader.effectiveDate, "YYYY-MM-DD").format("YYYYMMDD"), '@OPERATION': 'LT', '@CONDITION': 'AND' },
                { "@FIELD_NAME": 'RELEASE_DATE', "@FIELD_VALUE": moment(this.proposalHeader.effectiveDate, "YYYY-MM-DD").format("YYYYMMDD"), '@OPERATION': 'GT', '@CONDITION': 'AND' });
            this._cordysService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.blackListSuccessHandler, this.handleError, true, { comp: this });
        }
    }

    checkChannelConflict() {

        if (this.proposal.newBusiness.headerInfo.isConflictResolvedByUser == "true") {
            return;
        }
        if (this.caseInfo.status != "Draft") {
            return;
        }
        if (BMSConstants.getBMSType() == BMSType.RenewalRerate || BMSConstants.getBMSType() == BMSType.Renewal) {
            return;
        }

        let code: string = this.getIdNo();
        let IdNumber: string = "";


        if (this.proposal.newBusiness.clientDetails.client.genericDetails.clienttype == 'P' && this.proposal.newBusiness.clientDetails.client.personalClientDetails.IdNumber != undefined)
            IdNumber = this.proposal.newBusiness.clientDetails.client.personalClientDetails.IdNumber;
        if ((code || IdNumber) && this.proposalHeader.effectiveDate && this.proposalHeader.endDate && this.proposalHeader.contractType && this.proposalHeader.businessChannel) {
            let initiatedOn: string = this.caseInfo.initiatedOn;
            if (initiatedOn == undefined || initiatedOn == null || initiatedOn == "") {
                initiatedOn = moment.utc(new Date()).format();
                initiatedOn = initiatedOn.substring(0, initiatedOn.length - 1);
            }
            this._cordysService.callCordysSoapService("GetChannelConflictV2", "http://schemas.cordys.com/bmsintegrationapp", { "APPLICATION_NAME": "BMS", "STATUS": "Closed','Deleted", "CODE": code, "ID_NUMBER": IdNumber, "CONTRACTTYPE": this.proposalHeader.contractType, "EFFECTIVEDATE": this.proposalHeader.effectiveDate, "ENDDATE": this.proposalHeader.endDate, "INITIATED_ON": initiatedOn }, this.channelConflictHandler, this.handleError, true, { comp: this });
        }
    }

    changeCheckBox(checkBox, type) {
        if (checkBox.checked) {
            if (type === 'CHANNELCONFLICT') {
                this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Channel conflict cannot be checked manually", -1));
                checkBox.checked = false;
                this.channelConflictIndicatorUI = false;
                this.proposal.newBusiness.headerInfo.channelConflictIndicator = "false";
            } else if (type === 'DUPLICATE') {
                this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Duplicate indicator cannot be checked manually", -1));
                checkBox.checked = false;
                this.duplicateIndicatorUI = false;
                this.proposal.newBusiness.headerInfo.duplicateIndicator = "false";
            }
        } else {
            // to handle pop-up close window option
            checkBox.checked = true;
            this.checkBoxRef = checkBox;
            // Create Process history record for resolving channel conflict
            let lookup = new ModalInput();
            lookup.component = ["CommonCommentDialogComponent", "app/bms/components/proposal/process/common.comment.dialog.module", "CommonCommentDialogModule"];
            if (type === 'CHANNELCONFLICT') {
                lookup.datainput = { dialogName: "resolve-channel-conflict" };
            } else if (type === 'DUPLICATE') {
                lookup.datainput = { dialogName: "resolve-duplicate" };
            }
            lookup.outputCallback = this.commonCommentDialogCallback;
            lookup.parentCompPRMS = { comp: this };
            if (type === 'CHANNELCONFLICT') {
                lookup.heading = "Enter Reason for channel conflict resolve";
            } else if (type === 'DUPLICATE') {
                lookup.heading = "Enter Reason for duplicate resolve";
            }
            lookup.icon = "fa fa-comment";
            lookup.containerRef = this.contentArea;
            this.dcl.openLookup(lookup);
        }
    }


    commonCommentDialogCallback(data, prms) {
        if (data.isDialogCancelled) {
            if (data.dialogName === 'resolve-channel-conflict') {
                prms.comp.checkBoxRef.checked = true;
                prms.comp.channelConflictIndicatorUI = true;
                prms.comp.proposal.newBusiness.headerInfo.channelConflictIndicator = "true";
                prms.comp.proposal.newBusiness.headerInfo.isConflictResolvedByUser = "false";
            } else if (data.dialogName === 'resolve-duplicate') {
                prms.comp.duplicateIndicatorUI = true;
                prms.comp.proposal.newBusiness.headerInfo.duplicateIndicator = "true";
                prms.comp.proposal.newBusiness.headerInfo.isConflictResolvedByUser = "false";
            }
            return;
        }
        else if (!data.isDialogCancelled && data.dialogName == "AML-CDD-Comments") {
            let commentsState = (prms.comp.proposal.newBusiness.headerInfo.AMLCDDComments.trim() != '') ? 'updated' : 'added';
            prms.comp.proposal.newBusiness.headerInfo.AMLCDDComments = data.comments;
            // prms.comp.proposal.newBusiness.headerInfo.AMLCDDCheck = "true";
            // prms.comp.proposal.newBusiness.headerInfo.AMLCDDCheckUI = true;
        }
        else {
            if (data.dialogName != "renewal-type-change" && prms.comp.checkBoxRef != undefined) {
                prms.comp.checkBoxRef.checked = false;
            }

            let historyObj = null;

            if (data.dialogName == "resolve-channel-conflict") {
                prms.comp.proposal.newBusiness.headerInfo.channelConflictIndicator = "false";
                prms.comp.proposal.newBusiness.headerInfo.isConflictResolvedByUser = "true";
                historyObj = { action: "Conflict Resolved", comment: data.comments, isPrivate: "", roleName: "", target: "SELF", targetType: "SELF", user: "", userName: "" };
            } else if (data.dialogName == "resolve-duplicate") {
                prms.comp.proposal.newBusiness.headerInfo.duplicateIndicator = "false";
                prms.comp.proposal.newBusiness.headerInfo.isConflictResolvedByUser = "true";
                historyObj = { action: "Duplicate Resolved", comment: data.comments, isPrivate: "", roleName: "", target: "SELF", targetType: "SELF", user: "", userName: "" };
            }
            else if (data.dialogName == "renewal-type-change") {
                historyObj = { action: "Renewal Type Changed", comment: data.comments, isPrivate: "", roleName: "", target: "SELF", targetType: "SELF", user: "", userName: "" };
            }
            if (prms.comp.loggedInUser == "") {
                prms.comp._aus.getUserFullName().subscribe((user) => {
                    prms.comp.loggedInUser = user;
                    historyObj.user = prms.comp.loggedInUser;
                    historyObj.userName = prms.comp.loggedInUser;
                    prms.comp.caseInfo.approvalInfo.addItem(historyObj);
                    prms.comp._appObjService.saveData().subscribe();
                });
            }
            else {
                historyObj.user = prms.comp.loggedInUser;
                historyObj.userName = prms.comp.loggedInUser;
                prms.comp.caseInfo.approvalInfo.addItem(historyObj);
                prms.comp._appObjService.saveData().subscribe();
            }
        }
    }

    getIdNo(): string {
        if (this.proposal.newBusiness.clientDetails) {
            if (this.proposal.newBusiness.clientDetails.client.genericDetails.clienttype == 'C')
                return this.proposal.newBusiness.clientDetails.client.corporateClientDetails.BusinessRegNo;
            else if (this.proposal.newBusiness.clientDetails.client.genericDetails.clienttype == 'P')
                if (this.proposal.newBusiness.clientDetails.client.personalClientDetails.NRICNo)
                    return this.proposal.newBusiness.clientDetails.client.personalClientDetails.NRICNo;
                else
                    return "";
        }
    }

    blackListSuccessHandler(response, prms) {
        if (response.tuple != null) {
            prms.comp.proposalHeader.blackListIndicator = "true";
            prms.comp.proposalHeader.blackListIndicatorUI = true;
            prms.comp.proposalHeader.blackListInternalIndicator = (response.tuple.old.ZBLCPF.ZIEIND == 'I') ? "Y" : "N";
            prms.comp.proposalHeader.blackListReason = response.tuple.old.ZBLCPF.REMARKS;
            prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Selected Client is BlackListed in Policy Inception Date.", 5000));
        }
        else {
            prms.comp.proposalHeader.blackListIndicator = "false";
            prms.comp.proposalHeader.blackListIndicatorUI = false;
            prms.comp.proposalHeader.blackListInternalIndicator = 'N';
        }
        prms.comp.setReferred(prms.comp);
    }

    channelConflictHandler(response, prms) {
        prms.comp.proposalHeader.channelConflictedCaseId = "";
        prms.comp.proposalHeader.channelConflictIndicator = "false";
        prms.comp.proposalHeader.duplicateIndicator = "false";
        prms.comp.channelConflictIndicatorUI = false;
        prms.comp.duplicateIndicatorUI = false;
        let ary = [];
        let count = 0;

        if (response.tuple != null && !Array.prototype.isPrototypeOf(response.tuple)) {
            ary = [response.tuple];
        }
        else if (response.tuple != null) {
            ary = response.tuple;
        }

        for (let item of ary) {
            count++;
            if (item.old.MSIG_BUSINESS_OBJECT && prms.comp.caseInfo.caseId != item.old.MSIG_BUSINESS_OBJECT.CASE_ID) {
                if (prms.comp.proposalHeader.agentCode == item.old.MSIG_BUSINESS_OBJECT.AGENTCODE) {
                    prms.comp.proposalHeader.duplicateIndicator = "true";
                    prms.comp.proposalHeader.channelConflictIndicator = "false";
                    prms.comp.duplicateIndicatorUI = true;
                    prms.comp.channelConflictIndicatorUI = false;
                    prms.comp.proposalHeader.channelConflictedCaseId = prms.comp.proposalHeader.channelConflictedCaseId + item.old.MSIG_BUSINESS_OBJECT.CASE_ID;
                } else {
                    if (prms.comp.proposal.newBusiness.clientDetails.client.genericDetails.clienttype == 'P') {
                        continue;
                    }
                    prms.comp.proposalHeader.channelConflictIndicator = "true";
                    prms.comp.proposalHeader.duplicateIndicator = "false";
                    prms.comp.channelConflictIndicatorUI = true;
                    prms.comp.duplicateIndicatorUI = false;
                    prms.comp.proposalHeader.channelConflictedCaseId = prms.comp.proposalHeader.channelConflictedCaseId + item.old.MSIG_BUSINESS_OBJECT.CASE_ID;
                }
                if (ary.length != count)
                    prms.comp.proposalHeader.channelConflictedCaseId = prms.comp.proposalHeader.channelConflictedCaseId + ",";
            } else if (prms.comp.proposalHeader.channelConflictedCaseId == "") {
                prms.comp.proposalHeader.channelConflictIndicator = "false";
                prms.comp.proposalHeader.duplicateIndicator = "false";
                prms.comp.channelConflictIndicatorUI = false;
                prms.comp.duplicateIndicatorUI = false;
                prms.comp.proposalHeader.channelConflictedCaseId = "";
            }
        }
        if (prms.comp.proposalHeader.channelConflictedCaseId.endsWith(",")) {
            prms.comp.proposalHeader.channelConflictedCaseId = prms.comp.proposalHeader.channelConflictedCaseId.substring(0, prms.comp.proposalHeader.channelConflictedCaseId.lastIndexOf(","));
        }
        if (prms.comp.duplicateIndicatorUI && BMSConstants.getBMSType() != BMSType.RenewalRerate && BMSConstants.getBMSType() != BMSType.Renewal) {
            // Display notification for duplicate indicator
            if (!prms.comp.notifDisplayed) {
                prms.comp.notifDisplayed = true;
                prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Duplicate case(s) identified", -1));
            }

        } else if (prms.comp.channelConflictIndicatorUI) {
            // Display notification for channel conflict indicator
            //prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Channel conflict identified" , -1));
        }
    }

    checkForJapaneseChannel(busChannelCode, subTier) {
        if (busChannelCode == "MF" || ["AJ", "BJ", "JC", "JD", "JCRHB", "JDRHB", "JCOCA", "JDOCA"].indexOf(subTier) != -1) {
            return "true";
        }
        return "false";
    }

    refreshAHList() {
        this.resetAHData();
        //this.getAccountHandler(this,false);	
        this.getAccountHandlerByBranchAndApplication(this, false);
    }

    resetAHData() {
        this.ahList = [];
        this.caseInfo.accountHandler = null;
        this.proposalHeader.accountHandler = null;
        this.caseInfo.accountHandlerName = null;
    }

    getAccountHandler(comp, forceNotSetAH: boolean) {
        if (comp.ahList.length == 0 && comp.proposalHeader.handlingBranch != null && comp.proposalHeader.handlingBranch != "") {
            comp._cordysService.callCordysSoapService("GetAccountHandlersFromBranch", "http://schemas.cordys.com/msig/masterdata/1.0", { BRANCH_CODE: comp.proposalHeader.handlingBranch }, this.setAccountHandler, this.showAHError, true, { comp: comp, forceNotSetAH: forceNotSetAH });
        }
        else if (comp.ahList.length != 0 && forceNotSetAH == false) {
            comp.setDefaultAH(comp);
        }
    }
    
    getAccountHandlerByBranchAndApplication(comp, forceNotSetAH: boolean) {
        if (comp.ahList.length == 0 && comp.proposalHeader.handlingBranch != null && comp.proposalHeader.handlingBranch != "") {
            comp._cordysService.callCordysSoapService("GetAccountHandlersByBranchAndApplication", "http://schemas.cordys.com/msig/masterdata/1.0", { "BRANCH_CODE": comp.proposalHeader.handlingBranch, "APP_TYPE": 'BMS' }, this.setAccountHandler, this.showAHError, true, { comp: comp, forceNotSetAH: forceNotSetAH });

        }
        else if (comp.ahList.length != 0 && forceNotSetAH == false) {
            comp.setDefaultAH(comp);
        }
    }

    setAHName(elmnt) {
        /* this.caseInfo.accountHandlerName = jQuery(elmnt).find("option:selected").text();
        if (event != null && event.target != null) {
            let ah: any = event.target;
            this.proposalHeader.accountHandler = ah.value;
            //Renewal fix for CSE 
            if (this.caseInfo.businessFunction == "Renewal" && ah.value != "" && ah.value != null) {
                this.getAHRole();
            }
        } */
        this.caseInfo.accountHandlerName = elmnt.description;
        this.caseInfo.accountHandler = elmnt.value;
        this.proposalHeader.accountHandler = elmnt.value;
    }

    private getAHRole() {
        this._cordysService.callCordysSoapService("GetRolesForBranchLOBUser",
            "http://schemas.cordys.com/msig/masterdata/1.0",
            this.getGetAHRoleParams(),
            this.getAHRoleSuccessHandler,
            this.getAHRoleErrorHandler,
            true, this)
    }

    private getGetAHRoleParams() {
        return {
            "BRANCH_CODE": BMSConstants.getBMSObj().ApplicationBusinessObject.caseInfo.handlingBranchId,
            "LOB_CODE": BMSConstants.getBMSObj().ApplicationBusinessObject.caseInfo.lineOfBusiness,
            "USER_ID": BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.accountHandler,
            "APPLICATION": "BMS",
            "BUSINESS_FUNCTION": "NB"
        }
    }

    private getAHRoleSuccessHandler(data, scopeObject) {
        if (data.tuple) {
            BMSConstants.getBMSObj().ApplicationBusinessObject.processObject.accountHandlerRoleDn = data.tuple.old.MSIG_BRANCH_LOB_ROLE_USER_MAPPING.BRANCH_CODE + "_" + data.tuple.old.MSIG_BRANCH_LOB_ROLE_USER_MAPPING.LOB_CODE + "_" + data.tuple.old.MSIG_BRANCH_LOB_ROLE_USER_MAPPING.ROLE_CODE;
            BMSConstants.getBMSObj().ApplicationBusinessObject.processObject.caseHandlerRoleDn = "cn=" + BMSConstants.getBMSObj().ApplicationBusinessObject.processObject.accountHandlerRoleDn + ",cn=organizational roles," + scopeObject.orgDN;
        }

    }

    private getAHRoleErrorHandler(response, status, errorText, extraParams) {
        extraParams._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error getting the AH role", -1));
    }

    setDefaultAH(comp) {
        let deafultAH = comp.ahList.filter(ah => comp.proposalHeader.producerCode != null && ah.PRODUCER_CODE == comp.proposalHeader.producerCode);
        if (deafultAH != null && Array.prototype.isPrototypeOf(deafultAH) == true && deafultAH.length != 0) {
            let ah = deafultAH[0];
            comp.caseInfo.accountHandler = ah.USER_ID;
            comp.proposalHeader.accountHandler = ah.USER_ID;
            comp.caseInfo.accountHandlerName = ah.USER_FULL_NAME;
        }
        else {
            comp.caseInfo.accountHandler = "";
            comp.proposalHeader.accountHandler = "";
            comp.caseInfo.accountHandlerName = "";
        }
    }

    setAccountHandler(response, prms) {
        let ahItems = [];
        if (response.tuple != null && !Array.prototype.isPrototypeOf(response.tuple)) {
            ahItems = [response.tuple];
        }
        else if (response.tuple != null) {
            ahItems = response.tuple;
        }
        for (let ahinfo of ahItems) {
            let ah = new AHInfo(ahinfo.old.MSIG_BRANCH_LOB_ROLE_USER_MAPPING.USER_ID, ahinfo.old.MSIG_BRANCH_LOB_ROLE_USER_MAPPING.USER_FULL_NAME, ahinfo.old.MSIG_BRANCH_LOB_ROLE_USER_MAPPING.PRODUCER_CODE);
            prms.comp.ahList.push(ah);
        }
        if (prms.forceNotSetAH == false)
            prms.comp.setDefaultAH(prms.comp);
    }

    showAHError(error, prms) {

    }

    setPayPlan(checkBanca) {
        if (this.proposalHeader.contractType != null && this.proposalHeader.contractType != "") {
            if (checkBanca == true)
                this.proposalHeader.payPlan = "";
            let request: GetLOVData = new GetLOVData();
            request.BRANCH = 'ALL';
            request.LOB = 'ALL';
            request.BUSINESS_FUNCTION = 'NEW BUSINESS';
            request.PRODUCT = 'ALL';
            request.OPERATION = 'ALL';
            request.FORM_NAME = 'ALL';
            request.FORM_FIELD_NAME = 'PayPlan';
            request.FIELD_TYPE = 'LOV';
            request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
            request.ADVANCE_CONFIG_XML.FILTERS = new Filter();

            request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({ "@FIELD_NAME": 'A.DESCITEM', "@FIELD_VALUE": this.proposalHeader.contractType, '@OPERATION': 'EQ', '@CONDITION': 'AND' });
            let prom = this._cordysService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, null, null, true, null);
            prom.success((response) => this.payPlanHandler(response, checkBanca));
            prom.error((error) => this.showError(error));
        }
    }

    payPlanHandler(response, checkBanca) {
        let ppItems = [];
        ppItems = new AppUtil().getArray(response.tuple);
        this.payPlanList = [];
        for (let ppinfo of ppItems) {
            let pp = new PayPlanInfo(ppinfo.old.T3681.PAY_PLAN_VALUE, ppinfo.old.T3681.PAY_PLAN_DESC, ppinfo.old.T3681.PAYPLANSEQ);
            this.payPlanList.push(pp);
        }
        this.setDefaultPayPlan();
        if (checkBanca == true)
            this.checkBancaInfo(false);
    }

    setDefaultPayPlan() {
        if ((this.proposalHeader.payPlan == undefined || this.proposalHeader.payPlan == '') && this.payPlanList.length > 0) {
            this.proposalHeader.payPlan = this.payPlanList[0].PAY_PLAN_VALUE;
        }
    }

    getPayPlanSequence(payPlan) {
        let seq = -1;
        let correctPayPlan = [];
        if (this.payPlanList != null)
            correctPayPlan = this.payPlanList.filter((item) => item.PAY_PLAN_VALUE == payPlan);
        if (correctPayPlan.length > 0)
            seq = correctPayPlan[0].PAYPLANSEQ;
        return seq;
    }

    setRenewalType() {
        let prom = null;
        if (this.proposalHeader.contractType != null && this.proposalHeader.contractType != "") {
            let request: GetLOVData = new GetLOVData();
            request.BRANCH = 'ALL';
            request.LOB = 'ALL';
            request.BUSINESS_FUNCTION = 'NEW BUSINESS';
            request.PRODUCT = 'ALL';
            request.OPERATION = 'ALL';
            request.FORM_NAME = 'ALL';
            request.FORM_FIELD_NAME = 'RenewalType';
            request.FIELD_TYPE = 'LOV';
            request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
            request.ADVANCE_CONFIG_XML.FILTERS = new Filter();

            let _descItems = "'***','" + this.proposalHeader.contractType + "'";
            // request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({"@FIELD_NAME":'A.DESCITEM',"@FIELD_VALUE":this.proposalHeader.contractType ,'@OPERATION':'EQ','@CONDITION':'AND'});
            request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({ "@FIELD_NAME": 'A.DESCITEM', "@FIELD_VALUE": _descItems, '@OPERATION': 'IN', '@CONDITION': 'AND' });
            prom = this._cordysService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.renewalTypeHandler, this.handleError, true, { comp: this });
        }
        return prom;
    }

    renewalTypeHandler(response, prms) {
        let ppItems = [];

        if (response.tuple) {
            ppItems = new AppUtil().getArray(response.tuple);
        }

        prms.comp.rnlTypeList = [];

        if (ppItems.length > 0) {
            let _hasPPItemForProduct = ppItems.some(_item => _item.old.T4695.DESCITEM == prms.comp.proposalHeader.contractType);
            if (_hasPPItemForProduct) {
                ppItems = ppItems.filter(_item => _item.old.T4695.DESCITEM != '***');
            }
        }

        for (let ppinfo of ppItems) {
            let pp = new RenewalTypeInfo(ppinfo.old.T4695.RNLTYPE, ppinfo.old.T4695.RNLTYPEDESC, ppinfo.old.T4695.RNLTYPESEQ);
            prms.comp.rnlTypeList.push(pp);
        }
        if (prms.comp.rnlTypeList.length > 0)
            prms.comp.setDefaultRenewalType(prms.comp);
    }

    setDefaultRenewalType(comp) {
        if (comp.proposalHeader.renewalType == undefined || comp.proposalHeader.renewalType == '')
            comp.proposalHeader.renewalType = comp.rnlTypeList[0].RNL_TYPE_VALUE;
    }

    setNotificationType() {
        if (this.proposalHeader.contractType != null && this.proposalHeader.contractType != "") {
            let request: GetLOVData = new GetLOVData();
            request.BRANCH = 'ALL';
            request.LOB = 'ALL';
            request.BUSINESS_FUNCTION = 'NEW BUSINESS';
            request.PRODUCT = 'ALL';
            request.OPERATION = 'ALL';
            request.FORM_NAME = 'ALL';
            request.FORM_FIELD_NAME = 'NotificationType';
            request.FIELD_TYPE = 'LOV';
            request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
            request.ADVANCE_CONFIG_XML.FILTERS = new Filter();

            let _descItems = "'***','" + this.proposalHeader.contractType + "'";

            request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({ "@FIELD_NAME": 'A.DESCITEM', "@FIELD_VALUE": _descItems, '@OPERATION': 'IN', '@CONDITION': 'AND' },
                { "@FIELD_NAME": 'A.RNLTYPE', "@FIELD_VALUE": this.proposalHeader.renewalType, '@OPERATION': 'EQ', '@CONDITION': 'AND' });
            this._cordysService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.notificationTypeHandler, this.handleError, true, { comp: this });
        }
    }

    notificationTypeHandler(response, prms) {
        let notifItems = [];

        if (response.tuple) {
            notifItems = new AppUtil().getArray(response.tuple);
        }

        prms.comp.notificationTypeList = [];

        if (notifItems.length > 0) {
            let _hasItemForProduct = notifItems.some(_item => _item.old.T4695.DESCITEM == prms.comp.proposalHeader.contractType);

            if (_hasItemForProduct) {
                notifItems = notifItems.filter(_item => _item.old.T4695.DESCITEM != '***');
            }
        }

        for (let notifinfo of notifItems) {
            let pp = new NotificatTypeInfo(notifinfo.old.T4695.RNLTYPE, notifinfo.old.T4695.NOT_TYPE_VALUE, notifinfo.old.T4695.NOT_TYPE_DESC, notifinfo.old.T4695.RNLNOTSSEQ);
            prms.comp.notificationTypeList.push(pp);
        }
        if (prms.comp.notificationTypeList.length > 0)
            prms.comp.setDefaultNotificfationType(prms.comp);
    }

    setDefaultNotificfationType(comp) {
        if (comp.proposalHeader.renewalType) {
            for (let eachItem of comp.notificationTypeList) {
                if (eachItem["RNLTYPE"] != null && eachItem["RNLTYPE"] != "" && eachItem["RNLTYPE"] == comp.proposalHeader.renewalType && eachItem["RNLNOTSSEQ"] == "1") {
                    comp.proposalHeader.noticeType = eachItem["NOT_TYPE_VALUE"]
                }
            }
        }
    }

    hasRisks() {
        if (this.proposal.newBusiness.risks != null) {
            let risks = new RisksValidator(this.proposal.newBusiness.risks);
            return risks.hasRisks();
        }
        return false;
    }

    resetCoinsurance(value) {
        value = value ? 'Y' : 'N';
        this.proposalHeader.CoInsurance = value;
        this._coiService.resetCOI(value);
    }
    setMinForStartDate() {
        if (this.caseInfo.businessFunction != "Renewal" && this.caseInfo.businessFunction != "RenewalRerate" && this.caseInfo.businessFunction != "MiscCN") {
            if (this.startDateCtrl != null) {
                if (this.caseInfo.caseId == undefined || this.caseInfo.caseId == "") {
                    if (this.proposalHeader.lineOfBusiness && this.proposalHeader.lineOfBusiness != "MTR") {
                        this.startDateCtrl.setMinDate(moment().subtract(1, 'year').format(this.getDateFormat()), this.startDateCtrl.comp);
                    } else if (this.proposalHeader.lineOfBusiness && this.proposalHeader.lineOfBusiness == "MTR" && ["MSW", "MWP", "MPA", "DPA"].indexOf(this.proposalHeader.contractType) != -1) {
                        this.startDateCtrl.setMinDate(moment().subtract(1, 'year').format(this.getDateFormat()), this.startDateCtrl.comp);
                    } else {
                        if (["CVF", "HVF", "MTF", "MPF", "MCF"].indexOf(this.proposalHeader.contractType) != -1) {
                            this.startDateCtrl.setMinDate(moment().subtract(30, 'days').format(this.getDateFormat()), this.startDateCtrl.comp);
                        }
                        else {
                            this.startDateCtrl.setMinDate(moment().format(this.getDateFormat()), this.startDateCtrl.comp);
                        }
                    }
                } else {

                    if (["CVF", "HVF", "MTF", "MPF", "MCF"].indexOf(this.proposalHeader.contractType) != -1) {
                        this.startDateCtrl.setMinDate(moment(this.caseInfo.initiatedOn, "YYYY-MM-DD").subtract(30, 'days').format(this.getDateFormat()), this.startDateCtrl.comp);
                    } else {
                        if (this.proposalHeader.lineOfBusiness && this.proposalHeader.lineOfBusiness != "MTR") {
                            this.startDateCtrl.setMinDate(moment(this.caseInfo.initiatedOn).subtract(1, 'year').format(this.getDateFormat()), this.startDateCtrl.comp);
                        } else if (this.proposalHeader.lineOfBusiness && this.proposalHeader.lineOfBusiness == "MTR" && ["MSW", "MWP", "MPA", "DPA"].indexOf(this.proposalHeader.contractType) != -1) {
                            this.startDateCtrl.setMinDate(moment().subtract(1, 'year').format(this.getDateFormat()), this.startDateCtrl.comp);
                        } else {
                            if (this.proposalHeader.effectiveDate != '') {
                                if (moment(this.proposalHeader.effectiveDate, "YYYY-MM-DD") > moment()) {
                                    this.startDateCtrl.setMinDate(moment().format(this.getDateFormat()), this.startDateCtrl.comp);
                                }
                                else {
                                    this.startDateCtrl.setMinDate(moment(this.proposalHeader.effectiveDate, "YYYY-MM-DD").format(this.getDateFormat()), this.startDateCtrl.comp);
                                }
                            }

                        }
                    }

                }
            }
        }
    }

    setMinDateForFleetPolicy() {
        if (this.startDateCtrl != null) {
            if (this.caseInfo.caseId == undefined || this.caseInfo.caseId == "") {
                if (["CVF", "HVF", "MTF", "MPF", "MCF"].indexOf(this.proposalHeader.contractType) != -1) {
                    this.startDateCtrl.setMinDate(moment().subtract(30, 'days').format(this.getDateFormat()), this.startDateCtrl.comp);
                }
                else {
                    this.startDateCtrl.setMinDate(moment().format(this.getDateFormat()), this.startDateCtrl.comp);
                }
            }
            else {
                if (["CVF", "HVF", "MTF", "MPF", "MCF"].indexOf(this.proposalHeader.contractType) != -1) {
                    this.startDateCtrl.setMinDate(moment(this.caseInfo.initiatedOn, "YYYY-MM-DD").subtract(30, 'days').format(this.getDateFormat()), this.startDateCtrl.comp);
                }
                else {
                    this.setMinForStartDate();
                }
            }
        }
    }

    getDateFormat() {
        let dtFormat = ApplicationUtilService.DATE_TIME_FORMAT;
        return dtFormat.split(" ")[0];
    }

    setEndDate() {
        if (this.endDateCtrl != null) {
            if (["MAR"].indexOf(this.proposalHeader.contractType) != -1) {
                let _poiEffectiveDatePrevDate = moment(this.proposalHeader.effectiveDate, "YYYY-MM-DD").subtract(1, 'days').format("YYYY-MM-DD");
                this.endDateCtrl.setter(moment(_poiEffectiveDatePrevDate, "YYYY-MM-DD").add(3, 'months').format("YYYY-MM-DD"), "YYYY-MM-DD", this.endDateCtrl.comp);
            }
            else {
                //GA002 START
                //this.endDateCtrl.setter(moment(this.proposalHeader.effectiveDate, "YYYY-MM-DD").add(364, 'days').format("YYYY-MM-DD"),"YYYY-MM-DD",this.endDateCtrl.comp);				
                let endDate = moment(this.proposalHeader.effectiveDate, "YYYY-MM-DD").add(1, 'years').format("YYYY-MM-DD");
                endDate = moment(endDate, "YYYY-MM-DD").subtract(1, 'days').format("YYYY-MM-DD");
                this.endDateCtrl.setter(endDate, "YYYY-MM-DD", this.endDateCtrl.comp);
                //GA002 END
            }
        }
    }

    //VK002 Added Conditions for FIR,MIS,PA, MAR,MCA
    setStartDateMonthValidation() {
        if (this.proposalHeader.effectiveDate != null || this.proposalHeader.effectiveDate != "") {
            /* VK002 if((this.proposalHeader.effectiveDate != null || this.proposalHeader.effectiveDate != "")){    VK002 */
            if (this.proposalHeader.lineOfBusiness && ["PA", "MIS", "FIR"].indexOf(this.proposalHeader.lineOfBusiness) >= 0) {
                return;
            } else if (this.proposalHeader.contractType && ["MAR", "MCA", "PL", "PPL", "PP3"].indexOf(this.proposalHeader.contractType) >= 0) {
                return;
            }
            let difference = moment(this.proposalHeader.effectiveDate, "YYYY-MM-DD").diff(moment(moment(), "YYYY-MM-DD"));
            if (moment.duration(difference).asMonths() > 3) {
                this.setStartDate();
                this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Advance issuance limit can be only 3 months.", 10000));
                this.validateEndDate();
            }
        }
    }

    validateEndDate() {
        if ((this.proposalHeader.effectiveDate != null || this.proposalHeader.effectiveDate != "") && (this.proposalHeader.endDate != null || this.proposalHeader.endDate != "")) {
            if (moment(this.proposalHeader.effectiveDate, "YYYY-MM-DD") > moment(this.proposalHeader.endDate, "YYYY-MM-DD")) {
                this.setEndDate();
                this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "End Date can not be smaller than Effective Date.", 10000));
            }
            //VK002 Added Conditions for FIR,MIS,PA, MAR,MCA
            if ((this.proposalHeader.contractType && ["WC", "PI", "CAR", "EAR", "DDO", "DandO", "DPI", "GL", "PL", "PRL", "TCM", "WLL", "POL", "MAR", "MCA", "PL", "PPL", "PP3"].indexOf(this.proposalHeader.contractType) < 0) && ((this.proposalHeader.lineOfBusiness && ["PA", "MIS", "FIR"].indexOf(this.proposalHeader.lineOfBusiness) < 0) || (this.proposalHeader.contractType && ["OSS", "OSI"].indexOf(this.proposalHeader.contractType) >= 0))) { //Redmine - 2020,2021, Redmine#2701-PL 
                let _allowedMonths = (this.proposalHeader.contractType && this.proposalHeader.contractType == 'OSI') ? 36 : 18;

                let difference = moment(this.proposalHeader.endDate, "YYYY-MM-DD").diff(moment(this.proposalHeader.effectiveDate, "YYYY-MM-DD"));
                if (moment.duration(difference).asMonths() > _allowedMonths) {
                    this.setEndDate();
                    this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Date difference can not be more than " + _allowedMonths + " months.", 10000));
                }
            }
            //VK002 Added Conditions for FIR,MIS,PA, MAR,MCA 
            if ((this.proposalHeader.contractType && ["PL", "PPL", "PP3", "ME", "EP", "CAR", "EAR", "MAR", "MCA", "PL", "PPL", "PP3"].indexOf(this.proposalHeader.contractType) >= 0) || ((this.proposalHeader.lineOfBusiness && ["PA", "MIS", "FIR"].indexOf(this.proposalHeader.lineOfBusiness) >= 0))) {
                this.setReferred(this);
            }
			/*/VK002
			if( this.proposalHeader.contractType && ["WC","PI","CAR","EAR","DDO","DandO","DPI","GL","PL","PRL","TCM","WLL","POL"].indexOf(this.proposalHeader.contractType) < 0 ){ //Redmine - 2020,2021, Redmine#2701-PL 
				let _allowedMonths = (this.proposalHeader.contractType && this.proposalHeader.contractType == 'OSI') ? 36 : 18;
			
				let difference  = moment(this.proposalHeader.endDate,"YYYY-MM-DD").diff(moment(this.proposalHeader.effectiveDate,"YYYY-MM-DD"));
				
				if(moment.duration(difference).asMonths() > _allowedMonths){
					this.setEndDate();
					this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Date difference can not be more than "+_allowedMonths+" months." , 10000));
				}
			}
			
			if( this.proposalHeader.contractType && ["PL","PPL","PP3","ME","EP","CAR","EAR"].indexOf(this.proposalHeader.contractType) >= 0 ){
				this.setReferred(this);
			}
			//VK002 END */
        }
    }

    setStartDate() {
        if (this.startDateCtrl != null)
            this.startDateCtrl.setter(moment(new Date().toISOString(), "YYYY-MM-DD").format("YYYY-MM-DD"), "YYYY-MM-DD", this.startDateCtrl.comp);
    }

    emitPeroid(effOrEnd) {
        if (this.inceptionDateChanged == true || this.entDateChanged == true) {
            this._rtService.setListLock();
            this.mergePOIContractChange();
            this.onpoichange.emit();
        }
    }

    launchAppChangeConfirm(values) {
        if (this.hasRisks() == true) {
            this.productCtrl.setter(this.proposalHeader.contractType, this.productCtrl.comp);
            this.confirmAppChange("Changing product will clear all the risks added in the risk table. Do you still want to continue?", values);
        }
        else {
            this.proposalHeader.contractType = values.value;
            this.setProductDetails(values);

            if (this.proposalHeader.contractType == 'MPA' && this.proposalHeader.insuredType == 'Corporate') {
                this.resetClientInfo();
            }
        }
    }

    resetClientInfo() {
        this.insuredPersonType = '';
        this.proposalHeader.insuredType = '';
        this.proposal.newBusiness.clientDetails = new ClientDetails();
        this.proposalHeader.insuredNumber = '';
        this.proposalHeader.insuredName = '';
        this.proposalHeader.insuredAge = 0;
    }

    private confirmAppChange(message: string, values) {
        let inputObj = {
            "Message": message
        };
        let lookup = new ModalInput();
        lookup.component = ["Confirm", "app/common/components/utility/confirmmessage/confirm.module", "ConfirmModule"];
        lookup.datainput = inputObj;
        lookup.outputCallback = null;
        lookup.parentCompPRMS = {
            comp: this,
            values: values
        };
        lookup.heading = "User Confirmation";
        lookup.icon = "fa fa-hand-paper-o";
        lookup.containerRef = this.contentArea;
        this.dcl.openLookup(lookup).subscribe((data) => {
            this.appChangeDecision(data, values);
        });

    }

    private appChangeDecision(data, values) {
        if (data.data.value == 'Y') {
            this.proposalHeader.marineOpenCover = "";
            this.proposalHeader.contractType = values.value;
            this.setProductDetails(values);

            if (this.proposalHeader.contractType == 'MPA' && this.proposalHeader.insuredType == 'Corporate') {
                this.resetClientInfo();
            }
        }
        else {
            if (this.productCtrl != null) {
                this.productCtrl.setter(this.proposalHeader.contractType, this.productCtrl.comp);
            }
        }
    }

    private confirmInceptionDtChange( message: string, values ) {
        let inputObj = {
            "Message": message
        };
        let lookup = new ModalInput();
        lookup.component = ["Confirm", "app/common/components/utility/confirmmessage/confirm.module", "ConfirmModule"];
        lookup.datainput = inputObj;
        lookup.outputCallback = null;
        lookup.parentCompPRMS = {
            comp: this,
            values: values
        };
        lookup.heading = "User Confirmation";
        lookup.icon = "fa fa-hand-paper-o";
        lookup.containerRef = this.contentArea;
        this.dcl.openLookup(lookup).subscribe((data) => {
            this.inceptionDtChangeDecision(data, values);
        });

    }

    private inceptionDtChangeDecision(data, values) {
        if (this.proposalHeader.contractType == 'TAA' || this.proposalHeader.contractType == 'TDA') {
            if (data.data.value == 'Y') {
                this._rtService.resetRiskList(true);
            } else {
                this.proposalHeader.effectiveDate = values;
                if (this.startDateCtrl != null)
                    this.startDateCtrl.setter(moment(values, "YYYY-MM-DD").format("YYYY-MM-DD"), "YYYY-MM-DD", this.startDateCtrl.comp);
            }
        }
    }

    checkBancaForPayPlanUI(payPlan) {
        this.proposalHeader.payPlan = payPlan;
        this.checkBancaInfo(false);
    }

    isInceptionDateChanged(newValue) {
        if (this.proposalHeader.effectiveDate != newValue)
            this.inceptionDateChanged = true;
        else
            this.inceptionDateChanged = false;

        //SST code
        if (this.inceptionDateChanged) {
            //let expiryDate = moment(newValue, "YYYY-MM-DD").add(364, 'days').format("YYYY-MM-DD");
            let expiryDate = moment(newValue, "YYYY-MM-DD").add(1, 'years').format("YYYY-MM-DD");
            expiryDate = moment(expiryDate, "YYYY-MM-DD").subtract(1, 'days').format("YYYY-MM-DD");
            this.proposalHeader.effectiveDate = newValue;
            this.proposalHeader.endDate = expiryDate;
            let respObj = this._bus.getTAXDetails();
            if (respObj != undefined && respObj != "") {
                this.proposalHeader.SSTTaxRate = Number(respObj[0].old.ITEMPF.GST);
                this.proposalHeader.GSTTaxRate = Number(respObj[1].old.ITEMPF.GST);
            }
        }
        //End
    }

    isEndDateChanged(newValue) {
        if (this.proposalHeader.endDate != newValue)
            this.entDateChanged = true;
        else
            this.entDateChanged = false;
    }

    openLongNameLookup() {
        let input = new ModalInput();
        input.parentCompPRMS = { comp: this };
        input.heading = "Insured Long Name";
        input.datainput = { proposalHeader: this.proposalHeader, isViewMode: this.disableForm };
        input.component = ["LNComponent", "app/bms/components/proposal/proposalheader/dialogs/ln.module", "LNModule"];
        input.icon = "fa fa-file-pdf-o";
        input.containerRef = this.contentArea;
        this.dcl.openLookup(input);
    }

    openRefReason() {
        let input = new ModalInput();
        input.parentCompPRMS = { comp: this };
        input.heading = "Reason For Policy Referred";
        input.datainput = { newBusiness: this.proposal.newBusiness };
        input.component = ["ReferredReasonComponent", "app/bms/components/proposal/proposalheader/dialogs/referredreason.module", "ReferredReasonModule"];
        input.icon = "fa fa-file-pdf-o";
        input.containerRef = this.contentArea;
        this.dcl.openLookup(input);
    }

    onMasterPolicyChange(ev) {
        if (this.proposalHeader.contractType != 'TDA')
            this._rtService.resetStampDuty().subscribe((data) => BMSConstants.getNewBusinessInfo().resetAllPremCalc());
    }

    resetBanca(optionVal) {
        optionVal = optionVal ? 'Y' : 'N';
        this.proposalHeader.bancaRequired = optionVal;
        this._bancaService.resetBanca(optionVal);
        this.proposalHeader.handleFlags();
    }

    checkBancaInfo(isByButton) {
        this._bancaService.checkBancaInfo(this.proposalHeader.effectiveDate, this.proposalHeader.agentCode, this.proposalHeader.contractType, this.proposalHeader.payPlan, this.getPayPlanSequence(this.proposalHeader.payPlan)).subscribe((data) => {
            if (isByButton == true)
                this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Banca is checked successfully.", -1));
            this.checkUOBInfo();
            this.proposalHeader.handleFlags();
        });
    }

    checkUOBInfo() {
        this._bancaService.resetUOBInfo(this.proposalHeader.contractType, this.proposalHeader.renewalType, this.proposalHeader.agentCode).subscribe();
    }

    checkManuscript(manVal) {
        this.proposalHeader.manuscript = manVal ? 'Y' : 'N';
        this.proposalHeader.setRIMethod();
        this.setReferred(this);
    }

    setRIMethod(riVal) {
        if (riVal == "No") {
            this.proposalHeader.RIType = "";
            this.proposalHeader.RIReason = "";
        }
    }

    setReferred(comp) {
        comp._rcls.setRiskClassification("", "Y", "", "").subscribe();
    }
    openAMLCDDComments() {
        if (this.proposalHeader.AMLCDDCheck == "true") {
            let lookup = new ModalInput();
            lookup.component = ["CommonCommentDialogComponent", "app/bms/components/proposal/process/common.comment.dialog.module", "CommonCommentDialogModule"];
            lookup.datainput = { dialogName: "AML-CDD-Comments", DNComments: this.proposalHeader.AMLCDDComments };
            lookup.outputCallback = this.commonCommentDialogCallback;
            lookup.parentCompPRMS = { comp: this };
            lookup.heading = "Enter AML Customer Due Diligence Comments";
            lookup.icon = "fa fa-comment";
            lookup.containerRef = this.contentArea;
            this.dcl.openLookup(lookup);
        }

    }

    openHighRiskCusDialog() {
        if (this.proposalHeader.HighRiskCus == "Y") {
            let lookup = new ModalInput();
            lookup.component = ["HRCComponent", "app/bms/components/proposal/proposalheader/dialogs/hrc.module", "HRCModule"];
            lookup.heading = "High Risk Customer";
            lookup.datainput = { proposalHeader: this.proposalHeader, isQuotationCompleted: BMSConstants.isQuotationCompleted() };
            lookup.icon = "fa fa-comment";
            lookup.containerRef = this.contentArea;
            this.dcl.openLookup(lookup);
        }

    }

    openRIPage() {
        let disable = (this.proposalHeader.RIRequiredHeader == 'No' || this.proposalHeader.isApprovalCompleted == 'Y') ? true : false;
        let lookup = new ModalInput();
        lookup.component = ["RIComponent", "app/bms/components/proposal/proposalheader/dialogs/ri.module", "RIModule"];
        lookup.heading = "RI Type";
        lookup.datainput = { proposalHeader: this.proposalHeader, disable: disable };
        lookup.icon = "fa fa-comment";
        lookup.containerRef = this.contentArea;
        this.dcl.openLookup(lookup).subscribe(() => {
            this.proposalHeader.setRIMethod();
        });

    }

    openDuplicates() {
        event.preventDefault();
        if (this.duplicateIndicatorUI == true) {
            let lookup = new ModalInput();
            lookup.component = ["DuplicateComponent", "app/bms/components/proposal/proposalheader/dialogs/duplicate.module", "DuplicateModule"];
            lookup.heading = "Duplicate Cases";
            lookup.datainput = { proposalHeader: this.proposalHeader };
            lookup.icon = "fa fa-comment";
            lookup.containerRef = this.contentArea;
            this.dcl.openLookup(lookup);
        }
    }

    openConflicts() {
        event.preventDefault();
        if (this.channelConflictIndicatorUI == true) {
            let lookup = new ModalInput();
            lookup.component = ["DuplicateComponent", "app/bms/components/proposal/proposalheader/dialogs/duplicate.module", "DuplicateModule"];
            lookup.heading = "Channel Conflict Cases";
            lookup.datainput = { proposalHeader: this.proposalHeader };
            lookup.icon = "fa fa-comment";
            lookup.containerRef = this.contentArea;
            this.dcl.openLookup(lookup);
        }
    }

    onAMLCDDcheck(value) {
        this.proposalHeader.AMLCDDCheck = value ? 'true' : 'false';
        if (value == true)
            this.openAMLCDDComments();
    }

    onHighRiskCuscheck(value) {
        this.proposalHeader.HighRiskCus = value ? 'Y' : 'N';
        if (value == true)
            this.openHighRiskCusDialog();
        else {
            this.proposalHeader.HighRiskCusType = "";
            this.proposalHeader.HighRiskCusComments = "";
            this.proposalHeader.HighRiskCEOApproval = "N";
        }
    }

    private TravelPlansBenefitsRefresh(value) {
        if (this.hasRisks() && this.inceptionDateChanged && (this.proposalHeader.contractType == 'TAA' || this.proposalHeader.contractType == 'TDA')) {
            this.confirmInceptionDtChange("Changing Inception Date will clear all the risks added in the risk table. Do you still want to continue?", value);
        }
    }

    private callbackCampignCodes( scopeObject ) {
        if ( scopeObject.lovDropDownService.lovDataList.CampignCode != null && scopeObject.lovDropDownService.lovDataList.CampignCode != undefined
            && scopeObject.lovDropDownService.lovDataList.CampignCode.length > 0 ) {
            let campaignCode = scopeObject.lovDropDownService.lovDataList.CampignCode.find( camp => camp.VALUE == scopeObject.proposalHeader.campaign );

            if ( campaignCode == null || campaignCode == undefined ) {
                scopeObject.proposalHeader.campaign = "";
            }
        }

    }
    
}
export class AHInfo {
    constructor(public USER_ID: string,
        public USER_FULL_NAME: string,
        public PRODUCER_CODE: string) { }
}

export class PayPlanInfo {
    constructor(public PAY_PLAN_VALUE: string,
        public PAY_PLAN_DESC: string,
        public PAYPLANSEQ: string) { }
}

export class RenewalTypeInfo {
    constructor(public RNL_TYPE_VALUE: string,
        public RNL_TYPE_DESC: string,
        public RNLTYPESEQ: string) { }
}

export class NotificatTypeInfo {
    constructor(public RNLTYPE: string,
        public NOT_TYPE_VALUE: string,
        public NOT_TYPE_DESC: string,
        public RNLNOTSSEQ: string) { }
}