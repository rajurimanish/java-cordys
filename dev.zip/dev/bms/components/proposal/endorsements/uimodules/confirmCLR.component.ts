import { Component, OnInit } from "@angular/core";
import { BMSConstants } from "../../../common/constants/bms_constants";
import { AlertMessage } from "../../../../../common/components/utility/alertmessage/alertmessages.model";
import { AlertMessagesService } from "../../../../../common/components/utility/alertmessage/alertmessages.service";


@Component( {
    selector: "clr-comments",
    templateUrl: "app/bms/components/proposal/endorsements/uimodules/confirmCLR.template.html",
    inputs: ['datainput', 'closeDialog', 'parentCompPRMS']
} )
export class CLRCommentComponent implements OnInit {
    public isViewMode: string = 'N';
    public smtApprovalUI: boolean = false;
    public smtApproval: string = "";
    public comments: string = "";

    public datainput: any;
    public closeDialog: Function;
    public parentCompPRMS: any;

    constructor( public _alertMsgService: AlertMessagesService) {
    }

    ngOnInit() {
        this.isViewMode = this.datainput.isViewMode;
        this.setInitData();
    }

    setInitData() {
        this.smtApproval = BMSConstants.getBMSHeaderInfo().SMTApproval;
        this.smtApprovalUI = ( this.smtApproval == "Y" ) ? true : false;
    }

    onApprovalCheck( value ) {
        this.smtApproval = ( value ) ? "Y" : "N";
    }

    save() {
        if ( this.comments.length == 0) {
            this._alertMsgService.add( new AlertMessage( AlertMessage.ERROR, "Please Enter Comments and proceed.", -1 ) );
            return;
        }
        BMSConstants.getBMSHeaderInfo().SMTApprovalComments = this.comments;
        BMSConstants.getBMSHeaderInfo().SMTApproval = this.smtApproval;
        this.closeDialog( null, this.parentCompPRMS );
    }

    cancel() {
        this.closeDialog( null, this.parentCompPRMS );
    }
}