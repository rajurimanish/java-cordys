import { Component, OnInit } from "@angular/core";
import { ApplicationUtilService } from "../../../../common/services/application.util.service";
import { CordysSoapWService } from "../../../../common/components/utility/cordys-soap-ws";
import { AlertMessagesService } from '../../../../common/components/utility/alertmessage/alertmessages.service';
import { AlertMessage } from '../../../../common/components/utility/alertmessage/alertmessages.model';

@Component({
    selector: "user-selection-component",
    templateUrl: "app/bms/components/proposal/process/common.comment.dialog.template.html",
    inputs: ['datainput', 'closeDialog', 'parentCompPRMS']
})
export class CommonCommentDialogComponent implements OnInit {

    private dialogName: string;
    public comments: string;
    public parentCompParams: any;
    public hideReasons: boolean = true;
    public declineReasonList: any[];
    public reasonForDecline: string;
    public lobCode: string;
    public declineReasonDesc: string;
    public DNComments: string;
    public datainput: any;
    public closeDialog: Function;
    public parentCompPRMS: any;
    public isCommentsMandtory: boolean = false;
    public commentDate: string = '';
    public caseStatus: String;

    constructor(public _alertMsgService: AlertMessagesService, public _cordysService: CordysSoapWService) { }

    ngOnInit() {
        this.dialogName = this.datainput.dialogName;
        this.parentCompParams = this.datainput.params;
        this.DNComments = this.datainput.DNComments;
        if (this.dialogName == "DNComments" || this.dialogName == "AML-CDD-Comments") {
            this.comments = this.DNComments;
            this.commentDate = this.datainput.commentDate;
        }
        else this.comments = "";
        this.lobCode = this.datainput.lobCode;
        this.caseStatus = this.datainput.caseStatus;

        // adding below code for issue 1823 -- start
        let keyVal;
        if (this.dialogName === "common-comment-decline-reason")
            keyVal = "/com/msig/lov/bms-decline-reasons.xml";
        else if (this.dialogName == "common-comment-approval-quotation-referred" || this.dialogName == "common-comment-close-case" ||
            this.dialogName == "common-comment-busmt-appeal-referred" || this.dialogName == "common-comment-approval-appeal-referred")
            keyVal = "/com/msig/insurance/BMSReasonCodesConfiguration.xml";

        //if (this.dialogName === "common-comment-decline-reason") {
        if (keyVal != undefined && keyVal.length > 0) {
            this.hideReasons = false;
            this._cordysService.callCordysSoapService(
                "GetXMLObject",
                "http://schemas.cordys.com/1.0/xmlstore",
                {
                    key: keyVal
                },
                this.getXMLObjSuccessHandler,
                this.getXMLObjErrorHandler,
                false,
                this
            );
        } // End
    }

    private getXMLObjSuccessHandler(response, originalObject) {
        if (!response) {
            originalObject.hideReasons = true;
            originalObject._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Decline reasons not available in confuguration file. Please contact Administrator", -1));
            return;
        }
        if (originalObject.dialogName == "common-comment-decline-reason") {
            if (response && !response.tuple.old.DeclineReasons) {
                originalObject.hideReasons = true;
                originalObject._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Decline reasons not available in confuguration file. Please contact Administrator", -1));
                return;
            }

            let lobTypes = response.tuple.old.DeclineReasons.Application.LOB;
            if (!lobTypes.sort) {
                lobTypes = [response.tuple.old.DeclineReasons.Application.LOB];
            }
            originalObject.declineReasonList = [];
            for (let index = 0; index < lobTypes.length; index++) {
                if (lobTypes[index]["@type"] === originalObject.lobCode) {
                    let reasons = lobTypes[index].Reason;
                    if (!reasons.sort) {
                        reasons = [lobTypes[index].Reason];
                    }
                    for (let r = 0; r < reasons.length; r++) {
                        originalObject.declineReasonList.push({ description: reasons[r].description, code: reasons[r].code });
                    }
                } else {
                    continue;
                }
            }
            if (originalObject.declineReasonList.length < 1) {
                originalObject.hideReasons = true;
                originalObject._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Decline reasons not available in confuguration file. Please contact Administrator", -1));
                return;
            }
            originalObject.reasonForDecline = "";
        }
        // code for issue 1823 -- start
        else if (originalObject.dialogName == "common-comment-approval-quotation-referred" || originalObject.dialogName == "common-comment-close-case" ||
            originalObject.dialogName == "common-comment-busmt-appeal-referred" || originalObject.dialogName == "common-comment-approval-appeal-referred") {
            if (!response) {
                originalObject.hideReasons = true;
                originalObject._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Reason codes are not available in confuguration file. Please contact Administrator", -1));
                return;
            }
            let reasonCodes = response.tuple.old.Reasons.ReasonCodes;
            let approveReasons;
            for (let i = 0; i < reasonCodes.length; i++) {
                if (reasonCodes[i]['@type'] == originalObject.dialogName) {
                    approveReasons = reasonCodes[i].Reason;
                }
            }

            originalObject.declineReasonList = [];
            for (let r = 0; r < approveReasons.length; r++) {
                originalObject.declineReasonList.push({ description: approveReasons[r].description, code: approveReasons[r].code });
            }
        } // End 
    }

    private getXMLObjErrorHandler(response, status, errorText, extraPrms) {

    }

    private _CloseDialog() {
        // added below code for issue 1823
        if ((this.isCommentsMandtory || this.hideReasons) && this.comments.trim() === "") {
            //if (this.hideReasons && this.comments.trim() === "") {
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Please provide comments", 5000));
            return;
        }
        this.CloseDialogWithComments();
    }

    private CloseDialogWithComments() {
        if (this.dialogName == "common-comment-decline-reason" || this.dialogName == "common-comment-approval-quotation-referred" ||
            this.dialogName == "common-comment-close-case" || this.dialogName == "common-comment-busmt-appeal-referred" ||
            this.dialogName == "common-comment-approval-appeal-referred") {
            if ((this.reasonForDecline == undefined || this.reasonForDecline == "") && this.caseStatus != "P400 In forced") {
                /* commented & added below code for issue 1823
                this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Please select a reason for decline", -1)); */
                this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Please select a reason", -1));
                return;
            }
            let comments: string = "";
            if (this.comments == "") {
                this.reasonForDecline = (this.reasonForDecline == undefined) ? "" : this.reasonForDecline;
                this.declineReasonDesc = (this.declineReasonDesc == undefined) ? "" : this.declineReasonDesc;
                comments = "Reason: " + this.reasonForDecline + "-" + this.declineReasonDesc;
            } else {
                this.reasonForDecline = (this.reasonForDecline == undefined) ? "" : this.reasonForDecline;
                this.declineReasonDesc = (this.declineReasonDesc == undefined) ? "" : this.declineReasonDesc;
                comments = "Reason: " + this.reasonForDecline + "-" + this.declineReasonDesc + ", Comments: " + this.comments;
            }
            this.closeDialog(
                {
                    dialogName: this.dialogName,
                    comments: comments,
                    reasonCode: this.reasonForDecline,
                    reasonDesc: this.declineReasonDesc
                },
                this.parentCompPRMS
            );
        } else {
            this.closeDialog({
                dialogName: this.dialogName,
                comments: this.comments
            },
                this.parentCompPRMS
            );
        }
    }

    private cancelDialog() {
        this.closeDialog({
            dialogName: this.dialogName,
            isDialogCancelled: true
        },
            this.parentCompPRMS
        );
    }

    private reasonChange(selectField) {
        if (selectField.value == "") {
            this.declineReasonDesc = "";
        } else {
            this.declineReasonDesc = selectField[selectField.selectedIndex].innerHTML.trim();
            this.reasonForDecline = selectField.value;
            // added below code for issue 1823
            this.isCommentsMandtory = (this.declineReasonDesc == "Others") ? true : false;
        }
    }
}