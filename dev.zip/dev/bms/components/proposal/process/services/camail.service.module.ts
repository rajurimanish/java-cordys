import { NgModule } from '@angular/core';
import { CAMailService } from './camail.service';

@NgModule({
    providers: [CAMailService]
})

export class CAMailServiceModule { }