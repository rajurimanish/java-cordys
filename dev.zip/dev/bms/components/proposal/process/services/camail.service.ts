import { Injectable } from '@angular/core';
declare var Rx: any;
declare var Observer: any;
import { CordysSoapWService } from "../../../../../common/components/utility/cordys-soap-ws";
import { AlertMessagesService } from '../../../../../common/components/utility/alertmessage/alertmessages.service';
import { AlertMessage } from '../../../../../common/components/utility/alertmessage/alertmessages.model';
import { BMSConstants } from '../../../common/constants/bms_constants';
import { BMSType } from '../../../common/constants/bms_types';
import { AppUtil } from '../../../../../common/components/utility/apputil/app.util';

declare var jQuery: any;
declare var moment: any;

@Injectable()
export class CAMailService {

    constructor(private _cordysService: CordysSoapWService, public _alertMsgService: AlertMessagesService) { }

    public getFACLOBs() {
        return Rx.Observable.create((observer) => {
            let fac = { "key": "/com/msig/insurance/exceptions/fac_lobs.xml" };
            let prom = this._cordysService.callCordysSoapService("GetXMLObject", "http://schemas.cordys.com/1.0/xmlstore", fac, null, null, true, null);
            prom.success((resp) => {
                let facLOBs = AppUtil.getValueByPath(resp, "tuple.old.config.fac_lob");
                let list = new AppUtil().getArray(facLOBs.lob);
                observer.next(list);
            });
            prom.error((resp) => {
                this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error occurred while getting supported LOB for FacRI mail.", -1));
                observer.error("");
            });
        });
    }

    public sendFacRIMail(sendTo, reason) {
        return Rx.Observable.create((observer) => {
            let header = BMSConstants.getBMSHeaderInfo();
            let caseInfo = BMSConstants.getBMSCaseInfo();
            if (this.canSendRIMail(sendTo, header, caseInfo) == true) {
                this.getFACLOBs().subscribe((lobs) => {
                    if (lobs.indexOf(caseInfo.lineOfBusiness) != -1) {
                        let prom = this._cordysService.callCordysSoapService("SendFACRIMail", "http://schemas.insurance.com/businessobject/1.0/", { caseId: BMSConstants.getCaseId(), sendTo: sendTo, reason: reason }, null, null, true, null);
                        prom.success((data) => this.handleFacRISuccess(data, observer));
                        prom.error((data) => this.handleError(data, observer));
                    }
                });
            }
            else
                observer.next("");
        });
    }

    public sendManuscriptMail(isPosted) {
        return Rx.Observable.create((observer) => {
            let supportedLobs = ['FIR', 'PA', 'MIS', 'ENG', 'LIA', 'CPG'];
            let header = BMSConstants.getBMSHeaderInfo();
            let caseInfo = BMSConstants.getBMSCaseInfo();
            if (header.manuscript == 'Y' && supportedLobs.indexOf(caseInfo.lineOfBusiness) != -1) {
                let prom = this._cordysService.callCordysSoapService("SendAutoEmailNotificationForManuscriptPolicies", "http://schemas.insurance.com/businessobject/1.0/", { "caseId": caseInfo.caseId, "isPosted": isPosted }, null, null, true, null);
                prom.success((data) => {
                    observer.next("");
                });
                prom.error((data) => this.handleManError(data, observer));
            }
        });
    }

    public canSendRIMail(sendTo, header, caseInfo) {
        let canSend = false;
        if ( ( BMSConstants.getBMSType() == BMSType.NewBusiness || BMSConstants.getBMSType() == BMSType.Renewal || BMSConstants.getBMSType() == BMSType.Endorsements || BMSConstants.getBMSType() == BMSType.Cancellations || BMSConstants.getBMSType() == BMSType.Endorsements) && header.RIType != 'TreatyAdjustment') {
            if (sendTo != "NRI") {
                if (header.RIRequiredHeader == "Yes") {
                    canSend = true;
                    if ( sendTo == "ISD" && BMSConstants.getBMSType() != BMSType.NewBusiness && BMSConstants.getBMSType() != BMSType.Endorsements && BMSConstants.getBMSType() != BMSType.Cancellations)
                        canSend = false;
                }
            }
            else {
                if (header.RIRequiredHeaderOrg == "Yes" && header.RIRequiredHeader == "No" && sendTo == "NRI")
                    canSend = true;
            }
        }
        return canSend;
    }

    public handleFacRISuccess(data, observer) {
        observer.next("");
    }

    public handleError(data, observer) {
        if (data.status != 200) {
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error occurred while sending RI mail.", -1));
            observer.error("");
        }
    }

    public handleManError(data, observer) {
        if (data.status != 200) {
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error occurred while sending Manuscript mail.", -1));
            observer.error("");
        }
    }
}