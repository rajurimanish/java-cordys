import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { CommonCommentDialogComponent } from './common.comment.dialog.component';
import { DatePickerModule } from '../../../../common/components/utility/date/datepicker.module';

@NgModule({
    imports: [CommonModule, FormsModule, ReactiveFormsModule, DatePickerModule],
    declarations: [CommonCommentDialogComponent],
    exports: [CommonCommentDialogComponent]
})
export class CommonCommentDialogModule { }