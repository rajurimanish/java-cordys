import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BasicUIModule } from '../../../../common/components/utility/basicui.module';
import { TaskServiceModule } from "../../../../common/services/taskservice.module";
import { RenewalServicesModule } from '../../../services/renewal.service.module';
import { ControlAreaComponent } from './controlarea.component';
import { CoverNoteServiceModule } from '../../../services/covernote.service.module';


@NgModule({
    imports: [CommonModule, FormsModule, ReactiveFormsModule, BasicUIModule, TaskServiceModule, RenewalServicesModule, CoverNoteServiceModule],
    declarations: [ControlAreaComponent],
    exports: [ControlAreaComponent]
})
export class ControlAreaModule { }

