import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BasicUIModule } from '../../../../common/components/utility/basicui.module';

import { AppealtoBUSMTComponent } from './appealtobusmt.dialog.component';

@NgModule({
    imports: [CommonModule, FormsModule, ReactiveFormsModule, BasicUIModule],
    exports: [AppealtoBUSMTComponent],
    declarations: [AppealtoBUSMTComponent]
})
export class AppealtoBUSMTModule { }
