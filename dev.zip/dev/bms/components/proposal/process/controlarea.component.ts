/*
 * Change History:
 * 
 * No      Date          Description                                   Changed By
 * ====    ==========    ===========                                   ==========
 * AL001   24/08/2017   MYS-2017-0685 - Transaction of Policy with 
 *                              effective date Oct 2017 onwards             ALA	
 * AL002   15/09/2017   MYS-2017-0517 - Enable Dropdown Function for 
 *                             DeclineReason (Bug + Enhancement)            ALA
 * 
 * MD001   21/02/2018   MYS-2018-0100 - To capture Reason for appeal       Madhan
 * 						to BU SMT in process history
 * 
 * KA0001  26/03/2018   MYS-2017-1062 - To move DPA from PA to MTR LOB     Divek
 * 
 * MD002   07/06/2018   MYS-2018-0261 : To display "Business Consideration   MKU1
 * 						Form" at subsequent stages after BU SMT approved
 * 
 * KA0001  13/6/2018    MYS-2018-0391- Validate Terminated Agent Code       Divek
 * 						at Assessment Status		
 * 
 * KA0001  12/6/2018    MYS-2018-0415- To Capture Policy Numberin BMS       Divek 
 * 
 * GA001  13/08/2018	MYS-2018-0597 - Fac RI Email Trigger for Appeal 
 * 						to BU SMT routing									KGA
 * GA002  14/08/2018	MYS-2018-0945 - HD Log Incorrect User Name capture 
 * 						in Process History in BMS							KGA
 * 
 * GA003   25/09/2018  MYS-2018-0707 : Quotation Date in BMS 				KGA  
 * 
 * KA001   31/10/2018  MYS-2018-0793 : RI Type and Reason					DKA  
 * 
 * VK001   04/09/2018  MYS-2018-1026 - Security fix							VKR
 * 
 * E1001   18/06/2019  MYS-2019-0514 - To allow PP branch to post 
 *                     integrated products for New Business and Renewal		SRE1
 * 
 * E1002   18/06/2019  MYS-2019-0402 - When RI Type = Treatment Adjustment,
 *                     allow PP branch for posting							SRE1
 * E1003   28/05/2019  MYS-2019-0582 - Wrong assignee role after case is 
 *                     RFI & Re-Submit in BMS		                        SRE1
 * VK012   23/07/2019  MYS-2019-1104 - Routing for Payment & Receipting     VKR
 * GA004   11/09/2019  MYS-2019-0974 - BMS Enhancement on High Risk Vehicle & Client       KGA
 * 
 * VK015   19/10/2019   MYS-2019-1206   HD Log : RFI for Receipting Users Pool failed in BMS VKR
 * 
 * E1004   23/10/2019  MYS-2019-1008 - To include Business Consideration
 *                     Form for Renewal & Simplified Proposal		        SRE1
*/
import { Component, EventEmitter, Output, ViewChild, ViewContainerRef } from "@angular/core";
import { Router, ActivatedRoute } from '@angular/router';
import { CordysSoapWService } from "../../../../common/components/utility/cordys-soap-ws";
import { CaseInfo } from "../../../../common/components/appobjects/caseinfo";
import { Approval } from "../../../../common/components/appobjects/approval";
import { CustomDCLService, DCLInput } from "../../../../common/services/customdcl.service";
import { ApplicationUtilService } from "../../../../common/services/application.util.service";
import { TaskService } from "../../../../common/services/task.service";
import { ApplicationObject, ApplicationBusinessObject, BusinessObject } from '../../common/appobjects/applicationBusinessObject';
import { CommentDialogData } from "./appobjects/comment.dialog.data.component";
import { ModalInput } from "../../../../common/components/utility/modal/modal";
import { ProposalValidator } from '../validation/proposal.validator';
import { BMSProductValidator } from '../validation/bmsproduct.validator';
import { HeaderValidator } from '../validation/header.validator';
import { ValidationResult } from '../../../../common/components/validator/validator';
import { AlertMessagesService } from '../../../../common/components/utility/alertmessage/alertmessages.service';
import { AlertMessage } from '../../../../common/components/utility/alertmessage/alertmessages.model';
import { GetLOVData, SearchAdvancedConfig, Filter } from '../../../../common/components/utility/search/search.requests';
import { BMSUtilService } from "../../../services/bms.util.service";
import { BMSConstants } from '../../common/constants/bms_constants';
import { BMSType } from '../../common/constants/bms_types';
import { ProgressBarComponent } from '../../../../common/components/utility/progressbar/progressbar.component';
import { RiskClassificationService } from "../newbusinessrisks/services/riskcls.service"; // added code for AccRegister
import { RenewalServices } from '../../../services/renewal.service';
import { BMSAppObjService } from '../../../services/bmsappobj.service';
import { BMSControlAreaService } from '../../../services/bms.controlarea.service';
import { CoverNoteService } from '../../../services/covernote.service';
import { AppUtil } from '../../../../common/components/utility/apputil/app.util';
import { RiskArray } from '../proposalheader/uimodules/riskArray';
import { CAMailService } from './services/camail.service';
import { NCDService } from '../newbusinessrisks/motorcommercial/handler/ncd.service';
//import {RiskType} from '../proposalheader/uimodules/risktypes';

declare var moment: any;
declare var numeral: any;// Divek MYS-2018-0415
declare var jQuery: any;// Divek MYS-2018-0415

@Component({
    selector: 'control-area',
    templateUrl: 'app/bms/components/proposal/process/controlarea.template.html',
    inputs: ['appObj'],
    providers: [RiskClassificationService]
})

export class ControlAreaComponent {
    @Output() setFormMode = new EventEmitter<boolean>();
    @Output() onBeforePost = new EventEmitter<Object>();
    @Output() refreshAttachment = new EventEmitter<Object>();
    @Output() onBeforeCancel = new EventEmitter<Object>();
    //@Output() setCcmOpsFlag = new EventEmitter<boolean>();//pku

    private caseInfo: CaseInfo;
    public orgDN;
    public nextRole;
    public claimBO;
    public processObject;
    public BMSWFHelperCanComplete = "false";
    public BMSWorkflowButtonConfig;
    public nextUserDn;
    private userList;
    private userName;
    private userFullName: string;
    public buttonArray = [];
    public appObj: ApplicationObject;
    private dateDisable: any;
    public taskID;
    private loggedInUser: string;
    private userId: string;
    private appid: string;
    private rpt_file: string;
    private taskDueDate: string;
    public dispatchDateCtrl: any;
    private userRoles;
    private AHRole;
    private isUserActive: boolean;
    public isActionsButtonEnable: boolean = true;
    private statusBeforeHoldCover;
    private RNAccountHandler: string;
    private RNBusinessHandler: string;
    private vpmsBlockDate: string; //AL001
    private vpmsBlockDateValidProducts = [];//AL001
    private RIRequired: string;
    private isRerateReviewed: boolean = false;
    public riskArray: RiskArray = new RiskArray();
    public dispatchModes = [];
    public emailType: string;
    public accRiskObject;
    public component: string = "";
    private el: HTMLElement;// Divek MYS-2018-0415
    private setPolicyNumberCtrl: any; // Divek MYS-2018-0415
    public agentaccount: boolean;//Divek MYS-2018-0391
    public disablePolicyNumber: boolean; // Divek MYS-2018-0415

    public caInfo: any;
    @ViewChild('controlAreaModal', { read: ViewContainerRef }) contentArea: ViewContainerRef;

    constructor(private _cordysService: CordysSoapWService, private _router: Router, private _activatedRoute: ActivatedRoute, public dcl: CustomDCLService, private _appUtilService: ApplicationUtilService, private _taskService: TaskService, public _alertMsgService: AlertMessagesService, private _bmsUtilService: BMSUtilService, public renService: RenewalServices, public _appObjService: BMSAppObjService, public _controlAreaService: BMSControlAreaService, private cnService: CoverNoteService, private _caMailService: CAMailService, public riskClassificationService: RiskClassificationService, private _ncdService: NCDService) { }

    ngOnInit() {
        this.caInfo = this._controlAreaService.getCAInfo();
        if (!this.appObj) {
            return;
        }
        //KA001 Divek added this validation to check whether to disable policy number  MYS-2018-0415 Start
        if (this.appObj.ApplicationBusinessObject.caseInfo.businessFunction == 'Renewal' || this.appObj.ApplicationBusinessObject.caseInfo.businessFunction == 'RenewalRerate') {
            this.disablePolicyNumber = true;
        }
        else if (this.appObj.ApplicationBusinessObject.caseInfo.businessFunction == 'NewBusiness' && (this.appObj.ApplicationBusinessObject.caseInfo.status == 'Draft' || this.appObj.ApplicationBusinessObject.caseInfo.status == 'Assessment' || this.appObj.ApplicationBusinessObject.caseInfo.status == 'Quotation' || this.appObj.ApplicationBusinessObject.caseInfo.status == 'Assessment Approval' || this.appObj.ApplicationBusinessObject.caseInfo.status == 'Referral Review' || this.appObj.ApplicationBusinessObject.caseInfo.status == 'Referral Approval')) {
            this.disablePolicyNumber = false;
        }
        else {
            this.disablePolicyNumber = true;
        }
        //KA001 END
        this.RTActionsHandler();
        if (this.appObj.ApplicationBusinessObject.caseInfo.businessFunction != 'RenewalRerate' && this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.policyIssued == 'true' && this.isActionsButtonEnable)
            this.populateDispatchMode();
        // Set the  task id globally
        if (this._activatedRoute.snapshot.params['taskID']) {
            this.taskID = this._activatedRoute.snapshot.params['taskID'];
        }
        this.component = this._activatedRoute.snapshot.params['component'];
        if ((this.component) != "MyTasks" && (this.component) != null && (this.component) != "MyDrafts" && (this.component) != "/MyRenewalRerate" && (this.component) != "/MyRenewal" && (this.component) != "MiscCNEnquiry") {
            this.setFormMode.emit(true);
        }

        // Set the user dn and name globally
        this._appUtilService.getUserName().subscribe((data) => {
            this.loggedInUser = data;
            this._appUtilService.getUserFullName(data).subscribe(
                (fullName) => this.userFullName = fullName
            )
        });
        this._appUtilService.getUserDn().subscribe((data) => this.getUserId(data));

        if (!this.taskID) {
            this._appUtilService.getOrgDn().subscribe((data) => {
				/*let processInfo = BMSConstants.getBMSProcessInfo();
				if (processInfo.workflowStatus === "P400 Pending NB")
					this.checkIfPolicyPosted(false).done(()=>{
						this.RTActionsHandler();
						this.getOrgDn(data, this)
					});
				else*/
                this.getOrgDn(data, this);
            });
        }
        //added below code to avoid Case missings.
        if (this.orgDN == undefined || this.orgDN == "" || this.orgDN == '') {
            this._appUtilService.getOrgDn().subscribe((data) => {
                this.orgDN = data;//this.getOrgDn(data, this);
            });
        }

        this.checkIfPolicyCancelled();
        //this.checkforInceptionDate();
        //AL001 START - VPMS BLOCKDATE FOR PRODUCTS
        this.setVPMSBlockDate();
        this.setVPMSBlockDateProductList();
        //AL001 END 
        //Handle fast track
        if (this.appObj.ApplicationBusinessObject.caseInfo.businessFunction == "Renewal") {
            this.fastTrackHandler();
        }

		/*if(this.appObj.ApplicationBusinessObject.processObject.workflowStatus == "P400 In forced"){
			this.fillTransactionNumberInDispatchInfo();
		}*/

        //To handle async posting for multi risk 
        this.handleAsyncPosting();

    }

    private disableDate(event) {

        this.dateDisable = event;
        var postingDate = this.appObj.ApplicationBusinessObject.caseInfo['p400PostingDate'];
        var currentDateEndTime = ApplicationUtilService.getFormattedDate(postingDate, "YYYY-MM-DDTHH:mm:ss", "DD/MM/YY HH:MM");
        this.dateDisable.setMaxDateTime(currentDateEndTime, this.dateDisable.comp);
        this.dateDisable.setMinDateTime(currentDateEndTime, this.dateDisable.comp);

    }


    private disableInitDate(event) {

        this.dateDisable = event;
        var postingDate = this.appObj.ApplicationBusinessObject.caseInfo['initiatedOn'];
        var currentDateEndTime = ApplicationUtilService.getFormattedDate(postingDate, "YYYY-MM-DDTHH:mm:ss", "DD/MM/YY HH:MM");
        this.dateDisable.setMaxDateTime(currentDateEndTime, this.dateDisable.comp);
        this.dateDisable.setMinDateTime(currentDateEndTime, this.dateDisable.comp);

    }

    handleAsyncPosting() {
        if (Number(BMSConstants.getBMSHeaderInfo().noOfRisks) > 20 && (this._activatedRoute.snapshot.params['component']) == "MyTasks" && (BMSConstants.getBMSCaseInfo().businessFunction == "Renewal" || BMSConstants.getBMSCaseInfo().businessFunction == "RenewalRerate")) {
            let asyncPostingStatus = this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.asyncPostingStatus;
            let asyncPostingMessage = this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.asyncPostingMessage;
            if (asyncPostingStatus == "InProgress") {
                this.setFormMode.emit(true);
                this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Posting is in progress. Please revisit after some time.", -1));
            }
            else if (asyncPostingStatus == "Failed") {
                this.setFormMode.emit(false);
                this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, asyncPostingMessage, -1));
            }
            else if (asyncPostingStatus == "Success") {
                this.setFormMode.emit(false);
                this._alertMsgService.add(new AlertMessage(AlertMessage.SUCCESS, "Case posted successfully", -1));
            }
        }

    }

    onStartOfAsyncPosting() {
        //Show message for async posting
        if (Number(BMSConstants.getBMSHeaderInfo().noOfRisks) > 20 && (this.appObj.ApplicationBusinessObject.caseInfo.businessFunction == "Renewal" || this.appObj.ApplicationBusinessObject.caseInfo.businessFunction == "RenewalRerate")) {
            this.setFormMode.emit(true);
            this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Posting is in progress. Please revisit after some time.", -1));
            ProgressBarComponent.hide();
        }
    }

    RTActionsHandler() {
        if (this._activatedRoute.snapshot.params['component'] == "MiscCNEnquiry")
            this.isActionsButtonEnable = false;
        this.isActionsButtonEnable = true;
    }

    public checkIfPolicyCancelled() {

        //Case Invalidation For Renewal and Renewal Rerate
        if (this.appObj.ApplicationBusinessObject.caseInfo.businessFunction == "RenewalRerate" && this.appObj.ApplicationBusinessObject.caseInfo.status != 'Closed') {
            ProgressBarComponent.show('Please wait...', { dialogSize: 'm', progressType: 'primary' });
            this._cordysService.callCordysSoapService(
                "GetLOVData",
                "http://schemas.opentext.com/lovhandler/v1.0",
                this.getLOVDataParamsForRR(this.appObj.ApplicationBusinessObject.caseInfo.policyNumber),
                this.getLOVDataParamsForRRSuccessHandler,
                this.getLOVDataParamsForRRErrorHandler,
                true,
                {
                    comp: this
                }
            );
        }
        else if (this.appObj.ApplicationBusinessObject.caseInfo.businessFunction == "Renewal" && this.appObj.ApplicationBusinessObject.caseInfo.status != 'Closed') {
            ProgressBarComponent.show('Please wait...', { dialogSize: 'm', progressType: 'primary' });
            this._cordysService.callCordysSoapService(
                "GetLOVData",
                "http://schemas.opentext.com/lovhandler/v1.0",
                this.getLOVDataParamsForRN(this.appObj.ApplicationBusinessObject.caseInfo.policyNumber),
                this.getLOVDataParamsForRRSuccessHandler,
                this.getLOVDataParamsForRRErrorHandler,
                true,
                {
                    comp: this
                }
            );
        }

    }
	/*private checkforInceptionDate(){
		if(BMSConstants.getBMSType()== BMSType.CoverNote && BMSConstants.getSatus() =="Cover Note Accepted"){
			this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo. = '';
			this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.eneffectiveDatedDate = '';
		}
	}*/
    private populateDispatchMode() {
        let disMode = { "key": "/com/msig/insurance/dispatch_types.xml" };
        let prom = this._cordysService.callCordysSoapService("GetXMLObject", "http://schemas.cordys.com/1.0/xmlstore", disMode, null, null, true, null);
        prom.success((resp) => {
            let dispObj = AppUtil.getValueByPath(resp, "tuple.old.config.dispatch_types");
            this.dispatchModes = new AppUtil().getArray(dispObj.type);
        });
        prom.error((resp) => {
            this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Error while fetching dispatch modes.", -1));
        });
    }


    private getLOVDataParamsForRR(policyNumber) {
        var requestObj = new GetLOVData();
        requestObj.BRANCH = 'ALL';
        requestObj.LOB = 'ALL';
        requestObj.BUSINESS_FUNCTION = 'NEW BUSINESS';
        requestObj.PRODUCT = 'ALL';
        requestObj.OPERATION = 'ALL';
        requestObj.FORM_NAME = 'Renewal Rerate';
        requestObj.FORM_FIELD_NAME = 'Renewal Rerate';
        requestObj.FIELD_TYPE = 'LOOKUP';
        requestObj.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        requestObj.ADVANCE_CONFIG_XML.FILTERS = new Filter();

        requestObj.ADVANCE_CONFIG_XML.FILTERS.FILTER = [
            {
                "@FIELD_NAME": 'CHDRNUM',
                "@FIELD_VALUE": policyNumber,
                '@OPERATION': 'EQ',
                '@CONDITION': 'AND'
            }
        ];

        return requestObj;
    }

    private getLOVDataParamsForRN(policyNumber) {
        var requestObj = new GetLOVData();
        requestObj.BRANCH = 'ALL';
        requestObj.LOB = 'ALL';
        requestObj.BUSINESS_FUNCTION = 'NEW BUSINESS';
        requestObj.PRODUCT = 'ALL';
        requestObj.OPERATION = 'ALL';
        requestObj.FORM_NAME = 'Renewal';
        requestObj.FORM_FIELD_NAME = 'Renewal';
        requestObj.FIELD_TYPE = 'LOOKUP';
        requestObj.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        requestObj.ADVANCE_CONFIG_XML.FILTERS = new Filter();

        requestObj.ADVANCE_CONFIG_XML.FILTERS.FILTER = [
            {
                "@FIELD_NAME": 'CHDRNUM',
                "@FIELD_VALUE": policyNumber,
                '@OPERATION': 'EQ',
                '@CONDITION': 'AND'
            }
        ];
        return requestObj;
    }

    private getLOVDataParamsForRRSuccessHandler(response, prms) {

        if (prms.comp._activatedRoute.snapshot.params['component'] == "MyTasks" && prms.comp.appObj.ApplicationBusinessObject.caseInfo.status != "P400 In forced" && prms.comp.appObj.ApplicationBusinessObject.caseInfo.status != "P400 Pending NB") {
            if (!response.tuple) {
                prms.comp.closeCase();
            }
            else ProgressBarComponent.hide();
        }
        else
            ProgressBarComponent.hide();

    }

    private closeCase() {

        this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Policy is already Cancelled or Lapsed, So it will be automatically closed !", -1));
        this.appObj.ApplicationBusinessObject.processObject.workflowStatus = "Closed";
        // fill process history 
        this.fillProcessHistoryInfo(
            this.appObj.ApplicationBusinessObject,
            "Closed",
            "Policy is already Cancelled or Lapsed, So it will be automatically closed !",
            "SELF",
            "User"
        );
        this.deleteCasePolicyMapping(); // SAF MYS-2019-0355
        this.saveBusinessObject(this.callBackAfterCommentCloseWithoutFormClose);

    }

    private getLOVDataParamsForRRErrorHandler(response, status, errorText, extraParams) {
        ProgressBarComponent.hide();
        extraParams.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error getting the policy record from P400", -1));
    }

    private handleReadConfigError(e) {
        this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error while Reading configuration file " + e, -1));
    }

    private checkPolicyStatusButtonClick() {
        this.checkIfPolicyPosted(true);
    }

    public checkIfPolicyPosted(isManual?: boolean) {
        return this._cordysService.callCordysSoapService(
            "GetLOVData",
            "http://schemas.opentext.com/lovhandler/v1.0",
            this.getLOVDataParams(),
            this.checkIfPolicyPostedSuccessHandler,
            this.checkIfPolicyPostedErrorHandler,
            true,
            {
                comp: this,
                isManual: isManual
            }
        );
    }

    private getLOVDataParams() {
        var requestObj = new GetLOVData();
        requestObj.BRANCH = 'ALL';
        requestObj.LOB = 'ALL';
        requestObj.BUSINESS_FUNCTION = 'NEW BUSINESS';
        requestObj.PRODUCT = 'ALL';
        requestObj.OPERATION = 'NEW';
        requestObj.FORM_NAME = 'ALL';
        requestObj.FORM_FIELD_NAME = 'CheckPolicyPosted';
        requestObj.FIELD_TYPE = 'LOV';
        requestObj.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        requestObj.ADVANCE_CONFIG_XML.FILTERS = new Filter();

        requestObj.ADVANCE_CONFIG_XML.FILTERS.FILTER = [
            {
                "@FIELD_NAME": 'ZCASEID',
                "@FIELD_VALUE": this.appObj.ApplicationBusinessObject.caseInfo.caseId,
                '@OPERATION': 'EQ',
                '@CONDITION': 'AND'
            }, {
                "@FIELD_NAME": 'CNTBRANCH',
                "@FIELD_VALUE": this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.servicingBranch,
                '@OPERATION': 'EQ',
                '@CONDITION': 'AND'
            }, {
                "@FIELD_NAME": 'CCDATE',
                "@FIELD_VALUE": this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.effectiveDate.replace(/-/g, ""),
                '@OPERATION': 'EQ',
                '@CONDITION': 'AND'
            }];

        return requestObj;
    }

    private checkIfPolicyPostedSuccessHandler(response, prms) {
        if (response.tuple) {
            // Policy is posted manually from P400; Update policyNumber, isPendingNB and policyIssued values
            let policyNumber: string = response.tuple.old != undefined ? response.tuple.old.TABLE.CHDRNUM : response.tuple[response.tuple.length - 1].old.TABLE.CHDRNUM;
            prms.comp.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.policyIssued = "true";
            prms.comp.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.isPendingNB = "false";
            prms.comp.appObj.ApplicationBusinessObject.caseInfo.policyNumber = policyNumber;
            prms.comp.appObj.ApplicationBusinessObject.caseInfo.status = "P400 In forced";
            prms.comp.appObj.ApplicationBusinessObject.processObject.workflowStatus = "P400 In forced";
            prms.comp.populateDispatchMode();

            var userName = prms.comp.userFullName;
            var userId = prms.comp.userId;
            var newApprovalNode = new Approval();
            newApprovalNode.target = "SELF";
            newApprovalNode.targetType = "SELF";
            newApprovalNode.user = userName;
            newApprovalNode.action = (prms.comp.appObj.ApplicationBusinessObject.caseInfo.isPostedBySTP == 'Y') ? "Straight Through Processing" : "Posted to P400";

            prms.comp.appObj.ApplicationBusinessObject.caseInfo.approvalInfo.addItem(newApprovalNode);


            prms.comp.manuscriptMailHandler('true');
            prms.comp.setContolButtonsACL();
            prms.comp.fillTransactionNumberInDispatchInfo().done(() => {
                if (BMSConstants.getBMSType() == BMSType.Renewal && prms.comp.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.CoInsurance == "Y") {
                    prms.comp.sendMailToCoinsurer(prms.comp);
                }
                //Save BO
                prms.comp.saveBusinessObject();
                prms.comp._caMailService.sendFacRIMail("ISD", "").subscribe();
            });

        } else {
            // Policy is not posted yet
            if (prms.isManual) {
                prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Policy is not yet posted", -1));
            }
        }
    }

    private checkIfPolicyPostedErrorHandler(response, status, errorText, extraParams) {
        //extraParams._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "P400 services seems to be down. Please retry after sometime.", -1));
    }

    private getTaskDetails(): any {
        this._cordysService.callCordysSoapService("GetTask",
            "http://schemas.cordys.com/notification/workflow/1.0",
            this.getTaskDetailsParams(this.taskID),
            this.getTaskDetailsSuccessHandler,
            this.getTaskDetailsErrorHandler,
            true, this)
    }

    private getTaskDetailsParams(taskId) {
        return {
            "TaskId": taskId,
            "Target": "",
            "RetrievePossibleActions": "false",
            "ReturnTaskData": "false"
        }
    }


    private getTaskDetailsSuccessHandler(data, scopeObject) {
        if (!data.tuple.old.Task.Assignee.text) {
            return;
        }
        let currentTaskAssignee = data.tuple.old.Task.Assignee.text.substring(3, data.tuple.old.Task.Assignee.text.indexOf(","));
        scopeObject.taskDueDate = data.tuple.old.Task.DueDate.text;
        if (scopeObject.userId == currentTaskAssignee || scopeObject.userRoles.indexOf(data.tuple.old.Task.Assignee.text) > -1) {
            scopeObject._appUtilService.getOrgDn().subscribe((data) => scopeObject.getOrgDn(data, scopeObject));
            scopeObject._appUtilService.getUserName().subscribe((data) => scopeObject.getUserName(data, scopeObject));
        }
        else {
            scopeObject.setFormMode.emit(true);
            scopeObject._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "You do not have permission to act on the task", -1));
        }
    }

    private getTaskDetailsErrorHandler(response, status, errorText, extraParams) {
        this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error getting the task info", -1));
    }

    private validateProposal(): boolean {
        BMSConstants.setBmsUtilServiceObj(this._bmsUtilService);
        let bmsProductValidator = new BMSProductValidator(this.appObj.ApplicationBusinessObject);
        let validationResult: ValidationResult = bmsProductValidator.validate();
        if (validationResult.isValid == false) {
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, validationResult.message, -1));
            // Auto trigger emails for motor blacklist
            let riskScreen = this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.riskScreen;
            if (riskScreen == 'MPV' || riskScreen == 'MCV') {
                let risks;
                if (riskScreen == 'MPV') {
                    risks = this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.risks.motorMPV;
                } else {
                    risks = this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.risks.motorMCV;
                }
                if (!risks.sort) {
                    risks = [risks];
                }
                for (var index = 0; index < risks.length; index++) {
                    let riskObj = risks[index];
                    if (riskObj.blackListIndicator == 'true') {
                        this.sendAutoEmailNotif(5, (index + 1), riskObj.blackListReason);
                        break;
                    }
                }
            }
        }

        if (validationResult.isWarned) {
            this._alertMsgService.add(new AlertMessage(AlertMessage.WARN, validationResult.warningMessage, -1));
        }

        //AL001 START - VPMS BLOCKDATE VERIFY FOR THE PRODUCT
        let isVPMSBlockedProduct = false;
        this.vpmsBlockDateValidProducts.forEach(element => {
            if (element == this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.contractType) {
                isVPMSBlockedProduct = true;
            }
        });
        let isAfterVPMSBlockDate = moment(this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.effectiveDate, "YYYY-MM-DD").isSameOrAfter(
            moment(this.vpmsBlockDate, "YYYYMMDD"));
        //console.log("isAfterVPMSBlockDate =" + isAfterVPMSBlockDate + ",isVPMSBlockedProduct=" + isVPMSBlockedProduct);
        if (isAfterVPMSBlockDate && isVPMSBlockedProduct) {
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Not accepting the policy effective date is after "
                + moment(this.vpmsBlockDate, "YYYYMMDD").format(this.getDateFormat()) + ", Please proceed for Save"
                , -1));
            validationResult.isValid = false;
        }

        //AL001 END
        return validationResult.isValid;
    }

    private validateHeader(): boolean {
        let draftValidator = new HeaderValidator(this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo);
        let validationResult: ValidationResult = draftValidator.validate();
        if (validationResult.isValid == false)
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, validationResult.message, -1));

        //GA004 START
        /*
        let caseInfo = BMSConstants.getBMSCaseInfo();
        let procObj = BMSConstants.getBMSProcessInfo();
        let headerInfo = this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo;
        this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "caseId:<"+ caseInfo.caseId+ "> status:<" + caseInfo.status  + "> workflowStatus:<" + procObj.workflowStatus+">", -1));
        if( headerInfo.highRiskInternalIndicator == "A" || headerInfo.highRiskVehicleIndicator == "A" || headerInfo.highRiskLossRatioIndicator == "A" 
            || headerInfo.highRiskInsuredInternalInd == "A" || headerInfo.highRiskNomineeInternalInd == "A" || headerInfo.highRiskDriverInternalInd == "A" ){
            let error_message = "";
            if(BMSConstants.getBMSCaseInfo().lineOfBusiness == "MTR") {
                error_message = "<p> Header: Client / Vehicle is High Risk Indicator with Alert.</p>";
                this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, error_message, -1));
            }else{
                error_message = "<p> Header: Client is High Risk Indicator with Alert.</p>";
                this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, error_message, -1));
            } 
        }
        */
        //GA004 END
        return validationResult.isValid;
    }


    //AL001 START	
    setVPMSBlockDate() {
        let request: GetLOVData = new GetLOVData();
        request.BRANCH = 'ALL';
        request.LOB = 'MOTOR';
        request.BUSINESS_FUNCTION = 'NEW BUSINESS';
        request.PRODUCT = 'ALL';
        request.OPERATION = 'NEW';
        request.FORM_NAME = 'PRIVATE_MOTOR';
        request.FORM_FIELD_NAME = 'VPMS BLOCK DATE';
        request.FIELD_TYPE = 'LOV';
        request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        this._cordysService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.VPMSBlockDateSuccessHandler, this.handleError, false, this);

    }

    VPMSBlockDateSuccessHandler(response, scopeObject) {
        scopeObject.vpmsBlockDate = response.tuple.old.T7031.lastUpdateDate;
    }

    handleError(response, status, errorText, scopeObject) {
        scopeObject._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, response.responseJSON.faultstring.text, 10000));
    }

    setVPMSBlockDateProductList() {
        let request: GetLOVData = new GetLOVData();
        request.BRANCH = 'ALL';
        request.LOB = 'MOTOR';
        request.BUSINESS_FUNCTION = 'NEW BUSINESS';
        request.PRODUCT = 'ALL';
        request.OPERATION = 'NEW';
        request.FORM_NAME = 'PRIVATE_MOTOR';
        request.FORM_FIELD_NAME = 'VPMS block date valid';
        request.FIELD_TYPE = 'LOV';
        request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        this._cordysService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.VPMSBlockDateProductListSuccessHandler, this.handleError, false, this);

    }

    VPMSBlockDateProductListSuccessHandler(response, scopeObject) {
        scopeObject.vpmsBlockDateValidProducts.push(response.tuple.old.T7274.CNTTYPE01);
        scopeObject.vpmsBlockDateValidProducts.push(response.tuple.old.T7274.CNTTYPE02);
        scopeObject.vpmsBlockDateValidProducts.push(response.tuple.old.T7274.CNTTYPE03);
        scopeObject.vpmsBlockDateValidProducts.push(response.tuple.old.T7274.CNTTYPE04);
        scopeObject.vpmsBlockDateValidProducts.push(response.tuple.old.T7274.CNTTYPE05);
        scopeObject.vpmsBlockDateValidProducts.push(response.tuple.old.T7274.CNTTYPE06);
        scopeObject.vpmsBlockDateValidProducts.push(response.tuple.old.T7274.CNTTYPE07);
        scopeObject.vpmsBlockDateValidProducts.push(response.tuple.old.T7274.CNTTYPE08);
        scopeObject.vpmsBlockDateValidProducts.push(response.tuple.old.T7274.CNTTYPE10);
        scopeObject.vpmsBlockDateValidProducts.push(response.tuple.old.T7274.CNTTYPE12);
        scopeObject.vpmsBlockDateValidProducts.push(response.tuple.old.T7274.CNTTYPE13);
        scopeObject.vpmsBlockDateValidProducts.push(response.tuple.old.T7274.CNTTYPE14);
        scopeObject.vpmsBlockDateValidProducts.push(response.tuple.old.T7274.CNTTYPE15);
        scopeObject.vpmsBlockDateValidProducts.push(response.tuple.old.T7274.CNTTYPE16);
        scopeObject.vpmsBlockDateValidProducts.push(response.tuple.old.T7274.CNTTYPE17);
        scopeObject.vpmsBlockDateValidProducts.push(response.tuple.old.T7274.CNTTYPE18);
        scopeObject.vpmsBlockDateValidProducts.push(response.tuple.old.T7274.CNTTYPE19);
        scopeObject.vpmsBlockDateValidProducts.push(response.tuple.old.T7274.CNTTYPE20);
    }
    //AL001 END

    public setContolButtonsACL() {
        this._controlAreaService.setActionLisByStatus().subscribe(() => {
            let processInfo = BMSConstants.getBMSProcessInfo();
            if (processInfo.workflowStatus === "P400 Pending NB" && (["MyTasks", "MyDrafts"].indexOf(this._activatedRoute.snapshot.params['component']) >= 0 || Object.keys(this._activatedRoute.snapshot.params).length == 0)) //GA002 -- added condition
                this.checkIfPolicyPosted(false);
        });
    }

    private closeForm() {
        if (this._activatedRoute.snapshot.params['caseID']) {
            switch (this._activatedRoute.snapshot.params['component']) {

                case "MyTasks":

                    this._router.navigate(["/Home"]);
                    break;
                case "MyCases":

                    this._router.navigate(["/MyCases"]);
                    break;
                case "Enquiry":

                    this._router.navigate(["/Enquiry"]);
                    break;
                default:

                    this._router.navigate(["/Home"]);
            }
        } else {
            this._router.navigate(["Home"]);
        }
    }

    private getUserId(data) {
        this.userId = data.substring(3, data.indexOf(","));
        //Get roles
        this._appUtilService.getUserRoles().subscribe((data) => this.setUserRoles(data));
    }

    private setUserRoles(data) {
        this.userRoles = data;
        // Check the task permissions
        if (this.taskID) {
            this.getTaskDetails();
        }
    }

    // ---------------------Comments logic starts here-------------------------
    // This is for Comments Component
    public openCommentDialog() {
        let lookup = new ModalInput();
        lookup.component = ["CommentComponent", "app/common/components/comment/comment.module", "CommentModule"];
        lookup.outputCallback = this.getCommentsData;
        lookup.datainput = {
            branch: this.appObj.ApplicationBusinessObject.caseInfo.handlingBranchId,
            lob: this.appObj.ApplicationBusinessObject.caseInfo.lineOfBusiness,
            application: "BMS"
        }
        lookup.parentCompPRMS = {
            comp: this
        };
        lookup.heading = "Enter Comments";
        lookup.icon = "glyphicon glyphicon-comment";
        lookup.containerRef = this.contentArea;
        this.dcl.openLookup(lookup);
    }

    public getCommentsData(_comment, prms) {
        prms.comp.addCommentToProcessHistory(_comment);
    }

    public addCommentToProcessHistory(commentObj) {
        var userName = this.userFullName;
        var userId = this.userId;
        var newApprovalNode = new Approval();
        newApprovalNode.target = (AppUtil.isEmpty(commentObj.roleName, false) == false) ? this.getRolesFromComntRole(commentObj) : "SELF";
        newApprovalNode.targetType = (AppUtil.isEmpty(commentObj.roleName, false) == false) ? "Role" : "SELF";
        newApprovalNode.user = userName;
        newApprovalNode.action = "Commented";
        newApprovalNode.isPrivate = commentObj.isPrivate;
        newApprovalNode.targetRoles = commentObj.roleName;
        newApprovalNode.comment = commentObj.comments;
        this.appObj.ApplicationBusinessObject.caseInfo.approvalInfo.addItem(newApprovalNode);
        this.saveBusinessObject(this.callBackAfterSaveButtonClick);
    }

    public getRolesFromComntRole(commentObj) {
        let roleNames = "";
        let roles = commentObj.roleName;
        if (AppUtil.isEmpty(roles, false) == false) {
            let rlList = roles.split("'");
            let takeFlg = false;
            for (var count = 0; count < rlList.length; count++) {
                if (takeFlg == true) {
                    roleNames = (AppUtil.isEmpty(roleNames, false) == false) ? roleNames + ", " + rlList[count] : rlList[count];
                    takeFlg = false;
                }
                else
                    takeFlg = true;
            }
        }
        return roleNames;
    }

    // ---------------------Comments logic ends here-------------------------

    // -------------------------- Process history comments logic starts here----------------------

    public openCommentsDialog(dialogData: CommentDialogData, response?: any) {
        let lookup = new ModalInput();
        lookup.component = [dialogData.component, dialogData.moduleAbsPath, dialogData.moduleName];
        lookup.datainput = {
            dialogName: dialogData.dialogName,
            userList: null,
            areCommentsMandatory: true,
            registerResponse: null,
            caseStatus: this.appObj.ApplicationBusinessObject.caseInfo.status
        };
        lookup.outputCallback = dialogData.callBackHandler;
        lookup.parentCompPRMS = {
            comp: this,
            response: response
        };
        lookup.heading = dialogData.dialogTitle;
        lookup.icon = dialogData.icon;
        lookup.containerRef = this.contentArea;
        this.dcl.openLookup(lookup);
    }

    private getAHRole() {
        this._cordysService.callCordysSoapService("GetRolesForBranchLOBUser",
            "http://schemas.cordys.com/msig/masterdata/1.0",
            this.getGetAHRoleParams(),
            this.getAHRoleSuccessHandler,
            this.getAHRoleErrorHandler,
            false, this)
    }

    private getGetAHRoleParams() {
        return {
            "BRANCH_CODE": this.appObj.ApplicationBusinessObject.caseInfo.handlingBranchId,
            "LOB_CODE": this.appObj.ApplicationBusinessObject.caseInfo.lineOfBusiness,
            "USER_ID": this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.accountHandler,
            "APPLICATION": "BMS",
            "BUSINESS_FUNCTION": "NB"
        }
    }

    private getAHRoleSuccessHandler(data, scopeObject) {
        if (data.tuple) {
            scopeObject.appObj.ApplicationBusinessObject.processObject.accountHandlerRoleDn = data.tuple.old.MSIG_BRANCH_LOB_ROLE_USER_MAPPING.BRANCH_CODE + "_" + data.tuple.old.MSIG_BRANCH_LOB_ROLE_USER_MAPPING.LOB_CODE + "_" + data.tuple.old.MSIG_BRANCH_LOB_ROLE_USER_MAPPING.ROLE_CODE;
            scopeObject.nextRole = scopeObject.appObj.ApplicationBusinessObject.processObject.accountHandlerRoleDn;
        }
        else {
            scopeObject.AHRole = null;
            scopeObject.appObj.ApplicationBusinessObject.processObject.accountHandlerRoleDn = "";
        }

    }

    private getAHRoleErrorHandler(response, status, errorText, extraParams) {
        extraParams._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error getting the AH role", -1));
    }

	/* VK001
	private isUserAccountActive(userId){
			this._cordysService.callCordysSoapService("GetMsigUsersMasterObject",
			"http://schemas.opentext.com/msig/persistancedb/1.0",
			{"USER_ID": userId},
			this.isUserActiveSuccessHandler,
			this.isUserActiveErrorHandler,
			false,this)
	}
	*/
    //VK001 Changed the service call from getMsigUsersMasterObject to GetLoggedInUserInfo

    private isUserAccountActive(userId) {
        this._cordysService.callCordysSoapService("GetLoggedInUserInfo",
            "http://schemas.opentext.com/msig/persistancedb/1.0",
            null,
            this.isUserActiveSuccessHandler,
            this.isUserActiveErrorHandler,
            false, this)
    }

    //  END VK001 

    private isUserActiveSuccessHandler(data, scopeObject) {
        if (!data.tuple) {
            scopeObject.isUserActive = false;
            return;
        }
        if (data.tuple.old.MSIG_USERS_MASTER.STATUS == "ACTIVE") {
            scopeObject.isUserActive = true;
        }
        // added below code for SAF-2017-1086
        else if (data.tuple.old.MSIG_USERS_MASTER.STATUS == "INACTIVE" && (data.tuple.old.MSIG_USERS_MASTER.OUT_FROM_DATE != "" || data.tuple.old.MSIG_USERS_MASTER.OUT_FROM_DATE != "NULL") && moment.utc(new Date()).format("YYYY-MM-DD") < moment(data.tuple.old.MSIG_USERS_MASTER.OUT_FROM_DATE, "YYYY-MM-DD").format("YYYY-MM-DD")) {
            scopeObject.isUserActive = true;
        }
        else {
            scopeObject.isUserActive = false;
        }
    }

    private commentCallBackForHoldCover(data, prms) {
        if (data.isDialogCancelled) {
            return;
        }
        prms.comp.appObj.ApplicationBusinessObject.caseInfo.caseobjectstatusBeforeHoldCover = prms.comp.appObj.ApplicationBusinessObject.caseInfo.status;
        prms.comp.appObj.ApplicationBusinessObject.caseInfo.processobjectstatusBeforeHoldCover = prms.comp.appObj.ApplicationBusinessObject.processObject.workflowStatus;
        prms.comp.appObj.ApplicationBusinessObject.caseInfo.status = "Hold Cover";
        prms.comp.appObj.ApplicationBusinessObject.processObject.workflowStatus = "Hold Cover";
        //Process History
        var userName = prms.comp.userFullName;
        var userId = prms.comp.userId;
        var newApprovalNode = new Approval();
        newApprovalNode.target = "SELF";
        newApprovalNode.targetType = "SELF";
        newApprovalNode.user = userName;
        newApprovalNode.action = "Hold Cover";
        newApprovalNode.comment = data.comments;
        prms.comp.appObj.ApplicationBusinessObject.caseInfo.approvalInfo.addItem(newApprovalNode);
        //Save
        prms.comp.saveBusinessObject(prms.comp.callBackAfterCommentCloseForHoldCover);
    }

    private isUserActiveErrorHandler(response, status, errorText, extraParams) {
        extraParams._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error getting the status of  user account", -1));
    }

    private commentCallBack(data, prms) {
        if (data.isDialogCancelled) {
            return;
        }
        prms.comp.appObj.ApplicationBusinessObject.processObject.workFlowTaskID = prms.comp.taskID;
        switch (data.dialogName) {
            case "blackListed":
                prms.comp.appObj.ApplicationBusinessObject.processObject.workflowStatus = "Black Listed";
                prms.comp.appObj.ApplicationBusinessObject.processObject.nextUserDN = "cn="
                    + prms.comp.appObj.ApplicationBusinessObject.caseInfo.requestedBy
                    + ",cn=organizational users," + prms.comp.orgDN;
                prms.comp.fillProcessHistoryInfo(
                    prms.comp.appObj.ApplicationBusinessObject,
                    "Black listed",
                    data.comments,
                    prms.comp.appObj.ApplicationBusinessObject.processObject.caseHandlerRoleDn.substring(3, prms.comp.appObj.ApplicationBusinessObject.processObject.caseHandlerRoleDn.indexOf(",")),
                    "Role"
                );
                prms.comp.sendAutoEmailNotif(4, 1, prms.comp.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.blackListReason);
                break;
            case "submitToAH":
                prms.comp.getAHRole();
                prms.comp.appObj.ApplicationBusinessObject.processObject.workflowStatus = "Assessment Approval";
                if (!prms.comp.isUserActive) {
                    prms.comp.appObj.ApplicationBusinessObject.processObject.nextUserDN = "";
                } else {
                    prms.comp.appObj.ApplicationBusinessObject.processObject.nextUserDN = "cn=" + prms.comp.appObj.ApplicationBusinessObject.caseInfo.accountHandler + ",cn=organizational users," + prms.comp.orgDN;
                }
                prms.comp.appObj.ApplicationBusinessObject.processObject.nextRoleDN = "cn="
                    + prms.comp.appObj.ApplicationBusinessObject.processObject.accountHandlerRoleDn
                    + ",cn=organizational roles," + prms.comp.orgDN;
                prms.comp.fillProcessHistoryInfo(
                    prms.comp.appObj.ApplicationBusinessObject,
                    "Submitted to AH",
                    data.comments,
                    prms.comp.appObj.ApplicationBusinessObject.processObject.accountHandlerRoleDn,
                    "Role"
                );
                if (prms.comp.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.HighRiskCus == 'Y') {
                    prms.comp.addProcessHistoryRecord(prms.comp, "High Risk Customer checked.", "SELF", "SELF", prms.comp.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.HighRiskCusComments);
                }
                //GA004 START
                //prms.comp.sendHighRiskMailtoAH(prms.comp);
                //GA004 END
                break;

            case "submitToAHForJPJFeedback":
                prms.comp.getAHRole();
                prms.comp.appObj.ApplicationBusinessObject.processObject.workflowStatus = "Cover Note Created";
                if (!prms.comp.isUserActive) {
                    prms.comp.appObj.ApplicationBusinessObject.processObject.nextUserDN = "";
                } else {
                    prms.comp.appObj.ApplicationBusinessObject.processObject.nextUserDN = "cn=" + prms.comp.appObj.ApplicationBusinessObject.caseInfo.accountHandler + ",cn=organizational users," + prms.comp.orgDN;
                }
                prms.comp.appObj.ApplicationBusinessObject.processObject.nextRoleDN = "cn="
                    + prms.comp.appObj.ApplicationBusinessObject.processObject.accountHandlerRoleDn
                    + ",cn=organizational roles," + prms.comp.orgDN;
                prms.comp.fillProcessHistoryInfo(
                    prms.comp.appObj.ApplicationBusinessObject,
                    "Submitted to AH",
                    data.comments,
                    prms.comp.appObj.ApplicationBusinessObject.processObject.accountHandlerRoleDn,
                    "Role"
                );
                break;

            case "close":
            // added code for 1823  -- start
            case "common-comment-close-case": // End
                prms.comp.appObj.ApplicationBusinessObject.processObject.workflowStatus = "Closed";
                prms.comp.fillProcessHistoryInfo(
                    prms.comp.appObj.ApplicationBusinessObject,
                    "Closed",
                    data.comments,
                    "SELF",
                    "User"
                );
                prms.comp.deleteCasePolicyMapping();
                prms.comp._caMailService.sendFacRIMail("CL", data.reasonDesc).subscribe();
                break;

            case "moveToAssessment":
                prms.comp.appObj.ApplicationBusinessObject.processObject.workflowStatus = "Assessment";
                prms.comp.appObj.ApplicationBusinessObject.processObject.nextUserDN = "cn="
                    + prms.comp.appObj.ApplicationBusinessObject.caseInfo.requestedBy
                    + ",cn=organizational users," + prms.comp.orgDN;
                prms.comp.fillProcessHistoryInfo(
                    prms.comp.appObj.ApplicationBusinessObject,
                    "Submitted to Assessment",
                    data.comments,
                    prms.comp.appObj.ApplicationBusinessObject.caseInfo.requestedBy,
                    "User"
                );
                break;

            case "moveToAssessmentRR":
                if (prms.comp.appObj.ApplicationBusinessObject.processObject.workflowStatus != "Decline") {
                    prms.comp.appObj.ApplicationBusinessObject.processObject.isRerateApprovedByUW = "true";
                    prms.comp.isRerateReviewed = true;
                }
                else {
                    prms.comp.appObj.ApplicationBusinessObject.processObject.isRerateApprovedByUW = "false";
                    prms.comp.isRerateReviewed = false;
                }

                prms.comp.isRerateReviewed ? prms.comp.appObj.ApplicationBusinessObject.processObject.workflowStatus = "Rerate Reviewed" : prms.comp.appObj.ApplicationBusinessObject.processObject.workflowStatus = "Assessment";
                prms.comp.appObj.ApplicationBusinessObject.processObject.nextUserDN = "cn="
                    + prms.comp.appObj.ApplicationBusinessObject.caseInfo.requestedBy
                    + ",cn=organizational users," + prms.comp.orgDN;
                prms.comp.isRerateReviewed ? prms.comp.fillProcessHistoryInfo(prms.comp.appObj.ApplicationBusinessObject, "Rerate Reviewed", data.comments, prms.comp.appObj.ApplicationBusinessObject.caseInfo.requestedBy, "User") : prms.comp.fillProcessHistoryInfo(prms.comp.appObj.ApplicationBusinessObject, "Submitted to Assessment", data.comments, prms.comp.appObj.ApplicationBusinessObject.caseInfo.requestedBy, "User");
                break;

            case "decline":
                // To handle decline from AH to go to BH
                if (prms.comp.appObj.ApplicationBusinessObject.processObject.workflowStatus === "Assessment Approval") {
                    prms.comp.appObj.ApplicationBusinessObject.processObject.workflowStatus = "Assessment";
                    prms.comp.appObj.ApplicationBusinessObject.processObject.action = "Declined by AH";
                    prms.comp.appObj.ApplicationBusinessObject.processObject.comments = data.comments;
                } else {
                    if (prms.comp.appObj.ApplicationBusinessObject.processObject.nextRoleDN.indexOf("UW") != -1 && prms.comp.appObj.ApplicationBusinessObject.caseInfo.businessFunction != "RenewalRerate") {
                        prms.comp.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.isDeclinedByUW = "true";
                    } else {
                        prms.comp.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.isDeclinedByUW = "false";
                    }
                    prms.comp.appObj.ApplicationBusinessObject.processObject.workflowStatus = "Decline";
                    if (!prms.comp.isUserActive) {
                        prms.comp.appObj.ApplicationBusinessObject.processObject.nextUserDN = "";
                    } else {
                        prms.comp.appObj.ApplicationBusinessObject.processObject.nextUserDN = "cn=" + prms.comp.appObj.ApplicationBusinessObject.caseInfo.accountHandler + ",cn=organizational users," + prms.comp.orgDN;
                    }
                    prms.comp.appObj.ApplicationBusinessObject.processObject.nextRoleDN = "cn="
                        + prms.comp.appObj.ApplicationBusinessObject.processObject.accountHandlerRoleDn
                        + ",cn=organizational roles," + prms.comp.orgDN;
                    prms.comp.fillProcessHistoryInfo(
                        prms.comp.appObj.ApplicationBusinessObject,
                        "Declined",
                        data.comments,
                        prms.comp.appObj.ApplicationBusinessObject.processObject.accountHandlerRoleDn,
                        "Role"
                    );
                }
                break;
            case "resubmit":
                switch (prms.comp.appObj.ApplicationBusinessObject.processObject.workflowStatus) {
                    case "RFI Review":
                        prms.comp.appObj.ApplicationBusinessObject.processObject.workflowStatus = "Refferal Review";
                        break;
                    case "RFI Approval":
                        prms.comp.appObj.ApplicationBusinessObject.processObject.workflowStatus = "Refferal Approval";
                        break;
                    case "RFI RHC Approval":
                        prms.comp.appObj.ApplicationBusinessObject.processObject.workflowStatus = "RHC Referral Approval";
                        break;
                    case "RFI Quotation":
                        prms.comp.appObj.ApplicationBusinessObject.processObject.workflowStatus = "Quotation";
                        break;
                    case "RFI Policy Processing":
                        prms.comp.appObj.ApplicationBusinessObject.processObject.workflowStatus = "Policy Processing";
                        break;
                    //VK012
                    case "RFI Pending Receipting":
                        prms.comp.appObj.ApplicationBusinessObject.processObject.workflowStatus = "Pending Receipting";
                        break;
                    //VK012 END
                    case "RFI Cover Note Processing":
                        prms.comp.appObj.ApplicationBusinessObject.processObject.workflowStatus = "Cover Note Processing";
                        break;
                    case "RFI Assessment Approval":
                        prms.comp.appObj.ApplicationBusinessObject.processObject.workflowStatus = "Assessment Approval";
                        break;
                    case "RFI Decline":
                        prms.comp.appObj.ApplicationBusinessObject.processObject.workflowStatus = "Decline";
                        break;
                    case "RFI Policy Pipeline":
                        prms.comp.appObj.ApplicationBusinessObject.processObject.workflowStatus = "Policy Pipeline";
                        break;
                    case "RFI BU SMT":
                        prms.comp.appObj.ApplicationBusinessObject.processObject.workflowStatus = "Appeal to BU SMT";
                        break;
                }
                prms.comp.appObj.ApplicationBusinessObject.processObject.nextRoleDN = prms.comp.appObj.ApplicationBusinessObject.processObject.currentRoleDN;
                prms.comp.appObj.ApplicationBusinessObject.processObject.nextUserDN = prms.comp.appObj.ApplicationBusinessObject.processObject.currentUserDN;
                if (prms.comp.appObj.ApplicationBusinessObject.processObject.workflowStatus != "Assessment Approval"
                    && prms.comp.appObj.ApplicationBusinessObject.processObject.workflowStatus != "Decline"
                    && prms.comp.appObj.ApplicationBusinessObject.processObject.workflowStatus != "Policy Pipeline") {
                    //E1003 Start
                    let actionValue = "";
                    if (prms.comp.appObj.ApplicationBusinessObject.processObject.workflowStatus == "Policy Processing") {
                        actionValue = "";
                    }
                    else {
                        actionValue = "Re-Submit";
                    }
                    //E1003 End
                    prms.comp.fillProcessHistoryInfo(
                        prms.comp.appObj.ApplicationBusinessObject,
                        actionValue,
                        data.comments,
                        prms.comp.appObj.ApplicationBusinessObject.processObject.currentRoleDN.substring(
                            3,
                            prms.comp.appObj.ApplicationBusinessObject.processObject.currentRoleDN.indexOf(",")
                        ),
                        "Role"
                    );
                } else {
                    prms.comp.fillProcessHistoryInfo(
                        prms.comp.appObj.ApplicationBusinessObject,
                        "Re-Submit",
                        data.comments,
                        prms.comp.appObj.ApplicationBusinessObject.processObject.currentUserDN.substring(
                            3,
                            prms.comp.appObj.ApplicationBusinessObject.processObject.currentUserDN.indexOf(",")
                        ),
                        "User"
                    );
                }
                break;
            case "moveToQuote":
            // added code for 1823  -- start
            case "common-comment-approval-quotation-referred":
                let oldState = prms.comp.appObj.ApplicationBusinessObject.processObject.workflowStatus;
                if (oldState == "Assessment" && prms.comp.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.HighRiskCus == 'Y') {
                    prms.comp.addProcessHistoryRecord(prms.comp, "High Risk Customer checked.", "SELF", "SELF", prms.comp.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.HighRiskCusComments);
                }
                prms.comp.appObj.ApplicationBusinessObject.processObject.comments = data.comments;
                //For Cancel Logic
                prms.comp.appObj.ApplicationBusinessObject.processObject.nextUserDN = prms.response.Success.nextUserDN;
                prms.comp.appObj.ApplicationBusinessObject.processObject.nextRoleDN = prms.response.Success.nextRoleDN;
                prms.comp.appObj.ApplicationBusinessObject.processObject.workflowStatus = prms.response.Success.nextWorkFlowStatus;
                prms.comp.appObj.ApplicationBusinessObject.processObject.buttonAction = prms.response.Success.buttonAction;
                prms.comp.appObj.ApplicationBusinessObject.processObject.reviewIndex = prms.response.Success.reviewIndex;
                prms.comp.appObj.ApplicationBusinessObject.processObject.action = "Submitted to Quotation";
                prms.comp.appObj.ApplicationBusinessObject.processObject.target = prms.comp.appObj.ApplicationBusinessObject.processObject.caseHandlerRoleDn.substring(3, prms.comp.appObj.ApplicationBusinessObject.processObject.caseHandlerRoleDn.indexOf(","));
                prms.comp.appObj.ApplicationBusinessObject.processObject.targetType = "Role";
                // For cancel
                break;
            case "approveByRefer":
                prms.comp.appObj.ApplicationBusinessObject.processObject.comments = data.comments;
                //For Cancel Logic
                prms.comp.appObj.ApplicationBusinessObject.processObject.nextUserDN = prms.response.Success.nextUserDN;
                prms.comp.appObj.ApplicationBusinessObject.processObject.nextRoleDN = prms.response.Success.nextRoleDN;
                prms.comp.appObj.ApplicationBusinessObject.processObject.workflowStatus = prms.response.Success.nextWorkFlowStatus;
                prms.comp.appObj.ApplicationBusinessObject.processObject.buttonAction = prms.response.Success.buttonAction;
                prms.comp.appObj.ApplicationBusinessObject.processObject.reviewIndex = prms.response.Success.reviewIndex;
                prms.comp.appObj.ApplicationBusinessObject.processObject.workFlowTaskID = prms.comp.taskID;
                prms.comp.appObj.ApplicationBusinessObject.processObject.action = "Submitted to Quotation";
                prms.comp.appObj.ApplicationBusinessObject.processObject.target = prms.comp.appObj.ApplicationBusinessObject.processObject.caseHandlerRoleDn.substring(3, prms.comp.appObj.ApplicationBusinessObject.processObject.caseHandlerRoleDn.indexOf(","));
                prms.comp.appObj.ApplicationBusinessObject.processObject.targetType = "Role";
                //For Cancel Logic
                break;

            case "moveToPolicyProcessing":
                prms.comp.appObj.ApplicationBusinessObject.processObject.comments = data.comments;
                prms.comp.appObj.ApplicationBusinessObject.processObject.workflowStatus = prms.response.Success.nextWorkFlowStatus;
                prms.comp.appObj.ApplicationBusinessObject.processObject.buttonAction = prms.response.Success.buttonAction;
                prms.comp.appObj.ApplicationBusinessObject.processObject.reviewIndex = prms.response.Success.reviewIndex;
                prms.comp.appObj.ApplicationBusinessObject.processObject.workFlowTaskID = prms.comp.taskID;
                prms.comp.appObj.ApplicationBusinessObject.processObject.action = "Recommended to policy processing";
                prms.comp.appObj.ApplicationBusinessObject.processObject.target = prms.response.Success.nextRoleDN.substring(3, prms.response.Success.nextRoleDN.indexOf(","));
                prms.comp.appObj.ApplicationBusinessObject.processObject.targetType = "Role";
                //Save BO
                prms.comp.appObj.ApplicationBusinessObject.processObject.nextRoleDN = prms.response.Success.nextRoleDN;
                prms.comp.appObj.ApplicationBusinessObject.processObject.nextUserDN = "";
                //GA001 START - MYS-2018-0597		
                //prms.comp._caMailService.sendFacRIMail("UW", "").subscribe();
                prms.comp._caMailService.sendFacRIMail("RID", "").subscribe();
                //GA001 End
                break;
            //VK012
            case "moveToReceipting":
                prms.comp.appObj.ApplicationBusinessObject.processObject.comments = data.comments;
                prms.comp.appObj.ApplicationBusinessObject.processObject.workflowStatus = prms.response.Success.nextWorkFlowStatus;
                prms.comp.appObj.ApplicationBusinessObject.processObject.buttonAction = prms.response.Success.buttonAction;
                prms.comp.appObj.ApplicationBusinessObject.processObject.reviewIndex = prms.response.Success.reviewIndex;
                prms.comp.appObj.ApplicationBusinessObject.processObject.workFlowTaskID = prms.comp.taskID;
                prms.comp.appObj.ApplicationBusinessObject.processObject.action = "Recommended to Pending Receipting";
                prms.comp.appObj.ApplicationBusinessObject.processObject.target = prms.response.Success.nextRoleDN.substring(3, prms.response.Success.nextRoleDN.indexOf(","));
                prms.comp.appObj.ApplicationBusinessObject.processObject.targetType = "Role";
                //Save BO
                prms.comp.appObj.ApplicationBusinessObject.processObject.nextRoleDN = prms.response.Success.nextRoleDN;
                prms.comp.appObj.ApplicationBusinessObject.processObject.nextUserDN = "";
                break;

            //VK012 END
        }
        prms.comp.saveBusinessObject(prms.comp.callBackAfterCommentClose);
    }

    private callBackAfterCommentClose(originalObject) {
        ProgressBarComponent.hide();
        originalObject._taskService.completeTask(originalObject.taskID);
        originalObject.closeForm();
    }

    private callBackAfterCommentCloseForHoldCover(originalObject) {
        originalObject.setContolButtonsACL();
        originalObject._alertMsgService.add(new AlertMessage(AlertMessage.SUCCESS, "Hold Cover Successful", -1));
        originalObject.closeForm();
    }

    private callBackAfterCommentCloseWithoutFormClose(originalObject) {
        ProgressBarComponent.hide();
        originalObject._taskService.completeTask(originalObject.taskID);
    }

    private getUserName(data, scopeObject) {
        scopeObject.userName = data;
    }

    // -------------------------- Process history comments logic ends here------------------------

    // Creates a Process history record
    private addProcessHistoryRecord(scopeObject, action, target, targetType, comments) {
        var newApprovalNode = new Approval();
        newApprovalNode.action = action;
        newApprovalNode.target = target
        newApprovalNode.targetType = targetType;
        newApprovalNode.comment = comments;
        newApprovalNode.user = scopeObject.userFullName;
        scopeObject.appObj.ApplicationBusinessObject.caseInfo.approvalInfo.addItem(newApprovalNode);
    }

    // Fill Process history information
    private fillProcessHistoryInfo(scopeObject: any, action: string, comments: string, target: string, targetType: string) {
        scopeObject.processObject.action = action;
        scopeObject.processObject.comments = comments;
        scopeObject.processObject.target = target;
        scopeObject.processObject.targetType = targetType;
    }

    /*Buttons*/
    //Save
    private saveButtonClick() {
        if (this.validateHeader()) {
            if (this.appObj.ApplicationBusinessObject.caseInfo.status != "Draft") {
                this.addProcessHistoryRecord(this, "Saved", "SELF", "SELF", "-");
            }
            this.saveBusinessObject(this.callBackAfterSaveButtonClick);
        }
    }

    private fillIdentity() {
        let identity = '';
        let risks = this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.risks;
        let header = this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo;
        let riskList = risks[this.riskArray.getArrayByRiskType(header.contractType)];
        identity = riskList.map(o => o.identity).toString();
        if (risks.motorMCV.length != 0) {
            identity = identity + "," + riskList.map(o => o.trailerRegistration).toString();
        }

        this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.identity = identity;
    }

    private saveBusinessObject(callbackFunction) {
        //	this.fillIdentity();
        if (callbackFunction) {
            this._appObjService.saveData().subscribe(() => callbackFunction(this));
        }
        else {
            this._appObjService.saveData().subscribe();
        }
    }

    private callBackAfterSaveButtonClick(originalObject) {
        originalObject._alertMsgService.add(new AlertMessage(AlertMessage.SUCCESS, "Data saved successfully", -1));
        originalObject._appObjService.refreshCaseData(originalObject.appObj.ApplicationBusinessObject.caseInfo).subscribe();
    }

    private saveSuccessHandler(data, scopeObject) {
        scopeObject.callBackFuncton(data, scopeObject.originalObject);
        scopeObject._alertMsgService.add(new AlertMessage(AlertMessage.SUCCESS, "Data saved successfully", -1));
    }

    saveErrorHandler(resp, a) {
        a._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Save Failed", -1));
    }
    /*Draft*/
    //Submit
    private submitButtonClick() {
        ProgressBarComponent.show('Please wait...', { dialogSize: 'm', progressType: 'primary' });
        if (this.validateHeader()) {
            this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.bizReceivedDate = moment.utc(new Date()).format("YYYY-MM-DD");;//GA003
            this.saveBusinessObject(this.submitCallBackAfterSave);
        }
        else {
            ProgressBarComponent.hide();
        }
    }

    private checkForExposureValue(originalObject) {
        let isValid = "true";
        let valueObj = originalObject.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.risks;
        let riskList = Object.keys(valueObj);
        let rtIdx = 0;
        for (let eachRiskAry of riskList) {
            if (valueObj[eachRiskAry].length > 0) {
                let allRisks: Array<any> = valueObj[eachRiskAry];
                let rkIdx = 1;
                for (let eachRisk of allRisks) {
                    switch (eachRisk.riskType) {
                        case "FC1":
                        case "FC2":
                        case "FC3":
                        case "FD1":
                        case "FD2":
                        case "FD3":
                        case "HHO":
                        case "ARI":
                        case "LOP":
                        case "AR":
                        case "ECP":
                        case "PP1":
                            //eachRisk.locality = (eachRisk.locality == "0")?"":eachRisk.locality;
                            if (eachRisk.accRegister.totalPercentage >= 90 && eachRisk.accRegister.totalPercentage <= 100) {
                                ProgressBarComponent.hide();
                                isValid = "false"
                                originalObject.emailType = "2";
                                originalObject.accRiskObject = eachRisk;
                                let inputObj = {
                                    "Message": "Total exposure percentage is more than 90 % against GAL, Do you want to send email to under writer?",
                                    "Action": ""
                                };
                                let input = inputObj;
                                let lookup = new ModalInput().get("Confirm");
                                lookup.datainput = input;
                                lookup.outputCallback = originalObject.openConfirmPopUpCallBack;
                                lookup.parentCompPRMS = { comp: originalObject };
                                lookup.heading = "Confirm Send Email to Underwriter";
                                lookup.icon = "fa fa-hand-paper-o";
                                lookup.containerRef = originalObject.contentArea;
                                originalObject.dcl.openLookup(lookup);

                                break;
                            }
                            break;
                    }
                    rkIdx++;
                }
                rtIdx++;
            }
        }
        if (isValid == "true") {
            if (originalObject.appObj.ApplicationBusinessObject.caseInfo.businessFunction == "Renewal") {
                originalObject.callBMSWorkflowHelper("SUBMIT_TO_ASSESSMENT_RN", originalObject.callBackForSubmitClick);
            }
            else {
                originalObject.callBMSWorkflowHelper("SUBMIT_TO_ASSESSMENT", originalObject.callBackForSubmitClick);
            }
        }
    }
    private openConfirmPopUpCallBack(data, prms) {

        ProgressBarComponent.show('Please wait...', { dialogSize: 'm', progressType: 'primary' });
        if (data.value == 'Y') {

            prms.comp.riskClassificationService.sendMailtoTreaty(prms.comp.accRiskObject, prms.comp.appObj.ApplicationBusinessObject.caseInfo.caseId, prms.comp.emailType);

        }
        if (prms.comp.appObj.ApplicationBusinessObject.caseInfo.businessFunction == "Renewal") {
            prms.comp.callBMSWorkflowHelper("SUBMIT_TO_ASSESSMENT_RN", prms.comp.callBackForSubmitClick);
        }
        else {
            prms.comp.callBMSWorkflowHelper("SUBMIT_TO_ASSESSMENT", prms.comp.callBackForSubmitClick);
        }
    }

    private submitCallBackAfterSave(originalObject) {
        //GA004 START
        let caseInfo = BMSConstants.getBMSCaseInfo();
        let procObj = BMSConstants.getBMSProcessInfo();
        let headerInfo = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo;
        //this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "caseId:<"+ caseInfo.caseId+ "> status:<" + caseInfo.status  + "> workflowStatus:<" + procObj.workflowStatus+">", -1));
        if ( headerInfo.isHighRiskApplicable && headerInfo.highRiskIndicator == "true"
            && (headerInfo.highRiskInternalIndicator == "A" || headerInfo.highRiskVehicleIndicator == "A" 
            || headerInfo.highRiskLossRatioIndicator == "A"
            || headerInfo.highRiskInsuredInternalInd == "A" || headerInfo.highRiskNomineeInternalInd == "A" || headerInfo.highRiskDriverInternalInd == "A" || headerInfo.highRiskLossRatioWDInd == "A") ) {
            let error_message = "";
            if (BMSConstants.getBMSCaseInfo().lineOfBusiness == "MTR") {
                error_message = "<p> Header: Client / Vehicle is High Risk Indicator with Alert.</p>";
                originalObject._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, error_message, -1));
            } else {
                error_message = "<p> Header: Client is High Risk Indicator with Alert.</p>";
                originalObject._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, error_message, -1));
            }
        }
        //GA004 END
        if (!headerInfo.isHighRiskApplicable && originalObject.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.blackListIndicator === "true") {
            let type = originalObject.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.blackListInternalIndicator == 'Y' ? 3 : 4;
            originalObject.sendAutoEmailNotif(type, 1, originalObject.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.blackListReason);
            ProgressBarComponent.hide();
            originalObject.openConfirmationPopUp("The case will be blacklisted.  Do you want to continue?", "blacklist");
        }
        else if (originalObject.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.channelConflictIndicator === "true" && originalObject.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.clientDetails.client.genericDetails.clienttype != 'P') {
            originalObject.sendChannelConflcitMail();
            ProgressBarComponent.hide();
            originalObject._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Channel conflict occured for this case. Please resolve and proceed", -1));
        }
        else {
            if (originalObject.validateProposal()) {
                originalObject.appObj.ApplicationBusinessObject.caseInfo.handlingBranchId = originalObject.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.handlingBranch;
                if (!originalObject.validateForsubmit()) {
                    ProgressBarComponent.hide();
                    return;
                } else {

                    originalObject.checkForExposureValue(originalObject)

                }
            }
            else {
                ProgressBarComponent.hide();
            }
        }
    }

    private sendChannelConflcitMail() {

        let type = this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.lineOfBusiness == 'FIR' ? 1 : 2;
        let reason = "";
        if (type == 1) {
            let headerInfoObj = this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo;
            let risks: any;
            if (headerInfoObj.contractType == 'FC1' || headerInfoObj.contractType == 'FC2' || headerInfoObj.contractType == 'FC3') {
                risks = this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.risks.fireIDC;
            } else if (headerInfoObj.contractType == 'LOP') {
                risks = this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.risks.fireLOP;
            }
            if (risks != undefined) {
                if (!risks.sort) {
                    risks = [risks];
                }
                let risk = risks[0];
                if (risk.situation1 && risk.situation1.trim() != "") {
                    reason += risk.situation1 + "\n|\n";
                }
                if (risk.situation2 && risk.situation2.trim() != "") {
                    reason += risk.situation2 + "\n|\n";
                }
                if (risk.situationLine1 && risk.situationLine1.trim() != "") {
                    reason += risk.situationLine1 + "\n|\n";
                }
                if (risk.situationLine2 && risk.situationLine2.trim() != "") {
                    reason += risk.situationLine2 + "\n|\n";
                }
                if (risk.situationLine3 && risk.situationLine3.trim() != "") {
                    reason += risk.situationLine3 + "\n|\n";
                }
                if (risk.situationLine4 && risk.situationLine4.trim() != "") {
                    reason += risk.situationLine4 + "\n|\n";
                }
                if (risk.situationLine5 && risk.situationLine5.trim() != "") {
                    reason += risk.situationLine5 + "\n|\n";
                }
                if (risk.situationLine6 && risk.situationLine6.trim() != "") {
                    reason += risk.situationLine6 + "\n|\n";
                }
                if (risk.situationLine7 && risk.situationLine7.trim() != "") {
                    reason += risk.situationLine7 + "\n|\n";
                }
                if (risk.situationLine8 && risk.situationLine8.trim() != "") {
                    reason += risk.situationLine8;
                }
            }
        }
        this.sendAutoEmailNotif(type, 1, reason);
    }

    private callBackForSubmitClick(response, originalObject) {
        if (response.Success) {
            if (response.Success.canComplete === "true") {
                ProgressBarComponent.hide();
                originalObject._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "BR and BH cannot be same.  Please check the master data mapping.", -1));
            }
            else {
                // Pop up to be displayed with users list under nextRole 
                if (response.Success) {
                    originalObject.userList = response.Success.userList;
                }
                ProgressBarComponent.hide();
                originalObject.openUserSelectionDialog("submit", response);
            }
        }
        else {
            ProgressBarComponent.hide();
            originalObject._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error Occured.Please check the Approval Matrix Routing Configuration", -1));
        }

    }

    private callBack2ForSubmitClick(originalObject) {
        originalObject.startApprovalProcess();
    }

    private sendAutoEmailNotif(type: number, riskNo?: number, reason?: string) {
        if (!riskNo) {
            riskNo = 1;
        }
        if (!reason) {
            reason = "";
        }
        this._cordysService.callCordysSoapService(
            "SendAutoEmailNotification",
            "http://schemas.insurance.com/businessobject/1.0/",
            {
                "CaseId": this.appObj.ApplicationBusinessObject.caseInfo.caseId,
                "Type": type,
                "RiskNo": riskNo,
                "Reason": reason
            },
            null,
            null,
            true,
            this
        );
    }

    //Conflict
    private conflictButtonClick() {
        this.appObj.ApplicationBusinessObject.caseInfo.handlingBranchId = this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.handlingBranch;
        this.saveBusinessObject(this.conflictCallBackAfterSave);
    }

    private conflictCallBackAfterSave(originalObject) {
        if (originalObject.appObj.ApplicationBusinessObject.caseInfo.businessFunction == "Renewal") {
            originalObject.callBMSWorkflowHelper("SUBMIT_TO_CC_RN", originalObject.callBackForConflictClick);
        }
        else
            originalObject.callBMSWorkflowHelper("SUBMIT_TO_CC", originalObject.callBackForConflictClick);
    }

    private callBackForConflictClick(response, originalObject) {
        if (response.Success) {
            if (response.Success.canComplete === "true") {
                originalObject._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "BR and BH cannot be same.  Please check the master data mapping.", -1));
            }
            else {
                // Pop up to be displayed with users list under nextRole 
                if (response.Success) {
                    originalObject.userList = response.Success.userList;
                }
                originalObject.openUserSelectionDialog("conflict", response);
            }
        }
        else {
            originalObject._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error Occured.Please check the Approval Matrix Routing Configuration", -1));
        }

    }

    private callBack2ForConflictClick(originalObject) {
        originalObject.startApprovalProcess();
    }

    //Blacklist from BR
    private blacklistFromBRButtonClick() {
        this.appObj.ApplicationBusinessObject.caseInfo.handlingBranchId = this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.handlingBranch;
        this.saveBusinessObject(this.blacklistFromBRCallBackAfterSave);
    }

    private blacklistFromBRCallBackAfterSave(originalObject) {
        if (originalObject.appObj.ApplicationBusinessObject.caseInfo.businessFunction == "Renewal") {
            originalObject.callBMSWorkflowHelper("SUBMIT_TO_BL_RN", originalObject.callBackForBlacklistFromBRClick);
        }
        else
            originalObject.callBMSWorkflowHelper("SUBMIT_TO_BL", originalObject.callBackForBlacklistFromBRClick);
    }

    private callBackForBlacklistFromBRClick(response, originalObject) {
        if (response.Success) {
            if (response.Success.canComplete === "true") {
                originalObject._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "BR and BH cannot be same.  Please check the master data mapping.", -1));
            }
            else {
                // Pop up to be displayed with users list under nextRole 
                if (response.Success) {
                    originalObject.userList = response.Success.userList;
                }
                originalObject.openUserSelectionDialog("blacklistFromBR", response);
            }
        }
        else {
            originalObject._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error Occured.Please check the Approval Matrix Routing Configuration", -1));
        }

    }

    private callBack2ForBlacklistFromBRClick(originalObject) {
        originalObject.startApprovalProcess();
    }

    /*Assessment*/
    //Blacklist
    private blacklistButtonClick() {
        var dialogData = new CommentDialogData("CommonCommentDialogComponent", "app/bms/components/proposal/process/common.comment.dialog.module", "CommonCommentDialogModule", "Provide comments", "blackListed", "fa fa-comment", this.commentCallBack);
        this.openCommentsDialog(dialogData);
    }

    //Submit to AH
    private submitToAHButtonClick() {
        //GA004 START
        let caseInfo = BMSConstants.getBMSCaseInfo();
        let procObj = BMSConstants.getBMSProcessInfo();
        let headerInfo = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo;
        //this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "caseId:<"+ caseInfo.caseId+ "> status:<" + caseInfo.status  + "> workflowStatus:<" + procObj.workflowStatus+">", -1));
        if ( headerInfo.isHighRiskApplicable && headerInfo.highRiskIndicator == "true"
            && (headerInfo.highRiskInternalIndicator == "A" || headerInfo.highRiskVehicleIndicator == "A" 
            || headerInfo.highRiskLossRatioIndicator == "A"
            || headerInfo.highRiskInsuredInternalInd == "A" || headerInfo.highRiskNomineeInternalInd == "A" || headerInfo.highRiskDriverInternalInd == "A" || headerInfo.highRiskLossRatioWDInd == "A") ) {
            let error_message = "";
            if (BMSConstants.getBMSCaseInfo().lineOfBusiness == "MTR") {
                error_message = "<p> Header: Client / Vehicle is High Risk Indicator with Alert.</p>";
                this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, error_message, -1));
            } else {
                error_message = "<p> Header: Client is High Risk Indicator with Alert.</p>";
                this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, error_message, -1));
            }
        }
        //GA004 END
        if (this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.duplicateIndicator === "true") {
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Duplicate case(s) found, please complete the check and proceed", -1));
            return;
        }
        if (!headerInfo.isHighRiskApplicable && this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.blackListIndicator === "true") {
            this.openConfirmationPopUp("The case will be blacklisted.  Do you want to continue?", "blacklist");
        }
        //KA0001 MYS-2018-0391 START 
        //let workFlowInfo = BMSConstants.getBMSProcessInfo();
        if (this.appObj.ApplicationBusinessObject.caseInfo.status == "Assessment" && this.appObj.ApplicationBusinessObject.caseInfo.businessFunction === "Renewal" && this.agentAccountValidation()) {
            //if(){
            //	if(this.agentAccountValidation()){
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Agent Account Expired. Please select different Agent", -1));
            return;

        }
        // KA0001 Divek END
        else {
            this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.isDeclinedByUW = "false";
            this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.isApprovedBySMT = "false";
            this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.isRFIByDC = "false";
            if (this.appObj.ApplicationBusinessObject.caseInfo.accountHandler != null && this.appObj.ApplicationBusinessObject.caseInfo.accountHandler != "") {
                this.confirmHRC().subscribe((data) => {
                    if (data.data.value == "Y") {
                        if (this.validateProposal()) {
                            //Redmine ticket 818
                            this.getAHRole();
                            if ((this.appObj.ApplicationBusinessObject.processObject.accountHandlerRoleDn == "" || !this.appObj.ApplicationBusinessObject.processObject.accountHandlerRoleDn) && (!this.AHRole || this.AHRole == null)) {
                                this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "AH Role is not available. Please contact Administrator.", 6000));
                                return;
                            }
                            //Redmine ticket 818
                            this.isUserAccountActive(this.appObj.ApplicationBusinessObject.caseInfo.accountHandler);
                            if (!this.isUserActive) {
                                this.openConfirmationPopUp("The selected AH is out of office. The task will be sent to the role. Do you want to continue?", "AHOutOfOffice");
                            }
                            else {
                                var dialogData = new CommentDialogData("CommonCommentDialogComponent", "app/bms/components/proposal/process/common.comment.dialog.module", "CommonCommentDialogModule", "Provide comments", "submitToAH", "fa fa-comment", this.commentCallBack);
                                this.openCommentsDialog(dialogData);
                            }

                        }
                    }
                });
            }
            else {
                this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "AH cannot be empty", -1));
            }
        }
    }
    //KA0001 MYS-2018-0391 added below method
    public agentAccountValidation() {
        var validAgent: boolean;
        var dateValue: any;
        var responsePromise = this._cordysService.callCordysSoapService("GetCurrentDate", "http://schemas.opentext.com/msig/persistancedb/1.0", null, null, null, false, null);
        responsePromise.done((data) => {
            dateValue = data.tuple.old.getCurrentDate.getCurrentDate;
        });
        dateValue = ApplicationUtilService.getFormattedDate(dateValue, "YYYY-MM-DD", "YYYYMMDD");
        var respObj: any;
        var responseObj = this._cordysService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0",
            {
                "cursor": {
                    "@id": "0", "position": "0", "numRows": "5", "maxRows": "25", "sameConnection": "false"
                },
                "BRANCH": "ALL", "LOB": "ALL", "BUSINESS_FUNCTION": "ALL", "PRODUCT": "ALL", "OPERATION": "ALL",
                "FORM_NAME": "ALL", "FORM_FIELD_NAME": "AGENT_CODE", "FIELD_TYPE": "LOOKUP",
                "ADVANCE_CONFIG_XML": {
                    "FILTERS": {
                        "FILTER": [
                            { "@FIELD_NAME": "AGENT_CODE", "@FIELD_VALUE": this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.agentCode, "@OPERATION": "EQ", "@CONDITION": "AND" },
                            { "@FIELD_NAME": "DATEEND", "@FIELD_VALUE": dateValue, "@OPERATION": "GTEQ", "@CONDITION": "AND" }
                        ]
                    }
                }
            }, null, null, false, null);
        responseObj.done((data) => {
            respObj = data.tuple;
            //	if(typeof respObj==='undefined' )	{     
            if (!respObj) {
                this.agentaccount = true;

            }
            else {
                this.agentaccount = false;

            }

        });
        if (this.agentaccount)
            return true;
        else
            return false;

    }
    //KA0001 MYS-2018-0391 end
    /*Assessment Approval*/
    //Move to Quotation
    private moveToQuotationButtonClick() {
        if (this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.duplicateIndicator === "true") {
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Duplicate case(s) found, please complete the check and proceed", -1));
            return;
        }

        //GA004 START
        let caseInfo = BMSConstants.getBMSCaseInfo();
        let procObj = BMSConstants.getBMSProcessInfo();
        let headerInfo = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo;
        //this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "caseId:<"+ caseInfo.caseId+ "> status:<" + caseInfo.status  + "> workflowStatus:<" + procObj.workflowStatus+">", -1));
        if ( headerInfo.isHighRiskApplicable && headerInfo.highRiskIndicator == "true"
            && (headerInfo.highRiskInternalIndicator == "A" || headerInfo.highRiskVehicleIndicator == "A" 
            || headerInfo.highRiskLossRatioIndicator == "A"
            || headerInfo.highRiskInsuredInternalInd == "A" || headerInfo.highRiskNomineeInternalInd == "A" || headerInfo.highRiskDriverInternalInd == "A" || headerInfo.highRiskLossRatioWDInd == "A") ) {
            let error_message = "";
            if (BMSConstants.getBMSCaseInfo().lineOfBusiness == "MTR") {
                error_message = "<p> Header: Client / Vehicle is High Risk Indicator with Alert.</p>";
                this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, error_message, -1));
            } else {
                error_message = "<p> Header: Client is High Risk Indicator with Alert.</p>";
                this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, error_message, -1));
            }
        }
        //GA004 END

        let workFlowInfo = BMSConstants.getBMSProcessInfo();
        if (workFlowInfo.workflowStatus == "Assessment") {
            //KA0001 Divek Start 0391 changes 
            if (this.appObj.ApplicationBusinessObject.caseInfo.businessFunction == "Renewal") {
                if (this.agentAccountValidation()) {
                    this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Agent Account Expired. Please select different Agent", -1));
                    return;
                }
            }
            // KA0001 Divek END	
            this.confirmHRC().subscribe((data) => {
                if (data.data.value == "Y") {
                    if (this.validateProposal()) {
                        this.untagSTP();
                        this.saveBusinessObject(this.moveToQuotationCallBackAfterSave);
                    }
                }
            });
        }
        else {
            if (this.validateProposal()) {
                this.untagSTP();
                this.saveBusinessObject(this.moveToQuotationCallBackAfterSave);
            }
        }
    }

    private untagSTP() {
        if (this.appObj.ApplicationBusinessObject.caseInfo.businessFunction == "Renewal") {
            this.appObj.ApplicationBusinessObject.caseInfo.isPostedBySTP = 'N';
            this.appObj.ApplicationBusinessObject.caseInfo.isFastTrack = "N";
        }
    }


    private moveToQuotationCallBackAfterSave(originalObject) {
        if (originalObject.appObj.ApplicationBusinessObject.caseInfo.businessFunction == "Renewal") {
            originalObject.callBMSWorkflowHelper("QUOTATION_RN", originalObject.callBackForMoveToQuotationClick);
        }
        else
            originalObject.callBMSWorkflowHelper("QUOTATION", originalObject.callBackForMoveToQuotationClick);
    }

    private callBackForMoveToQuotationClick(response, originalObject) {
        if (response.Success) {
            if (response.Success.canComplete === "true") {
                // Should open User selection popup and on close fill process history information annd then save
				/* old code
				var dialogData = new CommentDialogData("CommonCommentDialogComponent", "app/bms/components/proposal/process/common.comment.dialog.module", "CommonCommentDialogModule", "Provide comments", "moveToQuote", "fa fa-comment", originalObject.commentCallBack);
				*/
                // code for 1823 -- start
                if (!originalObject.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.isReferredRiskUI)
                    var dialogData = new CommentDialogData("CommonCommentDialogComponent", "app/bms/components/proposal/process/common.comment.dialog.module", "CommonCommentDialogModule", "Provide comments", "moveToQuote", "fa fa-comment", originalObject.commentCallBack);
                //var dialogData = new CommentDialogData(UserSelectionComponent, "Provide comments", "moveToQuote", "fa fa-comment", originalObject.commentCallBack);
                else
                    var dialogData = new CommentDialogData("CommonCommentDialogComponent", "app/bms/components/proposal/process/common.comment.dialog.module", "CommonCommentDialogModule", "Provide comments", "common-comment-approval-quotation-referred", "fa fa-comment", originalObject.commentCallBack);

                originalObject.openCommentsDialog(dialogData, response);
            }
            else {
                // Pop up to be displayed with users list under nextRole 
                if (response.Success) {
                    originalObject.userList = response.Success.userList;
                }
                originalObject.openUserSelectionDialog("moveToQuotation", response);
            }
        }
        else {
            originalObject._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error Occurred.Please check the Approval Matrix Routing Configuration", -1));
        }
    }

    private callBack2ForMoveToQuotationClick(originalObject) {
        originalObject._taskService.completeTask(originalObject.taskID);
        originalObject.closeForm();
    }

    //VK012 Move to Receipting
    private moveToReceiptingButtonClick() {

        if (BMSConstants.getBMSHeaderInfo().isSimplifiedProcess == 'Y') {
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "For simplified flow please opt for HO Policy Processing !", 15000));
            return;
        }
        this._controlAreaService.validateQuotationDate().subscribe(
            (data) => {
                if (data.response == 'true') {
                    if (this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.RIRequiredHeader == "Yes" && this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.RIType != "TreatyAdjustment") {
                        this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "For RIRequired 'Yes' and RIType Treatment Adjustment related risks please opt for HO Policy Processing !", 15000));
                        return;
                    }

                    if (this.validateProposal()) {
                        ProgressBarComponent.show('Please wait...', { dialogSize: 'm', progressType: 'primary' });
                        this.appObj.ApplicationBusinessObject.processObject.isHeadOfficePP = "false";
                        this.saveBusinessObject(this.moveToReceiptingCallBackAfterSave);
                    }
                }
            });
    }

    private moveToHOReceiptingButtonClick() {

        this._controlAreaService.validateQuotationDate().subscribe(
            (data) => {
                if (data.response == 'true') {

                    if (this.validateProposal()) {
                        ProgressBarComponent.show('Please wait...', { dialogSize: 'm', progressType: 'primary' });
                        this.appObj.ApplicationBusinessObject.processObject.isHeadOfficePP = "true";
                        this.saveBusinessObject(this.moveToReceiptingCallBackAfterSave);
                    }
                }
            });
    }

    private moveToReceiptingCallBackAfterSave(originalObject) {
        if (originalObject.appObj.ApplicationBusinessObject.caseInfo.businessFunction == "Renewal") {
            originalObject.callBMSWorkflowHelper("RECEIPTING_RN", originalObject.callBackForMoveToReceiptingClick);
        }
        else originalObject.callBMSWorkflowHelper("RECEIPTING", originalObject.callBackForMoveToReceiptingClick);
    }


    private callBackForMoveToReceiptingClick(response, originalObject) {
        if (response.Success) {
            if (response.Success.canComplete === "true") {
                var dialogData = new CommentDialogData("CommonCommentDialogComponent", "app/bms/components/proposal/process/common.comment.dialog.module", "CommonCommentDialogModule", "Provide comments", "moveToReceipting", "fa fa-comment", originalObject.commentCallBack);
                originalObject.openCommentsDialog(dialogData, response);
            }
            else {
                // Pop up to be displayed with users list under nextRole 
                originalObject.userList = response.Success.userList;
                originalObject.openUserSelectionDialog("moveToReceipting", response);
            }
        }
        else {
            if (response.Fault && response.Fault.FaultDetail) {
                originalObject._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, response.Fault.FaultString, -1));
            } else {
                originalObject._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error Occured.Please check the Approval Matrix Routing Configuration", -1));
            }
        }
        ProgressBarComponent.hide();//Added new code to avoid multiple clicks from UI.
    }

    private callBack2ForMoveToReceiptingClick(originalObject) {
        originalObject.manuscriptMailHandler('false');
        originalObject._taskService.completeTask(originalObject.taskID);
        originalObject.closeForm();
    }

    //VK012 END

    //Move to policy processing
    private moveToPolicyProcessingButtonClick() {

        if (BMSConstants.getBMSHeaderInfo().isSimplifiedProcess == 'Y') {
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "For simplified flow please opt for HO Policy Processing !", 15000));
            return;
        }
        this._controlAreaService.validateQuotationDate().subscribe(
            (data) => {
                if (data.response == 'true') {
                    // Allowing users to submit HHO, FD1, FD2, FD3 products proposals to PP for MYS-2017-0884 -- start
                    //E1002 Start
                    if (this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.RIRequiredHeader == "Yes" && this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.RIType != "TreatyAdjustment") {
                        this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "For RIRequired 'Yes' and RIType Treatment Adjustment related risks please opt for HO Policy Processing !", 15000));
                        return;
                    }
                    //E1002 End
                    // E1001 commented the code for all products to move policy processing
                    /*if (["MIS", "WCE"].indexOf(this.appObj.ApplicationBusinessObject.caseInfo.lineOfBusiness) >= 0 || ["FC1", "FC2", "FC3", "ECP"].indexOf(this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.contractType) >= 0) {
                        let _msg = "For " + this.appObj.ApplicationBusinessObject.caseInfo.lineOfBusiness + " (or) FC1, FC2, FC3, LOP related risks please opt for HO Policy Processing !";
                        this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, _msg, 15000));
                        return;
                    }*/ //End
                    // E1001 End
                    if (this.validateProposal()) {
                        ProgressBarComponent.show('Please wait...', { dialogSize: 'm', progressType: 'primary' });//Added new code to avoid multiple clicks from UI.
                        this.appObj.ApplicationBusinessObject.processObject.isHeadOfficePP = "false";
                        this.saveBusinessObject(this.moveToPolicyProcessingCallBackAfterSave);
                    }
                }
            });


    }

    //Move to HO policy processing
    private moveToHOPolicyProcessingButtonClick() {
        this._controlAreaService.validateQuotationDate().subscribe(
            (data) => {
                if (data.response == 'true') {
                    let isValid = "true";
                    let valueObj = this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.risks;
                    let riskList = Object.keys(valueObj);
                    let rtIdx = 0;
                    for (let eachRiskAry of riskList) {
                        if (valueObj[eachRiskAry].length > 0) {
                            let allRisks: Array<any> = valueObj[eachRiskAry];
                            let rkIdx = 1;
                            for (let eachRisk of allRisks) {
                                switch (eachRisk.riskType) {
                                    case "FC1":
                                    case "FC2":
                                    case "FC3":
                                    case "FD1":
                                    case "FD2":
                                    case "FD3":
                                    case "HHO":
                                    case "ARI":
                                    case "LOP":
                                    case "AR":
                                    case "ECP":
                                    case "PP1":
                                        //eachRisk.locality = (eachRisk.locality == "0")?"":eachRisk.locality;
                                        if (eachRisk.accumulationRegister == "0") {
                                            let count = (rtIdx * allRisks.length) + rkIdx;
                                            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Risk Number: " + count + ") Please select a valid Accumulation Register. Current selected value is \"Register Not Found\"", 9000));
                                            isValid = "false";
                                        }
                                        break;
                                }
                                rkIdx++;
                            }
                            rtIdx++;
                        }
                    }

                    if (this.validateProposal() && isValid == "true") {
                        ProgressBarComponent.show('Please wait...', { dialogSize: 'm', progressType: 'primary' });//Added new code to avoid multiple clicks from UI.
                        this.appObj.ApplicationBusinessObject.processObject.isHeadOfficePP = "true";
                        this.saveBusinessObject(this.moveToPolicyProcessingCallBackAfterSave);
                    }
                }
            });
    }

    //Move to cover note processing
    private moveToCoverNoteProcessingButtonClick() {
        if (this.validateProposal()) {
            this.appObj.ApplicationBusinessObject.processObject.isHeadOfficePP = "false";
            this.saveBusinessObject(this.moveToCoverNoteProcessingCallBackAfterSave);
        }
    }

    //Move to HO cover note processing
    private moveToHOCoverNoteProcessingButtonClick() {
        if (this.validateProposal()) {
            this.appObj.ApplicationBusinessObject.processObject.isHeadOfficePP = "true";
            this.saveBusinessObject(this.moveToCoverNoteProcessingCallBackAfterSave);
        }
    }

    private moveToPolicyProcessingCallBackAfterSave(originalObject) {
        if (originalObject.appObj.ApplicationBusinessObject.caseInfo.businessFunction == "Renewal") {
            originalObject.callBMSWorkflowHelper("POLICY_PROCESSING_RN", originalObject.callBackForMoveToPolicyProcessingClick);
        }
        else originalObject.callBMSWorkflowHelper("POLICY_PROCESSING", originalObject.callBackForMoveToPolicyProcessingClick);
    }

    private callBackForMoveToPolicyProcessingClick(response, originalObject) {
        if (response.Success) {
            if (response.Success.canComplete === "true") {
                var dialogData = new CommentDialogData("CommonCommentDialogComponent", "app/bms/components/proposal/process/common.comment.dialog.module", "CommonCommentDialogModule", "Provide comments", "moveToPolicyProcessing", "fa fa-comment", originalObject.commentCallBack);
                originalObject.openCommentsDialog(dialogData, response);
            }
            else {
                // Pop up to be displayed with users list under nextRole 
                originalObject.userList = response.Success.userList;
                originalObject.openUserSelectionDialog("moveToPolicyProcessing", response);
            }
        }
        else {
            if (response.Fault && response.Fault.FaultDetail) {
                originalObject._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, response.Fault.FaultString, -1));
            } else {
                originalObject._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error Occured.Please check the Approval Matrix Routing Configuration", -1));
            }
        }
        ProgressBarComponent.hide();//Added new code to avoid multiple clicks from UI.
    }

    private callBack2ForMoveToPolicyProcessingClick(originalObject) {
        originalObject.manuscriptMailHandler('false');
        //GA001 START - MYS-2018-0597		
        //originalObject._caMailService.sendFacRIMail("UW", "").subscribe();
        originalObject._caMailService.sendFacRIMail("RID", "").subscribe();
        //GA001 End
        originalObject._taskService.completeTask(originalObject.taskID);
        originalObject.closeForm();
    }

    private moveToCoverNoteProcessingCallBackAfterSave(originalObject) {
        originalObject.callBMSWorkflowHelper("Cover Note Processing", originalObject.callBackForMoveToCoverNoteProcessingClick);
    }

    private callBackForMoveToCoverNoteProcessingClick(response, originalObject) {
        if (response.Success) {
            if (response.Success.canComplete === "true") {

                originalObject.openUserSelectionDialog("moveToCNPOnCanCompleteYes", response);
            }
            else {
                // Pop up to be displayed with users list under nextRole 
                originalObject.userList = response.Success.userList;
                originalObject.openUserSelectionDialog("moveToCoverNoteProcessing", response);
            }
        }
        else {
            if (response.Fault && response.Fault.FaultDetail) {
                originalObject._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, response.Fault.FaultDetail, -1));
            } else {
                originalObject._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error Occured.Please check the Approval Matrix Routing Configuration", -1));
            }
        }
    }

    private declineButtonClick() {
        this.saveBusinessObject(this.callBackAfterDeclineSave);
    }

    private callBackAfterDeclineSave(originalObject) {
        originalObject.isUserAccountActive(originalObject.appObj.ApplicationBusinessObject.caseInfo.accountHandler);
        if (!originalObject.isUserActive) {
            originalObject.openConfirmationPopUp("The selected AH is out of office. The task will be sent to the role. Do you want to continue?", "AHOutOfOfficeDecline");
        }
        else {
            //AL002 START
			/*if (originalObject.appObj.ApplicationBusinessObject.processObject.workflowStatus == "Assessment Approval" || originalObject.appObj.ApplicationBusinessObject.processObject.workflowStatus == "Refferal Approval") {
				originalObject.openCommonCommentDialog("common-comment-decline-reason","Provide reason for decline");
			} 
			else{
				var dialogData = new CommentDialogData("CommonCommentDialogComponent", "app/bms/components/proposal/process/common.comment.dialog.module", "CommonCommentDialogModule", "Provide comments", "decline", "fa fa-comment", originalObject.commentCallBack);
				originalObject.openCommentsDialog(dialogData);
			}
          */
            originalObject.openCommonCommentDialog("common-comment-decline-reason", "Provide reason for decline");
            //AL002 END
        }
    }

    private callBackDeclineReasonAtAH(response, originalObject) {
        // if canComplete is true, decline reasons are rquired; otherwise not
        if (response.Success) {
            if (response.Success.canComplete == "true") {
                originalObject.openCommonCommentDialog("common-comment-decline-reason", "Provide reason for decline");
            } else {
                var dialogData = new CommentDialogData("CommonCommentDialogComponent", "app/bms/components/proposal/process/common.comment.dialog.module", "CommonCommentDialogModule", "Provide comments", "decline", "fa fa-comment", originalObject.commentCallBack);
                originalObject.openCommentsDialog(dialogData, response);
            }
        } else {
            var dialogData = new CommentDialogData("CommonCommentDialogComponent", "app/bms/components/proposal/process/common.comment.dialog.module", "CommonCommentDialogModule", "Provide comments", "decline", "fa fa-comment", originalObject.commentCallBack);
            originalObject.openCommentsDialog(dialogData, response);
        }
    }

    /*Decline*/
    //moveToAssessment
    private moveToAssessmentButtonClick() {
        if (this.validateProposal()) {
            var dialogData = new CommentDialogData("CommonCommentDialogComponent", "app/bms/components/proposal/process/common.comment.dialog.module", "CommonCommentDialogModule", "Provide comments", "moveToAssessment", "fa fa-comment", this.commentCallBack);
            this.openCommentsDialog(dialogData);
        }
    }

    private moveToAssessmentButtonClickRR() {
        if (this.validateProposal()) {
            var dialogData = new CommentDialogData("CommonCommentDialogComponent", "app/bms/components/proposal/process/common.comment.dialog.module", "CommonCommentDialogModule", "Provide comments", "moveToAssessmentRR", "fa fa-comment", this.commentCallBack);
            this.openCommentsDialog(dialogData);
        }
    }

    private validateDispatchHeader(): boolean {
        let draftValidator = new HeaderValidator(this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo);

        if (this.appObj.ApplicationBusinessObject.caseInfo.businessFunction != 'RenewalRerate') {
            let validationResult: ValidationResult = draftValidator.validateDispathInfo();
            if (validationResult.isValid == false)
                this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, validationResult.message, -1));
            return validationResult.isValid;
        }
        else {
            return true;
        }


    }

    //Close

    private closeButtonClick() {
        //If PP Do not allow to close without posting
        if (this.appObj.ApplicationBusinessObject.caseInfo.status === "Policy Processing" || this.appObj.ApplicationBusinessObject.caseInfo.status === "Cover Note Processing") {
            //Policy Successful Posted check 
            if (this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.policyIssued) {
                if (this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.policyIssued != "true") {
                    this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Please post the case in P400 before closing", -1));
                    return;
                }
            }
            else {
                this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Please post the case in P400 before closing", -1));
                return;
            }
        } else if (this.appObj.ApplicationBusinessObject.caseInfo.status == "P400 In forced") {
            // header validation for isssue 782.
            if (!this.validateDispatchHeader()) {
                return;
            }
        }
        else if (this.appObj.ApplicationBusinessObject.caseInfo.status == "Quotation") {

            let headerInfo = BMSConstants.getBMSHeaderInfo();
            if (headerInfo && headerInfo.lineOfBusiness == 'MTR') {

                this._ncdService.cancelNCD().subscribe((resp) => { this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "NCD Cancelled", -1)) },
                    error => this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error while cancelling NCD", -1)));
            }
        }

		/* old code
		var dialogData = new CommentDialogData("CommonCommentDialogComponent", "app/bms/components/proposal/process/common.comment.dialog.module", "CommonCommentDialogModule", "Provide comments", "close", "fa fa-comment", this.commentCallBack);
		*/
        /* adding below code for issue 1823 -- start */
        var dialogData = new CommentDialogData("CommonCommentDialogComponent", "app/bms/components/proposal/process/common.comment.dialog.module", "CommonCommentDialogModule", "Provide comments", "common-comment-close-case", "fa fa-comment", this.commentCallBack);
        // End
        this.openCommentsDialog(dialogData);
    }

    setMinForDispatchDate() {
        if (this.dispatchDateCtrl != null && (this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.dispatchDate == '' || this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.dispatchDate == undefined)) {
            this.dispatchDateCtrl.setMinDate(moment(this.appObj.ApplicationBusinessObject.caseInfo.lastModifiedOn).format(this.getDateFormat()), this.dispatchDateCtrl.comp);
        }
    }

    getDateFormat() {
        let dtFormat = ApplicationUtilService.DATE_TIME_FORMAT;
        return dtFormat.split(" ")[0];
    }

    /* Referral review & Referral approval */
    //Approve
    private approveReviewButtonClick() {
        if (!this.validateHeader()) {// MYS-2018-0793-Divek -Added this validation
            return;
        }
        //GA004 START
        let caseInfo = BMSConstants.getBMSCaseInfo();
        let procObj = BMSConstants.getBMSProcessInfo();
        let headerInfo = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo;
        //this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "caseId:<"+ caseInfo.caseId+ "> status:<" + caseInfo.status  + "> workflowStatus:<" + procObj.workflowStatus+">", -1));
        if ( headerInfo.isHighRiskApplicable && headerInfo.highRiskIndicator == "true"
            && (headerInfo.highRiskInternalIndicator == "A" || headerInfo.highRiskVehicleIndicator == "A" 
            || headerInfo.highRiskLossRatioIndicator == "A"
            || headerInfo.highRiskInsuredInternalInd == "A" || headerInfo.highRiskNomineeInternalInd == "A" || headerInfo.highRiskDriverInternalInd == "A" || headerInfo.highRiskLossRatioWDInd == "A") ) {
            let error_message = "";
            if (BMSConstants.getBMSCaseInfo().lineOfBusiness == "MTR") {
                error_message = "<p> Header: Client / Vehicle is High Risk Indicator with Alert.</p>";
                this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, error_message, -1));
            } else {
                error_message = "<p> Header: Client is High Risk Indicator with Alert.</p>";
                this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, error_message, -1));
            }
        }
        //GA004 END
        if (!headerInfo.isHighRiskApplicable && this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.blackListIndicator === "true") {
            this.openConfirmationPopUp("The case will be blacklisted.  Do you want to continue?", "blacklist");
        }
        else {
            this.saveBusinessObject(this.approveCallBackAfterSave);
        }
    }

    private approveRefferalButtonClick() {
        if (!this.validateHeader()) {// MYS-2018-0793-Divek -Added this validation
            return;
        }
        //GA004 START
        let caseInfo = BMSConstants.getBMSCaseInfo();
        let procObj = BMSConstants.getBMSProcessInfo();
        let headerInfo = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo;
        //this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "caseId:<"+ caseInfo.caseId+ "> status:<" + caseInfo.status  + "> workflowStatus:<" + procObj.workflowStatus+">", -1));
        if ( headerInfo.isHighRiskApplicable && headerInfo.highRiskIndicator == "true"
            && (headerInfo.highRiskInternalIndicator == "A" || headerInfo.highRiskVehicleIndicator == "A" 
            || headerInfo.highRiskLossRatioIndicator == "A"
            || headerInfo.highRiskInsuredInternalInd == "A" || headerInfo.highRiskNomineeInternalInd == "A" || headerInfo.highRiskDriverInternalInd == "A" || headerInfo.highRiskLossRatioWDInd == "A") ) {
            let error_message = "";
            if (BMSConstants.getBMSCaseInfo().lineOfBusiness == "MTR") {
                error_message = "<p> Header: Client / Vehicle is High Risk Indicator with Alert.</p>";
                this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, error_message, -1));
            } else {
                error_message = "<p> Header: Client is High Risk Indicator with Alert.</p>";
                this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, error_message, -1));
            }
        }
        //GA004 END
        if (!headerInfo.isHighRiskApplicable && this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.blackListIndicator === "true") {
            this.openConfirmationPopUp("The case will be blacklisted.  Do you want to continue?", "blacklist");
        }
        else {
            this.saveBusinessObject(this.openCommonCommentDialogPopup);
        }

    }

    private openCommonCommentDialogPopup(originalObject) {
		/* old code 
		originalObject.openCommonCommentDialog("common-comment-referralapproval","Enter Comments"); */
        // new  code for 1823 -- start
        if (!originalObject.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.isReferredRiskUI)
            originalObject.openCommonCommentDialog("common-comment-referralapproval", "Enter Comments");
        else
            originalObject.openCommonCommentDialog("common-comment-approval-quotation-referred", "Provide Reason of Approve Referred Risk");
        // End
    }

    private approveCallBackAfterSave(originalObject) {
        originalObject.callBMSWorkflowHelper(originalObject.appObj.ApplicationBusinessObject.processObject.buttonAction, originalObject.callBackForApproveClick);
    }

    private refferalApproveCallBackAfterSave(originalObject) {
        originalObject.callBMSWorkflowHelper(originalObject.appObj.ApplicationBusinessObject.processObject.buttonAction, originalObject.callBackForRefferalApproveClick);
    }

    private callBackForRefferalApproveClick(response, originalObject) {
        if (response.Success) {
            if (response.Success.canComplete === "true") {
                originalObject.appObj.ApplicationBusinessObject.processObject.nextUserDN = response.Success.nextUserDN;
                originalObject.appObj.ApplicationBusinessObject.processObject.nextRoleDN = response.Success.nextRoleDN;
                originalObject.appObj.ApplicationBusinessObject.processObject.workflowStatus = response.Success.nextWorkFlowStatus;
                originalObject.appObj.ApplicationBusinessObject.processObject.buttonAction = response.Success.buttonAction;
                originalObject.appObj.ApplicationBusinessObject.processObject.reviewIndex = response.Success.reviewIndex;
                originalObject.appObj.ApplicationBusinessObject.processObject.workFlowTaskID = originalObject.taskID;
                originalObject.appObj.ApplicationBusinessObject.processObject.action = "Submitted to Quotation";
                originalObject.appObj.ApplicationBusinessObject.processObject.target = originalObject.appObj.ApplicationBusinessObject.processObject.caseHandlerRoleDn.substring(3, originalObject.appObj.ApplicationBusinessObject.processObject.caseHandlerRoleDn.indexOf(","));
                originalObject.appObj.ApplicationBusinessObject.processObject.targetType = "Role";
                //Save BO
                originalObject.saveBusinessObject(originalObject.callBack2ForApproveClick);
            }
            else {
                // Pop up to be displayed with users list under nextRole 
                if (response.Success) {
                    originalObject.userList = response.Success.userList;
                }
                originalObject.openUserSelectionDialog("refferal", response);
            }
        }
        else {
            originalObject._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error Occured.Please check the Approval Matrix Routing Configuration", -1));
        }
    }

    private callBackForApproveClick(response, originalObject) {
        if (response.Success) {
            if (response.Success.canComplete === "true") {
                var dialogData = new CommentDialogData("CommonCommentDialogComponent", "app/bms/components/proposal/process/common.comment.dialog.module", "CommonCommentDialogModule", "Provide comments", "approveByRefer", "fa fa-comment", originalObject.commentCallBack);
                originalObject.openCommentsDialog(dialogData, response);
            } else {
                // Pop up to be displayed with users list under nextRole 
                if (response.Success) {
                    originalObject.userList = response.Success.userList;
                }
                originalObject.openUserSelectionDialog("refferal", response);
            }
        }
        else {
            originalObject._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error Occured.Please check the Approval Matrix Routing Configuration", -1));
        }
    }

    private callBack2ForApproveClick(originalObject) {
        originalObject._caMailService.sendFacRIMail("FACRI", "").subscribe();
        originalObject._caMailService.sendFacRIMail("NRI", "").subscribe();
        originalObject._taskService.completeTask(originalObject.taskID);
        originalObject.closeForm();
    }

    //RFI
    private rfiButtonClick() {
        //VK015
        if (this.appObj.ApplicationBusinessObject.caseInfo.status == "Pending Receipting") {
            let approvalNodes = this.appObj.ApplicationBusinessObject.caseInfo.approvalInfo.approval;
            let approvalRec = approvalNodes.find((_data) => _data.action == "Submitted");
            let initiatedOn: any;
            let rfiLiveDate: any;
            initiatedOn = approvalRec.startDate.split("T")[0];
            let prom = this._cordysService.callCordysSoapService("GetMsigPropertiesObject", "http://schemas.cordys.com/msig/masterdata/1.0", { "KEY": "RFI_LIVE_DATE" }, null, null, false, null);
            prom.success((resp) => {
                rfiLiveDate = resp.tuple.old.MSIG_PROPERTIES.VALUE.toString();
            });
            prom.error((error) => {
                this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error while fetching Receipting Live Date.", -1));
            });
            let liveDate = moment(rfiLiveDate, "YYYY-MM-DD").format("YYYY-MM-DD");
            if (!moment(initiatedOn).isSameOrAfter(liveDate, 'day')) {
                this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Cannot perform RFI on this cases.", 10000));
                return true;
            }
        }
        //VK015
        this.getListOfUsersActedOnCase(this.appObj.ApplicationBusinessObject.caseInfo.caseId);
    }

    private getListOfUsersActedOnCase(caseId: string) {
        this._cordysService.callCordysSoapService("GetUsersWorkedOnCase",
            "http://schemas.cordys.com/msig/masterdata/1.0",
            this.getListOfUsersActedOnCaseParams(caseId),
            this.getListOfUsersActedOnCaseSuccessHandler,
            this.getListOfUsersActedOnCaseErrorHandler,
            true, this)
    }

    private getListOfUsersActedOnCaseParams(caseId) {
        return {
            "CASE_ID": caseId
        }
    }

    private getListOfUsersActedOnCaseSuccessHandler(data, scopeObject) {
        // Popup user selection dialog 
        scopeObject.openUserSelectionDialog("rfi", data);
    }

    private getListOfUsersActedOnCaseErrorHandler(response, status, errorText, extraParams) {
        console.error("Error while calling the getListOfUsersActedOnCase");
        extraParams._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error while calling the getListOfUsersActedOnCase", -1));
    }

    private rfiCallBackAfterSave(originalObject) {
        originalObject._taskService.completeTask(originalObject.taskID);
        originalObject.closeForm();
    }

    //Resubmit
    private resubmitButtonClick() {
        var dialogData = new CommentDialogData("CommonCommentDialogComponent", "app/bms/components/proposal/process/common.comment.dialog.module", "CommonCommentDialogModule", "Provide comments", "resubmit", "fa fa-comment", this.commentCallBack);
        this.openCommentsDialog(dialogData);
    }

    public getOrgDn(data, scopeObject) {
        scopeObject.orgDN = data;
        // Set the button actions
        this.setContolButtonsACL();
    }

    private setBMSWorkflowButtonConfig(data, scopeObject) {
        scopeObject.BMSWorkflowButtonConfig = data;
    }

    private postToP400ButtonClick() {

        if (this.validateProposal()) {
            ProgressBarComponent.show('Posting to P400 is in Progress', { dialogSize: 'm', progressType: 'primary' });
            //GA003 START
            let headerInfo = BMSConstants.getBMSHeaderInfo();
            if (headerInfo.bizReceivedDate == undefined || headerInfo.bizReceivedDate == "" || headerInfo.bizReceivedDate == '') {
                let caseInfo = BMSConstants.getBMSCaseInfo();
                let approvalNodes = caseInfo.approvalInfo.approval;
                let approvalRec = approvalNodes.find((_data) => _data.action == "Submitted");
                if (approvalRec != undefined && approvalRec.startDate != undefined && approvalRec.startDate != "") {
                    headerInfo.bizReceivedDate = approvalRec.startDate.split("T")[0];
                } else {
                    headerInfo.bizReceivedDate = headerInfo.bizAcceptanceDate;
                }
            }
            //GA003 END
            this.saveBusinessObject(this.afterSaveBeforePost);
        }
    }

    private postToP400ButtonClickRR() {
        if (this.validateProposal()) {
            ProgressBarComponent.show('Posting to P400 is in Progress', { dialogSize: 'm', progressType: 'primary' });
            //GA003 START
            let headerInfo = BMSConstants.getBMSHeaderInfo();
            if (headerInfo.bizReceivedDate == undefined || headerInfo.bizReceivedDate == "" || headerInfo.bizReceivedDate == '') {
                let caseInfo = BMSConstants.getBMSCaseInfo();
                let approvalNodes = caseInfo.approvalInfo.approval;
                let approvalRec = approvalNodes.find((_data) => _data.action == "Submitted");
                if (approvalRec != undefined && approvalRec.startDate != undefined && approvalRec.startDate != "") {
                    headerInfo.bizReceivedDate = approvalRec.startDate.split("T")[0];
                } else {
                    headerInfo.bizReceivedDate = headerInfo.bizAcceptanceDate;
                }
            }
            //GA003 END
            this.saveBusinessObject(this.afterSaveBeforePostRR);
        }
    }

    private postToP400RROnAfterSave(originalobject) {
        if (originalobject.validateProposal()) {
            ProgressBarComponent.show('Posting to P400 is in Progress', { dialogSize: 'm', progressType: 'primary' });
            originalobject.saveBusinessObject(originalobject.afterSaveBeforePostRR);
        }
    }

    private afterSaveBeforePostRR(originalObject) {
        originalObject.renService.postRenewals(originalObject.appObj.ApplicationBusinessObject.caseInfo.caseId, "", originalObject, "").subscribe(
            (data) => {
                originalObject.moveToPolicyInforced();

            }
        );
    }

    private sendMailToCoinsurer(originalObject) {
        originalObject._cordysService.callCordysSoapService("sendMailToCoInsurer", "http://schemas.insurance.com/businessobject/1.0/", { "caseId": originalObject.appObj.ApplicationBusinessObject.caseInfo.caseId }, null, null, false, this)
            .success((data) => {
                originalObject._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "A Co Insurance Notification mail sent to AH.", 6000));

            }
            )
            .error((response, status, errorText) => {
                originalObject._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, " Co Insurance Notification mail sending failed. " + errorText, 6000));

            });
    }

    private afterSaveBeforePost(originalObject) {
        originalObject.onBeforePost.emit({
            callbackFunction: null,
            scopeObject: originalObject
        });
    }

    private moveToPolicyInforced(comments?: string) {
        if (Number(BMSConstants.getBMSHeaderInfo().noOfRisks) > 20) {
            //For async  posting message and form disabling
            this.onStartOfAsyncPosting();
            return;
        }
        let headerInfo = BMSConstants.getBMSHeaderInfo();
        if (headerInfo.isPendingNB == "true" || !headerInfo.policyIssued || (headerInfo.policyIssued != "true" && headerInfo.policyIssued != true)) {
            headerInfo.policyIssued = "false";
            this.appObj.ApplicationBusinessObject.caseInfo.status = "P400 Pending NB";
            this.appObj.ApplicationBusinessObject.processObject.workflowStatus = "P400 Pending NB";
            this.saveBusinessObject(this.resetButtons);
        }
        else {
            this.fillTransactionNumberInDispatchInfo().done(() => {
                headerInfo.policyIssued = "true";
                this.appObj.ApplicationBusinessObject.caseInfo.status = "P400 In forced";
                this.appObj.ApplicationBusinessObject.processObject.workflowStatus = "P400 In forced";
                this.populateDispatchMode();
                //Process History
                var userName = this.userFullName;
                var userId = this.userId;
                var newApprovalNode = new Approval();
                newApprovalNode.target = "SELF";
                newApprovalNode.targetType = "SELF";
                newApprovalNode.user = userName;
                newApprovalNode.action = (this.appObj.ApplicationBusinessObject.caseInfo.isPostedBySTP == 'Y') ? "Straight Through Processing" : "Posted to P400";
                newApprovalNode.comment = comments != null || comments != "" || comments != undefined ? comments : "";
                this.appObj.ApplicationBusinessObject.caseInfo.approvalInfo.addItem(newApprovalNode);
                if (BMSConstants.getBMSType() == BMSType.Renewal && this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.CoInsurance == "Y") {
                    this.sendMailToCoinsurer(this);
                }
                this.saveBusinessObject(this.resetButtons);
            });
        }
    }



    private fillTransactionNumberInDispatchInfo() {
        return this._cordysService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", this.getLOVDataParamsForTxNo(), this.getLOVDataTxNoSuccessHandler, null, true, { comp: this });
    }

    private getLOVDataParamsForTxNo() {
        var requestObj = new GetLOVData();
        requestObj.BRANCH = 'ALL';
        requestObj.LOB = 'ALL';
        requestObj.BUSINESS_FUNCTION = 'NEW BUSINESS';
        requestObj.PRODUCT = 'ALL';
        requestObj.OPERATION = 'ALL';
        requestObj.FORM_NAME = 'DESPATCH INFO';
        requestObj.FORM_FIELD_NAME = 'Transaction Number';
        requestObj.FIELD_TYPE = 'LOV';
        requestObj.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        requestObj.ADVANCE_CONFIG_XML.FILTERS = new Filter();

        requestObj.ADVANCE_CONFIG_XML.FILTERS.FILTER = [
            {
                "@FIELD_NAME": 'CHDRNUM',
                "@FIELD_VALUE": this.appObj.ApplicationBusinessObject.caseInfo.policyNumber,
                '@OPERATION': 'EQ',
                '@CONDITION': 'AND'
            },
            {
                "@FIELD_NAME": 'CURRFROM',
                "@FIELD_VALUE": this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.effectiveDate.replace(/-/g, ""),
                '@OPERATION': 'EQ',
                '@CONDITION': 'AND'
            }
        ];

        return requestObj;
    }

    private getLOVDataTxNoSuccessHandler(response, prms) {
        if (response.tuple) {
            if (response.tuple.old && response.tuple.old.CHDR.TRANNO != "") {
                prms.comp.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.transactionNumber = response.tuple.old.CHDR.TRANNO;
            }
        }
    }

    private resetButtons(originalObject) {
        originalObject.setContolButtonsACL();
        ProgressBarComponent.hide();
    }

    private createCoverNoteButtonClick() {
        if (this.validateProposal()) {

            var DefaultingPOIDetails = this.defautValueforPOI();
            ProgressBarComponent.show('Creating CoverNote is in Progress', { dialogSize: 'm', progressType: 'primary' });
            this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.isDeclinedByUW = "false";
            this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.isApprovedBySMT = "false";
            this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.isRFIByDC = "false";
            this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.coverNoteissuedDate = moment.utc(new Date()).format("YYYY-MM-DD");

            this.saveBusinessObject(this.createCoverNoteService);

        }
    }
    private defautValueforPOI() {
        if (this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.riskScreen == 'MPV') {
            if (this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.risks.motorMPV[0].motorItems != undefined && Array.isArray(this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.risks.motorMPV[0].motorItems.motorItem)) {
                for (var i = 0; i < this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.risks.motorMPV[0].motorItems.motorItem.length; i++) {
                    if (this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.risks.motorMPV[0].motorItems.motorItem[i].isSpecial == 'Y' && (this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.risks.motorMPV[0].motorItems.motorItem[i].code != 'E101' || this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.risks.motorMPV[0].motorItems.motorItem[i].code != 'E102')) {
                        if (this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.risks.motorMPV[0].PIAMStatistics.prevPOIfrom == '' || this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.risks.motorMPV[0].PIAMStatistics.prevPOIfrom == undefined) {
                            this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.risks.motorMPV[0].PIAMStatistics.prevPOIfrom = this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.effectiveDate;
                            this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.risks.motorMPV[0].motorItems.motorItem[i].dateFromAdditionalBenfit = this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.effectiveDate;

                        }
                        if (this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.risks.motorMPV[0].PIAMStatistics.prevPOIto == '' || this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.risks.motorMPV[0].PIAMStatistics.prevPOIto == undefined) {
                            this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.risks.motorMPV[0].PIAMStatistics.prevPOIto = this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.endDate;
                            this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.risks.motorMPV[0].motorItems.motorItem[i].dateToAdditionalBenfit = this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.effectiveDate;

                        }

                    }
                }
            }
        } else {
            if (this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.risks.motorMCV[0].motorItems != undefined && Array.isArray(this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.risks.motorMCV[0].motorItems.motorItem)) {
                for (var i = 0; i < this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.risks.motorMCV[0].motorItems.motorItem.length; i++) {
                    if (this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.risks.motorMCV[0].motorItems.motorItem[i].isSpecial == 'Y' && (this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.risks.motorMCV[0].motorItems.motorItem[i].code != 'E101' || this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.risks.motorMCV[0].motorItems.motorItem[i].code != 'E102')) {
                        if (this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.risks.motorMCV[0].PIAMStatistics.prevPOIfrom == '' || this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.risks.motorMCV[0].PIAMStatistics.prevPOIfrom == undefined) {
                            this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.risks.motorMCV[0].PIAMStatistics.prevPOIfrom = this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.effectiveDate;
                            this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.risks.motorMCV[0].motorItems.motorItem[i].dateFromAdditionalBenfit = this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.effectiveDate;

                        }
                        if (this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.risks.motorMCV[0].PIAMStatistics.prevPOIto == '' || this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.risks.motorMCV[0].PIAMStatistics.prevPOIto == undefined) {
                            this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.risks.motorMCV[0].PIAMStatistics.prevPOIto = this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.endDate;
                            this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.risks.motorMCV[0].motorItems.motorItem[i].dateToAdditionalBenfit = this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.effectiveDate;

                        }

                    }
                }
            }
        }
    }

    private updateCoverNoteButtonClick() {
        let caseInfo = BMSConstants.getBMSCaseInfo();
        let headerInfo = BMSConstants.getBMSHeaderInfo();
        let processObj = BMSConstants.getBMSProcessInfo();
        if (this.validateProposal()) {
            ProgressBarComponent.show('Modify CoverNote is in Progress', { dialogSize: 'm', progressType: 'primary' });
            headerInfo.isDeclinedByUW = "false";
            headerInfo.isApprovedBySMT = "false";
            headerInfo.isRFIByDC = "false";
            headerInfo.coverNoteissuedDate = moment.utc(new Date()).format("YYYY-MM-DD");

            this.saveBusinessObject(this.updateCoverNoteService);
        }
    }

    private afterCreatingCoverNoteSequence(data) {
        if (data.sequenceNo) this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.coverNoteNumber = data.sequenceNo;
        this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.isDeclinedByUW = "false";
        this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.isApprovedBySMT = "false";
        this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.isRFIByDC = "false";
        this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.coverNoteissuedDate = moment.utc(new Date()).format("YYYY-MM-DD");
        this.saveBusinessObject(this.createCoverNoteService);
    }

    private createCoverNoteService(originalObject) {
        originalObject._ncdService.confirmNCD().subscribe((res) => {
            //	originalObject.cnService.coverNoteService(originalObject.appObj.ApplicationBusinessObject.caseInfo.caseId,"NV","CREATE","1","1")
            originalObject.cnService.coverNoteWrapperService(originalObject.appObj.ApplicationBusinessObject.caseInfo.caseId, "CREATE")
                .subscribe(
                    (data) => originalObject.aftercreateCoverNoteService(originalObject),
                    error => ProgressBarComponent.hide()
                );
        },
            error => this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error while confirming NCD", -1)));

    }


    private updateCoverNoteService(originalObject) {
        //	originalObject.cnService.coverNoteService(originalObject.appObj.ApplicationBusinessObject.caseInfo.caseId,"NV","CREATE","1","1")
        originalObject.cnService.coverNoteWrapperService(originalObject.appObj.ApplicationBusinessObject.caseInfo.caseId, "MODIFY")
            .subscribe(
                (data) => originalObject.afterUpdateCoverNoteService(originalObject),
                error => ProgressBarComponent.hide()
            );
    }

    private aftercreateCoverNoteService(originalObject) {
        let caseInfo = BMSConstants.getBMSCaseInfo();
        originalObject.appObj.ApplicationBusinessObject.processObject.workflowStatus = "Cover Note Created";
        caseInfo.jpjStatus = "Cover Note Created";
        originalObject.saveBusinessObject(originalObject.coverNoteSuccess);
    }

    private afterUpdateCoverNoteService(originalObject) {
        originalObject.appObj.ApplicationBusinessObject.processObject.workflowStatus = "Cover Note Created";
        originalObject.saveBusinessObject(originalObject.coverNoteSuccess);
    }

    private coverNoteSuccess(originalObject) {
        //originalObject._taskService.completeTask(originalObject.taskID);
        originalObject.closeForm();
        ProgressBarComponent.hide();
    }

    private cancelCoverNoteButtonClick() {
        let dialogData = new CommentDialogData("CommonCommentDialogComponent", "app/bms/components/proposal/process/common.comment.dialog.module", "CommonCommentDialogModule", "Provide comments", "cancelCoverNote", "fa fa-comment", this.cancelCoverNoteCallBack);
        this.openCommentsDialog(dialogData);
    }

    private cancelCoverNoteCallBack(res, prms) {
        if (res.isDialogCancelled) {
            return;
        }
        //prms.comp.cnService.coverNoteService(prms.comp.appObj.ApplicationBusinessObject.caseInfo.caseId,"NV","CANCEL","1","1")
        prms.comp.cnService.coverNoteWrapperService(prms.comp.appObj.ApplicationBusinessObject.caseInfo.caseId, "CANCEL").subscribe(
            (data) => prms.comp.afterCancelCoverNoteService(prms, res),
            error => ProgressBarComponent.hide()
        );
    }

    private afterCancelCoverNoteService(prms, res) {
        prms.comp.appObj.ApplicationBusinessObject.processObject.workflowStatus = "Cover Note Cancelled";
        prms.comp.fillProcessHistoryInfo(prms.comp.appObj.ApplicationBusinessObject, "Cover Note Cancelled", res.comments, "SELF", "User");
        prms.comp.saveBusinessObject(prms.comp.cancelCovenoteAfterSave);
    }

    private cancelCovenoteAfterSave(originalObject) {
        originalObject.onBeforeCancel.emit({
            callbackFunction: originalObject.onAfterNCDCancel,
            scopeObject: originalObject
        });
        //originalObject._taskService.completeTask(originalObject.taskID);
        originalObject.setContolButtonsACL();
        originalObject.closeForm();
    }

    private onAfterNCDCancel() {
        this.appObj.ApplicationBusinessObject.processObject.workflowStatus = "Cover Note Cancelled";
        this.addProcessHistoryRecord(this, "Cover Note Cancelled", "SELF", "SELF", "-");
        this.saveBusinessObject(this.completeAndClose);
    }

    private completeAndClose() {
        this._taskService.completeTask(this.taskID);
        this.closeForm();
    }

    private cloneAndCancelCoverNoteButtonClick() {
        this.copyCase(this.appObj.ApplicationBusinessObject.caseInfo.caseId);
        this.cancelCoverNoteButtonClick();
    }

    private closeCoverNoteButtonClick() {
        var dialogData = new CommentDialogData("CommonCommentDialogComponent", "app/bms/components/proposal/process/common.comment.dialog.module", "CommonCommentDialogModule", "Provide comments", "close", "fa fa-comment", this.commentCallBack);
        this.openCommentsDialog(dialogData);
    }

    private cloneAndCloseCoverNoteButtonClick() {
        this.copyCase(this.appObj.ApplicationBusinessObject.caseInfo.caseId);
        this.closeCoverNoteButtonClick();
    }

    private convertToPolicyButtonClick() {
        if (this.validateProposal()) {
            this.saveBusinessObject(this.moveToPolicyProcessingCallBackAfterSave);
        }
    }

    // Generic open user selection logic
    public openUserSelectionDialog(dialogName, registerResponse) {
        let lookup = new ModalInput();
        lookup.component = ["UserSelectionComponent", "app/bms/components/proposal/process/userselectiondialog.module", "UserSelectionDialogModule"];
        lookup.datainput = {
            dialogName: dialogName,
            userList: this.userList,
            orgDn: this.orgDN,
            registerResponse: registerResponse
        };
        if (dialogName === "rfi") {
            lookup.datainput.areCommentsMandatory = true;
        }
        lookup.outputCallback = this.userSelectionCallBack;
        lookup.parentCompPRMS = {
            comp: this
        };
        lookup.heading = "Select User";
        lookup.icon = "fa fa-link";
        lookup.containerRef = this.contentArea;
        this.dcl.openLookup(lookup);
    }

    // Generic open user selection callback logic
    private userSelectionCallBack(data, prms) {
        if (data.isDialogCancelled) {
            if (data.dialogName == "rfiAppeal") {
                prms.comp.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.isRFIByDC = "false";
                prms.comp.saveBusinessObject(null);
            }
            return;
        }
        let nextWStatus: string = "";
        switch (data.dialogName) {
            case "rfiAppeal":
                let currentWStatus = prms.comp.appObj.ApplicationBusinessObject.processObject.workflowStatus;
                nextWStatus = "";
                if (currentWStatus == "SMT Referral Approval") {
                    nextWStatus = "RFI SMT Approval";
                } else if (currentWStatus == "SMT Referral Review") {
                    nextWStatus = "RFI SMT Review";
                } else if (currentWStatus == "RHC Appeal Approval") {
                    nextWStatus = "RFI RHC Appeal Approval";
                } else {
                    nextWStatus = "RFI SMT Approval";
                }
                prms.comp.appObj.ApplicationBusinessObject.processObject.workflowStatus = nextWStatus;
                prms.comp.appObj.ApplicationBusinessObject.processObject.currentRoleDN = prms.comp.appObj.ApplicationBusinessObject.processObject.nextRoleDN;
                prms.comp.appObj.ApplicationBusinessObject.processObject.currentUserDN = prms.comp.appObj.ApplicationBusinessObject.processObject.nextUserDN;
                prms.comp.appObj.ApplicationBusinessObject.processObject.nextRoleDN = data.response.Success.nextRoleDN;
                prms.comp.appObj.ApplicationBusinessObject.processObject.nextUserDN = data.userDn;
                prms.comp.appObj.ApplicationBusinessObject.processObject.action = "RFI";
                prms.comp.appObj.ApplicationBusinessObject.processObject.targetType = "Role";
                prms.comp.appObj.ApplicationBusinessObject.processObject.target = data.response.Success.nextRoleDN.substring(3, data.response.Success.nextRoleDN.indexOf(","));
                prms.comp.appObj.ApplicationBusinessObject.processObject.workFlowTaskID = prms.comp.taskID;
                prms.comp.appObj.ApplicationBusinessObject.processObject.comments = data.comments;
                prms.comp.saveBusinessObject(prms.comp.callBackAfterCommentClose);
                break;
            case "appealedBUSMT":
                /**MD001 appending reason and remarks of bu smt form*/
                let busmtForm = prms.comp.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.appealBUSMTForm;
                let commentsInfo;
                if (busmtForm.remarks != "") {
                    commentsInfo = "Reason: " + busmtForm.reasonCode + "-" + busmtForm.reason + ", Comments: " + busmtForm.remarks;
                } else {
                    commentsInfo = "Reason: " + busmtForm.reasonCode + "-" + busmtForm.reason;
                }
                if (data.comments != "")
                    commentsInfo = commentsInfo + "; Comments:" + data.comments;
                /**MD001 */
                prms.comp.appObj.ApplicationBusinessObject.processObject.workflowStatus = "Appeal to BU SMT";
                prms.comp.appObj.ApplicationBusinessObject.processObject.nextRoleDN = data.response.Success.nextRoleDN;
                prms.comp.appObj.ApplicationBusinessObject.processObject.nextUserDN = data.userDn;
                prms.comp.appObj.ApplicationBusinessObject.processObject.action = "Appealed to BU SMT";
                prms.comp.appObj.ApplicationBusinessObject.processObject.targetType = "Role";
                prms.comp.appObj.ApplicationBusinessObject.processObject.target = data.response.Success.nextRoleDN.substring(3, data.response.Success.nextRoleDN.indexOf(","));
                prms.comp.appObj.ApplicationBusinessObject.processObject.workFlowTaskID = prms.comp.taskID;
                //prms.comp.appObj.ApplicationBusinessObject.processObject.comments = data.comments; //MD001 commented by MKU1
                prms.comp.appObj.ApplicationBusinessObject.processObject.comments = commentsInfo;//MD001				
                prms.comp.saveBusinessObject(prms.comp.callBackAfterCommentClose);
                break;
            case "approveAppeal":
                nextWStatus = "";
                let action: string = "Recommended for Appeal Approval";
                if (data.response.Success.nextRoleDN.indexOf("RHCREP") != -1) {
                    nextWStatus = "RHC Appeal Approval";
                    action = "Recommended for RHC Appeal Approval";
                } else if (data.response.Success.reviewIndex != "" && Number(data.response.Success.reviewIndex) > 0) {
                    nextWStatus = "SMT Referral Review";
                } else {
                    nextWStatus = "SMT Referral Approval";
                }
                prms.comp.appObj.ApplicationBusinessObject.processObject.workflowStatus = nextWStatus;
                prms.comp.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.SMTRole = prms.comp.appObj.ApplicationBusinessObject.processObject.nextRoleDN;
                prms.comp.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.SMTUser = prms.comp.appObj.ApplicationBusinessObject.processObject.nextUserDN;
                prms.comp.appObj.ApplicationBusinessObject.processObject.nextRoleDN = data.response.Success.nextRoleDN;
                prms.comp.appObj.ApplicationBusinessObject.processObject.nextUserDN = data.userDn;
                prms.comp.appObj.ApplicationBusinessObject.processObject.action = action;
                prms.comp.appObj.ApplicationBusinessObject.processObject.targetType = "Role";
                prms.comp.appObj.ApplicationBusinessObject.processObject.target = data.response.Success.nextRoleDN.substring(3, data.response.Success.nextRoleDN.indexOf(","));
                prms.comp.appObj.ApplicationBusinessObject.processObject.workFlowTaskID = prms.comp.taskID;
                prms.comp.appObj.ApplicationBusinessObject.processObject.comments = data.comments;
                prms.comp.saveBusinessObject(prms.comp.callBackAfterCommentClose);
                break;
            case "appealedtoRHC":
                prms.comp.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.RHCRole = prms.comp.appObj.ApplicationBusinessObject.processObject.nextRoleDN;
                prms.comp.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.RHCUser = prms.comp.appObj.ApplicationBusinessObject.processObject.nextUserDN;
                prms.comp.appObj.ApplicationBusinessObject.processObject.nextRoleDN = data.response.Success.nextRoleDN;
                prms.comp.appObj.ApplicationBusinessObject.processObject.nextUserDN = data.userDn;
                prms.comp.appObj.ApplicationBusinessObject.processObject.action = "Recommended for RHC Appeal Approval";
                prms.comp.appObj.ApplicationBusinessObject.processObject.targetType = "Role";
                prms.comp.appObj.ApplicationBusinessObject.processObject.target = data.response.Success.nextRoleDN.substring(3, data.response.Success.nextRoleDN.indexOf(","));
                prms.comp.appObj.ApplicationBusinessObject.processObject.workFlowTaskID = prms.comp.taskID;
                prms.comp.appObj.ApplicationBusinessObject.processObject.comments = data.comments;
                prms.comp.appObj.ApplicationBusinessObject.processObject.workflowStatus = "RHC Appeal Approval";
                prms.comp.saveBusinessObject(prms.comp.callBackAfterCommentClose);
                break;
            case "submit":
                prms.comp.appObj.ApplicationBusinessObject.processObject.workflowStatus = data.response.Success.nextWorkFlowStatus;
                prms.comp.appObj.ApplicationBusinessObject.caseInfo.status = data.response.Success.nextWorkFlowStatus;
                //Save BO
                prms.comp.nextRole = data.response.Success.nextRoleDN;
                prms.comp.nextUserDn = data.userDn;
                //Set BH user and role dn in Process Object
                prms.comp.appObj.ApplicationBusinessObject.processObject.caseHandlerRoleDn = data.response.Success.nextRoleDN;
                prms.comp.appObj.ApplicationBusinessObject.processObject.caseHandlerUserDn = data.userDn;
                prms.comp.appObj.ApplicationBusinessObject.processObject.comments = data.comments;
                prms.comp.saveBusinessObject(prms.comp.callBack2ForSubmitClick);
                break;
            case "conflict":
                prms.comp.appObj.ApplicationBusinessObject.processObject.workflowStatus = data.response.Success.nextWorkFlowStatus;
                prms.comp.appObj.ApplicationBusinessObject.caseInfo.status = data.response.Success.nextWorkFlowStatus;
                prms.comp.fillProcessHistoryInfo(prms.comp.appObj.ApplicationBusinessObject, "Channel conflicted", data.comments,
                    data.response.Success.nextRoleDN.substring(3, data.response.Success.nextRoleDN.indexOf(",")), "Role");
                //Save BO
                prms.comp.nextRole = data.response.Success.nextRoleDN;
                prms.comp.nextUserDn = data.userDn;
                //Set BH user and role dn in Process Object
                prms.comp.appObj.ApplicationBusinessObject.processObject.caseHandlerRoleDn = data.response.Success.nextRoleDN;
                prms.comp.appObj.ApplicationBusinessObject.processObject.caseHandlerUserDn = data.userDn;
                prms.comp.sendChannelConflcitMail();
                prms.comp.saveBusinessObject(prms.comp.callBack2ForConflictClick);
                break;
            case "blacklistFromBR":
                prms.comp.appObj.ApplicationBusinessObject.processObject.workflowStatus = data.response.Success.nextWorkFlowStatus;
                prms.comp.appObj.ApplicationBusinessObject.caseInfo.status = data.response.Success.nextWorkFlowStatus;
                prms.comp.fillProcessHistoryInfo(prms.comp.appObj.ApplicationBusinessObject, "Black listed", data.comments,
                    data.response.Success.nextRoleDN.substring(3, data.response.Success.nextRoleDN.indexOf(",")), "Role");
                //Save BO
                prms.comp.nextRole = data.response.Success.nextRoleDN;
                prms.comp.nextUserDn = data.userDn;
                //Set BH user and role dn in Process Object
                prms.comp.appObj.ApplicationBusinessObject.processObject.caseHandlerRoleDn = data.response.Success.nextRoleDN;
                prms.comp.appObj.ApplicationBusinessObject.processObject.caseHandlerUserDn = data.userDn;
                //send auto mail
                prms.comp.sendAutoEmailNotif(4, 1, prms.comp.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.blackListReason);
                prms.comp.saveBusinessObject(prms.comp.callBack2ForBlacklistFromBRClick);
                break;
            case "moveToQuotation":
                let oldState = prms.comp.appObj.ApplicationBusinessObject.processObject.workflowStatus;
                prms.comp.appObj.ApplicationBusinessObject.processObject.workflowStatus = data.response.Success.nextWorkFlowStatus;
                prms.comp.appObj.ApplicationBusinessObject.processObject.buttonAction = data.response.Success.buttonAction;
                prms.comp.appObj.ApplicationBusinessObject.processObject.reviewIndex = data.response.Success.reviewIndex;
                prms.comp.appObj.ApplicationBusinessObject.processObject.workFlowTaskID = prms.comp.taskID;
                prms.comp.fillProcessHistoryInfo(prms.comp.appObj.ApplicationBusinessObject, "Recommended to Quotation", data.comments,
                    data.response.Success.nextRoleDN.substring(3, data.response.Success.nextRoleDN.indexOf(",")), "Role");
                if (oldState == "Assessment" && prms.comp.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.HighRiskCus == 'Y') {
                    prms.comp.addProcessHistoryRecord(prms.comp, "High Risk Customer checked.", "SELF", "SELF", prms.comp.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.HighRiskCusComments);
                }
                //Save BO
                prms.comp.appObj.ApplicationBusinessObject.processObject.nextRoleDN = data.response.Success.nextRoleDN;
                prms.comp.appObj.ApplicationBusinessObject.processObject.nextUserDN = data.userDn;
                prms.comp.saveBusinessObject(prms.comp.callBack2ForMoveToQuotationClick);
                break;
            case "moveToPolicyProcessing":
                prms.comp.appObj.ApplicationBusinessObject.processObject.workflowStatus = data.response.Success.nextWorkFlowStatus;
                prms.comp.appObj.ApplicationBusinessObject.processObject.buttonAction = data.response.Success.buttonAction;
                prms.comp.appObj.ApplicationBusinessObject.processObject.reviewIndex = data.response.Success.reviewIndex;
                prms.comp.appObj.ApplicationBusinessObject.processObject.workFlowTaskID = prms.comp.taskID;
                prms.comp.fillProcessHistoryInfo(prms.comp.appObj.ApplicationBusinessObject, "Recommended to policy processing", data.comments,
                    data.response.Success.nextRoleDN.substring(3, data.response.Success.nextRoleDN.indexOf(",")), "Role");

                if (prms.comp.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.AMLCDDCheck == 'true') {
                    prms.comp.addProcessHistoryRecord(prms.comp, "AML CDD checked.", "SELF", "SELF", prms.comp.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.AMLCDDComments);
                }

                //Save BO
                prms.comp.appObj.ApplicationBusinessObject.processObject.nextRoleDN = data.response.Success.nextRoleDN;
                prms.comp.appObj.ApplicationBusinessObject.processObject.nextUserDN = data.userDn;
                prms.comp.saveBusinessObject(prms.comp.callBack2ForMoveToPolicyProcessingClick);
                break;
            //VK012
            case "moveToReceipting":
                prms.comp.appObj.ApplicationBusinessObject.processObject.workflowStatus = data.response.Success.nextWorkFlowStatus;
                prms.comp.appObj.ApplicationBusinessObject.processObject.buttonAction = data.response.Success.buttonAction;
                prms.comp.appObj.ApplicationBusinessObject.processObject.reviewIndex = data.response.Success.reviewIndex;
                prms.comp.appObj.ApplicationBusinessObject.processObject.workFlowTaskID = prms.comp.taskID;
                prms.comp.fillProcessHistoryInfo(prms.comp.appObj.ApplicationBusinessObject, "Recommended to Receipting", data.comments,
                    data.response.Success.nextRoleDN.substring(3, data.response.Success.nextRoleDN.indexOf(",")), "Role");

                if (prms.comp.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.AMLCDDCheck == 'true') {
                    prms.comp.addProcessHistoryRecord(prms.comp, "Moved to Receipting.", "SELF", "SELF", prms.comp.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.AMLCDDComments);
                }

                //Save BO
                prms.comp.appObj.ApplicationBusinessObject.processObject.nextRoleDN = data.response.Success.nextRoleDN;
                prms.comp.appObj.ApplicationBusinessObject.processObject.nextUserDN = data.userDn;
                prms.comp.saveBusinessObject(prms.comp.callBack2ForMoveToReceiptingClick);
                break;

            //VK012 END
            case "moveToCoverNoteProcessing":
                prms.comp.appObj.ApplicationBusinessObject.processObject.workflowStatus = data.response.Success.nextWorkFlowStatus;
                prms.comp.appObj.ApplicationBusinessObject.processObject.buttonAction = data.response.Success.buttonAction;
                prms.comp.appObj.ApplicationBusinessObject.processObject.reviewIndex = data.response.Success.reviewIndex;
                prms.comp.appObj.ApplicationBusinessObject.processObject.workFlowTaskID = prms.comp.taskID;
                prms.comp.fillProcessHistoryInfo(prms.comp.appObj.ApplicationBusinessObject, "Recommended to cover note processing", data.comments,
                    data.response.Success.nextRoleDN.substring(3, data.response.Success.nextRoleDN.indexOf(",")), "Role");
                if (prms.comp.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.AMLCDDCheck == 'true') {
                    prms.comp.addProcessHistoryRecord(prms.comp, "AML CDD checked.", "SELF", "SELF", prms.comp.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.AMLCDDComments);
                }
                //Save BO
                prms.comp.appObj.ApplicationBusinessObject.processObject.nextRoleDN = data.response.Success.nextRoleDN;
                prms.comp.appObj.ApplicationBusinessObject.processObject.nextUserDN = data.userDn;
                prms.comp.saveBusinessObject(prms.comp.callBack2ForMoveToPolicyProcessingClick);
                break;
            case "refferal":
                prms.comp.appObj.ApplicationBusinessObject.processObject.workflowStatus = data.response.Success.nextWorkFlowStatus;
                prms.comp.appObj.ApplicationBusinessObject.processObject.buttonAction = data.response.Success.buttonAction;
                prms.comp.appObj.ApplicationBusinessObject.processObject.reviewIndex = data.response.Success.reviewIndex;
                prms.comp.appObj.ApplicationBusinessObject.processObject.workFlowTaskID = prms.comp.taskID;
                prms.comp.fillProcessHistoryInfo(prms.comp.appObj.ApplicationBusinessObject, "Recommended to Quotation", data.comments,
                    data.response.Success.nextRoleDN.substring(3, data.response.Success.nextRoleDN.indexOf(",")), "Role");
                //Save BO
                prms.comp.appObj.ApplicationBusinessObject.processObject.nextRoleDN = data.response.Success.nextRoleDN;
                prms.comp.appObj.ApplicationBusinessObject.processObject.nextUserDN = data.userDn;
                prms.comp.saveBusinessObject(prms.comp.callBack2ForApproveClick);
                break;
            case "rfi":
                switch (prms.comp.appObj.ApplicationBusinessObject.processObject.workflowStatus) {

                    case "Refferal Review":
                        prms.comp.appObj.ApplicationBusinessObject.processObject.workflowStatus = "RFI Review";
                        break;

                    case "Refferal Approval":
                        prms.comp.appObj.ApplicationBusinessObject.processObject.workflowStatus = "RFI Approval";
                        break;
                    case "RHC Referral Approval":
                        prms.comp.appObj.ApplicationBusinessObject.processObject.workflowStatus = "RFI RHC Approval";
                        break;

                    case "Quotation":
                        prms.comp.appObj.ApplicationBusinessObject.processObject.workflowStatus = "RFI Quotation";
                        break;

                    case "Policy Processing":
                        prms.comp.appObj.ApplicationBusinessObject.processObject.workflowStatus = "RFI Policy Processing";
                        break;

                    //VK012
                    case "Pending Receipting":
                        prms.comp.appObj.ApplicationBusinessObject.processObject.workflowStatus = "RFI Pending Receipting";
                        break;
                    //VK012 END
                    case "Cover Note Processing":
                        prms.comp.appObj.ApplicationBusinessObject.processObject.workflowStatus = "RFI Cover Note Processing";
                        break;

                    case "Assessment Approval":
                        prms.comp.appObj.ApplicationBusinessObject.processObject.workflowStatus = "RFI Assessment Approval";
                        break;
                    case "Decline":
                        prms.comp.appObj.ApplicationBusinessObject.processObject.workflowStatus = "RFI Decline";
                        break;
                    case "Policy Pipeline":
                        prms.comp.appObj.ApplicationBusinessObject.processObject.workflowStatus = "RFI Policy Pipeline";
                        break;
                    case "Appeal to BU SMT":
                        prms.comp.appObj.ApplicationBusinessObject.processObject.workflowStatus = "RFI BU SMT";
                        break;
                }
                prms.comp.appObj.ApplicationBusinessObject.processObject.currentRoleDN = prms.comp.appObj.ApplicationBusinessObject.processObject.nextRoleDN;
                prms.comp.appObj.ApplicationBusinessObject.processObject.currentUserDN = "cn=" + prms.comp.userId + ",cn=organizational users," + prms.comp.orgDN;
                prms.comp.appObj.ApplicationBusinessObject.processObject.nextUserDN = data.userDn;
                prms.comp.appObj.ApplicationBusinessObject.processObject.workFlowTaskID = prms.comp.taskID;
                prms.comp.fillProcessHistoryInfo(prms.comp.appObj.ApplicationBusinessObject, "RFI", data.comments, data.userDn.substring(3, data.userDn.indexOf(",")), "User");
                prms.comp.saveBusinessObject(prms.comp.rfiCallBackAfterSave);
                break;
            case "Rerate Review":
                let roleToBeSent = prms.comp.appObj.ApplicationBusinessObject.caseInfo.handlingBranchId + "_" + prms.comp.appObj.ApplicationBusinessObject.caseInfo.lineOfBusiness + "_" + prms.comp.RNBusinessHandler;
                prms.comp.appObj.ApplicationBusinessObject.processObject.workflowStatus = "Rerate Review";
                prms.comp.appObj.ApplicationBusinessObject.processObject.nextRoleDN = "cn=" + roleToBeSent + ",cn=organizational roles," + prms.comp.orgDN;
                let nextRoleDN = prms.comp.appObj.ApplicationBusinessObject.processObject.nextRoleDN;
                prms.comp.appObj.ApplicationBusinessObject.processObject.workFlowTaskID = prms.comp.taskID;
                prms.comp.fillProcessHistoryInfo(prms.comp.appObj.ApplicationBusinessObject, "Sent To BH for Rerate Review", data.comments, nextRoleDN.substring(3, nextRoleDN.indexOf(",")), "Role");
                prms.comp.saveBusinessObject(prms.comp.rfiCallBackAfterSave);
                break;
            case "moveToPPOnCanCompleteYes":
                prms.comp.appObj.ApplicationBusinessObject.processObject.workflowStatus = data.response.Success.nextWorkFlowStatus;
                prms.comp.appObj.ApplicationBusinessObject.processObject.buttonAction = data.response.Success.buttonAction;
                prms.comp.appObj.ApplicationBusinessObject.processObject.reviewIndex = data.response.Success.reviewIndex;
                prms.comp.appObj.ApplicationBusinessObject.processObject.workFlowTaskID = prms.comp.taskID;
                prms.comp.fillProcessHistoryInfo(prms.comp.appObj.ApplicationBusinessObject, "Recommended to policy processing", data.comments,
                    data.response.Success.nextRoleDN.substring(3, data.response.Success.nextRoleDN.indexOf(",")), "Role");
                //Save BO
                prms.comp.appObj.ApplicationBusinessObject.processObject.nextRoleDN = data.response.Success.nextRoleDN;
                prms.comp.appObj.ApplicationBusinessObject.processObject.nextUserDN = data.userDn;
                prms.comp.saveBusinessObject(prms.comp.callBack2ForMoveToPolicyProcessingClick);
                break;
            case "moveToCNPOnCanCompleteYes":
                prms.comp.appObj.ApplicationBusinessObject.processObject.workflowStatus = data.response.Success.nextWorkFlowStatus;
                prms.comp.appObj.ApplicationBusinessObject.processObject.buttonAction = data.response.Success.buttonAction;
                prms.comp.appObj.ApplicationBusinessObject.processObject.reviewIndex = data.response.Success.reviewIndex;
                prms.comp.appObj.ApplicationBusinessObject.processObject.workFlowTaskID = prms.comp.taskID;
                prms.comp.fillProcessHistoryInfo(prms.comp.appObj.ApplicationBusinessObject, "Recommended to cover note processing", data.comments,
                    data.response.Success.nextRoleDN.substring(3, data.response.Success.nextRoleDN.indexOf(",")), "Role");
                //Save BO
                prms.comp.appObj.ApplicationBusinessObject.processObject.nextRoleDN = data.response.Success.nextRoleDN;
                prms.comp.appObj.ApplicationBusinessObject.processObject.nextUserDN = data.userDn;
                prms.comp.saveBusinessObject(prms.comp.callBack2ForMoveToPolicyProcessingClick);
                break;
            case "rerateReferral":
                prms.comp.appObj.ApplicationBusinessObject.processObject.workflowStatus = data.response.Success.nextWorkFlowStatus;
                prms.comp.appObj.ApplicationBusinessObject.processObject.buttonAction = data.response.Success.buttonAction;
                prms.comp.appObj.ApplicationBusinessObject.processObject.reviewIndex = data.response.Success.reviewIndex;
                prms.comp.appObj.ApplicationBusinessObject.processObject.workFlowTaskID = prms.comp.taskID;
                prms.comp.fillProcessHistoryInfo(prms.comp.appObj.ApplicationBusinessObject, "Sent for Rerate Referral", data.comments,
                    data.response.Success.nextRoleDN.substring(3, data.response.Success.nextRoleDN.indexOf(",")), "Role");
                //Save BO
                prms.comp.appObj.ApplicationBusinessObject.processObject.nextRoleDN = data.response.Success.nextRoleDN;
                prms.comp.appObj.ApplicationBusinessObject.processObject.nextUserDN = data.userDn;
                prms.comp.saveBusinessObject(prms.comp.callBack2ForMoveToQuotationClick);
                break;
        }
    }

    public openCommonCommentDialog(dialogName, heading) {
        let lookup = new ModalInput();
        lookup.component = ["CommonCommentDialogComponent", "app/bms/components/proposal/process/common.comment.dialog.module", "CommonCommentDialogModule"];
        lookup.datainput = {
            dialogName: dialogName,
            lobCode: this.appObj.ApplicationBusinessObject.caseInfo.lineOfBusiness
        };
        lookup.outputCallback = this.commonCommentDialogCallback;
        lookup.parentCompPRMS = {
            comp: this
        };
        lookup.heading = heading;
        lookup.icon = "fa fa-comment";
        lookup.containerRef = this.contentArea;
        this.dcl.openLookup(lookup);
    }

    private commonCommentDialogCallback(data, prms) {
        if (data.isDialogCancelled) {
            return;
        }
        prms.comp.appObj.ApplicationBusinessObject.processObject.comments = data.comments;
        switch (data.dialogName) {
            case "common-comment-posttop400":
                if (prms.comp.isExistingClient()) {
                    prms.comp.postToP400(prms.comp.appObj.ApplicationBusinessObject.caseInfo.caseId);
                }
                else {
                    prms.comp.postClientToP400(prms.comp.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.clientDetails.client.itemNo);
                }
                break;
            case "common-comment-referralapproval":
            // added below code for issue 1823 -- start
            case "common-comment-approval-quotation-referred": // End
                prms.comp.refferalApproveCallBackAfterSave(prms.comp);
                break;
            case "common-comment-onhold":
                prms.comp.callHoldResumeService(prms.comp.taskID, "Pending", prms.comp.holdSuccessHandler, prms.comp.holdErrorHandler);
                break;
            case "common-comment-resumed":
                prms.comp.callHoldResumeService(prms.comp.taskID, "Resume", prms.comp.resumeSuccessHandler, prms.comp.resumeErrorHandler);
                break;
            case "common-comment-resubmit-to-assessment":
                prms.comp.appObj.ApplicationBusinessObject.processObject.workflowStatus = "Assessment";
                prms.comp.appObj.ApplicationBusinessObject.caseInfo.status = "Assessment";
                prms.comp.nextRole = prms.comp.appObj.ApplicationBusinessObject.processObject.caseHandlerRoleDn;
                prms.comp.nextUserDn = prms.comp.appObj.ApplicationBusinessObject.processObject.caseHandlerUserDn;
                prms.comp.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.isTotalFormDisabled = "false";
                //Process History
                var userName = prms.comp.userFullName;
                var nextRoleInPH = prms.comp.appObj.ApplicationBusinessObject.processObject.caseHandlerRoleDn;
                prms.comp.appObj.ApplicationBusinessObject.processObject.action = "Moved to Assessment";
                prms.comp.appObj.ApplicationBusinessObject.processObject.targetType = "ROLE";
                prms.comp.appObj.ApplicationBusinessObject.processObject.target = nextRoleInPH.substring(3, nextRoleInPH.indexOf(","));;
                prms.comp.appObj.ApplicationBusinessObject.processObject.user = userName;
                prms.comp.appObj.ApplicationBusinessObject.processObject.comments = data.comments;
                prms.comp.saveBusinessObject(prms.comp.callBackAfterCommentClose);
                break;
            case "common-comment-pipeline":
                prms.comp.moveCaseToPipeline(prms.comp);
                break;
            case "common-comment-approval-uw":
                prms.comp.saveBusinessObject(prms.comp.callBackAfterCommentClose);
                break;
            case "common-comment-appealToSMT":
                prms.comp.appealToSMTAfterCommentClose(prms.comp);
                break;
            case "common-comment-approval-appeal":
                prms.comp.callBackAfterApprovalAppealCommentClose(prms.comp);
                break;
            // added code for 1823  -- start
            case "common-comment-approval-appeal-referred":
                prms.comp.callBackAfterApprovalBUSMTCommentClose(prms.comp);
                break; // End
            case "common-comment-rfi-approval-appeal":
                prms.comp.callBackAfterSMTRfiCommentClose(prms.comp);
                break;
            case "common-comment-resubmit-appeal":
                prms.comp.callBackAfterAppealResubmitCommentClose(prms.comp);
                break;
            case "common-comment-approval-appeal-decline":
                prms.comp.callBackAfterApprovalAppealDeclineCommentClose(prms.comp);
                break;
            case "common-comment-decline-appeal":
                prms.comp.declineAppealCallBackAfterSaveCommentClose(prms.comp);
                break;
            case "common-comment-move-to-quote-appeal":
                prms.comp.callBackAfterMoveToQuoteFromAppealCommentClose(prms.comp);
                break;
            case "common-comment-decline-approval-appeal":
                prms.comp.declineAppealCallBackAfterSaveCommentClose(prms.comp);
                break;
            case "common-comment-decline-reason":
                prms.comp.declineReasonCallBackAfterCommentClose(data, prms);
                break;
            case "common-comment-rerate-review":
                prms.comp.callBackAfterCommentCloseRR(data, prms);;
                break;
        }
    }

    private declineReasonCallBackAfterCommentClose(data, prms) {
        // To handle decline from AH to go to BH
        if (prms.comp.appObj.ApplicationBusinessObject.processObject.workflowStatus === "Assessment Approval") {
            prms.comp.appObj.ApplicationBusinessObject.processObject.workflowStatus = "Assessment";
            prms.comp.appObj.ApplicationBusinessObject.processObject.action = "Declined by AH";
            prms.comp.appObj.ApplicationBusinessObject.processObject.comments = data.comments;
        } else {
            if (prms.comp.appObj.ApplicationBusinessObject.processObject.nextRoleDN.indexOf("UW") != -1 && prms.comp.appObj.ApplicationBusinessObject.caseInfo.businessFunction != "RenewalRerate") {
                prms.comp.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.isDeclinedByUW = "true";
            } else {
                prms.comp.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.isDeclinedByUW = "false";
            }
            prms.comp.appObj.ApplicationBusinessObject.processObject.workflowStatus = "Decline";
            if (!prms.comp.isUserActive) {
                prms.comp.appObj.ApplicationBusinessObject.processObject.nextUserDN = "";
            } else {
                prms.comp.appObj.ApplicationBusinessObject.processObject.nextUserDN = "cn=" + prms.comp.appObj.ApplicationBusinessObject.caseInfo.accountHandler + ",cn=organizational users," + prms.comp.orgDN;
            }
            if (prms.comp.appObj.ApplicationBusinessObject.caseInfo.businessFunction == "RenewalRerate") {
                let roleToBeSent = prms.comp.appObj.ApplicationBusinessObject.caseInfo.handlingBranchId + "_" + prms.comp.appObj.ApplicationBusinessObject.caseInfo.lineOfBusiness + "_" + "AHRN";
                prms.comp.appObj.ApplicationBusinessObject.processObject.nextRoleDN = "cn="
                    + roleToBeSent + ",cn=organizational roles," + prms.comp.orgDN;

                prms.comp.fillProcessHistoryInfo(
                    prms.comp.appObj.ApplicationBusinessObject,
                    "Declined", data.comments,
                    roleToBeSent, "Role"
                );
            }
            else {
                prms.comp.appObj.ApplicationBusinessObject.processObject.nextRoleDN = "cn="
                    + prms.comp.appObj.ApplicationBusinessObject.processObject.accountHandlerRoleDn
                    + ",cn=organizational roles," + prms.comp.orgDN;

                prms.comp.fillProcessHistoryInfo(
                    prms.comp.appObj.ApplicationBusinessObject,
                    "Declined", data.comments,
                    prms.comp.appObj.ApplicationBusinessObject.processObject.accountHandlerRoleDn, "Role"
                );
            }



        }
        prms.comp.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.declineReasonCode = data.reasonCode;
        prms.comp.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.declineReasonDesc = data.reasonDesc;
        prms.comp.saveBusinessObject(prms.comp.callBackAfterCommentClose);
    }

    private callBackAfterCommentCloseRR(data, prms) {
        prms.comp.isRerateReviewed = true;
        prms.comp.isRerateReviewed ? prms.comp.appObj.ApplicationBusinessObject.processObject.workflowStatus = "Rerate Reviewed" : prms.comp.appObj.ApplicationBusinessObject.processObject.workflowStatus = "Assessment";
        prms.comp.appObj.ApplicationBusinessObject.processObject.nextRoleDN = "cn=" + prms.comp.RNAccountHandler + ",cn=organizational roles," + prms.comp.orgDN;
        prms.comp.appObj.ApplicationBusinessObject.processObject.workFlowTaskID = prms.comp.taskID;
        prms.comp.fillProcessHistoryInfo(prms.comp.appObj.ApplicationBusinessObject, "Sent Back To AH for Assessment", data.comments, prms.comp.RNAccountHandler, "Role");
        prms.comp.saveBusinessObject(prms.comp.rfiCallBackAfterSave);
    }

    public callHoldResumeService(taskId, action, successHandler, errorHandler) {
        this._cordysService.callCordysSoapService("HoldResumeHandler",
            "http://schemas.insurance.com/businessobject/1.0/",
            {
                TaskId: taskId,
                Action: action,
                BPMTrxnDetails: {
                    CaseId: this.appObj.ApplicationBusinessObject.caseInfo.caseId,
                    Comments: ""
                }
            },
            successHandler,
            errorHandler,
            true, {
                originalObject: this
            }
        );
    }

    public holdButtonClick() {
        this.openCommonCommentDialog("common-comment-onhold", "Enter Comments");
    }

    public holdSuccessHandler(response, prms) {
        // Hide all Buttons and display only Resume button, change the status to Pending
        prms.originalObject.createHoldResumeApprovalRecord("Pending", "On Hold", "", prms);
    }

    public holdErrorHandler(response, status, errorText, extraParams) {

    }

    public resumeButtonClick() {
        this.openCommonCommentDialog("common-comment-resumed", "Enter Comments");
    }

    public resumeSuccessHandler(response, prms) {
        // Show all Buttons and hide Resume button, change the status to Assessment
        prms.originalObject.createHoldResumeApprovalRecord("Assessment", "Resumed", "", prms);
    }

    public resumeErrorHandler(response, status, errorText, extraParams) { }
    // KA0001 Divek Added the condition to not to show alert for DPA product
    public moveToPolicyPipelineButtonClick() {
        this.checkQuotationAttached();
        if (this.appObj.ApplicationBusinessObject.caseInfo.lineOfBusiness != 'LIA' && this.appObj.ApplicationBusinessObject.caseInfo.lineOfBusiness != 'MED' && this.appObj.ApplicationBusinessObject.caseInfo.lineOfBusiness != 'ENG' && this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.contractType != 'EP' && this.appObj.ApplicationBusinessObject.caseInfo.lineOfBusiness != 'PA' && this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.isQuoteGenerated != "true" && this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.contractType != 'DPA') { //Redmine:2723- Optional for all Phase 2B products
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Please generate Quotation", -1));
            return;
        }
        this.saveBusinessObject(this.policyPipelineCallBackAfterSave);
    }
    // KA0001  END
    private checkQuotationAttached() {
        let TempAttachmentsArray = [];
        if (Array.prototype.isPrototypeOf(this.appObj.ApplicationBusinessObject.caseInfo.attachmentInfo.attachment)) {
            TempAttachmentsArray = this.appObj.ApplicationBusinessObject.caseInfo.attachmentInfo.attachment;
        }
        else {
            TempAttachmentsArray = [this.appObj.ApplicationBusinessObject.caseInfo.attachmentInfo.attachment];
        }
        if (TempAttachmentsArray.length == 0) {
            this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.isQuoteGenerated = "false";
        }
        else {
            let matchCfg = TempAttachmentsArray.filter((attachment) => attachment.attachmentName.includes("Quotation") || attachment.attachmentName.includes("Cover Letter") || attachment.attachmentName.includes("Quote"));
            if (matchCfg.length != 0) {
                this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.isQuoteGenerated = "true";
            }
            else {
                this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.isQuoteGenerated = "false";
            }
        }

    }

    private policyPipelineCallBackAfterSave(scopeObject) {
        scopeObject.openCommonCommentDialog("common-comment-pipeline", "Enter Comments");
    }

    private moveCaseToPipeline(scopeObject) {
        // Move case to Policy Pipeline (Will be done by BH); Set status, process history actions (No need to set nextUserDN)
        scopeObject.appObj.ApplicationBusinessObject.processObject.workflowStatus = "Policy Pipeline";
        scopeObject.appObj.ApplicationBusinessObject.processObject.action = "Moved to Pending Pipeline";
        scopeObject.appObj.ApplicationBusinessObject.processObject.target = scopeObject.userId;
        scopeObject.appObj.ApplicationBusinessObject.processObject.targetType = "User";
        scopeObject.appObj.ApplicationBusinessObject.processObject.workFlowTaskID = scopeObject.taskID;
        scopeObject.saveBusinessObject(scopeObject.callBackAfterCommentClose);
        scopeObject._caMailService.sendFacRIMail("UW", "").subscribe();
    }


    public createHoldResumeApprovalRecord(status: string, action: string, comments: string, prms: any) {
        prms.originalObject.appObj.ApplicationBusinessObject.caseInfo.status = status;
        prms.originalObject.appObj.ApplicationBusinessObject.processObject.workflowStatus = status;
        var newApprovalNode = new Approval();
        newApprovalNode.action = action;
        newApprovalNode.target = "SELF";
        newApprovalNode.targetType = "SELF";
        newApprovalNode.comment = prms.originalObject.appObj.ApplicationBusinessObject.processObject.comments;
        newApprovalNode.workflowTaskId = prms.originalObject.taskID;
        newApprovalNode.user = prms.originalObject.loggedInUser;
        if (action === "On Hold") {
            newApprovalNode.dueDate = prms.originalObject.taskDueDate;
        }
        prms.originalObject.appObj.ApplicationBusinessObject.caseInfo.approvalInfo.addItem(newApprovalNode);
        prms.originalObject.saveBusinessObject();
        prms.originalObject.setContolButtonsACL();
        if (action === "Resumed") {
            // Fire Get Task to get updated due date
            prms.originalObject.getTaskDetails();
        }
    }

    // At AH in Declined status ------------------- start---------------------------------------
    public appealToSMTButtonClick() {
        if (this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.isDeclinedByUW != "true") {
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "This action is not possible. Please contact Administrator", -1));
        }
        this.saveBusinessObject(this.appealToSMTAfterCommentClose);
    }

    public appealToSMTCallBackAfterSave(scopeObject) {
        scopeObject.openCommonCommentDialog("common-comment-appealToSMT", "Enter Comments");
    }

    public appealToSMTAfterCommentClose(originalObject) {
        // Fetch SMT from Approval Matrix
        if (originalObject.appObj.ApplicationBusinessObject.caseInfo.businessFunction == "Renewal") {
            originalObject.openAppealToBUSMTDialog(); //E1004
            //originalObject.callBMSWorkflowHelper("APPEAL_TO_BUSMT_RN", originalObject.callBackForAppealBUSMT);
        }
        else {
			/* old code 
			originalObject.callBMSWorkflowHelper("APPEAL_TO_BUSMT", originalObject.callBackForAppealBUSMT); */
            // added below code for issue 1823 -- start
            originalObject.openAppealToBUSMTDialog(); // End
        }
    }

    public callBackForAppealBUSMT(response, originalObject) {
        if (response.Success) {
            let responseNode = response.Success;
            if (responseNode.canComplete === "false") {
                // Open User selection popup to display users under BU SMT
                originalObject.userList = response.Success.userList;
                originalObject.openUserSelectionDialog("appealedBUSMT", response);
            } else {
                // Not possible
            }
        } else {
            // Display error Message
        }
    }

    // added below code for issue 1823 -- start
    public openAppealToBUSMTDialog() {
        let lookup = new ModalInput();
        lookup.component = ["AppealtoBUSMTComponent", "app/bms/components/proposal/process/appealtobusmt.module", "AppealtoBUSMTModule"];
        lookup.outputCallback = this.callBackforAppealToBUSMT;
        lookup.datainput = {
            applicationObj: this.appObj,
            application: "BMS",
            viewType: "LOOKUP"//MD002
        }
        lookup.parentCompPRMS = {
            comp: this
        };
        lookup.heading = "Business Consideration form";
        lookup.icon = "glyphicon glyphicon-comment";
        lookup.containerRef = this.contentArea;
        this.dcl.openLookup(lookup);
    }

    public callBackforAppealToBUSMT(data, prms) {
        //prms.comp.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.appealBUSMTForm = data.businessObject.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.appealBUSMTForm;
        prms.comp.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.appealBUSMTForm = data.busmtForm;
        prms.comp.saveBusinessObject(prms.comp.appealSuccessHandler);

        if (data.action == "appealtoBUSMT" && prms.comp.appObj.ApplicationBusinessObject.caseInfo.businessFunction != "Renewal") //E1004
            prms.comp.callBMSWorkflowHelper("APPEAL_TO_BUSMT", prms.comp.callBackForAppealBUSMT);
        if (data.action == "appealtoBUSMT" && prms.comp.appObj.ApplicationBusinessObject.caseInfo.businessFunction == "Renewal") //E1004
            prms.comp.callBMSWorkflowHelper("APPEAL_TO_BUSMT_RN", prms.comp.callBackForAppealBUSMT); //E1004
    }

    public appealSuccessHandler() { }
    // End

    // At AH in Declined status ------------------- end---------------------------------------

    // At BU SMT in Appeal to BU SMT status ------------------- start---------------------------------------
    public approveAppealButtonClick() {
        this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.isApprovedBySMT = "true";
        this.saveBusinessObject(this.approveAppealCallBackAfterSave);
    }

    public approveAppealCallBackAfterSave(originalObject) {
        if (originalObject.appObj.ApplicationBusinessObject.caseInfo.businessFunction == "Renewal") {
            originalObject.callBMSWorkflowHelper("APPROVE_APPEAL_RN", originalObject.callBackForApproveAppeal);
        }
        else originalObject.callBMSWorkflowHelper("APPROVE_APPEAL", originalObject.callBackForApproveAppeal);
    }

    public callBackForApproveAppeal(response, originalObject) {
        if (response.Success) {
            let responseNode = response.Success;
            if (responseNode.canComplete === "false") {
                // Open User selection popup to display users under BU SMT
                originalObject.userList = response.Success.userList;
                originalObject.openUserSelectionDialog("approveAppeal", response);
            } else if (responseNode.canComplete === "true") {

                originalObject.isUserAccountActive(originalObject.appObj.ApplicationBusinessObject.caseInfo.accountHandler);
                if (!originalObject.isUserActive) {
                    originalObject.openConfirmationPopUp("The selected AH is out of office. The task will be sent to the role. Do you want to continue?", "AHOutOfOfficeApproveAppeal");
                }
                else {
                    // added code for 1823  -- start
                    if (!originalObject.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.isReferredRiskUI)
                        originalObject.openCommonCommentDialog("common-comment-approval-appeal", "Enter Comments");
                    else {
                        originalObject.openCommonCommentDialog("common-comment-approval-appeal-referred", "Provide Reason of Approve Referred Risk"); // End
                    }

                    // commeting below code for issue and same code will execute in callBackAfterApprovalBUSMTCommentClose()
					/* 
					// RAA is within his limit; Create process history record, send email to UW; change the status to Appeal Approved
					originalObject.appObj.ApplicationBusinessObject.processObject.workflowStatus = "Appeal Approved";
					if (!originalObject.isUserActive) {
						originalObject.appObj.ApplicationBusinessObject.processObject.nextUserDN = "";
					} else {
						originalObject.appObj.ApplicationBusinessObject.processObject.nextUserDN = "cn=" + originalObject.appObj.ApplicationBusinessObject.caseInfo.accountHandler + ",cn=organizational users," + originalObject.orgDN;
					}
					originalObject.appObj.ApplicationBusinessObject.processObject.nextRoleDN = "cn=" 
						+ originalObject.appObj.ApplicationBusinessObject.processObject.accountHandlerRoleDn
						+ ",cn=organizational roles," + originalObject.orgDN;
					originalObject.appObj.ApplicationBusinessObject.processObject.action = "Appeal Approved by SMT";
					originalObject.appObj.ApplicationBusinessObject.processObject.target = originalObject.appObj.ApplicationBusinessObject.processObject.accountHandlerRoleDn;
					originalObject.appObj.ApplicationBusinessObject.processObject.targetType = "Role";
					originalObject.appObj.ApplicationBusinessObject.processObject.comments = "-";
					originalObject.appObj.ApplicationBusinessObject.processObject.workFlowTaskID = originalObject.taskID;
					originalObject.saveBusinessObject(originalObject.callBackAfterCommentClose); */
                }
            }
        }
        else {
            // Display error message
            originalObject._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Failed to fetch BU SMT role from Approval matrix. Please contact Administrator for more inforamtion", -1));
        }
    }

    public declineAppealButtonClick() {
        this.saveBusinessObject(this.declineAppealCallBackAfterSave);
    }

    public declineAppealCallBackAfterSave(originalObject) {
        originalObject.isUserAccountActive(originalObject.appObj.ApplicationBusinessObject.caseInfo.accountHandler);
        if (!originalObject.isUserActive) {
            originalObject.openConfirmationPopUp("The selected AH is out of office. The task will be sent to the role. Do you want to continue?", "AHOutOfOfficeDeclineAppeal");
        }
        else {
            //AL002 START
            //originalObject.openCommonCommentDialog("common-comment-decline-appeal","Enter Comments");
            originalObject.openCommonCommentDialog("common-comment-decline-reason", "Provide reason for decline");
            //AL002 END
        }
    }

    public declineAppealCallBackAfterSaveCommentClose(originalObject) {
        // Assign the case back to AH
        originalObject.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.isApprovedBySMT = "false";
        originalObject.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.isRFIByDC = "false";
        originalObject.appObj.ApplicationBusinessObject.processObject.workflowStatus = "Decline";
        if (!originalObject.isUserActive) {
            originalObject.appObj.ApplicationBusinessObject.processObject.nextUserDN = "";
        } else {
            originalObject.appObj.ApplicationBusinessObject.processObject.nextUserDN = "cn=" + originalObject.appObj.ApplicationBusinessObject.caseInfo.accountHandler + ",cn=organizational users," + originalObject.orgDN;
        }
        originalObject.appObj.ApplicationBusinessObject.processObject.nextRoleDN = "cn=" + originalObject.appObj.ApplicationBusinessObject.processObject.accountHandlerRoleDn + ",cn=organizational roles," + originalObject.orgDN;
        originalObject.appObj.ApplicationBusinessObject.processObject.action = "Appeal Declined by SMT";
        originalObject.appObj.ApplicationBusinessObject.processObject.target = originalObject.appObj.ApplicationBusinessObject.processObject.accountHandlerRoleDn;
        originalObject.appObj.ApplicationBusinessObject.processObject.targetType = "Role";
        originalObject.appObj.ApplicationBusinessObject.processObject.workFlowTaskID = originalObject.taskID;
        originalObject.saveBusinessObject(originalObject.callBackAfterCommentClose);
    }
    // At BU SMT in Appeal to BU SMT status ------------------- end---------------------------------------

    // At SMT Approver in SMT Referral Approval status ------------------- start---------------------------------------
    public approvalAppealApproveButtonClick() {
        this.saveBusinessObject(this.callBackAfterApprovalAppealApprove);
    }

    public callBackAfterApprovalAppealApprove(originalObject) {
        if (originalObject.appObj.ApplicationBusinessObject.processObject.workflowStatus == "SMT Referral Review") {
            if (originalObject.appObj.ApplicationBusinessObject.caseInfo.businessFunction == "Renewal") {
                originalObject.callBMSWorkflowHelper("APPROVE_APPEAL_RN", originalObject.cBAReviewerApproveClick);
            }
            else originalObject.callBMSWorkflowHelper("APPROVE_APPEAL", originalObject.cBAReviewerApproveClick);
        } else {
            originalObject.isUserAccountActive(originalObject.appObj.ApplicationBusinessObject.caseInfo.accountHandler);
            if (!originalObject.isUserActive) {
                originalObject.openConfirmationPopUp("The selected AH is out of office. The task will be sent to the role. Do you want to continue?", "AHOutOfOfficeApprovalApproveAppeal");
            } else {
				/* old code 
				originalObject.openCommonCommentDialog("common-comment-approval-appeal","Enter Comments"); */
                // added code for issue 1823.
                if (!originalObject.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.isReferredRiskUI)
                    originalObject.openCommonCommentDialog("common-comment-approval-appeal", "Enter Comments");
                else
                    originalObject.openCommonCommentDialog("common-comment-approval-appeal-referred", "Provide Reason of Approve Referred Risk");
                // End
            }
        }
    }

    private cBAReviewerApproveClick(response, scopeObject) {
        // Must be RHCREP role
        if (response.Success) {
            let responseNode = response.Success;
            if (responseNode.canComplete === "false") {
                // Open User selection popup to display users under BU SMT
                scopeObject.userList = response.Success.userList;
                scopeObject.openUserSelectionDialog("appealedtoRHC", response);
            } else {
                // Not possible
            }
        } else {
            scopeObject._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, response.Fault.FaultString, -1));
        }
    }


    public callBackAfterApprovalAppealCommentClose(originalObject) {
        let smtRole: string = originalObject.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.SMTRole;
        originalObject.appObj.ApplicationBusinessObject.processObject.action = "Appeal Approved by HM";
        originalObject.appObj.ApplicationBusinessObject.processObject.target = originalObject.appObj.ApplicationBusinessObject.processObject.accountHandlerRoleDn;
        originalObject.appObj.ApplicationBusinessObject.processObject.targetType = "Role";
        originalObject.appObj.ApplicationBusinessObject.processObject.workFlowTaskID = originalObject.taskID;
        if (!originalObject.isUserActive) {
            originalObject.appObj.ApplicationBusinessObject.processObject.nextUserDN = "";
        } else {
            originalObject.appObj.ApplicationBusinessObject.processObject.nextUserDN = "cn=" + originalObject.appObj.ApplicationBusinessObject.caseInfo.accountHandler + ",cn=organizational users," + originalObject.orgDN;
        }
        originalObject.appObj.ApplicationBusinessObject.processObject.nextRoleDN = "cn=" + originalObject.appObj.ApplicationBusinessObject.processObject.accountHandlerRoleDn + ",cn=organizational roles," + originalObject.orgDN;
        originalObject.appObj.ApplicationBusinessObject.processObject.workflowStatus = "Appeal Approved by HM";
        originalObject.saveBusinessObject(originalObject.callBackAfterCommentClose);
    }

    // Added code for 1823 -- start
    public callBackAfterApprovalBUSMTCommentClose(originalObject) {
        // RAA is within his limit; Create process history record, send email to UW; change the status to Appeal Approved
        originalObject.appObj.ApplicationBusinessObject.processObject.workflowStatus = "Appeal Approved";
        if (!originalObject.isUserActive) {
            originalObject.appObj.ApplicationBusinessObject.processObject.nextUserDN = "";
        } else {
            originalObject.appObj.ApplicationBusinessObject.processObject.nextUserDN = "cn=" + originalObject.appObj.ApplicationBusinessObject.caseInfo.accountHandler + ",cn=organizational users," + originalObject.orgDN;
        }
        originalObject.appObj.ApplicationBusinessObject.processObject.nextRoleDN = "cn="
            + originalObject.appObj.ApplicationBusinessObject.processObject.accountHandlerRoleDn
            + ",cn=organizational roles," + originalObject.orgDN;
        originalObject.appObj.ApplicationBusinessObject.processObject.action = "Appeal Approved by SMT";
        originalObject.appObj.ApplicationBusinessObject.processObject.target = originalObject.appObj.ApplicationBusinessObject.processObject.accountHandlerRoleDn;
        originalObject.appObj.ApplicationBusinessObject.processObject.targetType = "Role";
		/* Added code for 1823.
		originalObject.appObj.ApplicationBusinessObject.processObject.comments = "-"; */
        originalObject.appObj.ApplicationBusinessObject.processObject.comments = originalObject.appObj.ApplicationBusinessObject.processObject.comments;
        originalObject.appObj.ApplicationBusinessObject.processObject.workFlowTaskID = originalObject.taskID;
        originalObject.saveBusinessObject(originalObject.callBackAfterCommentClose);
    }
    // End

    public approvalAppealDeclineButtonClick() {
        this.saveBusinessObject(this.callBackAfterApprovalAppealDecline);
    }

    public callBackAfterApprovalAppealDecline(originalObject) {
        //AL002 START
        //originalObject.openCommonCommentDialog("common-comment-approval-appeal-decline","Enter Comments");
        originalObject.openCommonCommentDialog("common-comment-decline-reason", "Provide reason for decline");
        //AL002 END
    }

    public callBackAfterApprovalAppealDeclineCommentClose(originalObject) {
        let smtRole: string = originalObject.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.SMTRole;
        originalObject.appObj.ApplicationBusinessObject.processObject.workflowStatus = "Appeal Declined";
        originalObject.appObj.ApplicationBusinessObject.processObject.nextRoleDN = smtRole;
        originalObject.appObj.ApplicationBusinessObject.processObject.action = "Appeal Declined by HM";
        originalObject.appObj.ApplicationBusinessObject.processObject.target = smtRole.substring(3, smtRole.indexOf(","));
        originalObject.appObj.ApplicationBusinessObject.processObject.targetType = "Role";
        originalObject.appObj.ApplicationBusinessObject.processObject.workFlowTaskID = originalObject.taskID;
        originalObject.saveBusinessObject(originalObject.callBackAfterCommentClose);
    }

    public approvalAppealRFIButtonClick() {
        this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.isRFIByDC = "true";
        this.saveBusinessObject(this.callBackAfterSMTRfiCommentClose);
    }

    public callBackAfterSMTRFI(originalObject) {
        originalObject.openCommonCommentDialog("common-comment-rfi-approval-appeal", "Enter Comments");
    }

    public callBackAfterSMTRfiCommentClose(originalObject) {
        if (originalObject.appObj.ApplicationBusinessObject.caseInfo.businessFunction == "Renewal") {
            originalObject.callBMSWorkflowHelper("RFI_APPEAL_RN", originalObject.callBackForRFIAppeal);
        }
        else originalObject.callBMSWorkflowHelper("RFI_APPEAL", originalObject.callBackForRFIAppeal);
    }

    public callBackForRFIAppeal(response, originalObject) {
        if (response.Success) {
            let responseNode: any = response.Success;
            if (responseNode.canComplete === "false") {
                originalObject.userList = response.Success.userList;
                originalObject.openUserSelectionDialog("rfiAppeal", response);
            } else {
                // Not possible scenario
            }
        } else {
            // Display error message
            originalObject._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Failed to fetch UW SMT role from Approval matrix. Please contact Administrator for more inforamtion", -1));
        }
    }
    // At SMT Approver in SMT Referral Approval status ------------------- start---------------------------------------

    // Resubmit by UW SMT --------------------starts here---------------------------
    public resubmitAppealRFIButtonClick() {
        this.saveBusinessObject(this.callBackAfterAppealResubmit);
    }

    public callBackAfterAppealResubmit(originalObject) {
        originalObject.openCommonCommentDialog("common-comment-resubmit-appeal", "Enter Comments");
    }

    public callBackAfterAppealResubmitCommentClose(originalObject) {
        let nextRole: string = originalObject.appObj.ApplicationBusinessObject.processObject.currentRoleDN;
        let currentWStatus: string = originalObject.appObj.ApplicationBusinessObject.processObject.workflowStatus;
        let nextWStatus: string = "SMT Referral Approval";
        switch (currentWStatus) {
            case "RFI SMT Approval":
                nextWStatus = "SMT Referral Approval";
                break;
            case "RFI SMT Review":
                nextWStatus = "SMT Referral Review";
                break;
            case "RFI RHC Appeal Approval":
                nextWStatus = "RHC Appeal Approval";
                break;
        }
        originalObject.appObj.ApplicationBusinessObject.processObject.workflowStatus = nextWStatus;
        originalObject.appObj.ApplicationBusinessObject.processObject.action = "Resubmitted";
        originalObject.appObj.ApplicationBusinessObject.processObject.target = nextRole.substring(3, nextRole.indexOf(","));
        originalObject.appObj.ApplicationBusinessObject.processObject.targetType = "Role";
        originalObject.appObj.ApplicationBusinessObject.processObject.workFlowTaskID = originalObject.taskID;
        originalObject.appObj.ApplicationBusinessObject.processObject.nextRoleDN = nextRole;
        originalObject.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.isRFIByDC = "false";
        originalObject.saveBusinessObject(originalObject.callBackAfterCommentClose);
    }
    // Resubmit by UW SMT --------------------ends here---------------------------

    public declineAppealFromApprovalButtonClick() {
        this.saveBusinessObject(this.callBackAfterDeclineAppealApproval);
    }

    public callBackAfterDeclineAppealApproval(originalObject) {
        originalObject.isUserAccountActive(originalObject.appObj.ApplicationBusinessObject.caseInfo.accountHandler);
        if (!originalObject.isUserActive) {
            originalObject.openConfirmationPopUp("The selected AH is out of office. The task will be sent to the role. Do you want to continue?", "AHOutOfOfficeDeclineAppealApproval");
        }
        else {
            //AL002 START
            //originalObject.openCommonCommentDialog("common-comment-decline-approval-appeal","Enter Comments");
            originalObject.openCommonCommentDialog("common-comment-decline-reason", "Provide reason for decline");
            //AL002 END
        }
    }

    public moveToQuoteFromAppealButtonClick() {

        //GA001 START - MYS-2018-0597		
        this._caMailService.sendFacRIMail("FACRI", "").subscribe();
        //GA001 End

        this.saveBusinessObject(this.callBackAfterMoveToQuoteFromAppeal);
    }

    public callBackAfterMoveToQuoteFromAppeal(originalObject) {
        originalObject.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.isDeclinedByUW = "false";
        originalObject.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.isApprovedBySMT = "false";
        originalObject.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.isRFIByDC = "false";
        originalObject.openCommonCommentDialog("common-comment-move-to-quote-appeal", "Enter Comments");
    }

    public callBackAfterMoveToQuoteFromAppealCommentClose(originalObject) {
        originalObject.appObj.ApplicationBusinessObject.processObject.workflowStatus = "Quotation";
        originalObject.appObj.ApplicationBusinessObject.processObject.action = "Submitted to Quotation";
        originalObject.appObj.ApplicationBusinessObject.processObject.target = originalObject.appObj.ApplicationBusinessObject.processObject.caseHandlerRoleDn.substring(3, originalObject.appObj.ApplicationBusinessObject.processObject.caseHandlerRoleDn.indexOf(","));
        originalObject.appObj.ApplicationBusinessObject.processObject.targetType = "Role";
        originalObject.appObj.ApplicationBusinessObject.processObject.workFlowTaskID = originalObject.taskID;
        originalObject.appObj.ApplicationBusinessObject.processObject.nextRoleDN = originalObject.appObj.ApplicationBusinessObject.processObject.caseHandlerRoleDn;
        originalObject.saveBusinessObject(originalObject.callBackAfterCommentClose);
    }

    public validateForsubmit() {
        return true;
    }

    private callButtonClickFunction(buttonClickFunc, buttonId) {
        BMSConstants.setMovingState(buttonId);
        this[buttonClickFunc](buttonId);
    }

    private startApprovalProcess() {
        this._bmsUtilService.startApprovalWorkflow(this.appObj.ApplicationBusinessObject.caseInfo.caseId, this.nextRole, this.nextUserDn).subscribe((data) => this.startApprovalSuccessHandler());
    }

    private startApprovalSuccessHandler() {
        ProgressBarComponent.hide();
        this.closeForm();
    }

    private startApprovalErrorHandler(response, status, errorText, extraParams) { }

    private callBMSWorkflowHelper(buttonAction: string, callBackForBMSHelper) {
        this._cordysService.callCordysSoapService("BMSWorkflowHelper",
            "http://schemas.insurance.com/businessobject/1.0/",
            this.getBMSWorkflowHelperParams(buttonAction),
            this.BMSWorkflowHelperSuccessHandler,
            this.BMSWorkflowHelperErrorHandler,
            true, {
                originalObject: this,
                callBackFuncton: callBackForBMSHelper
            });
    }

    private getBMSWorkflowHelperParams(buttonAction) {
        if (BMSConstants.getBMSHeaderInfo().isSimplifiedProcess != 'Y') {
            return {
                "workFlowButtonAction": buttonAction,
                "caseId": this.appObj.ApplicationBusinessObject.caseInfo.caseId
            }
        }
        else {
            return {
                "workFlowButtonAction": buttonAction,
                "caseId": this.appObj.ApplicationBusinessObject.caseInfo.caseId,
                "isSimplifiedProcess": "Y"
            }
        }

    }

    private BMSWorkflowHelperSuccessHandler(data, scopeObject) {
        //VK012
        if (data.Success != null && data.Success.nextRoleDN == "" && (data.Success.buttonAction != "RenewalRerate" && scopeObject.originalObject.appObj.ApplicationBusinessObject.caseInfo.status != 'Assessment') && data.Success.canComplete != "true") {
            ProgressBarComponent.hide();
            scopeObject.originalObject._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Failed to fetch next role. Please contact Administrator for more inforamtion", -1));
            return;
        }
        //VK012
        scopeObject.callBackFuncton(data, scopeObject.originalObject);
    }

    private BMSWorkflowHelperErrorHandler(response, status, errorText, extraParams) {
        console.error("Error while calling the BMS Work flow Helper");
    }

    // BIRT Report Related Functions
    private attachReportToCase(report, paramObj) {
        this._cordysService.callCordysSoapService("AttachReportToCase",
            "http://schemas.insurance.com/businessobject/utility/1.0/",
            this.getattachReportToCaseParams(report, paramObj),
            this.getattachReportToCaseSuccessHandler,
            this.getattachReportToCaseErrorHandler,
            true, this)
    }

    private getattachReportToCaseParams(report, paramObj) {
        return {
            "CaseID": this.appObj.ApplicationBusinessObject.caseInfo.caseId,
            "ReportType": this.rpt_file,
            "PARAMS": paramObj,
            "isSimplifiedProcess": BMSConstants.TEMPOBJ.ISSIMPLIFIEDPROCESS
        }
    }

    private getattachReportToCaseSuccessHandler(data, scopeObject) {
        // Set the BO with new attacchment info in view 
        if (data.ApplicationBusinessObject) {
            scopeObject._appObjService.refreshCaseData(data.ApplicationBusinessObject.caseInfo).subscribe();
        }
        scopeObject._alertMsgService.add(new AlertMessage(AlertMessage.SUCCESS, "Report attached to Case", 3000));

    }

    private getattachReportToCaseErrorHandler(response, status, errorText, extraParams) {
        console.error("Error while calling the getattachReportToCase");
        this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error while attaching report to case", -1));
    }

    //E-Mail Management
    private openSendMailDialog() {
        if (BMSConstants.getBMSType() == BMSType.MiscCN) {
            let policyNo = BMSConstants.getBMSCaseInfo().policyNumber;
            this._appObjService.getRTCaseForPolicy(policyNo).subscribe(() => {
                this.openSendMailDialogMisc();
            });
        }
        else
            this.openSendMailDialogNB();
    }

    private openSendMailDialogMisc() {
        let caseInfo = BMSConstants.getRTBMSCaseInfo();
        let headerInfo = BMSConstants.getBMSHeaderInfo();
        let tempAttachmentsArray = caseInfo.attachmentInfoDisp.attachment;

        let input = {
            "attachments": tempAttachmentsArray,
            "caseId": caseInfo.caseId,
            "APP": this._appUtilService.getAppIdFromURL(),
            "PRODUCT": headerInfo.lineOfBusiness,
            "RISK": "",
            "ORIENTATION": "PORTRAIT",
            "WORKFLOW_STATUS": caseInfo.status
        };
        let lookup = new ModalInput();
        lookup.component = ["SendMailComponent", "app/common/components/utility/sendmail/sendmail.module", "SendMailModule"];
        lookup.outputCallback = this.sendMailCallBack;
        lookup.datainput = input;
        lookup.parentCompPRMS = {
            comp: this
        };
        lookup.heading = "Send Mail";
        lookup.icon = "fa fa-envelope-o";
        lookup.containerRef = this.contentArea;
        this.dcl.openLookup(lookup);
    }


    private openSendMailDialogNB() {
        let TempAttachmentsArray = [];
        if (Array.prototype.isPrototypeOf(this.appObj.ApplicationBusinessObject.caseInfo.attachmentInfo.attachment)) {
            TempAttachmentsArray = this.appObj.ApplicationBusinessObject.caseInfo.attachmentInfo.attachment;
        }
        else {
            TempAttachmentsArray = [this.appObj.ApplicationBusinessObject.caseInfo.attachmentInfo.attachment];
        }

        if (BMSConstants.getBMSType() == BMSType.MiscCN) {
            let policyNo = BMSConstants.getBMSCaseInfo().policyNumber;
            this._appObjService.getRTCaseForPolicy(policyNo).subscribe(() => {
                TempAttachmentsArray = BMSConstants.getRTBMSCaseInfo().attachmentInfoDisp.attachment;
            });
        }

        let input = {
            "attachments": TempAttachmentsArray,
            "caseId": this.appObj.ApplicationBusinessObject.caseInfo.caseId,
            "APP": this._appUtilService.getAppIdFromURL(),
            "PRODUCT": this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.lineOfBusiness,
            "RISK": "",
            "ORIENTATION": "PORTRAIT",
            "WORKFLOW_STATUS": this.appObj.ApplicationBusinessObject.caseInfo.status
        };
        let lookup = new ModalInput();
        lookup.component = ["SendMailComponent", "app/common/components/utility/sendmail/sendmail.module", "SendMailModule"];
        lookup.outputCallback = this.sendMailCallBack;
        lookup.datainput = input;
        lookup.parentCompPRMS = {
            comp: this
        };
        lookup.heading = "Send Mail";
        lookup.icon = "fa fa-envelope-o";
        lookup.containerRef = this.contentArea;
        this.dcl.openLookup(lookup);
    }

    private sendMailCallBack(data, prms) {
        prms.comp.addProcessHistoryRecord(prms.comp, "Mail Sent", data.emailTarget, data.emailTargetType, data.emailContent);
        prms.comp.saveBusinessObject(null);
    }

    //Utility
    private openConfirmationPopUp(Message: string, Action: string) {
        let inputObj = {
            "Message": Message,
            "Action": Action
        };
        let input = inputObj;
        let lookup = new ModalInput();
        lookup.component = ["Confirm", "app/common/components/utility/confirmmessage/confirm.module", "ConfirmModule"];
        lookup.datainput = input;
        lookup.outputCallback = this.openConfirmationPopUpCallBack;
        lookup.parentCompPRMS = {
            comp: this
        };
        lookup.heading = "User Confirmation";
        lookup.icon = "fa fa-hand-paper-o";
        lookup.containerRef = this.contentArea;
        this.dcl.openLookup(lookup);
    }

    private openConfirmationPopUpCallBack(data, prms) {
        if (data.value == 'Y') {
            // Logic for Yes
            switch (data.action) {

                case "blacklist":
                    prms.comp.blacklistFromBRButtonClick();
                    break;

                case "channelconflict":
                    prms.comp.conflictButtonClick();
                    break;

                case "AHOutOfOffice":
                    var dialogData = new CommentDialogData("CommonCommentDialogComponent", "app/bms/components/proposal/process/common.comment.dialog.module", "CommonCommentDialogModule", "Provide comments", "submitToAH", "fa fa-comment", prms.comp.commentCallBack);
                    prms.comp.openCommentsDialog(dialogData);
                    break;

                case "AHOutOfOfficeJPJConfirmation":
                    var dialogData = new CommentDialogData("CommonCommentDialogComponent", "app/bms/components/proposal/process/common.comment.dialog.module", "CommonCommentDialogModule", "Provide comments", "submitToAHForJPJFeedback", "fa fa-comment", prms.comp.commentCallBack);
                    prms.comp.openCommentsDialog(dialogData);
                    break;

                case "AHOutOfOfficeDecline":
                    if (prms.comp.appObj.ApplicationBusinessObject.processObject.workflowStatus == "Assessment Approval" || prms.comp.appObj.ApplicationBusinessObject.processObject.workflowStatus == "Refferal Approval") {
                        prms.comp.openCommonCommentDialog("common-comment-decline-reason", "Provide reason for decline");
                    } else {
                        var dialogData = new CommentDialogData("CommonCommentDialogComponent", "app/bms/components/proposal/process/common.comment.dialog.module", "CommonCommentDialogModule", "Provide comments", "decline", "fa fa-comment", prms.comp.commentCallBack);
                        prms.comp.openCommentsDialog(dialogData);
                    }
                    break;

                case "AHOutOfOfficeApproveAppeal":
                    // RAA is within his limit; Create process history record, send email to UW; change the status to Appeal Approved
                    prms.comp.appObj.ApplicationBusinessObject.processObject.workflowStatus = "Appeal Approved";
                    if (!prms.comp.isUserActive) {
                        prms.comp.appObj.ApplicationBusinessObject.processObject.nextUserDN = "";
                    } else {
                        prms.comp.appObj.ApplicationBusinessObject.processObject.nextUserDN = "cn=" + prms.comp.appObj.ApplicationBusinessObject.caseInfo.accountHandler + ",cn=organizational users," + prms.comp.orgDN;
                    }
                    prms.comp.appObj.ApplicationBusinessObject.processObject.nextRoleDN = "cn="
                        + prms.comp.appObj.ApplicationBusinessObject.processObject.accountHandlerRoleDn
                        + ",cn=organizational roles," + prms.comp.orgDN;
                    prms.comp.appObj.ApplicationBusinessObject.processObject.action = "Appeal Approved by SMT";
                    prms.comp.appObj.ApplicationBusinessObject.processObject.target = prms.comp.appObj.ApplicationBusinessObject.processObject.accountHandlerRoleDn;
                    prms.comp.appObj.ApplicationBusinessObject.processObject.targetType = "Role";
                    prms.comp.appObj.ApplicationBusinessObject.processObject.comments = "-";
                    prms.comp.appObj.ApplicationBusinessObject.processObject.workFlowTaskID = prms.comp.taskID;

                    // Notify UW and AH

                    prms.comp.saveBusinessObject(prms.comp.callBackAfterCommentClose);
                    break;

                case "AHOutOfOfficeDeclineAppealApproval":
                    prms.comp.openCommonCommentDialog("common-comment-decline-approval-appeal", "Enter Comments");
                    break;

                case "AHOutOfOfficeDeclineAppeal":
                    prms.comp.openCommonCommentDialog("common-comment-decline-appeal", "Enter Comments");
                    break;

                case "AHOutOfOfficeApprovalApproveAppeal":
                    prms.comp.openCommonCommentDialog("common-comment-approval-appeal", "Enter Comments");
                    break;

            }
        }
        else if ((data.value == 'N')) {
            // Logic for No
        }
        else {
            //Logic for Cancel
        }
    }

    //Letter Generation
    private openGenerateLetterDialog() {
        if (this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.VPMSProduct != 'Y') {
            this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.quotationDate = moment.utc(new Date()).format("YYYY-MM-DD");
        }
        ProgressBarComponent.show('Please wait...', { dialogSize: 'm', progressType: 'primary' });//Added new code to avoid multiple clicks from UI.
        this.saveBusinessObject(this.callBackAfterOpenGenerateLetterDialog);

    }
    private callBackAfterOpenGenerateLetterDialog(originalObject) {
        let input = {
            "CASEID": originalObject.appObj.ApplicationBusinessObject.caseInfo.caseId,
            "APP": originalObject._appUtilService.getAppIdFromURL(),
            "PRODUCT": originalObject.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.lineOfBusiness,
            "RISK": originalObject.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.contractType,
            "ORIENTATION": "PORTRAIT",
            "WORKFLOW_STATUS": originalObject.appObj.ApplicationBusinessObject.caseInfo.status,
            "APP_OBJ": originalObject.appObj,
            "selectBoxData": originalObject.getGenLtrSelectBoxData(),
            "isSimplifiedProcess": BMSConstants.TEMPOBJ.ISSIMPLIFIEDPROCESS

        };
        let lookup = new ModalInput();
        lookup.component = ["CaseReport", "app/common/components/utility/generatereport/generatereport.module", "GenerateReportModule"];
        lookup.outputCallback = originalObject.generateLetterCallBack;
        lookup.datainput = input;
        lookup.parentCompPRMS = {
            comp: originalObject
        };
        lookup.heading = "Case Reports";
        lookup.icon = "fa fa-file-text";
        lookup.containerRef = originalObject.contentArea;
        originalObject.dcl.openLookup(lookup);
        ProgressBarComponent.hide();//Added new code to avoid multiple clicks from UI.
    }

    private getGenLtrSelectBoxData() {
        let input = {
            "CoverType": []
        }
        let inputvalue = {
            "value": "",
            "description": ""
        }
        inputvalue.value = "Prime Mover";
        inputvalue.description = "Prime Mover / Other Vehicle";
        input.CoverType.push(inputvalue);
        if (this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.riskScreen == 'MCV') {
            inputvalue = {
                "value": "",
                "description": ""
            }
            var vechClass = this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.risks.motorMCV[0].vehicalClass != undefined ? this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.risks.motorMCV[0].vehicalClass : '';
            if (vechClass == 'GA' || vechClass == 'GC' || vechClass == 'AT' || vechClass == 'CT') {
                inputvalue.value = "Trailor";
                inputvalue.description = "Trailor";
                input.CoverType.push(inputvalue);
            }
        }
        let ltrSelectBoxinput = {
            "Confirmation Of Purchase Of Insurance JPJ_NewCoverNote": input
        }
        /*return JSON.parse("{\"Confirmation Of Purchase Of Insurance JPJ_NewCoverNote\":{\"CoverType\":[{\"value\":\"Prime Mover\",\"description\":\"Prime Mover\"},{\"value\":\"Trailor\",\"description\":\"Trailor\"}]}}"); */
        return ltrSelectBoxinput;
    }

    private generateLetterCallBack(data, prms) {
        if (prms.comp.isQuotationValidationNeeded(data.reportName)) {
            prms.comp.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.isQuoteGenerated = "true";
            if (prms.comp.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.VPMSProduct != 'Y') {
                prms.comp.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.quotationDate = moment.utc(new Date()).format("YYYY-MM-DD");
                if (prms.comp.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.riskScreen == 'MPV') {
                    prms.comp.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.risks.motorMPV.quotationDate = moment.utc(new Date()).format("YYYY-MM-DD");
                }
                else if (prms.comp.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.riskScreen == 'MCV') {
                    prms.comp.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.risks.motorMCV.quotationDate = moment.utc(new Date()).format("YYYY-MM-DD");

                }
            }
        }
        prms.comp.addProcessHistoryRecord(prms.comp, "Report " + "'" + data.reportName + "' Attached", "SELF", "SELF", "-");
        prms.comp._appObjService.saveData().subscribe();
    }

    private isQuotationValidationNeeded(reportName) {
        let returnVal = reportName.includes("Quotation") || reportName.includes("Cover Letter");
        return returnVal;
    }

    private copyCase(caseID) {
        if (BMSConstants.TEMPOBJ.ISSIMPLIFIEDPROCESS == 'Y') {
            this._cordysService.callCordysSoapService("CopySimplfiedProposalRequest", "http://schemas.insurance.com/simplifiedBMSBO/1.0/", { "caseId": caseID }, this.copyCaseSuccessHandler, this.copyCaseErrorHandler, true, this);
        } else {
            this._cordysService.callCordysSoapService("CopyBusinessObjectRequest", "http://schemas.insurance.com/businessobject/1.0/", { "caseId": caseID }, this.copyCaseSuccessHandler, this.copyCaseErrorHandler, true, this);
        }

    }

    private copyCaseSuccessHandler(data, scopeObject) {

        scopeObject._alertMsgService.add(new AlertMessage(AlertMessage.SUCCESS, "The Case has been copied as Draft with Case ID :" + data.success.ApplicationBusinessObject.caseInfo.caseId, 5000));
    }

    private copyCaseErrorHandler(response, status, errorText, scopeObject) {
        scopeObject._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error while copying Case", 5000));
    }



    private renewPolicyButtonClick() {
        if (this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.blackListIndicator === "true") {
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Cannot Proceed with Blacklisted Case.  Please uncheck Blacklist Indicator or Close the Case.", 5000));
            return;
        }
        if (!this.validateProposal()) {
            return;
        }
        ProgressBarComponent.show('Please wait..', { dialogSize: 'm', progressType: 'primary' });
        this.saveBusinessObject(this.callBackAfterrenewPolicyButtonClickSave);
    }

    private callBackAfterrenewPolicyButtonClickSave(originalObject) {
        if (originalObject.appObj.ApplicationBusinessObject.processObject.isRerateApprovedByUW && originalObject.appObj.ApplicationBusinessObject.processObject.isRerateApprovedByUW == "true") {
            ProgressBarComponent.hide();
            var dialogData = new CommentDialogData("CommonCommentDialogComponent", "app/bms/components/proposal/process/common.comment.dialog.module", "CommonCommentDialogModule", "Provide comments", "MR Comments", "fa fa-comment", originalObject.commentCallBackForRenew);
            originalObject.openCommentsDialog(dialogData);
        }
        else {
            originalObject.callBMSWorkflowHelper("RenewalRerate", originalObject.callBackForrenewPolicyButtonClick);
        }
    }

    private callBackForrenewPolicyButtonClick(response, originalObject) {
        ProgressBarComponent.hide();
        if (response.Success) {

            let responseNode = response.Success;
            if (responseNode.canComplete === "false") {
                // Open User selection popup to display users under BU SMT
                originalObject.userList = response.Success.userList;
                originalObject.openUserSelectionDialog("rerateReferral", response);
            } else if (responseNode.canComplete === "true") {
                // Call the posting service of renewal rerate
                //alert("Service call and close form");
                var dialogData = new CommentDialogData("CommonCommentDialogComponent", "app/bms/components/proposal/process/common.comment.dialog.module", "CommonCommentDialogModule", "Provide comments", "MR Comments", "fa fa-comment", originalObject.commentCallBackForRenew);
                originalObject.openCommentsDialog(dialogData);
            }
        } else {
            // Display error message
            originalObject._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Failed to fetch next role from Approval matrix. Please contact Administrator for more information", -1));
        }
    }

    private commentCallBackForRenew(data, prms) {
        if (data.isDialogCancelled) {
            return;
        }
        var localComments = data.comments;
        ProgressBarComponent.show('Please wait..', { dialogSize: 'm', progressType: 'primary' });
        prms.comp.renService.postRenewalRerate(prms.comp.appObj.ApplicationBusinessObject.caseInfo.caseId, "MR", prms.comp, data.comments).subscribe(
            (data) => prms.comp.moveToPolicyInforced(localComments)
        );
    }

    private sendToBHRR() {
        // if(!this.validateProposal()){
        // 	return;
        // }
        this.getRenewalWorkflowConfigForBH();
    }

    private getRenewalWorkflowConfigForBH() {
        let RNAccountHandlerResponse = this._cordysService.callCordysSoapService("GetXMLObject", "http://schemas.cordys.com/1.0/xmlstore",
            { key: "/com/msig/insurance/RenewalsWorkflowConfig.xml" }, null, null, false, this);
        RNAccountHandlerResponse.done((data) => this.getRNBusinessHandler(data))
    }

    private getRNBusinessHandler(data) {
        this.RNBusinessHandler = data.tuple.old.WorkflowConfigs.Rerate.BH;
        this.getListOfUsersUnderRole();
    }

    private getListOfUsersUnderRole() {
        this._cordysService.callCordysSoapService("GetUsersForBranchLOBAndRoleCode",
            "http://schemas.cordys.com/msig/masterdata/1.0",
            this.getListOfUsersUnderRoleParams(),
            this.getListOfUsersUnderRoleSuccessHandler,
            this.getListOfUsersUnderRoleErrorHandler,
            true, this)
    }

    private getListOfUsersUnderRoleParams() {
        return {
            "BRANCH_CODE": this.appObj.ApplicationBusinessObject.caseInfo.handlingBranchId,
            "LOB_CODE": this.appObj.ApplicationBusinessObject.caseInfo.lineOfBusiness,
            "ROLE_CODE": this.RNBusinessHandler,
            "APPLICATION": "BMS"
        };
    }

    private getListOfUsersUnderRoleSuccessHandler(data, scopeObject) {
        // Popup user selection dialog 
        scopeObject.openUserSelectionDialog("Rerate Review", data);
    }

    private getListOfUsersUnderRoleErrorHandler(response, status, errorText, extraParams) {
        console.error("Error while calling the GetUsersWorkedOnCase");
        extraParams.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error while calling the GetUsersWorkedOnCase", -1));
    }

    private submitToAHButtonClickRR() {
        if (!this.validateProposal()) {
            return;
        }
        this.getRenewalWorkflowConfig();
    }

    private getRenewalWorkflowConfig() {
        let RNAccountHandlerResponse = this._cordysService.callCordysSoapService("GetXMLObject", "http://schemas.cordys.com/1.0/xmlstore",
            { key: "/com/msig/insurance/RenewalsWorkflowConfig.xml" }, null, null, false, this);
        RNAccountHandlerResponse.done((data) => this.getRNAccountHandler(data))
    }

    private getRNAccountHandler(data) {
        this.RNAccountHandler = this.appObj.ApplicationBusinessObject.caseInfo.handlingBranchId + "_" + this.appObj.ApplicationBusinessObject.caseInfo.lineOfBusiness + "_" + data.tuple.old.WorkflowConfigs.Rerate.AH;
        this.RNBusinessHandler = data.tuple.old.WorkflowConfigs.Renewals.BH;
        this.openCommonCommentDialog("common-comment-rerate-review", "Enter Comments");
    }

    //Hold Cover for Renewals
    private holdCoverButtonClick() {
        var dialogData = new CommentDialogData("CommonCommentDialogComponent", "app/bms/components/proposal/process/common.comment.dialog.module", "CommonCommentDialogModule", "Provide comments", "holdCover", "fa fa-comment", this.commentCallBackForHoldCover);
        this.openCommentsDialog(dialogData);
    }

    private resumeCoverButtonClick() {
        this.appObj.ApplicationBusinessObject.caseInfo.status = this.appObj.ApplicationBusinessObject.caseInfo.caseobjectstatusBeforeHoldCover;
        this.appObj.ApplicationBusinessObject.processObject.workflowStatus = this.appObj.ApplicationBusinessObject.caseInfo.processobjectstatusBeforeHoldCover;
        //Process History
        var userName = this.userFullName;
        var userId = this.userId;
        var newApprovalNode = new Approval();
        newApprovalNode.target = "SELF";
        newApprovalNode.targetType = "SELF";
        newApprovalNode.user = userName;
        newApprovalNode.action = "Resume";
        newApprovalNode.comment = "";
        this.appObj.ApplicationBusinessObject.caseInfo.approvalInfo.addItem(newApprovalNode);
        //Save
        this.saveBusinessObject(this.callBackAfterResumeCover);
    }

    private callBackAfterResumeCover(originalObject) {
        originalObject.setContolButtonsACL();
        originalObject._alertMsgService.add(new AlertMessage(AlertMessage.SUCCESS, "Resume Successful", -1));
        originalObject.closeForm();
    }


    private deleteCasePolicyMapping() { //VK006 start
        let caseId = this.appObj.ApplicationBusinessObject.caseInfo.caseId;
        let policyNoOrg = this.appObj.ApplicationBusinessObject.caseInfo.policyNumberOrg;
        let policyNo = this.appObj.ApplicationBusinessObject.caseInfo.policyNumber;

        if (["Renewal", "RenewalRerate"].indexOf(this.appObj.ApplicationBusinessObject.caseInfo.businessFunction) >= 0 && caseId.length > 0 && policyNo.length > 0) {
            this.deleteMsigCasePolicyMapping(caseId, policyNo);
        } else if (this.appObj.ApplicationBusinessObject.caseInfo.businessFunction == "NewBusiness" && policyNoOrg != undefined && policyNoOrg.length > 0) {
            this.deleteMsigCasePolicyMapping(caseId, policyNoOrg);
        }
    }

    private deleteMsigCasePolicyMapping(caseId: string, policyNo: string) {
        this._cordysService.callCordysSoapService("UpdateMsigBmsRenewalPolicyCaseMapping", "http://schemas.opentext.com/msig/persistancedb/1.0", { "tuple": { "old": { "MSIG_BMS_RENEWAL_POLICY_CASE_MAPPING": { "CASE_ID": caseId, "POLICY_NO": policyNo } } } }, null, null, false, null);
    }//VK006 End

    private moveBackToAssessment() {
        this.openCommonCommentDialog("common-comment-resubmit-to-assessment", "Enter Comments");
    }

    public manuscriptMailHandler(isPosted) {
        this._caMailService.sendManuscriptMail(isPosted).subscribe();
    }

    private RSTButtonClick() {

        if (this.isRNFastTrack()) {

            this.confirmAppChange("This case will be renewed on same terms and posted to P400 directly. Do you want to continue?");
        }
        else {
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, this.getReasonForNotAllowingRNFastTrack(), -1));
        }

    }
    private confirmAppChange(message: string) {
        let inputObj = {
            "Message": message
        };
        let lookup = new ModalInput();
        lookup.component = ["Confirm", "app/common/components/utility/confirmmessage/confirm.module", "ConfirmModule"];
        lookup.datainput = inputObj;
        lookup.outputCallback = null;
        lookup.parentCompPRMS = {
            comp: this
        };
        lookup.heading = "User Confirmation";
        lookup.icon = "fa fa-hand-paper-o";
        lookup.containerRef = this.contentArea;
        this.dcl.openLookup(lookup).subscribe((data) => {
            this.goForRST(data);
        });

    }

    private goForRST(data) {
        if (data.data.value == 'Y') {

            /* if (this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.ccmOPSs.printQ == "" ) {
                this._alertMsgService.add( new AlertMessage( AlertMessage.ERROR, "Please fill all mandatory fields in CCM Parameters section. ", 10000 ) );                
            } else { */
            this.appObj.ApplicationBusinessObject.caseInfo.isPostedBySTP = 'Y';
            this.saveBusinessObject(this.postToP400RROnAfterSave);
            //}  

            /* //pku
            if ( this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.isSimplifiedProcess != "Y"){
                this.setCcmOpsFlag.emit( true );
            } //End
            */
        }
    }

    private isRNFastTrack() {
        let isRNFastTrack = true;
        let header = this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo;
        this.RIRequired = header.RIRequiredHeader;
        if ((header.isSimplifiedProcess != 'Y') && (header.isReferredRiskUI || header.CoInsurance == "Y" || this.RIRequired == "true" || header.isRiskEdited == "Y" || (AppUtil.isEmpty(header.effectiveDateOrg, false) == false && header.effectiveDate != header.effectiveDateOrg) || (AppUtil.isEmpty(header.endDateOrg, false) == false && header.endDate != header.endDateOrg))) {
            isRNFastTrack = false;
        }
        else if ((header.isSimplifiedProcess == 'Y') && (header.isReferredRiskUI || header.CoInsurance == "Y" || this.RIRequired == "true" || (AppUtil.isEmpty(header.effectiveDateOrg, false) == false && header.effectiveDate != header.effectiveDateOrg) || (AppUtil.isEmpty(header.endDateOrg, false) == false && header.endDate != header.endDateOrg))) {
            isRNFastTrack = false;
        }

        //GA004 START
        if (header.isHighRiskApplicable && header.highRiskIndicator == "true") {
            if (header.highRiskBNMIndicator == "B" || header.highRiskInternalIndicator == "B" || header.highRiskVehicleIndicator == "B" || header.highRiskLossRatioWDInd == "B" ||
                header.highRiskInsuredBNMInd == "B" || header.highRiskInsuredInternalInd == "B" || header.highRiskNomineeInternalInd == "B" || header.highRiskDriverInternalInd == "B") {
                isRNFastTrack = false;
            } else if (header.highRiskInternalIndicator == "A" || header.highRiskVehicleIndicator == "A"
                || header.highRiskLossRatioIndicator == "A" || header.highRiskInsuredInternalInd == "A"
                || header.highRiskNomineeInternalInd == "A" || header.highRiskDriverInternalInd == "A"
                || header.highRiskLossRatioWDInd == "A") {
                this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "<p> Header: Client is High Risk Indicator with Alert.</p>", 3000));
            }
        }
        //GA004 END

        return isRNFastTrack;
    }

    private getReasonForNotAllowingRNFastTrack() {
        let reason = "";
        let header = this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo;
        if (header.isReferredRiskUI) {
            reason = "STP not allowed for Referred Risk";
        }
        if (header.CoInsurance == "Y") {
            reason = "STP not allowed for policies with Coinsurance";
        }
        if (this.RIRequired == "true") {
            reason = "STP not allowed for policies with Reinsurance";
        }
        if ((AppUtil.isEmpty(header.effectiveDateOrg, false) == false && header.effectiveDate != header.effectiveDateOrg) || (AppUtil.isEmpty(header.endDateOrg, false) == false && header.endDate != header.endDateOrg)) {
            reason = "POI is modified.";
        }
        if (header.isRiskEdited == "Y") {
            reason = "Risk information modified.";
        }
        //GA004 START
        //BLOCK
        if (header.isHighRiskApplicable && header.highRiskIndicator == "true") {
            if (header.highRiskBNMIndicator == "B" || header.highRiskInternalIndicator == "B" || header.highRiskVehicleIndicator == "B" || header.highRiskLossRatioWDInd == "B" ||
                header.highRiskInsuredBNMInd == "B" || header.highRiskInsuredInternalInd == "B" || header.highRiskNomineeInternalInd == "B" || header.highRiskDriverInternalInd == "B") {
                reason = "<p> Header: Client is High Risk Indicator with Block.</p>";
            }
        }
        //GA004 END

        return reason;
    }

    private fastTrackHandler() {
        if (this.isRNFastTrack()) {
            this.appObj.ApplicationBusinessObject.caseInfo.isFastTrack = "Y";
            //this.saveBusinessObject(null);
        }
    }

    private confirmHRC() {
        let inputObj = {
            "Message": "Please ensure you have performed Client Risk Profile check (High Risk Customer) to comply with AMLCFT. Do you want to proceed?"
        };
        let lookup = new ModalInput();
        lookup.component = ["Confirm", "app/common/components/utility/confirmmessage/confirm.module", "ConfirmModule"];
        lookup.datainput = inputObj;
        lookup.outputCallback = null;
        lookup.parentCompPRMS = {
            comp: this
        };
        lookup.heading = "User Confirmation";
        lookup.icon = "fa fa-hand-paper-o";
        lookup.containerRef = this.contentArea;
        return this.dcl.openLookup(lookup);
    }

    private loadDispatchModes() {
        if (this.dispatchModes.length == 0) {
            this.populateDispatchMode();
        }
    }

    //Renewal Reminder 
    private sendRenewalReminder() {
        this._cordysService.callCordysSoapService("SendRenewalReminder",
            "http://schemas.insurance.com/businessobject/1.0/",
            this.sendRenewalReminderparams(),
            this.sendRenewalReminderSuccessHandler,
            this.sendRenewalReminderErrorHandler,
            false, this)
    }

    private sendRenewalReminderparams() {
        return {
            "CaseID": this.appObj.ApplicationBusinessObject.caseInfo.caseId
        }
    }

    private sendRenewalReminderSuccessHandler(data, scopeObject) {
        if (data.status.text != 'ERROR') {
            scopeObject._alertMsgService.add(new AlertMessage(AlertMessage.SUCCESS, "Renewal reminder sent to agent and client", 3000));
            scopeObject.addProcessHistoryRecord(scopeObject, "Reminder sent", data.mailids.text, "emailTo", "Renewal reminder sent successfully");
            scopeObject.saveBusinessObject(null);
        }
        else {
            scopeObject._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, data.message.text, -1));
        }

    }

    private sendRenewalReminderErrorHandler(response, status, errorText, extraParams) {
        extraParams._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error sending renewal reminder", -1));
    }
    //POD
    private podButtonClick() {
        //CMSEvents.SaveBOTrigger.next("");
        if (this.appObj.ApplicationBusinessObject.caseInfo.policyNumber != '' && this.appObj.ApplicationBusinessObject.caseInfo.policyNumber != undefined && this.appObj.ApplicationBusinessObject.caseInfo.policyNumber != '') {
            var StatisticsData = this._cordysService.callCordysSoapService("PolicyOnDemandProcess",
                "http://schemas.insurance.com/businessobject/1.0/", this.getPODRequest(), this.successOfPOD, this.errorHandlerPOD, false, this);
        } else {
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Policy on Demand is crated after the policy creation in P400", 3000));
        }
    }


    private getPODRequest() {
        return {
            "PolicyNumber": this.appObj.ApplicationBusinessObject.caseInfo.policyNumber,
            "LossDate": ApplicationUtilService.getFormattedDate(this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.effectiveDate, "YYYY-MM-DD", "YYYYMMDD"),
            "CaseID": this.appObj.ApplicationBusinessObject.caseInfo.caseId,
            "AppType": "BMS"
        }
    }
    private downloadPODpdf() {
        this.appObj.ApplicationBusinessObject.caseInfo = BMSConstants.getBMSCaseInfo();
        if (this.appObj.ApplicationBusinessObject.caseInfo.podattachment != undefined && this.appObj.ApplicationBusinessObject.caseInfo.podattachment.sLocationUrl != undefined) {
            this.downloadDocument(this.appObj.ApplicationBusinessObject.caseInfo.podattachment);
        } else {
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Policy Document is not attached to the Case", 2000));
        }
        //var podattachment = "MSIG_DEV_02/77111342/20170101/PL77111342201701010003.pdf";
        //this.downloadDocument(podattachment);
    }
    private downloadDocument(podattachment) {
        var responsePromise = this._cordysService.callCordysSoapService("GetDocumentWithContent", "http://schemas.cordys.com/ecm/integration/1.0", this.getDownLoadParameter(podattachment), this.documentDeleteSuccessHandler, this.errorHandlerPOD, false, { comp: this });
        //VK001 responsePromise.done((data) => this.getDownloadedLink(data));
    }
    public successHandler(data, scopeObject) {

    }
    // VK001 Passing empty instead of XML path
    private getDownLoadParameter(podattachment) {//podattachment
        // documentURL: podattachment.sLocationUrl,
        return {
            documentURL: podattachment.sLocationUrl,
            xmlStoreECMPropPath: ""
        }
    }
    // END of VK001

    // VK001 Security Fix 02/10/2018
    private documentDeleteSuccessHandler(data, prms) {
        var response = data.tuple.old.getDocumentWithContent.getDocumentWithContent.GetDocumentResponse;
        var downloadURL: string = response.DocumentContent.text;
        var fileName: string = downloadURL.substring(downloadURL.lastIndexOf("/") + 1);
        window.open("/" + downloadURL.replace(fileName, encodeURIComponent(fileName)));
        //let response = data.tuple.old.getDocumentWithContent.getDocumentWithContent.GetDocumentResponse;  
        setTimeout(() => {
            if (response != undefined && response.Folder != undefined && response.Folder != "" && response.DocumentName != undefined && response.DocumentName != "") {
                prms.comp._cordysService.callCordysSoapService("DeleteFileAttachment", "http://schemas.cordys.com/ecm/integration/1.0", { "filePath": response.Folder + "/" + response.DocumentName }, prms.comp.successHandler, prms.comp.errorHandler, true, null);
            }
        }, 6000);
    }
    //VK001 End

    getDownloadedLink(data) {
        var response = data.tuple.old.getDocumentWithContent.getDocumentWithContent.GetDocumentResponse;
        var downloadURL = response.DocumentContent.text;
        window.open("/" + downloadURL);
    }
    private successOfPOD(data, scopeObject) {
        if (data.status == "Success") {
            this.appObj.ApplicationBusinessObject.caseInfo = BMSConstants.getBMSCaseInfo();
        } else {
            scopeObject._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "POD Generation failed", 2000));
        }
    }

    private errorHandlerPOD(resp) {

    }
    // KA0001-Divek MYS-2018-0415 Start
    public isSystemGenerated(value) {
        let PolicyNumber = value;
        if (PolicyNumber.length > 8) {
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Policy Number should be less than or equal to 8 digits", 5000));
            this.appObj.ApplicationBusinessObject.caseInfo.policyNumber = '';
            return;
        }
        this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.systemGenerated = (AppUtil.isEmpty(PolicyNumber, false)) ? true : false;
    }

    private formatPolicyNumber(event) {
        if (isNaN(Number(event.target.value))) {
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Please Enter Policy Number in Valid Format", 5000));
            jQuery(this.el).find("#policyNumber").focus();
            event.target.value = '';
        }
    }

    private checkExcessValidation(event) {
        if (!(event.keyCode >= 48 && event.keyCode <= 57)) {
            event.preventDefault();
        }
    }


    // KA0001- Divek END

    //GA004 START
    /* 
    private sendHighRiskMailtoAH(obj){
        let userId = obj.appObj.ApplicationBusinessObject.caseInfo.accountHandler;
        obj._cordysService.callCordysSoapService(
            "GetMsigUsersMasterObject",
            "http://schemas.opentext.com/msig/persistancedb/1.0",
            { "USER_ID": userId },            
            obj.highRiskMailSuccessHandler, 
            obj.highRiskMailErrorHandler,
            true,
            {
                comp: obj
            }
        );
    }

    private highRiskMailErrorHandler(response, status, errorText, extraParams) {
        extraParams._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error while getting email ID for High Risk email send", -1));
    }
   
    private highRiskMailSuccessHandler(data, prms){
        let userEmail = "";
        let userName = "";
        if(data!=undefined && data.tuple){
            userEmail = data.tuple.old.MSIG_USERS_MASTER.USER_EMAIL;
            userName = data.tuple.old.MSIG_USERS_MASTER.USER_FULL_NAME;
        }else{
            return;
        }
        if(userEmail!="" && userEmail!=undefined){
            userEmail = "kiran25399@gmail.com";
        }
        */
    /* let bodyContent = "\n"+
    "Please take note on the proposal submitted under High Risk Client and further action is require at your end. \n"+
    "Client : "+ "=" +" \n Agent : "; */
    /*
    let bodyContent = "";
    let subjectContent = "";
    let headerInfo = prms.comp.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo;
    if( headerInfo.highRiskIndicator == "true"){
        if(headerInfo.highRiskInternalIndicator == 'A'){
            let highRiskObj = headerInfo.highRiskIndicatorReasons.highRiskIndReason.find(item => item.item_key === "INTERNAL_CLIENT");
            let clientName = "";
            if ( prms.comp.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.clientDetails.client.genericDetails.clienttype == "P"){
                clientName = prms.comp.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.clientDetails.client.personalClientDetails.Name;
            } else if ( prms.comp.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.clientDetails.client.genericDetails.clienttype == "C"){
                clientName = prms.comp.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.clientDetails.client.corporateClientDetails.corporation;
            }
            subjectContent = "High Risk Client (" + highRiskObj.reason + ") – " + clientName;
            bodyContent = "\n" +
                "Please take note on the proposal submitted under High Risk Client and further action is require at your end. \nClient : " + clientName + " \nAgent  : ";
            let emailContent = {
                "to":{
                    "address":{
                        "emailAddress":"noreply@my.msig-asia.com",
                        "displayName":"HIGH RISK CLIENT NOTIFICATION - UAT"
                    }
                },
                "subject":subjectContent,
                "body": bodyContent,                    
                "from":{
                    "address":{
                        "emailAddress": userEmail,
                        "displayName": userName
                    }
                }
            };
            prms.comp._cordysService.callCordysSoapService(
                "SendMail",
                "http://schemas.cordys.com/1.0/email",
                emailContent,
                null,
                null,
                true,
                {
                    comp: this
                }
            );

        }else if(headerInfo.highRiskVehicleIndicator == 'A') {
            let highRiskObj = headerInfo.highRiskIndicatorReasons.highRiskIndReason.find(item => item.item_key === "HIGHRISK_VEHICLE");
            let clientName = "";
            if ( prms.comp.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.clientDetails.client.genericDetails.clienttype == "P"){
                clientName = prms.comp.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.clientDetails.client.personalClientDetails.Name;
            }else if(headerInfo.newBusiness.clientDetails.client.genericDetails.clienttype == "C"){
                clientName = prms.comp.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.clientDetails.client.corporateClientDetails.corporation;
            }
            subjectContent = "High Risk Vehicle ("+ highRiskObj.reason +") – "+ clientName;
            let emailContent = {
                "to":{
                    "address":{
                        "emailAddress":"noreply@my.msig-asia.com",
                        "displayName":"HIGH RISK VEHICLE NOTIFICATION - UAT"
                    }
                },
                "subject":subjectContent ,
                "body": bodyContent,
                "from":{
                    "address":{
                        "emailAddress": userEmail,
                        "displayName": userName
                    }
                }
            };
            prms.comp._cordysService.callCordysSoapService(
                "SendMail",
                "http://schemas.cordys.com/1.0/email",
                emailContent,
                null,
                null,
                true,
                {
                    comp: this
                }
            );
        }                
    }
}
*/
    //GA004 END
}