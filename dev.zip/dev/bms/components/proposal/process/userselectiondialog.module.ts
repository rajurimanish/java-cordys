import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { UserSelectionComponent } from './userselectiondialog.component';
import { UserPipe } from './userselectiondialog.userpipe';

@NgModule({
    imports: [CommonModule, FormsModule, ReactiveFormsModule],
    declarations: [UserSelectionComponent, UserPipe],
    exports: [UserSelectionComponent, UserPipe]
})
export class UserSelectionDialogModule { }