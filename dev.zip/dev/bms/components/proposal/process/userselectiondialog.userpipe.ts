import { Pipe } from '@angular/core';

@Pipe({ name: 'UserPipe' })
export class UserPipe {

    transform(value, args) {
        if (args) {
            if (args[0] != undefined) {

                return value.filter(function (user) {
                    if (user.old.MSIG_BO_ACTIVITIES) {
                        return (user.old.MSIG_BO_ACTIVITIES.USER_ID.startsWith(args)) || (user.old.MSIG_BO_ACTIVITIES.USER_FULL_NAME.startsWith(args));
                    }
                    else {
                        return (user.old.MSIG_BRANCH_LOB_ROLE_USER_MAPPING.USER_ID.startsWith(args)) || (user.old.MSIG_BRANCH_LOB_ROLE_USER_MAPPING.USER_FULL_NAME.startsWith(args));
                    }
                });

            }
            else return value;
        }
        else return value;

    }

}