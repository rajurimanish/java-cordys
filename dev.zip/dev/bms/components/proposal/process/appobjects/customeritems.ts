import { CustomerItem } from './customeritem'

export class CustomerItems {
    constructor(
        public customerItem?: CustomerItem[]
    ) {
        this.customerItem = [];
    }
}