import { CustomerItems } from './customeritems'
import { AgentItems } from './agentitems'

export class AppealToBUSMTForm {
    constructor(
        public duration?: number,
        public sumInsured?: number,
        public rateable?: string,
        public reasonCode?: string,
        public reason?: string,
        public remarks?: string,
        public customerItems?: CustomerItems,
        public agentsLists?: AgentItems
    ) {
        this.remarks = "";
    }
}