import { AgentItem } from './agentitem'

export class AgentItems {
    constructor(
        public agentItem?: AgentItem[]
    ) {
        this.agentItem = [];
    }
}