export class AgentItem {
    public year;
    public GPW;
    public GCI;
    public LR;
    constructor() {
        this.year = '';
        this.GPW = '';
        this.GCI = '';
        this.LR = '';
    }
}