export class CustomerItem {
    public year;
    public GPW;
    public GCI;
    public LR;
    constructor() {
        this.year = '';
        this.GPW = '';
        this.GCI = '';
        this.LR = '';
    }
}