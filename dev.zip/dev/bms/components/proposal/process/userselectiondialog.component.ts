import { Component, OnInit, NgZone } from "@angular/core";
import { ApplicationUtilService } from "../../../../common/services/application.util.service";
//import {Message,MessageMode,MessageType} from '../../../components/utility/message/message.component';
import { AlertMessagesService } from '../../../../common/components/utility/alertmessage/alertmessages.service';
import { AlertMessage } from '../../../../common/components/utility/alertmessage/alertmessages.model';

@Component({
    selector: "user-selection-component-rfi",
    templateUrl: "app/bms/components/proposal/process/userselectiondialog.template.html",
    inputs: ['datainput', 'closeDialog', 'parentCompPRMS']
})

export class UserSelectionComponent implements OnInit {

    public userDn: string;
    private response: any;
    private dialogName: string;
    public userList: any;
    private orgDn: string;
    private roleDN: string;
    public comments: string;
    private isMandatory: boolean;
    private hideUserTable: boolean;
    private isRFI: boolean = false;
    private roleDescription: string;

    public datainput: any;
    public closeDialog: Function;
    public parentCompPRMS: any;

    constructor(private _appUtilService: ApplicationUtilService, public _alertMsgService: AlertMessagesService) { }

    ngOnInit() {
        this.response = this.datainput.registerResponse;
        this.dialogName = this.datainput.dialogName;
        this.isMandatory = this.datainput.areCommentsMandatory;
        this.orgDn = this.datainput.orgDn;
        this.comments = "";

        if (this.response !== undefined && this.response !== null) {
            this.hideUserTable = false;
            if (this.dialogName !== "rfi" && this.dialogName !== "Rerate Review") {
                // Setting RoleDN
                this.roleDN = this.response.Success.nextRoleDN;

                if (this.roleDN != undefined && this.roleDN.indexOf(",") != -1) {
                    this.roleDN = this.roleDN.substring(3, this.roleDN.indexOf(","));
                }
                //Setting Role Description
                if (this.response.Success.userList && this.response.Success.userList != "") {
                    if (Array.prototype.isPrototypeOf(this.response.Success.userList.tuple)) {
                        if (this.response.Success.userList.tuple[0]) {
                            this.roleDescription = this.response.Success.userList.tuple[0].old.MSIG_BRANCH_LOB_ROLE_USER_MAPPING.ROLE_NAME;
                            this.roleDN = this.roleDN + " (" + this.roleDescription + ")";
                        }
                    }
                    else {
                        if (this.response.Success.userList.tuple) {
                            this.roleDescription = this.response.Success.userList.tuple.old.MSIG_BRANCH_LOB_ROLE_USER_MAPPING.ROLE_NAME;
                            this.roleDN = this.roleDN + " (" + this.roleDescription + ")";
                        }
                    }

                } else if (typeof (this.response.Success.userList) === 'string') {
                    this.userList = [];
                    this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "No users available under role: " + this.roleDN, 5000));
                }

                this.isRFI = false;

                if (this.dialogName == "moveToPPOnCanCompleteYes" || this.dialogName == "moveToCNPOnCanCompleteYes") {
                    this.hideUserTable = true;
                } else if (typeof (this.response.Success.userList) !== 'string') {
                    if (Array.prototype.isPrototypeOf(this.response.Success.userList.tuple)) {
                        this.userList = this.response.Success.userList.tuple;
                    } else {
                        this.userList = [this.response.Success.userList.tuple];
                    }
                }
            } else {
                if (this.response.tuple) {
                    if (Array.prototype.isPrototypeOf(this.response.tuple)) {
                        this.userList = this.response.tuple;
                        let item = this.response.tuple[0].old.MSIG_BRANCH_LOB_ROLE_USER_MAPPING;
                        if (item)
                            this.roleDN = item.BRANCH_CODE + "_" + item.LOB_CODE + "_" + item.ROLE_CODE;
                    } else {
                        this.userList = [this.response.tuple];
                        let item = this.response.tuple.old.MSIG_BRANCH_LOB_ROLE_USER_MAPPING;
                        if (item)
                            this.roleDN = item.BRANCH_CODE + "_" + item.LOB_CODE + "_" + item.ROLE_CODE;
                    }
                }
                else {
                    this.userList = [];
                    this.hideUserTable = true;
                }
                if (this.dialogName == "rfi")
                    this.isRFI = true;
            }
        } else if (this.response === undefined || this.response === null) {
            this.userList = [];
            this.hideUserTable = true;
        }

        // Get and set the orgDn
        // this._appUtilService.getOrgDn().subscribe((data) => this.getOrgDn(data, this));  (Not required as senindg from control area)
    }


    public getOrgDn(data, scopeObject) {
        scopeObject.orgDn = data;
    }

    private CloseDialog() {
        if (this.isMandatory) {
            if (this.comments.trim() === "") {
                this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Please provide comments", 5000));
                return;
            }
        }
        if (this.isMandatory && this.userList != undefined && this.userList.length < 1) {
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "At least one user should be configured under the role: " + this.roleDN + ". Please contact administrator", 5000));
            return;
        }
        if (this.userDn || this.hideUserTable || this.dialogName != "rfi") {
            this.closeDialog({
                dialogName: this.dialogName,
                userDn: this.userDn,
                comments: this.comments,
                response: this.response
            }, this.parentCompPRMS);
        } else {
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Please select one user", 5000));
            //this.CloseDialogAndSendToRole();
        }
    }

    private CloseDialogAndSendToRole() {
        this.closeDialog({
            dialogName: this.dialogName,
            userDn: null,
            comments: this.comments,
            response: this.response
        }, this.parentCompPRMS);
    }

    private setUserId(userObj) {
        if (this.dialogName != "rfi") {
            let userId = userObj.old.MSIG_BRANCH_LOB_ROLE_USER_MAPPING.USER_ID
            this.userDn = null;
        } else {
            let userId = userObj.old.MSIG_BO_ACTIVITIES.USER_ID
            this.userDn = "cn=" + userId + ",cn=organizational users," + this.orgDn;
            this.resetColorPattern();
            (<HTMLElement>event.target).parentElement.style.backgroundColor = "#ccccb3";
        }

    }

    private resetColorPattern() {
        let rows = document.getElementById("userTable").getElementsByTagName("tr");
        if (rows) {
            for (let i = 1; i < rows.length; i++) {
                rows[i].style.backgroundColor = "rgb(255,255,255)";
            }
        }
    }

    private cancelDialog() {
        this.closeDialog({
            dialogName: this.dialogName,
            isDialogCancelled: true
        }, this.parentCompPRMS);
    }

}