/*
 * Change History:
 * 
 * No      Date          Description                                                        Changed By
 * ====    ==========    ===========                                                        ==========
   MD001   07/06/2018    MYS-2018-0261 : To display "Business Consideration Form" at         MKU1
                         subsequent stages after BU SMT approved                        
   GA001   20/08/2019    MYS-2019-0985 : Incorrect Loss Ratio populated 
                         under Business Consideration Form                                   KGA                    
*/
import { Component, NgZone } from "@angular/core";
import { CordysSoapWService } from "../../../../common/components/utility/cordys-soap-ws";
import { AlertMessagesService } from '../../../../common/components/utility/alertmessage/alertmessages.service';
import { AlertMessage } from '../../../../common/components/utility/alertmessage/alertmessages.model';
//import { SelectBox } from "../../utility/selectbox/select-box";
import { ApplicationObject, ApplicationBusinessObject, BusinessObject } from '../../common/appobjects/applicationBusinessObject';

import { AppealToBUSMTForm } from '../process/appobjects/appealtobusmt.dialog.data.component';
import { CustomerItems } from '../process/appobjects/customeritems';
import { CustomerItem } from '../process/appobjects/customeritem';
import { AgentItems } from '../process/appobjects/agentitems';
import { AgentItem } from '../process/appobjects/agentitem';

declare var moment: any;
declare var numeral: any;

const RATE_FORMAT: string = "0.00";//GA001

@Component({
    selector: "appealtobusmt-dialog",
    templateUrl: "app/bms/components/proposal/process/appealtobusmt.dialog.template.html",
    inputs: ['appObj'],
    /* providers: [CordysSoapWService],
    directives:[SelectBox] */
})

export class AppealtoBUSMTComponent {
    private appObj: ApplicationObject;
    private riskObj;
    private reasonCodesList: any[];
    private dialogName: string;
    private currentyear: string;
    private fields = ["Gross Premium Written", "Gross Claim Incurred", "Loss Ratio (Gross)"];
    private years = [];
    private approvalInfoObj: any;
    private customerName: string;
    private isCommentsMandtory: boolean = false;
    private busmtForm: any;
    private hideFields: boolean = true;
    private showForm: boolean = true;
    private categoryValue: string;

    public datainput: any;
    public parentCompPRMS: any;
    public closeDialog: Function;
    private viewType: String;//MD001
    constructor(private _cordysService: CordysSoapWService, public _alertMsgService: AlertMessagesService) { }

    ngOnInit() {
        if (this.datainput != undefined) {
            this.showForm = false;
            this.viewType = this.datainput.viewType;//MD001
        }

        this.appObj = (this.datainput != undefined) ? this.datainput.applicationObj : this.appObj;
        let risksObj: any = this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.risks;
        this.dialogName = "common-comment-busmt-appeal-referred";

        this.currentyear = moment().format('YYYY');

        this.busmtForm = new AppealToBUSMTForm();

        this.busmtForm.sumInsured = this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.targetSumInsured;

        if (this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.appealBUSMTForm == undefined ||
            this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.appealBUSMTForm == "") {

            this.busmtForm.customerItems = new CustomerItems();
            this.busmtForm.customerItems.customerItem = [];

            this.busmtForm.agentItems = new AgentItems();
            this.busmtForm.agentItems.agentItem = [];

            this.getYearsInfo(this.currentyear, 5);

            for (let i = 0; i < this.years.length; i++) {

                this.busmtForm.customerItems.customerItem.push(new CustomerItem());
                this.busmtForm.agentItems.agentItem.push(new AgentItem());

                this.busmtForm.customerItems.customerItem[i].year = this.years[i];
                this.busmtForm.agentItems.agentItem[i].year = this.years[i];
            }

        } else if (this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.appealBUSMTForm.customerItems != ""
            && this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.appealBUSMTForm.customerItems != null
            && this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.appealBUSMTForm.customerItems != undefined) {
            this.busmtForm.customerItems = this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.appealBUSMTForm.customerItems;
            this.busmtForm.agentItems = this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.appealBUSMTForm.agentItems;

            for (let i = 0; i < this.busmtForm.customerItems.customerItem.length; i++) {
                this.years[i] = this.busmtForm.customerItems.customerItem[i].year;
            }

            this.busmtForm.duration = this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.appealBUSMTForm.duration;
            this.busmtForm.rateable = this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.appealBUSMTForm.rateable;
            this.busmtForm.reasonCode = this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.appealBUSMTForm.reasonCode;
            this.busmtForm.reason = this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.appealBUSMTForm.reason;
            this.busmtForm.remarks = this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.appealBUSMTForm.remarks;

            if (this.busmtForm.reason == "Others")
                this.isCommentsMandtory = true;
        }

        if (risksObj.motorMCV.length >= 1)
            this.riskObj = risksObj.motorMCV[0];
        else if (risksObj.motorMPV.length >= 1)
            this.riskObj = risksObj.motorMPV[0];
        else if (risksObj.driverPersonalAccident.length >= 1)
            this.riskObj = risksObj.driverPersonalAccident[0];
        else if (risksObj.fireIDC.length >= 1)
            this.riskObj = risksObj.fireIDC[0];
        else if (risksObj.fireLOP.length >= 1)
            this.riskObj = risksObj.fireLOP[0];
        else if (risksObj.individualPersonalAccident.length >= 1)
            this.riskObj = risksObj.individualPersonalAccident[0];
        else if (risksObj.s4805.length >= 1)
            this.riskObj = risksObj.s4805[0];
        else if (risksObj.s4808.length >= 1)
            this.riskObj = risksObj.s4808[0];
        else if (risksObj.s4811.length >= 1)
            this.riskObj = risksObj.s4811[0];
        else if (risksObj.s4846.length >= 1)
            this.riskObj = risksObj.s4846[0];
        else if (risksObj.s4857.length >= 1)
            this.riskObj = risksObj.s4857[0];
        else if (risksObj.s4861.length >= 1)
            this.riskObj = risksObj.s4861[0];
        else if (risksObj.s5335.length >= 1)
            this.riskObj = risksObj.s5335[0];
        else if (risksObj.travel.length >= 1)
            this.riskObj = risksObj.travel[0];
        else if (risksObj.s4804.length >= 1)
            this.riskObj = risksObj.s4804[0];
        else if (risksObj.s4810.length >= 1)
            this.riskObj = risksObj.s4810[0];
        else if (risksObj.s4851.length >= 1)
            this.riskObj = risksObj.s4851[0];
        else if (risksObj.s5183.length >= 1)
            this.riskObj = risksObj.s5183[0];
        else if (risksObj.s5381.length >= 1)
            this.riskObj = risksObj.s5381[0];
        else if (risksObj.s6271.length >= 1)
            this.riskObj = risksObj.s6271[0];
        else if (risksObj.generic.length >= 1)
            this.riskObj = risksObj.generic[0];

        let inputReq = {
            "cursor": { "@id": "0", "@position": "0", "@numRows": "500", "@maxRows": "99999", "@sameConnection": "false" },
            "BRANCH": "ALL", "LOB": "ALL", "BUSINESS_FUNCTION": "NEW BUSINESS", "PRODUCT": "ALL", "OPERATION": "ALL", "FORM_NAME": "MIS_SUB_TIER",
            "FORM_FIELD_NAME": "MIS Sub Tier", "FIELD_TYPE": "LOV",
            "ADVANCE_CONFIG_XML": {
                "FILTERS": {
                    "FILTER": [
                        { "@FIELD_NAME": "DESCITEM", "@FIELD_VALUE": this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.misSubTier, "@OPERATION": "EQ", "@CONDITION": "AND" }
                    ]
                }
            }
        }

        // Fetching Category value from DESCPF --> T7238 table
        this._cordysService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0",
            inputReq, this.lovSuccessHandler, this.lovErrorHandler, true, this);
    }

    ngAfterContentInit() {
        // calling GetXMLObject service to fetch reasoncodes
        this._cordysService.callCordysSoapService(
            "GetXMLObject",
            "http://schemas.cordys.com/1.0/xmlstore",
            { key: "/com/msig/insurance/BMSReasonCodesConfiguration.xml" },
            this.getXMLObjSuccessHandler,
            this.getXMLObjErrorHandler,
            false,
            this
        );

        // get approval object for Declined by UW
        this.approvalInfoObj = this.appObj.ApplicationBusinessObject.caseInfo.approvalInfo.approval.filter(function (obj) { return obj.action === "Declined"; })[0];
        this.customerName = (this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.clientDetails.client.genericDetails.clienttype == 'P') ?
            this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.clientDetails.client.personalClientDetails.Name :
            this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.clientDetails.client.corporateClientDetails.corporation;
    }

    private getYearsInfo(currentYear, displayYears) {
        for (let i = 0; i < displayYears; i++)
            this.years.push(currentYear--);
    }

    private lovSuccessHandler(response, scopeObject) {
        if (response.tuple && response.tuple.old)
            scopeObject.categoryValue = response.tuple.old.DESCPF.LONGDESC;
    }

    private lovErrorHandler(response, status, errorText, scopeObject) { }


    private getXMLObjSuccessHandler(response, originalObject) {
        if (!response.tuple) {
            originalObject._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Reason codes are not available in confuguration file. Please contact Administrator", 7000));
            return;
        }
        let reasonCodes = response.tuple.old.Reasons.ReasonCodes;
        let reasons = [];
        for (let i = 0; i < reasonCodes.length; i++) {
            if (reasonCodes[i]['@type'] == originalObject.dialogName) {
                reasons = reasonCodes[i].Reason;
            }
        }

        originalObject.reasonCodesList = [];
        for (let r = 0; r < reasons.length; r++) {
            originalObject.reasonCodesList.push({ description: reasons[r].description, code: reasons[r].code });
        }
    }

    private getXMLObjErrorHandler(response, status, errorText, extraPrms) {
        this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Reason codes are not available in confuguration file. Please contact Administrator", -1));
    }

    private cancelDialog(action) {
        if ((action == "appealtoBUSMT") && this.validateForm()) {
            return;
        }

        //this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.appealBUSMTForm = this.busmtForm;

        this.closeDialog({
            dialogName: this.dialogName,
            isDialogCancelled: (action == "appealtoBUSMT") ? false : true,
            action: (action == "appealtoBUSMT") ? "appealtoBUSMT" : "cancel",
            "busmtForm": this.busmtForm
        }, this.parentCompPRMS);
    }

    private reasonChange(selectedReason) {
        this.isCommentsMandtory = (selectedReason.description == "Others") ? true : false;
        this.busmtForm.reasonCode = selectedReason.value;
        this.busmtForm.reason = selectedReason.description;;
    }

    private validateForm() {
        if ((this.busmtForm.reason == undefined || this.busmtForm.reason.length == 0) || (this.busmtForm.remarks == undefined || this.busmtForm.remarks.length == 0)) {
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Please fill all Mandatory fields.", 6000));
            return true;
        }
        return false;
    }

    /*
    GA001 - ex: numeral(numeral(51.46146909003355).format("0.00")).value();
                numeral(numeral(parseFloat(51.46646909003355)).format("0.00")).value(); - 51.47
    */
    private calculateLossRatio(event, cursor, type) {

        let lossRatio = 0;//GA001
        let list = (type == "customerList") ? this.busmtForm.customerItems.customerItem.length : this.busmtForm.agentItems.agentItem.length;
        for (let i = 0; i < list; i++) {
            if (i == cursor && type == "customerList" && numeral(this.busmtForm.customerItems.customerItem[i].GCI).value() != 0 && numeral(this.busmtForm.customerItems.customerItem[i].GPW).value()) {
                //GA001 START
                //this.busmtForm.customerItems.customerItem[i].LR = numeral(this.busmtForm.customerItems.customerItem[i].GCI).value() % numeral(this.busmtForm.customerItems.customerItem[i].GPW).value();
                lossRatio = (numeral(this.busmtForm.customerItems.customerItem[i].GCI).value() / numeral(this.busmtForm.customerItems.customerItem[i].GPW).value()) * 100;
                if( lossRatio != NaN && lossRatio != undefined ){
                    this.busmtForm.customerItems.customerItem[i].LR = numeral(numeral(parseFloat(""+lossRatio)).format(RATE_FORMAT)).value();
                }
                //GA001 END
                break;
            }
            if (i == cursor && type == "agentList") {
                //this.busmtForm.agentItems.agentItem[i].LR = numeral(this.busmtForm.agentItems.agentItem[i].GCI).value() % numeral(this.busmtForm.agentItems.agentItem[i].GPW).value();
                //GA001 START
                lossRatio = (numeral(this.busmtForm.agentItems.agentItem[i].GCI).value() / numeral(this.busmtForm.agentItems.agentItem[i].GPW).value()) * 100;
                if( lossRatio != NaN && lossRatio != undefined ){
                    this.busmtForm.agentItems.agentItem[i].LR = numeral(numeral(parseFloat(""+ lossRatio)).format(RATE_FORMAT)).value();
                }
                //GA001 END
                break;
            }
        }
    }

}