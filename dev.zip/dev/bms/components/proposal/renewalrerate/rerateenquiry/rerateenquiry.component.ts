import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { AdvancedSearchInput } from '../../../../../common/components/advancedsearchgrid/advancedsearchgridinput';
import { GetLOVData, SearchAdvancedConfig, Filter } from '../../../../../common/components/utility/search/search.requests';
import { AlertMessage } from '../../../../../common/components/utility/alertmessage/alertmessages.model';
import { AppUtil } from '../../../../../common/components/utility/apputil/app.util';
import { ApplicationUtilService } from '../../../../../common/services/application.util.service';

declare var numeral: any;
@Component({
    selector: 'rerate-enquiry',
    templateUrl: 'app/bms/components/proposal/renewalrerate/rerateenquiry/rerateenquiry.template.html'
})

export class RerateEnquiryComponent implements OnInit {

    private advancedSearchInput: AdvancedSearchInput = new AdvancedSearchInput();
    constructor(private _router: Router, private _appUtilService: ApplicationUtilService) {
    }

    ngOnInit() {
        this.advancedSearchInput.advancedFilterOptnsArry = { "LIKE": "LIKE", "EQ": "EQ", ">": "GT", ">=": "GTEQ", "<": "LT", "<=": "LTEQ" };
        this.advancedSearchInput.onColumnDataBind = this._appUtilService.transformValue;
        this.advancedSearchInput.getRecordsCount = this.getTotalSearchRecordsCount;
    }

    private transformValue(value, listItem) {
        let siFormat: string = '0,0.00';

        if (listItem == "DOB" && value != "") {
            if (value == '99999999') return "";
            else
                return new AppUtil().convertDate(value, "YYYYMMDD", AppUtil.DATE_FORMAT);
        }
        if (listItem == "Expiry Date" && value != "") {
            if (value == '99999999') return "";
            else
                return new AppUtil().convertDate(value, "YYYYMMDD", AppUtil.DATE_FORMAT);
        }
        if ((listItem == "Premium") && value != "") {
            return numeral(value).format(siFormat);
        }

        else return value;
    }
    private getTotalSearchRecordsCount(input, prm) {
        var requestObj = new GetLOVData();
        requestObj.BRANCH = 'ALL';
        requestObj.LOB = 'ALL';
        requestObj.BUSINESS_FUNCTION = 'NEW BUSINESS';
        requestObj.PRODUCT = 'ALL';
        requestObj.OPERATION = 'ALL';
        requestObj.FORM_NAME = 'Renewal  Rerate';
        requestObj.FORM_FIELD_NAME = 'Renewal  Rerate Count';
        requestObj.FIELD_TYPE = 'LOOKUP';
        requestObj.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        requestObj.ADVANCE_CONFIG_XML.FILTERS = new Filter();
        requestObj.ADVANCE_CONFIG_XML.FILTERS.FILTER = [];

        requestObj.ADVANCE_CONFIG_XML = input.ADVANCE_CONFIG_XML;

        //input.FORM_NAME='RENEWAL_ENQ_COUNT';     
        //input.FORM_FIELD_NAME = 'RENEWAL_ENQ_COUNT';
        let recordsCountResponse = prm._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", requestObj, null, null, true, null);
        recordsCountResponse.success((data) => {
            if (data.tuple) {
                prm.recordsCount = data.tuple.old.TABLE.VALUE;
            }
        });
        recordsCountResponse.error((response, status, errorText) =>
            prm._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error while calling LOV service " + errorText, -1)));

    }

    private onActionClick(event) {
        switch (event.action) {
            case "dblclick":
                this._router.navigate(["Proposal/Edit", { policyNo: event.item.CHDRNUM, viewmode: true, component: "P400RerateEnquiry" }]);
                break;
            default: break;
        }
    }
}
