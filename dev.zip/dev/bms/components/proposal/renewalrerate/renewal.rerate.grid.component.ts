/*
 * Change History	:
 *
 * 	No      Date         Description                                 			Changed By
 *	====    ==========   ===========                                 			==========	
 *  VK001   04/09/2018  MYS-2018-1026 - Security fix                                VKR
 * 							   
 */


import { ViewChild, ViewContainerRef } from "@angular/core";
import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ApplicationUtilService } from '../../../../common/services/application.util.service';
import { CordysSoapWService } from '../../../../common/components/utility/cordys-soap-ws';
import { GetLOVData, SearchAdvancedConfig, Filter } from '../../../../common/components/utility/search/search.requests';
import { AlertMessagesService } from '../../../../common/components/utility/alertmessage/alertmessages.service';
import { AlertMessage } from '../../../../common/components/utility/alertmessage/alertmessages.model';
import { RenewalServices } from '../../../services/renewal.service';
import { AdvancedSearchInput } from '../../../../common/components/advancedsearchgrid/advancedsearchgridinput';
import { ProgressBarComponent } from '../../../../common/components/utility/progressbar/progressbar.component';
import { ModalInput } from "../../../../common/components/utility/modal/modal";
import { DCLInput } from "../../../../common/services/customdcl.service";
import { CommentDialogData } from "../../../components/proposal/process/appobjects/comment.dialog.data.component";
import { CustomDCLService } from "../../../../common/services/customdcl.service";
import { AppUtil } from '../../../../common/components/utility/apputil/app.util';

declare var numeral: any;
declare var Rx: any;

@Component({
    selector: 'myrenewalrerate-comp',
    templateUrl: 'app/bms/components/proposal/renewalrerate/renewal.rerate.grid.template.html'
})

export class MyRenewalRerateComponent implements OnInit {
    private advancedSearchInput: AdvancedSearchInput = new AdvancedSearchInput();
    public initiated = false;
    public comments: string = '';
    public commentDate: string = '';
    public simplifiedProdList: any;

    @ViewChild('RenewalRerateModal', { read: ViewContainerRef }) contentArea: ViewContainerRef;

    constructor(private _soapService: CordysSoapWService, private _appUtilService: ApplicationUtilService, public _alertMsgService: AlertMessagesService,
        public renService: RenewalServices, private _router: Router, public dcl: CustomDCLService) {

    }


    ngOnInit() {
        this.advancedSearchInput.advancedFilterOptnsArry = { "EQ": "EQ", "LIKE": "LIKE", ">": "GT", ">=": "GTEQ", "<": "LT", "<=": "LTEQ" };
        this.advancedSearchInput.isActionsEnableFunction = this.checkEnable;
        this.advancedSearchInput.onColumnDataBind = this.onColumnDataBind;
        this.advancedSearchInput.bindHover = this.bindHover;
        this.advancedSearchInput.getRecordsCount = this.getTotalSearchRecordsCount;
        this._appUtilService.getUserDn().subscribe((data) => this.getUserId(data));
        this.loadProductList();
    }
    loadProductList() {
        this._soapService.callCordysSoapService("GetXMLObject", "http://schemas.cordys.com/1.0/xmlstore", { "key": "com/msig/insurance/simplifiedprocess/productlist.xml" }, null, null, true, null)
            .success((data) => {
                if (data.tuple && data.tuple.old) {
                    this.simplifiedProdList = AppUtil.getValueByPath(data, "tuple.old.SimplifiedProductList.ProductList");
                    this.simplifiedProdList = (typeof (this.simplifiedProdList) == "string" && this.simplifiedProdList != "") ? [this.simplifiedProdList] : this.simplifiedProdList;
                }
            })
            .error((err) => {
                this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error while getting Product List XML" + err, -1));
            });
    }

    private getTotalSearchRecordsCount(input, prm) {
        var requestObj = new GetLOVData();
        requestObj.BRANCH = 'ALL';
        requestObj.LOB = 'ALL';
        requestObj.BUSINESS_FUNCTION = 'NEW BUSINESS';
        requestObj.PRODUCT = 'ALL';
        requestObj.OPERATION = 'ALL';
        requestObj.FORM_NAME = 'Renewal  Rerate';
        requestObj.FORM_FIELD_NAME = 'Renewal  Rerate Count';
        requestObj.FIELD_TYPE = 'LOOKUP';
        requestObj.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        requestObj.ADVANCE_CONFIG_XML.FILTERS = new Filter();
        requestObj.ADVANCE_CONFIG_XML.FILTERS.FILTER = [];

        requestObj.ADVANCE_CONFIG_XML = input.ADVANCE_CONFIG_XML;

        //input.FORM_NAME='RENEWAL_ENQ_COUNT';     
        //input.FORM_FIELD_NAME = 'RENEWAL_ENQ_COUNT';
        let recordsCountResponse = prm._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", requestObj, null, null, true, null);
        recordsCountResponse.success((data) => {
            if (data.tuple) {
                prm.recordsCount = data.tuple.old.TABLE.VALUE;
            }
        });
        recordsCountResponse.error((response, status, errorText) =>
            prm._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error while calling LOV service " + errorText, -1)));

    }

    private getUserId(data) {
        let ZPRODUCER = "";
        /* let ZUSERID =  data.substring(3, data.indexOf(","));
        let producerCodeResponsePromise = this._soapService.callCordysSoapService("GetMsigUsersMasterObject", "http://schemas.opentext.com/msig/persistancedb/1.0", {"USER_ID" : ZUSERID}, null, null, false, null);
        */

        //VK001 Changed the service call from getMsigUsersMasterObject to GetLoggedInUserInfo
        let producerCodeResponsePromise = this._soapService.callCordysSoapService("GetLoggedInUserInfo", "http://schemas.opentext.com/msig/persistancedb/1.0", null, null, null, false, null);
        /*  END VK001 */
        producerCodeResponsePromise.success((data) => ZPRODUCER = (data.tuple != undefined ? data.tuple.old.MSIG_USERS_MASTER.PRODUCER_CODE : ""));
        producerCodeResponsePromise.error((response, status, errorText) => this.handleLOVError(response, status, errorText));
        //Set Advanced Filter COnfig
        if (ZPRODUCER.length > 0) {

            let searchDefinitionForAdvancedFilter = this.createSearchDef();
            searchDefinitionForAdvancedFilter.FILTER["@FIELD_NAME"] = "ZPRODUCER";
            searchDefinitionForAdvancedFilter.FILTER["@FIELD_VALUE"] = ZPRODUCER;
            searchDefinitionForAdvancedFilter.FILTER["@OPERATION"] = "EQ";
            this.advancedSearchInput.searchFilter = searchDefinitionForAdvancedFilter;
            this.initiated = true;
        }
    }

    private handleLOVError(response, status, errorText) {
        this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error while calling LOV service " + errorText, -1));
    }

    private createSearchDef() {
        let searchDef = {
            "FILTER": {
                "@FIELD_NAME": "",
                "@FIELD_VALUE": "",
                "@OPERATION": "LIKE",
                "@CONDITION": "AND"
            }
        };
        return searchDef;
    }

    private onActionClick(event) {
        if (event.action == "dblclick") {
            ProgressBarComponent.show('Please Wait...', { dialogSize: 'm', progressType: 'primary' });
            if (this.simplifiedProdList.indexOf(event.item.CNTTYPE) != -1) {
                this._router.navigate(["SimplifiedProposal/Edit", { policyNo: event.item.CHDRNUM, component: "MyRenewalRerate", product: event.item.CNTTYPE }]);
            }
            else {
                this._router.navigate(["Proposal/Edit", { policyNo: event.item.CHDRNUM, component: "MyRenewalRerate", product: event.item.CNTTYPE }]);
            }
        }
        else if (event.action == "View Comment") {
            let request = {
                "cursor": {
                    "@id": "0",
                    "@position": "",
                    "@numRows": "",
                    "@maxRows": "100",
                    "@sameConnection": "false"
                },
                "BRANCH": "ALL",
                "LOB": "ALL",
                "BUSINESS_FUNCTION": "RENEWAL",
                "PRODUCT": "ALL",
                "OPERATION": "ALL",
                "FORM_NAME": "RERATE",
                "FORM_FIELD_NAME": "View Comments",
                "FIELD_TYPE": "LOV",
                "ADVANCE_CONFIG_XML": {
                    "FILTERS": {
                        "FILTER": [
                            {
                                "@FIELD_NAME": "CHDRNO",
                                "@FIELD_VALUE": event.item.CHDRNUM,
                                "@OPERATION": "EQ",
                                "@CONDITION": "AND"
                            },
                            {
                                "@FIELD_NAME": "DTEEFF ",
                                "@FIELD_VALUE": event.item.CRDATE01,
                                "@OPERATION": "GTEQ",
                                "@CONDITION": "AND"
                            }
                        ]

                    }
                }
            };


            let viewComentsPromise = this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, null, null, true, { comp: this });
            viewComentsPromise.success((data) => {
                if (data.tuple) {
                    if (Array.prototype.isPrototypeOf(data.tuple)) {
                        this.comments = data.tuple[0].old.GENPPF.GENPLNE;
                        this.commentDate = data.tuple[0].old.GENPPF.DTEEFF;
                    }
                    else {
                        this.comments = data.tuple.old.GENPPF.GENPLNE;
                        this.commentDate = data.tuple.old.GENPPF.DTEEFF;
                    }
                    var dialogData = new CommentDialogData("CommonCommentDialogComponent", "app/bms/components/proposal/process/common.comment.dialog.module", "CommonCommentDialogModule", "View Comments", "DNComments", "fa fa-comment", null);
                    ProgressBarComponent.hide();
                    this.openCommentsDialog(dialogData, event.item.CHDRNUM);
                }
                else {
                    this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "No Comments found ", 6000));
                }
            });
            viewComentsPromise.error((response, status, errorText) => this.handleLOVError(response, status, errorText));
        }
        else {
            let duplicate = this.renService.checkDuplicate(event.item.CHDRNUM, "RR");
            let trans = this.renService.getRelatedTransaction(event.item.CHDRNUM);

            let dpTrn = Rx.Observable.zip(duplicate, trans, (dp: any, trn: any) => { return { dp: dp, trn: trn } });

            dpTrn.subscribe((data) => {
                if (data.dp == false && (data.trn == null || data.trn == "")) {
                    this.doOperation(event.action, event);
                }
                else if (data.trn != null) {
                    let trn = data.trn;
                    if (trn.OPERATION_STATUS != "ERROR") {
                        this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, trn.OPERATION + " operation is in '" + trn.OPERATION_STATUS + "' status. Wait until it is completed.", -1));
                    }
                    else if (trn.OPERATION == event.action) {
                        this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, trn.OPERATION + " operation is failed with error. Error: '" + trn.ERROR_MESSAGE + ".", -1));
                    }
                    else if (trn.OPERATION != event.action) {
                        let cnfrmMsg = trn.OPERATION + " operation is failed with error. Error: '" + trn.ERROR_MESSAGE + ". Do you want to continue with " + event.action + " operation?";
                        this.confirmOperationChange(cnfrmMsg).subscribe((choice) => {
                            if (choice.data.value == "Y") {
                                let prom = this._soapService.callCordysSoapService("UpdateMsigBmsRenewalPolicyCaseMapping", "http://schemas.opentext.com/msig/persistancedb/1.0", { "tuple": { "old": { "MSIG_BMS_RENEWAL_POLICY_CASE_MAPPING": { "CASE_ID": trn.CASE_ID, "POLICY_NO": trn.POLICY_NO } }, "new": { "MSIG_BMS_RENEWAL_POLICY_CASE_MAPPING": { "CASE_ID": trn.CASE_ID, "POLICY_NO": trn.POLICY_NO, "OPERATION": " ", "OPERATION_STATUS": " ", "ERROR_MESSAGE": " " } } } }, null, null, true, null);
                                prom.success((data) => {
                                    this.doOperation(event.action, event);
                                });
                            }
                        });

                    }
                }
            });
        }
    }

    doOperation(action, event) {
        if (action == "MR")
            this.mrOperation(event);
        else if (action == "NC")
            this.ncOperation(event);
        else if (action == "DN")
            this.dnOperation(event);
    }

    private dnOperation(event) {
        ProgressBarComponent.show('Please Wait...', { dialogSize: 'm', progressType: 'primary' });
        var dialogData = new CommentDialogData("CommonCommentDialogComponent", "app/bms/components/proposal/process/common.comment.dialog.module", "CommonCommentDialogModule", "Provide comments", "DN", "fa fa-comment", this.commentCallBack);
        ProgressBarComponent.hide();
        let evnt: any = event;
        let dataobj = {
            "event": event,
            "CHDRNUM": evnt.item.CHDRNUM,
            "CNTYPE": event.item.CNTTYPE
        }
        this.openCommentsDialog(dialogData, dataobj);
    }

    private ncOperation(event) {
        let evnt: any = event;
        ProgressBarComponent.show('Please Wait...', { dialogSize: 'm', progressType: 'primary' });
        this.renService.postRenewalRerate(evnt.item.CHDRNUM, "NC", this, "", event.item.CNTTYPE).subscribe((data) => this.refreshGridRow(evnt, data, 'NC'));
        ProgressBarComponent.hide();
    }

    private mrOperation(event) {
        let evnt: any = event;
        ProgressBarComponent.show('Creating Renewal Rerate Case', { dialogSize: 'm', progressType: 'primary' });
        let isSimplifiedprocess = (this.simplifiedProdList.indexOf(event.item.CNTTYPE) != -1) ? 'Y' : 'N';
        this.renService.createRenewalRerateTaskForAH(evnt.item.CHDRNUM, "RenewalRerate", null, null, isSimplifiedprocess).subscribe((data) => {
        });
    }

    private confirmOperationChange(message) {
        let inputObj = {
            "Message": message
        };
        let lookup = new ModalInput();
        lookup.component = ["Confirm", "app/common/components/utility/confirmmessage/confirm.module", "ConfirmModule"];
        lookup.datainput = inputObj;
        lookup.outputCallback = null;
        lookup.heading = "User Confirmation";
        lookup.icon = "fa fa-hand-paper-o";
        lookup.containerRef = this.contentArea;
        return this.dcl.openLookup(lookup);
    }

    private commentCallBack(data, prms) {
        if (data.isDialogCancelled) {
            return;
        }
        switch (data.dialogName) {
            case "DN":
                let localComments = data.comments;
                ProgressBarComponent.show('Please Wait...', { dialogSize: 'm', progressType: 'primary' });
                let isSimplifiedprocess = (prms.comp.simplifiedProdList.indexOf(prms.response.event.item.CNTTYPE) != -1) ? 'Y' : 'N';
                prms.comp.renService.createRenewalRerateTaskForAH(prms.response.CHDRNUM, "RenewalRerate", null, "false", isSimplifiedprocess).subscribe((data) => {//MYS-2018-0877 Phase 2A Renewals and Renewal rerate 
                    prms.comp.renService.postRenewalRerate(data, "DN", this, localComments, prms.response.CNTYPE).subscribe(
                        (data) => prms.comp.moveToPolicyInforced(prms.response.event, data, 'DN', isSimplifiedprocess)
                    );
                });
                ProgressBarComponent.hide();
                break;
        }
    }

    private moveToPolicyInforced(event, data, status, isSimplified?: string) {
        this.refreshGridRow(event, data, status, isSimplified);
    }

    private refreshGridRow(eventObject, data, status, isSimplified?: string) {
        if (isSimplified == 'Y' && status == 'DN') {
            this._alertMsgService.add(new AlertMessage(AlertMessage.SUCCESS, status + " Header positng successful ", -1));
        }
        else {
            if (data.success) {
                eventObject.item.ZTRNTYP = status;
            }
            this._alertMsgService.add(new AlertMessage(AlertMessage.SUCCESS, status + " operation successful ", -1));
        }
        ProgressBarComponent.hide();

    }

    private checkEnable(action, report) {
        if (action.enableWhen == undefined) {
            return false;
        }
        else if (action.enableWhen.indexOf(report["ZTRNTYP"]) != -1) {
            return false;
        }
        else {
            if (report["ZTRNTYP"] == "" && action.button != 'View Comment') return false;
            else return true;
        }
    }

    public onColumnDataBind(value, columnName) {
        if ((columnName == 'Inception date' || columnName == 'Expiry Date') && value != "" && value != undefined) {
            return value.substring(6) + "/" + value.substring(4, 6) + "/" + value.substring(0, 4);
        }
        else if ((columnName == 'Premium') && (columnName == 'Sum Insured') && (columnName == 'Claim Amount') && value != "" && value != undefined) {
            return numeral(value).format("0,0.00");
        }
        else return value;
    }

    public bindHover(report, listItem) {
        let value = report[listItem.onhover];
        if (value == '0.00' || value == '0' || value == '99999999' || value == report[listItem.id])
            return '';
        else {
            return this.onColumnDataBind(value, listItem.name);
        }
    }

    public openCommentsDialog(dialogData: CommentDialogData, response?: any) {
        let lookup = new ModalInput();
        lookup.component = [dialogData.component, dialogData.moduleAbsPath, dialogData.moduleName];
        lookup.datainput = {
            dialogName: dialogData.dialogName,
            userList: null,
            areCommentsMandatory: true,
            registerResponse: null,
            DNComments: this.comments,
            commentDate: this.commentDate
        };
        lookup.outputCallback = dialogData.callBackHandler;
        lookup.parentCompPRMS = {
            comp: this,
            response: response
        };
        lookup.heading = dialogData.dialogTitle;
        lookup.icon = dialogData.icon;
        lookup.containerRef = this.contentArea;
        this.dcl.openLookup(lookup);
    }
}

