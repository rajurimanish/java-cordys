import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MyRenewalRerateComponent } from './renewal.rerate.grid.component';
import { AppUtil } from '../../../../common/components/utility/apputil/app.util';
import { AdvancedSearchGridModule } from '../../../../common/components/advancedsearchgrid/advancedsearchgrid.module';
import { RenewalServicesModule } from '../../../services/renewal.service.module';
const webRouterConfig: Routes = [
    { path: "", component: MyRenewalRerateComponent }
];

let routerConfig = webRouterConfig;

@NgModule({
    imports: [CommonModule, FormsModule, ReactiveFormsModule, RouterModule.forChild(routerConfig), AdvancedSearchGridModule, RenewalServicesModule],
    declarations: [MyRenewalRerateComponent],
    exports: [MyRenewalRerateComponent, AdvancedSearchGridModule, RouterModule]
})
export class RenewalRerateModule { }