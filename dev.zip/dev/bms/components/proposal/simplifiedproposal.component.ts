import { Component, OnInit, OnDestroy, EventEmitter, ViewChild, ViewContainerRef } from '@angular/core';
import { CordysSoapWService } from "../../../common/components/utility/cordys-soap-ws";
import { ApplicationUtilService } from "../../../common/services/application.util.service";
import { BMSObject } from '../common/appobjects/bmsobject';
import { ProposalHeader } from './proposalheader/appobjects/proposalheader';
import { ApplicationObject, ApplicationBusinessObject } from '../common/appobjects/applicationBusinessObject';
import { CaseInfo } from '../../../common/components/appobjects/caseinfo';
import { ActivatedRoute, Router } from '@angular/router';
import { AlertMessagesService } from '../../../common/components/utility/alertmessage/alertmessages.service';
import { AlertMessage } from '../../../common/components/utility/alertmessage/alertmessages.model';
import { ProgressBarComponent } from '../../../common/components/utility/progressbar/progressbar.component';
import { BMSConstants } from '../common/constants/bms_constants';
import { NCDService } from './newbusinessrisks/motorcommercial/handler/ncd.service';
import { BMSAppObjService } from '../../services/bmsappobj.service';
import { NumberField } from '../../../common/components/utility/number/number';
import { BMSPostingService } from '../../services/bmsposting.service';
declare var Rx: any;
declare var Observer: any;
import { GetLOVData, SearchAdvancedConfig, Filter } from '../../../common/components/utility/search/search.requests';
import { CAMailService } from './process/services/camail.service';
import { CustomDCLService, DCLInput } from '../../../common/services/customdcl.service';
import { BMSControlAreaService } from '../../services/bms.controlarea.service';
import { AppUtil } from '../../../common/components/utility/apputil/app.util';
import { PaginationModule } from '../../../common/components/utility/pagination/pagination.module';
import { PaginationPipe } from '../../../common/components/utility/pagination/filtertable.pipe';
import { FilterTableContentPipe } from '../../../common/components/utility/pagination/filtercontent.pipe';
import { Generic, RiskCoverage, CustomField, CustomClause } from './newbusinessrisks/generic/appobjects/generic';
import { ExtraTextDialogData } from "./newbusinessrisks/dialogs/extratext.dialog.data";
import { ModalInput } from "../../../common/components/utility/modal/modal";
import { BMSUtilService } from '../../services/bms.util.service';


declare var numeral: any;
declare var moment: any;
declare var jQuery: any;

@Component({
    selector: 'simplified-proposal-component',
    templateUrl: 'app/bms/components/proposal/simplifiedproposal.template.html',
    styleUrls: [
        'assets/css/simplifiedForm.css'
    ]
})

export class SimplifiedProposalComponent implements OnInit {

    public appObj: ApplicationObject;
    public appBusObj: ApplicationBusinessObject;
    public bmsObject: BMSObject;
    public proposalHeader: ProposalHeader;
    public caseInfo: any;
    public risks: any;
    public loggedInUser: string;
    public userFullName: string;
    public userRoles: any[];
    public disableForm: boolean = false;
    public userID: string;
    public isAsyncValidationRequired: boolean = true;
    public isPolicyFetch: boolean = false;
    private isformDataReady: boolean = false;
    public baseModuleLoaded: boolean = false;
    public riskObj;

    public position = 1;
    public sizeObj = { length: 0, orglength: 0 };
    public contentSizeObs: any;
    public itemPerPage = 3;
    public maxPageCount = 10;

    private isCLCollapsedMode: boolean = false;
    private isCLLoaded: boolean = false;
    public premiumFormat: string = "0,00.00";
    public siFormat: string = "0,00";
    public riskTableObject;
    private customFieldsCollapse: boolean = true;
    private isImpNotesCollapsed: boolean = false;
    public rateFormat: string = "0.00000";

    @ViewChild('xtModal', { read: ViewContainerRef }) contentArea: ViewContainerRef;
    @ViewChild('clModal', { read: ViewContainerRef }) clArea: ViewContainerRef;

    private isPHCollapsedMode: boolean = false;
    private isPHLoaded: boolean = false;
    @ViewChild('phModal', { read: ViewContainerRef }) phArea: ViewContainerRef;

    private isATCollapsedMode: boolean = false;
    private isATLoaded: boolean = false;
    @ViewChild('atModal', { read: ViewContainerRef }) atArea: ViewContainerRef;

    private isTDCollapsedMode: boolean = false;
    private isTDLoaded: boolean = false;
    @ViewChild('tdModal', { read: ViewContainerRef }) tdArea: ViewContainerRef;

    @ViewChild('rtModal', { read: ViewContainerRef }) rtArea: ViewContainerRef;
    @ViewChild('gstModal', { read: ViewContainerRef }) gstArea: ViewContainerRef;
    @ViewChild('clausesModal', { read: ViewContainerRef }) clausesArea: ViewContainerRef;


    private isHDCollapsedMode: boolean = false;
    private isHDLoaded: boolean = false;
    @ViewChild('hdModal', { read: ViewContainerRef }) hdArea: ViewContainerRef;

    @ViewChild('cntrlModal', { read: ViewContainerRef }) cntrlArea: ViewContainerRef;

    private isAPSMTCollapsedMode: boolean = false;
    private isAPSMTLoaded: boolean = false;

    private tempObj: any;
    public customClausesCollapse: boolean = true;

    @ViewChild('apsmtModal', { read: ViewContainerRef }) apsmtArea: ViewContainerRef;
    constructor(public ncd: NCDService, private _cordysService: CordysSoapWService, private _routeParams: ActivatedRoute, private _aus: ApplicationUtilService, public _alertMsgService: AlertMessagesService, private _router: Router, private _appObjService: BMSAppObjService, private _postingService: BMSPostingService, private _caMailService: CAMailService, private _dcl: CustomDCLService, private _controlAService: BMSControlAreaService, public _bus: BMSUtilService) { }

    onPremiumChange = new EventEmitter<any>();

    ngOnInit() {
        ProgressBarComponent.hide();
        BMSConstants.TEMPOBJ.ISSIMPLIFIEDPROCESS = "Y";
        this.tempObj = BMSConstants.getTempObj();
        let caseId = this._routeParams.snapshot.params['caseID'];
        let policyNo = this._routeParams.snapshot.params['policyNo'];
        this.setIsPolicyFetch(policyNo);
        this.initProposal(caseId, policyNo);
    }
    ngOnDestroy() {
        this._dcl.unloadComponent(this.riskTableObject);
    }
    setIsPolicyFetch(policyNo) {
        if (AppUtil.isEmpty(policyNo, false) == false)
            this.isPolicyFetch = true;
    }

    private setUserId(data) {
        this.userID = data.substring(3, data.indexOf(","));
    }

    initVars(applObj) {
        this.appObj = applObj;
        this.appBusObj = this.appObj.ApplicationBusinessObject;
        this.caseInfo = this.appBusObj.caseInfo;
        this.bmsObject = this.appBusObj.businessObject.bms;
        this.proposalHeader = this.bmsObject.newBusiness.headerInfo;
        this.proposalHeader.isSimplifiedProcess = 'Y'
        this.risks = this.bmsObject.newBusiness.risks;
        //SST code
        let tempRespObj = this._bus.getLiveDate();
        if (tempRespObj != undefined && tempRespObj != "") {
            this.proposalHeader.GSTLiveDate = tempRespObj[0].old.ITEMPF.LIVEDATE;
            this.proposalHeader.SSTLiveDate = tempRespObj[1].old.ITEMPF.LIVEDATE;
        }
        //End
    }

    initProposal(caseId, policyNo) {
        let udn = this._aus.getUserDn();
        let uname = this._aus.getUserName();
        let uroles = this._aus.getUserRoles();
        let uwuser = this._aus.isUnderWriterUser();
        let component = this._routeParams.snapshot.params['component'];
        let boData = this._appObjService.initData(caseId, policyNo, component);

        let dataComplete = Rx.Observable.zip(udn, uname, uroles, boData, uwuser, (usrdn: any, usrname: any, urols: any, busObj: any, uwUserCheck) => { return { usrdn: usrdn, usrname: usrname, urols: urols, busObj: busObj, uwUserCheck: uwUserCheck } });

        dataComplete.subscribe((data) => {
            this.setUserId(data.usrdn);
            this.userRoles = data.urols;
            this.loggedInUser = data.usrname;
            this.initVars(data.busObj);
            BMSConstants.setApprovalStatus(data.uwUserCheck);
            BMSConstants.setQuotationCompleted();
            BMSConstants.emptyRTObj();
            BMSConstants.setMainObjDetailsForRT(this._routeParams.snapshot.params['caseID'], "RT");
            this.validateAsyncPostingStatus();
            this.isformDataReady = true;
            // For Process History related issue
            this._aus.getUserFullName(this.loggedInUser).subscribe((data) => {
                this.userFullName = data;
                BMSConstants.setUserName(data);
                if (this.baseModuleLoaded == false) {
                    this.loadModules();
                    this.baseModuleLoaded = true;
                }
            });
            // E1001 Start
            if((this.isformDataReady == true && (this.appObj.ApplicationBusinessObject.caseInfo.status == 'Appeal to BU SMT'||this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.isApprovedBySMT=='true'||this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.appealBUSMTForm)))
            jQuery( "#MyAccounts" ).css("min-height", "980px");
            //E1001 End
        });
        
    }

    private loadModules() {
        let ctrlInput = new DCLInput();
        ctrlInput.component = ["ControlAreaComponent", "app/bms/components/proposal/process/controlarea.module", "ControlAreaModule"];
        ctrlInput.viewContainerRef = this.cntrlArea;
        ctrlInput.inputs = { appObj: this.appObj };

        this._dcl.loadComponent(ctrlInput).subscribe((compRef) => {
            if (compRef.instance.setFormMode != null) {
                compRef.instance.setFormMode.subscribe((values) => {
                    this.setFormDisabled(values);
                });
            }

            if (compRef.instance.onBeforeCancel != null) {
                compRef.instance.onBeforeCancel.subscribe((values) => {
                    this.cancelPosting();
                });
            }

            if (compRef.instance.onBeforePost != null) {
                compRef.instance.onBeforePost.subscribe((values) => {
                    this.onBeforePost(values)
                });
            }

            if (compRef.instance.onAfterPost != null) {
                compRef.instance.onAfterPost.subscribe((values) => {
                    //this.onAfterPost(values)
                });
            }

            if (compRef.instance.refreshAttachment != null) {
                compRef.instance.refreshAttachment.subscribe((values) => {
                    //this.refreshAttachment(values)
                });
            }

        });

        let rtIinput = new DCLInput();
        rtIinput.component = ["RiskTableComponent", "app/bms/components/proposal/proposalheader/uimodules/risktable.module", "RiskTableModule"];
        rtIinput.viewContainerRef = this.rtArea;
        rtIinput.inputs = { risks: this.risks, headerInfo: this.proposalHeader, product: this.proposalHeader.contractType, clientDetails: this.bmsObject.newBusiness.clientDetails, status: this.caseInfo.status, caseInfo: this.caseInfo };
        this._dcl.loadComponent(rtIinput).subscribe((componentRef) => {
            if (componentRef) {
                this.riskTableObject = componentRef;
                componentRef.instance.onRiskSelect.subscribe((compRef) => {
                    this.riskObj = compRef;

                });
                componentRef.instance.onRiskRemove.subscribe((compRef) => {
                    this.riskObj = compRef;
                });
            }
        });

        this.loadHD();//added to load Header first for Simplified Process
    }

    validateAsyncPostingStatus() {
        if (this.isAsyncValidationRequired)
            if (this.proposalHeader.asyncPostingStatus == "InProgress") {
                this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Posting in progress. Please check the status later. Editing information is not allowed until risk is posting is completed.", -1));
            } else if (this.proposalHeader.asyncPostingStatus == "Failed") {
                this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Posting Failed. Please correct data and try posting again. <br/>Posting Error Message is: " + this.proposalHeader.asyncPostingMessage, -1));
            }
    }

    attachmentAdded(callerObject) {
        this.caseInfo.attachmentChange(callerObject, this.userFullName);
        this._appObjService.saveData().subscribe();
    }

    attachmentAddedMisc(callerObject) {
        let miscCaseInfo = BMSConstants.getRTBMSCaseInfo();
        miscCaseInfo.attachmentChange(callerObject, this.userFullName);
        this._appObjService.saveRTData().subscribe();
    }

    setFormDisabled(set: boolean) {
        this.disableForm = set;
    }

    cancelPosting() {
        this.ncd.cancelNCD().success((data) => {
            this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "NCD cancelled for this risk", 5000));
        })
            .error((response, status, errorText) => {
                this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "NCD cancel failed,Please try again", -1));
            });
    }

    onBeforePost(event) {
        if (this.proposalHeader.policyIssued && this.proposalHeader.policyIssued === "true") {
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Policy already posted in P400 system", -1));
            return;
        }
        else if (this.proposalHeader.policyIssued && this.caseInfo.status === "Pending NB") {
            this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "This policy requires RI from P400 system", -1));
            return;
        }
        else {
            this.postToP400(this.caseInfo.caseId);
        }
    }

    private postToP400(caseId) {
        //Below condition added by Rajesh to support asynchronous posting to P400. 
        //New web service has been added to BMS integration project
        ProgressBarComponent.show('Posting to P400 is in Progress', { dialogSize: 'm', progressType: 'primary' });
        if (["NGA", "PMA", "PMB", "PMR", "MSW", "MWP", "MPA", "PAS", "FHG", "FHI", "FSI", "HIG", "HII", "EMC"].indexOf(this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.contractType) >= 0) {
            this.proposalHeader.asyncPostingMessage = "";
            this.proposalHeader.asyncPostingStatus = "";
            this._postingService.postNBCaseAsync().subscribe(data => this.AsyncPostToP400SuccessHandler(data),
                error => this.AsyncPostToP400ErrorHandler(error));

        } else {
            this._postingService.postNBCase().subscribe(data => this.postToP400SuccessHandler(),
                errorMsg => this.postToP400ErrorHandler(errorMsg));
        }
    }

    private AsyncPostToP400SuccessHandler(data) {
        if (!data.fault) {
            //Close the progress bar
            if (data.HeaderPosting_Status.text) {
                if (data.HeaderPosting_Status.text == "SUCCESS") {
                    this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Header Posted Successfully. Risk Posting in Progress. Check status later.", -1));
                } else if (data.HeaderPosting_Status.text == "SKIPPED") {
                    this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Header Already Posted. Risk Posting in Progress. Check status later.", -1));
                } else {
                    if (data && data.Posting_Messages && data.Posting_Messages.text)
                        this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Post to P400 failed due to : " + data.Posting_Messages.text, -1));
                    else
                        this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Post to P400 failed.", -1));
                }

                this.isAsyncValidationRequired = false;
                this.initProposal(this.caseInfo.caseId, null);
            }
            ProgressBarComponent.hide();
        }
    }

    //private AsyncPostToP400ErrorHandler(response, status, errorText, extraParams) {
    private AsyncPostToP400ErrorHandler(error) {
        //Close the progress bar
        ProgressBarComponent.hide();
        this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Post to P400 failed due to : " + error.responseJSON.faultstring.text, -1));
    }

    private postToP400SuccessHandler() {
        ProgressBarComponent.hide();
        let header = BMSConstants.getBMSHeaderInfo();
        if (header.isPendingNB == "true") {
            if ("FIR" == header.lineOfBusiness || "MIS" == header.lineOfBusiness || "WCE" == header.lineOfBusiness || "TPI" == header.contractType || (["TAA", "TDA", "TDI", "TPI"].indexOf(header.contractType) != -1 && !header.masterPolicy))
                this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Policy is moved to 'P400 Pending NB' state.", -1));
            else
                this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Policy is moved to 'P400 Pending NB' state due to RI or Co Insurance.", -1));
        }
        else {
            this._cordysService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", this.getLOVDataParamsForTxNo(), this.getLOVDataTxNoSuccessHandler, null, false, { comp: this });
            this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Policy is moved to 'P400 Pending NB' state.", -1));
            this._caMailService.sendManuscriptMail('true').subscribe();
            this._caMailService.sendFacRIMail("ISD", "").subscribe();
        }


        this._controlAService.setActionLisByStatus().subscribe();

    }

    private getLOVDataParamsForTxNo() {
        var requestObj = new GetLOVData();
        requestObj.BRANCH = 'ALL';
        requestObj.LOB = 'ALL';
        requestObj.BUSINESS_FUNCTION = 'NEW BUSINESS';
        requestObj.PRODUCT = 'ALL';
        requestObj.OPERATION = 'ALL';
        requestObj.FORM_NAME = 'DESPATCH INFO';
        requestObj.FORM_FIELD_NAME = 'Transaction Number';
        requestObj.FIELD_TYPE = 'LOV';
        requestObj.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        requestObj.ADVANCE_CONFIG_XML.FILTERS = new Filter();

        requestObj.ADVANCE_CONFIG_XML.FILTERS.FILTER = [
            {
                "@FIELD_NAME": 'CHDRNUM',
                "@FIELD_VALUE": this.appObj.ApplicationBusinessObject.caseInfo.policyNumber,
                '@OPERATION': 'EQ',
                '@CONDITION': 'AND'
            },
            {
                "@FIELD_NAME": 'CURRFROM',
                "@FIELD_VALUE": this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.effectiveDate.replace(/-/g, ""),
                '@OPERATION': 'EQ',
                '@CONDITION': 'AND'
            }
        ];

        return requestObj;
    }

    private getLOVDataTxNoSuccessHandler(response, prms) {
        if (response.tuple) {
            if (response.tuple.old && response.tuple.old.CHDR.TRANNO != "") {
                prms.comp.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.transactionNumber = response.tuple.old.CHDR.TRANNO;
            }
        }
    }

    private postToP400ErrorHandler(error) {
        ProgressBarComponent.hide();
        this._controlAService.setActionLisByStatus().subscribe()
        this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Post to P400 failed due to : " + error, -1));
    }

    private loadCL() {
        if (this.isCLLoaded == false) {
            let input = new DCLInput();
            input.component = ["ChangeLogComponent", "app/common/components/changelog/changelog.module", "ChangeLogModule"];
            input.viewContainerRef = this.clArea;
            input.inputs = { _changeLogs: this.appObj.ApplicationBusinessObject.caseInfo.auditTrail };
            this._dcl.loadComponent(input).subscribe(() => {
                this.isCLLoaded = true;
            });
        }
    }

    private loadPH() {
        if (this.isPHLoaded == false) {
            if (this.caseInfo.businessFunction == 'MiscCN')
                this.loadPHMisc();
            else
                this.loadPHNB();
        }
    }

    private loadPHNB() {
        if (this.isPHLoaded == false) {
            let input = new DCLInput();
            input.component = ["ProcessHistoryComponent", "app/bms/components/common/processhistory/processhistory.module", "ProcessHistoryModule"];
            input.viewContainerRef = this.phArea;
            input.inputs = { approvalNodes: this.appObj.ApplicationBusinessObject.caseInfo.approvalInfo };
            this._dcl.loadComponent(input).subscribe(() => {
                this.isPHLoaded = true;
            });
        }
    }

    private loadPHMisc() {
        if (this.isPHLoaded == false) {
            let policyNo = BMSConstants.getBMSCaseInfo().policyNumber;
            this._appObjService.getRTCaseForPolicy(policyNo).subscribe(() => {
                let input = new DCLInput();
                input.component = ["ProcessHistoryComponent", "app/bms/components/common/processhistory/processhistory.module", "ProcessHistoryModule"];
                input.viewContainerRef = this.phArea;
                let miscCaseInfo = BMSConstants.getRTBMSCaseInfo();
                input.inputs = { approvalNodes: miscCaseInfo.approvalInfo };
                this._dcl.loadComponent(input).subscribe(() => {
                    this.isPHLoaded = true;
                });
            });
        }
    }

    private loadAT() {
        if (this.isATLoaded == false) {
            if (this.caseInfo.businessFunction == 'MiscCN')
                this.loadATMisc();
            else
                this.loadATNB();
        }
    }

    private loadATNB() {
        if (this.isATLoaded == false) {
            let input = new DCLInput();
            input.component = ["AttachmentComponent", "app/common/components/attachment/attachment.module", "AttachmentModule"];
            input.viewContainerRef = this.atArea;
            input.inputs = { CurrentUser: this.userID, setRoles: this.userRoles, branch: this.caseInfo.handlingBranchId, isCMS: false, lob: this.caseInfo.lineOfBusiness, _attachments: this.caseInfo.attachmentInfoDisp, caseInfo: this.caseInfo };
            this._dcl.loadComponent(input).subscribe((compRef) => {
                if (compRef.instance.saveBO != null) {
                    compRef.instance.saveBO.subscribe((values) => {
                        this.attachmentAdded(values);
                    });
                }
                this.isATLoaded = true;
            });
        }
    }

    private loadATMisc() {
        if (this.isATLoaded == false) {
            let policyNo = BMSConstants.getBMSCaseInfo().policyNumber;
            this._appObjService.getRTCaseForPolicy(policyNo).subscribe(() => {
                let input = new DCLInput();
                input.component = ["AttachmentComponent", "app/common/components/attachment/attachment.module", "AttachmentModule"];
                input.viewContainerRef = this.atArea;

                let miscCaseInfo = BMSConstants.getRTBMSCaseInfo();

                input.inputs = { CurrentUser: this.userID, setRoles: this.userRoles, branch: this.caseInfo.handlingBranchId, isCMS: false, lob: this.caseInfo.lineOfBusiness, _attachments: miscCaseInfo.attachmentInfoDisp, caseInfo: miscCaseInfo };
                this._dcl.loadComponent(input).subscribe((compRef) => {
                    if (compRef.instance.saveBO != null) {
                        compRef.instance.saveBO.subscribe((values) => {
                            this.attachmentAddedMisc(values);
                        });
                    }
                    this.isATLoaded = true;
                });
            });
        }
    }

    private loadTD() {
        if (this.isTDLoaded == false) {
            let input = new DCLInput();
            input.component = ["TransactionDetailsComponent", "app/bms/components/proposal/enquiry/transactiondetails/transactiondetails.module", "TransactionDetailsModule"];
            input.viewContainerRef = this.tdArea;
            input.inputs = { policyno: this.caseInfo.policyNumber, caseId: this.caseInfo.caseId };
            this._dcl.loadComponent(input).subscribe(() => {
                this.isTDLoaded = true;
            });
        }
    }

    private loadHD() {
        if (this.isHDLoaded == false) {
            let input = new DCLInput();
            input.component = ["ProposalHeaderComponent", "app/bms/components/proposal/proposalheader/proposalheader.module", "ProposalHeaderModule"];
            input.viewContainerRef = this.hdArea;
            input.inputs = { proposal: this.bmsObject, proposalHeader: this.proposalHeader, caseInfo: this.caseInfo };
            this._dcl.loadComponent(input).subscribe((compRef) => {
                this.isHDLoaded = true;
                compRef.instance.onproductchange.subscribe((compRef) => {
                    this.riskObj = null;
                });
                compRef.instance.onpoichange.subscribe((compRef) => {
                    if (this.riskObj)
                        this.setTotalPremium();
                });
            });
        }
    }

    private loadAPSMT() {
        if (this.isAPSMTLoaded == false) {
            let input = new DCLInput();
            input.component = ["AppealtoBUSMTComponent", "app/bms/components/proposal/process/appealtobusmt.module", "AppealtoBUSMTModule"];
            input.viewContainerRef = this.apsmtArea;
            input.inputs = { appObj: this.appObj };
            this._dcl.loadComponent(input).subscribe((compRef) => {
                this.isAPSMTLoaded = true;
            });
        }
    }

    addRiskCoverage() {
        let riskCoverageItem = new RiskCoverage();
        riskCoverageItem.seqNumber = this.riskObj.riskCoverageDetails.riskCoverage.length + 1;

        this.riskObj.riskCoverageDetails.riskCoverage.push(riskCoverageItem);
    }

    validateTextInput(ev) {
        let eVal = ev.target.value;
        ev.target.value = eVal.replace(/\s\s+/g, ' ');
    }

    addXT(coverItem) {
        var dialogData = new ExtraTextDialogData("ExtraTextDialogComponent", "app/bms/components/proposal/newbusinessrisks/dialogs/extratext.dialog.module", "ExtraTextDialogModule", "Extra Text", "ExtraText", "fa fa-comment", coverItem, this.extraTextCallBack);
        this.openExtraTextCommentsDialog(dialogData);
    }

    public openExtraTextCommentsDialog(dialogData: ExtraTextDialogData, response?: any) {
        let lookup = new ModalInput();
        lookup.component = [dialogData.component, dialogData.moduleAbsPath, dialogData.moduleName];
        lookup.datainput = {
            dialogName: dialogData.dialogName,
            areCommentsMandatory: false,
            coverageItem: dialogData.coverageItem
        };
        lookup.outputCallback = dialogData.callBackHandler;
        lookup.parentCompPRMS = {
            comp: this,
            response: response
        };
        lookup.heading = dialogData.dialogTitle;
        lookup.icon = dialogData.icon;
        lookup.containerRef = this.contentArea;
        this._dcl.openLookup(lookup);
    }

    private extraTextCallBack(data, prms) {
        if (data.isDialogCancelled) {
            return;
        } else if (!data.isDialogCancelled && data.coverageItem && data.coverageItem.extraText) {
        }
    }
    setValue(customeFeilds) {
        let CurrencyValue = customeFeilds.value;
        CurrencyValue = (CurrencyValue == null || CurrencyValue == "") ? 0.00 : CurrencyValue;
        if (CurrencyValue != 0.00) {
            customeFeilds.value = numeral(numeral(CurrencyValue).format(this.premiumFormat)).value();
        }

    }
    setPremium(coverItem) {
        let si: any = coverItem.sumInsured;
        let rate: any = coverItem.rate;
        let iLoad: any = coverItem.load;

        si = (si == null || si == "") ? 0 : si;
        rate = (rate == null || rate == "") ? 0 : parseFloat(rate);
        // iLoad  = (iLoad == null || iLoad == "") ? 0 : parseFloat(iLoad);

        if (si != 0 && rate != 0) {
            let cpremium = (si * (rate)) / 100;
            coverItem.premium = numeral(numeral(cpremium).format(this.premiumFormat)).value();
            // coverItem.premium = ((coverItem.premium * iLoad)/100) + coverItem.premium; 			
        } else {
            coverItem.premium = 0.00;
        }

        this.setTotalPremium();
    }




    setTotalPremium() {
        this.riskObj.totalSI = this.getTotalByProperty("sumInsured", this.riskObj.riskCoverageDetails.riskCoverage, this.siFormat);
        this.riskObj.grossPremium = this.getTotalByProperty("premium", this.riskObj.riskCoverageDetails.riskCoverage, this.premiumFormat);

        this.riskObj.originalTotalPremium = numeral(numeral(this.riskObj.grossPremium).format(this.premiumFormat)).value();

        this.riskObj.rebateAmount = numeral(numeral((parseFloat("" + numeral(this.riskObj.grossPremium).value()) * parseFloat("" + this.riskObj.rebate)) / 100).format(this.premiumFormat)).value();

        let discountedPrem = numeral(numeral(parseFloat("" + numeral(this.riskObj.grossPremium).value()) - parseFloat("" + numeral(this.riskObj.rebateAmount).value())).format(this.premiumFormat)).value();
        this.riskObj.discountedPremium = discountedPrem;

        //this.riskObj.gstAmount = numeral(numeral((discountedPrem * parseInt(""+this.riskObj.GST))/100).format(this.premiumFormat)).value();	
        //SST Code
        let tempGSTAmount = numeral(numeral((discountedPrem * parseInt("" + this.riskObj.GST)) / 100).format(this.premiumFormat)).value();
        this.riskObj.gstAmount = numeral(numeral(BMSUtilService.calculatePremiumAmount(tempGSTAmount, "G")).format(this.premiumFormat)).value();
        let tempSSTAmount = numeral(numeral((discountedPrem * parseInt("" + this.riskObj.SST)) / 100).format(this.premiumFormat)).value();
        this.riskObj.sstAmount = numeral(numeral(BMSUtilService.calculatePremiumAmount(tempSSTAmount, "S")).format(this.premiumFormat)).value();

        //let _totalPremium = parseFloat(""+numeral(discountedPrem).value()) + parseFloat(""+numeral(this.riskObj.gstAmount).value());
        let _totalPremium = parseFloat("" + numeral(discountedPrem).value()) + parseFloat("" + numeral(this.riskObj.gstAmount).value()) + parseFloat("" + numeral(this.riskObj.sstAmount).value());
        //End
        this.riskObj.totalPremium = numeral(numeral(_totalPremium).format(this.premiumFormat)).value();

        this.riskObj.capitalSumInsured = this.riskObj.totalSI;

        //this.onPremiumChange.emit(this.riskObj.totalPremium);		
        this.riskTableObject._component.rtRisksInfo.currentRiskObj.basePostedPremiumAdj
        this.riskTableObject._component.resetAllPremTotal();

    }

    getTotalByProperty(prop, ary, format: string) {
        let total = 0;
        for (let eachItem of ary) {
            if (eachItem[prop] != null && eachItem[prop] != "")
                total = total + parseFloat(numeral(eachItem[prop]).value());
        }
        if (format != null)
            return numeral(numeral(total).format(format)).value();
        else
            return total;
    }

    removeRiskCover(coverItem) {
        let _idx = this.riskObj.riskCoverageDetails.riskCoverage.indexOf(coverItem);
        this.riskObj.riskCoverageDetails.riskCoverage.splice(_idx, 1);
        this.resetCoverageItemNumber();
        this.setTotalPremium();
    }

    resetCoverageItemNumber() {
        for (let _riskCoverage of this.riskObj.riskCoverageDetails.riskCoverage) {
            let index = this.riskObj.riskCoverageDetails.riskCoverage.indexOf(_riskCoverage);
            _riskCoverage.seqNumber = (index + 1);
        }
    }


    addCustomField() {
        let customField = new CustomField();
        customField.seqNumber = this.riskObj.customFields.customField.length + 1;

        this.riskObj.customFields.customField.push(customField);
    }

    removeCustomField(customField) {
        let _idx = this.riskObj.customFields.customField.indexOf(customField);
        this.riskObj.customFields.customField.splice(_idx, 1);
        this.resetCustomFieldsItemNumber();
    }

    resetCustomFieldsItemNumber() {
        for (let _customField of this.riskObj.customFields.customField) {
            let index = this.riskObj.customFields.customField.indexOf(_customField);
            _customField.seqNumber = (index + 1);
        }
    }
    private validateAmount(event, i) {
        if (event.target.value != '') {
            let amountFormatted = numeral(event.target.value).format('0,0.00');
            this.riskObj.customFields.customField[i].value = amountFormatted;

        } else {

            this.riskObj.customFields.customField[i].value = 0;
        }
        return true;
    }

    private scrollTop() {
        jQuery("body,html").animate({ scrollTop: 0 }, 800);
    }


}