import { EventHandler } from '../../../../common/services/eventhandler';

export var BMSEvents: any = {};

const eventList = [];

const eventGroupList = [{
    "name": "ProposalBeforeP400",
    "init": ["GrpP400SaveStTrigger"],
    "complete": ["onGrpP400SaveEnd"],
    "events": [
        ["NCDStartTrigger", "onNCDStart", "T"],
        ["NCDEndTrigger", "onNCDEnd", "L"],
        ["ClientCreationStartTrigger", "onClientCreationStart", "T"],
        ["ClientCreationEndTrigger", "onClientCreationEnd", "L"]
    ]
}];
export class BMSEventHandler extends EventHandler {
    constructor() { super(BMSEvents, eventList); super.handleEventGroups(BMSEvents, eventGroupList); }
}