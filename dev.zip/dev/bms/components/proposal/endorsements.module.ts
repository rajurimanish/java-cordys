import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';
import { BasicUIModule } from '../../../common/components/utility/basicui.module';
import { PaginationModule } from '../../../common/components/utility/pagination/pagination.module';
import { LovModule } from '../../../common/services/lovdropdown/lov.module';
import { BMSServiceModule } from '../../services/bmsservice.module';
import { EndorsementsComponent } from './endorsements.component';
import { BMSEventHandler } from './events/bms.events';
import { RIServiceModule } from './newbusinessrisks/services/ri.module';
import { CAMailServiceModule } from './process/services/camail.service.module';
import { ReferenceServiceModule } from './proposalheader/service/reference.service.module';
import { ReferenceModule } from './proposalheader/uimodules/reference.module';
import { NCDModule } from './newbusinessrisks/motorcommercial/handler/ncd.module';
import { RiskClassificationServiceModule } from './newbusinessrisks/services/riskcls.module';

const routerConfig: Routes = [
    { path: "Edit", component: EndorsementsComponent },
    { path: "", component: EndorsementsComponent }
];

@NgModule({
    imports: [CommonModule, FormsModule, ReactiveFormsModule, RouterModule.forChild( routerConfig ), LovModule, BMSServiceModule,
        NCDModule, RiskClassificationServiceModule, RIServiceModule, CAMailServiceModule, BasicUIModule, PaginationModule, ReferenceModule, ReferenceServiceModule],
    declarations: [EndorsementsComponent],
    exports: [RouterModule, EndorsementsComponent]
})

export class EndorsementsModule {
    constructor() {
        new BMSEventHandler();
    }
}