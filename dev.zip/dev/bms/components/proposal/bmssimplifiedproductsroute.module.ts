import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { LovModule } from '../../../common/services/lovdropdown/lov.module';

import { SimplifiedProposalComponent } from './simplifiedproposal.component';
import { CAMailServiceModule } from './process/services/camail.service.module';

import { RIServiceModule } from './newbusinessrisks/services/ri.module';
import { RiskClassificationServiceModule } from './newbusinessrisks/services/riskcls.module';

import { BMSEventHandler } from './events/bms.events';
import { BMSServiceModule } from '../../services/bmsservice.module';
import { NCDModule } from './newbusinessrisks/motorcommercial/handler/ncd.module';
import { BasicUIModule } from '../../../common/components/utility/basicui.module';
import { PaginationModule } from '../../../common/components/utility/pagination/pagination.module';
import { ClausesModule } from './newbusinessrisks/uimodules/clauses.module';
import { GSTModule } from './newbusinessrisks/uimodules/gst.module';
import { ReferenceModule } from './proposalheader/uimodules/reference.module';
import { ReferenceServiceModule } from './proposalheader/service/reference.service.module';

const routerConfig: Routes = [
    { path: "Edit", component: SimplifiedProposalComponent },
    { path: "", component: SimplifiedProposalComponent }
];

@NgModule({
    imports: [CommonModule, FormsModule, ReactiveFormsModule, RouterModule.forChild(routerConfig), LovModule, BMSServiceModule,
        NCDModule, RiskClassificationServiceModule, RIServiceModule, CAMailServiceModule, BasicUIModule, PaginationModule,
        ClausesModule, GSTModule, ReferenceModule, ReferenceServiceModule],
    declarations: [SimplifiedProposalComponent],
    exports: [RouterModule, SimplifiedProposalComponent]
})

export class BMSSimplifiedProductsRouteModule {
    constructor() {
        new BMSEventHandler();
    }
}