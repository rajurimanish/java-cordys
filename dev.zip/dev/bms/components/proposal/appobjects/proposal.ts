/*
Change History	:

	No      Date          Description                               					    Changed By
	====    ==========    ===========                              						    ==========						 
					  								   
	KA001  18/10/2018    MYS-2018-0896    -  To save Premium Details	               		  DKA
	E1004  31/12/2018    MYS-2018-0844    -  Incorrect risk number	               		      SRE1 
*/
import { ProposalHeader } from '../proposalheader/appobjects/proposalheader';
import { ClientDetails } from '../../../../common/components/client/appobjects/client';
import { AppUtil, ChangeImpact } from '../../../../common/components/utility/apputil/app.util';
import { RiskFactory } from '../proposalheader/uimodules/riskFactory';
import { RiskArray } from '../proposalheader/uimodules/riskArray';
import { PostedPrem } from '../proposalheader/appobjects/postedprem';
import { BMSUtilService } from '../../../services/bms.util.service';
import { BMSConstants } from '../../common/constants/bms_constants'; // SAF MYS-2017-1108
declare var numeral: any;

export class NewBusiness {
    public headerInfo: ProposalHeader;
    public clientDetails: ClientDetails;
    public risks: Risks;
    constructor() {
        this.headerInfo = new ProposalHeader();
        this.clientDetails = new ClientDetails();
        this.risks = new Risks();
    }
    public getInstance(valObj: NewBusiness) {
        this.headerInfo = new ProposalHeader().getInstance(valObj.headerInfo);
        this.headerInfo.appealBUSMTForm = valObj.headerInfo.appealBUSMTForm;// added code for issue 1823.
        this.clientDetails = new ClientDetails().getInstance(valObj.clientDetails);
        this.risks = new Risks().getInstance(valObj.risks);
        this.headerInfo.extraDetails = valObj.headerInfo.extraDetails;
        return this;
    }

    //Endorsements Code
    public getInstanceforENCA( valObj: NewBusiness ) {
        this.headerInfo = new ProposalHeader().getInstance( valObj.headerInfo );
        this.headerInfo.appealBUSMTForm = valObj.headerInfo.appealBUSMTForm;
        this.clientDetails = new ClientDetails().getInstance( valObj.clientDetails );
        this.risks = new Risks().getInstanceforENCA( valObj.risks );
        this.headerInfo.extraDetails = valObj.headerInfo.extraDetails;
        return this;
    }  // End

    public getNewMiscInstance() {
        this.headerInfo = new ProposalHeader().getNewMiscInstance();
        this.clientDetails = null;
        this.risks = null;
        return this;
    }

    public getMiscInstance(valObj: NewBusiness) {
        this.headerInfo = new ProposalHeader().getMiscInstance(valObj.headerInfo);
        this.clientDetails = null;
        this.risks = null;
        return this;
    }

    public resetAllPremCalc() {
		//Added below condition for Endorsements Code
        if ( BMSConstants.getBMSCaseInfo().businessFunction != "Endorsements" && BMSConstants.getBMSCaseInfo().businessFunction != "Cancellations" && BMSConstants.getBMSCaseInfo().businessFunction != "Reinstatement") {
            let allRisks = this.risks.getRisksByPriority();
            this.setTaxCalculation( allRisks );
            this.setTotalPremium( allRisks );
            this.setPostedPremium( allRisks );
            this.setTotalDiscountedPremium( allRisks );
        }      
    }

    public setTaxCalculation(allRisks) {
        if (this.headerInfo.isVPMS == "N")
            this.risks.resetTax(allRisks, this.headerInfo.rebate);
    }

    public setPostedPremium(allRisks) {
        this.risks.resetPostedPremium(null);
        this.headerInfo.setPPTotal(allRisks);
        this.headerInfo.setNetPostedPremTotal(this.risks.getTotalNetPostedPrem());
    }

    public setTotalDiscountedPremium(allRisks) {
        let totalDisPrem = new AppUtil().getTotalByProperty("discountedPremium", allRisks, AppUtil.getPremFormat());
        this.headerInfo.totalDiscountedPremium = totalDisPrem.nonFormatted;
    }

    public setTotalPremium(allRisks) {
        let totalPrem = new AppUtil().getTotalByProperty("totalPremium", allRisks, AppUtil.getPremFormat());
        this.headerInfo.originalTotalPremium = totalPrem.nonFormatted;
        this.headerInfo.totalPremium = numeral(numeral(parseInt("" + this.headerInfo.stampDuty) + totalPrem.nonFormatted).format(AppUtil.getPremFormat())).value();
    }

    public getAllReferredReasons() {
        let headerReasons = this.headerInfo.getReferredReason();
        let riskReasons = this.risks.getReferredReason();

        let allReasons = [];
        if (headerReasons.length > 0)
            allReasons.push({ riskNumber: "HEADER", reasons: headerReasons });
        allReasons = allReasons.concat(riskReasons);
        return allReasons;
    }

    public refreshClassification(newValObj: NewBusiness) {
        this.headerInfo.refreshClassification(newValObj.headerInfo);
        this.risks.refreshClassification(newValObj.risks);
    }
}

export class Risks {
    public driverPersonalAccident = [];
    public motorMCV = [];
    public motorMPV = [];
    public individualPersonalAccident = [];
    public fireIDC = [];
    public fireLOP = [];
    public s4804 = [];
    public s4805 = [];
    public s4808 = [];
    public s4810 = [];
    public s4811 = [];
    public s4846 = [];
    public s4857 = [];
    public s4851 = [];
    public s4861 = [];
    public s5335 = [];
    public s5381 = [];
    public s6271 = [];
    public s5183 = [];
    public travel = [];
    public generic = [];

    public getInstance(valObj: Risks) {
        if (new AppUtil().isValidObj(valObj) == true) {
            let risknames = Object.keys(valObj);
            for (let riskname of risknames) {
                new AppUtil().handleArray(this, valObj, riskname);
                for (let eachRisk of this[riskname]) {
                    let riskObj = new RiskFactory().getOldRiskObj(eachRisk.riskType, eachRisk)
                    this[riskname][this[riskname].indexOf(eachRisk)] = riskObj;
                }
            }
        }
        return this;
    }

    //Endorsements Code
    public getInstanceforENCA( valObj: Risks ) {
        if ( new AppUtil().isValidObj( valObj ) == true ) {
            let risknames = Object.keys( valObj );
            for ( let riskname of risknames ) {
                new AppUtil().handleArray( this, valObj, riskname );
                for ( let eachRisk of this[riskname] ) {
                    //let riskObj = new RiskFactory().getOldENCARiskObj( eachRisk.riskType, eachRisk )
                    if ( riskname == "generic" ) {
                        let riskObj = new RiskFactory().getOldENCARiskObj( "ANY", eachRisk );
                        this[riskname][this[riskname].indexOf( eachRisk )] = riskObj;
                    }
                }
            }
        }
        return this;
    }//End

    getAllRisks(valObj: Risks) {
        let allRisks = [];
        let currentRisks = valObj;
        allRisks = allRisks.concat(currentRisks.individualPersonalAccident, currentRisks.motorMCV, currentRisks.motorMPV, currentRisks.driverPersonalAccident, currentRisks.fireIDC, currentRisks.fireLOP, currentRisks.travel, currentRisks.s4846, currentRisks.s4811, currentRisks.s5335, currentRisks.s4804, currentRisks.s4805, currentRisks.s4808, currentRisks.s4857, currentRisks.s4851, currentRisks.s4810, currentRisks.s4861, currentRisks.s5381, currentRisks.s6271, currentRisks.s5183, currentRisks.generic);
        allRisks = allRisks.filter(function (riskItem) {
            return (riskItem != null);
        });
        return allRisks;
    }

    setContractNumber(oldValObj: Risks, newValObj: Risks) {
        let oldRiskList = this.getAllRisks(oldValObj);
        let newRiskList = new Risks().getInstance(newValObj).getAllRisks(newValObj);
        for (let risk of oldRiskList) {
            let selectedRiskList = newRiskList.filter((eachRisk) => eachRisk.riskNumber == risk.riskNumber);
            if (selectedRiskList != null && selectedRiskList.length > 0) {
                risk.contractNumber = selectedRiskList[0].contractNumber;
            }
        }
    }

    clear() {
        let risknames = Object.keys(this);
        for (let riskname of risknames) {
            this[riskname] = [];
        }
    }

    handleInceptionChange() {
        let risks = this.getAllRisks(this);
        let message = "";
        for (let risk of risks) {
            let changeImpact = new ChangeImpact();
            if (risk.handleInceptionChange != null)
                risk.handleInceptionChange();
            if (changeImpact.isChanged == true && changeImpact.itemChanged.length > 0) {
                message = message + "Risk " + risk.riskNumber + ":<br/>";
                for (let item of changeImpact.itemChanged) {
                    message = message + item.message + "<br/>";
                }
            }
        }
        message = (message == "") ? message : "Inception date change has impacted below. <br/>" + message;
        return message;
    }

    checkInceptionChangeImpact() {

    }

    canHaveVPMSCalculator() {
        let risks = this.getAllRisks(this);
        if (risks.length == 0)
            return 'Y';

        let oldRisks = risks.filter((risk) => risk.premiumInfo == null);
        if (oldRisks.length == 0)
            return 'Y';
        else
            return 'N';
    }

    getRisksCount() {
        let allRisks = this.getAllRisks(this);
        return allRisks.length;
    }

    public resetPostedPremium(risk) {
        let clearAdjPrem = false;
        let risks = (risk == null) ? this.getAllRisks(this) : [risk];
		/*let lineofBusiness = BMSConstants.getBMSCaseInfo().lineOfBusiness;//SAF MYS-2017-1108, MYS-2018-0896(commented the below code to allow Premium adjustment for all types of LOBs)
		if(lineofBusiness != 'PA' && risks.length > 1) //SAF MYS-2017-1108-- 
		//if(risks.length > 1)
			clearAdjPrem = true;*/
        for (let riskObj of risks) {
            /*	if(clearAdjPrem == true)  //SAF MYS-2018-0896 commented this code
                    riskObj.basePostedPremiumAdj = 0;*/

            let postedPrem = new PostedPrem().getPostedPremDetails(riskObj, riskObj.basePostedPremiumAdj);
            riskObj.postedPremium = postedPrem.totalPrem;
            riskObj.postedPremDetails = postedPrem;
        }
    }

    public getTotalNetPostedPrem() {
        let risks = this.getAllRisks(this);
        let totalNetPrem = 0;
        for (let riskObj of risks) {
            totalNetPrem = totalNetPrem + riskObj.postedPremDetails.netPrem;
        }
        return totalNetPrem;
    }

    public clearVPMSCalculation() {
        let risks = this.getAllRisks(this);
        for (let riskObj of risks) {
            if (AppUtil.isEmpty(riskObj.isVPMS, false) == false && riskObj.isVPMS == "Y") {
                if (riskObj.setPremiumInfo != null)
                    riskObj.setPremiumInfo(null, null);
            }
        }
    }

    public getRisksByPriority() {
        let finalList = [];
        let tempRiskList = this.getAllRisks(this);
        finalList = this.getClassifiedList(tempRiskList);
        return finalList;
    }

    public getClassifiedList(riskList) {
        let finalList = [];
        if (riskList != null && riskList.length > 0) {
            let refRisks = riskList.filter((risk) => risk.riskClassification != null && risk.riskClassification == "Referred");
            let nonRefRisks = riskList.filter((risk) => risk.riskClassification == null || (risk.riskClassification != null && risk.riskClassification != "Referred"));
            finalList = finalList.concat(refRisks, nonRefRisks);
        }
        return finalList;
    }


    public setRiskNumberByPriority() {
        //let finalList = [];
        let tempRiskList = this.getAllRisks(this);
        if (tempRiskList != null && tempRiskList.length > 0) {
            let priorityRisks = tempRiskList.filter((risk) => AppUtil.isEmpty(risk.priority, false) == false);
            let nonPriorityRisks = tempRiskList.filter((risk) => AppUtil.isEmpty(risk.priority, false) == true);

            let totalNoRisks = tempRiskList.length;
            let position = 1;

            while (priorityRisks.length != 0) {
                let priorityVal = this.getMinValByProperty(priorityRisks, 'priority');
                let risks = priorityRisks.filter((risk) => risk.priority == priorityVal);
                position = this.setRiskNumberByPosition(risks, position);
                //finalList = finalList.concat(risks);
                priorityRisks = priorityRisks.filter((risk) => risk.priority != priorityVal);
            }

            this.setRiskNumberByPosition(nonPriorityRisks, position);
            //finalList = finalList.concat(nonPriorityRisks);
        }
        //finalList = this.getClassifiedList(finalList);
        //return finalList;
    }

    public setRiskNumberForNewItems() {
        let tempRiskList = this.getAllRisks(this);
        let tempNewRiskList = tempRiskList.filter((risk) => AppUtil.isEmpty(risk.isNew, false) == false && risk.isNew == "Y");
        if (tempNewRiskList.length > 0) {
            let position = this.getNextRiskNumberForNewItems();
            this.setRiskNumberByPosition(tempNewRiskList, position);
        }
    }

    // E1004 - Start
	public getNextRiskNumberForNewItems() {
		let position: any = "";
		let totalNoOfRisks = AppUtil.isEmpty(BMSConstants.getBMSHeaderInfo().totalNoOfRisks, false) == false ? parseInt(BMSConstants.getBMSHeaderInfo().totalNoOfRisks) : null; // E1004
		let tempRiskList = this.getAllRisks(this);
		let tempNewRiskList = tempRiskList.filter((risk) => AppUtil.isEmpty(risk.isNew, false) == true);
		if (tempNewRiskList.length > 0) {
			let latestPosition = Math.max.apply(null, tempNewRiskList.map(risk => parseInt(risk.riskNumber)));
			if (AppUtil.isEmpty(BMSConstants.getBMSCaseInfo().caseId, false) == false
				&& totalNoOfRisks != null) {
				position = totalNoOfRisks > position ? totalNoOfRisks + 1 : position + 1;
			} else {
				position = "" + (latestPosition + 1);
			}
		} else {
			position = "1";
		}
		return position;
	}
	// E1004 - End
    public setRiskNumberByPosition(risks, position) {
        let pos = position;
        for (let risk of risks) {
            risk.riskNumber = pos;
            pos++;
        }
        return pos;
    }

    public getReferredRisks() {
        let finalList = [];
        let tempRiskList = this.getAllRisks(this);
        if (tempRiskList != null && tempRiskList.length > 0) {
            let refRisks = tempRiskList.filter((risk) => risk.riskClassification != null && (risk.riskClassification == "Referred" || risk.riskClassification == "ReferredCEO" || risk.riskClassification == "ReferredRHC")); // added ReferredCEO & ReferredRHC conditions SAF MYS-2018-0143 .
            finalList = refRisks;
        }
        return finalList;
    }


    public resetTax(allRisks, rebateVal) {
        let risks = allRisks;
        for (let risk of risks) {
            risk.rebate = isNaN(parseFloat(rebateVal)) ? 0 : parseFloat(rebateVal);
            let rebateNF = (parseFloat("" + risk.originalTotalPremium) * parseFloat("" + risk.rebate)) / 100;
            risk.rebateAmount = AppUtil.decFormatNoRound(rebateNF, AppUtil.getPremFormat());
            let discountedPrem = numeral(numeral(parseFloat("" + risk.originalTotalPremium) - parseFloat("" + risk.rebateAmount)).format(AppUtil.getPremFormat())).value();
            risk.discountedPremium = discountedPrem;
            //risk.gstAmount = (parseInt(risk.GST) > 0)?numeral(numeral((discountedPrem*parseInt(risk.GST))/100).format(AppUtil.getPremFormat())).value():0; //SAF MYS-2018-0629
            //SST Code			
            let headerInfo = BMSConstants.getBMSHeaderInfo();
            if (parseInt(risk.GST) == 0 || parseInt(risk.SST) == 0) {
                //let headerInfo = BMSConstants.getBMSHeaderInfo();
                risk.GST = Number(headerInfo.GSTTaxRate);
                risk.SST = Number(headerInfo.SSTTaxRate);
            }

            let tempGSTAmount = (parseInt(risk.GST) > 0) ? numeral(numeral((discountedPrem * parseInt(risk.GST)) / 100).format(AppUtil.getPremFormat())).value() : 0;
            risk.gstAmount = numeral(numeral(BMSUtilService.calculatePremiumAmount(tempGSTAmount, "G")).format(AppUtil.getPremFormat())).value();

            let tempSSTAmount = (parseInt(risk.SST) > 0) ? numeral(numeral((discountedPrem * parseInt(risk.SST)) / 100).format(AppUtil.getPremFormat())).value() : 0;
            if ("MAR" == headerInfo.lineOfBusiness) {
                risk.sstAmount = numeral(numeral(tempSSTAmount).format("0,00.00")).value();
            }
            else if(headerInfo.lobName =='Medical' && headerInfo.insuredType == 'Personal') {//MYS-2018-0878 - SST FIX FOR MEDICAL PRODUCTS
                risk.sstAmount=0;
                risk.SST=0;
            }
            else {
                risk.sstAmount = numeral(numeral(BMSUtilService.calculatePremiumAmount(tempSSTAmount, "S")).format(AppUtil.getPremFormat())).value();
            }


            //risk.totalPremium = numeral(numeral(parseFloat(""+discountedPrem) + parseFloat(""+risk.gstAmount)).format(AppUtil.getPremFormat())).value();
            let tempTotalPrem = numeral( numeral( parseFloat( "" + discountedPrem ) + parseFloat( "" + risk.gstAmount ) + parseFloat( "" + risk.sstAmount ) ).format( AppUtil.getPremFormat() ) ).value();
            //End
            //SAF MYS-2019-0909
            if ( risk.isValidBenefitPlan != undefined && risk.isValidBenefitPlan == "Y"){
                tempTotalPrem = numeral( numeral( parseFloat( "" + discountedPrem ) + parseFloat( "" + risk.gstAmount ) + parseFloat( "" + risk.sstAmount ) + parseFloat( "" + risk.fireItems.benefitPremium )).format( AppUtil.getPremFormat() ) ).value();
            }
            risk.totalPremium = tempTotalPrem;
            //End
        }
    }

    public getReferredReason() {
        let allReasons = [];
        let referredRisks = this.getReferredRisks();
        for (let risk of referredRisks) {
            if (risk.getReferredReason != null)
                allReasons.push({ riskNumber: "Risk No: " + risk.riskNumber, reasons: risk.getReferredReason() });
        }
        return allReasons;
    }

    public refreshClassification(newValObj: Risks) {
        let newRisks = this.getAllRisks(newValObj);
        let allRisks = this.getRisksByPriority();
        for (let risk of allRisks) {
            if (risk.refreshClassification != null)
                risk.refreshClassification(newRisks.filter((eachRisk) => eachRisk.riskNumber == risk.riskNumber)[0]);
        }
    }

    public getNextRiskNumber() {
        let allRisks = this.getRisksByPriority();
        if (allRisks.length > 0)
            return "" + (1 + Math.max.apply(null, allRisks.map(risk => parseInt(risk.riskNumber))));
        else
            return "1";
    }

    public getMinValByProperty(risks, property) {
        if (risks.length > 0)
            return Math.min.apply(null, risks.map(risk => parseInt(risk[property])));
        else
            return -1;
    }
}