import { ReferredReason, Reason } from '../proposalheader/appobjects/referredreason';
import { AppUtil } from '../../../../common/components/utility/apputil/app.util';

export abstract class RiskHelper {
    abstract riskClassification: string;
    abstract symRiskClassification: string;
    abstract riskClassificationReason: string;
    abstract riskClassificationReasons: ReferredReason;
    abstract childRiskPath: string;
    abstract childRiskIdentity: string;
    public getReferredReason() {
        let reasons = [];
        let newReason = new Reason();

        newReason.reason = "Reasons from risk number : " + this["riskNumber"];
        reasons.push(newReason);

        if (this.symRiskClassification != "Referred" && this.riskClassification == "Referred" && AppUtil.isEmpty(this.riskClassificationReason, false) == false) {
            let rclReason = new Reason();
            rclReason.reason = this.riskClassificationReason;
            newReason.reasons.push(rclReason);
        }
        else {
            if (this.symRiskClassification == "Referred" && AppUtil.isEmpty(this.riskClassificationReason, false) == false && this.riskClassificationReasons.reasons.reason.length == 0) {
                let symRsnAry: any = [{ reason: this.riskClassificationReason }];
                newReason.reasons = symRsnAry;
            }
            else {
                let rsnAry: any = this.riskClassificationReasons.reasons.reason.map((reason) => { return { reason: reason } });
                newReason.reasons = rsnAry;
            }
        }

        if (this.hasChildRisks() == true)
            this.fillChildReasons(newReason);

        if (this.isChildRisk() == true)
            return newReason.reasons;
        else
            return reasons;
    }

    public fillChildReasons(newReason) {
        let childRisks = AppUtil.getValueByPath(this, this.childRiskPath);
        for (let risk of childRisks) {
            if (risk.riskClassification == "Referred") {
                let riskReason = risk.getReferredReason();
                let subRiskReason = new Reason();
                subRiskReason.reason = "Reasons from sub risk item " + risk[risk.childRiskIdentity];
                subRiskReason.reasons = subRiskReason.reasons.concat(riskReason);
                newReason.reasons.push(subRiskReason);
            }
        }
    }

    public hasChildRisks() {
        if (this.childRiskPath != null)
            return true;
        else
            return false;
    }

    public isChildRisk() {
        if (AppUtil.isEmpty(this.childRiskIdentity, false) == false)
            return true;
        else
            return false;
    }

    public refreshClassification(newValObj: any) {
        this.symRiskClassification = newValObj.symRiskClassification;
        this.riskClassification = newValObj.riskClassification;
        this.riskClassificationReason = newValObj.riskClassificationReason;

        this.riskClassificationReasons.refresh(newValObj.riskClassificationReasons);
        if (this.symRiskClassification == "Referred" || this.symRiskClassification == "Declined" || this.symRiskClassification == "ReferredCEO" || this.symRiskClassification == "ReferredRHC") // added ReferredCEO & ReferredRHC conditions SAF MYS-2018-0143 .
            this.riskClassificationReason = this.riskClassificationReasons.getCombinedReason();

        if (this.hasChildRisks() == true) {
            let childRisks = AppUtil.getValueByPath(this, this.childRiskPath);
            let newChildRisks = new AppUtil().getArray(AppUtil.getValueByPath(newValObj, this.childRiskPath));
            for (let risk of childRisks) {
                risk.refreshClassification(newChildRisks.filter((eachRisk) => eachRisk[risk.childRiskIdentity] == risk[risk.childRiskIdentity])[0]);
            }
        }
    }
}