export interface NBRisk {
    basePostedPremiumAdj: number;
    isPOIConsidered: string;
    priority: string;
    getInstance(valObj: any);
    getNewInstanceByCriteria(criteria: any);
    getValidator();
}