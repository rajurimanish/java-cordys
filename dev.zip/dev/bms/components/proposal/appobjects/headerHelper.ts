import { ReferredReason, Reason } from '../proposalheader/appobjects/referredreason';
import { AppUtil } from '../../../../common/components/utility/apputil/app.util';

export abstract class HeaderHelper {
    abstract isReferredRisk: string;
    abstract isHeaderReferred: string;
    abstract riskClassificationReasons: ReferredReason;
    abstract isReferredRiskUI: boolean;
    public getReferredReason() {
        let reasons = [];
        if (this.riskClassificationReasons.reasons.reason.length > 0) {
            let newReason = new Reason();
            newReason.reason = "Reasons from Header";
            reasons.push(newReason);

            let rsnAry: any = this.riskClassificationReasons.reasons.reason.map((reason) => { return { reason: reason } });
            newReason.reasons = rsnAry;
        }

        return reasons;
    }

    public refreshClassification(newValObj: any) {
        this.isReferredRisk = newValObj.isReferredRisk;
        if (this.isReferredRisk == "true")
            this.isReferredRiskUI = true;
        else
            this.isReferredRiskUI = false;

        this.isHeaderReferred = newValObj.isHeaderReferred;
        this.riskClassificationReasons.refresh(newValObj.riskClassificationReasons);
    }
}