import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { EventEmitter, Output, ViewChild, ViewContainerRef } from "@angular/core";
import { AdvancedSearchInput } from '../../../../../common/components/advancedsearchgrid/advancedsearchgridinput';
import { GetLOVData, SearchAdvancedConfig, Filter } from '../../../../../common/components/utility/search/search.requests';
import { AlertMessage } from '../../../../../common/components/utility/alertmessage/alertmessages.model';
import { AppUtil } from '../../../../../common/components/utility/apputil/app.util';
import { ModalInput } from "../../../../../common/components/utility/modal/modal";
import { CustomDCLService, DCLInput } from "../../../../../common/services/customdcl.service";
import { ApplicationUtilService } from '../../../../../common/services/application.util.service';


declare var numeral: any;

@Component({
    selector: 'bancaEnquiry',
    templateUrl: 'app/bms/components/proposal/enquiry/banca/bancaEnquiry.template.html'
})

export class BancaEnquiryComponent implements OnInit {
    private advancedSearchInput: AdvancedSearchInput = new AdvancedSearchInput();
    @ViewChild('APIAreaModal', { read: ViewContainerRef }) contentArea: ViewContainerRef;
    constructor(private _router: Router, public dcl: CustomDCLService, private _appUtilService: ApplicationUtilService) {
    }

    ngOnInit() {

        this.advancedSearchInput.advancedFilterOptnsArry = { "LIKE": "LIKE", "EQ": "EQ", ">": "GT", ">=": "GTEQ", "<": "LT", "<=": "LTEQ" };
        this.advancedSearchInput.onColumnDataBind = this._appUtilService.transformValue;
        this.advancedSearchInput.isActionsHiddenFunction = this.checkHidden;
    }

    private checkHidden(app, action, report) {
        if (action.hiddenWhen != undefined && action.hiddenWhen.indexOf(report.status) > -1) {
            return false;
        }
        return true;

    }

    private onActionClick(event) {
        switch (event.action) {
            default: break;
        }
    }
}
