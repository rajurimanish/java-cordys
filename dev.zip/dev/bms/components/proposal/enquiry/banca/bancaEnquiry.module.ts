import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BancaEnquiryComponent } from './bancaEnquiry.component';
import { AdvancedSearchGridModule } from '../../../../../common/components/advancedsearchgrid/advancedsearchgrid.module';



const webRouterConfig: Routes = [
    { path: "", component: BancaEnquiryComponent }
];

let routerConfig = webRouterConfig;

@NgModule({
    imports: [CommonModule, FormsModule, ReactiveFormsModule, RouterModule.forChild(routerConfig), AdvancedSearchGridModule],
    declarations: [BancaEnquiryComponent],
    exports: [BancaEnquiryComponent, AdvancedSearchGridModule, RouterModule]
})
export class BancaEnquiryModule { }