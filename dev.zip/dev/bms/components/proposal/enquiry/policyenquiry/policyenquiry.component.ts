import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { AdvancedSearchInput } from '../../../../../common/components/advancedsearchgrid/advancedsearchgridinput';
import { GetLOVData, SearchAdvancedConfig, Filter } from '../../../../../common/components/utility/search/search.requests';
import { AlertMessage } from '../../../../../common/components/utility/alertmessage/alertmessages.model';
declare var numeral: any;
@Component({
    selector: 'policy-enquiry',
    templateUrl: 'app/bms/components/proposal/enquiry/policyenquiry/policyenquiry.template.html'
})

export class PolicyEnquiryComponent implements OnInit {
    private advancedSearchInput: AdvancedSearchInput = new AdvancedSearchInput();
    constructor(private _router: Router) {
    }

    ngOnInit() {

        this.advancedSearchInput.advancedFilterOptnsArry = { "LIKE": "LIKE", "EQ": "EQ", ">": "GT", ">=": "GTEQ", "<": "LT", "<=": "LTEQ" };
        this.advancedSearchInput.onColumnDataBind = this.transformValue;
        this.advancedSearchInput.getRecordsCount = this.getTotalSearchRecordsCount;
    }
    private getTotalSearchRecordsCount(input, prm) {
        var requestObj = new GetLOVData();
        requestObj.BRANCH = 'ALL';
        requestObj.LOB = 'MTR';
        requestObj.BUSINESS_FUNCTION = 'NEW BUSINESS';
        requestObj.PRODUCT = 'MTR';
        requestObj.OPERATION = 'NEW';
        requestObj.FORM_NAME = 'POLICY_ENQUIRY';
        requestObj.FORM_FIELD_NAME = 'Policy Enquiry Count';
        requestObj.FIELD_TYPE = 'LOV';
        requestObj.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        requestObj.ADVANCE_CONFIG_XML.FILTERS = new Filter();
        requestObj.ADVANCE_CONFIG_XML.FILTERS.FILTER = [];

        requestObj.ADVANCE_CONFIG_XML = input.ADVANCE_CONFIG_XML;

        //input.FORM_NAME='RENEWAL_ENQ_COUNT';     
        //input.FORM_FIELD_NAME = 'RENEWAL_ENQ_COUNT';
        let recordsCountResponse = prm._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", requestObj, null, null, true, null);
        recordsCountResponse.success((data) => {
            if (data.tuple) {
                prm.recordsCount = data.tuple.old.TABLE.VALUE;
            }
        });
        recordsCountResponse.error((response, status, errorText) =>
            prm._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error while calling LOV service " + errorText, -1)));

    }
    private transformValue(value, listItem) {
        let siFormat: string = '0,0.00';
        /* if(listItem=="Sum Insured" && value !=""){
              return numeral(value).format(siFormat);
         }*/
        if (listItem == "Premium" && value != "") {
            return numeral(value).format('0,0.00');
        }

        else return value;
    }

    private onActionClick(event) {
        switch (event.action) {
            case "dblclick":
                if (event.item.VERSION != 'Simplified') {
                    this._router.navigate(["Proposal/Edit", { caseID: event.item.CASE_ID, viewmode: true, component: "PolicyEnquiry" }]);
                }
                else {
                    this._router.navigate(["SimplifiedProposal/Edit", { caseID: event.item.CASE_ID, viewmode: true, component: "PolicyEnquiry" }]);
                }


                break;
            default: break;
        }
    }
}
