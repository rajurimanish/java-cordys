import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AdvancedSearchInput } from '../../../../../common/components/advancedsearchgrid/advancedsearchgridinput';
import { ApplicationUtilService } from '../../../../../common/services/application.util.service';

@Component({
    selector: 'covernote-enquiry',
    templateUrl: 'app/bms/components/proposal/enquiry/covernoteenquiry/covernoteenquiry.template.html'
})

export class CoverNoteEnquiryComponent implements OnInit {
    private advancedSearchInput: AdvancedSearchInput = new AdvancedSearchInput();
    constructor(private _router: Router, private _appUtilService: ApplicationUtilService) {
    }

    ngOnInit() {
        this.advancedSearchInput.advancedFilterOptnsArry = { "LIKE": "LIKE", "EQ": "EQ", ">": "GT", ">=": "GTEQ", "<": "LT", "<=": "LTEQ" };
        this.advancedSearchInput.onColumnDataBind = this._appUtilService.transformValue;
    }

    private onActionClick(event) {
        switch (event.action) {
            case "dblclick":
                if (event.item.REQUEST_TYPE == "CoverNote") {
                    this._router.navigate(["Proposal/Edit", { caseID: event.item.caseId, viewmode: true, type: event.item.coverNoteType, component: "CoverNoteEnquiry" }]);
                } else if (event.item.REQUEST_TYPE == "MiscCN") {
                    this._router.navigate(["Proposal/Edit", { caseID: event.item.caseId, policyNo: event.item.policyNumber, viewmode: true, type: event.item.coverNoteType, component: "CoverNoteEnquiry" }]);
                }
                break;
            default: break;
        }
    }
}
