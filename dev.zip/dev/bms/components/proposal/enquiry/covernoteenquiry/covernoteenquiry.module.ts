import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CoverNoteEnquiryComponent } from './covernoteenquiry.component';
import { AdvancedSearchGridModule } from '../../../../../common/components/advancedsearchgrid/advancedsearchgrid.module';



const webRouterConfig: Routes = [
    { path: "", component: CoverNoteEnquiryComponent }
];

let routerConfig = webRouterConfig;

@NgModule({
    imports: [CommonModule, FormsModule, ReactiveFormsModule, RouterModule.forChild(routerConfig), AdvancedSearchGridModule],
    declarations: [CoverNoteEnquiryComponent],
    exports: [CoverNoteEnquiryComponent, AdvancedSearchGridModule, RouterModule]
})
export class CoverNoteEnquiryModule { }