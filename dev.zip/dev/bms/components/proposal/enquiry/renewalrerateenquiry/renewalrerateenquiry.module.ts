import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RenewalRerateEnquiryComponent } from './renewalrerateenquiry.component';
import { AdvancedSearchGridModule } from '../../../../../common/components/advancedsearchgrid/advancedsearchgrid.module';



const webRouterConfig: Routes = [
    { path: "", component: RenewalRerateEnquiryComponent }
];

let routerConfig = webRouterConfig;

@NgModule({
    imports: [CommonModule, FormsModule, ReactiveFormsModule, RouterModule.forChild(routerConfig), AdvancedSearchGridModule],
    declarations: [RenewalRerateEnquiryComponent],
    exports: [RenewalRerateEnquiryComponent, AdvancedSearchGridModule, RouterModule]
})

export class RenewalRerateEnquiryModule { }