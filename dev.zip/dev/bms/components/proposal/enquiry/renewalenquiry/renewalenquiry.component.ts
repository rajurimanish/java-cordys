import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AdvancedSearchInput } from '../../../../../common/components/advancedsearchgrid/advancedsearchgridinput';
import { ApplicationUtilService } from '../../../../../common/services/application.util.service';

@Component({
    selector: 'newbusiness-enquiry',
    templateUrl: 'app/bms/components/proposal/enquiry/renewalenquiry/renewalenquiry.template.html'
})

export class RenewalEnquiryComponent implements OnInit {
    private advancedSearchInput: AdvancedSearchInput = new AdvancedSearchInput();
    constructor(private _router: Router, private _appUtilService: ApplicationUtilService) {
    }

    ngOnInit() {
        this.advancedSearchInput.advancedFilterOptnsArry = { "LIKE": "LIKE", "EQ": "EQ", ">": "GT", ">=": "GTEQ", "<": "LT", "<=": "LTEQ" };
        this.advancedSearchInput.onColumnDataBind = this._appUtilService.transformValue;
    }

    private onActionClick(event) {
        switch (event.action) {
            case "dblclick":
                if (event.item.caseId.startsWith("RN")) {
                    let isSimplifiedProcess = (event.item.version == 'Simplified') ? 'Y' : 'N';
                    let component = this._appUtilService.getNavigationComponent("BMS", event.item.caseId, isSimplifiedProcess);
                    this._router.navigate([component, { caseID: event.item.caseId, component: "RenewalEnquiry" }]);
                }
                break;
            default: break;
        }
    }
}
