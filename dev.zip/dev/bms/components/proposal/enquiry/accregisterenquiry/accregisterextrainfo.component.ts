import { Component, ViewChild, ViewContainerRef, EventEmitter, OnInit, ElementRef } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

declare var numeral: any;

@Component({
    selector: 'accregister-enquiry',
    templateUrl: 'app/bms/components/proposal/enquiry/accregisterenquiry/accregisterextrainfo.template.html'
})

export class AccRegisterExtraInfoComponent implements OnInit {
    public datainput: any;
    public parentCompPRMS: any;
    public closeDialog: Function;

    private accRegisterObj: any = {};

    constructor(private _router: Router) { }

    ngOnInit() {
        this.accRegisterObj = this.datainput.resAccRegisterObj;
        // formatted values
        this.accRegisterObj.formattedExposerQuotAccepted = numeral(this.accRegisterObj.ExposerQuotAccepted.text).format("0,0");
        this.accRegisterObj.formattedHoldCoverExposer = numeral(this.accRegisterObj.HoldCoverExposer.text).format("0,0");
        this.accRegisterObj.formattedGAL = numeral(this.accRegisterObj.GAL.text).format("0,0");
        this.accRegisterObj.formattedP400InforcedExposer = numeral(this.accRegisterObj.P400InforcedExposer.text).format("0,0");
        this.accRegisterObj.formattedTotalExposer = numeral(this.accRegisterObj.TotalExposer.text).format("0,0");
        this.accRegisterObj.formattedOutstanding = numeral(this.accRegisterObj.Outstanding.text).format("0,0");
        this.accRegisterObj.formattedcessionOutwords = numeral(this.accRegisterObj.cessionOutwords.text).format("0,0");
        this.accRegisterObj.formattedtotGR = numeral(this.accRegisterObj.TOTGR.text).format("0,0");
        this.accRegisterObj.formattedtotMNR = numeral(this.accRegisterObj.TOTMNR.text).format("0,0");
        this.accRegisterObj.formattedtotFAC = numeral(this.accRegisterObj.TOTFAC.text).format("0,0");
        this.accRegisterObj.formattedtotTREATY = numeral(this.accRegisterObj.TOTTREATY.text).format("0,0");
        this.accRegisterObj.formattedLimitMNR = numeral(this.accRegisterObj.LIMITMNR.text).format("0,0");
        this.accRegisterObj.formattedLimitFAC = numeral(this.accRegisterObj.LIMITFAC.text).format("0,0");
        this.accRegisterObj.formattedLimitTREATY = numeral(this.accRegisterObj.LIMITTREATY.text).format("0,0");
        this.accRegisterObj.formattedLimitNet = numeral(this.accRegisterObj.LIMITNET.text).format("0,0");

        this.accRegisterObj.totalPercentage = (Number(this.accRegisterObj.TotalExposer.text) * 100) / Number(this.accRegisterObj.GAL.text);

        if (this.accRegisterObj.totalPercentage < 0) {
            this.accRegisterObj.totalPercentage = -(Number(this.accRegisterObj.totalPercentage));
        }
        if (Number(this.accRegisterObj.GAL.text) > 0) {
            this.accRegisterObj.formattedGALPercentage = numeral(this.accRegisterObj.totalPercentage).format("00.00");
        } else {
            this.accRegisterObj.totalPercentage = 0;
            this.accRegisterObj.formattedGALPercentage = numeral(this.accRegisterObj.totalPercentage).format("00.00");
        }
    }
}