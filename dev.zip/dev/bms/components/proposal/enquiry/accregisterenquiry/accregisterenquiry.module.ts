import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AccRegisterEnquiryComponent } from './accregisterenquiry.component';
import { AccRegisterExtraInfoComponent } from './accregisterextrainfo.component';

import { SelectBoxModule } from '../../../../../common/components/utility/selectbox/selectbox.module';
import { NumberModule } from '../../../../../common/components/utility/number/number.module';
import { PaginationModule } from '../../../../../common/components/utility/pagination/pagination.module';
import { AccuRegSearchFilter } from '../accregisterenquiry/pipes/searchfilter.pipe';
import { AccuRegSortPipe } from '../accregisterenquiry/pipes/sortarray.pipe';
import { DatePickerModule } from '../../../../../common/components/utility/date/datepicker.module';

const webRouterConfig: Routes = [
    { path: "", component: AccRegisterEnquiryComponent }
];

let routerConfig = webRouterConfig;

@NgModule({
    imports: [CommonModule, FormsModule, ReactiveFormsModule, RouterModule.forChild(routerConfig), SelectBoxModule, NumberModule, PaginationModule, DatePickerModule],
    declarations: [AccRegisterEnquiryComponent, AccRegisterExtraInfoComponent, AccuRegSearchFilter, AccuRegSortPipe],
    exports: [AccRegisterEnquiryComponent, AccRegisterExtraInfoComponent, AccuRegSearchFilter, AccuRegSortPipe]
})

export class AccRegisterEnquiryModule { }