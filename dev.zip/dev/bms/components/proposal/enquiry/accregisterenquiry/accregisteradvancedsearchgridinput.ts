export class AccRegisterAdvancedSearchInput {
    public onColumnDataBind: any;
    public onRowBind: any;
    public isActionsEnableFunction: any;
    public searchFilter: any;
    public getRecordsCount: any;
    public advancedFilterOptnsArry: any;
    public bindHover: any;
    public getRowClass: any;
    constructor() {

    }
}