import { Pipe, PipeTransform } from '@angular/core';

@Pipe({ name: 'searchfilter' })
export class AccuRegSearchFilter implements PipeTransform {
    transform(items: any[], args: any[]): any {
        if (!Array.isArray(items) || !Array.isArray(args)) return items;
        if (args[0] === '' || args[0] === undefined) return items;

        return items.filter(item => this.checkArray(item, args[0], args[1]));
    }
    checkArray(item, searchString, searchableFields) {
        if (searchableFields === undefined) {
            for (let i in item) {
                if (item[i] != null && item[i].toString().toLowerCase().indexOf(searchString.toLowerCase()) !== -1)
                    return item;
            }
        }
        else {
            for (let sField of searchableFields) {
                if (item[sField] != null && item[sField].toString().toLowerCase().indexOf(searchString.toLowerCase()) !== -1)
                    return item;
            }
        }
    }
}