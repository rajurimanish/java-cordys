import { Pipe, PipeTransform } from '@angular/core';

@Pipe({ name: 'sortarray' })
export class AccuRegSortPipe implements PipeTransform {
    transform(_array: Array<any>, args: string[]): any {
        let sfield: string = args[0];
        if (sfield === '' || sfield === undefined) return _array;
        let order = (args[1]) ? -1 : 1;
        if (!_array || args[0] === '' || args[0] === undefined) return _array;
        _array.forEach((item, index) => {
            item.origOrder = index;
        });
        _array.sort((a: any, b: any) => {
            if ((isNaN(parseFloat(a[sfield])) || !isFinite(a[sfield])) || (isNaN(parseFloat(b[sfield])) || !isFinite(b[sfield]))) {
                if (a[sfield].toLowerCase() > b[sfield].toLowerCase()) return 1 * order;
                else if (a[sfield].toLowerCase() < b[sfield].toLowerCase()) return -1 * order;
                else return a.origOrder - b.origOrder;
            }
            else {
                if (parseFloat(a[sfield]) < parseFloat(b[sfield])) return -1 * order;
                else if (parseFloat(a[sfield]) > parseFloat(b[sfield])) return 1 * order;
                else return parseFloat(a.origOrder) - parseFloat(b.origOrder);
            }
        });
        return _array;
    }
}