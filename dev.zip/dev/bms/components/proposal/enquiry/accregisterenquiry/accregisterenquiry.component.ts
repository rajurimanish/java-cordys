import { Component, ViewChild, ViewContainerRef, EventEmitter, OnInit, AfterViewInit, ElementRef } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { CordysSoapWService } from '../../../../../common/components/utility/cordys-soap-ws';
import { ApplicationUtilService } from '../../../../../common/services/application.util.service';
import { AlertMessagesService } from '../../../../../common/components/utility/alertmessage/alertmessages.service';
import { AlertMessage } from '../../../../../common/components/utility/alertmessage/alertmessages.model';
import { AppUtil } from '../../../../../common/components/utility/apputil/app.util';
import 'rxjs/add/operator/catch';
import { AccRegisterAdvancedSearchInput } from './accregisteradvancedsearchgridinput';
import { GetLOVData, SearchAdvancedConfig, Filter } from '../../../../../common/components/utility/search/search.requests';
declare var Observer: any;
import { ModalInput } from "../../../../../common/components/utility/modal/modal";
import { CustomDCLService } from '../../../../../common/services/customdcl.service';

@Component({
    selector: 'accregister-enquiry',
    templateUrl: 'app/bms/components/proposal/enquiry/accregisterenquiry/accregisterenquiry.template.html'
})

export class AccRegisterEnquiryComponent implements OnInit {

    // pagination
    public search: String = "";
    public position = 1;
    public sizeObj = { length: 0, orglength: 0 };
    public contentSizeObs: any;
    public itemPerPage = 10;
    public maxPageCount = 10;

    public sortasc: Boolean = true;
    public sortColumnName = '';

    private postalCode: string;
    private accumulationRegister: string;
    private city: string;
    private cityName: string;
    private locality: string;
    public AccRegList: AccumulationRegister[];
    private fireCaseDetailsNodes = [];
    private resAccRegisterObj: any;
    private recordsCount = 0;
    public accRegCtrl: any;
    private dateNotif: any;
    private _serverdate: string;
    private effectiveDate: any;
    private effectiveDateCTRL: any;

    @ViewChild('accRegisterModal', { read: ViewContainerRef }) contentArea: ViewContainerRef;

    constructor(public dcl: CustomDCLService, private _soapService: CordysSoapWService, private _router: Router,
        public _alertMsgService: AlertMessagesService) { }

    ngOnInit() {

    }

    private postCodeEnterHandler(event) {
        if (event.keyCode == 13) {
            this.getPostCodeInfo(event);
            return;
        }
    }
    private accEnterHandler(event) {
        if (event.keyCode == 13) {
            this.searchBackEnd();
            return;
        }
    }

    private initDateNotif(event) {

        this.dateNotif = event;
        var currentDateEndTime = ApplicationUtilService.getFormattedDate(this._serverdate, "YYYY-MM-DDTHH:mm:ss", "DD/MM/YY") + " 23:59";
        this.dateNotif.setMaxDateTime(currentDateEndTime, this.dateNotif.comp);

    }


    // Accumulation Register code
    getPostCodeInfo(event) {
        if (this.postalCode != "" && this.postalCode != undefined) {
            let request: GetLOVData = new GetLOVData().getRequest('ALL', 'FIRE', 'NEW BUSINESS', 'ALL', 'NEW', 'FIRE_IDC', 'PostCode', 'LOV');
            request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
            request.ADVANCE_CONFIG_XML.FILTERS = new Filter();

            request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({ "@FIELD_NAME": 'DESCITEM', "@FIELD_VALUE": this.postalCode, '@OPERATION': 'EQ', '@CONDITION': 'AND' });
            this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.setPostCodeInfo, this.handleError, true, { comp: this, postCode: this.postalCode });
        }
    }

    setPostCodeInfo(response, prms) {
        if (response.tuple != null) {
            prms.comp.city = response.tuple.old.DESCPF.SHORTDESC;
            prms.comp.cityName = response.tuple.old.DESCPF.LONGDESC;
            prms.comp.setAccRegInfo();
            prms.comp.locality = "";
            //prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Please select Accumulation Register." ,8000));
        }
        else {
            prms.comp.city = "";
            prms.comp.cityName = "";
            prms.comp.resetValues();
        }
    }

    handleError(response, status, errorText, prms) {
        prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, response.responseJSON.faultstring.text, -1));
    }

    setAccRegInfo() {
        //this.clearAccReg();
        this.setAccumulationRegister();
    }

    resetValues() {
        this.postalCode = "";
        this.accumulationRegister = "";
        this.city = "";
        this.cityName = "";
        this.locality = "";
        this.recordsCount = 0;
        this.fireCaseDetailsNodes = [];
        this.resAccRegisterObj = "";
        this.AccRegList = [];
        this.accRegCtrl.setter("", this.accRegCtrl.comp);
        this.effectiveDateCTRL.setter("EMPTY", "YYYY-MM-DD", this.effectiveDateCTRL.comp);
        this.effectiveDate = "";
    }

    setAccumulationRegister() {
        let request: GetLOVData = new GetLOVData();
        request.BRANCH = 'ALL';
        request.LOB = 'FIRE';
        request.BUSINESS_FUNCTION = 'NEW BUSINESS';
        request.PRODUCT = 'ALL';
        request.OPERATION = 'NEW';
        request.FORM_NAME = 'FIRE_IDC';
        request.FORM_FIELD_NAME = 'ACCREG';
        request.FIELD_TYPE = 'LOV';
        request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        request.ADVANCE_CONFIG_XML.FILTERS = new Filter();

        request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({ "@FIELD_NAME": 'ZTOWNCODE', "@FIELD_VALUE": this.city, '@OPERATION': 'EQ', '@CONDITION': 'AND' }, { "@FIELD_NAME": 'PCODE', "@FIELD_VALUE": this.postalCode, '@OPERATION': 'EQ', '@CONDITION': 'AND' });
        this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.setAccuRegHandler, this.handleError, true, { comp: this });
    }

    setAccuRegHandler(response, prms) {
        let ary = [];

        if (response.tuple != null && !Array.prototype.isPrototypeOf(response.tuple)) {
            ary = [response.tuple];
        }
        else if (response.tuple != null) {
            ary = response.tuple;
        }
        prms.comp.AccRegList = [];
        for (let item of ary) {
            let accReg: AccumulationRegister = {
                "accRegCode": item.old.FACM.FREG,
                "accRegDesc": item.old.FACM.FDESC,
                "locality": item.old.FACM.LOCREG
            };
            prms.comp.AccRegList.push(accReg);
        }
    }

    setAccReg(values) {
        this.locality = values.record.locality;

        /* if(values.value != "" && values.value != "0") {
            this.callAccRegisterFunction();
		} */
    }
    private onDateEffectiveChange(ev) {

        this.effectiveDate = ev;

    }

    searchBackEnd() {
        if (!this.accumulationRegister || this.accumulationRegister == "") {
            this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Please select proper accumulation register.", -1));
            return;
        }
        if (this.accumulationRegister != "" && this.accumulationRegister != "0") {
            this.callAccRegisterFunction();
        }
    }

    callAccRegisterFunction() {
        this._soapService.callCordysSoapService("GetCurrentExposerAccuRegister", "http://schemas.insurance.com/businessobject/1.0/",
            {
                "caseID": "",
                "snedmail": "",
                "AccumulationReg": this.accumulationRegister,
                "PostCode": this.postalCode,
                "LocationCode": this.locality,
                "TotalSI": 0,
                "Branch": "HO",
                "cslAmount": 0,
                "city": this.city,
                "responseType": "2",
                "effectiveDate": this.effectiveDate
            },
            this.setAccRegisterExtraInfoSuccess, this.setAccRegisterInfoError, true, { comp: this });
    }

    setAccRegisterExtraInfoSuccess(response, prms) {

        prms.comp.resAccRegisterObj = response;
        prms.comp.recordsCount = prms.comp.resAccRegisterObj.TotalCount.text;
        if (prms.comp.resAccRegisterObj != undefined) {
            let accRegItem: any = prms.comp.resAccRegisterObj.FIRE_CASE_DETAILS;
            if (accRegItem != undefined && !Array.prototype.isPrototypeOf(accRegItem)) {
                prms.comp.fireCaseDetailsNodes = [];
                prms.comp.fireCaseDetailsNodes.push(accRegItem);
            } else {
                prms.comp.fireCaseDetailsNodes = accRegItem;
            }
        } else {
            prms.comp.fireCaseDetailsNodes = [];
        }
    }

    setAccRegisterInfoError(response, status, errorText, prms) {
        prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error while Calling Accumulation Register service.", 7000));
    }

    public onDoubleClick(event, fireCaseDetailNode): void {
        switch (event.type) {
            case "dblclick":
                if (fireCaseDetailNode.CASE_ID != undefined && fireCaseDetailNode.CASE_ID != "") {
                    this._router.navigate(["Proposal/Edit", { caseID: fireCaseDetailNode.CASE_ID, viewmode: true, component: "AccumulationRegisterEnquiry" }]);
                } else {
                    this._router.navigate(["Proposal/Edit", { policyNo: fireCaseDetailNode.POLICY_NUMBER, viewmode: true, component: "AccumulationRegisterEnquiry" }]);
                }
                break;
            default:
                break;
        }
    }

    public sortColumn(columnName): void {
        this.sortColumnName = columnName.toUpperCase();
        this.sortasc = !this.sortasc;
    }

    public selectedClass(columnName): string {

        return columnName.toUpperCase() == this.sortColumnName ? 'control-label text-center sort-' + this.sortasc : "control-label text-center";
    }

    private viewAccuRegDialog() {


        this._soapService.callCordysSoapService("GetCurrentExposerAccuRegister", "http://schemas.insurance.com/businessobject/1.0/",
            {
                "caseID": "",
                "snedmail": "",
                "AccumulationReg": this.accumulationRegister,
                "PostCode": this.postalCode,
                "LocationCode": this.locality,
                "TotalSI": 0,
                "Branch": "HO",
                "cslAmount": 0,
                "city": this.city,
                "responseType": "",
                "effectiveDate": this.effectiveDate
            },
            this.setAccRegisterInfoSuccess, this.setAccRegisterInfoError, true, { comp: this });
    }

    setAccRegisterInfoSuccess(response, prms) {
        if (!response.fault) {
            let lookup = new ModalInput();
            lookup.component = ["AccRegisterExtraInfoComponent", "app/bms/components/proposal/enquiry/accregisterenquiry/accregisterenquiry.module", "AccRegisterEnquiryModule"];
            lookup.datainput = { isView: true, resAccRegisterObj: response };
            lookup.outputCallback = prms.comp.callbackAccRegisterInfo;
            lookup.parentCompPRMS = { comp: prms.comp };
            lookup.id = "accRegExtraInfoDialog";
            lookup.heading = "Accumulation Register Details";
            lookup.icon = "fa fa-eye";
            lookup.containerRef = prms.comp.contentArea;
            prms.comp.dcl.openLookup(lookup);
        }
    }

    private callbackAccRegisterInfo() { }

    public exportExcel() {

        if (!this.fireCaseDetailsNodes || this.fireCaseDetailsNodes.length == 0) {
            this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "No Records To Download", -1));
            return;
        }

        let input = {
            "soaprequest": {
                "GetCurrentExposerAccuRegister": {
                    "@xmlns": "http://schemas.insurance.com/businessobject/1.0/",
                    "caseID": "",
                    "snedmail": "",
                    "AccumulationReg": this.accumulationRegister,
                    "PostCode": this.postalCode,
                    "LocationCode": this.locality,
                    "TotalSI": 0,
                    "Branch": "HO",
                    "cslAmount": 0,
                    "city": this.city,
                    "responseType": "2"
                }
            },
            "businessObject": "FIRE_CASE_DETAILS",
            "reportname": "AccumulationRegister Enquiry",
            "headerNode": {
                "column": [{
                    "@datatype": "string",
                    "@id": "CASE_ID",
                    "@name": "Case ID"
                },
                {
                    "@datatype": "string",
                    "@id": "POLICY_NUMBER",
                    "@name": "Policy #"
                },
                {
                    "@datatype": "string",
                    "@id": "CONTRACTTYPE",
                    "@name": "Policy Class"
                },
                {
                    "@datatype": "string",
                    "@id": "RISK_TYPE",
                    "@name": "Risk Type"
                },
                {
                    "@datatype": "string",
                    "@id": "RISK_NO",
                    "@name": "Risk #"
                },
                {
                    "@datatype": "string",
                    "@id": "DTEEFF",
                    "@name": "Effective Date"
                },
                {
                    "@datatype": "string",
                    "@id": "DTETER",
                    "@name": "Termination Date"
                },
                {
                    "@datatype": "string",
                    "@id": "TOTSI",
                    "@name": "Total SI"
                }
                    ,
                {
                    "@datatype": "string",
                    "@id": "RISK_MNRB",
                    "@name": "MNRB"
                }
                    ,
                {
                    "@datatype": "string",
                    "@id": "RISK_TREATY",
                    "@name": "Treaty"
                }
                    ,
                {
                    "@datatype": "string",
                    "@id": "RISK_FAC",
                    "@name": "Fac RI"
                },
                {
                    "@datatype": "string",
                    "@id": "RISK_NET",
                    "@name": "Net Retention"
                },
                {
                    "@datatype": "string",
                    "@id": "STATUS",
                    "@name": "Status"
                }


                ]
            }
        }

        this._soapService.callCordysSoapService("GenerateExcelReport", "http://schemas.cordys.com/MSIGWorkflowCommon/ReportUtils", input, null, null, true, null)
            .success((data) => {
                if (data.tuple && data.tuple.old.generateExcelReport.generateExcelReport != 'exception') {
                    window.open("\\" + data.tuple.old.generateExcelReport.generateExcelReport);
                }
            })
            .error((response, status, errorText) => {
                this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error while exporting data to excel. Please contact Administrator", -1));
            })
    }

}

export class AccumulationRegister {
    constructor(
        public accRegCode: string,
        public accRegDesc: string,
        public locality: string
    ) { }
}