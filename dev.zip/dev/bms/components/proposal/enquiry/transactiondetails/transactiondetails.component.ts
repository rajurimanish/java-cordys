import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { CordysSoapWService } from '../../../../../common/components/utility/cordys-soap-ws';
import { ProgressBarComponent } from '../../../../../common/components/utility/progressbar/progressbar.component';
import { AlertMessagesService } from '../../../../../common/components/utility/alertmessage/alertmessages.service';
import { AlertMessage } from '../../../../../common/components/utility/alertmessage/alertmessages.model';
import { AppUtil } from '../../../../../common/components/utility/apputil/app.util';
declare var Observer: any;
@Component({
    selector: 'transactiondetails-enquiry',
    templateUrl: 'app/bms/components/proposal/enquiry/transactiondetails/transactiondetails.template.html',
    inputs: ['policyno','caseId']
})

export class TransactionDetailsComponent implements OnInit {

    public policyno: string;
    public caseId: string;
    public isheaderCollapsedMode: boolean = true;
    public isTableCollapsedMode: boolean = true;
    public transactionDetails = [];
    public tranResp: any = "";
    public commenceDateCtrl: any;
    public renewalDateCtrl: any;
    public billedDateCtrl: any;
    public _appUtil: AppUtil;
    public itemPerPage = 5;//3;
    public maxPageCount = 5;//3;
    public position = 1;
    public sizeObj = { length: 0, orglength: 0 };
    public contentSizeObs: any;
    public isResponse: boolean = false;
    constructor(private _router: Router, private _cordysService: CordysSoapWService, private _alertMsgService: AlertMessagesService) {
        this._appUtil = new AppUtil();
    }

    ngOnInit() {
        this.getTransactionDetails();
    }
    getTransactionDetails() {
        if (this.tranResp == "") {
            //  ProgressBarComponent.show('Please wait...', { dialogSize: 'm', progressType: 'primary' });
            this._cordysService.callCordysSoapService("getTransactionDetails",
                "http://schemas.insurance.com/businessobject/1.0/", { "policyNumber": this.policyno, "caseId": this.caseId }, null, null, true, this )
                .success((data) => {
                    this.isResponse = true;
                    if (!data.response.fault) {
                        this.tranResp = data.response.success;
                        //  this.commenceDateCtrl.setter(this.tranResp.commencementdate,"YYYY-MM-DD",this.commenceDateCtrl.comp);
                        // this.renewalDateCtrl.setter(this.tranResp.renewaldate,"YYYY-MM-DD",this.renewalDateCtrl.comp);
                        // this.billedDateCtrl.setter(this.tranResp.billedto,"YYYY-MM-DD",this.billedDateCtrl.comp);
                        this.transactionDetails = this._appUtil.getArray(data.response.success.transactions.transaction);
                    }
                    else {
                        this.tranResp = new TransactionResponse();
                        this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, data.response.fault.system + " Error while getting Transaction Info.", -1));
                    }
                    //   ProgressBarComponent.hide();
                })
                .error((data) => {
                    this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error while getting Transaction Info.", -1));
                    // ProgressBarComponent.hide();
                });
        }
    }
}
export class TransactionResponse {
    public policyno: string = '';
    public product: string = '';
    public cliientnumber: string = '';
    public clientname: string = '';
    public commencementdate: string = '';
    public renewaldate: string = '';
    public billedto: string = '';
    public noofrisks: string = '';
    public totalSI: string = '';
    constructor() { }
}
