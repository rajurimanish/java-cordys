import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RTEnquiryComponent } from './rtenquiry.component';
import { BMSAppObjServiceModule } from '../../../../services/bmsappobjservice.module';
import { BMSUtilServiceModule } from '../../../../services/bmsutilservice.module';
import { AdvancedSearchGridModule } from '../../../../../common/components/advancedsearchgrid/advancedsearchgrid.module';



const webRouterConfig: Routes = [
    { path: "", component: RTEnquiryComponent }
];

let routerConfig = webRouterConfig;

@NgModule({
    imports: [CommonModule, FormsModule, ReactiveFormsModule, RouterModule.forChild(routerConfig), AdvancedSearchGridModule, BMSAppObjServiceModule, BMSUtilServiceModule],
    declarations: [RTEnquiryComponent],
    exports: [RTEnquiryComponent, AdvancedSearchGridModule, RouterModule]
})
export class RTEnquiryModule {

}