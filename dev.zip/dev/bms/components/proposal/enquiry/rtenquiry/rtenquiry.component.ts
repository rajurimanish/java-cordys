/*
 * Change History	:
 *
 * 	No      Date         Description                                 			                                        Changed By
 *	====    ==========   ===========                                 			                                        ==========	
 *  SM001   15/05/2019  MYS-2018-0846 - Miscellaneous Covernote P400 listing to Vehicle Registration Number Search			SMA1
 * 				 								   
*/


import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AdvancedSearchInput } from '../../../../../common/components/advancedsearchgrid/advancedsearchgridinput';
import { ApplicationUtilService } from '../../../../../common/services/application.util.service';

declare var moment: any;

@Component({
    selector: 'rt-enquiry',
    templateUrl: 'app/bms/components/proposal/enquiry/rtenquiry/rtenquiry.template.html'
})

export class RTEnquiryComponent implements OnInit {
    private advancedSearchInput: AdvancedSearchInput = new AdvancedSearchInput();
    constructor(private _router: Router, private _aus: ApplicationUtilService) {
    }

    ngOnInit() {
        this.advancedSearchInput.advancedFilterOptnsArry = { "LIKE": "LIKE", "EQ": "EQ", ">": "GT", ">=": "GTEQ", "<": "LT", "<=": "LTEQ" };
        this.advancedSearchInput.onColumnDataBind = this._aus.transformValue;
        this.advancedSearchInput.searchFilter = this.getDefaultSearch();
    }

    private getDefaultSearch() {
        let searchFilter = this.createSearchDef();
        searchFilter.FILTER["@FIELD_NAME"] = "CRDATE";
        searchFilter.FILTER["@FIELD_VALUE"] = moment().format("YYYYMMDD");
        searchFilter.FILTER["@OPERATION"] = "GT";
        return searchFilter;
    }
    private createSearchDef() {
        let searchDef = {
            "FILTER": {
                "@FIELD_NAME": "",
                "@FIELD_VALUE": "",
                "@OPERATION": "LIKE",
                "@CONDITION": "AND"
            }
        };
        return searchDef;
    }

    private onActionClick(event) {
        switch (event.action) {
            case "dblclick":
                this._router.navigate(["Proposal/Edit", { policyNo: event.item.CHDRNUM, viewmode: true, component: "MiscCNEnquiry" }]);
                break;
            default:
                break;
        }
    }
}
