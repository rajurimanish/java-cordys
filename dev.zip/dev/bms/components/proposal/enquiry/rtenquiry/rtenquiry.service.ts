import { Injectable } from '@angular/core';
import { CordysSoapWService } from '../../../../../common/components/utility/cordys-soap-ws';
import { BMSConstants } from '../../../common/constants/bms_constants';
import { AlertMessagesService } from '../../../../../common/components/utility/alertmessage/alertmessages.service';
import { AlertMessage } from '../../../../../common/components/utility/alertmessage/alertmessages.model';
import { ProgressBarComponent } from '../../../../../common/components/utility/progressbar/progressbar.component';
import { AppUtil } from '../../../../../common/components/utility/apputil/app.util';

import { RiskArray } from '../../proposalheader/uimodules/riskArray';
import { BMSLOVRequest } from '../../../common/service/lov/bms.lovrequest';

declare var Rx: any;

@Injectable()
export class RTServices {

    private nextRole;
    private nextUserDn;
    private loggedInUser;
    private orgDN;
    public showMultiRisk: boolean = true;
    constructor(private _cordysService: CordysSoapWService, public _alertMsgService: AlertMessagesService) { }

    public createCaseForPolicy(policyNo, busFn) {
        return Rx.Observable.create((observer) => {
            this._cordysService.callCordysSoapService("GetCaseDetailsForPolicy", "http://schemas.insurance.com/businessobject/1.0/", { "POLICY_NO": policyNo, "businessFunction": busFn }, null, null, true, this)
                .success((data) => {
                    observer.next(data.success.ApplicationBusinessObject.caseInfo.caseId);
                })
                .error((response, status, errorText) => {
                    this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, errorText, -1));
                    observer.error("");
                });
        });
    }
}