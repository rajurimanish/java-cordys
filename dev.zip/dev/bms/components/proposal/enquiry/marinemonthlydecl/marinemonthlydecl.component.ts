import { Component, ViewChild, ViewContainerRef, EventEmitter, OnInit, AfterViewInit, ElementRef } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { CordysSoapWService } from '../../../../../common/components/utility/cordys-soap-ws';
import { ApplicationUtilService } from '../../../../../common/services/application.util.service';
import { AlertMessagesService } from '../../../../../common/components/utility/alertmessage/alertmessages.service';
import { AlertMessage } from '../../../../../common/components/utility/alertmessage/alertmessages.model';
import { AppUtil } from '../../../../../common/components/utility/apputil/app.util';
import 'rxjs/add/operator/catch';
import { GetLOVData, SearchAdvancedConfig, Filter } from '../../../../../common/components/utility/search/search.requests';
declare var Observer: any;
import { ModalInput } from "../../../../../common/components/utility/modal/modal";
import { CustomDCLService } from '../../../../../common/services/customdcl.service';
import { SearchInput } from '../../../../../common/components/utility/search/genericsearch';
declare var moment: any;

@Component({
    selector: 'marine-monthlydecl-enquiry',
    templateUrl: 'app/bms/components/proposal/enquiry/marinemonthlydecl/marinemonthlydecl.template.html'
})

export class MarineMonthlyDeclComponent implements OnInit {

    private moc: string;
    private branch: string;
    private clientNo: string;
    private clientName: string;
    private agentNo: string;
    private agentName: string;
    private inceptionDate: any;
    private effectiveDate: any;
    private effectiveDateCTRL: any;

    public branchList: any = [];
    public declPoliciesList: any = [];

    @ViewChild('mocModal', { read: ViewContainerRef }) contentArea: ViewContainerRef;

    constructor(public dcl: CustomDCLService, private _soapService: CordysSoapWService, private _router: Router,
        public _alertMsgService: AlertMessagesService) { }

    ngOnInit() {
        this.getBranchList();
    }

    openMOCLookup() {

        this.resetValues();

        let si = new SearchInput();
        si.BRANCH = 'ALL',
            si.LOB = 'MAR';
        si.BUSINESS_FUNCTION = 'ALL';
        si.PRODUCT = 'ALL';
        si.OPERATION = 'ALL';
        si.FORM_NAME = 'ALL';
        si.FORM_FIELD_NAME = 'Marine Open Cover Enquiry';
        si.FIELD_TYPE = 'LOOKUP';
        si.isSingleSelect = true;

        let input = new ModalInput().get("GenericSearchComponent");
        input.datainput = si;
        input.heading = "Marine Open Cover Search";
        input.icon = "fa fa-file-pdf-o";

        input.containerRef = this.contentArea;

        this.dcl.openLookup(input).subscribe((data) => {
            this.onMocSelect(data);
        });
    }

    private onMocSelect(data) {
        let mocData = data.data[0];
        let _effectiveDate = (mocData.old.WMOCPF.EFFDATE == null || mocData.old.WMOCPF.EFFDATE == "") ? "" : moment(mocData.old.WMOCPF.EFFDATE, "YYYYMMDD").format("YYYY-MM-DD");
        let _inceptionDate = (mocData.old.WMOCPF.CCDATE == null || mocData.old.WMOCPF.CCDATE == "") ? "" : moment(mocData.old.WMOCPF.CCDATE, "YYYYMMDD").format("YYYY-MM-DD");

        this.moc = mocData.old.WMOCPF.MCOVER;
        this.branch = mocData.old.WMOCPF.BRNCOD;
        this.clientNo = mocData.old.WMOCPF.CLNTNUM;
        this.clientName = mocData.old.WMOCPF.CLIENTNAME;
        this.agentNo = mocData.old.WMOCPF.AGNTNUM;
        this.agentName = mocData.old.WMOCPF.AGENTNAME;
        this.effectiveDate = _effectiveDate;
        this.inceptionDate = _inceptionDate;
        if (this.effectiveDateCTRL != null)
            this.effectiveDateCTRL.setter(_inceptionDate, "YYYY-MM-DD", this.effectiveDateCTRL.comp);
    }

    getBranchList() {
        let request: GetLOVData = new GetLOVData();
        request.BRANCH = 'ALL';
        request.LOB = 'ALL';
        request.BUSINESS_FUNCTION = 'ALL';
        request.PRODUCT = 'ALL';
        request.OPERATION = 'ALL';
        request.FORM_NAME = 'ALL';
        request.FORM_FIELD_NAME = 'BranchList';
        request.FIELD_TYPE = 'LOV';
        request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        request.ADVANCE_CONFIG_XML.FILTERS = new Filter();

        this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.setBranchList, this.handleError, true, { comp: this });
    }


    setBranchList(response, prms) {
        let ary = [];

        if (response.tuple != null && !Array.prototype.isPrototypeOf(response.tuple)) {
            ary = [response.tuple];
        }
        else if (response.tuple != null) {
            ary = response.tuple;
        }

        prms.comp.branchList = [];
        for (let item of ary) {
            let _branch = {
                "VALUE": item.old.MSIG_BRANCH_MASTER.VALUE,
                "DESCRIPTION": item.old.MSIG_BRANCH_MASTER.DESCRIPTION
            };
            prms.comp.branchList.push(_branch);
        }
    }

    resetValues() {
        this.moc = '';
        this.branch = '';
        this.clientNo = '';
        this.clientName = '';
        this.agentNo = '';
        this.agentName = '';
        this.inceptionDate = '';
        this.effectiveDate = '';
        if (this.effectiveDateCTRL != null)
            this.effectiveDateCTRL.setter("EMPTY", "YYYY-MM-DD", this.effectiveDateCTRL.comp);

        this.declPoliciesList = [];
    }

    searchBackEnd() {
        if (!this.moc || this.moc == "") {
            this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Please select Marine Open Cover.", -1));
        }
        else {
            this.getMonthlyDeclDetails();
        }
    }

    getMonthlyDeclDetails() {
        let request: GetLOVData = new GetLOVData();
        request.BRANCH = 'ALL';
        request.LOB = 'MAR';
        request.BUSINESS_FUNCTION = 'ALL';
        request.PRODUCT = 'ALL';
        request.OPERATION = 'ALL';
        request.FORM_NAME = 'ALL';
        request.FORM_FIELD_NAME = 'Monthly Declaration Enquiry';
        request.FIELD_TYPE = 'LOV';
        request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        request.ADVANCE_CONFIG_XML.FILTERS = new Filter();

        let filter: any = {};

        request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push(filter, { "@FIELD_NAME": 'A.ZOPNCVRNO', "@FIELD_VALUE": this.moc, '@OPERATION': 'EQ', '@CONDITION': 'AND' });

        this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.setMonthlyDeclList, this.handleError, true, { comp: this });

    }

    setMonthlyDeclList(response, prms) {
        let ary = [];

        if (response.tuple != null && !Array.prototype.isPrototypeOf(response.tuple)) {
            ary = [response.tuple];
        }
        else if (response.tuple != null) {
            ary = response.tuple;
        }

        if (ary.length == 0) {
            prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "No records found for the MOC selected.", 5000));
        }


        prms.comp.declPoliciesList = [];
        //A.ZOPNCVRNO,A.CHDRNO,C.DTEEFF,C.ZMNTH,C.YEAR,C.SUMINS,C.ORGPRM,C.STBILL,C.TORPRM

        for (let _item of ary) {
            let _policyNumber = _item.old.RCGOPF.CHDRNO;
            let _effectiveDate = _item.old.RCGOPF.DTEEFF;
            let _key = _policyNumber + '_' + _effectiveDate;
            _effectiveDate = moment(_effectiveDate, "YYYYMMDD").format("YYYY-MM-DD");
            let _policyItems = prms.comp.declPoliciesList.find((_data) => (_data.key == _key));

            if (_policyItems) {
                let _declItems = prms.comp.createMonthlyDeclEntry(_item);
                _policyItems.declarationDetails.push(_declItems);
            }
            else {
                let _policyItems = {
                    "key": _key,
                    "moc": _item.old.RCGOPF.ZOPNCVRNO,
                    "policyNumber": _item.old.RCGOPF.CHDRNO,
                    "effectiveDate": _effectiveDate,
                    "totalPremium": _item.old.RCGOPF.TORPRM,
                    "totalSI": _item.old.RCGOPF.STBILL,
                    "declarationDetails": []
                };

                let _declItems = prms.comp.createMonthlyDeclEntry(_item);
                _policyItems.declarationDetails.push(_declItems);

                prms.comp.declPoliciesList.push(_policyItems);
            }
        }

    }

    createMonthlyDeclEntry(item) {
        let _declItem = {
            "month": item.old.RCGOPF.ZMNTH,
            "year": item.old.RCGOPF.YEAR,
            "sumInsured": item.old.RCGOPF.SUMINS,
            "grossPremium": item.old.RCGOPF.ORGPRM,
        }

        return _declItem;
    }

    handleError(response, status, errorText, prms) {
        prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, response.responseJSON.faultstring.text, -1));
    }

}

export class AccumulationRegister {
    constructor(
        public accRegCode: string,
        public accRegDesc: string,
        public locality: string
    ) { }
}