import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { SelectBoxModule } from '../../../../../common/components/utility/selectbox/selectbox.module';
import { NumberModule } from '../../../../../common/components/utility/number/number.module';
import { DatePickerModule } from '../../../../../common/components/utility/date/datepicker.module';

import { MarineMonthlyDeclComponent } from './marinemonthlydecl.component';

const webRouterConfig: Routes = [
    { path: "", component: MarineMonthlyDeclComponent }
];

let routerConfig = webRouterConfig;

@NgModule({
    imports: [CommonModule, FormsModule, ReactiveFormsModule, RouterModule.forChild(routerConfig), SelectBoxModule, NumberModule, DatePickerModule],
    declarations: [MarineMonthlyDeclComponent],
    exports: [MarineMonthlyDeclComponent]
})

export class MarineMonthlyDeclEnquiryModule { }