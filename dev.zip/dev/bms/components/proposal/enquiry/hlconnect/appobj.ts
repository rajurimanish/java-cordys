export class SendMail {
    constructor(
        public emailTo?: string,
        public email?: string,
        public emailCc?: string,
        public emailBcc?: string,
        public subject?: string,
        public content?: string,
        public template?: string,
        public isTemplate?: boolean
    ) { }
}