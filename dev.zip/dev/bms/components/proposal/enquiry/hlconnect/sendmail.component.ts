
import { Component, Output, Input, EventEmitter } from "@angular/core";
import { ApplicationService } from '../../../../../common/services/application.service';
import { ChangeDetector } from '../../../../../common/services/changedetector.service';
import { SendMail } from '../hlconnect/appobj';
import { CordysSoapWService } from '../../../../../common/components/utility/cordys-soap-ws';
import { AlertMessagesService } from '../../../../../common/components/utility/alertmessage/alertmessages.service';
import { AlertMessage } from '../../../../../common/components/utility/alertmessage/alertmessages.model';
import { GetLOVData, SearchAdvancedConfig, Filter } from '../../../../../common/components/utility/search/search.requests';
//import {RichTextEditorComponent} from '../richtexteditor/richtexteditor.component';
import { ApplicationUtilService } from "../../../../../common/services/application.util.service";

declare var jQuery: any;

@Component({
    selector: 'sendmail',
    templateUrl: 'app/bms/components/proposal/enquiry/hlconnect/sendmail.template.html',
    inputs: ['datainput', 'parentCompPRMS', 'closeDialog']
})

export class SendMailComponent {
    private APP;
    private PRODUCT;
    private RISK;
    private ORIENTATION;
    private WORKFLOW_STATUS;
    public AttachmentsObj = [];
    public SelectedAttachments = [];
    public templates = [];
    private optionSelected;
    public _sendmail: SendMail;
    private caseId;
    private address = [];
    private emailTemplates = [];
    private responseStatus: any;
    public datainput: any;
    public parentCompPRMS: any;
    public closeDialog: Function;
    private userId: string;

    constructor(private _cordysService: CordysSoapWService, public _alertMsgService: AlertMessagesService
        , private _appUtilService: ApplicationUtilService) {

    }

    ngOnInit(): any {
        this.emailTemplates = [];
        this._sendmail = new SendMail();
        this._sendmail.isTemplate = false;



        if (this.datainput.hasValuesDefaulted != undefined) {
            //   this.AttachmentsObj =this.datainput.attachments ? this.datainput.attachments: [];
            this._sendmail.emailTo = this.datainput.emailTo;
            // this._sendmail.emailCc=this.datainput.emailCC;
            // this._sendmail.emailBcc=this.datainput.emailBcc;
            //  this._sendmail.subject=this.datainput.subject;


        }
        else {

            this.caseId = this.datainput.caseId;
            this.getCustomerEmail();
        }


        jQuery("#modalBaseClose").click(() => {
            if (this.datainput.hasValuesDefaulted != undefined)
                this.CancelButtonClick();
        });

    }

    private getCustomerEmail() {
        var requestObj = new GetLOVData();
        requestObj.BRANCH = 'ALL';
        requestObj.LOB = 'ALL';
        requestObj.BUSINESS_FUNCTION = 'ALL';
        requestObj.PRODUCT = 'ALL';
        requestObj.OPERATION = 'ALL';
        requestObj.FORM_NAME = 'RESENDMAIL';
        requestObj.FORM_FIELD_NAME = 'RESENDMAIL';
        requestObj.FIELD_TYPE = 'LOV';
        requestObj.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        requestObj.ADVANCE_CONFIG_XML.FILTERS = new Filter();
        requestObj.ADVANCE_CONFIG_XML.FILTERS.FILTER = [{
            "@FIELD_NAME": "CASE_ID",
            "@FIELD_VALUE": this.caseId,
            "@OPERATION": "EQ",
            "@CONDITION": "AND"
        }];

        // requestObj.ADVANCE_CONFIG_XML=input.ADVANCE_CONFIG_XML;

        let recordsCountResponse = this._cordysService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", requestObj, null, null, false, null);
        recordsCountResponse.success((data) => {
            if (data.tuple) {
                this._sendmail.emailTo = data.tuple.old.MSIG_BUSINESS_OBJECT.EMAIL;
            }
        });
        //    recordsCountResponse.error((response,status,errorText) => 
        //  prm._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error while calling LOV service "+errorText ,-1)));

    }

    private CloseDialog() {
        let res = "";

        this.closeDialog({
            response: res,

            emailTarget: this._sendmail.emailTo
        },
            this.parentCompPRMS
        );
    }
    private CancelButtonClick() {
        this.closeDialog({
            response: "deleteAttachment"

        },
            this.parentCompPRMS
        );

    }

    //Send report as mail
    private sendPolicyDocumentMail(receiver: string, caseid: string) {
        this._cordysService.callCordysSoapService("SendPolicyDocumentMail",
            "http://schemas.insurance.com/businessobject/1.0/",
            this.sendPolicyDocumentMailParams(receiver, caseid),
            this.sendPolicyDocumentMailSuccessHandler,
            this.sendPolicyDocumentMailErrorHandler,
            true, this)
    }

    private sendPolicyDocumentMailParams(receiver, caseid) {
        return {
            "receiver": receiver,
            "caseid": caseid,
            "action":'Resend'

        }
    }

    private sendPolicyDocumentMailSuccessHandler(data, scopeObject) {
        scopeObject._alertMsgService.add(new AlertMessage(AlertMessage.SUCCESS, "Mail sent successfully", 3000));
    }

    private sendPolicyDocumentMailErrorHandler(response, status, errorText, scopeObject) {
        scopeObject._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, errorText, 2000));
    }

    private sendButtonClick() {
        //this._sendmail.content = document.getElementById("richTextField").innerText;
        //  if(this.validateDialogSubmit()){
        if (this._sendmail.emailTo != undefined && this._sendmail.emailTo != "")
            if (!/^(([\s]*)(([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9_\-\.]+)\.([a-zA-Z]{2,5}){1,25})([\s]*)([;])*)*$/.test(this._sendmail.emailTo)) {

                this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Email address is not valid", 5000));
                return;
            }
        this.sendPolicyDocumentMail(this._sendmail.emailTo, this.caseId);

        //   }
        // this._sendmail.content = document.getElementById("richTextField").innerText;
        this.CloseDialog();

    }

    /*  private validateDialogSubmit(){
     
           if(!/^(([\s]*)(([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9_\-\.]+)\.([a-zA-Z]{2,5}){1,25})([\s]*)([;])*)*$/.test(this._sendmail.emailTo)){
  
             this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Email address is not valid" ,5000));
             return false;
           }
           else return true;
        
    }*/




}
