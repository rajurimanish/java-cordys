import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { EventEmitter, Output, ViewChild, ViewContainerRef } from "@angular/core";
import { AdvancedSearchInput } from '../../../../../common/components/advancedsearchgrid/advancedsearchgridinput';
import { GetLOVData, SearchAdvancedConfig, Filter } from '../../../../../common/components/utility/search/search.requests';
import { AlertMessage } from '../../../../../common/components/utility/alertmessage/alertmessages.model';
import { AppUtil } from '../../../../../common/components/utility/apputil/app.util';
import { ModalInput } from "../../../../../common/components/utility/modal/modal";
import { CustomDCLService, DCLInput } from "../../../../../common/services/customdcl.service";
import { ApplicationUtilService } from '../../../../../common/services/application.util.service';


declare var numeral: any;

@Component({
    selector: 'hlconnect',
    templateUrl: 'app/bms/components/proposal/enquiry/hlconnect/hlconnect.template.html'
})

export class HLConnectComponent implements OnInit {
    private advancedSearchInput: AdvancedSearchInput = new AdvancedSearchInput();
    @ViewChild('APIAreaModal', { read: ViewContainerRef }) contentArea: ViewContainerRef;
    constructor(private _router: Router, public dcl: CustomDCLService, private _appUtilService: ApplicationUtilService) {
    }

    ngOnInit() {

        this.advancedSearchInput.advancedFilterOptnsArry = { "LIKE": "LIKE", "EQ": "EQ", ">": "GT", ">=": "GTEQ", "<": "LT", "<=": "LTEQ" };
        this.advancedSearchInput.onColumnDataBind = this._appUtilService.transformValue;
        this.advancedSearchInput.isActionsHiddenFunction = this.checkHidden;
    }

    private checkHidden(app, action, report) {
        if (action.hiddenWhen != undefined && action.hiddenWhen.indexOf(report.status) > -1) {
            return false;
        }
        return true;

    }
    /*private getTotalSearchRecordsCount(input,prm) {
        var requestObj = new GetLOVData();
          requestObj.BRANCH ='ALL';
          requestObj.LOB = 'ALL';
          requestObj.BUSINESS_FUNCTION = 'NEW BUSINESS';
          requestObj.PRODUCT = 'ALL';
          requestObj.OPERATION = 'ENQUIRY';
          requestObj.FORM_NAME = 'BPM_ENQUIRY_COUNT';        
          requestObj.FORM_FIELD_NAME = 'BPM Enquiry Count';
          requestObj.FIELD_TYPE = 'LOV';
          requestObj.ADVANCE_CONFIG_XML = new SearchAdvancedConfig(); 
          requestObj.ADVANCE_CONFIG_XML.FILTERS = new Filter();
          requestObj.ADVANCE_CONFIG_XML.FILTERS.FILTER = [{"@FIELD_NAME":"UNIQU_REFERENCE",
                                                            "@FIELD_VALUE":"",
                                                            "@OPERATION":"NTEQ",
                                                            "@CONDITION":"AND"
                                                            }]; 
          
         requestObj.ADVANCE_CONFIG_XML=input.ADVANCE_CONFIG_XML;
  
       let recordsCountResponse = prm._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", requestObj, null, null, true, null);
       recordsCountResponse.success((data) => {
           if (data.tuple) {
               prm.recordsCount= data.tuple.old.MSIG_BUSINESS_OBJECT.Count;
              }
          });
       recordsCountResponse.error((response,status,errorText) => 
       prm._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error while calling LOV service "+errorText ,-1)));
         
      }*/



    private onActionClick(event) {
        switch (event.action) {
            case "dblclick":
                if (event.item.caseId.startsWith("NB") || event.item.caseId.startsWith("CN") ) {
                    let isSimplifiedProcess = (event.item.version == 'Simplified') ? 'Y' : 'N';
                    let component = this._appUtilService.getNavigationComponent("BMS", event.item.caseId, isSimplifiedProcess);
                    this._router.navigate([component, { caseID: event.item.caseId, component: "HLConnect" }]);
                }
                break;
            case "Resend Policy Documents":
                {
                    this.openResendEmailPopup(event.item.caseId);

                }
                break;
            default: break;
        }
    }



    private openResendEmailPopup(caseid) {

        let input = {

            "caseId": caseid
        };
        let lookup = new ModalInput();
        lookup.component = ["SendMailComponent", "app/bms/components/proposal/enquiry/hlconnect/sendmail.module", "SendMailModule"];
        //lookup.outputCallback = this.sendMailCallBack;
        lookup.datainput = input;
        lookup.parentCompPRMS = {
            comp: this
        };
        lookup.heading = "Send Mail";
        lookup.icon = "fa fa-envelope-o";
        lookup.containerRef = this.contentArea;
        this.dcl.openLookup(lookup);
    }



}
