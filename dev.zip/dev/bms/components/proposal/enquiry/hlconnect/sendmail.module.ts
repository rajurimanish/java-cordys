import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
//import { RichTextEditorModule } from '../richtexteditor/richtexteditor.module';
import { SendMailComponent } from './sendmail.component';

@NgModule({
    imports: [CommonModule, FormsModule, ReactiveFormsModule],
    exports: [SendMailComponent],
    declarations: [SendMailComponent]
})
export class SendMailModule { }
