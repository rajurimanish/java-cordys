import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AdvancedSearchInput } from '../../../../../common/components/advancedsearchgrid/advancedsearchgridinput';
import { ApplicationUtilService } from '../../../../../common/services/application.util.service';

@Component( {
    selector: 'newbusiness-enquiry',
    templateUrl: 'app/bms/components/proposal/enquiry/newbusinessenquiry/newbusinessenquiry.template.html'
} )

export class NewBusinessEnquiryComponent implements OnInit {
    private advancedSearchInput: AdvancedSearchInput = new AdvancedSearchInput();
    constructor( private _router: Router, private _appUtilService: ApplicationUtilService ) { }

    ngOnInit() {
        this.advancedSearchInput.advancedFilterOptnsArry = { "LIKE": "LIKE", "EQ": "EQ", ">": "GT", ">=": "GTEQ", "<": "LT", "<=": "LTEQ" };
        this.advancedSearchInput.onColumnDataBind = this._appUtilService.transformValue
    }

    private onActionClick( event ) {
        //Added Endorsements & Cancellations related code
        let isSimplifiedProcess = ( event.item.version == 'Simplified' ) ? 'Y' : 'N';
        let component = this._appUtilService.getNavigationComponent( "BMS", event.item.caseId, isSimplifiedProcess );
        let compName = "NewBusinessEnquiry";
        switch ( event.action ) {
            case "dblclick":
            case "Open":
                if ( event.item.caseId.startsWith( "EN" ) || event.item.caseId.startsWith( "CA" ) || event.item.caseId.startsWith( "RS" ) ) {
                    compName = "EndorsementEnquiry";
                } 
                this._router.navigate( [component, { caseID: event.item.caseId, component: compName }] );
                break;
            default: break;
        }
    }
}
