import { Component, ElementRef, EventEmitter, OnInit, ViewChild, ViewContainerRef, NgZone } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AlertMessage } from '../../../common/components/utility/alertmessage/alertmessages.model';
import { AlertMessagesService } from '../../../common/components/utility/alertmessage/alertmessages.service';
import { AppUtil } from '../../../common/components/utility/apputil/app.util';
import { CordysSoapWService } from "../../../common/components/utility/cordys-soap-ws";
import { ProgressBarComponent } from '../../../common/components/utility/progressbar/progressbar.component';
import { Filter, GetLOVData, SearchAdvancedConfig } from '../../../common/components/utility/search/search.requests';
import { ApplicationUtilService } from "../../../common/services/application.util.service";
import { CustomDCLService, DCLInput } from '../../../common/services/customdcl.service';
import { BMSControlAreaService } from '../../services/bms.controlarea.service';
import { BMSUtilService } from '../../services/bms.util.service';
import { BMSAppObjService } from '../../services/bmsappobj.service';
import { BMSPostingService } from '../../services/bmsposting.service';
import { ApplicationBusinessObject, ApplicationObject } from '../common/appobjects/applicationBusinessObject';
import { BMSObject } from '../common/appobjects/bmsobject';
import { BMSConstants } from '../common/constants/bms_constants';
import { CAMailService } from './process/services/camail.service';
import { ProposalHeader } from './proposalheader/appobjects/proposalheader';
import { RIService } from './newbusinessrisks/services/ri.service';
import { LOV_Field, LOVDropDownService } from '../../../common/services/lovdropdown/lovdropdown.service';

declare var Rx: any;
declare var numeral: any;
declare var jQuery: any;

@Component( {
    selector: 'endorsements-component',
    templateUrl: 'app/bms/components/proposal/endorsements.template.html',
    styleUrls: [
        'assets/css/simplifiedForm.css'
    ]
} )

export class EndorsementsComponent implements OnInit {
    private el: HTMLElement;
    public appObj: ApplicationObject;
    public appBusObj: ApplicationBusinessObject;
    public bmsObject: BMSObject;
    public proposalHeader: ProposalHeader;
    public caseInfo: any;
    public risks: any;
    public loggedInUser: string;
    public userFullName: string;
    public userRoles: any[];
    public disableForm: boolean = false;
    public disableCtrlForm: boolean = false;
    public userID: string;
    public isAsyncValidationRequired: boolean = true;
    public isPolicyFetch: boolean = false;
    private isformDataReady: boolean = false;
    public baseModuleLoaded: boolean = false;
    public riskObj;

    public premiumFormat: string = "0,00.00";
    public siFormat: string = "0,00";
    public rateFormat: string = "0.00000";

    public riskTableObject;
    private isCLLoaded: boolean = false;
    private isPHLoaded: boolean = false;
    private isATLoaded: boolean = false;
    private isTDLoaded: boolean = false;
    private isHDLoaded: boolean = false;
    private isAPSMTLoaded: boolean = false;
    private isImpNotesCollapsed: boolean = true;
    private iscoverageCollapsed: boolean = true;
    private isTDCollapsedMode: boolean = true;
    private isCLCollapsedMode: boolean = true;
    private tempObj: any;
    private hideForm: boolean = true;
    private isReferencesLoaded: boolean = false;
    public transactionObj;

    public elem: any;
    public winHeight: any;
    public winMinHeight: any;

    public riRetentionCodes = [];
    public rtRisksInfo: any;
    public construnctClassArr = [];

    @ViewChild( 'clModal', { read: ViewContainerRef } ) clArea: ViewContainerRef;
    @ViewChild( 'phModal', { read: ViewContainerRef } ) phArea: ViewContainerRef;
    @ViewChild( 'atModal', { read: ViewContainerRef } ) atArea: ViewContainerRef;
    @ViewChild( 'tdModal', { read: ViewContainerRef } ) tdArea: ViewContainerRef;
    @ViewChild( 'rtModal', { read: ViewContainerRef } ) rtArea: ViewContainerRef;
    //@ViewChild( 'gstModal', { read: ViewContainerRef } ) gstArea: ViewContainerRef;
    @ViewChild( 'hdModal', { read: ViewContainerRef } ) hdArea: ViewContainerRef;
    @ViewChild( 'cntrlModal', { read: ViewContainerRef } ) cntrlArea: ViewContainerRef;
    @ViewChild( 'referencesModal', { read: ViewContainerRef } ) referencesArea: ViewContainerRef;
    @ViewChild( 'apsmtModal', { read: ViewContainerRef } ) apsmtArea: ViewContainerRef;

    onPremiumChange = new EventEmitter<any>();

    constructor(
        private _cordysService: CordysSoapWService, private _routeParams: ActivatedRoute, private _aus: ApplicationUtilService, public _alertMsgService: AlertMessagesService, private _router: Router, private _appObjService: BMSAppObjService, private _postingService: BMSPostingService, private _caMailService: CAMailService, private _dcl: CustomDCLService, private _controlAService: BMSControlAreaService, public _bus: BMSUtilService, el: ElementRef, lc: NgZone, private _riService: RIService, private lovDropDownService: LOVDropDownService) {
            this.el = el.nativeElement;
            jQuery( "body" ).addClass( "scroll_hide_cs" );
        }    

    ngOnInit() {
        ProgressBarComponent.hide();
        BMSConstants.TEMPOBJ.ISSIMPLIFIEDPROCESS = "Y";
        this.tempObj = BMSConstants.getTempObj();
        let caseId = this._routeParams.snapshot.params['caseID'];
        let policyNo = this._routeParams.snapshot.params['policyNo'];
        this.setIsPolicyFetch( policyNo );
        this.initProposal( caseId, policyNo );
    }

    ngOnDestroy() {
        this._dcl.unloadComponent( this.riskTableObject );
        jQuery( "body" ).removeClass( "scroll_hide_cs" );
        //jQuery( "#rootHeader" ).css( { "position": "inherit;", "width": "-webkit-fill-available;" } );
    }

    ngAfterViewInit() {
        jQuery( '.showPop' ).tooltip();
    }

    setIsPolicyFetch( policyNo ) {
        if ( AppUtil.isEmpty( policyNo, false ) == false )
            this.isPolicyFetch = true;
    }

    private setUserId( data ) {
        this.userID = data.substring( 3, data.indexOf( "," ) );
    }

    initVars( applObj ) {
        this.appObj = applObj;
        this.appBusObj = this.appObj.ApplicationBusinessObject;
        this.caseInfo = this.appBusObj.caseInfo;
        this.bmsObject = this.appBusObj.businessObject.bms;
        this.proposalHeader = this.bmsObject.newBusiness.headerInfo;
        this.proposalHeader.isSimplifiedProcess = 'Y'
        this.risks = this.bmsObject.newBusiness.risks;
        //SST code
        /* let tempRespObj = this._bus.getLiveDate();
        if (tempRespObj != undefined && tempRespObj != "") {
            this.proposalHeader.GSTLiveDate = tempRespObj[0].old.ITEMPF.LIVEDATE;
            this.proposalHeader.SSTLiveDate = tempRespObj[1].old.ITEMPF.LIVEDATE;
        } */
        //End
    }

    initProposal( caseId, policyNo ) {
        let udn = this._aus.getUserDn();
        let uname = this._aus.getUserName();
        let uroles = this._aus.getUserRoles();
        let uwuser = this._aus.isUnderWriterUser();
        let component = this._routeParams.snapshot.params['component'];
        let boData = this._appObjService.initData( caseId, policyNo, component );

        let dataComplete = Rx.Observable.zip( udn, uname, uroles, boData, uwuser, ( usrdn: any, usrname: any, urols: any, busObj: any, uwUserCheck ) => { return { usrdn: usrdn, usrname: usrname, urols: urols, busObj: busObj, uwUserCheck: uwUserCheck } } );

        dataComplete.subscribe( ( data ) => {
            this.setUserId( data.usrdn );
            this.userRoles = data.urols;
            this.loggedInUser = data.usrname;
            this.initVars( data.busObj );
            BMSConstants.setApprovalStatus( data.uwUserCheck );
            this.isformDataReady = ( this.caseInfo.status != 'Assessment' ) ? true : false;
            this.hideForm = ( this.caseInfo.status == 'Endorsements Draft' || this.caseInfo.status == 'Cancellations Draft' || this.caseInfo.status == 'Reinstatement Draft') ? true : false;
            // For Process History related issue
            this._aus.getUserFullName( this.loggedInUser ).subscribe( ( data ) => {
                this.userFullName = data;
                BMSConstants.setUserName( data );
                if ( this.baseModuleLoaded == false ) {
                    this.loadModules();
                    this.baseModuleLoaded = true;
                }
            } );
        } );
    }

    private loadModules() {
        let ctrlInput = new DCLInput();
        ctrlInput.component = ["ControlAreaComponent", "app/bms/components/proposal/endorsements/controlarea/controlarea.module", "ControlAreaModule"];
        ctrlInput.viewContainerRef = this.cntrlArea;
        ctrlInput.inputs = { appObj: this.appObj };

        this._dcl.loadComponent( ctrlInput ).subscribe( ( compRef ) => {
            if ( compRef.instance.setFormMode != null ) {
                compRef.instance.setFormMode.subscribe( ( values ) => {
                    this.setFormDisabled( values );
                } );
                this.disableCtrlForm = ( this.appObj.ApplicationBusinessObject.caseInfo.status == 'Endorsements Draft' || this.appObj.ApplicationBusinessObject.caseInfo.status == 'Cancellations Draft' || this.appObj.ApplicationBusinessObject.caseInfo.status == 'Reinstatement Draft') ? true : false;
                this.hideForm = ( this.caseInfo.status == 'Endorsements Draft' || this.caseInfo.status == 'Cancellations Draft' || this.caseInfo.status == 'Reinstatement Draft' ) ? true : false;
            }

            if ( compRef.instance.onBeforeCancel != null ) {
                compRef.instance.onBeforeCancel.subscribe( ( values ) => {
                    //this.cancelPosting();
                } );
            }

            if ( compRef.instance.onBeforePost != null ) {
                compRef.instance.onBeforePost.subscribe( ( values ) => {
                    this.onBeforePost( values )
                } );
            }

            if ( compRef.instance.onAfterPost != null ) {
                compRef.instance.onAfterPost.subscribe( ( values ) => {
                    //this.onAfterPost(values)
                } );
            }

            if ( compRef.instance.refreshAttachment != null ) {
                compRef.instance.refreshAttachment.subscribe( ( values ) => {
                    //this.refreshAttachment(values)
                } );
            }

        } );

        if ( !this.hideForm ) {
            /* let rtIinput = new DCLInput();
            rtIinput.component = ["RiskTableComponent", "app/bms/components/proposal/proposalheader/uimodules/risktable.module", "RiskTableModule"];
            rtIinput.viewContainerRef = this.rtArea;
            rtIinput.inputs = { risks: this.risks, headerInfo: this.proposalHeader, product: this.proposalHeader.contractType, clientDetails: this.bmsObject.newBusiness.clientDetails, status: this.caseInfo.status, caseInfo: this.caseInfo };
            this._dcl.loadComponent( rtIinput ).subscribe( ( componentRef ) => {
                if ( componentRef ) {
                    this.riskTableObject = componentRef;
                    componentRef.instance.onRiskSelect.subscribe( ( compRef ) => {
                        this.riskObj = compRef;

                    } );
                    componentRef.instance.onRiskRemove.subscribe( ( compRef ) => {
                        this.riskObj = compRef;
                    } );
                }
            } ); */

            this.riskObj = this.risks["generic"][0];
            
            if ( this.proposalHeader.lineOfBusiness == "FIR" || this.proposalHeader.contractType == "AR" ) {
                this.lovDropDownService.createLOVDataList( ["construction", "riCode"] );
                let lovFields = [];
                lovFields.push( new LOV_Field( "ALL", "MOTOR", "NEW BUSINESS", "ALL", "NEW", "PRIVATE_MOTOR", "RI Retention Code", "LOV", [], "DESCPF", "riCode", null ) );
                lovFields.push( new LOV_Field( "ALL", "FIRE", "CLAIMS", "ALL", "NEW", "CLAIMS_FIRE", "Construction Code", "LOV", [], "DESCPF", "construction", null ) );
                
                this.lovDropDownService.util_populateLOV( lovFields, this );
            }            

            this.loadHD();
        }  

       /*  if ( !this.hideForm){
            this.loadHD();//added to load Header first for Simplified Process
        } */
    }

    attachmentAdded( callerObject ) {
        this.caseInfo.attachmentChange( callerObject, this.userFullName );
        this._appObjService.saveData().subscribe();
    }

    setFormDisabled( set: boolean ) {
        this.disableForm = set;
    }

    onBeforePost( event ) {
        if ( this.proposalHeader.policyIssued && this.proposalHeader.policyIssued === "true" ) {
            this._alertMsgService.add( new AlertMessage( AlertMessage.ERROR, "Policy already posted in P400 system", -1 ) );
            return;
        }
        else if ( this.proposalHeader.policyIssued && this.caseInfo.status === "Pending NB" ) {
            this._alertMsgService.add( new AlertMessage( AlertMessage.INFO, "This policy requires RI from P400 system", -1 ) );
            return;
        }
        else {
            this.postToP400( this.caseInfo.caseId );
        }
    }

    private postToP400( caseId ) {
        ProgressBarComponent.show( 'Posting to P400 is in Progress', { dialogSize: 'm', progressType: 'primary' } );        
        this._postingService.postEndorsementsCase().subscribe( data => this.postEndorsementToP400SuccessHandler(),
            errorMsg => this.postToP400ErrorHandler( errorMsg ) );       
    }   

    private postEndorsementToP400SuccessHandler() {
        ProgressBarComponent.hide();
        let header = BMSConstants.getBMSHeaderInfo();
        if ( header.isPendingNB == "true" ) {
            this._alertMsgService.add( new AlertMessage( AlertMessage.INFO, "Policy is moved to 'P400 Pending EN' state.", -1 ) );
        }
        else {
            this._cordysService.callCordysSoapService( "GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", this.getLOVDataParamsForTxNo(), this.getLOVDataTxNoSuccessHandler, null, false, { comp: this } );
            if ( header.isPendingNB == "false" && ( header.policyIssued == true || header.policyIssued == "true" ) ) {
                this._alertMsgService.add( new AlertMessage( AlertMessage.SUCCESS, "Policy posted Successfully.", -1 ) );
            } else {
                this._alertMsgService.add( new AlertMessage( AlertMessage.INFO, "Policy is moved to 'P400 Pending EN' state.", -1 ) );
            }
            
            this._caMailService.sendManuscriptMail( 'true' ).subscribe();
            this._caMailService.sendFacRIMail( "ISD", "" ).subscribe();
        }


        this._controlAService.setActionLisByStatus().subscribe();

    }
    
    private getLOVDataParamsForTxNo() {
        var requestObj = new GetLOVData();
        requestObj.BRANCH = 'ALL';
        requestObj.LOB = 'ALL';
        requestObj.BUSINESS_FUNCTION = 'NEW BUSINESS';
        requestObj.PRODUCT = 'ALL';
        requestObj.OPERATION = 'ALL';
        requestObj.FORM_NAME = 'DESPATCH INFO';
        requestObj.FORM_FIELD_NAME = 'Transaction Number';
        requestObj.FIELD_TYPE = 'LOV';
        requestObj.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        requestObj.ADVANCE_CONFIG_XML.FILTERS = new Filter();

        requestObj.ADVANCE_CONFIG_XML.FILTERS.FILTER = [
            {
                "@FIELD_NAME": 'CHDRNUM',
                "@FIELD_VALUE": this.appObj.ApplicationBusinessObject.caseInfo.policyNumber,
                '@OPERATION': 'EQ',
                '@CONDITION': 'AND'
            },
            {
                "@FIELD_NAME": 'CURRFROM',
                "@FIELD_VALUE": this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.effectiveDate.replace( /-/g, "" ),
                '@OPERATION': 'EQ',
                '@CONDITION': 'AND'
            }
        ];

        return requestObj;
    }

    private getLOVDataTxNoSuccessHandler( response, prms ) {
        if ( response.tuple ) {
            if ( response.tuple.old && response.tuple.old.CHDR.TRANNO != "" ) {
                prms.comp.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.transactionNumber = response.tuple.old.CHDR.TRANNO;
                prms.comp._appObjService.saveData().subscribe();
            }
        }
    }

    private postToP400ErrorHandler( error ) {
        ProgressBarComponent.hide();
        this._controlAService.setActionLisByStatus().subscribe()
        //this._alertMsgService.add( new AlertMessage( AlertMessage.ERROR, "Post to P400 failed due to : " + error, -1 ) );
        this._alertMsgService.add( new AlertMessage( AlertMessage.ERROR, error, -1 ) );
    }

    private loadCL() {
        if ( this.isCLLoaded == false ) {
            let input = new DCLInput();
            input.component = ["ChangeLogComponent", "app/common/components/changelog/changelog.module", "ChangeLogModule"];
            input.viewContainerRef = this.clArea;
            input.inputs = { _changeLogs: this.appObj.ApplicationBusinessObject.caseInfo.auditTrail };
            this._dcl.loadComponent( input ).subscribe( () => {
                this.isCLLoaded = true;
            } );
        }
    }

    private loadPH() {
        if ( this.isPHLoaded == false ) {
            let input = new DCLInput();
            input.component = ["ProcessHistoryComponent", "app/bms/components/common/processhistory/processhistory.module", "ProcessHistoryModule"];
            input.viewContainerRef = this.phArea;
            input.inputs = { approvalNodes: this.appObj.ApplicationBusinessObject.caseInfo.approvalInfo };
            this._dcl.loadComponent( input ).subscribe( () => {
                this.isPHLoaded = true;
            } );
        }
    }

    private loadAT() {
        if ( this.isATLoaded == false ) {
            let input = new DCLInput();
            input.component = ["AttachmentComponent", "app/common/components/attachment/attachment.module", "AttachmentModule"];
            input.viewContainerRef = this.atArea;
            input.inputs = { CurrentUser: this.userID, setRoles: this.userRoles, branch: this.caseInfo.handlingBranchId, isCMS: false, lob: this.caseInfo.lineOfBusiness, _attachments: this.caseInfo.attachmentInfoDisp, caseInfo: this.caseInfo };
            this._dcl.loadComponent( input ).subscribe( ( compRef ) => {
                if ( compRef.instance.saveBO != null ) {
                    compRef.instance.saveBO.subscribe( ( values ) => {
                        this.attachmentAdded( values );
                    } );
                }
                this.isATLoaded = true;
            } );
        }
    }

    private loadTD() {
        if ( this.caseInfo.policyNumber == undefined || this.caseInfo.policyNumber.length < 8 ) {
            this._alertMsgService.add( new AlertMessage( AlertMessage.INFO, "<b>Policy number</b> not found or not valid. Please try again.", 10000 ) );
            if ( this.transactionObj != null ) {
                this._dcl.unloadComponent( this.transactionObj );
                this.isTDLoaded = false;
            }
            return;
        }
        if ( this.transactionObj == undefined || this.transactionObj == null ) {
            this.callTD();
        }
        else if ( this.transactionObj != null ) {
            this._dcl.unloadComponent( this.transactionObj );
            this.isTDLoaded = false;
            this.callTD();
        }
    }

    private callTD() {
        let input = new DCLInput();
        input.component = ["TransactionDetailsComponent", "app/bms/components/proposal/enquiry/transactiondetails/transactiondetails.module", "TransactionDetailsModule"];
        input.viewContainerRef = this.tdArea;
        input.inputs = { policyno: this.caseInfo.policyNumber, caseId: this.caseInfo.caseId };
        this._dcl.loadComponent( input ).subscribe( ( componentRef ) => {
            if ( componentRef ) {
                this.transactionObj = componentRef;
                this.isTDLoaded = true;
            }
        } );
    }

    private loadHD() {
        if ( !this.hideForm && this.isHDLoaded == false ) {
            let input = new DCLInput();
            input.component = ["ProposalHeaderComponent", "app/bms/components/proposal/endorsements/proposalheader/proposalheader.module", "ProposalHeaderModule"];
            input.viewContainerRef = this.hdArea;
            input.inputs = { proposal: this.bmsObject, proposalHeader: this.proposalHeader, caseInfo: this.caseInfo };
            this._dcl.loadComponent( input ).subscribe( ( compRef ) => {
                this.isHDLoaded = true;
                if ( this.riskObj != null ) {
                    this.riskObj.symRiskClassification = this.riskObj.riskClassification;
                }
                compRef.instance.onproductchange.subscribe( ( compRef ) => {
                    this.riskObj = null;
                } );
            } );
            

        }
    }

    private loadReferences() {
        if ( !this.hideForm && this.isReferencesLoaded == false ) {
            let input = new DCLInput();
            input.component = ["ReferencesComponent", "app/bms/components/proposal/proposalheader/uimodules/reference.module", "ReferenceModule"];
            input.viewContainerRef = this.referencesArea;
            input.inputs = { _references: this.proposalHeader.references, _handlingBranch: this.proposalHeader.handlingBranch, _extraDetails: this.proposalHeader.extraDetails };            
            this._dcl.loadComponent( input ).subscribe( ( compRef ) => {                
                this.isReferencesLoaded = true;
            } );
        }
    }

    private loadAPSMT() {
        if ( this.isAPSMTLoaded == false ) {
            let input = new DCLInput();
            input.component = ["AppealtoBUSMTComponent", "app/bms/components/proposal/process/appealtobusmt.module", "AppealtoBUSMTModule"];
            input.viewContainerRef = this.apsmtArea;
            input.inputs = { appObj: this.appObj };
            this._dcl.loadComponent( input ).subscribe( ( compRef ) => {
                this.isAPSMTLoaded = true;
            } );
        }
    }

    setTotalPremium() {
        this.riskObj.totalSI = this.getTotalByProperty( "sumInsured", this.riskObj.riskCoverageDetails.riskCoverage, this.siFormat );
        this.riskObj.capitalSumInsured = this.riskObj.totalSI;
        this.proposalHeader.targetSumInsured = this.riskObj.totalSI;

        this.riskObj.grossPremium = this.getTotalByProperty( "premium", this.riskObj.riskCoverageDetails.riskCoverage, this.premiumFormat );
        this.riskObj.originalTotalPremium = numeral( numeral( this.riskObj.grossPremium ).format( this.premiumFormat ) ).value();

        this.riskObj.rebateAmount = numeral( numeral( ( parseFloat( "" + numeral( this.riskObj.grossPremium ).value() ) * parseFloat( "" + this.riskObj.rebate ) ) / 100 ).format( this.premiumFormat ) ).value();
        
        let discountedPrem = numeral( numeral( parseFloat( "" + numeral( this.riskObj.grossPremium ).value() ) - parseFloat( "" + numeral( this.riskObj.rebateAmount ).value() ) ).format( this.premiumFormat ) ).value();
        this.riskObj.discountedPremium = discountedPrem;

        this.riskObj.sstAmount = numeral( numeral( ( discountedPrem * parseInt( "" + this.riskObj.SST ) ) / 100 ).format( this.premiumFormat ) ).value();
        let _totalPremium = parseFloat( "" + numeral( discountedPrem ).value() ) + parseFloat( "" + numeral( this.riskObj.sstAmount ).value() );

        this.riskObj.totalPremium = numeral( numeral( _totalPremium ).format( this.premiumFormat ) ).value();

        this.proposalHeader.totalPostedPremium = this.riskObj.totalPremium;
        this.proposalHeader.originalTotalPremium = this.riskObj.originalTotalPremium;
        this.proposalHeader.totalPremium = this.riskObj.totalPremium;

        this.proposalHeader.isRefundInvolved = ( this.riskObj.discountedPremium <= 0 && this.riskObj.discountedPremium <= numeral( -5000 ))?"Y":"N";
        

    }

    getTotalByProperty( prop, ary, format: string ) {
        let total = 0;
        for ( let eachItem of ary ) {
            if ( eachItem[prop] != null && eachItem[prop] != "" )
                total = total + parseFloat( numeral( eachItem[prop] ).value() );
        }
        if ( format != null )
            return numeral( numeral( total ).format( format ) ).value();
        else
            return total;
    }

    private validateAmount( event, i ) {
        if ( event.target.value != '' ) {
            let amountFormatted = numeral( event.target.value ).format( '0,0.00' );
            this.riskObj.customFields.customField[i].value = amountFormatted;

        } else {

            this.riskObj.customFields.customField[i].value = 0;
        }
        return true;
    }

    private scrollTop() {
        jQuery( '.showPop' ).tooltip();
        var elmnt = jQuery( '#tabContent' );
        elmnt.stop().animate( { scrollTop: 0 }, 800, 'swing', function () { } );
    }

    private setUWReferred( ev ) {
        this.proposalHeader.isReferredToUW = ( ev == "Y" ) ? 'Y' : 'N';  
        this.riskObj.isReferredToUW = this.proposalHeader.isReferredToUW;
        if ( this.proposalHeader.isReferredToUW == "Y" ) {
            this.riskObj.riskClassification = "Referred";
            this.setReferredFromUI( "Referred" );
        }
    }

    private loadRiskObj() {
        if ( this.riskObj != null && this.riskObj.symRiskClassification == "") {
            this.riskObj.symRiskClassification = this.riskObj.riskClassification;
        }

        if ( this.proposalHeader.isReferredToUW != "Y" && this.proposalHeader.lineOfBusiness == "MAR" && ["MHA", "MHY", "MPI", "CR"].indexOf( this.proposalHeader.contractType ) >= 0 ){
            this.proposalHeader.isReferredToUW = "Y";
            this.riskObj.isReferredToUW = "Y";
            this.riskObj.riskClassification = "Referred";
            this.setReferredFromUI( "Referred" );
        }


        if ( this.riskObj.RIRequired == "Yes" ) {
            this.setRIMethod( "Yes" );
        }

        if ( this.proposalHeader.isHeaderReferred == "Referred" ) {
            this.riskObj.riskClassificationReason = "Selected product is a referred risk product.";
            this.setReferredFromUI( "Referred" );
        }
    }

    setRiCodes( response, prms ) {
        if(response != undefined && response.tuple){
            prms.comp.riRetentionCodes = response.tuple;
        }
    }

    setConstruction( ev ) {
        this.riskObj.construction = ev.value;
        this.riskObj.constructionName = ev.record.DESCRIPTION;

        if ( this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.risks["s4846"][0] != undefined ) {            
            this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.risks["s4846"][0].construction = ev.value;
            this.appObj.ApplicationBusinessObject.businessObject.bms.newBusiness.risks["s4846"][0].constructionName = ev.record.DESCRIPTION;
        }
    }
    
    handleError( response, status, errorText, prms ) {
        prms.comp._alertMsgService.add( new AlertMessage( AlertMessage.ERROR, response.responseJSON.faultstring.text, -1 ) );
    }

    onRIRtnChange( value ) {
        this.riskObj.RIRetentionCode = value; 
        BMSConstants.getBMSHeaderInfo().RIRetentionCode = value;
    }

    getFormatVal( field ,formatType ) {
        return numeral( field ).format( formatType );
    }

    setReferredFromUI( riskClass ) {
        this.riskObj.riskClassification = riskClass;
        BMSConstants.getBMSHeaderInfo().setReferred();
    }

    setRIMethod( value ) {
        if ( this.riskObj.RIRequired == "Yes" ) {
            this.riskObj.riskClassification = "Referred";
            this.riskObj.isReferredToUW = "Y";
            this.setReferredFromUI( "Referred" );
        }

        this.riskObj.RIMethod = ( value == "Yes" ) ? "8" : "1";       
        this._riService.setRI().subscribe();
    }

    private expandOrCollapseSI() {
        this.iscoverageCollapsed = ( this.iscoverageCollapsed ) ? false : true;
    }

    private expandOrCollapseNotes() {
        this.isImpNotesCollapsed = ( this.isImpNotesCollapsed ) ? false : true;
    }
}