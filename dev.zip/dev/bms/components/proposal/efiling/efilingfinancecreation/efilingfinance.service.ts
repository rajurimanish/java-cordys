import { Injectable } from '@angular/core';
import { EventEmitter, Output, ViewChild, ViewContainerRef } from "@angular/core";
import { AdvancedSearchInput } from '../../../../../common/components/advancedsearchgrid/advancedsearchgridinput';
import { GetLOVData, SearchAdvancedConfig, Filter } from '../../../../../common/components/utility/search/search.requests';
import { AppUtil } from '../../../../../common/components/utility/apputil/app.util';
import { ModalInput } from "../../../../../common/components/utility/modal/modal";
import { CustomDCLService, DCLInput } from "../../../../../common/services/customdcl.service";
import { ApplicationUtilService } from '../../../../../common/services/application.util.service';
import { CordysSoapWService } from "../../../../../common/components/utility/cordys-soap-ws";
import { AlertMessagesService } from '../../../../../common/components/utility/alertmessage/alertmessages.service';
import { ProgressBarComponent } from '../../../../../common/components/utility/progressbar/progressbar.component';

import { AlertMessage } from '../../../../../common/components/utility/alertmessage/alertmessages.model';
declare var Rx: any;
declare var Observer: any;

import { Router, ActivatedRoute } from "@angular/router";

@Injectable()
export class EFilingService {
    constructor(private _cordysService: CordysSoapWService, public _alertMsgService: AlertMessagesService,  private _router: Router,
       private _appUtilService: ApplicationUtilService) {
        //this._appUtil = new AppUtil();
    }

    public GetEfilingObject(referenceNo){

        ProgressBarComponent.show('Fetching Efiling Case', { dialogSize: 'm', progressType: 'primary' });
        return Rx.Observable.create((observer) => {
            this._cordysService.callCordysSoapService("GetEfilingObject" , "http://schemas.cordys.com/default" , {"referenceNumber":referenceNo}, null, null, false, this)
                .success((data) => this.eFilingrSuccessHandler(data, this, observer))
                .error((response, status, errorText) => this.eFilingErrorHandler(response, status, errorText, observer))
        });
    }
    public eFilingrSuccessHandler(data, prms, observer){
        ProgressBarComponent.hide();
                observer.next(data);
    }

    public eFilingErrorHandler(response, status, errorText, observer) {
        this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, errorText, -1));
        ProgressBarComponent.hide();
        observer.error("");
    }

    /* public SaveEFilingCase(appObj){
        this._cordysService.callCordysSoapService("SaveEFilingDetails", "http://schemas.insurance.com/businessobject/1.0/", this.client, this.successHandler, this.handleError, false, { comp: this });
    }

    private successHandler(response, prms) {
        let referenceNumber = response.success.client.itemNo;
       prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.SUCCESS, "EFiling Details Saved Successfully : " + referenceNumber, 3000));
        // SR002 Added Condition to check if Privacy Notice Sent or Not 
        
}
private handleError(response, status, errorText, prms) {
    prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, response.responseJSON.faultstring.text, 3000));
} */
}