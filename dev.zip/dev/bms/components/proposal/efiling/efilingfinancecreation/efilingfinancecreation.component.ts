import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { EventEmitter, Output, ViewChild, ViewContainerRef } from "@angular/core";
import { AdvancedSearchInput } from '../../../../../common/components/advancedsearchgrid/advancedsearchgridinput';
import { GetLOVData, SearchAdvancedConfig, Filter } from '../../../../../common/components/utility/search/search.requests';
import { AlertMessage } from '../../../../../common/components/utility/alertmessage/alertmessages.model';
import { AppUtil } from '../../../../../common/components/utility/apputil/app.util';
import { ModalInput } from "../../../../../common/components/utility/modal/modal";
import { CustomDCLService, DCLInput } from "../../../../../common/services/customdcl.service";
import { ApplicationUtilService } from '../../../../../common/services/application.util.service';
import { CordysSoapWService } from "../../../../../common/components/utility/cordys-soap-ws";
import { AlertMessagesService } from '../../../../../common/components/utility/alertmessage/alertmessages.service';
import { ProgressBarComponent } from '../../../../../common/components/utility/progressbar/progressbar.component';
import { EfilingDetails, FinanceEfilingDetails, CaseInfo, TransactionObject, ApplicationBusinessObject } from '../appobjects/efiling';
import { EFilingService } from './efilingfinance.service';
import { AttachmentInfo } from '../../../../../common/components/appobjects/attachmentinfo'
import { EfilingFinanceComponent } from '../efilingfinanceenquiry/efilingfinance.component';
declare var Rx: any;
declare var moment: any;
declare var numeral: any;

@Component({
    selector: 'efilingfinancecreation',
    templateUrl: 'app/bms/components/proposal/efiling/efilingfinancecreation/efilingfinancecreation.template.html',
    inputs: ["efileObject"],
    providers: [EFilingService]
})

export class EfilingFinanceCreationComponent implements OnInit {

    private advancedSearchInput: AdvancedSearchInput = new AdvancedSearchInput();
    private efilingdetails: FinanceEfilingDetails = new FinanceEfilingDetails();
    private caseInfo: CaseInfo = new CaseInfo();
    private transactionObject: TransactionObject = new TransactionObject();
    private isFormDisabled = "false";
    private isdisabledDelete = "false";
    private isModification = "false";
    private ApplicationBusinessObject: ApplicationBusinessObject = new ApplicationBusinessObject();
    public referenceNumber: string;
    public userRoles: any[];
    private isATCollapsedMode: boolean = false;
    private isATLoaded: boolean = false;
    public scannedBy: string;
    public userID: string;
    public UPDTCtrl: any;
    public scanDateCtrl: any;
    @ViewChild('atModal', { read: ViewContainerRef }) atArea: ViewContainerRef;
    @ViewChild('efilingHeaderModal', { read: ViewContainerRef }) contentArea: ViewContainerRef;
    constructor(private _cordysService: CordysSoapWService, public _alertMsgService: AlertMessagesService, private _router: Router, public dcl: CustomDCLService, private _appUtilService: ApplicationUtilService, private _efiling: EFilingService, private _activatedRoute: ActivatedRoute) {
    }

    ngOnInit() {
        if (["Modify", "Enquiry"].indexOf(this._activatedRoute.snapshot.params['component']) >= 0 && this._activatedRoute.snapshot.params.referenceNo != '') {
            if (["Enquiry"].indexOf(this._activatedRoute.snapshot.params['component']) >= 0) {
                this.isFormDisabled = 'true';
            }
            else {
                this.isModification = 'true'
            }
            this._efiling.GetEfilingObject(this._activatedRoute.snapshot.params.referenceNo).subscribe((data) => {
                if (data.ApplicationBusinessObject != undefined) {

                    ProgressBarComponent.hide()
                    this.transactionObject = data.ApplicationBusinessObject.transactionObject;
                    this.efilingdetails.ApplicationBusinessObject.transactionObject = this.transactionObject;
                    this.efilingdetails.ApplicationBusinessObject.transactionObject.businessFunction = 'eFilingFinance';
                }
                else if (data.fault) {
                    this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error while fetching the policy info", -1));
                    ProgressBarComponent.hide();
                    return;
                }
                else ProgressBarComponent.hide();
            });
        }
        this.initData();
        this.advancedSearchInput.advancedFilterOptnsArry = { "LIKE": "LIKE", "EQ": "EQ", ">": "GT", ">=": "GTEQ", "<": "LT", "<=": "LTEQ" };
        this.advancedSearchInput.onColumnDataBind = this._appUtilService.transformValue;
        this.advancedSearchInput.isActionsHiddenFunction = this.checkHidden;
        this.isATCollapsedMode = true;
        this.loadAT();

    }
    
     private initScanDate(event) {
        this.scanDateCtrl = event;
        var currentDateEndTime = ApplicationUtilService.getFormattedDate(this.getServerDate(), "YYYY-MM-DDTHH:mm:ss", "DD/MM/YY");
        this.scanDateCtrl.setMaxDate(currentDateEndTime, this.scanDateCtrl.comp);
    }

   private initUpdateDate(event){        
        this.UPDTCtrl = event;
        var currentDateEndTime = ApplicationUtilService.getFormattedDate(this.getServerDate(), "YYYY-MM-DD", "DD/MM/YY");
        this.UPDTCtrl.setMaxDate(currentDateEndTime, this.UPDTCtrl.comp);
    }

    private checkHidden(app, action, report) {
        return false;

    }
    private loadAT() {
        if (this.isATLoaded == false) {
            this.loadATNB();
        }
    }

    private setUserId(data) {
        this.userID = data.substring(3, data.indexOf(","));
    }
    initData() {
        if (this.transactionObject.scanDate) {
           // this.transactionObject.scanDate = moment.utc(this.transactionObject.scanDate).local().format("YYYY-MM-DDTHH:mm:ss");
            this.transactionObject.scanDate = moment(this.transactionObject.scanDate).utc().format('YYYY-MM-DDTHH:mm:ss');
            if(this.scanDateCtrl!=null)
            this.scanDateCtrl.setter(this.transactionObject.updateDate, "YYYY-MM-DD", this.scanDateCtrl.comp);
        } 
        /*else {
            //let date = moment.utc(new Date(this.getServerDate())).local().format("YYYY-MM-DDTHH:mm:ss"); 
            let curDate  =  moment(this.getServerDate()).utc().format('YYYY-MM-DDTHH:mm:ss'); 
            this.transactionObject.scanDate =  curDate;
        }*/
        if (this.transactionObject.updateDate && this.UPDTCtrl != null) {
            this.transactionObject.updateDate = ApplicationUtilService.getFormattedDate(this.transactionObject.updateDate, "YYYY-MM-DD", "YYYY-MM-DD");
            this.UPDTCtrl.setter(this.transactionObject.updateDate, "YYYY-MM-DD", this.UPDTCtrl.comp);
        }
        
        let udn = this._appUtilService.getUserDn();
        let uname = this._appUtilService.getUserName();
        let uroles = this._appUtilService.getUserRoles();
        this.caseInfo.status = "Assessment";
        let dataComplete = Rx.Observable.zip(udn, uname, uroles, (usrdn: any, usrname: any, urole: any) => { return { usrdn: usrdn, usrname: usrname, urole: urole } });
        dataComplete.subscribe((data) => {
            this.setUserId(data.usrdn);
            this.userRoles = data.urole;
            if (this.transactionObject.scannedBy == '') {
                this.transactionObject.scannedBy = data.usrname;
            }
        });
    }
    private loadATNB() {
        if (this.isATLoaded == false) {
            let input = new DCLInput();
            input.component = ["AttachmentComponent", "app/common/components/attachment/attachment.module", "AttachmentModule"];
            input.viewContainerRef = this.atArea;
           // let tempTransactionDetails: any = this.copy(this.transactionObject);
            input.inputs = { CurrentUser: this.userID, setRoles: '', branch: 'HO', isCMS: false, lob: "efilingFinance", _attachments: this.transactionObject.attachmentInfo, caseInfo: this.transactionObject };
            this.dcl.loadComponent(input).subscribe((compRef) => {
                if (compRef.instance.saveBO != null) {
                    compRef.instance.saveBO.subscribe((values) => {
                        this.attachmentAdded(values);
                    });
                }
                this.isATLoaded = true;
            });
        }
    }

    attachmentAdded(callerObject) {
        let tempRef = "";
        let tempBPMId ="";
        let temObject :any;
        if(callerObject != null) {
            if(callerObject.docAttached)  {        
        this.transactionObject.scanDate = moment.utc(this.transactionObject.scanDate).local().format("YYYY-MM-DDTHH:mm:ss");
        this.transactionObject.updateDate = moment.utc(this.transactionObject.updateDate).local().format("YYYY-MM-DDTHH:mm:ss");
        this.transactionObject.caseStatus = "Draft";
        this.efilingdetails.ApplicationBusinessObject.transactionObject = this.transactionObject;
        this.efilingdetails.ApplicationBusinessObject.transactionObject.attachmentInfo = callerObject.comp.attachmentInfo;
       let response =  this._cordysService.callCordysSoapService("SaveEfilingDetails", "http://schemas.cordys.com/default", this.efilingdetails, null, null, false, { comp: this });
       response.success((data) => {       
        temObject= data.success.ApplicationBusinessObject.transactionObject;
       
         });
         response.error((data) => {
         this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error while saving the details", 5000));
          });             
          this.efilingdetails.ApplicationBusinessObject.transactionObject = temObject;

    }
        
        else if(callerObject.docDeleted) {
            this._cordysService.callCordysSoapService("DeleteEfilingDoc", "http://schemas.cordys.com/EfilingWSAppServerPackage",{ "locationURL": callerObject.attachmentData.sLocationUrl } , null, this.handleError1, false, { comp: this });
        }
    }
    else if(this.transactionObject.referenceNumber == "") {
        
        this.transactionObject.scanDate = moment.utc(this.transactionObject.scanDate).local().format("YYYY-MM-DDTHH:mm:ss");
        this.transactionObject.caseStatus = "Draft";
        
        this.efilingdetails.ApplicationBusinessObject.transactionObject = this.transactionObject;
       let responsePromise = this._cordysService.callCordysSoapService("SaveEfilingDetails", "http://schemas.cordys.com/default", this.efilingdetails, null, null, false, { comp: this });
       responsePromise.success((data) => {
            tempRef = data.success.ApplicationBusinessObject.transactionObject.referenceNumber;  
            tempBPMId = data.success.ApplicationBusinessObject.transactionObject.bpmID
        });
        responsePromise.error((data) => {
        this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error while saving the details", 5000));
         });
         this.transactionObject.referenceNumber = tempRef;
         this.transactionObject.bpmID = tempBPMId;
    }
    }

    private successHandler1(response, prms) {
        prms.comp.efilingdetails.ApplicationBusinessObject = response.success.ApplicationBusinessObject;
        prms.comp.transactionObject.referenceNumber = response.success.ApplicationBusinessObject.transactionObject.referenceNumber;
        prms.comp.transactionObject.bpmID = response.success.ApplicationBusinessObject.transactionObject.bpmID;
        prms.comp.transactionObject.attachmentInfo = response.success.ApplicationBusinessObject.transactionObject.attachmentInfo;
        prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.SUCCESS, "Attachment added Successfully : " + response.success.ApplicationBusinessObject.transactionObject.referenceNumber, 7000));
    }

    handleError1(response, status, errorText, prms) {
        prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error while Deleting Document" , -1));
    }

   /* private copy(o) {
        let out, v, key;
        out = Array.isArray(o) ? [] : {};
        for (key in o) {
            v = o[key];
            out[key] = (typeof v === "object") ? this.copy(v) : v;
        }
        return out;
    } */    //End

    public getServerDate(): string {
        var server_date;
        var responsePromise = this._cordysService.callCordysSoapService("GetCurrentDate", "http://schemas.opentext.com/msig/persistancedb/1.0", null, null, null, false, null);
        responsePromise.done((data) => {
            server_date = data.tuple.old.getCurrentDate.getCurrentDate;
        });
        //server_date = ApplicationUtilService.getFormattedDate(server_date, "YYYY-MM-DD", "YYYY-MM-DD");
         //   server_date = moment.utc(server_date).local().format("YYYY-MM-DDTHH:mm:ss");

        return server_date;
    }

    public saveEfilingDetails() {//
        if (this.validDetails &&  this.transactionObject.attachmentInfo.attachment.length != 0) {
            this.SaveEFilingCase();
        }
        else {
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Please enter mandatory information and attachment before submitting. ", 50000))
        }
    }
    public SaveEFilingCase() {
        this.efilingdetails.ApplicationBusinessObject.transactionObject.scanDate = moment.utc(this.transactionObject.scanDate).local().format("YYYY-MM-DDTHH:mm:ss");
        this.efilingdetails.ApplicationBusinessObject.transactionObject.caseStatus = "Created";
        this._cordysService.callCordysSoapService("SaveEfilingDetails", "http://schemas.cordys.com/default", this.efilingdetails, this.successHandler, this.handleError, false, { comp: this });
    }

    private successHandler(response, prms) {
        prms.comp.efilingdetails.ApplicationBusinessObject = response.success.ApplicationBusinessObject;        
        prms.comp.transactionObject.referenceNumber = response.success.ApplicationBusinessObject.transactionObject.referenceNumber;
        prms.comp.transactionObject.bpmID = response.success.ApplicationBusinessObject.transactionObject.bpmID;
        prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.SUCCESS, "EFiling Details Saved Successfully : " + response.success.ApplicationBusinessObject.transactionObject.referenceNumber, 7000));
        prms.comp._router.navigate(["EfilingFinance"]);
        ProgressBarComponent.hide()
    }

    private handleError(response, status, errorText, prms) {
        prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, response.responseJSON.faultstring.text, 3000));
    }
    private setClientNumber(event) {
        this.transactionObject.clientNumber = event.target.value;
        this.getClientDetails(this.transactionObject.clientNumber);
        this.setUpdateDate();
    }
    setUpdateDate() {
        if (this.UPDTCtrl != null) {
            this.transactionObject.updateDate = ApplicationUtilService.getFormattedDate(this.transactionObject.updateDate, "YYYY-MM-DD", "YYYY-MM-DD");
            this.UPDTCtrl.setter(this.transactionObject.updateDate, "YYYY-MM-DD", this.UPDTCtrl.comp);
        }
    }
    private getClientDetails(clientNumber) {
        let request: GetLOVData = new GetLOVData();
        request.BRANCH = 'ALL';
        request.LOB = 'ALL';
        request.BUSINESS_FUNCTION = 'ALL';
        request.PRODUCT = 'ALL';
        request.OPERATION = 'ALL';
        request.FORM_NAME = 'ALL';
        request.FORM_FIELD_NAME = 'Client';
        request.FIELD_TYPE = 'LOOKUP';
        request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        request.ADVANCE_CONFIG_XML.FILTERS = new Filter();

        request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({ "@FIELD_NAME": 'CLNTNUM', "@FIELD_VALUE": clientNumber, '@OPERATION': 'EQ', '@CONDITION': 'AND' });
        this._cordysService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.clientNoSuccessHandler, this.handleError, false, { comp: this });

    }
    clientNoSuccessHandler(response, prms) {
        if (response.tuple != undefined) {
            prms.comp.transactionObject.accountHolderName = response.tuple.old.TABLE.NAME;
            prms.comp.transactionObject.NRIC = response.tuple.old.TABLE.NRIC;
            prms.comp.transactionObject.oldIC = response.tuple.old.TABLE.PASSPORT;
            prms.comp.getBankDetails(prms.comp.transactionObject.clientNumber);
        }
        else {
            prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "This is a non P400 Client.", 8000));
        }
    }

    private getBankDetails(clientNumber) {
        let request: GetLOVData = new GetLOVData();
        request.BRANCH = 'ALL';
        request.LOB = 'ALL';
        request.BUSINESS_FUNCTION = 'ALL';
        request.PRODUCT = 'ALL';
        request.OPERATION = 'ALL';
        request.FORM_NAME = 'ALL';
        request.FORM_FIELD_NAME = 'Bank Details';
        request.FIELD_TYPE = 'LOOKUP';
        request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        request.ADVANCE_CONFIG_XML.FILTERS = new Filter();

        request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({ "@FIELD_NAME": 'CLNTNUM', "@FIELD_VALUE": clientNumber, '@OPERATION': 'EQ', '@CONDITION': 'AND' });

        this._cordysService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.bankInfoSuccessHandler, this.handleError, false, { comp: this });
    }
    bankInfoSuccessHandler(response, prms) {
        if (response.tuple != undefined) {
            prms.comp.transactionObject.bankName = response.tuple.old.CLNBPF.BNKNAM;
            prms.comp.transactionObject.bankAccountNumber = response.tuple.old.CLNBPF.ZBANKACC;
            prms.comp.transactionObject.updateBy = response.tuple.old.CLNBPF.USER_PROFILE;
            prms.comp.transactionObject.updateDate = response.tuple.old.CLNBPF.DATIME;
        }
        else {
            prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Bank Details not available for this Client in P400", 8000))
        }
    }
    validDetails() {
        if ((this.transactionObject.clientNumber == '' && this.transactionObject.oracleNo == '') || AppUtil.isEmpty([this.transactionObject.scanDate, this.transactionObject.scannedBy, this.transactionObject.bankAccountNumber, this.transactionObject.bankName, this.transactionObject.updateBy, this.transactionObject.updateDate], true)) {
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Please fill all the mandatory information to proceed further", 8000));
            return false;
        }
        else {
            return true;
        }
    }
    removeDetails() {
        this.transactionObject.bankAccountNumber = this.transactionObject.bankName = this.transactionObject.updateBy = '';
        this.transactionObject.updateDate = ApplicationUtilService.getFormattedDate(new Date(this.getServerDate()), "YYYY-MM-DD", "YYYY-MM-DD")
    }

}
