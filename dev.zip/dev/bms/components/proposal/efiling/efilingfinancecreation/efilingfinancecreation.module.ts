import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { EfilingFinanceCreationComponent } from './efilingfinancecreation.component';
import { AdvancedSearchGridModule } from '../../../../../common/components/advancedsearchgrid/advancedsearchgrid.module';
import { EfilingDetails} from '../appobjects/efiling' ;
 
import { DatePickerModule } from '../../../../../common/components/utility/date/datepicker.module';

const webRouterConfig: Routes = [
    { path: "", component: EfilingFinanceCreationComponent }
];

let routerConfig = webRouterConfig;

@NgModule({
    imports: [CommonModule, FormsModule, ReactiveFormsModule, RouterModule.forChild(routerConfig), AdvancedSearchGridModule, DatePickerModule],
    declarations: [EfilingFinanceCreationComponent],
    exports: [EfilingFinanceCreationComponent, AdvancedSearchGridModule, RouterModule ]
})
export class EfilingFinanceCreationModule {
    public efilingDetails: EfilingDetails;
 }
