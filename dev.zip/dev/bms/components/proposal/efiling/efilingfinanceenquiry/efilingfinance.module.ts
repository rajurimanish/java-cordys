import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { EfilingFinanceComponent } from './efilingfinance.component';
import { AdvancedSearchGridModule } from '../../../../../common/components/advancedsearchgrid/advancedsearchgrid.module';



const webRouterConfig: Routes = [
    { path: "", component: EfilingFinanceComponent }
];

let routerConfig = webRouterConfig;

@NgModule({
    imports: [CommonModule, FormsModule, ReactiveFormsModule, RouterModule.forChild(routerConfig), AdvancedSearchGridModule],
    declarations: [EfilingFinanceComponent],
    exports: [EfilingFinanceComponent, AdvancedSearchGridModule, RouterModule]
})
export class EfilingFinanceModule { }
