import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { EventEmitter, Output, ViewChild, ViewContainerRef } from "@angular/core";
import { AdvancedSearchInput } from '../../../../../common/components/advancedsearchgrid/advancedsearchgridinput';
import { GetLOVData, SearchAdvancedConfig, Filter } from '../../../../../common/components/utility/search/search.requests';
import { AlertMessage } from '../../../../../common/components/utility/alertmessage/alertmessages.model';
import { AppUtil } from '../../../../../common/components/utility/apputil/app.util';
import { ModalInput } from "../../../../../common/components/utility/modal/modal";
import { CustomDCLService, DCLInput } from "../../../../../common/services/customdcl.service";
import { ApplicationUtilService } from '../../../../../common/services/application.util.service';
import { CordysSoapWService } from "../../../../../common/components/utility/cordys-soap-ws";
import { AlertMessagesService } from '../../../../../common/components/utility/alertmessage/alertmessages.service';
import { ProgressBarComponent } from '../../../../../common/components/utility/progressbar/progressbar.component';

import { EfilingFinanceCreationComponent } from '../efilingfinancecreation/efilingfinancecreation.component';
import { EFilingService } from '../efilingfinancecreation/efilingfinance.service';
declare var numeral: any;

@Component({
    selector: 'efilingfinance',
    templateUrl: 'app/bms/components/proposal/efiling/efilingfinanceenquiry/efilingfinance.template.html',
    providers: [EFilingService]
})

export class EfilingFinanceComponent implements OnInit {
    private advancedSearchInput: AdvancedSearchInput = new AdvancedSearchInput();
    @ViewChild('APIAreaModal', { read: ViewContainerRef }) contentArea: ViewContainerRef;
    constructor(private _cordysService: CordysSoapWService,public _alertMsgService: AlertMessagesService, private _router: Router, public dcl: CustomDCLService, private _appUtilService: ApplicationUtilService,private _efiling : EFilingService) {
    }

    ngOnInit() {

        this.advancedSearchInput.advancedFilterOptnsArry = { "LIKE": "LIKE", "EQ": "EQ", ">": "GT", ">=": "GTEQ", "<": "LT", "<=": "LTEQ" };
        this.advancedSearchInput.onColumnDataBind = this._appUtilService.transformValue;
        this.advancedSearchInput.isActionsHiddenFunction = this.checkHidden;
    }

    private checkHidden(app, action, report) {
        /*if (action.hiddenWhen != undefined && action.hiddenWhen.indexOf(report.status) > -1) {
            return false;
        }*/
        return false;

    }

    private onActionClick(event) {
        switch (event.action) {
            case "Edit":
                   this._router.navigate(["EfilingFinanceCreation", { referenceNo: event.item.referenceNo, component: "Modify"}]);
                        ProgressBarComponent.hide()
            break;
            case "Open":
               // this._efiling.GetEfilingObject(event.item.referenceNo);
                let compName = this._appUtilService.getNavigationComponent('BMS', event.item.referenceNo, 'N');
                this._router.navigate([compName, { referenceNo: event.item.referenceNo, component: "Enquiry"}]);
                        ProgressBarComponent.hide()              
            break;
            default: break;
        }
    }   
}
