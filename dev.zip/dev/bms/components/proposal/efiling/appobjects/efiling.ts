import { NgModule , OnInit } from '@angular/core';
import { AppUtil } from '../../../../../common/components/utility/apputil/app.util';

import { CustomDCLService, DCLInput } from '../../../../../common//services/customdcl.service';
import { EfilingFinanceCreationComponent} from '../efilingfinancecreation/efilingfinancecreation.component'
import { AttachmentInfo } from '../../../../../common/components/appobjects/attachmentinfo';

export class EfilingDetails {
    public efiling: Efiling;
       
    constructor() {
        this.efiling = new Efiling();
    }

    public getInstance(valObj: EfilingDetails) {
        if (new AppUtil().isValidObj(valObj) == true) {
            this.efiling = new Efiling().getInstance(valObj.efiling);
        }
        return this;
    }

    public refresh(valObj: EfilingDetails) {
        if (new AppUtil().isValidObj(valObj) == true) {
            this.efiling.refresh(valObj.efiling);
        }
    }    
}
    


export class Efiling {
    public itemNo: string = "";
    public clientNumber: string = "";
    public modifiedOn: string = "";
    
    public policyEfilingDetails: PolicyEfilingDetails;
    public financeEfilingDetails: FinanceEfilingDetails;
    
    constructor() {
      
        this.financeEfilingDetails = new FinanceEfilingDetails();
        this.policyEfilingDetails = new PolicyEfilingDetails();
    
    }

    public getInstance(valObj: Efiling) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
      
            this.policyEfilingDetails = new PolicyEfilingDetails().getInstance(valObj.policyEfilingDetails);
            this.financeEfilingDetails = new FinanceEfilingDetails().getInstance(valObj.financeEfilingDetails);     
        }
        return this;
    }

    public refresh(valObj: Efiling) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValueByType(this, valObj);
     
            this.policyEfilingDetails.refresh(valObj.policyEfilingDetails);
            this.financeEfilingDetails.refresh(valObj.financeEfilingDetails);
            
        }
    }
}



export class PolicyEfilingDetails {
     public attachment: Attachment;
     public ApplicationBusinessObject:ApplicationBusinessObject;
     public caseInfo :CaseInfo;

    constructor() {
        this.attachment = new Attachment();
        this.caseInfo = new CaseInfo();
        this.ApplicationBusinessObject = new ApplicationBusinessObject();
    }
    public getInstance(valObj: PolicyEfilingDetails) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
            this.attachment = new Attachment().getInstance(valObj.attachment);
        }
        return this;
    }

    public refresh(valObj: PolicyEfilingDetails) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValueByType(this, valObj);
            this.attachment.refresh(valObj.attachment);
        }
    }
}



export class FinanceEfilingDetails {
   
    public attachment: Attachment;
    public ApplicationBusinessObject:ApplicationBusinessObject;
    
    public caseInfo :CaseInfo;
    constructor() {
        this.attachment = new Attachment();
        this.caseInfo = new CaseInfo();
        this.ApplicationBusinessObject = new ApplicationBusinessObject();
    }
    public getInstance(valObj: FinanceEfilingDetails) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
            this.attachment = new Attachment().getInstance(valObj.attachment);
        }
        return this;
    }

    public refresh(valObj: FinanceEfilingDetails) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValueByType(this, valObj);
            this.attachment.refresh(valObj.attachment);
        }
    }
}

export class Attachment {
   
    public ID :string = "";
    public recallBoxNo: string ="";
    public dateAttached: string ="";
    public comments: string ="";
    public attachmentName: string ="";
    public sLocationUrl: string ="";
    public attachedBy: string ="";
    public attachmentType: string ="";

    public getInstance(valObj: Attachment) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
        }
        return this;
    }

    public refresh(valObj: Attachment) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValueByType(this, valObj);
        }
    }
}
export class CaseInfo {
    public status:string = "";

    public getInstance(valObj: CaseInfo) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
        }
        return this;
    }

    public refresh(valObj: CaseInfo) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValueByType(this, valObj);
        }
    }    
}
export class ApplicationBusinessObject {
    public transactionObject:TransactionObject;
    public policyDetails:PolicyDetails;


    constructor(){
        this.policyDetails = new PolicyDetails();
        this.transactionObject = new TransactionObject();
    }

    public getInstance(valObj: ApplicationBusinessObject) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
            this.policyDetails = new PolicyDetails().getInstance(valObj.policyDetails);
            this.transactionObject = new TransactionObject().getInstance(valObj.transactionObject);
        }
        return this;
    }

    public refresh(valObj: ApplicationBusinessObject) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValueByType(this, valObj);
            this.policyDetails = new PolicyDetails().getInstance(valObj.policyDetails);
            this.transactionObject = new TransactionObject().getInstance(valObj.transactionObject);
        }
    }    
}


export class TransactionObject {
    public attachmentInfo: AttachmentInfo;
    public referenceNumber: string = "";
    public clientNumber: string = "";
    public ORASUPPNO: string = "";
    public clientName: string = "";
    public NRIC: string = "";
    public OLDICNO: string = "E";
    public bankName: string = "";    
    public bankAccountNumber :string = "";
    public updateBy :string = "";
    public updateDate :Date;
    public offsiteStorageNumber :string = "";
    public businessFunction : string = "eFilingFinance";
    public scanDate :any;
    public scannedBy :string = "";
    public caseInfo :CaseInfo;
    public oracleNo :string = ""
    public bpmID :string = "";
    public attachmentID :string = "";
    public remarks :string = "";
    public caseStatus :string = "";

    constructor() {
        this.attachmentInfo = new AttachmentInfo();
    }

    public getInstance(valObj: TransactionObject) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
        }
        return this;
    }

    public refresh(valObj: TransactionObject) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValueByType(this, valObj);
        }
    }
}

export class PolicyDetails {
    public attachmentInfo: AttachmentInfo;
    public refNo: string = "";
    public policyNo: string = "";
    public insuredName: string = "";
    public NRIC: string = "";
    public docTypeId: string = "";
    public branchId: string = "";
    public contractType :string = "";
    public accountNo: string = "";
    public remarks: string = "";
    public MOCNo :string = "";
    public sumInsured :number = 0;
    public vehicleNo :string = "";
    public businessFunction : string = "eFilingPolicy";
    public storageNo :string = "";
    public transactionNo :string = "";
    public scanDate :Date;
    public scanBy :string = "";
    public userId :string = "";
    public caseStatus :string = "";
    public caseInfo :CaseInfo;
    constructor() {
        this.attachmentInfo = new AttachmentInfo();
    }
    public getInstance(valObj: PolicyDetails) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
        }
        return this;
    }

    public refresh(valObj: PolicyDetails) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValueByType(this, valObj);
        }
    }
}


