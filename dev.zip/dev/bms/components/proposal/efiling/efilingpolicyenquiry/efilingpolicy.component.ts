import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { EventEmitter, Output, ViewChild, ViewContainerRef } from "@angular/core";
import { AdvancedSearchInput } from '../../../../../common/components/advancedsearchgrid/advancedsearchgridinput';
import { GetLOVData, SearchAdvancedConfig, Filter } from '../../../../../common/components/utility/search/search.requests';
import { AppUtil } from '../../../../../common/components/utility/apputil/app.util';
import { ModalInput } from "../../../../../common/components/utility/modal/modal";
import { CustomDCLService, DCLInput } from "../../../../../common/services/customdcl.service";
import { ApplicationUtilService } from '../../../../../common/services/application.util.service';
import { CordysSoapWService } from "../../../../../common/components/utility/cordys-soap-ws";
import { AlertMessagesService } from '../../../../../common/components/utility/alertmessage/alertmessages.service';
import { AlertMessage } from '../../../../../common/components/utility/alertmessage/alertmessages.model';
import { ProgressBarComponent } from '../../../../../common/components/utility/progressbar/progressbar.component';

declare var numeral: any;

@Component({
    selector: 'efilingpolicy',
    templateUrl: 'app/bms/components/proposal/efiling/efilingpolicyenquiry/efilingpolicy.template.html'
})

export class EfilingPolicyComponent implements OnInit {
    private advancedSearchInput: AdvancedSearchInput = new AdvancedSearchInput();
    @ViewChild('APIAreaModal', { read: ViewContainerRef }) contentArea: ViewContainerRef;
    constructor(public _alertMsgService: AlertMessagesService,private _cordysService: CordysSoapWService,private _router: Router, public dcl: CustomDCLService, private _appUtilService: ApplicationUtilService) {
    }

    ngOnInit() {

        this.advancedSearchInput.advancedFilterOptnsArry = { "LIKE": "LIKE", "EQ": "EQ", ">": "GT", ">=": "GTEQ", "<": "LT", "<=": "LTEQ" };
        this.advancedSearchInput.onColumnDataBind = this._appUtilService.transformValue;
        this.advancedSearchInput.isActionsHiddenFunction = this.checkHidden;
    }

    private checkHidden(app, action, report) {
        /*if (action.hiddenWhen != undefined && action.hiddenWhen.indexOf(report.status) > -1) {
            return false;
        }*/
        return false;

    }

    private onActionClick(event) {
        switch (event.action) {
            case "Download":
            if(event.item.otcsReference == null || event.item.otcsReference == '')
            this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Document not available for this reference no.", -1));
            else
            this.downloadDocument(event.item.otcsReference)
            default: break;
        }
    }

     private downloadDocument(urlLocation) {
           ProgressBarComponent.show('Loading', { dialogSize: 'm', progressType: 'success' });
        var downloadParameter = {documentURL:urlLocation,xmlStoreECMPropPath:""};                
        var responsePromise = this._cordysService.callCordysSoapService("GetDocumentWithContent", "http://schemas.cordys.com/ecm/integration/1.0", downloadParameter, this.documentDeleteSuccessHandler, null, false, { comp: this });        
           responsePromise.success((data) => {
           
            ProgressBarComponent.hide();
        });
        responsePromise.error((data) => {
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error while downloading the document.", 5000));
            ProgressBarComponent.hide();
        });
    }
	
	private documentDeleteSuccessHandler(data, prms) {
        var response = data.tuple.old.getDocumentWithContent.getDocumentWithContent.GetDocumentResponse;
        var downloadURL: string = response.DocumentContent.text;
        var fileName: string = downloadURL.substring(downloadURL.lastIndexOf("/") + 1);
        window.open("/" + downloadURL.replace(fileName, encodeURIComponent(fileName)));        
        setTimeout(() => {
            if (response != undefined && response.Folder != undefined && response.Folder != "" && response.DocumentName != undefined && response.DocumentName != "") {
                prms.comp._cordysService.callCordysSoapService("DeleteFileAttachment", "http://schemas.cordys.com/ecm/integration/1.0", { "filePath": response.Folder + "/" + response.DocumentName }, null, null, true, null);
            }
        }, 6000);
    }
	
	 getDownloadedLink(data) {
        var response = data.tuple.old.getDocumentWithContent.getDocumentWithContent.GetDocumentResponse;
        var downloadURL = response.DocumentContent.text;
        window.open("/" + downloadURL);
    }
	
	 /*private getDownLoadParameter(podattachment) {        
        return {
            documentURL: podattachment.sLocationUrl,
            xmlStoreECMPropPath: ""
        }
    }*/
}
