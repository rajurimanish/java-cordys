import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { EventEmitter, Output, ViewChild, ViewContainerRef } from "@angular/core";
import { AdvancedSearchInput } from '../../../../../common/components/advancedsearchgrid/advancedsearchgridinput';
import { GetLOVData, SearchAdvancedConfig, Filter,ReplaceField } from '../../../../../common/components/utility/search/search.requests';
import { AlertMessage } from '../../../../../common/components/utility/alertmessage/alertmessages.model';
import { AppUtil } from '../../../../../common/components/utility/apputil/app.util';
import { ModalInput } from "../../../../../common/components/utility/modal/modal";
import { CustomDCLService, DCLInput } from "../../../../../common/services/customdcl.service";
import { ApplicationUtilService } from '../../../../../common/services/application.util.service';
import { CordysSoapWService } from "../../../../../common/components/utility/cordys-soap-ws";
import { AlertMessagesService } from '../../../../../common/components/utility/alertmessage/alertmessages.service';
import { ProgressBarComponent } from '../../../../../common/components/utility/progressbar/progressbar.component';
import { PolicyEfilingDetails, CaseInfo, PolicyDetails, ApplicationBusinessObject, } from '../appobjects/efiling';
import { SearchInput } from "../../../../../common/components/utility/search/genericsearch";
import { DatePicker } from '../../../../../common/components/utility/date/datepicker.component';

declare var Rx: any;
declare var moment: any;
declare var numeral: any;

@Component({
    selector: 'efilingpolicycreation',
    templateUrl: 'app/bms/components/proposal/efiling/efilingpolicycreation/efilingpolicycreation.template.html',
    inputs: ['efiling']
})

export class EfilingPolicyCreationComponent implements OnInit {

    private efiling: PolicyEfilingDetails = new PolicyEfilingDetails();
    private dateNotif: any;
    private _serverdate: string;
    public loggedInUser:string;
    public userID:string;
    public replaceField = [];
    private isATCollapsedMode: boolean = false;
    private isATLoaded: boolean = false;
    private scanDateCtrl: any;
    private ApplicationBusinessObject :ApplicationBusinessObject = new ApplicationBusinessObject();
    private caseInfo:CaseInfo = new CaseInfo();
    private policyDetails:PolicyDetails = new PolicyDetails();

    public userRoles: any[];

    @ViewChild('atModal', { read: ViewContainerRef }) atArea: ViewContainerRef;

    private advancedSearchInput: AdvancedSearchInput = new AdvancedSearchInput();
    @ViewChild('APIAreaModal', { read: ViewContainerRef }) contentArea: ViewContainerRef;
    constructor(private _cordysService: CordysSoapWService,public _alertMsgService: AlertMessagesService, private _router: Router, public dcl: CustomDCLService, private _appUtilService: ApplicationUtilService) {
    }

    ngOnInit() {
        this.initData();
        this.advancedSearchInput.advancedFilterOptnsArry = { "LIKE": "LIKE", "EQ": "EQ", ">": "GT", ">=": "GTEQ", "<": "LT", "<=": "LTEQ" };
        this.advancedSearchInput.onColumnDataBind = this._appUtilService.transformValue;
        this.advancedSearchInput.isActionsHiddenFunction = this.checkHidden;
        this._serverdate = this.getServerDate();
        if (this.scanDateCtrl) {
            this.scanDateCtrl.setter('EMPTY', "YYYY-MM-DD", this.scanDateCtrl.comp);
        }
    }

    private checkHidden(app, action, report) {
        return false;

    }

    private setUserId(data) {
        this.userID = data.substring(3, data.indexOf(","));
    }
    initData() {
        let date = new Date(this.getServerDate());
        if(this.policyDetails.scanDate){
            this.policyDetails.scanDate = moment.utc(this.policyDetails.scanDate).local().format("YYYY-MM-DDTHH:mm:ss");
        }
        else {
            this.policyDetails.scanDate = date;
                }
        let udn = this._appUtilService.getUserDn();
        let uname = this._appUtilService.getUserName(); 
        let uroles = this._appUtilService.getUserRoles();
        this.caseInfo.status = "Assessment";
        let dataComplete = Rx.Observable.zip(udn, uname,  (usrdn: any, usrname: any, urole: any) => { return { usrdn: usrdn, usrname: usrname, urole:urole } });
        dataComplete.subscribe((data) => {
            this.setUserId(data.usrdn);
            this.userRoles = data.urole;
            this.loggedInUser = data.usrname;
            if(this.policyDetails.scanBy == ''){
                this.policyDetails.scanBy = data.usrname;
                this.policyDetails.userId = data.usrname;
                }
        });
         this.isATCollapsedMode=true;
         this.policyDetails.docTypeId = "GENDOC";
        this.loadAT();
    }

    private getPolicyDetails(policy) {
        this.policyDetails.branchId = "";
        this.policyDetails.insuredName = "";
        this.policyDetails.NRIC = "";
        this.policyDetails.accountNo = "";
        this.policyDetails.contractType = "";
        this.policyDetails.vehicleNo = "";
        this.policyDetails.MOCNo = "";
        this.policyDetails.storageNo = "";
        this.policyDetails.transactionNo = "";
        this.policyDetails.transactionNo = "";
        this.policyDetails.sumInsured = 0;
        this.policyDetails.remarks = "";
        this.policyDetails.docTypeId = "GENDOC";

        if(policy!=""){
        this._serverdate = this.getServerDate();
        this._serverdate = this._serverdate.split('T')[0].split('-')[0] + "" + this._serverdate.split('T')[0].split('-')[1] + "" +
            this._serverdate.split('T')[0].split('-')[2];
        let request: GetLOVData = new GetLOVData();
        request.BRANCH = 'ALL';
        request.LOB = 'ALL';
        request.BUSINESS_FUNCTION = 'NEW BUSINESS';
        request.PRODUCT = 'ALL';
        request.OPERATION = 'NEW';
        request.FORM_NAME = 'EFILING_POLICY_DETAILS';
        request.FORM_FIELD_NAME = 'POLICY_NUMBER';
        request.FIELD_TYPE = 'LOOKUP';
        request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        request.ADVANCE_CONFIG_XML.REPLACEFIELDS = new ReplaceField();
        request.ADVANCE_CONFIG_XML.REPLACEFIELDS.REPLACEFIELD.push(
                { "@FIELD_NAME": "POLICYNO", "@FIELD_VALUE": "'" + policy + "'", '@OPERATION': "PARAM" },
                { "@FIELD_NAME": "CURRDATE", "@FIELD_VALUE": "'" + this._serverdate + "'", '@OPERATION': "PARAM" },
            );
            this._cordysService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.policySuccessHandler, this.handleError, true, { comp: this });
        }    
}
    

    policySuccessHandler(response, prms){
        if ( response.tuple ) {
                prms.comp.policyDetails.insuredName = response.tuple.old.RCGOPF.FULLNAME;
                prms.comp.policyDetails.branchId = response.tuple.old.RCGOPF.POLICYBRANCH;
                prms.comp.policyDetails.NRIC = response.tuple.old.RCGOPF.SECUITYNO;
                prms.comp.policyDetails.accountNo = response.tuple.old.RCGOPF.AGNTNUM;
                prms.comp.policyDetails.contractType = response.tuple.old.RCGOPF.CNTTYPE;
                prms.comp.policyDetails.MOCNo = response.tuple.old.RCGOPF.MOC;
            if(response.tuple.old.RCGOPF.VEHICLEREGNO)
                prms.comp.policyDetails.VEHICLENO = response.tuple.old.RCGOPF.VEHICLEREGNO;
            else
                prms.comp.policyDetails.vehicleNo = response.tuple.old.RCGOPF.VEHICLEREGNO1;
        }
        else {
            prms.comp.policyDetails.policyNo = "";
            prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Policy Number does not exist in P400", 5000));
        }
    }

    handleError(response, status, errorText, prms) {
        prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, response.responseJSON.faultstring.text, -1));
    }

    private savePolicyEfilingDetails(){
        if(this.validateFields()){
        if(this.policyDetails.policyNo != "" || this.policyDetails.policyNo.length == 0){
            this.SavePolicyEfilingCase(); 
            }
            else{
                this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Please enter mandatory information before submitting. " , 50000)) 
            }
        }
    }

    public SavePolicyEfilingCase(){
        this.policyDetails.scanDate = moment.utc(this.policyDetails.scanDate).local().format("YYYY-MM-DDTHH:mm:ss");
        
        this.policyDetails.caseStatus = "Created";
        if(this.policyDetails.policyNo !='')
        this.efiling.ApplicationBusinessObject.policyDetails = this.policyDetails;
        else
        this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Please enter policy no. " , 50000)) 
        this._cordysService.callCordysSoapService("SavePolicyEfilingDetails", "http://schemas.cordys.com/default", this.efiling, this.successHandler, this.handleError, false, { comp: this });
    }

    private successHandler(response, prms) {
        prms.comp.efiling.ApplicationBusinessObject = response.success.ApplicationBusinessObject;
        prms.comp.policyDetails.refNo = response.success.ApplicationBusinessObject.policyDetails.refNo;
       prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.SUCCESS, "Case Saved Successfully : " + response.success.ApplicationBusinessObject.policyDetails.refNo, 7000));   
       prms.comp._router.navigate(["EfilingPolicy"]);
}

    public getServerDate(): string {

        let server_date;
        let responsePromise = this._cordysService.callCordysSoapService("GetCurrentDate", "http://schemas.opentext.com/msig/persistancedb/1.0", null, null, null, false, null);
        responsePromise.done((data) => {
            server_date = data.tuple.old.getCurrentDate.getCurrentDate;
        });
        return server_date;
    }

    private loadAT() {     
        if (this.isATLoaded == false) {
          
                this.loadATNB();
        }
    }

    private loadATNB() {
        if (this.isATLoaded == false) {
            let input = new DCLInput();
            input.component = ["AttachmentComponent", "app/common/components/attachment/attachment.module", "AttachmentModule"];
            input.viewContainerRef = this.atArea;
           //let tempPolicyDetails: any = this.copy(this.policyDetails);
           input.inputs = { CurrentUser: this.userID, setRoles: '', branch: this.policyDetails.branchId, isCMS: false, lob: "", _attachments: this.policyDetails.attachmentInfo, caseInfo: this.policyDetails };
            this.dcl.loadComponent(input).subscribe((compRef) => {
                if (compRef.instance.saveBO != null) {
                    compRef.instance.saveBO.subscribe((values) => {
                        this.attachmentAdded(values);
                    });
                }
                this.isATLoaded = true;
            });
        }
        return false;
    }


    attachmentAdded(callerObject) {
        let tempRef = "";
    if(callerObject != null) {
        if(callerObject.docAttached)  {   
        this.policyDetails.scanDate = moment.utc(this.policyDetails.scanDate).local().format("YYYY-MM-DDTHH:mm:ss");
        this.policyDetails.caseStatus = "Draft";
        this.efiling.ApplicationBusinessObject.policyDetails = this.policyDetails;
        this.efiling.ApplicationBusinessObject.policyDetails.attachmentInfo = callerObject.comp.attachmentInfo;
        this._cordysService.callCordysSoapService("SavePolicyEfilingDetails", "http://schemas.cordys.com/default", this.efiling, this.successHandler1, this.handleError, false, { comp: this });
        }    
        else if(callerObject.docDeleted) {
            this._cordysService.callCordysSoapService("DeleteEfilingDoc", "http://schemas.cordys.com/EfilingWSAppServerPackage",{ "locationURL": callerObject.attachmentData.sLocationUrl } , null, this.handleError1, false, { comp: this });
        }
    }
        else if(this.policyDetails.refNo == "") {
        this.policyDetails.scanDate = moment.utc(this.policyDetails.scanDate).local().format("YYYY-MM-DDTHH:mm:ss");
        this.policyDetails.caseStatus = "Draft";
        
        this.efiling.ApplicationBusinessObject.policyDetails = this.policyDetails;
       let responsePromise = this._cordysService.callCordysSoapService("SavePolicyEfilingDetails", "http://schemas.cordys.com/default", this.efiling, null, null, false, { comp: this });
       responsePromise.success((data) => {
            tempRef = data.success.ApplicationBusinessObject.policyDetails.refNo;  

        });
        responsePromise.error((data) => {
        this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error while saving the details", 5000));
         });
         this.policyDetails.refNo = tempRef;
    }
        
    }

    private successHandler1(response, prms) {
        prms.comp.efiling.ApplicationBusinessObject = response.success.ApplicationBusinessObject;
       
}

handleError1(response, status, errorText, prms) {
    prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error while Deleting Document" , -1));
}

   /* private copy(o) {
        let out, v, key;
        out = Array.isArray(o) ? [] : {};
        for (key in o) {
            v = o[key];
            out[key] = (typeof v === "object") ? this.copy(v) : v;
        }
        return out;
    }*/
     //End

    private validateSumInsured(sumInsured){
        if (isNaN(this.policyDetails.sumInsured) == true) {
            this.policyDetails.sumInsured = 0;
            this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Only number value is allowed.", -1));
        }
    }

    validateFields(){
        if(this.policyDetails.policyNo == "" || this.policyDetails.policyNo.length == 0){
            this._alertMsgService.add( new AlertMessage( AlertMessage.ERROR, "Please enter policy no and proceed.", -1 ) );
            return false;
        }
        if(this.policyDetails.branchId == ""){
            this._alertMsgService.add( new AlertMessage( AlertMessage.ERROR, "Branch Code is mandatory.", -1 ) );
            return false;
        }
        if(this.policyDetails.docTypeId == ""){
            this._alertMsgService.add( new AlertMessage( AlertMessage.ERROR, "Document Type is mandatory.", -1 ) );
            return false;
        }
        if(this.policyDetails.insuredName == ""){
            this._alertMsgService.add( new AlertMessage( AlertMessage.ERROR, "Insured Name is mandatory.", -1 ) );
            return false;
        }
        if(this.policyDetails.NRIC == ""){
            this._alertMsgService.add( new AlertMessage( AlertMessage.ERROR, "NRIC number is mandatory.", -1 ) );
            return false;
        }
        if(this.policyDetails.accountNo == ""){
            this._alertMsgService.add( new AlertMessage( AlertMessage.ERROR, "Account number is mandatory.", -1 ) );
            return false;
        }
        if(this.policyDetails.transactionNo == ""){
            this._alertMsgService.add( new AlertMessage( AlertMessage.ERROR, "Transaction number is mandatory.", -1 ) );
            return false;
        }
        if(this.efiling.ApplicationBusinessObject.policyDetails.attachmentInfo.attachment.length<=0)        
        {
            this._alertMsgService.add( new AlertMessage( AlertMessage.ERROR, "Attach the document before submiting.", -1 ) );
            return false;
        }
        return true;
    }

}
