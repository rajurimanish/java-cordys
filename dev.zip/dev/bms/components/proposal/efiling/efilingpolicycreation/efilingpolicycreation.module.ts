import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { EfilingPolicyCreationComponent } from './efilingpolicycreation.component';
import { AdvancedSearchGridModule } from '../../../../../common/components/advancedsearchgrid/advancedsearchgrid.module';
import { PolicyEfilingDetails} from '../appobjects/efiling' ;
import { DatePickerModule } from '../../../../../common/components/utility/date/datepicker.module';


const webRouterConfig: Routes = [
    { path: "", component: EfilingPolicyCreationComponent }
];

let routerConfig = webRouterConfig;

@NgModule({
    imports: [CommonModule, FormsModule, ReactiveFormsModule, RouterModule.forChild(routerConfig), AdvancedSearchGridModule, DatePickerModule],
    declarations: [EfilingPolicyCreationComponent],
    exports: [EfilingPolicyCreationComponent, AdvancedSearchGridModule, RouterModule]
})
export class EfilingPolicyCreationModule { 
    public PolicyEfilingDetails: PolicyEfilingDetails;
    
}
