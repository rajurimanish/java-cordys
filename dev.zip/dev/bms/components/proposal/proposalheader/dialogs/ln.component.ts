import { Component, ElementRef, OnInit, NgZone } from "@angular/core";
import { ProposalHeader } from '../appobjects/proposalheader';

declare var jQuery: any;

@Component({
    selector: "long-name",
    templateUrl: "app/bms/components/proposal/proposalheader/dialogs/ln.template.html",
    inputs: ['datainput', 'closeDialog', 'parentCompPRMS']
})
export class LNComponent implements OnInit {
    private el: HTMLElement;
    private insuredLongName1: string;
    private insuredLongName2: string;
    private insuredLongName3: string;
    private insuredLongName4: string;
    private insuredLongName5: string;
    public proposalHeader: ProposalHeader;
    public isViewMode: string = 'N';

    public datainput: any;
    public closeDialog: Function;
    public parentCompPRMS: any;

    constructor(el: ElementRef) {
        this.el = el.nativeElement;
    }

    ngOnInit() {
        this.proposalHeader = this.datainput.proposalHeader;
        this.isViewMode = this.datainput.isViewMode;
        this.insuredLongName1 = this.datainput.proposalHeader.insuredLongName1;
        this.insuredLongName2 = this.datainput.proposalHeader.insuredLongName2;
        this.insuredLongName3 = this.datainput.proposalHeader.insuredLongName3;
        this.insuredLongName4 = this.datainput.proposalHeader.insuredLongName4;
        this.insuredLongName5 = this.datainput.proposalHeader.insuredLongName5;
    }

    setFocusToNext(elmnt) {
        let sutuationElmnts = jQuery(this.el).find("input");
        jQuery(sutuationElmnts[sutuationElmnts.index(elmnt) + 1]).focus();
    }

    save() {
        this.datainput.proposalHeader.insuredLongName1 = this.insuredLongName1;
        this.datainput.proposalHeader.insuredLongName2 = this.insuredLongName2;
        this.datainput.proposalHeader.insuredLongName3 = this.insuredLongName3;
        this.datainput.proposalHeader.insuredLongName4 = this.insuredLongName4;
        this.datainput.proposalHeader.insuredLongName5 = this.insuredLongName5;
        this.closeDialog(null, this.parentCompPRMS);
    }

    cancel() {
        this.closeDialog(null, this.parentCompPRMS);
    }
}