import { Component, ElementRef, OnInit, NgZone } from "@angular/core";
import { CordysSoapWService } from '../../../../../common/components/utility/cordys-soap-ws';
import { AlertMessagesService } from '../../../../../common/components/utility/alertmessage/alertmessages.service';
import { AlertMessage } from '../../../../../common/components/utility/alertmessage/alertmessages.model';
import { GetLOVData, SearchAdvancedConfig, Filter } from '../../../../../common/components/utility/search/search.requests';
import { AppUtil } from '../../../../../common/components/utility/apputil/app.util';

declare var jQuery: any;
declare var moment: any;

@Component({
    selector: "agent-info",
    templateUrl: "app/bms/components/proposal/proposalheader/dialogs/moc.details.template.html",
    inputs: ['datainput', 'closeDialog', 'parentCompPRMS']
})

export class MOCDetailsComponent implements OnInit {
    public datainput: any;
    public closeDialog: Function;
    public parentCompPRMS: any;

    private marineOpenCover: string = '';
    private mocStatus: string = '';
    private clientNumber: string = '';
    private clientName: string = '';
    private minimumPremium: number = 0;
    private commission: number = 0;
    private inceptionDate: string = '';
    private expiryDate: string = '';
    private interest: string = '';
    private voyage: string = '';
    private limits: string = '';
    private rates: string = '';
    private basisOfValuation: string = '';
    private conditionsOfCover: string = '';

    constructor(private _soapService: CordysSoapWService, public _alertMsgService: AlertMessagesService) { }

    ngOnInit() {

        this.marineOpenCover = this.parentCompPRMS.comp.proposalHeader.marineOpenCover;
        let request: GetLOVData = new GetLOVData().getRequest('ALL', 'MAR', 'ALL', 'ALL', 'ALL', 'ALL', 'Marine Open Cover', 'LOOKUP');
        request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        request.ADVANCE_CONFIG_XML.FILTERS = new Filter();

        request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push(
            { "@FIELD_NAME": "A.MCOVER", "@FIELD_VALUE": this.marineOpenCover, "@OPERATION": "EQ", "@CONDITION": "AND" });

        this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, null, null, false, null).success((data) => {

            let ary = [];

            if (data.tuple) {
                ary = new AppUtil().getArray(data.tuple);
            }

            if (ary && ary.length > 0) {
                //MAX(A.TRANNO) AS TRANNO, A.MCOVER, A.MTYPE, A.CLNTNUM, RTRIM(C.SURNAME) || C.GIVNAME AS CLIENTNAME, C.CLTDOB, C.CLTTYPE, A.CCDATE, A.CRDATE
                //A.STATCODE,A.MINPREM, A.ORIGCOMM

                this.mocStatus = (ary[0].old.WMOCPF.STATCODE && ary[0].old.WMOCPF.STATCODE == 'IF') ? 'In Force See Endorsement' : '';
                this.clientNumber = ary[0].old.WMOCPF.CLNTNUM;
                this.clientName = '';
                this.minimumPremium = ary[0].old.WMOCPF.MINPREM;
                this.commission = ary[0].old.WMOCPF.ORIGCOMM;
                this.inceptionDate = (ary[0].old.WMOCPF.CCDATE == null || ary[0].old.WMOCPF.CCDATE == "" || ary[0].old.WMOCPF.CCDATE == "99999999") ? "" : moment(ary[0].old.WMOCPF.CCDATE, "YYYYMMDD").format("YYYY-MM-DD");
                this.expiryDate = (ary[0].old.WMOCPF.CRDATE == null || ary[0].old.WMOCPF.CRDATE == "" || ary[0].old.WMOCPF.CRDATE == "99999999") ? "" : moment(ary[0].old.WMOCPF.CRDATE, "YYYYMMDD").format("YYYY-MM-DD");
            }
        }).error((response, status, errorText) => {
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error while getting MOC details", 5000));
        });

        this.getWOCTPFData();
    }

    getWOCTPFData() {

        let request: GetLOVData = new GetLOVData().getRequest('ALL', 'MAR', 'ALL', 'ALL', 'ALL', 'ALL', 'WOCTPF Data', 'LOV');
        request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        request.ADVANCE_CONFIG_XML.FILTERS = new Filter();

        request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push(
            { "@FIELD_NAME": "MCOVER", "@FIELD_VALUE": this.marineOpenCover, "@OPERATION": "EQ", "@CONDITION": "AND" },
            { "@FIELD_NAME": "DTETER", "@FIELD_VALUE": '99999999', "@OPERATION": "EQ", "@CONDITION": "AND" }
        );

        this._soapService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, null, null, false, null).success((data) => {
            let _arr = [];
            if (data.tuple) {
                _arr = new AppUtil().getArray(data.tuple);

                if (_arr && _arr.length > 0) {
                    for (let _moc of _arr) {
                        if (_moc.old.WOCTPF.TXTLINE) {
                            if (_moc.old.WOCTPF.SCREEN_COLUMN == '1') {
                                if (this.interest && _moc.old.WOCTPF.TXTLINE)
                                    this.interest += '\n';

                                this.interest += _moc.old.WOCTPF.TXTLINE;
                            }
                            else if (_moc.old.WOCTPF.SCREEN_COLUMN == '2') {
                                if (this.voyage && _moc.old.WOCTPF.TXTLINE)
                                    this.voyage += '\n';
                                this.voyage += _moc.old.WOCTPF.TXTLINE;
                            }
                            else if (_moc.old.WOCTPF.SCREEN_COLUMN == '4') {
                                if (this.limits && _moc.old.WOCTPF.TXTLINE)
                                    this.limits += '\n';
                                this.limits += _moc.old.WOCTPF.TXTLINE;
                            }
                            else if (_moc.old.WOCTPF.SCREEN_COLUMN == '5') {
                                if (this.rates && _moc.old.WOCTPF.TXTLINE)
                                    this.rates += '\n';
                                this.rates += _moc.old.WOCTPF.TXTLINE;
                            }
                            else if (_moc.old.WOCTPF.SCREEN_COLUMN == '6') {
                                if (this.basisOfValuation && _moc.old.WOCTPF.TXTLINE)
                                    this.basisOfValuation += '\n';
                                this.basisOfValuation += _moc.old.WOCTPF.TXTLINE;
                            }
                            else if (_moc.old.WOCTPF.SCREEN_COLUMN == '7') {
                                if (this.conditionsOfCover && _moc.old.WOCTPF.TXTLINE)
                                    this.conditionsOfCover += '\n';
                                this.conditionsOfCover += _moc.old.WOCTPF.TXTLINE;
                            }
                        }
                    }
                }
            }
        }).error((response, status, errorText) => {
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error while getting MOC deatils", 5000));
        });
    }

}