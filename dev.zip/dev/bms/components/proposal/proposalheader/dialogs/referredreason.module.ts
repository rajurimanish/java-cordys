import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { ReferredReasonComponent } from './referredreason.component';

@NgModule({
    imports: [CommonModule, FormsModule, ReactiveFormsModule],
    declarations: [ReferredReasonComponent],
    exports: [ReferredReasonComponent]
})
export class ReferredReasonModule { }