/*
Change History	:

	No      Date          Description                               					    Changed By
	====    ==========    ===========                              						    ==========						 
					  								   
	KA001  18/10/2018    MYS-2018-0896    -  To save Premium Details	               		  DKA
*/
import { Component, ElementRef, OnInit, NgZone } from "@angular/core";
import { ProposalHeader } from '../appobjects/proposalheader';
import { PostedPrem } from '../appobjects/postedprem';
import { AppUtil } from '../../../../../common/components/utility/apputil/app.util';
import { BMSConstants } from '../../../common/constants/bms_constants';
import { BMSUtilService } from "../../../../services/bms.util.service";

declare var jQuery: any;

@Component({
    selector: "posted-prem",
    templateUrl: "app/bms/components/proposal/proposalheader/dialogs/postedprem.template.html",
    inputs: ['datainput', 'closeDialog', 'parentCompPRMS']
})
export class PostedPremComponent implements OnInit {
    private el: HTMLElement;
    private postedPrem: PostedPrem;
    private riskCount: number;
    private riskObj: any;
    private premFormat: string;
    private isPremDisplayOnly: string = "N";
    private hasMinPrem: string = "N";

    public datainput: any;
    public closeDialog: Function;
    public parentCompPRMS: any;

    constructor(el: ElementRef, private _bus: BMSUtilService) {
        this.el = el.nativeElement;
    }

    ngOnInit() {
        this.setVars();
    }

    setVars() {
        this.riskObj = this.datainput.riskObj;
        //SST Code
        let headerInfo = BMSConstants.getBMSHeaderInfo();
        if (headerInfo.SSTLiveDate == "" || headerInfo.SSTLiveDate == undefined) {
            let tempRespObj = this._bus.getLiveDate();
            headerInfo.GSTLiveDate = tempRespObj[0].old.ITEMPF.LIVEDATE;
            headerInfo.SSTLiveDate = tempRespObj[1].old.ITEMPF.LIVEDATE;
        }
        if (headerInfo.SSTTaxRate.length == 0 || headerInfo.SSTTaxRate == undefined) {
            let respObj = this._bus.getTAXDetails();
            if (respObj != undefined && respObj != "") {
                headerInfo.SSTTaxRate = Number(respObj[0].old.ITEMPF.GST);
                headerInfo.GSTTaxRate = Number(respObj[1].old.ITEMPF.GST);

                this.riskObj.SST = (this.riskObj.SST == 0) ? Number(headerInfo.SSTTaxRate) : Number(this.riskObj.SST);
            }
        }
        let clientDetails = BMSConstants.getClientObj();
        if (clientDetails.client.genericDetails.clienttype == "P" && headerInfo.lineOfBusiness == "MED") {
            headerInfo.SSTTaxRate = 0;
            this.riskObj.SST = Number(headerInfo.SSTTaxRate);
        } else if (clientDetails.client.genericDetails.clienttype != "P") {
            if (headerInfo.SSTTaxRate.length == 0 || headerInfo.SSTTaxRate == undefined) {
                let respObj = this._bus.getTAXDetails();
                if (respObj != undefined && respObj != "") {
                    headerInfo.SSTTaxRate = Number(respObj[0].old.ITEMPF.GST);
                    headerInfo.GSTTaxRate = Number(respObj[1].old.ITEMPF.GST);

                    this.riskObj.SST = Number(headerInfo.SSTTaxRate);
                }
            }
        }
        if (["IM", "EX", "CV"].indexOf(this.riskObj.shipmentType) >= 0) {
            this.riskObj.SST = Number(0);
            headerInfo.SSTTaxRate = this.riskObj.SST;
        } else {
            if (headerInfo.SSTTaxRate.length == 0 || headerInfo.SSTTaxRate == undefined) {
                let respObj = this._bus.getTAXDetails();
                if (respObj != undefined && respObj != "") {
                    headerInfo.SSTTaxRate = Number(respObj[0].old.ITEMPF.GST);
                    headerInfo.GSTTaxRate = Number(respObj[1].old.ITEMPF.GST);

                    this.riskObj.SST = Number(headerInfo.SSTTaxRate);
                }
            }
        }

        //End
        this.postedPrem = new PostedPrem().getPostedPremDetails(this.riskObj, this.riskObj.basePostedPremiumAdj);
        this.premFormat = AppUtil.getPremFormat();
        this.riskCount = BMSConstants.getRisks().getRisksCount();
        //this.hasMinPrem = this.postedPrem.hasMinPremCalc(this.riskObj);MYS-2018-0896 commented this line and added below condn
        this.hasMinPrem = (this.riskCount > 1 && headerInfo.lineOfBusiness != 'PA') ? 'N' : 'Y';
        //this.isPremDisplayOnly = (this.postedPrem.ratingFlag == "M" && this.hasMinPrem =="Y")? "N" : "Y";
        // Added below code for SAF MYS-2017-1108 -- start
        this.isPremDisplayOnly = (this.postedPrem.ratingFlag == "M") ? "N" : "Y";
        // End
    }

    refreshCalc() {
        let postPremClac = new PostedPrem().getPostedPremDetails(this.riskObj, this.postedPrem.basicPremPOIAdj);
        this.postedPrem.refresh(postPremClac);
    }

    saveData() {
        this.closeDialog({ basePostedPremiumAdj: this.postedPrem.basicPremPOIAdj }, this.parentCompPRMS);
    }
}