import { Component, ElementRef, OnInit, NgZone } from "@angular/core";
import { ProposalHeader } from '../appobjects/proposalheader';

declare var jQuery: any;

@Component({
    selector: "duplicate-cases",
    templateUrl: "app/bms/components/proposal/proposalheader/dialogs/duplicate.template.html",
    inputs: ['datainput', 'closeDialog', 'parentCompPRMS']
})
export class DuplicateComponent implements OnInit {
    private el: HTMLElement;
    public proposalHeader: ProposalHeader;
    public cases = [];

    public datainput: any;
    public closeDialog: Function;
    public parentCompPRMS: any;

    constructor(el: ElementRef) {
        this.el = el.nativeElement;
    }

    ngOnInit() {
        this.proposalHeader = this.datainput.proposalHeader;
        this.setCasesList(this.proposalHeader.channelConflictedCaseId);
    }

    setCasesList(idslist) {
        this.cases = idslist.split(",");
    }

    closeForm() {
        this.closeDialog(null, this.parentCompPRMS);
    }
}