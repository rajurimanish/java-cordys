import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { AgentDetailsComponent } from './agent.details.component';

@NgModule({
    imports: [CommonModule, FormsModule, ReactiveFormsModule],
    declarations: [AgentDetailsComponent],
    exports: [AgentDetailsComponent]
})
export class AgentDetailsModule { }