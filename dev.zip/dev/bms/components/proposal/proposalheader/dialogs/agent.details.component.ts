/*
Change History	:

	No      Date           Description                         Changed By
	====    ==========     ===========                         ==========
  
   MRA001    30/05/2019     MYS2019-0113 agency transfer if the user   MRA 
                            entered agent is terminated
                        
                                                           
*/


import { Component, ElementRef, OnInit, NgZone } from "@angular/core";
import { CordysSoapWService } from '../../../../../common/components/utility/cordys-soap-ws';

declare var jQuery: any;

@Component({
    selector: "agent-info",
    templateUrl: "app/bms/components/proposal/proposalheader/dialogs/agent.details.template.html",
    inputs: ['datainput', 'closeDialog', 'parentCompPRMS']
})
export class AgentDetailsComponent implements OnInit {

    private agentCode: string;
    private intermediaryName: string;
    private branch: string;
    private producerCode: string;
    private busChannel: string;
    private category: string;
    private accHandler: string;

    public datainput: any;
    public closeDialog: Function;
    public parentCompPRMS: any;

    constructor(private _cordysService: CordysSoapWService) { }

    ngOnInit() {
        this.agentCode = this.datainput.agentCode;
        // Get Agent Details based on Agent Code
        this._cordysService.callCordysSoapService(
            "GetLOVData",
            "http://schemas.opentext.com/lovhandler/v1.0",
            {
                cursor: {
                    "@id": 0,
                    "@position": 0,
                    "@numRows": 1,//MRA001
                    "@maxRows": 99999,
                    "@sameConnection": "false"
                },
                BRANCH: 'ALL',
                LOB: 'ALL',
                BUSINESS_FUNCTION: 'NEW_BUSINESS',
                PRODUCT: 'ALL',
                OPERATION: 'ALL',
                FORM_NAME: 'AGENT_DETAILS',
                FORM_FIELD_NAME: 'AgentInfo',
                FIELD_TYPE: 'LOOKUP',
                ADVANCE_CONFIG_XML: {
                    FILTERS: {
                        FILTER: {
                            "@FIELD_NAME": 'AGENT_CODE',
                            "@FIELD_VALUE": this.agentCode,
                            "@OPERATION": 'EQ',
                            "@CONDITION": 'AND',
                            "@IGNORECASE": 'Y'
                        }
                    }
                }
            },
            this.getAgentInfoSuccessHandler,
            this.getAgentInfoErrorHandler,
            false,
            this
        );
    }

    private getAgentInfoSuccessHandler(response, originalObject) {
        var tuple: any = response.tuple;

        if (tuple && tuple.old && tuple.old.TABLE) {
            var table: any = tuple.old.TABLE;
            originalObject.intermediaryName = table.AGENT_NAME;
            originalObject.branch = table.AGENT_BRANCH;
            originalObject.producerCode = table.PRODUCER_CODE;
            originalObject.busChannel = table.BUSINESS_CHANNEL + " " + table.BUS_CHN_DESC;
            originalObject.category = table.LONGDESC;

            // Get Account Handler from Producer Code
            originalObject._cordysService.callCordysSoapService(
                "GetUserFromProducerCode",
                "http://schemas.cordys.com/msig/masterdata/1.0",
                {
                    PRODUCER_CODE: originalObject.producerCode
                },
                originalObject.getAccHandlerSuccessHandler,
                originalObject.getAccHandlerErrorHandler,
                false,
                originalObject
            );
        }
    }

    private getAgentInfoErrorHandler(response, status, errorText, extraPrms) {

    }

    private getAccHandlerSuccessHandler(response, originalObject) {

        var tuple: any = response.tuple;

        if (tuple && tuple.old && tuple.old.MSIG_USERS_MASTER) {
            var record: any = tuple.old.MSIG_USERS_MASTER;

            originalObject.accHandler = record.USER_FULL_NAME;
        } else {
            originalObject.accHandler = originalObject.producerCode;
        }
    }

    private getAccHandlerErrorHandler(response, status, errorText, extraPrms) {

    }
}