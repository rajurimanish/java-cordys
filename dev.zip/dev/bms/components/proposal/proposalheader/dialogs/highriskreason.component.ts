import { Component, OnInit } from "@angular/core";

@Component({
    selector: 'highrisk-reasons',
    templateUrl: 'app/bms/components/proposal/proposalheader/dialogs/highriskreason.template.html',
    inputs: ['datainput', 'closeDialog', 'parentCompPRMS']
})

export class HighRiskReasonComponent implements OnInit {
    public reasonsList : any;

    public datainput: any;
    public closeDialog: Function;
    public parentCompPRMS: any;

    constructor() { }

    ngOnInit() {
        //this.reasonsList = this.datainput.reasonsList;
        this.reasonsList = this.sortData();
    }
    sortData() {
        if(this.datainput.reasonsList!=undefined && this.datainput.reasonsList.length>0){
            return this.datainput.reasonsList.sort((item1, item2) => {
                return (item1.riskNumber - item2.riskNumber);
              });
        }else{
            return [];
        }
    }
}