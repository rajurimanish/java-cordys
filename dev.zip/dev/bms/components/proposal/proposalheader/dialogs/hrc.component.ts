/*
Change History	:

	No      Date          Description                                 Changed By
	====    ==========    ===========                                 ==========	
	GA001   14/11/2018   MYS-2018-1214 - To add Reference document & To update 
	                     drop-down selection list of High Risk Trades   KGA
 * 
 */
import { Component, ElementRef, OnInit, NgZone } from "@angular/core";
import { ProposalHeader } from '../appobjects/proposalheader';
import { CordysSoapWService } from "../../../../../common/components/utility/cordys-soap-ws";
import { AlertMessagesService } from '../../../../../common/components/utility/alertmessage/alertmessages.service';
import { AlertMessage } from '../../../../../common/components/utility/alertmessage/alertmessages.model';

declare var jQuery: any;

@Component({
    selector: "hrc-types",
    templateUrl: "app/bms/components/proposal/proposalheader/dialogs/hrc.template.html",
    inputs: ['datainput', 'closeDialog', 'parentCompPRMS']
})
export class HRCComponent implements OnInit {
    private el: HTMLElement;
    public proposalHeader: ProposalHeader;
    public isViewMode: string = 'N';
    public HighRiskCusType: string = "";
    public HighRiskCusComments: string = "";
    public ceoApprovalUI: boolean = false;
    public ceoApproval: string = "";
    public isQuotationCompleted: string = "N";
	/* GA001 - Commented old list
	private hrtList=[
		{VALUE:"AMA", DESCRIPTION:"Amusement Arcade"},
		{VALUE:"BSC", DESCRIPTION:"Billiard/Snooker Centre"},
		{VALUE:"CS", DESCRIPTION:"Crystal Shop"},
		{VALUE:"DNC", DESCRIPTION:"Disco / Night Club"},
		{VALUE:"GJS", DESCRIPTION:"Goldsmith / Jewelry shop"},
		{VALUE:"HR", DESCRIPTION:"Horse racing"},
		{VALUE:"KL", DESCRIPTION:"Karaoke lounge"},
		{VALUE:"LS", DESCRIPTION:"Liquor shop"},
		{VALUE:"PS", DESCRIPTION:"Pawn Shop"},
		{VALUE:"IHSI", DESCRIPTION:"Individuals with high sum insured exceeding RM5 million for Personal Accident"},
		{VALUE:"IHRT", DESCRIPTION:"Individuals involved or work as Manager &/or high position in the High Risk Trades/Business"},
		{VALUE:"FPE", DESCRIPTION:"Foreign politically exposed persons (PEPs)"},
		{VALUE:"NHRC", DESCRIPTION:"Not a High Risk Customer"},
		{VALUE:"OTH", DESCRIPTION:"Others"}
	
	];*/

    private hrtList = [];//GA001

    public datainput: any;
    public closeDialog: Function;
    public parentCompPRMS: any;

    constructor(el: ElementRef, private _soapService: CordysSoapWService, public _alertMsgService: AlertMessagesService) {
        this.el = el.nativeElement;
    }

    ngOnInit() {
        this.proposalHeader = this.datainput.proposalHeader;
        this.isViewMode = this.datainput.isViewMode;
        this.isQuotationCompleted = this.datainput.isQuotationCompleted;
        this.initializeHighRiskCodes();//GA001
        this.setInitData();
    }

    setInitData() {
        this.HighRiskCusType = this.proposalHeader.HighRiskCusType;
        this.HighRiskCusComments = this.proposalHeader.HighRiskCusComments;
        this.ceoApproval = this.proposalHeader.HighRiskCEOApproval;
        this.ceoApprovalUI = (this.ceoApproval == "Y") ? true : false;
    }

    onApprovalCheck(value) {
        this.ceoApproval = (value) ? "Y" : "N";
    }

    save() {
        this.datainput.proposalHeader.HighRiskCusType = this.HighRiskCusType;
        this.datainput.proposalHeader.HighRiskCusComments = this.HighRiskCusComments;
        this.datainput.proposalHeader.HighRiskCEOApproval = this.ceoApproval;
        this.closeDialog(null, this.parentCompPRMS);
    }

    cancel() {
        this.closeDialog(null, this.parentCompPRMS);
    }

    //GA001 START
    initializeHighRiskCodes() {
        let prom = this._soapService.callCordysSoapService("GetMsigPropertiesObject", "http://schemas.cordys.com/msig/masterdata/1.0", { "KEY": "HIGH_RISK_CODES" }, null, null, true, null);
        prom.success((resp) => {
            let tempVal: any = JSON.parse(resp.tuple.old.MSIG_PROPERTIES.VALUE);
            this.hrtList = tempVal.HISH_RISK_CODES;
        });
        prom.error((error) => {
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error while fetching Highrisk codes.", -1));
        });
    }
    //GA001 END
}