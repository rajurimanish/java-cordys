import { Component, OnInit } from "@angular/core";

@Component({
    selector: 'referred',
    templateUrl: 'app/bms/components/proposal/proposalheader/dialogs/referredreason.template.html',
    inputs: ['datainput', 'closeDialog', 'parentCompPRMS']
})

export class ReferredReasonComponent implements OnInit {
    public newBusiness;
    public referredRiskReasons = [];

    public datainput: any;
    public closeDialog: Function;
    public parentCompPRMS: any;

    constructor() { }

    ngOnInit() {
        this.newBusiness = this.datainput.newBusiness;
        this.referredRiskReasons = this.newBusiness.getAllReferredReasons();
    }
}