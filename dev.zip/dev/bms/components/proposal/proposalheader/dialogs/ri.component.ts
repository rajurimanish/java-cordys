import { Component, ElementRef, OnInit, NgZone } from "@angular/core";
import { ProposalHeader } from '../appobjects/proposalheader';

declare var jQuery: any;

@Component({
    selector: "ri-types",
    templateUrl: "app/bms/components/proposal/proposalheader/dialogs/ri.template.html",
    inputs: ['datainput', 'closeDialog', 'parentCompPRMS']
})
export class RIComponent implements OnInit {
    private el: HTMLElement;
    private RIRequiredHeader: string;
    private RIType: string;
    private RIReason: string;
    public proposalHeader: ProposalHeader;
    public disable: boolean = false;

    private riList = [{ VALUE: "TreatyAdjustment", DESCRIPTION: "Treaty Adjustment" }, { VALUE: "FacRI", DESCRIPTION: "Fac R/I" }, { VALUE: "DirectedRIJA", DESCRIPTION: "Directed R/I (Japanese Account)" }, { VALUE: "DirectedRIFA", DESCRIPTION: "Directed R/I (Fubon Account)" }, { VALUE: "DirectedRIBA", DESCRIPTION: "Directed R/I (Broking Account)" }, { VALUE: "DirectedRIFRA", DESCRIPTION: "Directed R/I (Fronting Account)" }];

    public datainput: any;
    public closeDialog: Function;
    public parentCompPRMS: any;

    constructor(el: ElementRef) {
        this.el = el.nativeElement;
    }

    ngOnInit() {
        this.proposalHeader = this.datainput.proposalHeader;
        this.disable = this.datainput.disable;
        this.RIRequiredHeader = this.proposalHeader.RIRequiredHeader;
        this.RIType = this.proposalHeader.RIType;
        this.RIReason = this.proposalHeader.RIReason;
    }

    save() {
        this.datainput.proposalHeader.RIType = this.RIType;
        this.datainput.proposalHeader.RIReason = this.RIReason;
        this.closeDialog(null, this.parentCompPRMS);
    }

    cancel() {
        this.closeDialog(null, this.parentCompPRMS);
    }
}