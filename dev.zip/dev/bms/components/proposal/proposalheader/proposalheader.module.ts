import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BasicUIModule } from '../../../../common/components/utility/basicui.module';
import { BancaModule } from './uimodules/banca.module';
import { BancaServiceModule } from './service/banca.service.module';
import { ReferenceModule } from './uimodules/reference.module';
import { CoInsuranceModule } from '../../../../common/components/coinsurance/coinsurance.module';
import { CoinsuranceServiceModule } from './service/coi.service.module';
import { RiskTableServiceModule } from './service/riskTable.service.module';
import { ReferenceServiceModule } from './service/reference.service.module';
import { ProposalHeaderComponent } from './proposalheader.component';
import { CcmOPSModule } from './uimodules/ccmOPS.module'; //pku

@NgModule({
    imports: [CommonModule, FormsModule, ReactiveFormsModule, BasicUIModule, BancaModule, ReferenceModule, CoInsuranceModule, BancaServiceModule, CoinsuranceServiceModule, RiskTableServiceModule, ReferenceServiceModule, CcmOPSModule],
    declarations: [ProposalHeaderComponent],
    exports: [ProposalHeaderComponent]
})
export class ProposalHeaderModule { }