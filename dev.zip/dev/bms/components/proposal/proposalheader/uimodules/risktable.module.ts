import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { PaginationModule } from '../../../../../common/components/utility/pagination/pagination.module';
import { NumberModule } from '../../../../../common/components/utility/number/number.module';

import { RiskTableComponent } from './risktable.component';
import { RiskTypePipe } from './filterrisktype.pipe';
import { RiskTableServiceModule } from '../service/riskTable.service.module';

@NgModule({
    imports: [CommonModule, FormsModule, ReactiveFormsModule, PaginationModule, NumberModule, RiskTableServiceModule],
    declarations: [RiskTableComponent, RiskTypePipe],
    exports: [RiskTableComponent, RiskTypePipe]
})
export class RiskTableModule { }