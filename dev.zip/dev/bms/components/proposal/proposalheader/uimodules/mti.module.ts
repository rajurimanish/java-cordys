import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NumberModule } from '../../../../../common/components/utility/number/number.module';

import { MTIComponent } from './mti.component';

@NgModule({
    imports: [CommonModule, FormsModule, ReactiveFormsModule, NumberModule],
    declarations: [MTIComponent],
    exports: [MTIComponent]
})
export class MTIModule { }