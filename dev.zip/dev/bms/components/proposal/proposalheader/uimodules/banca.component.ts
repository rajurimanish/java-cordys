import { Component, OnInit } from '@angular/core';
import { LOV_Field, LOVDropDownService, SearchFilter } from "../../../../../common/services/lovdropdown/lovdropdown.service";
import { LovModule } from "../../../../../common/services/lovdropdown/lov.module";
import { PeriodicDebitDetails, ProposalHeader } from '../appobjects/proposalheader';
import { AlertMessagesService } from '../../../../../common/components/utility/alertmessage/alertmessages.service';
import { AlertMessage } from '../../../../../common/components/utility/alertmessage/alertmessages.model';
import { GetLOVData, SearchAdvancedConfig, Filter } from '../../../../../common/components/utility/search/search.requests';

declare var jQuery: any;

@Component({
    selector: 'banca',
    templateUrl: 'app/bms/components/proposal/proposalheader/uimodules/banca.template.html',
    inputs: ['periodicDebitDetails', 'headerInfo']
})

export class BancaComponent implements OnInit {

    private collapseBancalInfo: boolean = false;
    public periodicDebitDetails: PeriodicDebitDetails;
    public headerInfo: ProposalHeader;
    private years = [];
    private subBankInfoList = [];
    public branchCtrl: any;

    public bankAcNumCtrl: any;
    public bankLnAcNumCtrl: any;

    public bankAcNumDis: string = "N";
    public bankLnAcNumDis: string = "N";

    constructor(private lovDropDownService: LOVDropDownService, public _alertMsgService: AlertMessagesService) {
    }

    ngOnInit() {
        this.setYearList();
        this.populateLovs();
        this.enableRequired();
    }

    setYearList() {
        let thisYear = new Date().getFullYear();
        for (let count = 0; count < 10; count++) {
            this.years.push(thisYear + count);
        }
    }

    populateLovs() {
        this.lovDropDownService.createLOVDataList(["CreditCardType", "CampignCode", "UOBSector", "BankInfo", "Merchant"]);
        let lovFields = [
            new LOV_Field("ALL", "ALL", "ALL", "ALL", "ALL", "ALL", "CreditCardType", "LOV", [], "DESCPF", "CreditCardType", null),
            new LOV_Field("ALL", "ALL", "BMS", "ALL", "ALL", "BMS_HEADER", "BANK_INFO", "LOV", [], "DESCPF", "BankInfo", "defaultBranch"),
            new LOV_Field("ALL", "ALL", "NEW_BUSINESS", "ALL", "ALL", "BMS_HEADER", "Merchant", "LOV", [], "DESCPF", "Merchant", null)
        ];
        this.lovDropDownService.util_populateLOV(lovFields, this);
    }

	/*getBankInfo(){
		let request:GetLOVData = new GetLOVData();
		request.BRANCH ='ALL';
		request.LOB = 'ALL';
		request.BUSINESS_FUNCTION = 'BMS';
		request.PRODUCT = 'ALL';
		request.OPERATION = 'ALL';
		request.FORM_NAME = 'BMS_HEADER';        
		request.FORM_FIELD_NAME = 'BANK_INFO';
		request.FIELD_TYPE = 'LOV';
		this._cordysService.callCordysSoapService("GetLOVData","http://schemas.opentext.com/lovhandler/v1.0", request , this.setBankInfo , this.handleError, true, {comp:this});
	}
	
	setBankInfo(response, prms){
		
	}
	
	handleError(response, status, errorText, prms){
        prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, response.responseJSON.faultstring.text , -1));
    }*/

    setBankInfo(values, toSetList, setEmpty) {
        this.periodicDebitDetails.bankBranchCode = (setEmpty == false) ? values.record.BRANCH_CODE : "";
        this.periodicDebitDetails.bankBranch = (setEmpty == false) ? values.record.BRANCH_CODE.substr(2, 3) : "";
        this.periodicDebitDetails.bankBranchName = (setEmpty == false) ? values.record.BRANCH_NAME : "";
        this.periodicDebitDetails.bankCode = (setEmpty == false) ? values.record.BANK_CODE : "";
        this.periodicDebitDetails.bankCodeName = (setEmpty == false) ? values.record.BANK_NAME : "";
        if (toSetList == true && this.branchCtrl != null) {
            this.branchCtrl.setter(this.periodicDebitDetails.bankBranchCode, this.branchCtrl.comp);
        }
    }

    resetBranchSubList() {
        this.subBankInfoList = [];
        if (this.lovDropDownService.lovDataList.BankInfo != null && this.lovDropDownService.lovDataList.BankInfo.length > 0) {
            this.subBankInfoList = this.lovDropDownService.lovDataList.BankInfo.filter((item) => (this.headerInfo.branchCodeForBanca != null && item.BRANCH_CODE.substr(0, 2) == this.headerInfo.branchCodeForBanca.substr(0, 2)));
            if (this.subBankInfoList.length == 0)
                this.subBankInfoList = this.lovDropDownService.lovDataList.BankInfo.filter((item) => item.BRANCH_CODE.substr(0, 2) == this.headerInfo.agentCode.substr(2, 2));
            if (this.subBankInfoList.length == 0)
                this.subBankInfoList = this.lovDropDownService.lovDataList.BankInfo;
        }
    }

    defaultBranch(comp, forceDefault) {
        this.resetBranchSubList();
        let brCode = (this.headerInfo.branchCodeForBanca == null || this.headerInfo.branchCodeForBanca == "") ? this.headerInfo.agentCode.substr(2, 5) : this.headerInfo.branchCodeForBanca;
        let bankByAgent = this.subBankInfoList.filter((item) => item.BRANCH_CODE == brCode);
        if (bankByAgent != null && bankByAgent.length > 0 && (this.periodicDebitDetails.bankBranch == null || this.periodicDebitDetails.bankBranch == "" || forceDefault == true)) {
            this.setBankInfo({ record: bankByAgent[0] }, true, false);
        }
        else if (comp == null && bankByAgent.length == 0)
            this.setBankInfo(null, true, true);
    }

    isSeqMandatory() {
        if (this.headerInfo.agentCode != null && this.headerInfo.agentCode.substr(2, 2) == "UB" && this.headerInfo.contractType != null && ["FIR", "COM", "DOM", "HHO", "BG"].indexOf(this.headerInfo.contractType) != -1) {
            return true;
        }
        return false;
    }

    clearBankAccNum() {
        this.periodicDebitDetails.bankAccountNumber = "";
    }

    clearMerchant() {
        if ((jQuery("#ccTypeEmnt").val() == null || jQuery("#ccTypeEmnt").val() == "") && (this.periodicDebitDetails.creditcardNumber == null || this.periodicDebitDetails.creditcardNumber == "") && (jQuery("#ccMntEmnt").val() == null || jQuery("#ccMntEmnt").val() == "") && (jQuery("#ccYrEmnt").val() == null || jQuery("#ccYrEmnt").val() == "")) {
            this.periodicDebitDetails.merchantId = "";
        }
    }

    clearCCDData() {
        this.periodicDebitDetails.creditcardType = "";
        this.periodicDebitDetails.creditcardNumber = "";
        this.periodicDebitDetails.creditcardExpiryMonth = "";
        this.periodicDebitDetails.creditcardExpiryYear = "";
    }

    clearLoanAccNum() {
        this.periodicDebitDetails.loanAccountNumber = "";
    }

    enableOrDisableAll(value) {
        if (this.bankAcNumCtrl != null) {
            this.bankAcNumCtrl.setDisable(value, this.bankAcNumCtrl.comp);
        }

        if (this.bankLnAcNumCtrl != null) {
            this.bankLnAcNumCtrl.setDisable(value, this.bankLnAcNumCtrl.comp);
        }

        this.bankLnAcNumDis = value;
        this.bankAcNumDis = value;
    }

    enableRequired() {
        this.enableOrDisableAll("Y");
        let isAnyEnabled = false;
        if (this.periodicDebitDetails.bankAccountNumber != null && this.periodicDebitDetails.bankAccountNumber != "") {
            this.enableBAcc();
            isAnyEnabled = true;
        }
        if (this.periodicDebitDetails.loanAccountNumber != null && this.periodicDebitDetails.loanAccountNumber != "") {
            this.enableLAcc();
            isAnyEnabled = true;
        }
        if ((jQuery("#ccTypeEmnt").val() != null && jQuery("#ccTypeEmnt").val() != "") || (this.periodicDebitDetails.creditcardNumber != null && this.periodicDebitDetails.creditcardNumber != "") || (jQuery("#ccMntEmnt").val() != null && jQuery("#ccMntEmnt").val() != "") || (jQuery("#ccYrEmnt").val() != null && jQuery("#ccYrEmnt").val() != "")) {
            isAnyEnabled = true;
        }

        if (isAnyEnabled == false) {
            this.enableOrDisableAll("N");
        }
    }

    enableBAcc() {
        if (this.bankAcNumCtrl != null) {
            this.bankAcNumCtrl.setDisable("N", this.bankAcNumCtrl.comp);
        }
        this.bankAcNumDis = "N";
    }

    enableLAcc() {
        if (this.bankLnAcNumCtrl != null) {
            this.bankLnAcNumCtrl.setDisable("N", this.bankLnAcNumCtrl.comp);
        }
        this.bankLnAcNumDis = "N";
    }

    validateCCDPeriod() {
        let thisYear = new Date().getFullYear();
        let thisMonth = new Date().getMonth() + 1;

        if (jQuery("#ccYrEmnt").val() != null && jQuery("#ccMntEmnt").val() !== null) {
            if (parseInt(jQuery("#ccYrEmnt").val()) == thisYear && parseInt(jQuery("#ccMntEmnt").val()) < thisMonth) {
                this.periodicDebitDetails.creditcardExpiryMonth = "" + thisMonth;
                jQuery("#ccMntEmnt").val(thisMonth);
                this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Invalid credit card validity.", -1));
            }
        }
    }
}