import { Component, OnInit, ViewChild, ViewContainerRef } from '@angular/core';
import { MTIItems, MTIItem } from '../appobjects/mti';
import { AlertMessagesService } from '../../../../../common/components/utility/alertmessage/alertmessages.service';
import { AlertMessage } from '../../../../../common/components/utility/alertmessage/alertmessages.model';
import { GetLOVData, SearchAdvancedConfig, Filter } from '../../../../../common/components/utility/search/search.requests';
import { DCLInput, CustomDCLService } from '../../../../../common/services/customdcl.service';
import { GenericSearchComponent } from "../../../../../common/components/utility/search/genericsearch.component";
import { SearchInput } from "../../../../../common/components/utility/search/genericsearch";
import { CordysSoapWService } from "../../../../../common/components/utility/cordys-soap-ws";
import { ProposalHeader } from '../appobjects/proposalheader';
import { ModalInput } from "../../../../../common/components/utility/modal/modal";

declare var numeral: any;

@Component({
    selector: 'multiple-tax-invoice',
    templateUrl: 'app/bms/components/proposal/proposalheader/uimodules/mti.template.html',
    inputs: ['mtiItems', 'headerInfo']
})

export class MTIComponent implements OnInit {

    public mtiItems: MTIItems;
    public headerInfo: ProposalHeader;
    public premiumFormat: string = "0,00.00";
    public selectedClients: any = "''";
    private effectiveDate: string;

    private numberCtrls: any = [];

    @ViewChild('mtiModal', { read: ViewContainerRef }) contentArea: ViewContainerRef;

    constructor(public dcl: CustomDCLService, private _soapService: CordysSoapWService, public _alertMsgService: AlertMessagesService) { }

    ngOnInit() {
        let index = this.headerInfo.effectiveDate.indexOf("-");
        this.effectiveDate = this.headerInfo.effectiveDate.replace(/-/g, "");
    }

    addMTI() {
        this.mtiItems.mtiItem.push(new MTIItem());
        this.refreshSelectedClients();
    }

    removeMTI(idx: number) {
        this.mtiItems.mtiItem.splice(idx, 1);
        this.numberCtrls.splice(idx, 1);
        this.mtiItems.totalAmount = numeral(numeral(this.getTotalSum()).format(this.premiumFormat)).value();
        this.refreshSelectedClients();
    }

    refreshSelectedClients() {
        this.selectedClients = "''";
        let items = this.mtiItems.mtiItem;
        if (items.length > 1) {
            this.selectedClients = (items[0].invoiceTo != "") ? "'" + items[0].invoiceTo + "'" : this.selectedClients;
            for (let index = 1; index < items.length; index++) {
                let item = items[index];
                if (item.invoiceTo != "") {
                    this.selectedClients += ",'" + item.invoiceTo + "'";
                }

            }
        } else if (items.length == 1) {
            this.selectedClients = (items[0].invoiceTo != "") ? "'" + items[0].invoiceTo + "'" : this.selectedClients;
        }
    }

    openInvoiceToLookup(mti: MTIItem) {
        this.refreshSelectedClients();
        let searchInput = new SearchInput();
        searchInput.isSingleSelect = true;
        searchInput.BRANCH = 'ALL';
        searchInput.BUSINESS_FUNCTION = 'ALL';
        searchInput.FIELD_TYPE = 'LOOKUP';
        searchInput.FORM_FIELD_NAME = 'Non Blacklisted Client';
        searchInput.FORM_NAME = 'NEW_BUSINESS';
        searchInput.LOB = 'ALL';
        searchInput.OPERATION = 'ALL';
        searchInput.PRODUCT = 'ALL';
        searchInput.condition = {
            "ZBLOCKDTE": this.effectiveDate,
            "RELEASE_DATE": this.effectiveDate,
            "CLNTNUM": this.selectedClients
        };

        let input = new ModalInput();
        input = input.get("GenericSearchComponent");
        input.datainput = searchInput;
        input.outputCallback = this.setClientInfo;
        input.parentCompPRMS = { comp: this, mti: mti };
        input.heading = "Client List (Non Blacklisted Clients)";
        input.icon = "fa fa-link";
        input.containerRef = this.contentArea;
        this.dcl.openLookup(input);
    }

    setClientInfo(response, prms) {
        if (response != null && response[0] != null) {
            let clientInfo = response[0];
            if (typeof (prms.mti) === "string") {
                prms.mti = new MTIItem();
            }
            prms.mti.invoiceTo = clientInfo.old.CLNTPF.CLNTNUM;
            prms.mti.invoiceToName = prms.mti.invoiceTo + ": " + clientInfo.old.CLNTPF.NAME;
            if (prms.comp.selectedClients == "''") {
                prms.comp.selectedClients = "'" + clientInfo.old.CLNTPF.CLNTNUM + "'";
            } else {
                prms.comp.selectedClients = ",'" + clientInfo.old.CLNTPF.CLNTNUM + "'";
            }
        }
    }

    validatePercent(mti) {
        let percentTotal = this.getTotalByProperty("sharePercent", this.mtiItems.mtiItem);
        if (percentTotal > 100) {
            mti.sharePercent = 0;
            this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Total share percentage can't be greater than 100.", -1));
        }
        this.resetCalc();
    }

    resetCalc() {
		/*this.setAmount();
		this.resetTotal();*/
    }

    setAmount() {
        for (let mti of this.mtiItems.mtiItem) {
            let amount = (parseFloat("" + mti.sharePercent) * parseFloat("" + this.headerInfo.totalDiscountedPremium)) / 100;
            mti.amount = numeral(numeral(amount).format(this.premiumFormat)).value();
        }
    }

    resetTotal() {
        this.mtiItems.totalMTIPercent = this.getTotalByProperty("sharePercent", this.mtiItems.mtiItem);
        this.mtiItems.totalAmount = this.getTotalByProperty("amount", this.mtiItems.mtiItem);
    }

    getTotalByProperty(prop, ary) {
        let total: any = numeral(0);
        for (let eachItem of ary) {
            if (eachItem[prop] != null && eachItem[prop] != "")
                total = numeral(total).add(numeral(eachItem[prop]));
        }
        return numeral(total.format('0[.]00')).value();
    }

    getTotalSum(): number {
        let totalAmount: any = numeral(0);
        if (this.mtiItems && this.mtiItems.mtiItem.length >= 1) {
            for (let mti of this.mtiItems.mtiItem) {
                totalAmount = numeral(totalAmount).add(numeral(mti.amount));
            }
        }
        return numeral(totalAmount.format('0[.]00')).value();
    }

    refreshTotalAmount(mtiItemObj, index) {

        let totalAmount: number = this.getTotalSum();

        if (parseFloat(mtiItemObj.amount) < 0) {
            this.mtiItems.mtiItem[index].amount = mtiItemObj.amount = numeral(numeral(0).format(this.premiumFormat)).value();
            this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Negative value in amount is not allowed", -1));

            this.mtiItems.totalAmount = numeral(numeral(this.getTotalSum()).format(this.premiumFormat)).value();
            this.numberCtrls[index].setter(0, this.numberCtrls[index].comp);
            return;
        }

        if (totalAmount > this.headerInfo.totalDiscountedPremium) {
            this.mtiItems.mtiItem[index].amount = mtiItemObj.amount = numeral(numeral(0).format(this.premiumFormat)).value();
            this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Total tax invoice amount should not be greater than total net premium", -1));
            // Reset the total sum
            this.mtiItems.totalAmount = numeral(numeral(this.getTotalSum()).format(this.premiumFormat)).value();
            this.numberCtrls[index].setter(0, this.numberCtrls[index].comp);
            // this.numberCtrls[index].numValObj.value = numeral(0).format(this.premiumFormat);
            return;
        }

        this.mtiItems.totalAmount = numeral(numeral(totalAmount).format(this.premiumFormat)).value();

    }
}