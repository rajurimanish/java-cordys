
import { Component, OnInit, Injector } from '@angular/core';
import { LOV_Field, LOVDropDownService, SearchFilter } from "../../../../../common/services/lovdropdown/lovdropdown.service";
import { LovModule } from "../../../../../common/services/lovdropdown/lov.module";
import { PeriodicDebitDetails, ProposalHeader } from '../appobjects/proposalheader';
import { AlertMessagesService } from '../../../../../common/components/utility/alertmessage/alertmessages.service';
import { AlertMessage } from '../../../../../common/components/utility/alertmessage/alertmessages.model';
import { GetLOVData, SearchAdvancedConfig, Filter } from '../../../../../common/components/utility/search/search.requests';
import { ExtraDetails } from '../appobjects/extraDetails';


declare var jQuery: any;

@Component({
    selector: 'extraDetails',
    templateUrl: 'app/bms/components/proposal/proposalheader/uimodules/extraDetails.template.html',
    inputs: ["extraDetails"]
})

export class ExtraDetailsComponent implements OnInit {


    private collapseEDInfo: boolean = false;
    public headerInfo: ProposalHeader;

    public extraDetails: ExtraDetails;

    constructor(public injector: Injector, private lovDropDownService: LOVDropDownService, public _alertMsgService: AlertMessagesService) {
    }

    ngOnInit(): any {
        if (this.extraDetails == undefined)
            this.extraDetails = new ExtraDetails();

    }
}