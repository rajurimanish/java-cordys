
import { Component, OnInit } from '@angular/core';
import { LOV_Field, LOVDropDownService } from "../../../../../common/services/lovdropdown/lovdropdown.service";
import { BMSConstants } from '../../../common/constants/bms_constants';
import { ProposalHeader } from '../appobjects/proposalheader';
import { CcmOPS, CcmOPSs } from '../appobjects/ccmOPS';
import { AlertMessagesService } from '../../../../../common/components/utility/alertmessage/alertmessages.service';
import { AlertMessage } from '../../../../../common/components/utility/alertmessage/alertmessages.model';

@Component( {
    selector: 'ccmOPS',
    templateUrl: 'app/bms/components/proposal/proposalheader/uimodules/ccmOPS.template.html'
} )

export class CcmOPSComponent implements OnInit {

    private collapseCcmInfo: boolean = false;

    public _ccmOpss: CcmOPSs;
    public proposalHeader: ProposalHeader;
    public clientDetails: any;
    public email: string;

    constructor( private lovDropDownService: LOVDropDownService, public _alertMsgService: AlertMessagesService ) { }

    ngOnInit(): any {

        this.proposalHeader = BMSConstants.getBMSHeaderInfo();
        //if ( BMSConstants.getBMSCaseInfo().status == "Policy Processing" ) {
            this.clientDetails = BMSConstants.getClientObj();
            this._ccmOpss = ( this.proposalHeader.ccmOPSs == undefined ) ? new CcmOPSs() : this.proposalHeader.ccmOPSs;
            this._ccmOpss.language = ( this.clientDetails.client.genericDetails.clienttype == "C" ) ? this.clientDetails.client.corporateClientDetails.language : this.clientDetails.client.personalClientDetails.language;
            this._ccmOpss.noOfHardCopy = ( this._ccmOpss.noOfHardCopy.length == 0 ) ? "1" : this._ccmOpss.noOfHardCopy;
            this.populateLOVs();
        //}
    }


    private populateLOVs(): void {

        this.lovDropDownService.createLOVDataList( ["CCM_Account_Types", "CCM_Printer_Queue", "CCM_Language"] );
        let lovFields = [
            new LOV_Field( "ALL", "ALL", "NEW BUSINESS", "ALL", "ALL", "CCM_PARAMS", "CCM_Account_Types", "LOV", null, "T9114", "CCM_Account_Types", "callbackAcctTypes" ),
            new LOV_Field( "ALL", "ALL", "NEW BUSINESS", "ALL", "ALL", "CCM_PARAMS", "CCM_Printer_Queue", "LOV", null, "ITEMPF", "CCM_Printer_Queue", null ),
            new LOV_Field( "ALL", "ALL", "NEW BUSINESS", "ALL", "ALL", "CCM_PARAMS", "CCM_Language", "LOV", null, "T1680", "CCM_Language", null )
        ];
        this.lovDropDownService.util_populateLOV( lovFields, this );

    }

    callbackAcctTypes( scopeObject ) {
        if ( !Array.prototype.isPrototypeOf( scopeObject._ccmOpss.ccmOPS ) ) {
            scopeObject._ccmOpss.ccmOPS = [scopeObject._ccmOpss.ccmOPS];
        }

        scopeObject.lovDropDownService.lovDataList.CCM_Account_Types.forEach( eachAcctInfo => {
            let _ccmOPS: CcmOPS = new CcmOPS();
            if ( eachAcctInfo.DESCITEM == "AG" ) {
                _ccmOPS.ent = scopeObject.proposalHeader.agentCode;
                _ccmOPS.longName = scopeObject.proposalHeader.agentName;
                _ccmOPS.recipientEmail = "";
            }
            else if ( eachAcctInfo.DESCITEM == "CN" ) {
                _ccmOPS.ent = scopeObject.proposalHeader.insuredNumber;
                _ccmOPS.longName = scopeObject.proposalHeader.insuredName;
                _ccmOPS.recipientEmail = ( this.clientDetails.client.genericDetails.clienttype == "C" ) ? this.clientDetails.client.corporateClientDetails.email : this.clientDetails.client.personalClientDetails.email;
            }
            else if ( eachAcctInfo.DESCITEM == "ST" ) {
                _ccmOPS.ent = "";
                _ccmOPS.longName = "";
                _ccmOPS.recipientEmail = "";
            } else {
                _ccmOPS.ent = "";
                _ccmOPS.longName = "";
                _ccmOPS.recipientEmail = "";
            }
            _ccmOPS.accountType = eachAcctInfo.DESCITEM;
            _ccmOPS.emailExt = eachAcctInfo.ELEMEXT;
            _ccmOPS.printFlag = eachAcctInfo.RPFLG;
            _ccmOPS.emailFlag = eachAcctInfo.YNFLAG;

            scopeObject._ccmOpss.ccmOPS.push( _ccmOPS );
        } );
    }

    onChangeNoofHardCopy( val ) {
        if ( val == "0" ) {
            let printFlagObj: any = this._ccmOpss.ccmOPS.find( ( item ) => item.printFlag == "Y" );
            if ( typeof ( printFlagObj ) == "object" ) {
                printFlagObj = [printFlagObj];
            }
            if ( printFlagObj != undefined && printFlagObj.length >= 1 ) {
                this._ccmOpss.noOfHardCopy = "1";
                this._alertMsgService.add( new AlertMessage( AlertMessage.ERROR, "No of Copies can not be zero, if any of the Print flag is set to 'Y'.", 15000 ) );
            }
        }
    }

}