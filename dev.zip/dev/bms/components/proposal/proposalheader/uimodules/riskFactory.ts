/*
Change History	:

	No      Date          Description                                    Changed By
	====    ==========    ===========                                    ==========
	AL001   15/08/2017   MYS-2017-0371    -  Develop MPD                     ALA
	MD001   14/02/2017   MYS-2017-0920    -  ABC PA to be incorporated
	                                         into BMS                       Madhan
    KA001   13/02/2019   MYS-2018-0523    -  Added FHD and FHE Product       DKA
	VK006  	20/03/2019   MYS-2019-0164    - MMP Product Configuration        VKR
    MS001  	24/07/2019   MYS-2019-0729    - MMF Product Configuration        MSU
*/

export class RiskFactory {
    public static RISKOBJMAP = {
        "NPA": { file: "app/bms/components/proposal/newbusinessrisks/pa/appobjects/pa", clsName: "IndividualPersonalAccident", cls: null },
        "OSI": { file: "app/bms/components/proposal/newbusinessrisks/pa/appobjects/pa", clsName: "IndividualPersonalAccident", cls: null },
        "OSS": { file: "app/bms/components/proposal/newbusinessrisks/pa/appobjects/pa", clsName: "IndividualPersonalAccident", cls: null },
        "PAX": { file: "app/bms/components/proposal/newbusinessrisks/pa/appobjects/pa", clsName: "IndividualPersonalAccident", cls: null },
        "DPA": { file: "app/bms/components/proposal/newbusinessrisks/driverpa/appobjects/dpa", clsName: "DriverPersonalAccident", cls: null },
        "PAM": { file: "app/bms/components/proposal/newbusinessrisks/driverpa/appobjects/dpa", clsName: "DriverPersonalAccident", cls: null },//AL001
        "CV": { file: "app/bms/components/proposal/newbusinessrisks/motorcommercial/appobjects/motorcommercial", clsName: "MotorCommercial", cls: null },
        "CVF": { file: "app/bms/components/proposal/newbusinessrisks/motorcommercial/appobjects/motorcommercial", clsName: "MotorCommercial", cls: null },
        "CVT": { file: "app/bms/components/proposal/newbusinessrisks/motorcommercial/appobjects/motorcommercial", clsName: "MotorCommercial", cls: null },
        "HVC": { file: "app/bms/components/proposal/newbusinessrisks/motorcommercial/appobjects/motorcommercial", clsName: "MotorCommercial", cls: null },
        "HVF": { file: "app/bms/components/proposal/newbusinessrisks/motorcommercial/appobjects/motorcommercial", clsName: "MotorCommercial", cls: null },
        "HVT": { file: "app/bms/components/proposal/newbusinessrisks/motorcommercial/appobjects/motorcommercial", clsName: "MotorCommercial", cls: null },
        "MTC": { file: "app/bms/components/proposal/newbusinessrisks/motorcommercial/appobjects/motorcommercial", clsName: "MotorCommercial", cls: null },
        "MTF": { file: "app/bms/components/proposal/newbusinessrisks/motorcommercial/appobjects/motorcommercial", clsName: "MotorCommercial", cls: null },
        "MTT": { file: "app/bms/components/proposal/newbusinessrisks/motorcommercial/appobjects/motorcommercial", clsName: "MotorCommercial", cls: null },
        "MCF": { file: "app/bms/components/proposal/newbusinessrisks/motorcommercial/appobjects/motorcommercial", clsName: "MotorCommercial", cls: null },
        "MCT": { file: "app/bms/components/proposal/newbusinessrisks/motorcommercial/appobjects/motorcommercial", clsName: "MotorCommercial", cls: null },
        "MCY": { file: "app/bms/components/proposal/newbusinessrisks/motorcommercial/appobjects/motorcommercial", clsName: "MotorCommercial", cls: null },
        "MPC": { file: "app/bms/components/proposal/newbusinessrisks/motorcommercial/appobjects/motorcommercial", clsName: "MotorCommercial", cls: null },
        "MMP": { file: "app/bms/components/proposal/newbusinessrisks/motorcommercial/appobjects/motorcommercial", clsName: "MotorCommercial", cls: null },//VK006
        "MMF": { file: "app/bms/components/proposal/newbusinessrisks/motorcommercial/appobjects/motorcommercial", clsName: "MotorCommercial", cls: null },//MS001
        "MPD": { file: "app/bms/components/proposal/newbusinessrisks/motorcommercial/appobjects/motorcommercial", clsName: "MotorCommercial", cls: null }, //AL001
        "MPF": { file: "app/bms/components/proposal/newbusinessrisks/motorcommercial/appobjects/motorcommercial", clsName: "MotorCommercial", cls: null },
        "MPT": { file: "app/bms/components/proposal/newbusinessrisks/motorcommercial/appobjects/motorcommercial", clsName: "MotorCommercial", cls: null },
        "ARI": { file: "app/bms/components/proposal/newbusinessrisks/fireidc/appobjects/fireIDC", clsName: "FireIDC", cls: null },
        "ECP": { file: "app/bms/components/proposal/newbusinessrisks/fireidc/appobjects/fireIDC", clsName: "FireIDC", cls: null },
        "FC1": { file: "app/bms/components/proposal/newbusinessrisks/fireidc/appobjects/fireIDC", clsName: "FireIDC", cls: null },
        "FC2": { file: "app/bms/components/proposal/newbusinessrisks/fireidc/appobjects/fireIDC", clsName: "FireIDC", cls: null },
        "FC3": { file: "app/bms/components/proposal/newbusinessrisks/fireidc/appobjects/fireIDC", clsName: "FireIDC", cls: null },
        "FD1": { file: "app/bms/components/proposal/newbusinessrisks/fireidc/appobjects/fireIDC", clsName: "FireIDC", cls: null },
        "FD2": { file: "app/bms/components/proposal/newbusinessrisks/fireidc/appobjects/fireIDC", clsName: "FireIDC", cls: null },
        "FD3": { file: "app/bms/components/proposal/newbusinessrisks/fireidc/appobjects/fireIDC", clsName: "FireIDC", cls: null },
        "PP1": { file: "app/bms/components/proposal/newbusinessrisks/fireidc/appobjects/fireIDC", clsName: "FireIDC", cls: null },
        "LOP": { file: "app/bms/components/proposal/newbusinessrisks/firelop/appobjects/fireLOP", clsName: "FireLOP", cls: null },
        "HHO": { file: "app/bms/components/proposal/newbusinessrisks/s4846/appobjects/s4846", clsName: "S4846", cls: null },
        "AR": { file: "app/bms/components/proposal/newbusinessrisks/s4805/appobjects/s4805", clsName: "S4805", cls: null },
        "BG": { file: "app/bms/components/proposal/newbusinessrisks/s4805/appobjects/s4805", clsName: "S4805", cls: null },
        "PG": { file: "app/bms/components/proposal/newbusinessrisks/s4805/appobjects/s4805", clsName: "S4805", cls: null },
        "PP2": { file: "app/bms/components/proposal/newbusinessrisks/s4805/appobjects/s4805", clsName: "S4805", cls: null },
        "SR": { file: "app/bms/components/proposal/newbusinessrisks/s4805/appobjects/s4805", clsName: "S4805", cls: null },
        "ARP": { file: "app/bms/components/proposal/newbusinessrisks/s4805/appobjects/s4805", clsName: "S4805", cls: null },
        "EL": { file: "app/bms/components/proposal/newbusinessrisks/s4811/appobjects/s4811", clsName: "S4811", cls: null },
        "WC": { file: "app/bms/components/proposal/newbusinessrisks/s4811/appobjects/s4811", clsName: "S4811", cls: null },
        "WPA": { file: "app/bms/components/proposal/newbusinessrisks/s4811/appobjects/s4811", clsName: "S4811", cls: null },
        "PAC": { file: "app/bms/components/proposal/newbusinessrisks/s5335/appobjects/s5335", clsName: "S5335", cls: null },
        "PAG": { file: "app/bms/components/proposal/newbusinessrisks/s5335/appobjects/s5335", clsName: "S5335", cls: null },
        "MSC": { file: "app/bms/components/proposal/newbusinessrisks/s5335/appobjects/s5335", clsName: "S5335", cls: null },
        "PMA": { file: "app/bms/components/proposal/newbusinessrisks/s5335/appobjects/s5335", clsName: "S5335", cls: null },
        "FPB": { file: "app/bms/components/proposal/newbusinessrisks/s5335/appobjects/s5335", clsName: "S5335", cls: null },//MD001
        "PMB": { file: "app/bms/components/proposal/newbusinessrisks/s5335/appobjects/s5335", clsName: "S5335", cls: null },
        "PMC": { file: "app/bms/components/proposal/newbusinessrisks/s5335/appobjects/s5335", clsName: "S5335", cls: null },
        "PMP": { file: "app/bms/components/proposal/newbusinessrisks/s5335/appobjects/s5335", clsName: "S5335", cls: null },
        "MSW": { file: "app/bms/components/proposal/newbusinessrisks/s5335/appobjects/s5335", clsName: "S5335", cls: null },
        "MWP": { file: "app/bms/components/proposal/newbusinessrisks/s5335/appobjects/s5335", clsName: "S5335", cls: null },
        "MWH": { file: "app/bms/components/proposal/newbusinessrisks/s5335/appobjects/s5335", clsName: "S5335", cls: null },
        "MPA": { file: "app/bms/components/proposal/newbusinessrisks/s5335/appobjects/s5335", clsName: "S5335", cls: null },
        "PAS": { file: "app/bms/components/proposal/newbusinessrisks/s5335/appobjects/s5335", clsName: "S5335", cls: null },
        "TAA": { file: "app/bms/components/proposal/newbusinessrisks/travel/appobjects/travel", clsName: "Travel", cls: null },
        "TDA": { file: "app/bms/components/proposal/newbusinessrisks/travel/appobjects/travel", clsName: "Travel", cls: null },
        "TDI": { file: "app/bms/components/proposal/newbusinessrisks/travel/appobjects/travel", clsName: "Travel", cls: null },
        "TPI": { file: "app/bms/components/proposal/newbusinessrisks/travel/appobjects/travel", clsName: "Travel", cls: null },
        "FGR": { file: "app/bms/components/proposal/newbusinessrisks/s4861/appobjects/s4861", clsName: "S4861", cls: null },
        "FPA": { file: "app/bms/components/proposal/newbusinessrisks/s4857/appobjects/s4857", clsName: "S4857", cls: null },
        "MIT": { file: "app/bms/components/proposal/newbusinessrisks/s4808/appobjects/s4808", clsName: "S4808", cls: null },
        "MAR": { file: "app/bms/components/proposal/newbusinessrisks/s4804/appobjects/s4804", clsName: "S4804", cls: null },
        "MCA": { file: "app/bms/components/proposal/newbusinessrisks/s4804/appobjects/s4804", clsName: "S4804", cls: null },
        "PL": { file: "app/bms/components/proposal/newbusinessrisks/s4810/appobjects/s4810", clsName: "S4810", cls: null },
        "PPL": { file: "app/bms/components/proposal/newbusinessrisks/s4810/appobjects/s4810", clsName: "S4810", cls: null },
        "IPL": { file: "app/bms/components/proposal/newbusinessrisks/s4810/appobjects/s4810", clsName: "S4810", cls: null },
        "PP3": { file: "app/bms/components/proposal/newbusinessrisks/s4810/appobjects/s4810", clsName: "S4810", cls: null },
        "EMC": { file: "app/bms/components/proposal/newbusinessrisks/s5381/appobjects/s5381", clsName: "S5381", cls: null },
        "HIG": { file: "app/bms/components/proposal/newbusinessrisks/s5381/appobjects/s5381", clsName: "S5381", cls: null },
        "HGM": { file: "app/bms/components/proposal/newbusinessrisks/s5381/appobjects/s5381", clsName: "S5381", cls: null },
        "HMG": { file: "app/bms/components/proposal/newbusinessrisks/s5381/appobjects/s5381", clsName: "S5381", cls: null },
        "HII": { file: "app/bms/components/proposal/newbusinessrisks/s5381/appobjects/s5381", clsName: "S5381", cls: null },
        "HIC": { file: "app/bms/components/proposal/newbusinessrisks/s5381/appobjects/s5381", clsName: "S5381", cls: null },
        "HMI": { file: "app/bms/components/proposal/newbusinessrisks/s5381/appobjects/s5381", clsName: "S5381", cls: null },
        "FHG": { file: "app/bms/components/proposal/newbusinessrisks/s6271/appobjects/s6271", clsName: "S6271", cls: null },
        "FHI": { file: "app/bms/components/proposal/newbusinessrisks/s6271/appobjects/s6271", clsName: "S6271", cls: null },
        "FSI": { file: "app/bms/components/proposal/newbusinessrisks/s6271/appobjects/s6271", clsName: "S6271", cls: null },
        "EP": { file: "app/bms/components/proposal/newbusinessrisks/s4805/appobjects/s4805", clsName: "S4805", cls: null },
        "ME": { file: "app/bms/components/proposal/newbusinessrisks/s4805/appobjects/s4805", clsName: "S4805", cls: null },
        "IFF": { file: "app/bms/components/proposal/newbusinessrisks/fireidc/appobjects/fireIDC", clsName: "FireIDC", cls: null },
        "CAR": { file: "app/bms/components/proposal/newbusinessrisks/s4851/appobjects/s4851", clsName: "S4851", cls: null },
        "EAR": { file: "app/bms/components/proposal/newbusinessrisks/s4851/appobjects/s4851", clsName: "S4851", cls: null },
        "CPA": { file: "app/bms/components/proposal/newbusinessrisks/s5183/appobjects/s5183", clsName: "S5183", cls: null },

        /**Simplified */
        "HIGC": { file: "app/bms/components/proposal/newbusinessrisks/generic/appobjects/generic", clsName: "Generic", cls: null },
        "BP": { file: "app/bms/components/proposal/newbusinessrisks/generic/appobjects/generic", clsName: "Generic", cls: null },
        "CER": { file: "app/bms/components/proposal/newbusinessrisks/generic/appobjects/generic", clsName: "Generic", cls: null },
        "CPM": { file: "app/bms/components/proposal/newbusinessrisks/generic/appobjects/generic", clsName: "Generic", cls: null },
        "DS": { file: "app/bms/components/proposal/newbusinessrisks/generic/appobjects/generic", clsName: "Generic", cls: null },
        "EE": { file: "app/bms/components/proposal/newbusinessrisks/generic/appobjects/generic", clsName: "Generic", cls: null },
        "ENE": { file: "app/bms/components/proposal/newbusinessrisks/generic/appobjects/generic", clsName: "Generic", cls: null },
        "MB": { file: "app/bms/components/proposal/newbusinessrisks/generic/appobjects/generic", clsName: "Generic", cls: null },
        "MBL": { file: "app/bms/components/proposal/newbusinessrisks/generic/appobjects/generic", clsName: "Generic", cls: null },
        "ST": { file: "app/bms/components/proposal/newbusinessrisks/generic/appobjects/generic", clsName: "Generic", cls: null },
        "CB": { file: "app/bms/components/proposal/newbusinessrisks/generic/appobjects/generic", clsName: "Generic", cls: null },
        "EWR": { file: "app/bms/components/proposal/newbusinessrisks/generic/appobjects/generic", clsName: "Generic", cls: null },
        "JBI": { file: "app/bms/components/proposal/newbusinessrisks/generic/appobjects/generic", clsName: "Generic", cls: null },
        "DDO": { file: "app/bms/components/proposal/newbusinessrisks/generic/appobjects/generic", clsName: "Generic", cls: null },
        "DandO": { file: "app/bms/components/proposal/newbusinessrisks/generic/appobjects/generic", clsName: "Generic", cls: null },
        "DPI": { file: "app/bms/components/proposal/newbusinessrisks/generic/appobjects/generic", clsName: "Generic", cls: null },
        "GL": { file: "app/bms/components/proposal/newbusinessrisks/generic/appobjects/generic", clsName: "Generic", cls: null },
        "PI": { file: "app/bms/components/proposal/newbusinessrisks/generic/appobjects/generic", clsName: "Generic", cls: null },
        "PRL": { file: "app/bms/components/proposal/newbusinessrisks/generic/appobjects/generic", clsName: "Generic", cls: null },
        "TCM": { file: "app/bms/components/proposal/newbusinessrisks/generic/appobjects/generic", clsName: "Generic", cls: null },
        "WLL": { file: "app/bms/components/proposal/newbusinessrisks/generic/appobjects/generic", clsName: "Generic", cls: null },
        "TER": { file: "app/bms/components/proposal/newbusinessrisks/generic/appobjects/generic", clsName: "Generic", cls: null },
        "PQ1": { file: "app/bms/components/proposal/newbusinessrisks/generic/appobjects/generic", clsName: "Generic", cls: null },
        "PR1": { file: "app/bms/components/proposal/newbusinessrisks/generic/appobjects/generic", clsName: "Generic", cls: null },
        "FSG": { file: "app/bms/components/proposal/newbusinessrisks/generic/appobjects/generic", clsName: "Generic", cls: null },
        "FSH": { file: "app/bms/components/proposal/newbusinessrisks/generic/appobjects/generic", clsName: "Generic", cls: null },
        "PRA": { file: "app/bms/components/proposal/newbusinessrisks/generic/appobjects/generic", clsName: "Generic", cls: null },
        "PRB": { file: "app/bms/components/proposal/newbusinessrisks/generic/appobjects/generic", clsName: "Generic", cls: null },
        "ARO": { file: "app/bms/components/proposal/newbusinessrisks/generic/appobjects/generic", clsName: "Generic", cls: null },
        "CPP": { file: "app/bms/components/proposal/newbusinessrisks/generic/appobjects/generic", clsName: "Generic", cls: null },
        "PSI": { file: "app/bms/components/proposal/newbusinessrisks/generic/appobjects/generic", clsName: "Generic", cls: null },
        "RIS": { file: "app/bms/components/proposal/newbusinessrisks/generic/appobjects/generic", clsName: "Generic", cls: null },
        "SSS": { file: "app/bms/components/proposal/newbusinessrisks/generic/appobjects/generic", clsName: "Generic", cls: null },
        "HCR": { file: "app/bms/components/proposal/newbusinessrisks/generic/appobjects/generic", clsName: "Generic", cls: null },
        "HCS": { file: "app/bms/components/proposal/newbusinessrisks/generic/appobjects/generic", clsName: "Generic", cls: null },
        "MH": { file: "app/bms/components/proposal/newbusinessrisks/generic/appobjects/generic", clsName: "Generic", cls: null },
        "MHA": { file: "app/bms/components/proposal/newbusinessrisks/generic/appobjects/generic", clsName: "Generic", cls: null },
        "MHC": { file: "app/bms/components/proposal/newbusinessrisks/generic/appobjects/generic", clsName: "Generic", cls: null },
        "MHP": { file: "app/bms/components/proposal/newbusinessrisks/generic/appobjects/generic", clsName: "Generic", cls: null },
        "MHY": { file: "app/bms/components/proposal/newbusinessrisks/generic/appobjects/generic", clsName: "Generic", cls: null },
        "MLL": { file: "app/bms/components/proposal/newbusinessrisks/generic/appobjects/generic", clsName: "Generic", cls: null },
        "MPI": { file: "app/bms/components/proposal/newbusinessrisks/generic/appobjects/generic", clsName: "Generic", cls: null },
        "CR": { file: "app/bms/components/proposal/newbusinessrisks/generic/appobjects/generic", clsName: "Generic", cls: null },
        "GHS": { file: "app/bms/components/proposal/newbusinessrisks/generic/appobjects/generic", clsName: "Generic", cls: null },
        "GSL": { file: "app/bms/components/proposal/newbusinessrisks/generic/appobjects/generic", clsName: "Generic", cls: null },
        "LLS": { file: "app/bms/components/proposal/newbusinessrisks/generic/appobjects/generic", clsName: "Generic", cls: null },
        "LSI": { file: "app/bms/components/proposal/newbusinessrisks/generic/appobjects/generic", clsName: "Generic", cls: null },
        "MED": { file: "app/bms/components/proposal/newbusinessrisks/generic/appobjects/generic", clsName: "Generic", cls: null },
        "PHS": { file: "app/bms/components/proposal/newbusinessrisks/generic/appobjects/generic", clsName: "Generic", cls: null },
        "PSL": { file: "app/bms/components/proposal/newbusinessrisks/generic/appobjects/generic", clsName: "Generic", cls: null },
        "PSM": { file: "app/bms/components/proposal/newbusinessrisks/generic/appobjects/generic", clsName: "Generic", cls: null },
        "BDY": { file: "app/bms/components/proposal/newbusinessrisks/generic/appobjects/generic", clsName: "Generic", cls: null },
        "GNA": { file: "app/bms/components/proposal/newbusinessrisks/generic/appobjects/generic", clsName: "Generic", cls: null },
        "LPG": { file: "app/bms/components/proposal/newbusinessrisks/generic/appobjects/generic", clsName: "Generic", cls: null },
        "JTA": { file: "app/bms/components/proposal/newbusinessrisks/generic/appobjects/generic", clsName: "Generic", cls: null },
        "PFP": { file: "app/bms/components/proposal/newbusinessrisks/generic/appobjects/generic", clsName: "Generic", cls: null },
        "PSP": { file: "app/bms/components/proposal/newbusinessrisks/generic/appobjects/generic", clsName: "Generic", cls: null },
        "TPA": { file: "app/bms/components/proposal/newbusinessrisks/generic/appobjects/generic", clsName: "Generic", cls: null },
        "APC": { file: "app/bms/components/proposal/newbusinessrisks/generic/appobjects/generic", clsName: "Generic", cls: null },
        "EPP": { file: "app/bms/components/proposal/newbusinessrisks/generic/appobjects/generic", clsName: "Generic", cls: null },
        "GKP": { file: "app/bms/components/proposal/newbusinessrisks/generic/appobjects/generic", clsName: "Generic", cls: null },
        "KPP": { file: "app/bms/components/proposal/newbusinessrisks/generic/appobjects/generic", clsName: "Generic", cls: null },
        "MKP": { file: "app/bms/components/proposal/newbusinessrisks/generic/appobjects/generic", clsName: "Generic", cls: null },
        "PCP": { file: "app/bms/components/proposal/newbusinessrisks/generic/appobjects/generic", clsName: "Generic", cls: null },
        "PPC": { file: "app/bms/components/proposal/newbusinessrisks/generic/appobjects/generic", clsName: "Generic", cls: null },
        "SKP": { file: "app/bms/components/proposal/newbusinessrisks/generic/appobjects/generic", clsName: "Generic", cls: null },
        "SSP": { file: "app/bms/components/proposal/newbusinessrisks/generic/appobjects/generic", clsName: "Generic", cls: null },
        "WPP": { file: "app/bms/components/proposal/newbusinessrisks/generic/appobjects/generic", clsName: "Generic", cls: null },
        "BGD": { file: "app/bms/components/proposal/newbusinessrisks/generic/appobjects/generic", clsName: "Generic", cls: null },
        "GCH": { file: "app/bms/components/proposal/newbusinessrisks/generic/appobjects/generic", clsName: "Generic", cls: null },
        "GI": { file: "app/bms/components/proposal/newbusinessrisks/generic/appobjects/generic", clsName: "Generic", cls: null },
        "SG": { file: "app/bms/components/proposal/newbusinessrisks/generic/appobjects/generic", clsName: "Generic", cls: null },
        "WPI": { file: "app/bms/components/proposal/newbusinessrisks/generic/appobjects/generic", clsName: "Generic", cls: null },
        "POL": { file: "app/bms/components/proposal/newbusinessrisks/generic/appobjects/generic", clsName: "Generic", cls: null },
        "FHD": { file: "app/bms/components/proposal/newbusinessrisks/generic/appobjects/generic", clsName: "Generic", cls: null },
        "FHE": { file: "app/bms/components/proposal/newbusinessrisks/generic/appobjects/generic", clsName: "Generic", cls: null },
    }; //MYS-2018-0523 Added FHD and FHE product in above list
	public getNewRiskObj(criteria: any) {
        return this.getInstanceByClass(criteria.riskType).getNewInstanceByCriteria(criteria);
    }

    public getOldRiskObj(riskType: string, riskObj) {
        return this.getInstanceByClass(riskType).getInstance(riskObj);
    }

    public getInstanceByClass(riskType) {
        return new RiskFactory.RISKOBJMAP[riskType].cls();
    }

    public static setClass(riskType, cls) {
            let riskInfo = RiskFactory.RISKOBJMAP[riskType];
            let clsName = riskInfo.clsName;
            let rts = Object.keys(RiskFactory.RISKOBJMAP);
            for (let eachRts of rts) {
                let eachRiskInfo = RiskFactory.RISKOBJMAP[eachRts];
                if (eachRiskInfo.clsName == clsName)
                    eachRiskInfo.cls = cls;
            }
    }

    public static getRiskInfo(riskType) {
        return RiskFactory.RISKOBJMAP[riskType];
    }

    //Endorsements Code
    public static RISKOBJMAPENCA = {
        "ANY": { file: "app/bms/components/proposal/newbusinessrisks/generic/appobjects/generic", clsName: "Generic", cls: null }
    };

    public getNewENCARiskObj(criteria: any) {
        return this.getInstanceByENCAClass(criteria.riskType).getNewInstanceByCriteria(criteria);
    }
    public getOldENCARiskObj(riskType: string, riskObj) {
        return this.getInstanceByENCAClass(riskType).getInstance(riskObj);
    }
    public getInstanceByENCAClass( riskType ) {
        return new RiskFactory.RISKOBJMAPENCA[riskType].cls();
    }
    public static setENCAClass(riskType, cls) {
        let riskInfo = RiskFactory.RISKOBJMAPENCA[riskType];
        let clsName = riskInfo.clsName;
        let rts = Object.keys(RiskFactory.RISKOBJMAPENCA);
        for (let eachRts of rts) {
            let eachRiskInfo = RiskFactory.RISKOBJMAPENCA[eachRts];
            if (eachRiskInfo.clsName == clsName)
                eachRiskInfo.cls = cls;
        }
    }
    public static getENCARiskInfo(riskType) {
        return RiskFactory.RISKOBJMAPENCA[riskType];
    }
    //End
}
export class RiskCriteria {
    public contractType: string;
    public riskType: string;
}