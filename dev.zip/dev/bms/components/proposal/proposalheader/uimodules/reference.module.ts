import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BasicUIModule } from '../../../../../common/components/utility/basicui.module';
import { ReferencesComponent } from './references.component';
import { ExtraDetailsModule } from './extraDetails.module';

@NgModule({
    imports: [CommonModule, FormsModule, ReactiveFormsModule, BasicUIModule, ExtraDetailsModule],
    declarations: [ReferencesComponent],
    exports: [ReferencesComponent]
})
export class ReferenceModule { }