import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BasicUIModule } from '../../../../../common/components/utility/basicui.module';

import { BancaComponent } from './banca.component';

@NgModule({
    imports: [CommonModule, FormsModule, ReactiveFormsModule, BasicUIModule],
    declarations: [BancaComponent],
    exports: [BancaComponent]
})
export class BancaModule { }