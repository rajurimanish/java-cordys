/*
Change History	:

	No      Date          Description                                 Changed By
	====    ==========    ===========                                 ==========
	AL001   30/08/2017   MYS-2017-0696-  To allow input of special 
                          characters at Reference Number field               ALA										   
*/
import { Component, OnInit, Injector } from '@angular/core';
import { Reference, ReferenceDetails } from '../appobjects/proposalheader';
import { DatePickerModule } from '../../../../../common/components/utility/date/datepicker.module';
import { LOV_Field, LOVDropDownService, SearchFilter } from "../../../../../common/services/lovdropdown/lovdropdown.service";
import { LovModule } from "../../../../../common/services/lovdropdown/lov.module";
import { AlertMessagesService } from '../../../../../common/components/utility/alertmessage/alertmessages.service';
import { AlertMessage } from '../../../../../common/components/utility/alertmessage/alertmessages.model';
import { ReferenceValidator } from '../../validation/reference.validator';
import { ReferenceService } from '../service/reference.service';
import { AppUtil } from '../../../../../common/components/utility/apputil/app.util';
import { BMSConstants } from '../../../common/constants/bms_constants';

@Component({
    selector: 'references',
    templateUrl: 'app/bms/components/proposal/proposalheader/uimodules/references.template.html',
    inputs: ["_references", "_handlingBranch", "_extraDetails"]
})

export class ReferencesComponent implements OnInit {

    private collapseRefInfo: boolean = false;
    private collapsePerRefInfo: boolean = false;

    public _references: Reference;
    public _handlingBranch: String;

    constructor(public injector: Injector, private lovDropDownService: LOVDropDownService, public _alertMsgService: AlertMessagesService, public _refServ: ReferenceService) {
    }

    ngOnInit(): any {//alert(this._handlingBranch);

        this.populateLOVs();
        /*if(this._references.reference != undefined && !(this._references.reference.constructor === Array)) {
            let reference:any = this._references.reference;
            this._references.reference = [reference];
        }*/
        this.handleSimplified();
    }
    handleSimplified() {
        if (BMSConstants.TEMPOBJ.ISSIMPLIFIEDPROCESS == 'Y') {
            this.collapseRefInfo = true;
        }
    }

    addReference() {
        let result = this.validateRefRecord();
        if (this._references.reference.length > 0) {
            if (result && result.isValid) {
                let refDetails: ReferenceDetails = new ReferenceDetails();
                this._references.reference.push(refDetails);
            }
            else
                this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, result.message, 5000));
        }
        else {
            let refDetails: ReferenceDetails = new ReferenceDetails();
            this._references.reference.push(refDetails);
        }
    }

    removeReference(idx: number) {
        this._references.reference.splice(idx, 1);
    }

    onChangeTitle(event) {
        let _isAlreadyAdded: boolean = false;
        let counter = 0;
        for (let eachRef of this._references.reference) {
            if (event.target.value == eachRef.title) {
                counter++;
                if (counter > 1) _isAlreadyAdded = true;
            }
        }
        if (_isAlreadyAdded) {
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Already Selected value: " + event.target.value + " as Reference Title. Please select another Reference Title", 5000));
            event.target.value = '';
        }
    }

    validateRefRecord() {
        var result;
        if (this._references.reference && this._references.reference.length > 0) {
            for (let eachref of this._references.reference) {
                result = new ReferenceValidator(eachref).validate();
            }
        }
        return result;
    }

    validateRefNo(eachRef, idx: number) {
        let refNo = eachRef.referenceNumber;
        if (refNo != undefined && refNo.length > 0) {
             //AL001 START
            /*
            if(!refNo.match("^[A-Za-z0-9-]+$")) {
                this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Please provide Alphanumeric values as input for reference number" , 2000));
                eachRef.referenceNumber = '';
                this._references.reference[idx].referenceNumber = '';
            }
            else {
             */ if (refNo.includes("^")) {
                this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Please provide Alphanumeric values as input for reference number", 2000));
                eachRef.referenceNumber = '';
                this._references.reference[idx].referenceNumber = '';
            }
            else {
                //AL001 END
                if (eachRef.title == '') {
                    this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Please select Reference Type", 2000));
                    eachRef.referenceNumber = '';
                    this._references.reference[idx].referenceNumber = '';
                }
                if (eachRef.title == 'Broker') {
                    if (refNo.length > 24) {
                        this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Please provide Broker Reference Number with length less than 24 as input", 2000));
                        eachRef.referenceNumber = '';
                        this._references.reference[idx].referenceNumber = '';
                    }
                }
                else if (eachRef.title == 'Ceding') {
                    if (refNo.length > 25) {
                        this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Please provide Ceding Reference Number with length less than 25 as input", 2000));
                        eachRef.referenceNumber = '';
                        this._references.reference[idx].referenceNumber = '';
                    }
                }
                else if (eachRef.title == 'Cover') {
                    if (refNo.length > 8) {
                        this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Please provide Cover Note Reference Number with length less than 8 as input", 2000));
                        eachRef.referenceNumber = '';
                        this._references.reference[idx].referenceNumber = '';
                    }
                }
                else if (eachRef.title == 'Reference') {
                    if (refNo.length > 10) {
                        this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Please provide Reference Number with length less than 10 as input", 2000));
                        eachRef.referenceNumber = '';
                        this._references.reference[idx].referenceNumber = '';
                    }
                }

            }
        }
    }

    private populateLOVs(): void {
        this._refServ.getRestrictedCedings().subscribe((restrictedCed) => {
            this.lovDropDownService.createLOVDataList(["CrossRefCodes"]);

            let restList = AppUtil.getNotInList(restrictedCed, "");

            let cFilter = [];
            if (restList != "") {
                cFilter = this.lovDropDownService.createFilter([new SearchFilter("DESCITEM", restList, "NOT IN", "AND")]);
            }

            let lovFields = [
                new LOV_Field("ALL", "ALL", "NEW BUSINESS", "ALL", "NEW", "REFERENCES", "Cross Reference Code", "LOV", cFilter, "DESCPF", "CrossRefCodes", null)];
            this.lovDropDownService.util_populateLOV(lovFields, this);
        });
    }

}