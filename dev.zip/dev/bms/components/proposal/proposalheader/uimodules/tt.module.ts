import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DatePickerModule } from '../../../../../common/components/utility/date/datepicker.module';

import { TurnAroundTimeComponent } from './tt.component';

@NgModule({
    imports: [CommonModule, FormsModule, ReactiveFormsModule, DatePickerModule],
    declarations: [TurnAroundTimeComponent],
    exports: [TurnAroundTimeComponent]
})
export class TurnAroundTimeModule { }