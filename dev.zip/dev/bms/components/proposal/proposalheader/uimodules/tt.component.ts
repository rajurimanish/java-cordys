import { Component, OnInit } from '@angular/core';
import { TurnAroundTime } from '../appobjects/turnAroundTime';
import { AlertMessagesService } from '../../../../../common/components/utility/alertmessage/alertmessages.service';
import { AlertMessage } from '../../../../../common/components/utility/alertmessage/alertmessages.model';

@Component({
    selector: 'turnaround-time',
    templateUrl: 'app/bms/components/proposal/proposalheader/uimodules/tt.template.html',
    inputs: ['turnAroundTime']
})

export class TurnAroundTimeComponent implements OnInit {

    private collapseTTInfo: boolean = false;
    public turnAroundTime: TurnAroundTime;

    constructor(public _alertMsgService: AlertMessagesService) { }

    ngOnInit() {

    }
}