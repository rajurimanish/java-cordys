import { Pipe, PipeTransform } from '@angular/core';
@Pipe({ name: 'riskType', pure: false })
export class RiskTypePipe implements PipeTransform {
    transform(riskTypeAry: any, allRiskAry: any, hasRiskToAdd: any): any {
        if (riskTypeAry != null && allRiskAry != null && allRiskAry.length > 0) {
            let requiredAry = riskTypeAry.filter(riskType => this.checkRiskAdded(riskType, allRiskAry));
            this.setRiskButtonState(requiredAry, hasRiskToAdd);
            return requiredAry;
        }
        else {
            this.setRiskButtonState(riskTypeAry, hasRiskToAdd);
            return riskTypeAry;
        }
    }

    setRiskButtonState(ary, hasRiskToAdd) {
        if (ary != null && ary.length == 0) {
            hasRiskToAdd.has = false;
        }
        else if (ary != null && ary.length > 0) {
            hasRiskToAdd.has = true;
        }
    }

    checkRiskAdded(riskType, allRiskAry) {
        let listbyRT = allRiskAry.filter(risk => risk.riskType == riskType.riskType);
        if ((riskType.isMultiple == null || riskType.isMultiple == 'N') && listbyRT.length >= 1) {
            return false;
        }
        else {
            return true;
        }
    }
}