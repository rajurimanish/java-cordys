/*
Change History	:

	No      Date          Description                                            Changed By
	====    ==========    ===========                                            ==========
	AL001   15/08/2017   MYS-2017-0371    -  Develop MPD                            ALA	
	MD001   09/03/2018   MYS-2017-0920    -  ABC PA to be incorporated 
	                                         into BMS                               MKU1
	MD002   02/07/2018   MYS-2018-0679    -  Incorrect peril details 
	                                         populated for Fire products in BMS		MKU1 								 	
	
    KA001  18/10/2018    MYS-2018-0896    -  To save Premium Details	            DKA	
    MR001  07/05/2019    MYS-2019-0526    - Adding the validation Inception         MRA1
	                                        Date and End Date for Cover Note in BMS 									 

	KA002  16/08/2019    MYS-2018-0974    -  To autopopulate discount for CPA
                                             if more than 1 insured                 DKA
    GA001  11/09/2019  MYS-2019-0974 - BMS Enhancement on High Risk Vehicle & Client       KGA
*/
import { Component, OnInit, EventEmitter, ViewChild, ElementRef, AfterViewInit, ViewContainerRef } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Risks } from '../../appobjects/proposal';
import { RiskType } from './risktypes';
import { ClientDetails } from '../../../../../common/components/client/appobjects/client';
import { CordysSoapWService } from '../../../../../common/components/utility/cordys-soap-ws';
import { GetLOVData, SearchAdvancedConfig, Filter } from '../../../../../common/components/utility/search/search.requests';
declare var Rx: any;
declare var Observer: any;
import { ProposalHeader } from '../appobjects/proposalheader';
import { HeaderValidator } from '../../validation/header.validator';
import { AlertMessagesService } from '../../../../../common/components/utility/alertmessage/alertmessages.service';
import { AlertMessage } from '../../../../../common/components/utility/alertmessage/alertmessages.model';
import { AppUtil } from '../../../../../common/components/utility/apputil/app.util';
import { CustomDCLService, DCLInput } from '../../../../../common/services/customdcl.service';
import { RiskFactory, RiskCriteria } from './riskFactory';
import { RiskArray } from './riskArray';
import { RiskModule } from './riskModule';
import { BMSConstants } from '../../../common/constants/bms_constants';
import { BMSType } from '../../../common/constants/bms_types';
import { CaseInfo } from '../../../../../common/components/appobjects/caseinfo';
import { ModalInput } from "../../../../../common/components/utility/modal/modal";
import { RiskTableService } from '../service/riskTable.service';
import { RIService } from '../../newbusinessrisks/services/ri.service';
import { RiskClassificationService } from '../../newbusinessrisks/services/riskcls.service';
import { BMSAppObjService } from '../../../../services/bmsappobj.service';
import { BMSUtilService } from '../../../../services/bms.util.service';

declare var jQuery: any;
declare var numeral: any;
declare var moment: any;

@Component( {
    selector: 'risk-table',
    templateUrl: 'app/bms/components/proposal/proposalheader/uimodules/risktable.template.html',
    inputs: ['product', 'risks', 'clientDetails', 'headerInfo', 'status', 'caseInfo'],
    outputs: ['onRiskSelect', 'onRiskRemove']
} )

export class RiskTableComponent implements OnInit {
    private isCollapsedMode: boolean = true;
    private mtiCollapse: boolean = false;
    public clientDetails: ClientDetails;
    private product: string;
    public risks: Risks;
    private el: HTMLElement;
    public headerInfo: ProposalHeader;
    public status: string;
    public hasRiskToAdd: any = { has: true };
    public caseInfo: CaseInfo;
    public disableForm = 'N';

    public premiumFormat: string = "0,00.00";
    public siFormat: string = "0,00";
    public rateFormat: string = "0.00000";

    public minimumPremium = 0;
    public search: String = "";
    public position = 1;
    public sizeObj = { length: 0, orglength: 0 };
    public contentSizeObs: any;
    public itemPerPage = 5;
    public maxPageCount = 5;
    public _appUtil: AppUtil;
    public hideProgress: boolean = true;
    private rebateCtrl: any;
    private selectedRiskIndex: number = -1; //FIX:double clicking on risk summary table row, risk component rendering twice when clear browser cache..
    public isRTButtonEnable: boolean = false;
    public isRerate: boolean = false;
    public references = [];
    public totalRiskCount;
    public riskFetch: boolean = false;
    public riskfetchEnable: boolean = false;
    public isFetchLocked: boolean = false;
    public showMultiRisk: boolean = true;
    public dontShowRisk: boolean = true;
    public isRiskCollapsedMode: boolean = false;

    public rtRisksInfo: any;
    @ViewChild( 'risksModal', { read: ViewContainerRef } ) contentArea: ViewContainerRef;
    @ViewChild( 'rtModal', { read: ViewContainerRef } ) rtModalArea: ViewContainerRef;

    private isMTILoaded: boolean = false;
    @ViewChild( 'mtiModal', { read: ViewContainerRef } ) mtiArea: ViewContainerRef;
    onRiskSelect = new EventEmitter<any>();
    onRiskRemove = new EventEmitter<any>();
    constructor( private _cordysService: CordysSoapWService, public _alertMsgService: AlertMessagesService, el: ElementRef, private _dcl: CustomDCLService, private _activatedRoute: ActivatedRoute, private _rtService: RiskTableService, private _riService: RIService, private _rcls: RiskClassificationService, private _bmsObj: BMSAppObjService, private _bus: BMSUtilService ) {
        this.el = el.nativeElement;
        this._appUtil = new AppUtil();
    }


    ngOnInit() {
        this.rtRisksInfo = this._rtService.getRiskTableInfo();
        this.rtRisksInfo.allRisks.length = 0;
        this.rtRisksInfo.currentRiskObj = null;
        //this._rtService.refreshVPMSRebateByAgent().subscribe();
        this.setStatus( this.status );
        this.setRisksAry();
        this.selectFirstRisk();
        this.resetAllPremTotal();
        this.RTButtonHandler();
        this.handleRenewal();
        this.handleRiskFetch();
        //For Sticky Risk Type Handling
        if ( this.rtRisksInfo.allRisks.length == 0 ) {
            this._rtService.resetRiskList( true );
        }
        // SAF MYS-2018-1249 start
        if ( ["MyTasks", "MyDrafts"].indexOf( this._activatedRoute.snapshot.params['component'] ) >= 0 || Object.keys( this._activatedRoute.snapshot.params ).length == 0 ) {
            this._rtService.refreshVPMSRebateByAgent().subscribe();
            if ( this.headerInfo.lineOfBusiness == "FIR" && this.headerInfo.contractType != "LOP" ) {
                this._rtService.setRiskScreenActivationInfo( this.headerInfo.contractType );
            }
        } //End
    }

    handleRiskFetch() {
        if ( BMSConstants.getBMSType() == BMSType.RenewalRerate || BMSConstants.getBMSType() == BMSType.Renewal || BMSConstants.getBMSType() == BMSType.MiscCN ) {
            this.riskFetch = true;
            this.totalRiskCount = BMSConstants.getBMSHeaderInfo().noOfRisks;
            if ( this.rtRisksInfo.allRisks.length < this.totalRiskCount ) {
                this.riskfetchEnable = true;
            }
            else {
                this.riskfetchEnable = false;
            }
        }
    }

    handleRenewal() {
        if ( BMSConstants.getBMSType() == BMSType.RenewalRerate || BMSConstants.getBMSType() == BMSType.Renewal ) {
            this.isRerate = true;

        }
    }

    RTButtonHandler() {
        if ( ( this._activatedRoute.snapshot.params['component'] == "MiscCNEnquiry" || this._activatedRoute.snapshot.params['component'] == "CoverNoteEnquiry" ) && this.headerInfo.lineOfBusiness == 'MTR' && ( this.caseInfo.policyNumber != undefined && this.caseInfo.policyNumber != '' ) )
            this.isRTButtonEnable = true;
    }

    ngAfterViewInit() {
        this.setFormDisabled();
    }

    setStatus( state ) {
        this.status = state;
    }

    setRisksAry() {
        this.rtRisksInfo.allRisks = this.risks.getRisksByPriority();
    }

    selectFirstRisk() {
        if ( this.rtRisksInfo.allRisks != null && Array.prototype.isPrototypeOf( this.rtRisksInfo.allRisks ) && this.rtRisksInfo.allRisks[0] != null ) {
            this.selectedRiskIndex = 0;
            this.rtRisksInfo.currentRiskObj = this.rtRisksInfo.allRisks[0];
            BMSConstants.setSelectedRiskType( this.rtRisksInfo.currentRiskObj.riskType );
            this.dontShowRisk = false;
            let defaultLoad = new RiskModule().getModule( this.rtRisksInfo.currentRiskObj.riskType )[3];
            if ( defaultLoad == "Y" ) {
                this.loadRiskPage();
                this.isRiskCollapsedMode = true;
            }

        }
        if ( this.rtRisksInfo.currentRiskObj && this.headerInfo.isSimplifiedProcess == 'Y' ) {
            this.onRiskSelect.emit( this.rtRisksInfo.currentRiskObj );
        }
    }

    selectRisk( risk, idx ) {

        this.dontShowRisk = false;
        if ( this.rtRisksInfo.currentRiskObj == null || this.rtRisksInfo.currentRiskObj.riskNumber != risk.riskNumber ) {
            this.removeRiskContent();
            this.isRiskCollapsedMode = false;
            this.rtRisksInfo.currentRiskObj = risk;
            this.selectedRiskIndex = idx;
            BMSConstants.setSelectedRiskType( risk.riskType );
            let defaultLoad = new RiskModule().getModule( this.rtRisksInfo.currentRiskObj.riskType )[3];
            if ( defaultLoad == "Y" ) {
                this.loadRiskPage();
                this.isRiskCollapsedMode = true;
            }
            if ( this.headerInfo.isSimplifiedProcess == 'Y' ) {
                this.onRiskSelect.emit( this.rtRisksInfo.currentRiskObj );
            }
        }
        risk.dateOfAttachment = this.headerInfo.effectiveDate;//MD002
    }

    loadRiskPage() {
        this.loadComponent( new RiskModule().getModule( this.rtRisksInfo.currentRiskObj.riskType ), null );
    }

    resetAllPremTotal() {
        //BMSConstants.getNewBusinessInfo().resetAllPremCalc();
        //SST Code
        if ( ["MyTasks", "MyDrafts"].indexOf( this._activatedRoute.snapshot.params['component'] ) >= 0 || Object.keys( this._activatedRoute.snapshot.params ).length == 0 ) // SST Code
        {
            BMSConstants.getNewBusinessInfo().resetAllPremCalc();
        }
        //End
    }

    setFormDisabled() {
        if ( jQuery( "#bmsForm" ).prop( "disabled" ) == true ) {
            this.disableForm = "Y";
        }
    }

    addRisk( risk ) {
        if ( this.isHeaderValid() == true ) {
            this._bmsObj.loadClassFileByRiskType( risk.riskType ).subscribe( () => {
                if ( this.rtRisksInfo.allRisks && this.rtRisksInfo.allRisks.length == 0 ) {
                    this.selectedRiskIndex = -1;
                }
                let riskType: string = risk.riskType;
				/*if (["PAC","PAG","PMA","FPB","PMB","PMC","PMP","PAS","MSW","MWP","MWH","MPA","FPA"].indexOf(riskType) != -1 ) {//MD001
					let insAge = 0;
					if(["PAC","PAG","PAS","MSW","MWP","MWH","MPA","FPA"].indexOf(riskType) != -1 ){
						insAge = 16;
					}else if(["PMA","PMB","FPB","PMC","PMP"].indexOf(riskType) != -1 ){//MD001
						insAge = 18;
					}
					if (this.getInsuredAge() < insAge) {
						this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Insured Age cannot be less than " + insAge, 5000));
					}else{
						this.getNewRisk(RiskType[riskType], risk.riskName, risk.riMethod, risk.minPrem, risk.screenName, risk.riskPriority);                    
					}
				} //AL001 START
				else*/ if ( riskType == "PAM" && this.rtRisksInfo.allRisks.length == 0 ) {
                    let massage = "<p>Add Risk: Please add MPD risk before PAM</p>"
                    this._alertMsgService.add( new AlertMessage( AlertMessage.INFO, massage, -1 ) );
                } //AL001 END
                else {
                    this.getNewRisk( RiskType[riskType], risk.riskName, risk.riMethod, risk.minPrem, risk.screenName, risk.riskPriority );
                    if ( riskType == 'OSI' || riskType == 'OSS' || riskType == 'HIG' || riskType == 'HGM' || riskType == 'HMG' || riskType == 'HII' || riskType == 'HIC' || riskType == 'HMI' ) {
                        this.rtRisksInfo.riskTypeList = this.rtRisksInfo.riskTypeList.filter( _item => _item === risk );
                    }
                }
                if ( riskType == 'CPA' && this.rtRisksInfo.allRisks.length > 1 ) { // MYS-2018-0974  KA002- START
                    for ( let riskObj of this.rtRisksInfo.allRisks ) {
                        riskObj.discountPercentage = 15;
                        this._bus.setTotalPremium5183( riskObj );
                    }
                    this._alertMsgService.add( new AlertMessage( AlertMessage.WARN, "Spouse Discount of 15% has been added for each Insured", 10000 ) );
                } //KA002- END
                BMSConstants.getNewBusinessInfo().resetAllPremCalc();
                this._riService.setRI().subscribe();
            } );
        }
    }
    getInsuredAge() {
        if ( this.clientDetails.client.genericDetails.clienttype == "P" )
            if ( this.clientDetails.client.personalClientDetails.dateOfBirth != null && this.clientDetails.client.personalClientDetails.dateOfBirth != "" ) {
                let curDate = moment( new Date().toISOString(), "YYYY-MM-DD" );
                let date = moment( this.clientDetails.client.personalClientDetails.dateOfBirth, "YYYY-MM-DD" ).format( "YYYY-MM-DD" );
                return curDate.diff( date, 'year' );
            }
            else {
                return 0;
            }
    }
    isHeaderValid() {
        let result = new HeaderValidator( this.headerInfo ).validate();
        if ( result.isValid == false ) {
            this._alertMsgService.add( new AlertMessage( AlertMessage.INFO, result.message, -1 ) );
        }
        return result.isValid;
    }

    getNewRisk( riskType: RiskType, riskName: string, riMethod: string, minPrem, sreenName: string, priority ): any {

        let riskCriteria = new RiskCriteria();
        riskCriteria.contractType = this.headerInfo.contractType;
        riskCriteria.riskType = RiskType[riskType];

        let riskObj: any = new RiskFactory().getNewRiskObj( riskCriteria );
        //riskObj.riskNumber = this.risks.getNextRiskNumber();
        //AL001 START	
        if ( ["PAM"].indexOf( RiskType[riskType] ) != -1 ) {
            riskObj.riskName = riskName;
            riskObj.vehicalRegNumber = this.risks.motorMPV[0].registrationNumber;
            riskObj.yearOfMake = this.risks.motorMPV[0].yearManufacture;
            riskObj.makeCode = this.risks.motorMPV[0].makeCode;
            riskObj.modelCode = this.risks.motorMPV[0].makeModel;
            riskObj.seatNo = this.risks.motorMPV[0].seats;
            riskObj.description = this.risks.motorMPV[0].makeModelDescription;
        }
        //AL001 END
        this.risks[new RiskArray().getArrayByRiskType( RiskType[riskType] )].push( riskObj );

        riskObj.riskName = riskName;
        riskObj.riskType = RiskType[riskType];
        riskObj.dateOfAttachment = this.headerInfo.effectiveDate;
        riskObj.RIMethod = riMethod;
        riskObj.RIMethodSys = riMethod;
        riskObj.terminationDate = "9999-99-99";
        riskObj.rebate = parseFloat( "" + this.headerInfo.rebate );
        riskObj.minimumPremium = parseFloat( "" + minPrem );
        riskObj.isNew = "Y";
        if ( priority )
            riskObj.priority = priority;

        this.setRIRequired( riskObj, riMethod );
        this.setVPMSInfoForRisk( riskObj );

        if ( sreenName ) {
            this.headerInfo.riskScreen = sreenName;
        }

        this.rtRisksInfo.allRisks.push( riskObj );
        this.resetRiskNumber();

        this.setReferred();

        return riskObj;
    }

    setVPMSInfoForRisk( riskObj ) {
        if ( this.headerInfo.lineOfBusiness == "MTR" ) {
            if ( this.headerInfo.VPMSProduct == "N" || this.risks.canHaveVPMSCalculator() == "N" ) {
                riskObj.premiumInfo = null;
                riskObj.isVPMS = "N";
            }
            else
                riskObj.isVPMS = "Y";
        }
        //below is the code to Enable Rebate Flag for FIRE VPMS products.
        if ( this.headerInfo.lineOfBusiness == "FIR" && ( this.headerInfo.VPMSProduct == "N" || this.headerInfo.VPMSProduct == "Y" ) ) {
            riskObj.premiumInfo = null;
            riskObj.isVPMS = "N";
        }
    }

    setRIRequired( risk, riMethod ) {
        if ( riMethod == "8" ) {
            risk.RIRequired = "Yes";
        }
        else {
            risk.RIRequired = "No";
        }
    }

    removeRisk( risk ) {
        this.resetHighRiskNumber(risk);//GA001
        let riskAry = this.risks[new RiskArray().getArrayByRiskType( risk.riskType )];
        riskAry.splice( riskAry.indexOf( risk ), 1 );
        this.rtRisksInfo.allRisks.splice( this.rtRisksInfo.allRisks.indexOf( risk ), 1 );
        this.resetRiskNumber();
        this.resetAllPremTotal();
        this.selectedRiskIndex = -1;
        this.setReferred();
        if ( this.rtRisksInfo.currentRiskObj != null && this.rtRisksInfo.currentRiskObj.riskNumber == risk.riskNumber ) {
            this.rtRisksInfo.currentRiskObj = null;
            this.removeRiskContent();
            this.dontShowRisk = true;
        }

        if ( this.headerInfo.contractType == 'OSI' || this.headerInfo.contractType == 'HIG' || this.headerInfo.contractType == 'HII' ) {
            this.rtRisksInfo.riskTypeList.length = 0;
            this.rtRisksInfo.riskTypeList = this.rtRisksInfo.productRiskTypeList.slice();
        }
        if ( this.headerInfo.isSimplifiedProcess == 'Y' ) {
            this.onRiskRemove.emit( this.rtRisksInfo.currentRiskObj );
        }
        if ( this.headerInfo.contractType == 'CPA' && this.rtRisksInfo.allRisks.length == 1 ) { // MYS-2018-0974  - KA002 START
            for ( let riskObj of this.rtRisksInfo.allRisks ) {
                riskObj.discountPercentage = 0;
                this._bus.setTotalPremium5183( riskObj );
            }
            BMSConstants.getNewBusinessInfo().resetAllPremCalc();
            this._alertMsgService.add( new AlertMessage( AlertMessage.WARN, "Spouse Discount of 15% has been removed since it is only allowed when both Insured and spouse enrol.", 10000 ) );
        } // KA002 END
    }

    removeRiskContent() {
        if ( RiskTableService.rtRisksInfo.currentRiskComponent != null )
            this._dcl.unloadComponent( RiskTableService.rtRisksInfo.currentRiskComponent );
        this._riService.setRI().subscribe();
    }

    resetRiskNumber() {
        if ( BMSConstants.getBMSType() == BMSType.NewBusiness || BMSConstants.getBMSType() == BMSType.CoverNote )
            this.risks.setRiskNumberByPriority();
        else
            this.risks.setRiskNumberForNewItems();
    }

    //GA001 START
    resetHighRiskNumber(risk) {
        if (this.headerInfo.isHighRiskApplicable) {
            let riskNumber: number = risk.riskNumber;
            let riskAry = this.risks[new RiskArray().getArrayByRiskType( risk.riskType )];

            if(this.headerInfo.highRiskIndicatorReasons!=undefined && this.headerInfo.highRiskIndicatorReasons.highRiskIndReason.length>0){
                this.headerInfo.highRiskIndicatorReasons.highRiskIndReason = this.headerInfo.highRiskIndicatorReasons.highRiskIndReason.filter((item) => (item.riskNumber != riskNumber));
                for (let highRiskIndReason1 of this.headerInfo.highRiskIndicatorReasons.highRiskIndReason.filter((item) => (item.riskNumber > riskNumber)) ) {
                    highRiskIndReason1.riskNumber--;
                }
            }
            if(!(this.headerInfo.highRiskIndicatorReasons!=undefined && this.headerInfo.highRiskIndicatorReasons.highRiskIndReason.length>0) ){
                this.headerInfo.highRiskIndicator = "false"; 
                this.headerInfo.highRiskIndicatorUI = false;
                this.headerInfo.highRiskInsuredInternalInd = "";
                this.headerInfo.highRiskNomineeInternalInd = "";
                this.headerInfo.highRiskDriverInternalInd = "";
                this.headerInfo.highRiskVehicleIndicator = "";
            }
        }
    }
    //GA001 END

    validateRebate() {
        if ( this.headerInfo.contractType == null || this.headerInfo.contractType == "" ) {
            this.headerInfo.rebate = 0;
            if ( this.rebateCtrl != null )
                this.rebateCtrl.setter( 0, this.rebateCtrl.comp );

            this._alertMsgService.add( new AlertMessage( AlertMessage.INFO, "Select product in the header before enter rebate.", -1 ) );
        }
        else {
            if ( "" + this.headerInfo.rebate == "null" || "" + this.headerInfo.rebate == "" ) {
                this.headerInfo.rebate = 0;
                if ( this.rebateCtrl != null )
                    this.rebateCtrl.setter( 0, this.rebateCtrl.comp );
            }
            else if ( isNaN( this.headerInfo.rebate ) || isNaN( parseFloat( "" + this.headerInfo.rebate ) ) ) {
                this.headerInfo.rebate = 0;
                if ( this.rebateCtrl != null )
                    this.rebateCtrl.setter( 0, this.rebateCtrl.comp );
                this._alertMsgService.add( new AlertMessage( AlertMessage.INFO, "Enter valid number.", -1 ) );
            }
            else if ( parseFloat( "" + this.headerInfo.rebate ) < 0 || parseFloat( "" + this.headerInfo.rebate ) > parseFloat( "" + this.headerInfo.maxRebate ) ) {
                this.headerInfo.rebate = 0;
                if ( this.rebateCtrl != null )
                    this.rebateCtrl.setter( 0, this.rebateCtrl.comp );
                this._alertMsgService.add( new AlertMessage( AlertMessage.INFO, "Rebate value must be between 0 to " + this.headerInfo.maxRebate + ".", -1 ) );
            }
        }
        this.resetAllPremTotal();
    }

    loadComponent( component, prms ) {
        //AL001 START
        if ( this.rtRisksInfo.currentRiskObj.riskType == "PAM" ) {
            this.rtRisksInfo.currentRiskObj.vehicalRegNumber = this.risks.motorMPV[0].registrationNumber;
            this.rtRisksInfo.currentRiskObj.yearOfMake = this.risks.motorMPV[0].yearManufacture;
            this.rtRisksInfo.currentRiskObj.makeCode = this.risks.motorMPV[0].makeCode;
            this.rtRisksInfo.currentRiskObj.modelCode = this.risks.motorMPV[0].makeModel;
            this.rtRisksInfo.currentRiskObj.modelCodeNew = ( this.risks.motorMPV[0].makeModelNew != undefined && this.risks.motorMPV[0].makeModelNew != "" ) ? this.risks.motorMPV[0].makeModelNew : this.risks.motorMPV[0].makeModel;
            this.rtRisksInfo.currentRiskObj.seatNo = this.risks.motorMPV[0].seats;
            this.rtRisksInfo.currentRiskObj.description = this.risks.motorMPV[0].makeModelDescription;
        } //AL001 END
        this.hideProgress = false;
        let input = new DCLInput();
        input.component = component;
        input.viewContainerRef = this.contentArea;
        input.inputs = { riskObj: this.rtRisksInfo.currentRiskObj, headerInfo: this.headerInfo, clientDetails: this.clientDetails, caseInfo: this.caseInfo };
        input.prms = { comp: this, prms: prms };
        this._dcl.loadComponent( input ).subscribe( ( compRef ) => this.setOutputHandle( compRef, prms ) );
    }

    setOutputHandle( compRef, prms ) {
        RiskTableService.rtRisksInfo.currentRiskComponent = compRef;
        this.hideProgress = true;
        if ( compRef.instance.onPremiumChange != null ) {
            compRef.instance.onPremiumChange.subscribe( () => {
                this.rtRisksInfo.currentRiskObj.basePostedPremiumAdj = 0;
                this.resetAllPremTotal();
            } );
        }
        if ( compRef.instance.onRiskClsChange != null ) {
            compRef.instance.onRiskClsChange.subscribe( () => {
                this.setReferred();
            } );
        }
        if ( compRef.instance.onRtngFlgChange != null ) {
            compRef.instance.onRtngFlgChange.subscribe( () => {
                this.rtRisksInfo.currentRiskObj.basePostedPremiumAdj = 0;
                this.resetAllPremTotal();
            } );
        }
        if ( compRef.instance.prms != null ) {
            compRef.instance.prms = prms;
        }
    }

    setReferred() {
        this._rcls.setRiskClassification( "", "", "", "Y" ).subscribe();
    }

    openRTCoverDialog() {
        let input = new ModalInput();
        input.component = ["RTCoverNoteComponent", "app/bms/components/proposal/newbusinessrisks/motorcommercial/dialogs/rtcovernote.module", "RTCoverNoteModule"];
        input.datainput = {
            riskObj: this.rtRisksInfo.currentRiskObj,
            client: this.clientDetails,
            caseInfo: this.caseInfo
        };
        input.parentCompPRMS = { comp: this };
        input.outputCallback = this.RTCoverDialogCallBack;
        input.heading = "Cover Note Details";
        input.icon = "fa fa-file-text";
        input.containerRef = this.rtModalArea;
        this._dcl.openLookup( input );
    }
    RTCoverDialogCallBack() {

    }

    openPPDetails( risk ) {
        //MR001 start
        if ( ( this.headerInfo.effectiveDate == null || this.headerInfo.effectiveDate == undefined || this.headerInfo.effectiveDate == '' ) && ( this.headerInfo.endDate == null || this.headerInfo.endDate == undefined || this.headerInfo.endDate == '' ) && ( risk.isVPMS == 'N' ) && ( risk.isPOIConsidered == "N" ) ) {
            this._alertMsgService.add( new AlertMessage( AlertMessage.ERROR, "Effective Date and End date are required for posted premium details ", -1 ) );
        }
        //MR001 end
        else {
            let input = new ModalInput();
            input.component = ["PostedPremComponent", "app/bms/components/proposal/proposalheader/dialogs/postedprem.module", "PostedPremModule"];
            input.datainput = { riskObj: risk };
            input.heading = "Posted Premium Details";
            input.icon = "fa fa-file-text";
            input.containerRef = this.rtModalArea;
            this._dcl.openLookup( input ).subscribe( ( data ) => {
                risk.basePostedPremiumAdj = data.data.basePostedPremiumAdj;
                this.resetAllPremTotal();
                this._bmsObj.saveData().subscribe();//Divek -MYS-2018-0896
            } );
        }
    }

    populateRef() {
        if ( this.references.length == 0 ) {
            let prom = this._cordysService.callCordysSoapService( "GetXMLObject", "http://schemas.cordys.com/1.0/xmlstore", { "key": "/com/msig/insurance/reference/references.xml" }, null, null, true, null );

            prom.success( ( resp ) => {
                let refAry = AppUtil.getValueByPath( resp, "tuple.old.references.reference" );
                this.references = this._appUtil.getArray( refAry );
            } );

            prom.error( ( error ) => {
                this.showError( error );
            } );
        }
    }

    showError( response ) {
        this._alertMsgService.add( new AlertMessage( AlertMessage.ERROR, response.responseJSON.faultstring.text, -1 ) );
    }

    downloadFile( reference ) {
        var link = document.createElement( "a" );
        link.href = "http://" + location.host + "/" + reference.filePath;
        link.download = reference.downloadFileName;
        link.click();
    }

    //Multi Risk

    fetchNextSetOfRisks() {
        this.isFetchLocked = true;
        let prom = this._rtService.fetchRisks().subscribe( ( resp ) => this.downloadRisksToRiskObj( resp ) );
    }

    downloadRisksToRiskObj( resp ) {
        let risksTobeAdded = resp;
        //After Push
        this.setRisksAry();
        //this.setReferred();
        this.isFetchLocked = false;
        this.handleRiskFetch();
        this._alertMsgService.add( new AlertMessage( AlertMessage.INFO, "Next set of risks successfully fetched", -1 ) );

    }

    private loadMTI() {
        if ( this.isMTILoaded == false ) {
            let input = new DCLInput();
            input.component = ["MTIComponent", "app/bms/components/proposal/proposalheader/uimodules/mti.module", "MTIModule"];
            input.viewContainerRef = this.mtiArea;
            input.inputs = { mtiItems: this.headerInfo.mtiItems, headerInfo: this.headerInfo };
            this._dcl.loadComponent( input ).subscribe( () => {
                this.isMTILoaded = true;
            } );
        }
    }

    private expandOrCollapseRisk() {
        if ( this.isRiskCollapsedMode ) {
            this.isRiskCollapsedMode = false;
            this.removeRiskContent();
            this.hideProgress = false;
        }
        else {
            this.isRiskCollapsedMode = true;
            this.loadRiskPage();
        }
    }

    private expandOrCollapseRiskSummary() {
        if ( this.isCollapsedMode ) {
            this.isCollapsedMode = false;
        }
        else {
            this.isCollapsedMode = true;
            this.selectFirstRisk();
        }
    }

}

export class RiskItem {
    public riskType: RiskType;
    public risk: any;
}

export class Risk {
    // constructor(public riskType,public riskName,public isMultiple,public riMethod,public minPrem,public stampDuty){}

    constructor( public riskType, public riskName, public isMultiple, public riMethod, public minPrem, public stampDuty, public screenName ) { }
}