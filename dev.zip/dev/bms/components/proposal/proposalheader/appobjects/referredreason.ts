/*
Change History	:

	No      Date          Description                                       Changed By
	====    ==========    ===========                                       ==========
    VK007    03/10/2019   MYS-2018-0993 NGA File Upload + Security Fixes    VKR
 *  
 */


import { AppUtil } from '../../../../../common/components/utility/apputil/app.util';

export class ReferredReason {
    public reasons: Reasons;
    constructor() {
        this.reasons = new Reasons();
    }
    public getInstance(valObj: ReferredReason) {
        if (new AppUtil().isValidObj(valObj) == true) {
            this.reasons = new Reasons().getInstance(valObj.reasons);
        }
        return this;
    }

    public getCombinedReason() {
        return this.reasons.reason.map(reason => { return this.reasons.reason.indexOf(reason) + 1 + ") " + reason }).join(', ');
    }

    public refresh(valObj: ReferredReason) {
        //VK007 commented by VK007 and added below condition
        //if (AppUtil.isEmpty(valObj, false) == false)
        if ( valObj != undefined ) {
            this.reasons.refresh( valObj.reasons );
        }
    }
}

export class Reasons {
    public reason: String[] = [];

    public getInstance(valObj: Reasons) {
        if (new AppUtil().isValidObj(valObj) == true) {
            //Below code to handle if reason is object
            if (typeof (valObj.reason) == "object") {
                valObj.reason = AppUtil.getValueByPath(valObj.reason, "text");
            }//End
            this.reason = new AppUtil().getArray(valObj.reason);
        }
        return this;
    }

    public refresh(valObj: Reasons) {
        if (new AppUtil().isValidObj(valObj) == true) {
            this.reason = new AppUtil().getArray(valObj.reason);
        }
        else
            this.reason = [];
    }
}


export class Reason {
    public reason: string;
    public reasons: Reason[] = [];
}