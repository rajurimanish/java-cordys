import { AppUtil } from '../../../../../common/components/utility/apputil/app.util';

export class TurnAroundTime {
    public bizReceivedDate: string = "";
    public bizAcceptanceDate: string = "";
    public bpuReceivedDate: string = "";

    public getInstance(valObj: TurnAroundTime) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
        }
        return this;
    }
}