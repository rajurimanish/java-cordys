/*
*	Change History	:
*
*	No      Date          Description                               					    Changed By
*   ====    ==========    ===========                              						    =========
*   GA001  15/03/2018  MYS-2018-0266 : Enhancement on Travelright Plus (TAA & TDA)			KGA	
*   GA002  25/09/2018  MYS-2018-0707 : Quotation Date in BMS 					            KGA
*	GA003  14/05/2019  MYS-2019-0609 - HD Log: Incorrect selection of BLACK LIST INDICATOR 
*					   for valid clients in BMS									 			KGA	
*   GA004  07/05/2019  MYS-2019-0041 - To enhance the module of Occupation (update: 0094: MP > 36 months) and
* 					   maintenance period referred risk validation    			            KGA	
*   E1002  17/06/2019  MYS-2019-0402 - When RI Type = Treatment Adjustment, allow PP
                       branch for posting				   							 		SRE1						   
*   GA005  11/09/2019  MYS-2019-0974 - BMS Enhancement on High Risk Vehicle & Client        KGA 
*/
import { TurnAroundTime } from './turnAroundTime';
import { MTIItems } from './mti';
import { AppUtil } from '../../../../../common/components/utility/apputil/app.util';
import { COInsurance } from "../../../../../common/components/coinsurance/appobjects/coinsurance";
import { BMSConstants } from '../../../common/constants/bms_constants';
import { BMSType } from '../../../common/constants/bms_types';
import { ExtraDetails } from './extraDetails';
import { HeaderHelper } from '../../appobjects/headerHelper';
import { ReferredReason, Reason } from './referredreason';
import { CcmOPS, CcmOPSs } from './ccmOPS'; //pku

declare var numeral: any;
declare var moment: any;

export class ProposalHeader extends HeaderHelper {
    public policyNumber: string;
    public caseId: string;
    public contractType: string;
    public contractDescription: string;
    public actionStatus: string;
    public isReferredRisk: string;
    public isReferredToUW: string = "N";
    public isReferredToUWMP: string = "N";//GA004
    public isReferredToHO: string = "N";
    public isReferredRiskUI: boolean = false;
    public insuredNumber: string;
    public insuredName: string;
    public insuredLongName1: string;
    public insuredLongName2: string;
    public insuredLongName3: string;
    public insuredLongName4: string;
    public insuredLongName5: string;
    public insuredType: string;
    public accountHandler: string;
    public commencmentDate: string;
    public renewalDate: string;
    public effectiveDate: string;
    public effectiveDateOrg: string;
    public effectiveDateTemp: string;//GA001
    public originalInceptionDate: string;
    public endDate: string;
    public endDateOrg: string;
    public originalInception: string;
    public lineOfBusiness: string;
    public agentCode: string;
    public agentPhone1: string;
    public agentPhone2: string;
    public agentBranch: string;
    public agentName: string;
    public isManuScriptFilesAttached: string;
    public producerCode: string;
    public validateCoverNote: string;
    public bancaChannel: string;
    public blackListIndicator: string;
    public blackListIndicatorUI: boolean = false;
    public blackListInternalIndicator: string = "N";
    public blackListInternalIndicatorOld: string = "EMPTY";
    public blackListIndicatorOld: string = "EMPTY";
    public blackListReason: string = "";
    public channelConflictIndicator: string;
    public duplicateIndicator: string;
    public UOBSector: string;
    public reference: string;
    public coverNoteNumber: string;
    public acceptanceDate: string;
    public BPUReceived: string;
    public issuedDate: string;
    public receivedDate: string;
    public masterPolicy: string;
    public campaign: string;
    public bankCode: string;
    public receiptNumber: string;
    public cedingReference: string;
    public cedingType: string;
    public brokerReference: string;
    public noticesTo: string;
    public renewalType: string = "";
    public noticeType: string = "";
    public attention: string;
    public duration: string;
    public policyJacket: string;
    public payPlan: string = "";
    public brokerClient: string;
    public scanDate: string;
    public trackingNo: string;
    public territory: string;
    public CoInsurance: string = "N";
    public CoInsuranceUI: boolean = false;
    public sysCOIValidation: string = "O";
    public source: string;
    public majorClass: string;
    public reserved1: string;
    public reserved2: string;
    public handlingBranch: string;
    public servicingBranch: string;
    public businessChannel: string;
    public serviceBranchName: string;
    public businessChannelName: string;
    public lobName: string;
    public PA: string;
    public DA: string;
    public LN: string;
    public GP: string;
    public CO: string;
    public PD: string;
    public TT: string;
    public MI: string;
    public agencyNumber: string;
    public agencyName: string;
    public noOfRisks: string;
    public numberOfCopies: string;
    public printScheduleOption: string;
    public printRIApplOption: string;
    public printSigningSlipOption: string;
    public printCreditDebitNoteOption: string;
    public messages: string;
    public periodicDebitDetails: PeriodicDebitDetails;
    public coInsuranceDetails: COInsurance;
    public ccmOPSs: CcmOPSs; //PKU 
    public references: Reference;
    public extraDetails: ExtraDetails;
    public riskScreen: string;
    public documentReceivedDate: string;
    public policyIssued: string;
    public isHeaderPosted: string;
    public targetSumInsured: number = 0;
    public rebate: number = 0;
    public totalPremium: number = 0;
    public totalNetPostedPremium: number = 0;
    public originalTotalPremium: number = 0;
    public totalPostedPremium: number = 0;
    public originalTotalPostedPremium: number = 0;
    public totalDiscountedPremium: number = 0;
    public turnAroundTime: TurnAroundTime;
    public manuscript: string = "N";
    public manuscriptUI: boolean = false;
    public dispatchRefNo: string;
    public dispatchDate: string;
    public dispatchedBy: string;
    public transactionNumber: string;
    public maxRebate: number = 0;
    public stampDuty: number = 10;
    public mtiItems: MTIItems;
    public insuredAge: number;
    public RIRetentionCode: string;
    public isDeclinedByUW: string = "false";
    public isApprovedBySMT: string = "false";
    public isQuoteGenerated: string = "false";
    public isRFIByDC: string = "false";
    public SMTRole: string = "false";
    public SMTUser: string = "false";
    public isJapaneseChannel: string;
    public misSubTier: string;
    public isConflictResolvedByUser: string = "false";
    public channelConflictedCaseId: string = "false";
    public branchCodeForBanca: string;
    public bancaRequired: string = 'N';
    public bancaRequiredUI: boolean = false;
    public sysBancaValidation: string = 'N';
    public othersButPerd: string = 'N';
    public bancaChecked: string = 'N';
    public MTI: string = 'N';
    public validUOBFMT = "N";
    public validABMBFMT = "N";
    public validHLBFMT = "N";
    public validPAYPLAN = "N";
    public isBancaValidationFailed: string = "N";
    public isVPMS: string = "N";
    public VPMSProduct: string = "N";
    public quotationDate: string = "";
    public coverNoteissuedDate: string = "";
    public isUOBMandatory: string = "N";
    public useMP: string = "";
    public isAgentHasRebate: string = "";
	/******
	 *  Added below properties for Asynchronous posting
	 ******/
    public asyncPostingStatus = "";
    public asyncPostingMessage = "";
    public appealBUSMTForm: any; // added this parameter for issue 1823
    public servicingBranchOriginal: string;
    public isHeaderReferred: string;
    public riskClassificationReasons: ReferredReason;
    public agentCodeOriginal: string;

    public marineOpenCover: string;
    public identity: string = "";
    public RIRequiredHeader: string = "No";
    public RIRequiredHeaderUI: boolean = false;
    public RIRequiredHeaderOrg: string = "No";
    public RIType: string = "";
    public RIReason: string;
    public isApprovalCompleted: string = "N";
    public isRiskEdited: string = "N";
    public AMLCDDCheckUI: boolean = false;
    public AMLCDDCheck: string;
    public AMLCDDDefualtlimit: number;
    public AMLCDDSupDoclimit: number;
    public AMLCDDComments: string = "";
    public HighRiskCusUI: boolean = false;
    public HighRiskCus: string;
    public HighRiskCusType: string = "";
    public HighRiskCusComments: string = "";
    public HighRiskCEOApproval: string;
    public latestEnqRiskNo: string = "";

    public currentCN: string = "";
    public currentRN: string = "";
    public cnOperation: string = "";
    public procId: string = "";
    public gpTextMaxLines:number=400;//VK004

    public isSimplifiedProcess: string = 'N';
    public isReferredProduct: string = 'N';
    public systemGenerated: boolean = true;// KA0001 MYS-2018-0415
    // SAF MYS-2018-0146	
    public agentClientNum: string = "";
    public agentClientSurName: string = "";
    public agentClientGivName: string = "";
    public agentClientPhone: string = "";

    //SAF MYS-2018-0666
    public disableFEAInfo: boolean = true;
    public disableDDInfo: boolean = true;
    //SST code
    public GSTTaxRate: number = 0;
    public SSTTaxRate: number = 0;
    public GSTLiveDate: string;
    public SSTLiveDate: string;
    //End
    // SAF //GA002
    public bizReceivedDate: string = "";//Business Unit Receive date - Assessment date 
    public bizAcceptanceDate: string = "";//Business Unit Acceptance date - Quotation Date from VPMS 
    public bpuReceivedDate: string = "";//BPU Receive date - policy posting date
    //End

    public referredRiskType: string = "";//SAF MYS-2018-0143
    public referredRiskTypeOld: string = "";//SAF MYS-2018-0143

    public firePostingScreen: string = "OLD"; // SAF MYS-2018-1249

    //GA005 START
    public highRiskBNMIndicator: string = "N";
    public highRiskInternalIndicator: string = "N";
    public highRiskVehicleIndicator: string = "N";
    public highRiskLossRatioIndicator: string = "N";
    public highRiskLossRatioWDInd: string = "N";
    public highRiskInsuredBNMInd: string = "N";
    public highRiskInsuredInternalInd: string = "N";
    public highRiskNomineeInternalInd: string = "N";
    public highRiskDriverInternalInd: string = "N";

    public highRiskIndicator: string;
    public highRiskIndicatorUI: boolean = false;
    public highRiskIndicatorType: string = "";
    public highRiskIndicatorReasons = new HighRiskIndReasons();

    public isWDHRV: string = "N";
    public countNWDClaims: string;
    public totalClaimIncurred: string;
    public highRiskLiveDate: string;
    public isHighRiskApplicable: boolean = false;
    public lossRatio:number;
    //GA005 END

    public isRefundInvolved: string = "N";//Endorsements Code
    public isClaimExists: string = "";//Endrosements Code
    public SMTApprovalComments: string = "";//Endrosements Code
    public SMTApproval: string = "N";

    public showCCMOps: boolean = false;//pku
    constructor() {
        super();
        this.references = new Reference(); 
        this.ccmOPSs = new CcmOPSs(); //pku
        this.turnAroundTime = new TurnAroundTime();
        this.riskClassificationReasons = new ReferredReason();
    }

    public getInstance(valObj: ProposalHeader) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
            this.periodicDebitDetails = new PeriodicDebitDetails().getInstance(valObj.periodicDebitDetails);
            if (valObj.CoInsurance == 'Y') {
                this.coInsuranceDetails = new COInsurance().getInstance(valObj.coInsuranceDetails);
            }
            this.references = new Reference().getInstance(valObj.references);
            this.ccmOPSs = new CcmOPSs().getInstance(valObj.ccmOPSs); //pku
            this.turnAroundTime = new TurnAroundTime().getInstance(valObj.turnAroundTime);
            this.riskClassificationReasons = new ReferredReason().getInstance(valObj.riskClassificationReasons);
            if (this.MTI == 'Y')
                this.mtiItems = new MTIItems().getInstance(valObj.mtiItems);
            this.initializeBL();
            //GA005 START
            this.initializeHR();
            if ( typeof ( valObj.highRiskIndicatorReasons ) == "string" || valObj.highRiskIndicatorReasons == undefined || JSON.stringify(valObj.highRiskIndicatorReasons) == JSON.stringify("")) { 
                this.highRiskIndicatorReasons = new HighRiskIndReasons();
                this.defaultHRValues();
            }
            else if ( valObj.highRiskIndicatorReasons != undefined && valObj.highRiskIndicatorReasons.highRiskIndReason != undefined) {
                let tempObj: any = new AppUtil().getArray( valObj.highRiskIndicatorReasons.highRiskIndReason );
                this.highRiskIndicatorReasons.highRiskIndReason = tempObj;
            } 

            //GA005 END
            this.initializeReferred();
            this.initializeAMLCDD();
            this.initializeHighRiskCus();
            this.handleFlags();

            //End
            if ( typeof ( this.showCCMOps ) == "string" ) {
                this.showCCMOps = Boolean( this.showCCMOps );
            }//End
        }
        return this;
    }

    public getNewMiscInstance() {
        this.references = null;
        this.turnAroundTime = null;
        this.riskClassificationReasons = null;
        return this;
    }

    public getMiscInstance(valObj: ProposalHeader) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
        }
        this.references = null;
        this.turnAroundTime = null;
        this.riskClassificationReasons = null;
        return this;
    }

    public setVPMS(needed) {
        this.isVPMS = needed;
    }

    public setMP(needed) {
        this.useMP = needed;
    }
    handleFlags() {
        this.manuscriptUI = this.manuscript == 'Y' ? true : false;
        this.CoInsuranceUI = this.CoInsurance == 'Y' ? true : false;
        this.bancaRequiredUI = this.bancaRequired == 'Y' ? true : false;
        this.RIRequiredHeaderUI = this.RIRequiredHeader == 'Yes' ? true : false;
    }
    initializeAMLCDD() {
        if (this.AMLCDDCheck == "true") {
            this.AMLCDDCheckUI = true;
        }
        else this.AMLCDDCheckUI = false;
    }

    initializeHighRiskCus() {
        if (this.HighRiskCus == "Y") {
            this.HighRiskCusUI = true;
        }
        else this.HighRiskCusUI = false;
    }
    //GA003 START
	/* initializeBL(){
		if(this.blackListIndicator == "false")
			this.blackListIndicatorUI = false;
		else
			this.blackListIndicatorUI = true;
	} */
	initializeBL(){
		if(this.blackListIndicator == "true")
			this.blackListIndicatorUI = true;
		else
			this.blackListIndicatorUI = false;
	}
	//GA003 END
    //GA005 START
    initializeHR(){
		if(this.highRiskIndicator == "true")
			this.highRiskIndicatorUI = true;
		else
			this.highRiskIndicatorUI = false;
    }
    defaultHRValues(){
        this.highRiskIndicatorUI = false;
        this.highRiskIndicator = "false";
        this.highRiskBNMIndicator = "";		
        this.highRiskInternalIndicator = "";	
        this.highRiskVehicleIndicator = "";	
        this.highRiskLossRatioIndicator = "";	
        this.highRiskLossRatioWDInd = "";	
        this.highRiskInsuredBNMInd = "";		
        this.highRiskInsuredInternalInd = "";	
        this.highRiskNomineeInternalInd = "";
        this.highRiskDriverInternalInd = "";
    }
    //GA005 END

    initializeReferred() {
        if (this.isReferredRisk == "true")
            this.isReferredRiskUI = true;
        else
            this.isReferredRiskUI = false;
    }

    setReferred() {
        this.isReferredRisk = "false";
        this.isReferredRiskUI = false;
        let allRisks = BMSConstants.getRisks().getRisksByPriority();
        for (let risk of allRisks) {
            if (risk.riskClassification != null && risk.riskClassification == "Referred") {
                this.isReferredRisk = "true";
                this.isReferredRiskUI = true;
            }
        }
        if (this.isHeaderReferred == "Referred") {
            this.isReferredRisk = "true";
            this.isReferredRiskUI = true;
        }
    }

    setRIMethod() {
        this.isReferredToUW = "N";
        this.isReferredToHO = "N";

        if ((this.manuscript == "Y") && (BMSConstants.getBMSType() == BMSType.NewBusiness || BMSConstants.getBMSType() == BMSType.CoverNote)) {
            this.isReferredToUW = "Y";
            this.isReferredToHO = "Y";
        }

        if ((this.RIRequiredHeader == "Yes") && (BMSConstants.getBMSType() == BMSType.NewBusiness || BMSConstants.getBMSType() == BMSType.CoverNote || BMSConstants.getBMSType() == BMSType.Renewal)) {
            if (this.isReferredToUW == "N" && AppUtil.isEmpty(this.RIType, false) == false && this.RIType != 'TreatyAdjustment')
                this.isReferredToUW = "Y";
            if(this.RIType != 'TreatyAdjustment') // E1002    
            this.isReferredToHO = "Y";
        }
        //GA004 START
        if ((this.isReferredToUWMP == "Y") && (BMSConstants.getBMSType() == BMSType.NewBusiness || BMSConstants.getBMSType() == BMSType.CoverNote)) {
            this.isReferredToUW = "Y";
        }
        //GA004 END
    }

    setTargetSI(valObj: ProposalHeader, allRisks) {
        let bigSI = 0;
        let riRetn = "";
        let leastPreferred = [];
        let referredToUW:string;
        for (let risk of allRisks) {
            let csi = (risk.bigCapitalSumInsured != null) ? risk.bigCapitalSumInsured : risk.capitalSumInsured;
            if (risk.isLeastPreferred != null && risk.isLeastPreferred == 'Y') {
                let lpcsi = 0;
                if (leastPreferred[0] != null)
                    lpcsi = (leastPreferred[0].bigCapitalSumInsured != null) ? leastPreferred[0].bigCapitalSumInsured : leastPreferred[0].capitalSumInsured;
                if (leastPreferred[0] == null || (leastPreferred[0] != null && parseFloat("" + lpcsi) < parseFloat("" + csi))) {
                    leastPreferred[0] = risk;
                    if (risk.addRelatedCases != null && risk.addRelatedCases == "Y") {
                        let total = (parseFloat("" + csi) + parseFloat("" + risk.relatedSumInsured));
                        bigSI = total;
                    }
                    else {
                        bigSI = parseFloat("" + csi);
                    }
                    riRetn = risk.RIRetentionCode;
                }
            }
            else if (leastPreferred.length == 0) {
                if (risk.addRelatedCases != null && risk.addRelatedCases == "Y") {
                    let total = (parseFloat("" + csi) + parseFloat("" + risk.relatedSumInsured));
                    if (total > bigSI) {
                        bigSI = total;
                        riRetn = risk.RIRetentionCode;
                    }
                }
                else {
                    if (parseFloat("" + csi) > bigSI) {
                        bigSI = parseFloat("" + csi);
                        riRetn = risk.RIRetentionCode;
                    }
                }
            }
            referredToUW = risk.isReferredToUW;
        }
        valObj.targetSumInsured = this.getTSIByCI(bigSI);
        valObj.RIRetentionCode = riRetn;
        valObj.isReferredToUW = ( referredToUW != undefined && referredToUW != "" ) ? referredToUW : "N";
    }

    public getTSIByCI(sumInsured) {
        if (AppUtil.isEmpty(this.coInsuranceDetails, false) == false && this.coInsuranceDetails.ourShareindicator == "L") {
            let ourSharePercent = AppUtil.getRateNumber(this.coInsuranceDetails.ourSharePercentage);
            let finalSINoFormat = (ourSharePercent / 100) * sumInsured;
            return AppUtil.getSumInsuredNumber(finalSINoFormat);
        }
        else
            return sumInsured;
    }

    internalBLChange() {
        let change = "";
        if (this.blackListInternalIndicator == 'Y' && this.blackListIndicator != this.blackListIndicatorOld) {
            if (this.isReferredRisk == "true" && this.blackListIndicator == "false")
                change = "RF";
            else if (this.isReferredRisk == "false" && this.blackListIndicator == "true")
                change = "BL";
        }
        else if (this.blackListInternalIndicator == 'N' && this.blackListInternalIndicatorOld != "EMPTY")
            change = "BLR";

        return change;
    }

    amendInternalBL() {
        this.blackListIndicatorOld == this.blackListIndicator;
        if (this.blackListInternalIndicator == 'Y')
            this.blackListInternalIndicatorOld == this.blackListInternalIndicator;
        else
            this.blackListInternalIndicatorOld == "EMPTY";
    }

    setCaseId(caseId) {
        this.caseId = caseId;
    }

    public setPPTotal(allRisks) {
        let ppTotals = new AppUtil().getTotalByProperty("postedPremium", allRisks, AppUtil.getPremFormat());
        this.originalTotalPostedPremium = ppTotals.nonFormatted;
        this.totalPostedPremium = numeral(numeral(parseInt("" + this.stampDuty) + ppTotals.nonFormatted).format(AppUtil.getPremFormat())).value();
    }

    public setNetPostedPremTotal(total) {
        this.totalNetPostedPremium = total;
    }

    public setCDDLimits(data) {
        this.AMLCDDDefualtlimit = data.default;
        this.AMLCDDSupDoclimit = data.supportingDocuments;
    }
}

export class Reference {
    public reference: ReferenceDetails[] = [];
    public getInstance(valObj: Reference) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().handleArray(this, valObj, "reference");
        }
        return this;
    }
}



export class ReferenceDetails {
    public title: string = "";
    public referenceType: string = "";
    public referenceNumber: string;
    public issueDate: string;
    public receivedDate: string;
}

export class PeriodicDebitDetails {
    public payerNumber: string;
    public payerName: string;
    public bankBranchCode: string;
    public bankBranch: string;
    public bankBranchName: string;
    public bankAccountNumber: string;
    public accountSeqNumber: string;
    public merchantId: string;
    public creditcardType: string = "";
    public creditcardNumber: string;
    public creditcardExpiryMonth: string = "";
    public creditcardExpiryYear: string = "";
    public bankCode: string;
    public bankCodeName: string;
    public loanAccountNumber: string;
    public directDebitIndicator: string = "N";
    public campaign: string;
    public UOBSector: string = "";

    public getInstance(valObj: PeriodicDebitDetails) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
            return this;
        }
        else
            return null;
    }
}

//GA005 START
export class HighRiskIndReasons {
    public highRiskIndReason: HighRiskIndReason[] = [];

    public getInstance( valObj: HighRiskIndReason ) {
        if ( new AppUtil().isValidObj( valObj ) == true ) {
            new AppUtil().handleArray( this, valObj, "highRiskIndReason" );
        }
        return this;
    }

    public refreshItem( valObj: HighRiskIndReason ) {
        if ( new AppUtil().isValidObj( valObj ) == true ) {
            new AppUtil().handleArray( this, valObj, "highRiskIndReason" );
        }
        return this;
    }
}

export class HighRiskIndReason {
    public riskNumber: number = 0;
    public item_key: string;
    public item: string;
    public reason: string;
    public ind: string;
}
//GA005 END