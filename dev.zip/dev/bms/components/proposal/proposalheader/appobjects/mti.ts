import { AppUtil } from '../../../../../common/components/utility/apputil/app.util';

export class MTIItems {
    public totalMTIPercent: number = 0;
    public totalAmount: number = 0;
    public mtiItem: MTIItem[] = [];
    public getInstance(valObj: MTIItems) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
            new AppUtil().handleArray(this, valObj, "mtiItem");
        }
        return this;
    }

    public clearMTI() {
        this.totalMTIPercent = 0;
        this.totalAmount = 0;
        this.mtiItem = [];
    }
}

export class MTIItem {
    constructor(public invoiceTo?: string,
        public invoiceToName?: string,
        public sharePercent?: string,
        public amount?: string) {
        this.invoiceTo = "";
        this.invoiceToName = "";
        this.sharePercent = "";
        this.amount = "0";
    }

}