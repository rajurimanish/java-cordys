

import { AppUtil } from '../../../../../common/components/utility/apputil/app.util';

export class CcmOPSs{
    public language: string = "";
    public noOfHardCopy: string = "";
    public printQ: string = "";

    public ccmOPS: CcmOPS[] = [];

    public getInstance(valObj: CcmOPSs) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
            new AppUtil().handleArray(this, valObj, "CcmOPSs");
        }
        return this;
    }
}

export class CcmOPS {    
    public accountType: string;
    public emailExt: string;
    public ent: string;
    public longName: string;
    public printFlag: string;
    public emailFlag: string;
    public recipientEmail: string;
    

    constructor() {         
        this.accountType = "";
        this.emailExt = "";
        this.ent = "";
        this.longName = "";
        this.printFlag = "";
        this.emailFlag = "";
        this.recipientEmail = "";
        
    }

    public getInstance(valObj: CcmOPS) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().handleArray(this, valObj, "CcmOPS");
        }
        return valObj;
    }
}
