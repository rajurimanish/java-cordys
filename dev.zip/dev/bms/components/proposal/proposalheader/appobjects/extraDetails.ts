
import { TurnAroundTime } from './turnAroundTime';
import { MTIItems } from './mti';
import { AppUtil } from '../../../../../common/components/utility/apputil/app.util';
import { COInsurance } from "../../../../../common/components/coinsurance/appobjects/coinsurance";
import { BMSConstants } from '../../../common/constants/bms_constants';
import { BMSType } from '../../../common/constants/bms_types';

declare var numeral: any;
declare var moment: any;
export class ExtraDetails {
    public payor: string;
    public pName: string;
    public pNRIC: string;
    public pPassportNo: string;
    public bankerID: string;
    public bankerName: string;
    public bankerNRIC: string;
    public branchCode: string;
    public bankName: string;
    public bankAbbr: string;
    public region: string;
    public channel: string;
    public aHname: string;
    public aHPC: string;
    public edRef: string;

    constructor() {
        this.payor = "";
        this.pName = "";
        this.pNRIC = "";
        this.pPassportNo = "";
        this.bankerID = "";
        this.bankerName = "";
        this.bankerNRIC = "";
        this.branchCode = "";
        this.bankName = "";
        this.bankAbbr = "";
        this.region = "";
        this.channel = "";
        this.aHname = "";
        this.aHPC = "";
        this.edRef = "";
    }

    public getInstance(valObj: ExtraDetails) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().handleArray(this, valObj, "ExtraDetails");
        }
        return valObj;
    }
}
