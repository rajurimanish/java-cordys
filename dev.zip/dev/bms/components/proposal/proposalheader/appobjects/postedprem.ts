/*
Change History	:

	No      Date          Description                               					    Changed By
	====    ==========    ===========                              						    ==========						 
					  								   
    KA001  18/10/2018    MYS-2018-0896    -  To save Premium Details	               		  DKA
    MR001  07/05/2019    MYS-2019-0526    - Adding the validation Inception Date and          MRA1
                                            End Date for Cover Note in BMS 
*  GA001    11/09/2019      MYS-2019-0974 - BMS Enhancement on High Risk Vehicle & Client      KGA
*/
import { AppUtil } from '../../../../../common/components/utility/apputil/app.util';
import { BMSConstants } from '../../../common/constants/bms_constants';
import { BMSUtilService } from "../../../../services/bms.util.service"; //SST code
import { BMSType } from '../../../common/constants/bms_types';
//GA001 START
import { HighRiskIndReason } from './proposalheader';
import { CordysSoapWService } from '../../../../../common/components/utility/cordys-soap-ws';
import { GetLOVData } from '../../../../../common/components/utility/search/search.requests';
//GA001 END

declare var numeral: any;
declare var moment: any;

export class PostedPrem {
    public ratingFlag = "A";
    public minimumPremium = 0;
    public basicPremAnnual = 0;
    public basicPremPOI = 0;
    public basicPremPOIAdj = 0;
    public rebatePercent = 0;
    public rebateAmount = 0;
    public commissionPercentage = 0;
    public commissionAmount = 0;
    public netPrem = 0;
    public gstPercent = 0;
    public gstAmount = 0;
    public totalPrem = 0;
    private bmsType: BMSType;//MRA001
    public sstPercent = 0; // SST code
    public sstAmount = 0; // SST code
    public isGSTApplicable: boolean;//SST Code
    public refresh( valObj: PostedPrem ) {
        if ( new AppUtil().isValidObj( valObj ) == true ) {
            new AppUtil().setFieldValueByType( this, valObj );
        }
    }

    public hasMinPremCalc( riskObj: any ) {
		/*let calcFlag = "N";
		let riskCount = BMSConstants.getRisks().getRisksCount();
		let minimumPremium = AppUtil.getPremiumNumber(riskObj.minimumPremium);
		// Added below code for SAF MYS-2017-1108 -- start
		let lineOfBusiness = BMSConstants.getBMSCaseInfo().lineOfBusiness;
		if (lineOfBusiness != "PA" && riskCount > 1)				
		//if(riskCount > 1 || minimumPremium == 0) // End
			calcFlag = "N"
		else
			calcFlag = "Y";
		return calcFlag;*/
        return "Y";  // MYS-2018-0896  commented above code
    }

    public getPostedPremDetails( riskObj: any, adjustedVal ) {
        let postedPrem = new PostedPrem();
        //SST Code
        //MRA001 changes starts
        let headerInfo = BMSConstants.getBMSHeaderInfo();
        this.bmsType = BMSConstants.getBMSType();
        if ( ( this.bmsType == BMSType.CoverNote ) && ( headerInfo.effectiveDate == null || headerInfo.effectiveDate == undefined || headerInfo.effectiveDate == '' ) && ( headerInfo.endDate == null || headerInfo.endDate == undefined || headerInfo.endDate == '' ) && ( riskObj.isVPMS == 'N' ) && ( riskObj.isPOIConsidered == "N" ) ) {
            return postedPrem;
        }
        //MRA001 changes ends

        if ( moment( headerInfo.effectiveDate, "YYYY-MM-DD" ).format( "YYYYMMDD" ) >= moment( headerInfo.SSTLiveDate, "YYYY-MM-DD" ).format( "YYYYMMDD" ) || headerInfo.SSTLiveDate == "" ) {
            postedPrem.isGSTApplicable = false;
        } else {
            postedPrem.isGSTApplicable = true;
        }
        riskObj.SST = Number( riskObj.SST );
        riskObj.GST = Number( riskObj.GST );
        postedPrem.sstPercent = Number( riskObj.SST );
        postedPrem.gstPercent = Number( riskObj.GST );
        //End

        postedPrem.ratingFlag = riskObj.ratingFlag;
        postedPrem.minimumPremium = AppUtil.getPremiumNumber( riskObj.minimumPremium );
        postedPrem.basicPremAnnual = AppUtil.getPremiumNumber( riskObj.originalTotalPremium );
        postedPrem.basicPremPOI = this.getPremForPOI( postedPrem.basicPremAnnual, riskObj );
        postedPrem.basicPremPOIAdj = this.getAdjVal( postedPrem.basicPremPOI, postedPrem.ratingFlag, postedPrem.minimumPremium, adjustedVal, riskObj );
        postedPrem.rebatePercent = this.getRebatePercent( riskObj );
        postedPrem.rebateAmount = this.getRebateAmount( riskObj, postedPrem );
        postedPrem.netPrem = this.getNetPrem( riskObj, postedPrem );
        postedPrem.gstPercent = this.getGSTPercent( riskObj );
        postedPrem.gstAmount = this.getGSTAmount( riskObj, postedPrem );
        postedPrem.sstPercent = Number( this.getSSTPercent( riskObj ) );//SST Code
        postedPrem.sstAmount = this.getSSTAmount( riskObj, postedPrem );//SST Code
        postedPrem.totalPrem = this.getTotalPrem( riskObj, postedPrem );
        this.fillCommissionInfo( riskObj, postedPrem );
        //GA001
        if ( BMSConstants.getBMSCaseInfo().businessFunction == "Renewal" || BMSConstants.getBMSCaseInfo().businessFunction == "Renewal Rerate" ) {
            this.calLossRatio( postedPrem );
        }//End       
        return postedPrem;
    }

    public getPremForPOI( premium, riskObj ) {
        if ( "Y" == riskObj.isVPMS ) {
            let premObj = riskObj.premiumInfo.getPostedPremiumObj( riskObj.premiumCalculator );
            return AppUtil.getPremiumNumber( premObj.grossPremium );
        }
        else {
            if ( "N" == riskObj.isPOIConsidered ) {
                let headerInfo = BMSConstants.getBMSHeaderInfo();
                return AppUtil.getPremForPOI( premium, headerInfo.effectiveDate, headerInfo.endDate );
            }
            else
                return premium;
        }
    }

    public getAdjVal( basicPremPOI, ratingFlag, minimumPremium, adjustedVal, riskObj ) {
        let riskCount = BMSConstants.getRisks().getRisksCount();
		/*if(this.hasMinPremCalc(riskObj) == "N" ){  //MYS-2018-0896 
			return basicPremPOI;			
		}
		else{*/
        let lineOfBusiness = BMSConstants.getBMSCaseInfo().lineOfBusiness; // //MYS-2018-0896 
        if ( riskCount > 1 && lineOfBusiness != 'PA' ) {
            minimumPremium = 0;
        }
        if ( ratingFlag == null || ratingFlag == "" || ratingFlag == "A" )
            return ( minimumPremium > basicPremPOI ) ? minimumPremium : basicPremPOI;
        else {
            if ( adjustedVal == 0 )
                return ( minimumPremium > basicPremPOI ) ? minimumPremium : basicPremPOI;
            else
                return adjustedVal;
        }

    }

    public getRebatePercent( riskObj ) {
        if ( AppUtil.isEmpty( riskObj.isVPMS, true ) || riskObj.isVPMS == "N" || riskObj.premiumInfoFlag == "N" )
            return AppUtil.getRateNumber( riskObj.rebate );
        else {
            let rateObj = riskObj.premiumInfo.getPostedPremiumObj( riskObj.premiumCalculator );
            return AppUtil.getRateNumber( rateObj.directDiscountRate );
        }
    }

    public getRebateAmount( riskObj, postedPrem ) {
        if ( AppUtil.isEmpty( riskObj.isVPMS, true ) || riskObj.isVPMS == "N" || riskObj.premiumInfoFlag == "N" ) {
            let rebateNF = ( postedPrem.basicPremPOIAdj * postedPrem.rebatePercent ) / 100;
            return AppUtil.decFormatNoRound( rebateNF, AppUtil.getPremFormat() );
        }
        else {
            let rateObj = riskObj.premiumInfo.getPostedPremiumObj( riskObj.premiumCalculator );
            return AppUtil.getPremiumNumber( rateObj.directDiscountAmount );
        }
    }

    public fillCommissionInfo( riskObj, postedPrem ) {
        if ( AppUtil.isEmpty( riskObj.isVPMS, false ) == false && riskObj.isVPMS == "Y" ) {
            let rateObj = riskObj.premiumInfo.getPostedPremiumObj( riskObj.premiumCalculator );
            postedPrem.commissionPercentage = AppUtil.getRateNumber( rateObj.commissionPercentage );
            postedPrem.commissionAmount = AppUtil.getPremiumNumber( rateObj.commissionAmount );
        }
    }

    public getNetPrem( riskObj, postedPrem ) {
        //if(AppUtil.isEmpty(riskObj.isVPMS, true) || riskObj.isVPMS == "N" || riskObj.premiumInfoFlag == "N")
        return postedPrem.basicPremPOIAdj - postedPrem.rebateAmount;
        //else{
        //let premObj = riskObj.premiumInfo.getPostedPremiumObj(riskObj.premiumCalculator);
        //return AppUtil.getPremiumNumber(premObj.netPremium);
        //}
    }

    public getGSTPercent( riskObj ) {
        let headerInfo = BMSConstants.getBMSHeaderInfo();
        riskObj.GST = ( riskObj.GST == 0 ) ? headerInfo.GSTTaxRate : riskObj.GST;
        if ( AppUtil.isEmpty( riskObj.isVPMS, true ) || riskObj.isVPMS == "N" || riskObj.premiumInfoFlag == "N" ) {
            let gstVal = parseInt( riskObj.GST );
            if ( isNaN( gstVal ) )
                return 0;
            else
                return gstVal;
        }
        else {
            let premObj = riskObj.premiumInfo.getPostedPremiumObj( riskObj.premiumCalculator );
            let gstVal = parseInt( premObj.gstPercentage );
            if ( isNaN( gstVal ) )
                return 0;
            else
                return gstVal;
        }
    }

    public getGSTAmount( riskObj, postedPrem ) {
        let headerInfo = BMSConstants.getBMSHeaderInfo();
        postedPrem.gstPercent = ( postedPrem.gstPercent == 0 ) ? Number( headerInfo.GSTTaxRate ) : Number( postedPrem.gstPercent );
        if ( AppUtil.isEmpty( riskObj.isVPMS, true ) || riskObj.isVPMS == "N" || riskObj.premiumInfoFlag == "N" ) {
            let amt = ( postedPrem.gstPercent > 0 ) ? Number( ( postedPrem.gstPercent / 100 ) * postedPrem.netPrem ) : 0; //SAF MYS-2018-0629
            if ( postedPrem.gstPercent > 0 ) {
                amt = BMSUtilService.calculatePremiumAmount( amt, "G" ); // SST code
            }
            return amt;
        }
        else {
            let premObj = riskObj.premiumInfo.getPostedPremiumObj( riskObj.premiumCalculator );
            return AppUtil.getPremiumNumber( premObj.gstPremium );
        }
    }

    public getTotalPrem( riskObj, postedPrem ) {
        if ( AppUtil.isEmpty( riskObj.isVPMS, true ) || riskObj.isVPMS == "N" || riskObj.premiumInfoFlag == "N" )
            return postedPrem.netPrem + postedPrem.gstAmount + postedPrem.sstAmount;
        else {
            let premObj = riskObj.premiumInfo.getPostedPremiumObj( riskObj.premiumCalculator );
            return AppUtil.getPremiumNumber( premObj.totalPremium );
        }
    }

    //SST Code
    public getSSTPercent( riskObj ) {
        let headerInfo = BMSConstants.getBMSHeaderInfo();
        riskObj.SST = ( riskObj.SST == 0 ) ? Number( headerInfo.SSTTaxRate ) : Number( riskObj.SST );
        if ( AppUtil.isEmpty( riskObj.isVPMS, true ) || riskObj.isVPMS == "N" || riskObj.premiumInfoFlag == "N" ) {
            let gstVal = parseInt( riskObj.SST );
            if ( isNaN( gstVal ) )
                return 0;
            else
                return gstVal;
        }
        else {
            let premObj = riskObj.premiumInfo.getPostedPremiumObj( riskObj.premiumCalculator );
            let gstVal = parseInt( premObj.sstPercentage );
            if ( isNaN( gstVal ) )
                return 0;
            else
                return gstVal;
        }
    }

    public getSSTAmount( riskObj, postedPrem ) {
        let headerInfo = BMSConstants.getBMSHeaderInfo();
        postedPrem.sstPercent = ( postedPrem.sstPercent == 0 ) ? Number( headerInfo.SSTTaxRate ) : Number( postedPrem.sstPercent );
        if ( AppUtil.isEmpty( riskObj.isVPMS, true ) || riskObj.isVPMS == "N" || riskObj.premiumInfoFlag == "N" ) {
            //let amt = (postedPrem.sstPercent > 0)?Number( (postedPrem.sstPercent/100) * postedPrem.netPrem ):0; //SAF MYS-2018-0629
            let amt = ( postedPrem.sstPercent > 0 ) ? numeral( numeral( ( postedPrem.netPrem * parseInt( "" + postedPrem.sstPercent ) ) / 100 ).format( "0,00.00" ) ).value() : 0;
            if ( "MAR" == headerInfo.lineOfBusiness ) {
                amt = numeral( numeral( amt ).format( "0,00.00" ) ).value();
            } else if ( "CAR" == headerInfo.contractType || "EAR" == headerInfo.contractType ) {
                let contractFrm = ( headerInfo.contractType == 'CAR' ) ? riskObj.contractPeriodFrom : riskObj.erectPeriodFrom;
                let contractTo = ( headerInfo.contractType == 'CAR' ) ? riskObj.contractPeriodTo : riskObj.erectPeriodTo;
                amt = numeral( numeral( BMSUtilService.calculatePremiumAmt( amt, "S", moment( contractFrm, "YYYY-MM-DD" ).format( "YYYYMMDD" ), moment( contractTo, "YYYY-MM-DD" ).format( "YYYYMMDD" ) ) ).format( "0,00.00" ) ).value();
            } else if ( "WC" == headerInfo.contractType || "EL" == headerInfo.contractType ) {
                amt = numeral( numeral( BMSUtilService.calculatePremiumAmt( amt, "S", moment( riskObj.contractDetails.contractPeriodFrom, "YYYY-MM-DD" ).format( "YYYYMMDD" ), moment( riskObj.contractDetails.contractPeriodTo, "YYYY-MM-DD" ).format( "YYYYMMDD" ) ) ).format( "0,00.00" ) ).value();
            } else {
                amt = numeral( numeral( BMSUtilService.calculatePremiumAmount( amt, "S" ) ).format( "0,00.00" ) ).value();
            }
            return amt;
        }
        else {
            let premObj = riskObj.premiumInfo.getPostedPremiumObj( riskObj.premiumCalculator );
            return AppUtil.getPremiumNumber( premObj.sstPremium );
        }
    }
    //End
    //GA001 START
    public calLossRatio( postedPrem: PostedPrem ) {
        let headerInfo = BMSConstants.getBMSHeaderInfo();
        let basicPrem = numeral( postedPrem.basicPremAnnual ).value();
        let lossRatio = ( numeral( headerInfo.totalClaimIncurred ).value() / basicPrem ) * 100;
        BMSConstants.getBMSHeaderInfo().lossRatio = lossRatio;

        if ( headerInfo.countNWDClaims > 2 ) {
            let item_key = "";
            let item = "";
            let reason = "";
            let highRiskIndReason: HighRiskIndReason;
            if ( BMSConstants.getBMSCaseInfo().lineOfBusiness == "MTR" ) {
                let removeIndex = -1;
                removeIndex = headerInfo.highRiskIndicatorReasons.highRiskIndReason.map( function ( item ) { return item.item_key; } ).indexOf( "NWD_HRV" );
                if ( removeIndex >= 0 ) {
                    BMSConstants.getBMSHeaderInfo().highRiskIndicatorReasons.highRiskIndReason.splice( removeIndex, 1 );
                }

                let removeIndex1 = -1;
                removeIndex1 = headerInfo.highRiskIndicatorReasons.highRiskIndReason.map( function ( item ) { return item.item_key; } ).indexOf( "NWD_HRC" );
                if ( removeIndex1 >= 0 ) {
                    BMSConstants.getBMSHeaderInfo().highRiskIndicatorReasons.highRiskIndReason.splice( removeIndex1, 1 );
                }
                if ( headerInfo.lossRatio > 80 ) {

                    //Get Reasons from T9201
                    let reasonHRC = "";
                    let indHRC = "";
                    let reasonHRV = "";
                    let indHRV = "";
                    let tempRespObj2 = BMSUtilService.getHighRiskReasons();
                    if ( tempRespObj2 != undefined ) {
                        //NWD_HRV
                        let reasonObj = tempRespObj2.find( ( item ) => ( item.old.T9201.REASON_CODE == "HRSV002" ) );
                        if ( reasonObj != undefined && reasonObj.old != undefined && reasonObj.old.T9201 != undefined ) {
                            reasonHRV = reasonObj.old.T9201.REASON_DESC;
                            indHRV = reasonObj.old.T9201.IND;
                        }

                        //NWD_HRC
                        let reasonObj1 = tempRespObj2.find( ( item ) => ( item.old.T9201.REASON_CODE == "HRSC006" ) );
                        if ( reasonObj1 != undefined && reasonObj1.old != undefined && reasonObj1.old.T9201 != undefined ) {
                            reasonHRC = reasonObj1.old.T9201.REASON_DESC;
                            indHRC = reasonObj1.old.T9201.IND;
                        }
                    }

                    BMSConstants.getBMSHeaderInfo().highRiskIndicator = "true";
                    BMSConstants.getBMSHeaderInfo().highRiskIndicatorUI = true;
                    BMSConstants.getBMSHeaderInfo().highRiskLossRatioIndicator = indHRV;
                    //HRV
                    item_key = "NWD_HRV";
                    item = "Non WD High Risk Vehicle";
                    //reason = ">2 Claims & L/Ratio>80% (PPOI)";
                    highRiskIndReason = new HighRiskIndReason();
                    highRiskIndReason.riskNumber = 0;
                    highRiskIndReason.item_key = item_key;
                    highRiskIndReason.item = item;
                    highRiskIndReason.reason = reasonHRV;
                    highRiskIndReason.ind = indHRV;
                    BMSConstants.getBMSHeaderInfo().highRiskIndicatorReasons.highRiskIndReason.push( highRiskIndReason );

                    //HRC
                    item_key = "NWD_HRC";
                    item = "Non WD High Risk Client";
                    //reason = ">2 Claims & L/Ratio>80% (Mtr)";
                    highRiskIndReason = new HighRiskIndReason();
                    highRiskIndReason.riskNumber = 0;
                    highRiskIndReason.item_key = item_key;
                    highRiskIndReason.item = item;
                    highRiskIndReason.reason = reasonHRC;
                    highRiskIndReason.ind = indHRC;
                    BMSConstants.getBMSHeaderInfo().highRiskIndicatorReasons.highRiskIndReason.push( highRiskIndReason );

                }
            } else {
                let removeIndex = -1;
                removeIndex = headerInfo.highRiskIndicatorReasons.highRiskIndReason.map( function ( item ) { return item.item_key; } ).indexOf( "NMotor_HRC" );
                if ( removeIndex >= 0 ) {
                    BMSConstants.getBMSHeaderInfo().highRiskIndicatorReasons.highRiskIndReason.splice( removeIndex, 1 );
                }
                if ( headerInfo.lossRatio > 100 ) {

                    //Get Reasons from T9201
                    let reasonHRC = "";
                    let indHRC = "";
                    let tempRespObj2 = BMSUtilService.getHighRiskReasons();
                    if ( tempRespObj2 != undefined ) {
                        //NWD_HRC
                        let reasonObj1 = tempRespObj2.find( ( item ) => ( item.old.T9201.REASON_CODE == "HRSC002" ) );
                        if ( reasonObj1 != undefined && reasonObj1.old != undefined && reasonObj1.old.T9201 != undefined ) {
                            reasonHRC = reasonObj1.old.T9201.REASON_DESC;
                            indHRC = reasonObj1.old.T9201.IND;
                        }
                    }
                    //HRC
                    BMSConstants.getBMSHeaderInfo().highRiskIndicator = "true";
                    BMSConstants.getBMSHeaderInfo().highRiskIndicatorUI = true;
                    BMSConstants.getBMSHeaderInfo().highRiskLossRatioIndicator = indHRC;

                    item_key = "NMotor_HRC";
                    item = "Non Motor High Risk Client";
                    //reason = ">2 Claims & L/Ratio>100% (NM)";
                    highRiskIndReason = new HighRiskIndReason();
                    highRiskIndReason.riskNumber = 0;
                    highRiskIndReason.item_key = item_key;
                    highRiskIndReason.item = item;
                    highRiskIndReason.reason = reasonHRC;
                    highRiskIndReason.ind = indHRC;
                    BMSConstants.getBMSHeaderInfo().highRiskIndicatorReasons.highRiskIndReason.push( highRiskIndReason );
                }
            }
        }
    }
    //GA001 END
}