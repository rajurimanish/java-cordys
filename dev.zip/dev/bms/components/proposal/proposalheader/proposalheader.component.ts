/*
 *
 *  Change History	:
 *  No      Date            Description                               					    Changed By
 *  ====    ==========      ===========                                                     ==========
 * MD001    28/02/2017       MYS-2018-0068 - HD Log: Product field shows as duplicates
 *                          in BMS,Added ProductList as a Form fieldname                        MKU1
 * 
 * GA001    15/03/2018      MYS-2018-0266 : Enhancement on Travelright Plus (TAA & TDA)         KGA
 * 
 * KA001	14/08/2018      MYS-2018-0582    -  To auto populate Rebate 	               		DKA
 * 
 * VK001	28/09/2018      MYS-2018-1026 : Security Fix                                        VKR
 * 
 * VK002	29/10/2018      Redmine Ticket#2033												  	VKR
 * 
 * E1001	26/10/2018    	MYS-2018-0511 - Campaign code validation in p400                    SRE1
 * 
 * VK003    12/11/2018      SAF-2018-1105 : Marine Open Cover									VKR
 * 
 * E1002    06/12/2018      MYS-2018-1163 : Enhancement on Travel products                      SRE1
 * 
 * GA002    29/01/2019		MYS-2019-0109 - HD Log  Leap Year issue in BMS System				KGA
 * 
 * E1005    11/04/2019      MYS-2018-1348 : Prospect to client conversion issue                 SRE1
 * 
 * VK006   25/03/2019		MYS-2019-0164 - MMP Product Configuration							VKR
 * GA003    26/04/2019		MYS-2018-0539 - Agent Termination Date was not updated in 
 *                          Periodic Debit information in BMS									KGA
 * 
 * GA004    14/05/2019      MYS-2019-0609 - HD Log: Incorrect selection of BLACK LIST 
 *                          INDICATOR for valid clients in BMS                                  KGA
 * 
 * KA0002   28/06/2019      MYS-2018-0878 - FHI Product for only renewals                       DKA
 *
 * E1003    30/05/2019      MYS-2019-0515 : Allow user to amend Expiry Date upon renewal        SRE1
 * 
 * KU001    30/05/2019      MYS-2019-0520 : New Vehicle class PF                                DKU
 *  E1009   01/07/2019      MYS-2019-0656 - Max Rebate value for MPD product on loading of risk 
 *                                      was override                                             SRE1 
 * MS001    26/07/2019		MYS-2019-0729 - MMF Product Configuration							MSU
 * GA005    11/09/2019      MYS-2019-0974 - BMS Enhancement on High Risk Vehicle & Client       KGA
 * E1003    23/09/2019       MYS-2019-0675 Document Validation for Co-outwards                  SRE1
 *                         case before sending to PPHO		
*/
import { Component, OnInit, ComponentRef, ViewContainerRef, EventEmitter, AfterViewInit, ViewChild } from '@angular/core';
import { SearchInput } from '../../../../common/components/utility/search/genericsearch';
import { CustomDCLService, DCLInput } from '../../../../common/services/customdcl.service';
import { BMSObject } from '../../common/appobjects/bmsobject';
import { ProposalHeader, HighRiskIndReason, HighRiskIndReasons } from './appobjects/proposalheader';//GA005
import { ClientDetails } from '../../../../common/components/client/appobjects/client';
import { CaseInfo } from '../../../../common/components/appobjects/caseinfo';
import { BancaComponent } from './uimodules/banca.component';
import { CordysSoapWService } from "../../../../common/components/utility/cordys-soap-ws";
import { LOV_Field, LOVDropDownService, SearchFilter } from "../../../../common/services/lovdropdown/lovdropdown.service";
import { GetLOVData, SearchAdvancedConfig, Filter } from '../../../../common/components/utility/search/search.requests';
import { RisksValidator } from '../validation/risks.validator';
import { ApplicationUtilService } from '../../../../common/services/application.util.service';
import { AlertMessagesService } from '../../../../common/components/utility/alertmessage/alertmessages.service';
import { AlertMessage } from '../../../../common/components/utility/alertmessage/alertmessages.model';
import { AppUtil } from '../../../../common/components/utility/apputil/app.util';
import { MTIItems } from './appobjects/mti';
import { ModalInput } from "../../../../common/components/utility/modal/modal";
import { BMSConstants } from '../../common/constants/bms_constants';
import { BMSType } from '../../common/constants/bms_types';
import { BMSAppObjService } from '../../../services/bmsappobj.service';
import { BMSLOVRequest } from '../../common/service/lov/bms.lovrequest';
import { BancaService } from './service/banca.service';
import { CoinsuranceService } from './service/coi.service';
import { RiskTableService } from './service/riskTable.service';
import { ExtraDetails } from './appobjects/extraDetails';
import { RiskClassificationService } from '../newbusinessrisks/services/riskcls.service';
import { BMSUtilService } from "../../../services/bms.util.service";
import { ActivatedRoute } from '@angular/router';
import { RiskArray } from './uimodules/riskArray'; //E1003
import { CcmOPSs } from './appobjects/ccmOPS';

declare var jQuery: any;
declare var moment: any;

@Component({
    selector: 'proposal-header',
    templateUrl: 'app/bms/components/proposal/proposalheader/proposalheader.template.html',
    inputs: ['proposal', 'proposalHeader', 'caseInfo'],
    outputs: ['onproductchange', 'oninsuredchange', 'onpoichange']
})
export class ProposalHeaderComponent implements OnInit {

    public proposal: BMSObject;
    public proposalHeader: ProposalHeader;
    public caseInfo: CaseInfo;
    private isCollapsedMode: boolean = false;
    private collapseAddlInfo: boolean = false;
    private collapseBancalInfo: boolean = false;
    private isReferredRiskUI: boolean = false;
    private channelConflictIndicatorUI: boolean = false;
    private duplicateIndicatorUI: boolean = false;
    onproductchange = new EventEmitter<string>();
    oninsuredchange = new EventEmitter<string>();
    onpoichange = new EventEmitter<string>();
    private ahList: AHInfo[] = [];
    private payPlanList: PayPlanInfo[] = [];
    private rnlTypeList: RenewalTypeInfo[] = [];
    private notificationTypeList: NotificatTypeInfo[] = [];
    public insuredDOB: string = "";
    private endDateCtrl: any;
    private startDateCtrl: any;
    private productCtrl: any;
    public disableForm = 'N';
    public disableDocReceivedDate = 'N';
    public poiDisable = 'N';
    public insuredPersonType: string = '';
    public inceptionDateChanged: boolean = false;
    public entDateChanged: boolean = false;
    public thiscomp: any;
    private orgDN: string;
    private notifDisplayed: boolean = false;
    private loggedInUser: string = "";
    public uobSectorList = [{ code: "CS", description: "Consumer Loan" }, { code: "MR", description: "Retail Loan" }, { code: "MM", description: "Middle Market Loan" }, { code: "MC", description: "Large Corporation" }, { code: "ML", description: "Listed Corporations" }, { code: "MB", description: "Bumi Development Unit" }, { code: "IP", description: "Corporate Banking" }, { code: "IS", description: "Specialised Financing" }, { code: "CM", description: "Business Banking" }, { code: "CV", description: "Privilege Banking" }]
    public isRerate: boolean = false;
    public isRerateOnly: boolean = false;
    public isRerateCSE: boolean = false;
    public checkBoxRef: any;
    public isITUW: string = "N";
    public disableManuscript: boolean = false;
    public isRIMethodEditable: string = 'Y';
    public isAgentEditMode;
    public isBancaBranch: boolean = false;
    public bancaBranch: string;
    public isQuotationCompleted: string = "N";
    public tempObj: any;
    public disabledSimplfied: string = 'N';
    public isRerateED: boolean = false; //E1003
    @ViewChild(BancaComponent) private bancaComp: BancaComponent;
    @ViewChild('proposalHeaderModal', { read: ViewContainerRef }) contentArea: ViewContainerRef;
    public isProductChanged: boolean = false;
    constructor(public dcl: CustomDCLService, private _cordysService: CordysSoapWService, private lovDropDownService: LOVDropDownService, private _aus: ApplicationUtilService, public _alertMsgService: AlertMessagesService, private _appObjService: BMSAppObjService, private _bancaService: BancaService, private _coiService: CoinsuranceService, private _rtService: RiskTableService, private _rcls: RiskClassificationService, public _bus: BMSUtilService, private _activatedRoute: ActivatedRoute) { }

    // KU001 Start
    public OldAgentType: boolean = false;
    public NewAgentType: boolean = false;
    // KU001 End

    ngOnInit() {
        this.handleIndicatorCheckBox();
        this.handleRenewal();
        this.handlePOIForCoverNote();
        this.setTempObj();
        this.populateLovs();
        //AL001 START
        //this.getAccountHandler(this,true);
        this.getAccountHandlerByBranchAndApplication(this, true);
        //AL001 END
        if (this.proposal.newBusiness.clientDetails && this.proposalHeader.effectiveDate && this.proposalHeader.endDate && this.proposalHeader.contractType) {
            this.notifDisplayed = false;
            this.checkChannelConflict();
        }
        this.setPayPlan(false);
        this.setInsuredPersonType(this.proposal.newBusiness.clientDetails);
        this.setRenewalType();
        if (AppUtil.isEmpty(this.proposalHeader.renewalType, false) == false)
            this.setNotificationType();
        this.thiscomp = this;
        if (this.caseInfo.businessFunction == "Renewal") {
            this._aus.getOrgDn().subscribe((data) => this.getOrgDn(data, this));
        }

        //this.resetRTInfo();
        this.handleManuScriptFld();
        this.setAgentEditMode();
        this.setRRType();
        if (this.proposalHeader.extraDetails == undefined) {
            this.proposalHeader.extraDetails = new ExtraDetails();
        }
        this.setQuotationCompleted();

        //SST code
        let tempRespObj = this._bus.getLiveDate();
        if (tempRespObj != undefined && tempRespObj != "") {
            this.proposalHeader.GSTLiveDate = tempRespObj[0].old.ITEMPF.LIVEDATE;
            this.proposalHeader.SSTLiveDate = tempRespObj[1].old.ITEMPF.LIVEDATE;
        }
        //End
        if ((["MyTasks", "MyDrafts"].indexOf(this._activatedRoute.snapshot.params['component']) >= 0 || Object.keys(this._activatedRoute.snapshot.params).length == 0)) {
            this.checkBancaInfo(false);//GA003
        }
        //Added below condition for SAF MYS-2019-0490 to disable complete form.
		/* if (["Quotation", "Policy Processing", "P400 In forced", "Appeal to BU SMT", "Appeal Approved", "Appeal Approved by HM", "RFI"].indexOf(this.caseInfo.status) >= 0) {
			jQuery("#bmsProposalHeaderForm").prop("disabled", true);
			this.setFormDisabled(true);
        } */

        //KU001 Start
        this.checkOldAgentType()
        //KU001 end
        //GA005 START
        let initiatedOnDt: string = this.caseInfo.initiatedOn;
        if (initiatedOnDt == undefined || initiatedOnDt == null || initiatedOnDt == "") {
            initiatedOnDt = moment.utc(new Date()).format();
            initiatedOnDt = initiatedOnDt.substring(0, initiatedOnDt.length - 1);
        }

        let tempRespObj1 = this._bus.getHighRiskLiveDt();
        this.proposalHeader.highRiskLiveDate = "";
        if (tempRespObj1 != undefined) {
            this.proposalHeader.highRiskLiveDate = tempRespObj1.old.T7031.HRLIVDT;
        }

        if (this.proposalHeader.highRiskLiveDate != "" && moment.utc(initiatedOnDt).format("YYYYMMDD") >=
            moment(this.proposalHeader.highRiskLiveDate, "YYYY-MM-DD").format("YYYYMMDD")) {
            this.proposalHeader.isHighRiskApplicable = true;
        } else {
            this.proposalHeader.isHighRiskApplicable = false;
        }

        if (this.proposalHeader.isHighRiskApplicable && this.caseInfo.businessFunction == "Renewal" || this.caseInfo.businessFunction == "Renewal Rerate") {
            let removeIndex = -1;
            if (this.proposalHeader.highRiskIndicatorReasons.highRiskIndReason != undefined) {
                removeIndex = this.proposalHeader.highRiskIndicatorReasons.highRiskIndReason.map(function (item) { return item.item_key; }).indexOf("WD_HRV");
            }
            if (removeIndex >= 0) {
                this.proposalHeader.highRiskIndicatorReasons.highRiskIndReason.splice(removeIndex, 1);
            }

            if ((this.proposalHeader.isWDHRV == "Y" || this.proposalHeader.isWDHRV == "Z") && removeIndex < 0) {
                
                //Get Reasons from T9201
                let reasonWD = "";
                let indWD = "";
                let resonCodeVal = "";
                if(this.proposalHeader.isWDHRV == "Y"){
                    resonCodeVal = "HRSV003";
                }else if(this.proposalHeader.isWDHRV == "Z"){
                    resonCodeVal = "HRSV004";
                }
                let tempRespObj2 = BMSUtilService.getHighRiskReasons();
                if (tempRespObj2 != undefined) {
                    let reasonObj = tempRespObj2.find((item) => (item.old.T9201.REASON_CODE == resonCodeVal));
                    if(reasonObj!=undefined && reasonObj.old!=undefined && reasonObj.old.T9201!=undefined){
                        reasonWD = reasonObj.old.T9201.REASON_DESC;
                        indWD = reasonObj.old.T9201.IND;
                    }
                }

                this.proposalHeader.highRiskIndicator = "true";
                this.proposalHeader.highRiskIndicatorUI = true;
                this.proposalHeader.highRiskLossRatioWDInd = indWD;

                let item_key = "WD_HRV";
                let item = "WD High Risk Vehicle";
                //let reason = ">2WD Claims for 2 cons years";
                let highRiskIndReason: HighRiskIndReason = new HighRiskIndReason();
                highRiskIndReason.riskNumber = 0;
                highRiskIndReason.item_key = item_key;
                highRiskIndReason.item = item;
                //highRiskIndReason.reason = reason;
                //highRiskIndReason.ind = "B";
                highRiskIndReason.reason = reasonWD;
                highRiskIndReason.ind = indWD;
                this.proposalHeader.highRiskIndicatorReasons.highRiskIndReason.push(highRiskIndReason);
            }
        }
        //GA005 END
        
        this.setCCMOpsScreen();//pku

    }

    setTempObj() {
        this.tempObj = BMSConstants.getTempObj();
    }

    setQuotationCompleted() {
        this.isQuotationCompleted = BMSConstants.isQuotationCompleted();
    }

    setRRType() {
        if (BMSConstants.getBMSType() == BMSType.RenewalRerate)
            this.isRerateOnly = true;
    }
    handleManuScriptFld() {
        this._aus.isUnderWriterUser().subscribe((isUW) => {
            this.isITUW = isUW;
            this.checkDisableManuscript();
            this.checkRIFieldEditable();
        })
    }

    checkDisableManuscript() {
        if (BMSConstants.getBMSType() == BMSType.NewBusiness || BMSConstants.getBMSType() == BMSType.CoverNote) {
            if (this.caseInfo.status == 'Draft' || this.caseInfo.status == 'Assessment' || this.caseInfo.status == 'Assessment Approval') {
                this.disableManuscript = false;
            }
            else if (this.caseInfo.status == 'Referral Approval') {
                if (this.isITUW == 'Y')
                    this.disableManuscript = false;
                else
                    this.disableManuscript = true;
            }
            //Redmine 2890,2891
            else if (this.caseInfo.status == 'RHC Referral Approval') {
                this.disableManuscript = false;
            }
            else
                this.disableManuscript = true;
        }
        else
            this.disableManuscript = false;
    }

    checkRIFieldEditable() {
        if (BMSConstants.getBMSType() == BMSType.NewBusiness || BMSConstants.getBMSType() == BMSType.CoverNote) {
            if (this.caseInfo.status == 'Draft' || this.caseInfo.status == 'Assessment' || this.caseInfo.status == 'Assessment Approval') {
                this.isRIMethodEditable = "Y";
            }
            else if (this.caseInfo.status == 'Referral Approval') {
                if (this.isITUW == 'Y')
                    this.isRIMethodEditable = "Y";
                else
                    this.isRIMethodEditable = "N";
            }
            else
                this.isRIMethodEditable = "N";
        }
        else
            this.isRIMethodEditable = "Y";
    }

    public onPolicyTypeChange(value) {
        this.proposalHeader.renewalType = value;
        this.setNotificationType();
        this.checkUOBInfo();
        //Capture comments
        this.openCommentsPopupForPolicyTypeChange();
    }

    openCommentsPopupForPolicyTypeChange() {
        let lookup = new ModalInput();
        lookup.component = ["CommonCommentDialogComponent", "app/bms/components/proposal/process/common.comment.dialog.module", "CommonCommentDialogModule"];
        lookup.datainput = { dialogName: "renewal-type-change" };
        lookup.outputCallback = this.commonCommentDialogCallback;
        lookup.parentCompPRMS = { comp: this };
        lookup.heading = "Enter Reason for Renewal Type Change";
        lookup.icon = "fa fa-comment";
        lookup.containerRef = this.contentArea;
        this.dcl.openLookup(lookup);
    }

    public resetRTInfo() {
        this._rtService.refreshVPMSRebateByAgent().subscribe();
    }

    public getOrgDn(data, scopeObject) {
        scopeObject.orgDN = data;
    }

    handleIndicatorCheckBox() {
        this.duplicateIndicatorUI = (this.proposal.newBusiness.headerInfo.duplicateIndicator === "true") ? true : false;
        this.channelConflictIndicatorUI = (this.proposal.newBusiness.headerInfo.channelConflictIndicator === "true") ? true : false;
    }
    handleRenewal() {
        // E1003 Start
        if (BMSConstants.getBMSType() == BMSType.RenewalRerate || BMSConstants.getBMSType() == BMSType.Renewal) {
            this.isRerate = true;
        }
        if (BMSConstants.getBMSType() == BMSType.RenewalRerate) {
            this.isRerateED = true;
        }
        // E1003 End
        if (BMSConstants.getBMSType() == BMSType.Renewal && this.caseInfo.status == "Assessment") {
            this.isRerateCSE = true;
        }
    }
    handlePOIForCoverNote() {
        let status = this.caseInfo.status;
        if (BMSConstants.getBMSType() == BMSType.CoverNote && status != "Ready for Conversion" && status != "Policy Processing" && status != "P400 In forced" && status != "Closed" && status != "P400 Pending NB" && status != "Cover Note Accepted") {
            this.poiDisable = 'Y';

            this.proposalHeader.effectiveDate = moment.utc(new Date()).format("YYYY-MM-DD");
            //GA002 START
            //this.proposalHeader.endDate = moment(moment.utc(new Date())).add(364, 'days').format("YYYY-MM-DD");	
            this.proposalHeader.endDate = moment(this.proposalHeader.effectiveDate, "YYYY-MM-DD").add(1, 'years').format("YYYY-MM-DD");
            this.proposalHeader.endDate = moment(this.proposalHeader.endDate, "YYYY-MM-DD").subtract(1, 'days').format("YYYY-MM-DD");
            //GA002 END
        }


    }
    populateLovs() {
        this.lovDropDownService.createLOVDataList(["HandlingBranch", "Contract Type", "CampignCode", "UOBSector"]);
        let lovFields = [
            new LOV_Field("ALL", "ALL", "ALL", "ALL", "ALL", "ALL", "BranchList", "LOV", [], "MSIG_BRANCH_MASTER", "HandlingBranch", null),
            // E1001 START
            //new LOV_Field("ALL", "ALL", "NEW BUSINESS", "ALL", "ALL", "ALL", "Campign Code", "LOV", [], "DESCPF", "CampignCode",null),
            new LOV_Field("ALL", "ALL", "NEW BUSINESS", "ALL", "ALL", "ALL", "Campign Code", "LOV", [], "DESCPF", "CampignCode", "callbackCampignCodes"),
            // E1001 END
            new LOV_Field("ALL", "ALL", "NEW BUSINESS", "ALL", "ALL", "ALL", "UOB", "LOV", [], "TABLE", "UOBSector", null)];

        let mFilter = [];
        if (this.poiDisable == 'Y') {  //MYS-2018-1145 MPD Covernote
            mFilter = this.lovDropDownService.createFilter([new SearchFilter("M.LOB_NAME", "Motor", "EQ", "AND"), new SearchFilter("P.PRODUCT_TYPE", "'CV','CVF','CVT','HVC','HVF','HVT','MTC','MTF','MTT','MCF','MCT','MCY','MPC','MPF','MPT','MPD','MMP','MMF'", "IN", "AND")]); //  MYS-2018-1145 MPD Covernote VK006 MMP Product // MS001 MMF Product
            lovFields.push(new BMSLOVRequest().getListRequest("ProductList", mFilter, "ProductList", "PRODUCT_DETAILS", null));
            this.lovDropDownService.util_populateLOV(lovFields, this);
        }
        else {
            let sProdList = "";
            let prom = this._cordysService.callCordysSoapService("GetXMLObject", "http://schemas.cordys.com/1.0/xmlstore", { "key": "/com/msig/insurance/simplifiedprocess/productlist.xml" }, null, null, true, null);
            prom.success((resp) => {
                sProdList = AppUtil.getValueByPath(resp, "tuple.old.SimplifiedProductList.ProductList");
                if (this.proposalHeader.isSimplifiedProcess == 'Y')
                    mFilter = this.lovDropDownService.createFilter([new SearchFilter("P.PRODUCT_TYPE", sProdList, "IN", "AND")]);
                else
                    if (this.caseInfo.businessFunction != "NewBusiness") { // MYS-2018-0878 - FHI Product for only renewals
                        mFilter = this.lovDropDownService.createFilter([new SearchFilter("P.PRODUCT_TYPE", sProdList, "NOT IN", "AND")]);
                    }
                    else { //MYS-2018-0878 - FHI Product for only renewals KA0002
                        sProdList = sProdList.concat(",'FHI'");
                        mFilter = this.lovDropDownService.createFilter([new SearchFilter("P.PRODUCT_TYPE", sProdList, "NOT IN", "AND")]);
                    }
                lovFields.push(new BMSLOVRequest().getListRequest("ProductList", mFilter, "ProductList", "PRODUCT_DETAILS", null));
                this.lovDropDownService.util_populateLOV(lovFields, this);
            });
            prom.error((resp) => {
                this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Error while fetching CDD limits.", -1));

            });
        }
    }

    setFormDisabled(set: boolean) {
        if (set == true) {
            this.disableForm = "Y";
            this.disableDocReceivedDate = "Y";
        }
        else {
            this.disableForm = "N";
            this.disableDocReceivedDate = "N";
        }

        this.setDocRecDateDisabled();
    }

    ngAfterViewInit() {
        this.setDocRecDateDisabled();
    }

    setDocRecDateDisabled() {
        if (this.disableForm == 'N' && this.caseInfo.status != null && (["Draft", "Assessment", "Assessment Approval"].indexOf(this.caseInfo.status) != -1)) {
            this.disableDocReceivedDate = 'N';
        }
        else {
            this.disableDocReceivedDate = 'Y';
        }
    }

    onHBranchInit(ctrl) {
        this.setDefaultBranch(ctrl);
    }

    setDefaultBranch(ctrl) {
        this.getLoggedInUserId(ctrl);
    }

    getLoggedInUserId(ctrl) {
        this._aus.getUserDn().subscribe((data) => this.setBranchByUserId(data, ctrl));
    }

    setBranchByUserId(data, ctrl) {
        if (data != null && ((this.proposalHeader.handlingBranch == null || this.proposalHeader.handlingBranch == "") || (this.caseInfo.handlingBranchId == null || this.caseInfo.handlingBranchId == ""))) {
            let branch;
            // Defaulting Handling branch if user have Banca role - SAF-2017-0921 -- start
            this.isBancaBranch = false;
            this._aus.getUserRoles().subscribe((roleData) => {
                for (let item of roleData) {
                    if (item.includes("cn=Banca")) {
                        branch = item.split("cn=")[1].split("_")[0];
                        this.bancaBranch = branch;
                        this.isBancaBranch = true;
                    }
                }
            });
            if (!this.isBancaBranch) {
                branch = data.substr(5, 2).toUpperCase();
            }  // End
            this.proposalHeader.handlingBranch = branch;
            this.caseInfo.handlingBranchId = branch;
            ctrl.setter(branch, ctrl.comp);
        }
    }

    setProductDetails(values) {
        let product = values.record;
        this.proposalHeader.contractDescription = product.PRODUCT_NAME;
        this.proposalHeader.lobName = product.LOB_NAME;
        this.proposalHeader.lineOfBusiness = product.LOB_CODE;
        this.proposalHeader.riskScreen = product.RISK_SCREEN_NM;
        this._rtService.resetRiskList(true);
        this.onproductchange.emit();
        this._rtService.setListLock();
        this.triggerProductChange(this.proposalHeader.contractType);
        this.caseInfo.lineOfBusiness = product.LOB_CODE;
        this.caseInfo.requestType = product.PRODUCT_TYPE;
        if (product.LOB_CODE == 'MTR')
            this.proposalHeader.renewalType = 'M1';
        else
            this.proposalHeader.renewalType = '';
        this.notifDisplayed = false;
        this.checkChannelConflict();
        this.setMinForStartDate();
        this.setPayPlan(true);
        let prom = this.setRenewalType();
        if (prom != null) {
            prom.done(() => this.setNotificationType());
        }
        //this.validateInsuredAge();
        this.checkMTIAvailability();
        this.validateEndDate();
        if (this.proposalHeader.isSimplifiedProcess == 'Y')
            this.setReferred(this);

        // SAF MYS-2018-1249 start
        if (this.proposalHeader.lineOfBusiness == "FIR" && this.proposalHeader.contractType != "LOP" && (["MyTasks", "MyDrafts"].indexOf(this._activatedRoute.snapshot.params['component']) >= 0 || Object.keys(this._activatedRoute.snapshot.params).length == 0)) {
            this._rtService.setRiskScreenActivationInfo(this.proposalHeader.contractType);
        } //End
        this.setCCMOpsScreen();//pku
    }

    public checkMTIAvailability() {
        let request: GetLOVData = new GetLOVData();
        request.BRANCH = 'ALL';
        request.LOB = 'ALL';
        request.BUSINESS_FUNCTION = 'NEW BUSINESS';
        request.PRODUCT = 'ALL';
        request.OPERATION = 'NEW';
        request.FORM_NAME = 'ALL';
        request.FORM_FIELD_NAME = 'MTI';
        request.FIELD_TYPE = 'LOV';
        request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        request.ADVANCE_CONFIG_XML.FILTERS = new Filter();

        let filter: any = {};

        request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push(filter, { "@FIELD_NAME": 'SUBSTRING(ITEMITEM, 1, 3)', "@FIELD_VALUE": this.proposalHeader.contractType, '@OPERATION': 'EQ', '@CONDITION': 'AND' });
        this._cordysService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.mtiSuccessHandler, this.handleError, true, { comp: this });
    }

    private mtiSuccessHandler(response, prms) {
        if (response.tuple) {
            // Show MTI Component
            prms.comp.proposalHeader.MTI = "Y";
            if (prms.comp.proposalHeader.mtiItems != null)
                prms.comp.proposalHeader.mtiItems.clearMTI();
            else
                prms.comp.proposalHeader.mtiItems = new MTIItems();
        } else {
            prms.comp.proposalHeader.MTI = "N";
            prms.comp.proposalHeader.mtiItems = null;
        }
    }

    openClientLookup() {
        let input = new ModalInput();
        input.parentCompPRMS = { comp: this };
        if (AppUtil.isEmpty(this.proposal.newBusiness.clientDetails.client.clientNumber, false) == false) {
            input.heading = "Client Details";
            input.datainput = { isViewMode: true, clienttype: 'C', clientNumber: this.proposal.newBusiness.clientDetails.client.clientNumber, isReadOnly: 'Y' };
        }
        else if (AppUtil.isEmpty(this.proposal.newBusiness.clientDetails.client.itemNo, false) == false) {
            input.heading = "Prospect Details";
            input.datainput = { isViewMode: true, clienttype: 'P', clientNumber: this.proposal.newBusiness.clientDetails.client.itemNo, isReadOnly: 'Y' };
        }
        if (this.proposal.newBusiness.clientDetails.client.genericDetails.clienttype == "P") {
            input = input.get("PersonalClientComponent");
        }
        else if (this.proposal.newBusiness.clientDetails.client.genericDetails.clienttype == "C") {
            input = input.get("CorporateClientComponent");
        }
        input.icon = "fa fa-file-pdf-o";
        input.containerRef = this.contentArea;

        //Start	E1005
        let resp = this._cordysService.callCordysSoapService("GetClientDetailsRequest", "http://schemas.insurance.com/businessobject/1.0/", { "itemNo": input.datainput.clientNumber, "type": input.datainput.clienttype }, null, this.handleError, false, { comp: this });
        this.proposal.newBusiness.clientDetails.client.clientNumber = resp.responseJSON.success.client.clientNumber;
        //End E1005
        this.dcl.openLookup(input);
    }

    triggerProductChange(product) {
        this.isProductChanged = true;
        this.proposalHeader.marineOpenCover = "";
        this.proposalHeader.setMP("");
        this.mergePOIContractChange();
    }

    mergePOIContractChange() {
        if (AppUtil.isEmpty([this.proposalHeader.contractType, this.proposalHeader.effectiveDate, this.proposalHeader.endDate], true) == false) {
            this._rtService.refreshContractInfo().subscribe((data) => {
                if (this.isProductChanged == true) {
                    this.isProductChanged = false;
                }
                this._rtService.releaseListLock();

                if (this.caseInfo.businessFunction == 'CoverNote' && BMSConstants.getSatus() != "Cover Note Accepted") {
                    BMSConstants.getNewBusinessInfo().risks.clearVPMSCalculation();
                    BMSConstants.getNewBusinessInfo().resetAllPremCalc();
                }
            });
        }

        if (this.caseInfo.businessFunction == 'CoverNote' && BMSConstants.getSatus() != "Cover Note Accepted") {
            BMSConstants.getNewBusinessInfo().risks.clearVPMSCalculation();
            BMSConstants.getNewBusinessInfo().resetAllPremCalc();
        }
    }

    triggerInsuredChange() {
        //this._rtService.getRisksByProduct(this.proposalHeader.contractType,true).subscribe();
    }

    openInsuredLookup() {
        let si = new SearchInput();
        si.BRANCH = 'ALL',
            si.LOB = 'ALL';
        si.BUSINESS_FUNCTION = 'ALL';
        si.PRODUCT = 'ALL';
        si.OPERATION = 'ALL';
        si.FORM_NAME = 'ALL';
        si.FORM_FIELD_NAME = 'Client';
        //VK003 Marine Open Cover Changes
        if (this.proposalHeader.contractType == "MAR" && this.proposalHeader.marineOpenCover != undefined && this.proposalHeader.marineOpenCover != '') {
            si.FORM_FIELD_NAME = 'ClientMAR';
            si.condition = {
                "CONTRACT": this.proposalHeader.contractType,
                "MCOVER": this.proposalHeader.marineOpenCover
            }
        }
        //VK003
        si.FIELD_TYPE = 'LOOKUP';
        si.isSingleSelect = true;

        let input = new ModalInput().get("GenericSearchComponent");
        input.datainput = si;
        input.outputCallback = this.setInsured;
        input.parentCompPRMS = { comp: this };
        input.heading = "Insured Details";
        input.icon = "fa fa-file-pdf-o";
        input.containerRef = this.contentArea;
        this.dcl.openLookup(input);
    }

    setInsured(data, prms) {

        let client = data[0];
        /**** Added by Rajesh to handle MSIG-1990 & MSIG-1991***/
        if (prms.comp.proposalHeader.contractType == "MPA" && client.old.TABLE.CLTTYPE == "C") {
            prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "MPA product is allowed only for Personal Client type.", -1));
        }
        else if (prms.comp.proposalHeader.contractType == "HII" && client.old.TABLE.CLTTYPE == "C") {
            prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "HII is only applicable to Personal Client. For Corporate Client, please select HIG.", -1));
        }
        else if (prms.comp.proposalHeader.contractType == "HIG" && client.old.TABLE.CLTTYPE == "P") {
            prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "HIG is only applicable to Corporate Client. For Personal Client, please select HII.", -1));
        }
        //commented by Rajesh as part of UAT/KUT Feedback on 11-Jul-2017
        //else if((prms.comp.proposalHeader.contractType=="MSW" || prms.comp.proposalHeader.contractType=="MWP") && client.old.TABLE.CLTTYPE == "P"){
        //	prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "MSW and MWP products are allowed only for Corporate Client type." , -1));            
        //}
        else {
            /* commented below code for SAF MYS-2018-0202 
             prms.comp.proposalHeader.insuredNumber=client.old.TABLE.CLNTNUM;
             prms.comp.proposalHeader.insuredName=client.old.TABLE.NAME; */

            prms.comp.setClientDetails(prms.comp, prms.View.substring(0, 1), client.old.TABLE.CLNTNUM).done(() => {
                if (client.old.TABLE.CLTDOB) {
                    prms.comp.insuredDOB = client.old.TABLE.CLTDOB.replace(/[-]/g, "");
                    let insuredDOB = moment(prms.comp.insuredDOB, "YYYYMMDD");
                    let curDate = moment(new Date().toISOString(), "YYYY-MM-DD");
                    prms.comp.proposalHeader.insuredAge = curDate.diff(insuredDOB, 'year');

                    // Added age validation if Age < 18 years for SAF MYS-2018-0202 -- start
                    //VK006 Added MMP Condition
                    //MS001 Added MMF Condition
                    if ((prms.comp.proposalHeader.contractType == 'MPC' || prms.comp.proposalHeader.contractType == 'MPD' || prms.comp.proposalHeader.contractType == 'MMP' || prms.comp.proposalHeader.contractType == 'MMF')
                        && !isNaN(prms.comp.proposalHeader.insuredAge) && Number(prms.comp.proposalHeader.insuredAge) + 1 < 18) {
                        prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "The Insured Age must be more than 17 years old.", -1));
                        prms.comp.proposalHeader.insuredNumber = undefined;
                        prms.comp.proposalHeader.insuredName = undefined;
                        prms.comp.proposalHeader.insuredType = undefined;
                        prms.comp.proposalHeader.insuredLongName1 = undefined;
                        prms.comp.proposalHeader.insuredLongName2 = undefined;
                        prms.comp.proposalHeader.insuredLongName3 = undefined;
                        prms.comp.proposalHeader.insuredLongName4 = undefined;
                        prms.comp.proposalHeader.insuredLongName5 = undefined;
                        prms.comp.proposal.newBusiness.clientDetails = new ClientDetails();
                        return;
                    }
                    //GA001
                    if (client.old.TABLE.CLTTYPE == "C" && ["TPI", "TDA", "TAA", "TDI"].indexOf(prms.comp.proposalHeader.contractType) >= 0) {
                        prms.comp.proposal.newBusiness.clientDetails.client.personalClientDetails.dateOfBirth = "1985-01-01"; // setting default Date of birth to avoid case turned to Referred.
                    }
                    //End
                }

                prms.comp.proposalHeader.insuredNumber = client.old.TABLE.CLNTNUM;
                prms.comp.proposalHeader.insuredName = client.old.TABLE.NAME;// End

                if (client.old.TABLE.CLTTYPE == "C") {
                    prms.comp.proposalHeader.insuredType = "Corporate";
                } else {
                    prms.comp.proposalHeader.insuredType = "Personal";
                }
                prms.comp.triggerInsuredChange();
                prms.comp.notifDisplayed = false;
                prms.comp.checkChannelConflict();
                //GA005 START
                if (prms.comp.proposalHeader.isHighRiskApplicable) {
                    prms.comp.checkHighRiskClient();
                } else {
                    prms.comp.checkBlackList();
                }
                //GA005 END
                //prms.comp.validateInsuredAge();
                prms.comp.resetInsuredInReferredPlace();
                prms.comp.setPayorId(prms.comp);
            });
        }

    }

    setPayorId(comp) {
        if (comp.proposalHeader.periodicDebitDetails != null && comp.proposalHeader.periodicDebitDetails != "") {
            comp.proposalHeader.periodicDebitDetails.payerNumber = comp.proposalHeader.insuredNumber;
            comp.proposalHeader.periodicDebitDetails.payerName = comp.proposalHeader.insuredName;
        }
    }

    setBranchCode(resp) {
        if (resp.tuple != null)
            this.proposalHeader.branchCodeForBanca = resp.tuple.old.DESCPF.BRANCH_CODE;
        this.proposalHeader.bancaRequired = "Y";
        this.proposalHeader.bancaRequiredUI = true;
        if (this.bancaComp != null)
            this.bancaComp.defaultBranch(null, true);
    }

    resetInsuredInReferredPlace() {

    }

    onChangeBlackList(e) {
        if (e.target.checked == false) {
            this.proposalHeader.blackListIndicator = "false";
            this.proposalHeader.blackListIndicatorUI = false;
        }
        else {
            this.proposalHeader.blackListIndicator = "true";
            this.proposalHeader.blackListIndicatorUI = true;
        }
        this.setReferred(this);
    }

    validateInsuredAge() {
        if (this.proposalHeader.insuredAge) {
            //(this.proposalHeader.insuredAge < 22 || this.proposalHeader.insuredAge > 70) Removed age validation for MPC SAF MYS-2018-0202 
            //VK006
            //MS001
            if (((this.proposalHeader.contractType == 'MPD' || this.proposalHeader.contractType == 'MPC' || this.proposalHeader.contractType == 'MMP' || this.proposalHeader.contractType == 'MMF') && Number(this.proposalHeader.insuredAge) + 1 > 75) || (this.proposalHeader.contractType == 'NPA' && !(this.proposalHeader.insuredAge > 15 && this.proposalHeader.insuredAge < 71))) {
                this.proposalHeader.isReferredRisk = "true";
                this.proposalHeader.isReferredRiskUI = true;
            }
            else {
                this.proposalHeader.isReferredRisk = "false";
                this.proposalHeader.isReferredRiskUI = false;
            }
        }
        else {
            this.proposalHeader.isReferredRisk = "false";
            this.proposalHeader.isReferredRiskUI = false;
        }
    }

    setClientDetails(comp, type, clientNumber) {
        return comp._cordysService.callCordysSoapService("GetClientDetailsRequest", "http://schemas.insurance.com/businessobject/1.0/", { "itemNo": clientNumber, "type": type }, this.getClientDataCallBack, this.handleError, true, { comp: comp });
    }

    getClientDataCallBack(response, prms) {
        prms.comp.proposal.newBusiness.clientDetails.refresh(response.success);
        prms.comp.setInsuredPersonType(prms.comp.proposal.newBusiness.clientDetails);
    }

    setInsuredPersonType(clientDetails: ClientDetails) {
        this.insuredPersonType = "";
        if (AppUtil.isEmpty(AppUtil.getValueByPath(clientDetails, "client.genericDetails.clienttype"), false) == false) {
            if (AppUtil.isEmpty(clientDetails.client.clientNumber, false) == false) {
                this.insuredPersonType = "Client";
            }
            else if (AppUtil.isEmpty(clientDetails.client.itemNo, false) == false) {
                this.insuredPersonType = "Prospect";
            }
        }
    }

    handleError(response, status, errorText, prms) {
        prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, response.responseJSON.faultstring.text, -1));
    }

    showError(response) {
        this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, response.responseJSON.faultstring.text, -1));
    }

    openAgentLookup() {
        let si = new SearchInput();
        let input = new ModalInput().get("GenericSearchComponent");
        si.BRANCH = 'ALL',
            si.LOB = 'ALL';
        si.BUSINESS_FUNCTION = 'ALL';
        si.PRODUCT = 'ALL';
        si.OPERATION = 'ALL';
        si.FORM_NAME = 'ALL';
        //MRA001 chnages start 
        if (BMSConstants.getBMSType() == BMSType.Renewal) {

            si.FORM_FIELD_NAME = 'AGENT_CODE';// MRA001
            si.FIELD_TYPE = 'LOOKUP';
            si.isSingleSelect = true;

            si.condition = { "DATEEND": moment(new Date()).format("YYYYMMDD") };

            if (AppUtil.isEmpty(this.proposalHeader.servicingBranch, false) == false)
                si.condition["AGENT_CODE"] = this.proposalHeader.servicingBranch;


            input.datainput = si;
            input.heading = "Agent Details";
            input.icon = "fa fa-file-pdf-o";
            input.containerRef = this.contentArea;
        }
        else {
            si.FORM_FIELD_NAME = 'AGENT_CODE_NEW';// MRA001
            si.FIELD_TYPE = 'LOOKUP';
            si.isSingleSelect = true;
            si.replaceField = { "value5": moment(new Date()).format("YYYYMMDD") };//MRA001
            si.isDefaultFilterRequired = false;
            //si.condition = { "DATEEND": moment(new Date()).format("YYYYMMDD") };// MRA001



            input.datainput = si;
            input.heading = "Agent Details(transferred agent will be displayed if agent is terminated)";//MRA001
            input.icon = "fa fa-file-pdf-o";
            input.containerRef = this.contentArea;

        }
        this.dcl.openLookup(input).subscribe((data) => {
            let agent;

            // KU0001 - Start
            //Flex agent validation
            if (BMSConstants.getBMSType() == BMSType.Renewal) {
                agent = data.data[0].old.TABLE;
                this.checkFluxAgentOrNot(agent.AGENT_CODE);
            }

            else {
                agent = data.data[0].old.AGNTPF;
                this.checkFluxAgentOrNot(agent.AGENT_CODE);
            }

            if (this.proposalHeader.contractType != "" && this.proposalHeader.contractType == "MPC") {
                this.changeAgentValidation(agent);
            } else {
                //otherwise
                this.setAgent(agent);

                this.checkBancaInfo(false);
            }
            // KU0001 - End
        });
    }
    //MRA001 changes end 
    //MRA001  chnages starts 
    setAgent(data) {
        let agent = data;//MRA001
        if (BMSConstants.getBMSType() == BMSType.Renewal) {
            this.setReferred(this);

        }

        this.proposalHeader.agentCode = agent.AGENT_CODE;
        this._coiService.checkCOIRequired(this.proposalHeader.agentCode).subscribe();
        this.proposalHeader.agentName = agent.AGENT_NAME;
        this.proposalHeader.servicingBranch = agent.AGENT_BRANCH;
        this.proposalHeader.serviceBranchName = agent.BRANCH_DESC;
        this.proposalHeader.businessChannel = agent.BUSINESS_CHANNEL;
        this.proposalHeader.agentPhone1 = agent.CLTPHONE01;
        this.proposalHeader.agentPhone2 = agent.CLTPHONE02;
        this._rtService.resetRebateByAgent().subscribe();
        this.proposalHeader.bancaChannel = agent.ZMISCHNL;
        this.proposalHeader.businessChannelName = agent.BUS_CHN_DESC;
        this.proposalHeader.producerCode = agent.PRODUCER_CODE;
        this.proposalHeader.misSubTier = agent.SUBTIER;
        this.proposalHeader.isJapaneseChannel = this.checkForJapaneseChannel(agent.ZMISCHNL, this.proposalHeader.misSubTier);
        this.caseInfo.division = agent.BRANCH_DESC;
        //AL001 START
        //prms.comp.getAccountHandler(prms.comp,false);
        this.getAccountHandlerByBranchAndApplication(this, false);
        //AL001 END
        this.notifDisplayed = false;
        this.checkChannelConflict();
        //prms.comp.checkPayPlan(prms.comp,"Y");
        //Divek MYS-2018-0582 changes Start       
        this.proposalHeader.rebate = (this.proposalHeader.businessChannel == '04' && this.proposalHeader.isVPMS == 'N') ? this.proposalHeader.maxRebate : 0;
        //END
        // SAF MYS-2018-0146	
        this.proposalHeader.agentClientNum = agent.CLIENT_NUM;
        this.proposalHeader.agentClientSurName = agent.CLIENT_SURNAME;
        this.proposalHeader.agentClientGivName = agent.CLIENT_GIVNAME;
        this.proposalHeader.agentClientPhone = agent.CLIENT_PHONE;
        //MRA001 Changes END
        // KU001 Start
        this.OldAgentType = this.NewAgentType;
        // KU001 End
    }
    //KU001 - Start
    changeAgentValidation(data) {
        let agent = data;//MRA001
        let value = agent.AGENT_CODE;
        if (value != undefined && value != "" && this.proposalHeader.contractType != undefined && this.proposalHeader.contractType != "" && this.proposalHeader.contractType == "MPC" && this.hasRisks() == true && this.NewAgentType != this.OldAgentType) {
            //this.productCtrl.setter(this.proposalHeader.contractType, this.productCtrl.comp);
            this.confirmAgentChange("Changing agent will clear all the risks added in the risk table. Do you still want to continue?", data);
        }
        else {
            this.setAgent(data);
            this.checkBancaInfo(false);
        }
    }
    //KU001 - End

    setAgentEditMode() {
        if (BMSConstants.getBMSType() == BMSType.Renewal && (this.caseInfo.status == 'Draft' || this.caseInfo.status == 'Assessment' || this.caseInfo.status == 'Assessment Approval')) {
            this.isAgentEditMode = true;
        }
        else {
            if (this.caseInfo.status == 'Draft')
                this.isAgentEditMode = true;
            else
                this.isAgentEditMode = false;
        }
    }

    private viewAgentDetails(control, agentCode) {
        let input = new ModalInput();
        input.component = ["AgentDetailsComponent", "app/bms/components/proposal/proposalheader/dialogs/agent.details.module", "AgentDetailsModule"];
        input.datainput = {
            agentCode: agentCode
        };
        input.parentCompPRMS = { comp: this };
        input.heading = "Agent Details";
        input.icon = "fa fa-eye";
        input.containerRef = this.contentArea;
        this.dcl.openLookup(input);
    }

    openMOCEnquiry() {
        let input = new ModalInput();
        input.component = ["MOCDetailsComponent", "app/bms/components/proposal/proposalheader/dialogs/moc.details.module", "MOCDetailsModule"];
        input.datainput = {
            isViewMode: true,
            moc: this.proposalHeader.marineOpenCover,
            isReadOnly: 'Y'
        };
        input.parentCompPRMS = { comp: this };
        input.heading = "Marine Open Cover Details";
        input.icon = "fa fa-eye";
        input.containerRef = this.contentArea;
        this.dcl.openLookup(input);
    }

    onMOCClear(ev) {
        if (this.hasRisks() == true) {
            this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "MOC Cannot be deleted if at least one risk is added in Risk Summary", 5000));
        }
        else {
            this.proposalHeader.marineOpenCover = '';
        }
        //this.confirmMOCChange("Changing Marine Open Cover Number will clear all the risks added in the risk table. Do you still want to continue?", '', true);
    }

    openMOCLookup() {
        let si = new SearchInput();
        si.BRANCH = 'ALL',
            si.LOB = 'MAR';
        si.BUSINESS_FUNCTION = 'ALL';
        si.PRODUCT = 'ALL';
        si.OPERATION = 'ALL';
        si.FORM_NAME = 'ALL';
        si.FORM_FIELD_NAME = 'Marine Open Cover';
        si.FIELD_TYPE = 'LOOKUP';
        si.isSingleSelect = true;
        //si.condition = {"DATEEND": moment(new Date()).format("YYYYMMDD")};
        si.condition = { "A.AGNTNUM": this.proposalHeader.agentCode, "A.STATCODE": "IF" };

        let input = new ModalInput().get("GenericSearchComponent");
        input.datainput = si;
        input.heading = "Open Cover Client Search";
        input.icon = "fa fa-file-pdf-o";
        input.containerRef = this.contentArea;
        this.dcl.openLookup(input).subscribe((data) => {
            this.setMOCClient(data);

        });
    }

    setMOCClient(data) {

        if (this.hasRisks() == true) {
            this.confirmMOCChange("Changing Marine Open Cover Number will clear all the risks added in the risk table. Do you still want to continue?", data, false);
        }
        else {
            this.setMOCDetails(data);
        }
    }

    private setMOCDetails(data) {
        let mocData = data.data[0];

        this.proposalHeader.marineOpenCover = mocData.old.WMOCPF.MCOVER;
        this.proposalHeader.insuredNumber = mocData.old.WMOCPF.CLNTNUM;
        this.proposalHeader.insuredName = mocData.old.WMOCPF.CLIENTNAME;

        this.setClientDetails(this, "C", mocData.old.WMOCPF.CLNTNUM).done(() => {
            if (mocData.old.WMOCPF.CLTDOB && mocData.old.WMOCPF.CLTDOB != '99999999') {
                this.insuredDOB = mocData.old.WMOCPF.CLTDOB.replace(/[-]/g, "");
                let insuredDOB = moment(this.insuredDOB, "YYYYMMDD");
                let curDate = moment(new Date().toISOString(), "YYYY-MM-DD");
                this.proposalHeader.insuredAge = curDate.diff(insuredDOB, 'year');
            }
            else {
                this.proposalHeader.insuredAge = 0;
            }

            this.proposalHeader.insuredNumber = mocData.old.WMOCPF.CLNTNUM;
            this.proposalHeader.insuredName = mocData.old.WMOCPF.CLIENTNAME;

            if (mocData.old.WMOCPF.CLTTYPE == "C") {
                this.proposalHeader.insuredType = "Corporate";
            } else {
                this.proposalHeader.insuredType = "Personal";
            }

            this.triggerInsuredChange();
            this.notifDisplayed = false;

            this.checkChannelConflict();
            //GA005 START
            if (this.proposalHeader.isHighRiskApplicable) {
                this.checkHighRiskClient();
            } else {
                this.checkBlackList();
            }
            //GA005 END
            this.resetInsuredInReferredPlace();
            this.setPayorId(this);

        });

		/*
		this.insuredPersonType = "Client";
		if (mocData.old.WMOCPF.CLTTYPE == "C") {
			this.proposalHeader.insuredType="Corporate";
		} else {
			this.proposalHeader.insuredType="Personal";
		}
		
		if(mocData.old.WMOCPF.CLTDOB && mocData.old.WMOCPF.CLTDOB != '999999999') {
			this.insuredDOB = mocData.old.WMOCPF.CLTDOB.replace(/[-]/g, "");
			let insuredDOB = moment(this.insuredDOB, "YYYYMMDD");
			let curDate = moment(new Date().toISOString(), "YYYY-MM-DD");
			this.proposalHeader.insuredAge = curDate.diff(insuredDOB, 'year');
		} else {
			this.proposalHeader.insuredAge = 0;
		}
		*/
    }


    private confirmMOCChange(message: string, values, isClear) {
        let inputObj = {
            "Message": message
        };
        let lookup = new ModalInput();
        lookup.component = ["Confirm", "app/common/components/utility/confirmmessage/confirm.module", "ConfirmModule"];
        lookup.datainput = inputObj;
        lookup.outputCallback = null;
        lookup.parentCompPRMS = {
            comp: this,
            values: values
        };
        lookup.heading = "User Confirmation";
        lookup.icon = "fa fa-hand-paper-o";
        lookup.containerRef = this.contentArea;
        this.dcl.openLookup(lookup).subscribe((data) => {
            this.mocChangeDecision(data, values, isClear);
        });
    }

    private mocChangeDecision(data, values, isClear) {
        if (data.data.value == 'Y') {
            this.proposalHeader.marineOpenCover = '';
            if (isClear) {
                this.triggerInsuredChange();
            }
            else {
                this.setMOCDetails(values);
                this.triggerInsuredChange();
            }
        }
    }

    //GA005 START
    getClientIDNum(): string {
        if (this.proposal.newBusiness.clientDetails) {
            if (this.proposal.newBusiness.clientDetails.client.genericDetails.clienttype == 'C') {
                return this.proposal.newBusiness.clientDetails.client.corporateClientDetails.BusinessRegNo;
            } else if (this.proposal.newBusiness.clientDetails.client.genericDetails.clienttype == 'P') {
                if (this.proposal.newBusiness.clientDetails.client.personalClientDetails.NRICNo
                    && this.proposal.newBusiness.clientDetails.client.personalClientDetails.NRICNo != undefined
                    && this.proposal.newBusiness.clientDetails.client.personalClientDetails.NRICNo != "") {
                    return this.proposal.newBusiness.clientDetails.client.personalClientDetails.NRICNo;
                } else if (this.proposal.newBusiness.clientDetails.client.personalClientDetails.IdNumber
                    && this.proposal.newBusiness.clientDetails.client.personalClientDetails.IdNumber != undefined
                    && this.proposal.newBusiness.clientDetails.client.personalClientDetails.IdNumber != "") {
                    return this.proposal.newBusiness.clientDetails.client.personalClientDetails.IdNumber;
                }
            }
        }
    }

    checkHighRiskClient() {
        let clientIDNo: string = this.getClientIDNum();
        let effectiveDate = "";
        let endDate = "";
        if (this.proposalHeader.effectiveDate != undefined && this.proposalHeader.effectiveDate != ""
            && moment(this.proposalHeader.effectiveDate).format("YYYYMMDD") != "Invalid date") {
            effectiveDate = moment(this.proposalHeader.effectiveDate).format("YYYYMMDD")
        }
        if (this.proposalHeader.endDate != undefined && this.proposalHeader.endDate != ""
            && moment(this.proposalHeader.endDate).format("YYYYMMDD") != "Invalid date") {
            endDate = moment(this.proposalHeader.endDate).format("YYYYMMDD")
        }
        if (clientIDNo != "" && clientIDNo != undefined) {
            this._cordysService.callCordysSoapService("CheckHighRiskForBnmClient", "http://schemas.cordys.com/bmsintegrationapp", {
                "CLIENTIDNO": clientIDNo, "EFFECTIVEDATE": effectiveDate, "ENDDATE": endDate
            }, this.highRiskBNMClientHandler, this.handleError, true, { comp: this });
        }
    }
    highRiskBNMClientHandler(response, prms) {
        let ind = "";
        let reason = "";
        let item = "BNM CLIENT";
        let item_key = "HIGHRISK_BNM_CLIENT";
        prms.comp.proposalHeader.highRiskIndicatorReasons = new HighRiskIndReasons();
        if (response.tuple != null && response.tuple.old != null && response.tuple.old.checkHighRiskForBnmClient
            && response.tuple.old.checkHighRiskForBnmClient.checkHighRiskForBnmClient != null
            && response.tuple.old.checkHighRiskForBnmClient.checkHighRiskForBnmClient != ""
            && response.tuple.old.checkHighRiskForBnmClient.checkHighRiskForBnmClient == "B") {
            ind = response.tuple.old.checkHighRiskForBnmClient.checkHighRiskForBnmClient.substring(0, 1);
            reason = "BNM Client is High Risk Indicator";
        }
        if (ind != null && ind == 'B') {
            let highRiskIndReason: HighRiskIndReason = new HighRiskIndReason();
            highRiskIndReason.riskNumber = 0;
            highRiskIndReason.item_key = item_key;
            highRiskIndReason.item = item;
            highRiskIndReason.reason = reason;
            highRiskIndReason.ind = ind;

            prms.comp.proposalHeader.highRiskIndicator = "true";
            prms.comp.proposalHeader.highRiskIndicatorUI = true;
            prms.comp.proposalHeader.highRiskBNMIndicator = ind;
            prms.comp.proposalHeader.highRiskIndicatorReasons.highRiskIndReason.push(highRiskIndReason);
            prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Selected Client is High Risk BNM Client.", 15000));
            prms.comp.setReferred(prms.comp);
        } else {
            prms.comp.proposalHeader.highRiskIndicator = "false";
            prms.comp.proposalHeader.highRiskIndicatorUI = false;
            prms.comp.proposalHeader.highRiskBNMIndicator = ind;

            let clientIDNo1: string = prms.comp.getClientIDNum();
            let effectiveDate1 = "";
            let endDate1 = "";
            if (prms.comp.proposalHeader.effectiveDate != undefined && prms.comp.proposalHeader.effectiveDate != ""
                && moment(prms.comp.proposalHeader.effectiveDate).format("YYYYMMDD") != "Invalid date") {
                effectiveDate1 = moment(prms.comp.proposalHeader.effectiveDate).format("YYYYMMDD")
            }
            if (prms.comp.proposalHeader.endDate != undefined && prms.comp.proposalHeader.endDate != ""
                && moment(prms.comp.proposalHeader.endDate).format("YYYYMMDD") != "Invalid date") {
                endDate1 = moment(prms.comp.proposalHeader.endDate).format("YYYYMMDD")
            }
            if (clientIDNo1 != "" && clientIDNo1 != undefined) {
                prms.comp._cordysService.callCordysSoapService("CheckHighRiskForInternalClient", "http://schemas.cordys.com/bmsintegrationapp", {
                    "CLIENTIDNO": clientIDNo1, "EFFECTIVEDATE": effectiveDate1, "ENDDATE": endDate1
                }, prms.comp.highRiskClientHandler, prms.comp.handleError, true, { comp: prms.comp });
            }
        }
    }
    highRiskClientHandler(response, prms) {
        let ind = "";
        let reason = "";
        let item_key = "INTERNAL_CLIENT";
        let item = "INTERNAL CLIENT";
        prms.comp.proposalHeader.highRiskIndicatorReasons = new HighRiskIndReasons();
        if (response.tuple != null && response.tuple.old != null && response.tuple.old.checkHighRiskForInternalClient
            && response.tuple.old.checkHighRiskForInternalClient.checkHighRiskForInternalClient != null
            && response.tuple.old.checkHighRiskForInternalClient.checkHighRiskForInternalClient != "") {
            ind = response.tuple.old.checkHighRiskForInternalClient.checkHighRiskForInternalClient.substring(0, 1);
            reason = response.tuple.old.checkHighRiskForInternalClient.checkHighRiskForInternalClient.substring(1);
        }
        if (ind != null && (ind == 'A' || ind == 'B')) {
            let highRiskIndReason: HighRiskIndReason = new HighRiskIndReason();
            highRiskIndReason.riskNumber = 0;
            highRiskIndReason.item_key = item_key;
            highRiskIndReason.item = item;
            highRiskIndReason.reason = reason;
            highRiskIndReason.ind = ind;

            prms.comp.proposalHeader.highRiskIndicator = "true";
            prms.comp.proposalHeader.highRiskIndicatorUI = true;
            prms.comp.proposalHeader.highRiskInternalIndicator = ind;
            prms.comp.proposalHeader.highRiskIndicatorType = ind;
            prms.comp.proposalHeader.highRiskIndicatorReasons.highRiskIndReason.push(highRiskIndReason);
            prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Selected Client is High Risk Internal Client.", 15000));
        } else {
            prms.comp.proposalHeader.highRiskIndicator = "false";
            prms.comp.proposalHeader.highRiskIndicatorUI = false;
            prms.comp.proposalHeader.highRiskInternalIndicator = 'N';
        }
        prms.comp.setReferred(prms.comp);
    }
    onChangeHighRiskClient(e) {
        if (e.target.checked == false) {
            this.proposalHeader.highRiskIndicator = "false";
            this.proposalHeader.highRiskIndicatorUI = false;
        }
        else {
            this.proposalHeader.highRiskIndicator = "true";
            this.proposalHeader.highRiskIndicatorUI = true;
        }
        this.setReferred(this);
    }
    openHighRiskReason() {//openRefReason
        let ary: any = this.proposalHeader.highRiskIndicatorReasons.highRiskIndReason;
        if (!Array.prototype.isPrototypeOf(this.proposalHeader.highRiskIndicatorReasons.highRiskIndReason)) {
            ary = [this.proposalHeader.highRiskIndicatorReasons.highRiskIndReason];
        }
        let input = new ModalInput();
        input.parentCompPRMS = { comp: this };
        input.heading = "Reason For High Risk Indicator";
        input.datainput = { reasonsList: ary };
        input.component = ["HighRiskReasonComponent", "app/bms/components/proposal/proposalheader/dialogs/highriskreason.module", "HighRiskReasonModule"];
        input.icon = "fa fa-file-pdf-o";
        input.containerRef = this.contentArea;
        this.dcl.openLookup(input);
    }
    //GA005 END
    checkBlackList() {
        if (this.proposalHeader.isHighRiskApplicable) {
            return;
        }
        let code: string = this.getIdNo();
        //GA004 START
        //if (code && this.proposalHeader.effectiveDate) {
        let IdNumber: string = "";

        if (this.proposal.newBusiness.clientDetails.client.genericDetails.clienttype == 'P' && this.proposal.newBusiness.clientDetails.client.personalClientDetails.IdNumber != undefined &&
            this.proposal.newBusiness.clientDetails.client.personalClientDetails.IdNumber != "") {
            IdNumber = this.proposal.newBusiness.clientDetails.client.personalClientDetails.IdNumber;
        }
        //if(code && this.proposalHeader.effectiveDate) {
        if ((code || IdNumber) && this.proposalHeader.effectiveDate) {
            //GA004 END
            let request: GetLOVData = new GetLOVData();
            request.BRANCH = 'ALL';
            request.LOB = 'ALL';
            request.BUSINESS_FUNCTION = 'NEW BUSINESS';
            request.PRODUCT = 'ALL';
            request.OPERATION = 'NEW';
            request.FORM_NAME = 'ALL';
            request.FORM_FIELD_NAME = 'Blacklisted Client';
            request.FIELD_TYPE = 'LOV';
            request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
            request.ADVANCE_CONFIG_XML.FILTERS = new Filter();

            if (this.proposal.newBusiness.clientDetails.client.genericDetails.clienttype == 'P' && this.proposal.newBusiness.clientDetails.client.personalClientDetails.IdNumber != undefined &&
                this.proposal.newBusiness.clientDetails.client.personalClientDetails.IdNumber != "") {
                IdNumber = this.proposal.newBusiness.clientDetails.client.personalClientDetails.IdNumber;
            }

            let filter: any = {};
            /* if(code != undefined)
                filter = {"@FIELD_NAME":'ZNRICBSRG',"@FIELD_VALUE":code ,'@OPERATION':'EQ','@CONDITION':'AND'}
            else if(this.proposal.newBusiness.clientDetails.client.personalClientDetails.IdNumber)
                filter = {"@FIELD_NAME":'ZOLDICPAS',"@FIELD_VALUE":this.proposal.newBusiness.clientDetails.client.personalClientDetails.IdNumber ,'@OPERATION':'EQ','@CONDITION':'AND'} */

            if (code != undefined && code != "")
                filter = { "@FIELD_NAME": 'ZNRICBSRG', "@FIELD_VALUE": code, '@OPERATION': 'EQ', '@CONDITION': 'AND' }
            //else if (this.proposal.newBusiness.clientDetails.client.personalClientDetails.IdNumber) //GA004
            else if (IdNumber != undefined && IdNumber != "")
                filter = { "@FIELD_NAME": 'ZOLDICPAS', "@FIELD_VALUE": IdNumber, '@OPERATION': 'EQ', '@CONDITION': 'AND' }
            //GA004
            //this.proposal.newBusiness.clientDetails.client.personalClientDetails.IdNumber, '@OPERATION': 'EQ', '@CONDITION': 'AND' }

            request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push(filter, { "@FIELD_NAME": 'ZBLOCKDTE', "@FIELD_VALUE": moment(this.proposalHeader.effectiveDate, "YYYY-MM-DD").format("YYYYMMDD"), '@OPERATION': 'LT', '@CONDITION': 'AND' },
                { "@FIELD_NAME": 'RELEASE_DATE', "@FIELD_VALUE": moment(this.proposalHeader.effectiveDate, "YYYY-MM-DD").format("YYYYMMDD"), '@OPERATION': 'GT', '@CONDITION': 'AND' });
            this._cordysService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.blackListSuccessHandler, this.handleError, true, { comp: this });
        }
    }

    checkChannelConflict() {

        if (this.proposal.newBusiness.headerInfo.isConflictResolvedByUser == "true") {
            return;
        }
        if (this.caseInfo.status != "Draft") {
            return;
        }
        if (BMSConstants.getBMSType() == BMSType.RenewalRerate || BMSConstants.getBMSType() == BMSType.Renewal) {
            return;
        }

        let code: string = this.getIdNo();
        let IdNumber: string = "";


        if (this.proposal.newBusiness.clientDetails.client.genericDetails.clienttype == 'P' && this.proposal.newBusiness.clientDetails.client.personalClientDetails.IdNumber != undefined)
            IdNumber = this.proposal.newBusiness.clientDetails.client.personalClientDetails.IdNumber;
        if ((code || IdNumber) && this.proposalHeader.effectiveDate && this.proposalHeader.endDate && this.proposalHeader.contractType && this.proposalHeader.businessChannel) {
			/*  VK001 
			let request:GetLOVData = new GetLOVData();
			request.BRANCH ='ALL';
			request.LOB = 'ALL';
			request.BUSINESS_FUNCTION = 'NEW BUSINESS';
			request.PRODUCT = 'ALL';
			request.OPERATION = 'ALL';
			request.FORM_NAME = 'ALL';        
			request.FORM_FIELD_NAME = 'Channel Conflict V2';
			request.FIELD_TYPE = 'LOV';
			request.ADVANCE_CONFIG_XML= new SearchAdvancedConfig(); 
			request.ADVANCE_CONFIG_XML.FILTERS = new Filter(); 
			VK001 - END */

            let initiatedOn: string = this.caseInfo.initiatedOn;
            if (initiatedOn == undefined || initiatedOn == null || initiatedOn == "") {
                initiatedOn = moment.utc(new Date()).format();
                initiatedOn = initiatedOn.substring(0, initiatedOn.length - 1);
            }
            /* VK001
            request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push(
				{"@FIELD_NAME":'concat(BusinessRegNo,NRICNo)',"@FIELD_VALUE": code ,'@OPERATION':'EQ','@CONDITION':'AND'},
				{"@FIELD_NAME":"ISNULL(OLDIC, '')","@FIELD_VALUE": IdNumber ,'@OPERATION':'EQ','@CONDITION':'AND'},
				{"@FIELD_NAME":'CONTRACTTYPE',"@FIELD_VALUE": this.proposalHeader.contractType ,'@OPERATION':'EQ','@CONDITION':'AND'},
				{"@FIELD_NAME":'EFFECTIVEDATE',"@FIELD_VALUE": this.proposalHeader.effectiveDate ,'@OPERATION':'EQ','@CONDITION':'AND'},
				{"@FIELD_NAME":'ENDDATE',"@FIELD_VALUE": this.proposalHeader.endDate ,'@OPERATION':'EQ','@CONDITION':'AND'},
				{"@FIELD_NAME":'INITIATED_ON',"@FIELD_VALUE": initiatedOn ,'@OPERATION':'LTEQ','@CONDITION':'AND'});
			this._cordysService.callCordysSoapService("GetLOVData","http://schemas.opentext.com/lovhandler/v1.0", request , this.channelConflictHandler, this.handleError, true, {comp:this});
			VK001 - END */
            //VK001 - Security Fix - Convertion of LOV to Service
            this._cordysService.callCordysSoapService("GetChannelConflictV2", "http://schemas.cordys.com/bmsintegrationapp", { "APPLICATION_NAME": "BMS", "STATUS": "Closed','Deleted", "CODE": code, "ID_NUMBER": IdNumber, "CONTRACTTYPE": this.proposalHeader.contractType, "EFFECTIVEDATE": this.proposalHeader.effectiveDate, "ENDDATE": this.proposalHeader.endDate, "INITIATED_ON": initiatedOn }, this.channelConflictHandler, this.handleError, true, { comp: this });
            //VK001 - END
        }
    }

    changeCheckBox(checkBox, type) {
        if (checkBox.checked) {
            if (type === 'CHANNELCONFLICT') {
                this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Channel conflict cannot be checked manually", -1));
                checkBox.checked = false;
                this.channelConflictIndicatorUI = false;
                this.proposal.newBusiness.headerInfo.channelConflictIndicator = "false";
            } else if (type === 'DUPLICATE') {
                this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Duplicate indicator cannot be checked manually", -1));
                checkBox.checked = false;
                this.duplicateIndicatorUI = false;
                this.proposal.newBusiness.headerInfo.duplicateIndicator = "false";
            }
        } else {
            // to handle pop-up close window option
            checkBox.checked = true;
            this.checkBoxRef = checkBox;
            // Create Process history record for resolving channel conflict
            let lookup = new ModalInput();
            lookup.component = ["CommonCommentDialogComponent", "app/bms/components/proposal/process/common.comment.dialog.module", "CommonCommentDialogModule"];
            if (type === 'CHANNELCONFLICT') {
                lookup.datainput = { dialogName: "resolve-channel-conflict" };
            } else if (type === 'DUPLICATE') {
                lookup.datainput = { dialogName: "resolve-duplicate" };
            }
            lookup.outputCallback = this.commonCommentDialogCallback;
            lookup.parentCompPRMS = { comp: this };
            if (type === 'CHANNELCONFLICT') {
                lookup.heading = "Enter Reason for channel conflict resolve";
            } else if (type === 'DUPLICATE') {
                lookup.heading = "Enter Reason for duplicate resolve";
            }
            lookup.icon = "fa fa-comment";
            lookup.containerRef = this.contentArea;
            this.dcl.openLookup(lookup);
        }
    }


    commonCommentDialogCallback(data, prms) {
        if (data.isDialogCancelled) {
            if (data.dialogName === 'resolve-channel-conflict') {
                prms.comp.checkBoxRef.checked = true;
                prms.comp.channelConflictIndicatorUI = true;
                prms.comp.proposal.newBusiness.headerInfo.channelConflictIndicator = "true";
                prms.comp.proposal.newBusiness.headerInfo.isConflictResolvedByUser = "false";
            } else if (data.dialogName === 'resolve-duplicate') {
                prms.comp.duplicateIndicatorUI = true;
                prms.comp.proposal.newBusiness.headerInfo.duplicateIndicator = "true";
                prms.comp.proposal.newBusiness.headerInfo.isConflictResolvedByUser = "false";
            }
            return;
        }
        else if (!data.isDialogCancelled && data.dialogName == "AML-CDD-Comments") {
            let commentsState = (prms.comp.proposal.newBusiness.headerInfo.AMLCDDComments.trim() != '') ? 'updated' : 'added';
            prms.comp.proposal.newBusiness.headerInfo.AMLCDDComments = data.comments;
            // prms.comp.proposal.newBusiness.headerInfo.AMLCDDCheck = "true";
            // prms.comp.proposal.newBusiness.headerInfo.AMLCDDCheckUI = true;
        }
        else {
            if (data.dialogName != "renewal-type-change" && prms.comp.checkBoxRef != undefined) {
                prms.comp.checkBoxRef.checked = false;
            }

            let historyObj = null;

            if (data.dialogName == "resolve-channel-conflict") {
                prms.comp.proposal.newBusiness.headerInfo.channelConflictIndicator = "false";
                prms.comp.proposal.newBusiness.headerInfo.isConflictResolvedByUser = "true";
                historyObj = { action: "Conflict Resolved", comment: data.comments, isPrivate: "", roleName: "", target: "SELF", targetType: "SELF", user: "", userName: "" };
            } else if (data.dialogName == "resolve-duplicate") {
                prms.comp.proposal.newBusiness.headerInfo.duplicateIndicator = "false";
                prms.comp.proposal.newBusiness.headerInfo.isConflictResolvedByUser = "true";
                historyObj = { action: "Duplicate Resolved", comment: data.comments, isPrivate: "", roleName: "", target: "SELF", targetType: "SELF", user: "", userName: "" };
            }
            else if (data.dialogName == "renewal-type-change") {
                historyObj = { action: "Renewal Type Changed", comment: data.comments, isPrivate: "", roleName: "", target: "SELF", targetType: "SELF", user: "", userName: "" };
            }
            if (prms.comp.loggedInUser == "") {
                prms.comp._aus.getUserFullName().subscribe((user) => {
                    prms.comp.loggedInUser = user;
                    historyObj.user = prms.comp.loggedInUser;
                    historyObj.userName = prms.comp.loggedInUser;
                    prms.comp.caseInfo.approvalInfo.addItem(historyObj);
                    prms.comp._appObjService.saveData().subscribe();
                });
            }
            else {
                historyObj.user = prms.comp.loggedInUser;
                historyObj.userName = prms.comp.loggedInUser;
                prms.comp.caseInfo.approvalInfo.addItem(historyObj);
                prms.comp._appObjService.saveData().subscribe();
            }
        }
    }

    getIdNo(): string {
        if (this.proposal.newBusiness.clientDetails) {
            if (this.proposal.newBusiness.clientDetails.client.genericDetails.clienttype == 'C')
                return this.proposal.newBusiness.clientDetails.client.corporateClientDetails.BusinessRegNo;
            else if (this.proposal.newBusiness.clientDetails.client.genericDetails.clienttype == 'P')
                if (this.proposal.newBusiness.clientDetails.client.personalClientDetails.NRICNo)
                    return this.proposal.newBusiness.clientDetails.client.personalClientDetails.NRICNo;
                else
                    return "";
        }
    }

    blackListSuccessHandler(response, prms) {
        if (response.tuple != null) {
            prms.comp.proposalHeader.blackListIndicator = "true";
            prms.comp.proposalHeader.blackListIndicatorUI = true;
            prms.comp.proposalHeader.blackListInternalIndicator = (response.tuple.old.ZBLCPF.ZIEIND == 'I') ? "Y" : "N";
            prms.comp.proposalHeader.blackListReason = response.tuple.old.ZBLCPF.REMARKS;
            prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Selected Client is BlackListed in Policy Inception Date.", 5000));
        }
        else {
            prms.comp.proposalHeader.blackListIndicator = "false";
            prms.comp.proposalHeader.blackListIndicatorUI = false;
            prms.comp.proposalHeader.blackListInternalIndicator = 'N';
        }
        prms.comp.setReferred(prms.comp);
    }

    channelConflictHandler(response, prms) {
        prms.comp.proposalHeader.channelConflictedCaseId = "";
        prms.comp.proposalHeader.channelConflictIndicator = "false";
        prms.comp.proposalHeader.duplicateIndicator = "false";
        prms.comp.channelConflictIndicatorUI = false;
        prms.comp.duplicateIndicatorUI = false;
        let ary = [];
        let count = 0;

        if (response.tuple != null && !Array.prototype.isPrototypeOf(response.tuple)) {
            ary = [response.tuple];
        }
        else if (response.tuple != null) {
            ary = response.tuple;
        }

        for (let item of ary) {
            count++;
            if (item.old.MSIG_BUSINESS_OBJECT && prms.comp.caseInfo.caseId != item.old.MSIG_BUSINESS_OBJECT.CASE_ID) {
                if (prms.comp.proposalHeader.agentCode == item.old.MSIG_BUSINESS_OBJECT.AGENTCODE) {
                    prms.comp.proposalHeader.duplicateIndicator = "true";
                    prms.comp.proposalHeader.channelConflictIndicator = "false";
                    prms.comp.duplicateIndicatorUI = true;
                    prms.comp.channelConflictIndicatorUI = false;
                    prms.comp.proposalHeader.channelConflictedCaseId = prms.comp.proposalHeader.channelConflictedCaseId + item.old.MSIG_BUSINESS_OBJECT.CASE_ID;
                } else {
                    if (prms.comp.proposal.newBusiness.clientDetails.client.genericDetails.clienttype == 'P') {
                        continue;
                    }
                    prms.comp.proposalHeader.channelConflictIndicator = "true";
                    prms.comp.proposalHeader.duplicateIndicator = "false";
                    prms.comp.channelConflictIndicatorUI = true;
                    prms.comp.duplicateIndicatorUI = false;
                    prms.comp.proposalHeader.channelConflictedCaseId = prms.comp.proposalHeader.channelConflictedCaseId + item.old.MSIG_BUSINESS_OBJECT.CASE_ID;
                }
                if (ary.length != count)
                    prms.comp.proposalHeader.channelConflictedCaseId = prms.comp.proposalHeader.channelConflictedCaseId + ",";
            } else if (prms.comp.proposalHeader.channelConflictedCaseId == "") {
                prms.comp.proposalHeader.channelConflictIndicator = "false";
                prms.comp.proposalHeader.duplicateIndicator = "false";
                prms.comp.channelConflictIndicatorUI = false;
                prms.comp.duplicateIndicatorUI = false;
                prms.comp.proposalHeader.channelConflictedCaseId = "";
            }
        }
        if (prms.comp.proposalHeader.channelConflictedCaseId.endsWith(",")) {
            prms.comp.proposalHeader.channelConflictedCaseId = prms.comp.proposalHeader.channelConflictedCaseId.substring(0, prms.comp.proposalHeader.channelConflictedCaseId.lastIndexOf(","));
        }
        if (prms.comp.duplicateIndicatorUI && BMSConstants.getBMSType() != BMSType.RenewalRerate && BMSConstants.getBMSType() != BMSType.Renewal) {
            // Display notification for duplicate indicator
            if (!prms.comp.notifDisplayed) {
                prms.comp.notifDisplayed = true;
                prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Duplicate case(s) identified", -1));
            }

        } else if (prms.comp.channelConflictIndicatorUI) {
            // Display notification for channel conflict indicator
            //prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Channel conflict identified" , -1));
        }
    }

    checkForJapaneseChannel(busChannelCode, subTier) {
        if (busChannelCode == "MF" || ["AJ", "BJ", "JC", "JD", "JCRHB", "JDRHB", "JCOCA", "JDOCA"].indexOf(subTier) != -1) {
            return "true";
        }
        return "false";
    }

    refreshAHList() {
        this.resetAHData();
        //AL001 START
        //this.getAccountHandler(this,false);	
        this.getAccountHandlerByBranchAndApplication(this, false);
        //AL001 END		
    }

    resetAHData() {
        this.ahList = [];
        this.caseInfo.accountHandler = null;
        this.proposalHeader.accountHandler = null;
        this.caseInfo.accountHandlerName = null;
    }

    getAccountHandler(comp, forceNotSetAH: boolean) {
        if (comp.ahList.length == 0 && comp.proposalHeader.handlingBranch != null && comp.proposalHeader.handlingBranch != "") {
            comp._cordysService.callCordysSoapService("GetAccountHandlersFromBranch", "http://schemas.cordys.com/msig/masterdata/1.0", { BRANCH_CODE: comp.proposalHeader.handlingBranch }, this.setAccountHandler, this.showAHError, true, { comp: comp, forceNotSetAH: forceNotSetAH });
        }
        else if (comp.ahList.length != 0 && forceNotSetAH == false) {
            comp.setDefaultAH(comp);
        }
    }

    //AL001 START - Redmine #1660 - Account handler by branch and application type
    getAccountHandlerByBranchAndApplication(comp, forceNotSetAH: boolean) {
        if (comp.ahList.length == 0 && comp.proposalHeader.handlingBranch != null && comp.proposalHeader.handlingBranch != "") {
            comp._cordysService.callCordysSoapService("GetAccountHandlersByBranchAndApplication", "http://schemas.cordys.com/msig/masterdata/1.0", { "BRANCH_CODE": comp.proposalHeader.handlingBranch, "APP_TYPE": 'BMS' }, this.setAccountHandler, this.showAHError, true, { comp: comp, forceNotSetAH: forceNotSetAH });

        }
        else if (comp.ahList.length != 0 && forceNotSetAH == false) {
            comp.setDefaultAH(comp);
        }
    }

    //AL001 END 

    setAHName(elmnt) {
        this.caseInfo.accountHandlerName = jQuery(elmnt).find("option:selected").text();
        if (event != null && event.target != null) {
            let ah: any = event.target;
            this.proposalHeader.accountHandler = ah.value;
            //Renewal fix for CSE 
            if (this.caseInfo.businessFunction == "Renewal" && ah.value != "" && ah.value != null) {
                this.getAHRole();
            }
        }
    }

    private getAHRole() {
        this._cordysService.callCordysSoapService("GetRolesForBranchLOBUser",
            "http://schemas.cordys.com/msig/masterdata/1.0",
            this.getGetAHRoleParams(),
            this.getAHRoleSuccessHandler,
            this.getAHRoleErrorHandler,
            true, this)
    }

    private getGetAHRoleParams() {
        return {
            "BRANCH_CODE": BMSConstants.getBMSObj().ApplicationBusinessObject.caseInfo.handlingBranchId,
            "LOB_CODE": BMSConstants.getBMSObj().ApplicationBusinessObject.caseInfo.lineOfBusiness,
            "USER_ID": BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.accountHandler,
            "APPLICATION": "BMS",
            "BUSINESS_FUNCTION": "NB"
        }
    }

    private getAHRoleSuccessHandler(data, scopeObject) {
        if (data.tuple) {
            BMSConstants.getBMSObj().ApplicationBusinessObject.processObject.accountHandlerRoleDn = data.tuple.old.MSIG_BRANCH_LOB_ROLE_USER_MAPPING.BRANCH_CODE + "_" + data.tuple.old.MSIG_BRANCH_LOB_ROLE_USER_MAPPING.LOB_CODE + "_" + data.tuple.old.MSIG_BRANCH_LOB_ROLE_USER_MAPPING.ROLE_CODE;
            BMSConstants.getBMSObj().ApplicationBusinessObject.processObject.caseHandlerRoleDn = "cn=" + BMSConstants.getBMSObj().ApplicationBusinessObject.processObject.accountHandlerRoleDn + ",cn=organizational roles," + scopeObject.orgDN;
        }

    }

    private getAHRoleErrorHandler(response, status, errorText, extraParams) {
        extraParams._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error getting the AH role", -1));
    }

    setDefaultAH(comp) {
        let deafultAH = comp.ahList.filter(ah => comp.proposalHeader.producerCode != null && ah.PRODUCER_CODE == comp.proposalHeader.producerCode);
        if (deafultAH != null && Array.prototype.isPrototypeOf(deafultAH) == true && deafultAH.length != 0) {
            let ah = deafultAH[0];
            comp.caseInfo.accountHandler = ah.USER_ID;
            comp.proposalHeader.accountHandler = ah.USER_ID;
            comp.caseInfo.accountHandlerName = ah.USER_FULL_NAME;
        }
        else {
            comp.caseInfo.accountHandler = "";
            comp.proposalHeader.accountHandler = "";
            comp.caseInfo.accountHandlerName = "";
        }
    }

    setAccountHandler(response, prms) {
        let ahItems = [];
        if (response.tuple != null && !Array.prototype.isPrototypeOf(response.tuple)) {
            ahItems = [response.tuple];
        }
        else if (response.tuple != null) {
            ahItems = response.tuple;
        }
        for (let ahinfo of ahItems) {
            let ah = new AHInfo(ahinfo.old.MSIG_BRANCH_LOB_ROLE_USER_MAPPING.USER_ID, ahinfo.old.MSIG_BRANCH_LOB_ROLE_USER_MAPPING.USER_FULL_NAME, ahinfo.old.MSIG_BRANCH_LOB_ROLE_USER_MAPPING.PRODUCER_CODE);
            prms.comp.ahList.push(ah);
        }
        if (prms.forceNotSetAH == false)
            prms.comp.setDefaultAH(prms.comp);
    }

    showAHError(error, prms) {

    }

    setPayPlan(checkBanca) {
        if (this.proposalHeader.contractType != null && this.proposalHeader.contractType != "") {
            if (checkBanca == true)
                this.proposalHeader.payPlan = "";
            let request: GetLOVData = new GetLOVData();
            request.BRANCH = 'ALL';
            request.LOB = 'ALL';
            request.BUSINESS_FUNCTION = 'NEW BUSINESS';
            request.PRODUCT = 'ALL';
            request.OPERATION = 'ALL';
            request.FORM_NAME = 'ALL';
            request.FORM_FIELD_NAME = 'PayPlan';
            request.FIELD_TYPE = 'LOV';
            request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
            request.ADVANCE_CONFIG_XML.FILTERS = new Filter();

            request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({ "@FIELD_NAME": 'A.DESCITEM', "@FIELD_VALUE": this.proposalHeader.contractType, '@OPERATION': 'EQ', '@CONDITION': 'AND' });
            let prom = this._cordysService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, null, null, true, null);
            prom.success((response) => this.payPlanHandler(response, checkBanca));
            prom.error((error) => this.showError(error));
        }
    }

    payPlanHandler(response, checkBanca) {
        let ppItems = [];
        ppItems = new AppUtil().getArray(response.tuple);
        this.payPlanList = [];
        for (let ppinfo of ppItems) {
            let pp = new PayPlanInfo(ppinfo.old.T3681.PAY_PLAN_VALUE, ppinfo.old.T3681.PAY_PLAN_DESC, ppinfo.old.T3681.PAYPLANSEQ);
            this.payPlanList.push(pp);
        }
        this.setDefaultPayPlan();
        if (checkBanca == true)
            this.checkBancaInfo(false);
    }

    setDefaultPayPlan() {
        if ((this.proposalHeader.payPlan == undefined || this.proposalHeader.payPlan == '') && this.payPlanList.length > 0) {
            this.proposalHeader.payPlan = this.payPlanList[0].PAY_PLAN_VALUE;
        }
    }

    getPayPlanSequence(payPlan) {
        let seq = -1;
        let correctPayPlan = [];
        if (this.payPlanList != null)
            correctPayPlan = this.payPlanList.filter((item) => item.PAY_PLAN_VALUE == payPlan);
        if (correctPayPlan.length > 0)
            seq = correctPayPlan[0].PAYPLANSEQ;
        return seq;
    }

    setRenewalType() {
        let prom = null;
        if (this.proposalHeader.contractType != null && this.proposalHeader.contractType != "") {
            let request: GetLOVData = new GetLOVData();
            request.BRANCH = 'ALL';
            request.LOB = 'ALL';
            request.BUSINESS_FUNCTION = 'NEW BUSINESS';
            request.PRODUCT = 'ALL';
            request.OPERATION = 'ALL';
            request.FORM_NAME = 'ALL';
            request.FORM_FIELD_NAME = 'RenewalType';
            request.FIELD_TYPE = 'LOV';
            request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
            request.ADVANCE_CONFIG_XML.FILTERS = new Filter();

            let _descItems = "'***','" + this.proposalHeader.contractType + "'";
            // request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({"@FIELD_NAME":'A.DESCITEM',"@FIELD_VALUE":this.proposalHeader.contractType ,'@OPERATION':'EQ','@CONDITION':'AND'});
            request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({ "@FIELD_NAME": 'A.DESCITEM', "@FIELD_VALUE": _descItems, '@OPERATION': 'IN', '@CONDITION': 'AND' });
            prom = this._cordysService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.renewalTypeHandler, this.handleError, true, { comp: this });
        }
        return prom;
    }

    renewalTypeHandler(response, prms) {
        let ppItems = [];

        if (response.tuple) {
            ppItems = new AppUtil().getArray(response.tuple);
        }

        prms.comp.rnlTypeList = [];

        if (ppItems.length > 0) {
            let _hasPPItemForProduct = ppItems.some(_item => _item.old.T4695.DESCITEM == prms.comp.proposalHeader.contractType);
            if (_hasPPItemForProduct) {
                ppItems = ppItems.filter(_item => _item.old.T4695.DESCITEM != '***');
            }
        }

        for (let ppinfo of ppItems) {
            let pp = new RenewalTypeInfo(ppinfo.old.T4695.RNLTYPE, ppinfo.old.T4695.RNLTYPEDESC, ppinfo.old.T4695.RNLTYPESEQ);
            prms.comp.rnlTypeList.push(pp);
        }
        if (prms.comp.rnlTypeList.length > 0)
            prms.comp.setDefaultRenewalType(prms.comp);
    }

    setDefaultRenewalType(comp) {
        if (comp.proposalHeader.renewalType == undefined || comp.proposalHeader.renewalType == '')
            comp.proposalHeader.renewalType = comp.rnlTypeList[0].RNL_TYPE_VALUE;
    }

    setNotificationType() {
        if (this.proposalHeader.contractType != null && this.proposalHeader.contractType != "") {
            let request: GetLOVData = new GetLOVData();
            request.BRANCH = 'ALL';
            request.LOB = 'ALL';
            request.BUSINESS_FUNCTION = 'NEW BUSINESS';
            request.PRODUCT = 'ALL';
            request.OPERATION = 'ALL';
            request.FORM_NAME = 'ALL';
            request.FORM_FIELD_NAME = 'NotificationType';
            request.FIELD_TYPE = 'LOV';
            request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
            request.ADVANCE_CONFIG_XML.FILTERS = new Filter();

            let _descItems = "'***','" + this.proposalHeader.contractType + "'";

            request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({ "@FIELD_NAME": 'A.DESCITEM', "@FIELD_VALUE": _descItems, '@OPERATION': 'IN', '@CONDITION': 'AND' },
                { "@FIELD_NAME": 'A.RNLTYPE', "@FIELD_VALUE": this.proposalHeader.renewalType, '@OPERATION': 'EQ', '@CONDITION': 'AND' });
            this._cordysService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.notificationTypeHandler, this.handleError, true, { comp: this });
        }
    }

    notificationTypeHandler(response, prms) {
        let notifItems = [];

        if (response.tuple) {
            notifItems = new AppUtil().getArray(response.tuple);
        }

        prms.comp.notificationTypeList = [];

        if (notifItems.length > 0) {
            let _hasItemForProduct = notifItems.some(_item => _item.old.T4695.DESCITEM == prms.comp.proposalHeader.contractType);

            if (_hasItemForProduct) {
                notifItems = notifItems.filter(_item => _item.old.T4695.DESCITEM != '***');
            }
        }

        for (let notifinfo of notifItems) {
            let pp = new NotificatTypeInfo(notifinfo.old.T4695.RNLTYPE, notifinfo.old.T4695.NOT_TYPE_VALUE, notifinfo.old.T4695.NOT_TYPE_DESC, notifinfo.old.T4695.RNLNOTSSEQ);
            prms.comp.notificationTypeList.push(pp);
        }
        if (prms.comp.notificationTypeList.length > 0)
            prms.comp.setDefaultNotificfationType(prms.comp);
    }

    setDefaultNotificfationType(comp) {
        if (comp.proposalHeader.renewalType) {
            for (let eachItem of comp.notificationTypeList) {
                if (eachItem["RNLTYPE"] != null && eachItem["RNLTYPE"] != "" && eachItem["RNLTYPE"] == comp.proposalHeader.renewalType && eachItem["RNLNOTSSEQ"] == "1") {
                    comp.proposalHeader.noticeType = eachItem["NOT_TYPE_VALUE"]
                }
            }
        }
    }

    hasRisks() {
        if (this.proposal.newBusiness.risks != null) {
            let risks = new RisksValidator(this.proposal.newBusiness.risks);
            return risks.hasRisks();
        }
        return false;
    }

    resetCoinsurance(value) {
        value = value ? 'Y' : 'N';
        this.proposalHeader.CoInsurance = value;
        this._coiService.resetCOI(value);
        //START E1003
        let riskType = new RiskArray().getArrayByRiskType(this.proposalHeader.contractType);
        let allrisks = this.proposal.newBusiness.risks[riskType];
        for (let eachRisk of allrisks) {
            if (eachRisk.clauses.clause.length > 0) {
                let rIndex = eachRisk.clauses.clause.map(function (item) { return item.clauseCode; }).indexOf("COIN");
                if (this.proposalHeader.CoInsurance == "N" && rIndex >= 0) {
                    eachRisk.clauses.clause.splice(rIndex, 1);
                    break;
                } else if (this.proposalHeader.CoInsurance == "Y" && rIndex == -1) {
                    this.coinClauseInfo(this, "COIN", eachRisk);
                }
            }
            else if (eachRisk.clauses.clause.length == 0 && this.proposalHeader.CoInsurance == "Y") {
                this.coinClauseInfo(this, "COIN", eachRisk);
            }
            break;
        }
    }

    coinClauseInfo(comp, clauseCode, eachRisk) {
        let tempRiskType = ( eachRisk.riskType != undefined && eachRisk.riskType.length < 3 ) ? eachRisk.riskType + " " : eachRisk.riskType;
        let filters = [
            { "@FIELD_NAME": 'DESCITEM', "@FIELD_VALUE": tempRiskType + clauseCode, '@OPERATION': 'EQ', '@CONDITION': 'AND' },
        ];
        let request: GetLOVData = new GetLOVData().getLovRequest('ALL', 'ALL', 'NEW BUSINESS', 'ALL', 'NEW', 'CLAUSE', 'ClauseDesc', 'LOV', filters, {}, null);
        this._cordysService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.clauseHandler, this.handleError, true, { comp: this, riskObj: eachRisk });
    }
    clauseHandler(response, prms) {
        if (response.tuple) {
            if (prms.comp.validClause(response.tuple.old.T4997.VALUE, "clauseCode", prms.riskObj.clauses.clause)) {
                prms.riskObj.clauses.clause.push({
                    "clauseCode": response.tuple.old.T4997.VALUE,
                    "description": response.tuple.old.T4997.DESCRIPTION,
                    "isDefaultClause": 'N'
                });
            }
        }
    }

    validClause(clauseCode, prop, ary) {
        if (ary) {
            for (let eachItem of ary) {
                if (eachItem[prop] != null && eachItem[prop] != "" && eachItem[prop] == clauseCode)
                    return false;
            }
        }
        return true;
    }

    //END E1003  

    //VK003 Marine Open Cover Changes
    isMarineSearch() {

        if (this.proposalHeader.contractType == "MAR" || this.proposalHeader.marineOpenCover == undefined || this.proposalHeader.marineOpenCover == '')
            return true;
        else false;
    }
    //VK003
    setMinForStartDate() {
        if (this.caseInfo.businessFunction != "Renewal" && this.caseInfo.businessFunction != "RenewalRerate" && this.caseInfo.businessFunction != "MiscCN") {
            if (this.startDateCtrl != null) {
                if (this.caseInfo.caseId == undefined || this.caseInfo.caseId == "") {
                    if (this.proposalHeader.lineOfBusiness && this.proposalHeader.lineOfBusiness != "MTR") {
                        this.startDateCtrl.setMinDate(moment().subtract(1, 'year').format(this.getDateFormat()), this.startDateCtrl.comp);
                    } else if (this.proposalHeader.lineOfBusiness && this.proposalHeader.lineOfBusiness == "MTR" && ["MSW", "MWP", "MPA", "DPA"].indexOf(this.proposalHeader.contractType) != -1) {
                        this.startDateCtrl.setMinDate(moment().subtract(1, 'year').format(this.getDateFormat()), this.startDateCtrl.comp);
                    } else {
                        if (["CVF", "HVF", "MTF", "MPF", "MCF"].indexOf(this.proposalHeader.contractType) != -1) {
                            this.startDateCtrl.setMinDate(moment().subtract(30, 'days').format(this.getDateFormat()), this.startDateCtrl.comp);
                        }
                        else {
                            this.startDateCtrl.setMinDate(moment().format(this.getDateFormat()), this.startDateCtrl.comp);
                        }
                    }
                } else {

                    if (["CVF", "HVF", "MTF", "MPF", "MCF"].indexOf(this.proposalHeader.contractType) != -1) {
                        this.startDateCtrl.setMinDate(moment(this.caseInfo.initiatedOn, "YYYY-MM-DD").subtract(30, 'days').format(this.getDateFormat()), this.startDateCtrl.comp);
                    } else {
                        if (this.proposalHeader.lineOfBusiness && this.proposalHeader.lineOfBusiness != "MTR") {
                            this.startDateCtrl.setMinDate(moment(this.caseInfo.initiatedOn).subtract(1, 'year').format(this.getDateFormat()), this.startDateCtrl.comp);
                        } else if (this.proposalHeader.lineOfBusiness && this.proposalHeader.lineOfBusiness == "MTR" && ["MSW", "MWP", "MPA", "DPA"].indexOf(this.proposalHeader.contractType) != -1) {
                            this.startDateCtrl.setMinDate(moment().subtract(1, 'year').format(this.getDateFormat()), this.startDateCtrl.comp);
                        } else {
                            if (this.proposalHeader.effectiveDate != '') {
                                if (moment(this.proposalHeader.effectiveDate, "YYYY-MM-DD") > moment()) {
                                    this.startDateCtrl.setMinDate(moment().format(this.getDateFormat()), this.startDateCtrl.comp);
                                }
                                else {
                                    this.startDateCtrl.setMinDate(moment(this.proposalHeader.effectiveDate, "YYYY-MM-DD").format(this.getDateFormat()), this.startDateCtrl.comp);
                                }
                            }

                        }
                    }

                }
            }
        }
    }

    setMinDateForFleetPolicy() {
        if (this.startDateCtrl != null) {
            if (this.caseInfo.caseId == undefined || this.caseInfo.caseId == "") {
                if (["CVF", "HVF", "MTF", "MPF", "MCF"].indexOf(this.proposalHeader.contractType) != -1) {
                    this.startDateCtrl.setMinDate(moment().subtract(30, 'days').format(this.getDateFormat()), this.startDateCtrl.comp);
                }
                else {
                    this.startDateCtrl.setMinDate(moment().format(this.getDateFormat()), this.startDateCtrl.comp);
                }
            }
            else {
                if (["CVF", "HVF", "MTF", "MPF", "MCF"].indexOf(this.proposalHeader.contractType) != -1) {
                    this.startDateCtrl.setMinDate(moment(this.caseInfo.initiatedOn, "YYYY-MM-DD").subtract(30, 'days').format(this.getDateFormat()), this.startDateCtrl.comp);
                }
                else {
                    this.setMinForStartDate();
                }
            }
        }
    }

    getDateFormat() {
        let dtFormat = ApplicationUtilService.DATE_TIME_FORMAT;
        return dtFormat.split(" ")[0];
    }

    setEndDate() {
        if (this.endDateCtrl != null) {
            if (["MAR"].indexOf(this.proposalHeader.contractType) != -1) {
                let _poiEffectiveDatePrevDate = moment(this.proposalHeader.effectiveDate, "YYYY-MM-DD").subtract(1, 'days').format("YYYY-MM-DD");
                this.endDateCtrl.setter(moment(_poiEffectiveDatePrevDate, "YYYY-MM-DD").add(3, 'months').format("YYYY-MM-DD"), "YYYY-MM-DD", this.endDateCtrl.comp);
            }
            else {
                //GA002 START
                //this.endDateCtrl.setter(moment(this.proposalHeader.effectiveDate, "YYYY-MM-DD").add(364, 'days').format("YYYY-MM-DD"),"YYYY-MM-DD",this.endDateCtrl.comp);				
                let endDate = moment(this.proposalHeader.effectiveDate, "YYYY-MM-DD").add(1, 'years').format("YYYY-MM-DD");
                endDate = moment(endDate, "YYYY-MM-DD").subtract(1, 'days').format("YYYY-MM-DD");
                this.endDateCtrl.setter(endDate, "YYYY-MM-DD", this.endDateCtrl.comp);
                //GA002 END
            }
        }
    }

    //VK002 Added Conditions for FIR,MIS,PA, MAR,MCA
    setStartDateMonthValidation() {
        if (this.proposalHeader.effectiveDate != null || this.proposalHeader.effectiveDate != "") {
            /* VK002 if((this.proposalHeader.effectiveDate != null || this.proposalHeader.effectiveDate != "")){    VK002 */
            if (this.proposalHeader.lineOfBusiness && ["PA", "MIS", "FIR"].indexOf(this.proposalHeader.lineOfBusiness) >= 0) {
                return;
            } else if (this.proposalHeader.contractType && ["MAR", "MCA", "PL", "PPL", "PP3"].indexOf(this.proposalHeader.contractType) >= 0) {
                return;
            }
            let difference = moment(this.proposalHeader.effectiveDate, "YYYY-MM-DD").diff(moment(moment(), "YYYY-MM-DD"));
            if (moment.duration(difference).asMonths() > 3) {
                this.setStartDate();
                this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Advance issuance limit can be only 3 months.", 10000));
                this.validateEndDate();
            }
        }
    }

    validateEndDate() {
        if ((this.proposalHeader.effectiveDate != null || this.proposalHeader.effectiveDate != "") && (this.proposalHeader.endDate != null || this.proposalHeader.endDate != "")) {
            //E1003 Start
            if (moment(this.proposalHeader.effectiveDate, "YYYY-MM-DD") >= moment(this.proposalHeader.endDate, "YYYY-MM-DD")) {
                this.setEndDate();
                this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "End Date can not be smaller than or equal to Effective Date.", 10000));
            }
            //E1003 End
            //VK002 Added Conditions for FIR,MIS,PA, MAR,MCA
            if ((this.proposalHeader.contractType && ["WC", "PI", "CAR", "EAR", "DDO", "DandO", "DPI", "GL", "PL", "PRL", "TCM", "WLL", "POL", "MAR", "MCA", "PL", "PPL", "PP3"].indexOf(this.proposalHeader.contractType) < 0) && ((this.proposalHeader.lineOfBusiness && ["PA", "MIS", "FIR"].indexOf(this.proposalHeader.lineOfBusiness) < 0) || (this.proposalHeader.contractType && ["OSS", "OSI"].indexOf(this.proposalHeader.contractType) >= 0))) { //Redmine - 2020,2021, Redmine#2701-PL 
                let _allowedMonths = (this.proposalHeader.contractType && this.proposalHeader.contractType == 'OSI') ? 36 : 18;

                let difference = moment(this.proposalHeader.endDate, "YYYY-MM-DD").diff(moment(this.proposalHeader.effectiveDate, "YYYY-MM-DD"));
                if (moment.duration(difference).asMonths() > _allowedMonths) {
                    this.setEndDate();
                    this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Date difference can not be more than " + _allowedMonths + " months.", 10000));
                }
            }
            //VK002 Added Conditions for FIR,MIS,PA, MAR,MCA 
            if ((this.proposalHeader.contractType && ["PL", "PPL", "PP3", "ME", "EP", "CAR", "EAR", "MAR", "MCA", "PL", "PPL", "PP3"].indexOf(this.proposalHeader.contractType) >= 0) || ((this.proposalHeader.lineOfBusiness && ["PA", "MIS", "FIR"].indexOf(this.proposalHeader.lineOfBusiness) >= 0))) {
                this.setReferred(this);
            }
			/*/VK002
			if( this.proposalHeader.contractType && ["WC","PI","CAR","EAR","DDO","DandO","DPI","GL","PL","PRL","TCM","WLL","POL"].indexOf(this.proposalHeader.contractType) < 0 ){ //Redmine - 2020,2021, Redmine#2701-PL 
				let _allowedMonths = (this.proposalHeader.contractType && this.proposalHeader.contractType == 'OSI') ? 36 : 18;
			
				let difference  = moment(this.proposalHeader.endDate,"YYYY-MM-DD").diff(moment(this.proposalHeader.effectiveDate,"YYYY-MM-DD"));
				
				if(moment.duration(difference).asMonths() > _allowedMonths){
					this.setEndDate();
					this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Date difference can not be more than "+_allowedMonths+" months." , 10000));
				}
			}
			
			if( this.proposalHeader.contractType && ["PL","PPL","PP3","ME","EP","CAR","EAR"].indexOf(this.proposalHeader.contractType) >= 0 ){
				this.setReferred(this);
			}
			//VK002 END */
        }
    }

    setStartDate() {
        if (this.startDateCtrl != null)
            this.startDateCtrl.setter(moment(new Date().toISOString(), "YYYY-MM-DD").format("YYYY-MM-DD"), "YYYY-MM-DD", this.startDateCtrl.comp);
    }

    emitPeroid(effOrEnd) {
        if (this.inceptionDateChanged == true || this.entDateChanged == true) {
            this._rtService.setListLock();
            this.mergePOIContractChange();
            this.onpoichange.emit();
        }
    }

    launchAppChangeConfirm(values) {

        if (this.hasRisks() == true) {
            this.productCtrl.setter(this.proposalHeader.contractType, this.productCtrl.comp);
            this.confirmAppChange("Changing product will clear all the risks added in the risk table. Do you still want to continue?", values);
            // E1009 Start
            if (document.getElementById("rebateinput") != null) {
                if (this.proposalHeader.contractType == 'MPD') {
                    document.getElementById("rebateinput").getElementsByTagName("input")[0].setAttribute("disabled", "true")
                }
                else {
                    document.getElementById("rebateinput").getElementsByTagName("input")[0].removeAttribute("disabled");
                }
            }
            // E1009 End
        }
        else {
            this.proposalHeader.contractType = values.value;
            this.setProductDetails(values);
            // E1009 Start
            if (document.getElementById("rebateinput") != null) {
                if (this.proposalHeader.contractType == 'MPD') {
                    document.getElementById("rebateinput").getElementsByTagName("input")[0].setAttribute("disabled", "true")
                }
                else {
                    document.getElementById("rebateinput").getElementsByTagName("input")[0].removeAttribute("disabled");
                }
            }
            // E1009 End
            if (this.proposalHeader.contractType == 'MPA' && this.proposalHeader.insuredType == 'Corporate') {
                this.resetClientInfo();
            }
            //			else if((this.proposalHeader.contractType == 'MSW'||this.proposalHeader.contractType == 'MWP') && this.proposalHeader.insuredType=='Personal'){
            //                this.resetClientInfo();
            //            }
        }
        this.resetHighRiskNumbers();//GA005
    }

    //GA001 START
    resetHighRiskNumbers() {
        if (this.proposalHeader.isHighRiskApplicable) {

            if(this.proposalHeader.highRiskIndicatorReasons!=undefined && this.proposalHeader.highRiskIndicatorReasons.highRiskIndReason.length>0){
                this.proposalHeader.highRiskIndicatorReasons.highRiskIndReason = this.proposalHeader.highRiskIndicatorReasons.highRiskIndReason.filter((item) => (Number(item.riskNumber) <1));
            }
            if(!(this.proposalHeader.highRiskIndicatorReasons!=undefined && this.proposalHeader.highRiskIndicatorReasons.highRiskIndReason.length>0) ){
                this.proposalHeader.highRiskIndicator = "false"; 
                this.proposalHeader.highRiskIndicatorUI = false;
                this.proposalHeader.highRiskInsuredInternalInd = "";
                this.proposalHeader.highRiskNomineeInternalInd = "";
                this.proposalHeader.highRiskDriverInternalInd = "";
                this.proposalHeader.highRiskVehicleIndicator = "";
            }
        }
    }
    //GA001 END

    resetClientInfo() {
        this.insuredPersonType = '';
        this.proposalHeader.insuredType = '';
        this.proposal.newBusiness.clientDetails = new ClientDetails();
        this.proposalHeader.insuredNumber = '';
        this.proposalHeader.insuredName = '';
        this.proposalHeader.insuredAge = 0;
    }

    private confirmAppChange(message: string, values) {
        let inputObj = {
            "Message": message
        };
        let lookup = new ModalInput();
        lookup.component = ["Confirm", "app/common/components/utility/confirmmessage/confirm.module", "ConfirmModule"];
        lookup.datainput = inputObj;
        lookup.outputCallback = null;
        lookup.parentCompPRMS = {
            comp: this,
            values: values
        };
        lookup.heading = "User Confirmation";
        lookup.icon = "fa fa-hand-paper-o";
        lookup.containerRef = this.contentArea;
        this.dcl.openLookup(lookup).subscribe((data) => {
            this.appChangeDecision(data, values);
        });

    }

    private appChangeDecision(data, values) {
        if (data.data.value == 'Y') {
            this.proposalHeader.marineOpenCover = "";
            this.proposalHeader.contractType = values.value;
            this.setProductDetails(values);

            if (this.proposalHeader.contractType == 'MPA' && this.proposalHeader.insuredType == 'Corporate') {
                this.resetClientInfo();
            }
        }
        else {
            if (this.productCtrl != null) {
                this.productCtrl.setter(this.proposalHeader.contractType, this.productCtrl.comp);
            }
        }
    }

    //GA001 START
    private confirmInceptionDtChange(message: string, values) {
        let inputObj = {
            "Message": message
        };
        let lookup = new ModalInput();
        lookup.component = ["Confirm", "app/common/components/utility/confirmmessage/confirm.module", "ConfirmModule"];
        lookup.datainput = inputObj;
        lookup.outputCallback = null;
        lookup.parentCompPRMS = {
            comp: this,
            values: values
        };
        lookup.heading = "User Confirmation";
        lookup.icon = "fa fa-hand-paper-o";
        lookup.containerRef = this.contentArea;
        this.dcl.openLookup(lookup).subscribe((data) => {
            this.inceptionDtChangeDecision(data, values);
        });

    }

    private inceptionDtChangeDecision(data, values) {
        if (this.proposalHeader.contractType == 'TAA' || this.proposalHeader.contractType == 'TDA') {
            if (data.data.value == 'Y') {
                this._rtService.resetRiskList(true);
            } else {
                this.proposalHeader.effectiveDate = values;
                if (this.startDateCtrl != null)
                    this.startDateCtrl.setter(moment(values, "YYYY-MM-DD").format("YYYY-MM-DD"), "YYYY-MM-DD", this.startDateCtrl.comp);
            }
        }
    }
    //GA001 END

    checkBancaForPayPlanUI(payPlan) {
        this.proposalHeader.payPlan = payPlan;
        this.checkBancaInfo(false);
    }

    isInceptionDateChanged(newValue) {
        if (this.proposalHeader.effectiveDate != newValue)
            this.inceptionDateChanged = true;
        else
            this.inceptionDateChanged = false;

        //SST code
        if (this.inceptionDateChanged) {
            //GA002 START
            //let expiryDate = moment(newValue, "YYYY-MM-DD").add(364, 'days').format("YYYY-MM-DD");
            let expiryDate = moment(newValue, "YYYY-MM-DD").add(1, 'years').format("YYYY-MM-DD");
            expiryDate = moment(expiryDate, "YYYY-MM-DD").subtract(1, 'days').format("YYYY-MM-DD");
            //GA002 END
            this.proposalHeader.effectiveDate = newValue;
            this.proposalHeader.endDate = expiryDate;
            let respObj = this._bus.getTAXDetails();
            if (respObj != undefined && respObj != "") {
                this.proposalHeader.SSTTaxRate = Number(respObj[0].old.ITEMPF.GST);
                this.proposalHeader.GSTTaxRate = Number(respObj[1].old.ITEMPF.GST);
            }
        }
        //End
    }

    isEndDateChanged(newValue) {
        if (this.proposalHeader.endDate != newValue)
            this.entDateChanged = true;
        else
            this.entDateChanged = false;
    }

    openLongNameLookup() {
        let input = new ModalInput();
        input.parentCompPRMS = { comp: this };
        input.heading = "Insured Long Name";
        input.datainput = { proposalHeader: this.proposalHeader, isViewMode: this.disableForm };
        input.component = ["LNComponent", "app/bms/components/proposal/proposalheader/dialogs/ln.module", "LNModule"];
        input.icon = "fa fa-file-pdf-o";
        input.containerRef = this.contentArea;
        this.dcl.openLookup(input);
    }

    openRefReason() {
        let input = new ModalInput();
        input.parentCompPRMS = { comp: this };
        input.heading = "Reason For Policy Referred";
        input.datainput = { newBusiness: this.proposal.newBusiness };
        input.component = ["ReferredReasonComponent", "app/bms/components/proposal/proposalheader/dialogs/referredreason.module", "ReferredReasonModule"];
        input.icon = "fa fa-file-pdf-o";
        input.containerRef = this.contentArea;
        this.dcl.openLookup(input);
    }

    onMasterPolicyChange(ev) {
        //E1002 Start
        if (this.proposalHeader.contractType != 'TDA')
            this._rtService.resetStampDuty().subscribe((data) => BMSConstants.getNewBusinessInfo().resetAllPremCalc());
        //E1002 End	
    }

    resetBanca(optionVal) {
        optionVal = optionVal ? 'Y' : 'N';
        this.proposalHeader.bancaRequired = optionVal;
        this._bancaService.resetBanca(optionVal);
        this.proposalHeader.handleFlags();
    }

    checkBancaInfo(isByButton) {
        this._bancaService.checkBancaInfo(this.proposalHeader.effectiveDate, this.proposalHeader.agentCode, this.proposalHeader.contractType, this.proposalHeader.payPlan, this.getPayPlanSequence(this.proposalHeader.payPlan)).subscribe((data) => {
            if (isByButton == true)
                this._alertMsgService.add(new AlertMessage(AlertMessage.INFO, "Banca is checked successfully.", -1));
            this.checkUOBInfo();
            this.proposalHeader.handleFlags();
        });
    }

    checkUOBInfo() {
        this._bancaService.resetUOBInfo(this.proposalHeader.contractType, this.proposalHeader.renewalType, this.proposalHeader.agentCode).subscribe();
    }

    checkManuscript(manVal) {
        this.proposalHeader.manuscript = manVal ? 'Y' : 'N';
        this.proposalHeader.setRIMethod();
        this.setReferred(this);
    }

    setRIMethod(riVal) {
        if (riVal == "No") {
            this.proposalHeader.RIType = "";
            this.proposalHeader.RIReason = "";
        }
    }

    setReferred(comp) {
        comp._rcls.setRiskClassification("", "Y", "", "").subscribe();
    }
    openAMLCDDComments() {
        if (this.proposalHeader.AMLCDDCheck == "true") {
            let lookup = new ModalInput();
            lookup.component = ["CommonCommentDialogComponent", "app/bms/components/proposal/process/common.comment.dialog.module", "CommonCommentDialogModule"];
            lookup.datainput = { dialogName: "AML-CDD-Comments", DNComments: this.proposalHeader.AMLCDDComments };
            lookup.outputCallback = this.commonCommentDialogCallback;
            lookup.parentCompPRMS = { comp: this };
            lookup.heading = "Enter AML Customer Due Diligence Comments";
            lookup.icon = "fa fa-comment";
            lookup.containerRef = this.contentArea;
            this.dcl.openLookup(lookup);
        }

    }

    openHighRiskCusDialog() {
        if (this.proposalHeader.HighRiskCus == "Y") {
            let lookup = new ModalInput();
            lookup.component = ["HRCComponent", "app/bms/components/proposal/proposalheader/dialogs/hrc.module", "HRCModule"];
            lookup.heading = "High Risk Customer";
            lookup.datainput = { proposalHeader: this.proposalHeader, isQuotationCompleted: BMSConstants.isQuotationCompleted() };
            lookup.icon = "fa fa-comment";
            lookup.containerRef = this.contentArea;
            this.dcl.openLookup(lookup);
        }

    }

    openRIPage() {
        let disable = (this.proposalHeader.RIRequiredHeader == 'No' || this.proposalHeader.isApprovalCompleted == 'Y') ? true : false;
        let lookup = new ModalInput();
        lookup.component = ["RIComponent", "app/bms/components/proposal/proposalheader/dialogs/ri.module", "RIModule"];
        lookup.heading = "RI Type";
        lookup.datainput = { proposalHeader: this.proposalHeader, disable: disable };
        lookup.icon = "fa fa-comment";
        lookup.containerRef = this.contentArea;
        this.dcl.openLookup(lookup).subscribe(() => {
            this.proposalHeader.setRIMethod();
        });

    }

    openDuplicates() {
        event.preventDefault();
        if (this.duplicateIndicatorUI == true) {
            let lookup = new ModalInput();
            lookup.component = ["DuplicateComponent", "app/bms/components/proposal/proposalheader/dialogs/duplicate.module", "DuplicateModule"];
            lookup.heading = "Duplicate Cases";
            lookup.datainput = { proposalHeader: this.proposalHeader };
            lookup.icon = "fa fa-comment";
            lookup.containerRef = this.contentArea;
            this.dcl.openLookup(lookup);
        }
    }

    openConflicts() {
        event.preventDefault();
        if (this.channelConflictIndicatorUI == true) {
            let lookup = new ModalInput();
            lookup.component = ["DuplicateComponent", "app/bms/components/proposal/proposalheader/dialogs/duplicate.module", "DuplicateModule"];
            lookup.heading = "Channel Conflict Cases";
            lookup.datainput = { proposalHeader: this.proposalHeader };
            lookup.icon = "fa fa-comment";
            lookup.containerRef = this.contentArea;
            this.dcl.openLookup(lookup);
        }
    }

    onAMLCDDcheck(value) {
        this.proposalHeader.AMLCDDCheck = value ? 'true' : 'false';
        if (value == true)
            this.openAMLCDDComments();
    }

    onHighRiskCuscheck(value) {
        this.proposalHeader.HighRiskCus = value ? 'Y' : 'N';
        if (value == true)
            this.openHighRiskCusDialog();
        else {
            this.proposalHeader.HighRiskCusType = "";
            this.proposalHeader.HighRiskCusComments = "";
            this.proposalHeader.HighRiskCEOApproval = "N";
        }
    }

    //GA001 START
    private TravelPlansBenefitsRefresh(value) {
        if (this.hasRisks() && this.inceptionDateChanged && (this.proposalHeader.contractType == 'TAA' || this.proposalHeader.contractType == 'TDA')) {
            this.confirmInceptionDtChange("Changing Inception Date will clear all the risks added in the risk table. Do you still want to continue?", value);
        }
    }
    //GA001 END

    // E1001 START
    private callbackCampignCodes(scopeObject) {
        if (this.caseInfo.businessFunction == "Renewal" || this.caseInfo.businessFunction == "RenewalRerate") {

            if (scopeObject.lovDropDownService.lovDataList.CampignCode != null && scopeObject.lovDropDownService.lovDataList.CampignCode != undefined
                && scopeObject.lovDropDownService.lovDataList.CampignCode.length > 0) {
                let campaignCode = scopeObject.lovDropDownService.lovDataList.CampignCode.find(camp => camp.VALUE == scopeObject.proposalHeader.campaign);

                if (campaignCode == null || campaignCode == undefined) {
                    scopeObject.proposalHeader.campaign = "";
                }
            }

        }
    }
    // E1001 END
    //KU001 START
    private confirmAgentChange(message: string, values) {
        let inputObj = {
            "Message": message
        };
        let lookup = new ModalInput();
        lookup.component = ["Confirm", "app/common/components/utility/confirmmessage/confirm.module", "ConfirmModule"];
        lookup.datainput = inputObj;
        lookup.outputCallback = null;
        lookup.parentCompPRMS = {
            comp: this,
            values: values
        };
        lookup.heading = "User Confirmation";
        lookup.icon = "fa fa-hand-paper-o";
        lookup.containerRef = this.contentArea;
        this.dcl.openLookup(lookup).subscribe((data) => {
            this.AgentChangeDecision(data, values);
        });

    }

    private AgentChangeDecision(data, values) {
        if (this.proposalHeader.contractType == 'MPC') {
            if (data.data.value == 'Y') {
                this.setAgent(values);
                this.checkBancaInfo(false);
                this._rtService.resetRiskList(true);

            } else {

            }
        }
    }
    checkFluxAgentOrNot(agentCodeTocheck) {
        let agentCode = agentCodeTocheck;
        let request: GetLOVData = new GetLOVData();
        request.BRANCH = 'ALL';
        request.LOB = 'MOTOR';
        request.BUSINESS_FUNCTION = 'ALL';
        request.PRODUCT = 'ALL';
        request.OPERATION = 'ALL';
        request.FORM_NAME = 'PRIVATE_MOTOR';
        request.FORM_FIELD_NAME = 'fluxAgentList1';
        request.FIELD_TYPE = 'LOV';
        request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        request.ADVANCE_CONFIG_XML.FILTERS = new Filter();

        request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({ "@FIELD_NAME": 'PFAGNT', "@FIELD_VALUE": agentCode, '@OPERATION': 'LIKE', '@CONDITION': 'AND' });
        this._cordysService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.successOfFluxAgent, this.handleError, false, { comp: this });
    }
    private successOfFluxAgent(data, prms) {
        if (data && data.tuple && data.tuple.old && data.tuple.old.T9192GA) {
            prms.comp.NewAgentType = true;
        } else {
            prms.comp.NewAgentType = false;
        }
    }
    checkOldAgentType() {
        let agentCode = this.proposalHeader.agentCode;
        let request: GetLOVData = new GetLOVData();
        request.BRANCH = 'ALL';
        request.LOB = 'MOTOR';
        request.BUSINESS_FUNCTION = 'ALL';
        request.PRODUCT = 'ALL';
        request.OPERATION = 'ALL';
        request.FORM_NAME = 'PRIVATE_MOTOR';
        request.FORM_FIELD_NAME = 'fluxAgentList1';
        request.FIELD_TYPE = 'LOV';
        request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        request.ADVANCE_CONFIG_XML.FILTERS = new Filter();

        request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push({ "@FIELD_NAME": 'PFAGNT', "@FIELD_VALUE": agentCode, '@OPERATION': 'LIKE', '@CONDITION': 'AND' });
        this._cordysService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.successOfOldAgent, this.handleError, false, { comp: this });
    }
    private successOfOldAgent(data, prms) {
        if (data && data.tuple && data.tuple.old && data.tuple.old.T9192GA) {
            prms.comp.OldAgentType = true;
        } else {
            prms.comp.OldAgentType = false;
        }
    }
    //KU001 END

    //pku
    setCCMOpsScreen() {
        let filters = [
            { "@FIELD_NAME": 'ZFLAG04A', "@FIELD_VALUE": 'Y', '@OPERATION': 'EQ', '@CONDITION': 'AND' },
            { "@FIELD_NAME": '', "@FIELD_VALUE": '', '@OPERATION': 'OPNPRNTHS', '@CONDITION': 'OR' },
            { "@FIELD_NAME": 'RTRIM(DESCITEM)', "@FIELD_VALUE": this.proposalHeader.contractType, '@OPERATION': 'EQ', '@CONDITION': 'OR' },
            { "@FIELD_NAME": 'RTRIM(DESCITEM)', "@FIELD_VALUE": '*ALL', '@OPERATION': 'EQ', '@CONDITION': '' },
            { "@FIELD_NAME": '', "@FIELD_VALUE": '', '@OPERATION': 'CLSPRNTHS', '@CONDITION': 'AND' }
        ];
        let request: GetLOVData = new GetLOVData().getLovRequest('ALL', 'ALL', 'NEW BUSINESS', 'ALL', 'ALL', 'CCM_PARAMS', 'CCM_Output_Print', 'LOV', filters, {}, null);
        this._cordysService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.setCCMOpsSuccessHandler, this.handleError, false, { comp: this });
    }

    setCCMOpsSuccessHandler(response, prms) {
        if (response.tuple) {
            let ary = [];
            if (response.tuple != null && !Array.prototype.isPrototypeOf(response.tuple)) {
                ary = [response.tuple];
            } else {
                ary = response.tuple;
            }
            if (ary.length > 0) {
                prms.comp.proposalHeader.showCCMOps = true;
            } else {
                prms.comp.proposalHeader.showCCMOps = false;
                prms.comp.proposalHeader.ccmOPSs = new CcmOPSs();
            }
        } else {
            prms.comp.proposalHeader.showCCMOps = false;
            prms.comp.proposalHeader.ccmOPSs = new CcmOPSs();
        }
    }//End
}
export class AHInfo {
    constructor(public USER_ID: string,
        public USER_FULL_NAME: string,
        public PRODUCER_CODE: string) { }
}

export class PayPlanInfo {
    constructor(public PAY_PLAN_VALUE: string,
        public PAY_PLAN_DESC: string,
        public PAYPLANSEQ: string) { }
}

export class RenewalTypeInfo {
    constructor(public RNL_TYPE_VALUE: string,
        public RNL_TYPE_DESC: string,
        public RNLTYPESEQ: string) { }
}

export class NotificatTypeInfo {
    constructor(public RNLTYPE: string,
        public NOT_TYPE_VALUE: string,
        public NOT_TYPE_DESC: string,
        public RNLNOTSSEQ: string) { }
}