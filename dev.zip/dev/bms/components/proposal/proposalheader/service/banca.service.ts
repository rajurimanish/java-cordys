import { Injectable } from '@angular/core';
declare var Rx: any;
declare var Observer: any;
import { CordysSoapWService } from "../../../../../common/components/utility/cordys-soap-ws";
import { GetLOVData, SearchAdvancedConfig, Filter } from '../../../../../common/components/utility/search/search.requests';
import { BMSConstants } from '../../../common/constants/bms_constants';
import { AppUtil } from '../../../../../common/components/utility/apputil/app.util';
import { ApplicationUtilService } from "../../../../../common/services/application.util.service";
import { BMSLOVRequest } from '../../../common/service/lov/bms.lovrequest';
import { PeriodicDebitDetails } from '../appobjects/proposalheader';
import { AlertMessagesService } from '../../../../../common/components/utility/alertmessage/alertmessages.service';
import { AlertMessage } from '../../../../../common/components/utility/alertmessage/alertmessages.model';

declare var jQuery: any;
declare var moment: any;

@Injectable()
export class BancaService {

    constructor(private _cordysService: CordysSoapWService, public _alertMsgService: AlertMessagesService) { }

    public getBancaInfo(effectiveDate, agentCode, contractType, payPlan, payPlanSequence) {
        return Rx.Observable.create((observer) => {
            let prom = this._cordysService.callCordysSoapService("getBancaInfo", "http://schemas.insurance.com/businessobject/1.0/", { effectiveDate: effectiveDate, agentCode: agentCode, contractType: contractType, payPlan: payPlan, payPlanSequence: payPlanSequence }, null, null, true, null);
            prom.success((data) => this.handleBancaSuccess(data, observer));
            prom.error((data) => this.handleError(data, observer));
        });
    }

    public handleBancaSuccess(data, observer) {
        observer.next({ isBancaMandatory: data.isBancaMandatory.text, isCheckFailed: data.isCheckFailed.text, payPlanValue: data.payPlanValue.text });
    }

    public handleError(data, observer) {
        observer.error("");
    }

    public resetBanca(optionVal) {
        let proposalHeader = BMSConstants.getBMSHeaderInfo();
        if (optionVal == 'Y') {
            if (proposalHeader.periodicDebitDetails == null) {
                proposalHeader.periodicDebitDetails = new PeriodicDebitDetails();
                this.defaultPayorId();
            }
        }
        else {
            proposalHeader.periodicDebitDetails = null;
            proposalHeader.bancaRequired = "N";
            proposalHeader.branchCodeForBanca = "";
        }
        proposalHeader.bancaRequired = optionVal;
    }

    public defaultPayorId() {
        let proposalHeader = BMSConstants.getBMSHeaderInfo();
        if (AppUtil.isEmpty(proposalHeader.periodicDebitDetails, false) == false) {
            proposalHeader.periodicDebitDetails.payerNumber = proposalHeader.insuredNumber;
            proposalHeader.periodicDebitDetails.payerName = proposalHeader.insuredName;
        }

    }

    public checkBancaInfo(effectiveDate, agentCode, contractType, payPlan, payPlanSequence) {
        return Rx.Observable.create((observer) => {
            let proposalHeader = BMSConstants.getBMSHeaderInfo();
            proposalHeader.branchCodeForBanca = "";
            if (AppUtil.isEmpty([effectiveDate, agentCode, contractType, payPlan, payPlanSequence], true) == false) {
                this.getBancaInfo(effectiveDate, agentCode, contractType, payPlan, payPlanSequence).subscribe((data) => {
                    if (data) {
                        proposalHeader.branchCodeForBanca = data.branchCodeForBanca;
                        if (data.isCheckFailed == "N") {
                            proposalHeader.sysBancaValidation = data.isBancaMandatory;
                            proposalHeader.payPlan = data.payPlanValue;
                            proposalHeader.isBancaValidationFailed = data.isCheckFailed;
                            if (proposalHeader.sysBancaValidation == "O")
                                this.resetBanca("N");
                            else
                                this.resetBanca(proposalHeader.sysBancaValidation);
                        }
                        else {
                            this.setBancaCheckError(observer);
                        }
                    }
                    observer.next(proposalHeader.bancaRequired);
                },
                    (error) => {
                        this.setBancaCheckError(observer);
                    });
            }
            else
                observer.next("N");
        });
    }

    public setBancaCheckError(observer) {
        this.resetBanca("N");
        let proposalHeader = BMSConstants.getBMSHeaderInfo();
        proposalHeader.isBancaValidationFailed = "Y";
        this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Banca validation failed. Click 'Check Banca' in header to resolve the problem or contact the administrator.", -1));
        observer.error("N");
    }

    public checkUOB(product, renewalType, agentCode) {
        return Rx.Observable.create((observer) => {
            let prom = this._cordysService.callCordysSoapService("getUOBInfo", "http://schemas.insurance.com/businessobject/1.0/", { product: new AppUtil().getRiskCode(product), renewalType: renewalType, agentCode: agentCode }, null, null, true, null);
            prom.success((data) => this.handleUOBSuccess(data, observer));
            prom.error((data) => this.handleError(data, observer));
        });
    }

    public handleUOBSuccess(data, observer) {
        observer.next({ isUOBRequired: data.isUOBRequired.text });
    }

    public setUOBDetails(isUOBRequired) {
        let proposalHeader = BMSConstants.getBMSHeaderInfo();
        proposalHeader.isUOBMandatory = isUOBRequired;
    }

    public resetUOBInfo(product, renewalType, agentCode) {
        return Rx.Observable.create((observer) => {
            if (AppUtil.isEmpty([product, renewalType, agentCode], true) == false) {
                this.checkUOB(product, renewalType, agentCode).subscribe((data) => {
                    this.setUOBDetails(data.isUOBRequired);
                    observer.next(data.isUOBRequired);
                },
                    (error) => {
                        this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error occurred while checking whether UOB is mandatory.", -1));
                        observer.error("");
                    });
            }
            else {
                this.setUOBDetails("O");
                observer.next("O");
            }
        });
    }
}