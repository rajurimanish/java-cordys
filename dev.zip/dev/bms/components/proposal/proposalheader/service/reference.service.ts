import { Injectable } from '@angular/core';
declare var Rx: any;
declare var Observer: any;
import { CordysSoapWService } from "../../../../../common/components/utility/cordys-soap-ws";
import { GetLOVData, SearchAdvancedConfig, Filter } from '../../../../../common/components/utility/search/search.requests';
import { BMSConstants } from '../../../common/constants/bms_constants';
import { BMSType } from '../../../common/constants/bms_types';
import { AppUtil } from '../../../../../common/components/utility/apputil/app.util';
import { ApplicationUtilService } from "../../../../../common/services/application.util.service";
import { BMSLOVRequest } from '../../../common/service/lov/bms.lovrequest';
import { AlertMessagesService } from '../../../../../common/components/utility/alertmessage/alertmessages.service';
import { AlertMessage } from '../../../../../common/components/utility/alertmessage/alertmessages.model';

declare var jQuery: any;
declare var moment: any;

@Injectable()
export class ReferenceService {

    constructor(private _cordysService: CordysSoapWService, public _alertMsgService: AlertMessagesService) { }

    public getRestrictedCedings() {
        return Rx.Observable.create((observer) => {
            let ceding = { "key": "/com/msig/insurance/exceptions/ceding_reference.xml" };
            let prom = this._cordysService.callCordysSoapService("GetXMLObject", "http://schemas.cordys.com/1.0/xmlstore", ceding, null, null, true, null);
            prom.success((resp) => {
                let list = [];
                let restObj = AppUtil.getValueByPath(resp, "tuple.old.config.restricted." + BMSType[BMSConstants.getBMSType()]);
                if (AppUtil.isNull(restObj, false) == false)
                    list = new AppUtil().getArray(restObj.type);
                observer.next(list);
            });
            prom.error((resp) => {
                this.cedError(resp, observer);
            });
        });
    }

    cedError(resp, observer) {
        this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error occurred while checking ceding restriction list.", -1));
        observer.error("");
    }
}