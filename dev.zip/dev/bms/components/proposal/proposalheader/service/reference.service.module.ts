import { NgModule } from '@angular/core';
import { ReferenceService } from './reference.service';

@NgModule({
    providers: [ReferenceService]
})

export class ReferenceServiceModule { }