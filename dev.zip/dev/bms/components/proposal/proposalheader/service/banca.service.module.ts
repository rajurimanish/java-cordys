import { NgModule } from '@angular/core';
import { BancaService } from './banca.service';

@NgModule({
    providers: [BancaService]
})

export class BancaServiceModule { }