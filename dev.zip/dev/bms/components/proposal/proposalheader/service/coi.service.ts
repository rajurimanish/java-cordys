import { Injectable } from '@angular/core';
declare var Rx: any;
declare var Observer: any;
import { CordysSoapWService } from "../../../../../common/components/utility/cordys-soap-ws";
import { GetLOVData, SearchAdvancedConfig, Filter } from '../../../../../common/components/utility/search/search.requests';
import { BMSConstants } from '../../../common/constants/bms_constants';
import { AppUtil } from '../../../../../common/components/utility/apputil/app.util';
import { BMSLOVRequest } from '../../../common/service/lov/bms.lovrequest';
import { AlertMessagesService } from '../../../../../common/components/utility/alertmessage/alertmessages.service';
import { AlertMessage } from '../../../../../common/components/utility/alertmessage/alertmessages.model';
import { COInsurance, COInsuranceDetail } from "../../../../../common/components/coinsurance/appobjects/coinsurance";

declare var jQuery: any;
declare var moment: any;

@Injectable()
export class CoinsuranceService {

    constructor(private _cordysService: CordysSoapWService, public _alertMsgService: AlertMessagesService) { }

    public checkCOIRequired(agentCode) {
        return Rx.Observable.create((observer) => {
            let filters = [{ "@FIELD_NAME": 'DESCITEM', "@FIELD_VALUE": agentCode, '@OPERATION': 'EQ', '@CONDITION': 'AND' }];
            let request = new BMSLOVRequest().getLOVRequest("COIRequired", filters);

            let prom = this._cordysService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, null, null, true, null);
            prom.success((data) => this.handleCOISuccess(data, observer));
            prom.error((data) => this.handleError(data, observer));
        });
    }

    public handleError(data, observer) {
        this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, data.responseJSON.faultstring.text, -1));
        observer.error("");
    }

    private handleCOISuccess(data, observer) {
        let optionVal = this.checkAndGetCOIMandatory(data);
        this.resetCOI(optionVal);
        observer.next("");
    }

    private checkAndGetCOIMandatory(resp) {
        let optionVal = "O";
        if (resp != null && resp.tuple != null)
            optionVal = "Y";
        let proposalHeader = BMSConstants.getBMSHeaderInfo();
        proposalHeader.sysCOIValidation = optionVal;
        return optionVal;
    }

    public resetCOI(optionVal) {
        let proposalHeader = BMSConstants.getBMSHeaderInfo();
        if ("Y" == optionVal) {
            let coi = new COInsurance();
            let coiDetail = new COInsuranceDetail();
            coiDetail = { accountNumber: "OurShare", accountName: "Our Share", coInsuranceindicator: "L", OGRONR: "", OCP: "", coinsurer: "", referenceNumber: "", commPercentage: "", sharePercentage: "", coInsurerClaimRef: "" };
            coi.coInsurance.push(coiDetail);
            proposalHeader.coInsuranceDetails = coi;
            proposalHeader.CoInsurance = "Y";
        }
        else if ("N" == optionVal) {
            proposalHeader.coInsuranceDetails = null;
            proposalHeader.CoInsurance = "N";
        }
        proposalHeader.handleFlags();
    }
}