/*
Change History	:

	No      Date          Description                               					    Changed By
	====    ==========    ===========                              						    ==========
	KA001   22/06/2018    MYS-2018-0582    -  To have auto populate rebate % in BMS         Divek	
	E1001   06/12/2018      MYS-2018-1163 : Enhancement on Travel products                  SRE1
    MS001   19/08/2019    MYS-2019-1006 : HD Log: Unable to fetch Risks for Misc Cover Note in BMS      MST
					 
*/
import { Injectable } from '@angular/core';
declare var Rx: any;
declare var Observer: any;
import { CordysSoapWService } from "../../../../../common/components/utility/cordys-soap-ws";
import { GetLOVData, SearchAdvancedConfig, Filter } from '../../../../../common/components/utility/search/search.requests';
import { BMSConstants } from '../../../common/constants/bms_constants';
import { AppUtil } from '../../../../../common/components/utility/apputil/app.util';
import { BMSLOVRequest } from '../../../common/service/lov/bms.lovrequest';
import { AlertMessagesService } from '../../../../../common/components/utility/alertmessage/alertmessages.service';
import { AlertMessage } from '../../../../../common/components/utility/alertmessage/alertmessages.model';
import { COInsurance, COInsuranceDetail } from "../../../../../common/components/coinsurance/appobjects/coinsurance";
import { ApplicationUtilService } from "../../../../../common/services/application.util.service";
import { RiskArray } from '../uimodules/riskArray';
import { RiskFactory } from '../uimodules/riskFactory';
import { BMSAppObjService } from '../../../../services/bmsappobj.service';
import { CustomDCLService, DCLInput } from '../../../../../common/services/customdcl.service';
import { RiskClassificationService } from '../../newbusinessrisks/services/riskcls.service';

declare var jQuery: any;
declare var moment: any;
declare var numeral: any;

@Injectable()
export class RiskTableService {

    public static rtRisksInfo: any = { currentRiskObj: null, allRisks: [], riskTypeList: [], productRiskTypeList: [], lockRiskLoading: false, currentRiskComponent: null };
    constructor(private _cordysService: CordysSoapWService, public _alertMsgService: AlertMessagesService, public _appObjService: BMSAppObjService, private _dcl: CustomDCLService, public _rcls: RiskClassificationService) { }

    getRiskTableInfo() {
        return RiskTableService.rtRisksInfo;
    }

    setListLock() {
        RiskTableService.rtRisksInfo.lockRiskLoading = true;
    }

    releaseListLock() {
        RiskTableService.rtRisksInfo.lockRiskLoading = false;
    }

    getAllRisksByProd() {
        let header = BMSConstants.getBMSHeaderInfo();
        if (AppUtil.isEmpty(header.contractType, false) == false && RiskTableService.rtRisksInfo.riskTypeList.length == 0 && RiskTableService.rtRisksInfo.lockRiskLoading == false) {
            this.addDummy();
            RiskTableService.rtRisksInfo.riskTypeList.length = 0;
            RiskTableService.rtRisksInfo.productRiskTypeList.length = 0;
            this.getRiskListWithMinPrem().subscribe((resp) => this.populateRisks(resp));
        }
    }

    resetRiskList(toClearList) {
        RiskTableService.rtRisksInfo.currentRiskObj = null;
        RiskTableService.rtRisksInfo.allRisks.length = 0;
        RiskTableService.rtRisksInfo.riskTypeList.length = 0;
        RiskTableService.rtRisksInfo.productRiskTypeList.length = 0;
        BMSConstants.getRisks().clear();
        BMSConstants.getBMSHeaderInfo().setReferred();
        if (RiskTableService.rtRisksInfo.currentRiskComponent != null)
            this._dcl.unloadComponent(RiskTableService.rtRisksInfo.currentRiskComponent);
    }

    populateRisks(riskList) {
        this.removeDummy();
        let headerInfo = BMSConstants.getBMSHeaderInfo();
        for (let risk of riskList) {
            let skipRiskType: boolean = false;
            if (risk.riskType == 'PAC' && headerInfo.insuredType != 'Corporate') {
                skipRiskType = true;
            }
            else if (risk.riskType == 'PAG' && headerInfo.insuredType != 'Personal') {
                skipRiskType = true;
            }
            else if (risk.riskType == 'MPA' && headerInfo.insuredType != 'Personal') {
                skipRiskType = true;
            }
            else if (risk.riskType == 'PMC' && headerInfo.insuredType != 'Corporate') {
                skipRiskType = true;
            }
            else if (risk.riskType == 'PMP' && headerInfo.insuredType != 'Personal') {
                skipRiskType = true;
            }
            else if (risk.riskType == 'MPA' && headerInfo.insuredType != 'Personal') {
                skipRiskType = true;
            }
            else if (risk.riskType == 'HII' && headerInfo.insuredType != 'Personal') {
                skipRiskType = true;
                this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "HII is only applicable to Personal Client. For Corporate Client, please select HIG.", -1));
            }
            else if (risk.riskType == 'HIG' && headerInfo.insuredType != 'Corporate') {
                skipRiskType = true;
                this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "HIG is only applicable to Corporate Client. For Personal Client, please select HII.", -1));
            }
            else if ((risk.riskType == 'OSI' || risk.riskType == 'OSS' || risk.riskType == 'HIG' || risk.riskType == 'HGM' || risk.riskType == 'HMG' || risk.riskType == 'HII' || risk.riskType == 'HIC' || risk.riskType == 'HMI') && RiskTableService.rtRisksInfo.allRisks && RiskTableService.rtRisksInfo.allRisks.length > 0) {
                skipRiskType = true;
            }

            let _multiRiskFlag = (headerInfo.insuredType == 'Corporate' && risk.riskType == 'MWP') ? "N" : risk.isMultiple;

            if (!skipRiskType) {
                RiskTableService.rtRisksInfo.riskTypeList.push({ riskType: risk.riskType, riskName: risk.riskName, isMultiple: _multiRiskFlag, riMethod: risk.riMethod, minPrem: risk.minPrem, stampDuty: risk.stampDuty, screenName: risk.sreenName, riskPriority: risk.riskPriority });
            }

            RiskTableService.rtRisksInfo.productRiskTypeList.push({ riskType: risk.riskType, riskName: risk.riskName, isMultiple: _multiRiskFlag, riMethod: risk.riMethod, minPrem: risk.minPrem, stampDuty: risk.stampDuty, screenName: risk.sreenName, riskPriority: risk.riskPriority });
        }

        this.resetStampDuty().subscribe((data) => this.resetAllPremTotal());
    }

    addDummy() {
        RiskTableService.rtRisksInfo.riskTypeList.push({ riskType: "Dummy", riskName: "Loading...", isMultiple: "N", riMethod: "0" });
    }

    removeDummy() {
        RiskTableService.rtRisksInfo.riskTypeList.length = 0;
    }

    resetAllPremTotal() {
        BMSConstants.getNewBusinessInfo().resetAllPremCalc();
    }

    public refreshContractInfo() {
        let vpms = this.resetVPMSProdFlag();
        let header = BMSConstants.getBMSHeaderInfo();
        let maxRebate = this.resetMaxRebate();
        let dataComplete = Rx.Observable.zip(vpms, maxRebate, (vpmsVr: any, maxRebateVr: any) => { return { vpmsVr: vpmsVr, maxRebateVr: maxRebateVr } });
        return dataComplete;
    }

    public refreshVPMSRebateByAgent() {
        let vpms = this.resetVPMSProdFlag();
        let agRebate = this.resetRebateByAgent();
        let dataComplete = Rx.Observable.zip(vpms, agRebate, (vpmsVr: any, agRebateVr: any) => { return { vpmsVr: vpmsVr, agRebateVr: agRebateVr } });
        return dataComplete;
    }

    public resetVPMSProdFlag() {
        return Rx.Observable.create((observer) => {
            let header = BMSConstants.getBMSHeaderInfo();
            if (AppUtil.isEmpty([header.contractType, header.effectiveDate], true) == false) {
                let prom = this._cordysService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", this.getRiskCaltrRequest(header.contractType), null, null, true, null);
                prom.success((resp) => this.setCalculator(resp, observer));
                prom.error((resp) => this.errorAtCaltr(resp, observer));
            }
            else
                observer.next("");
        });
    }

    setCalculator(resp, observer) {
        let header = BMSConstants.getBMSHeaderInfo();
        if (resp != null && resp.tuple != null)
            header.VPMSProduct = "Y";
        else
            header.VPMSProduct = "N";
        if (header.VPMSProduct == "N")
            header.isVPMS = "N";
        else {
            let risks = BMSConstants.getRisks();
            let isVPMSPos = risks.canHaveVPMSCalculator();
            if (isVPMSPos == "Y")
                header.isVPMS = "Y";
            else
                header.isVPMS = "N";
        }
        //below is the code to Enable Rebate Flag for FIRE VPMS products.
        if ( ["FIR"].indexOf( BMSConstants.getBMSHeaderInfo().lineOfBusiness ) >= 0 && header.VPMSProduct == "Y" ) {
            header.isVPMS = "N";
        }
        
        observer.next(header.VPMSProduct);
    }

    errorAtCaltr(resp, observer) {
        this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error occurred while checking VPMS info for this product.", -1));
        observer.error("Error while checking whether this product supports VPMS.");
    }

    getRiskCaltrRequest(product) {
        let prodCode = new AppUtil().getRiskCode(product);
        prodCode = prodCode + prodCode;
        let stDate = moment(this.getDateForLOV(), "YYYY-MM-DD").format("YYYYMMDD");

        let filters = [{ "@FIELD_NAME": "DESCITEM", "@FIELD_VALUE": prodCode, '@OPERATION': 'EQ', '@CONDITION': 'AND' }, { "@FIELD_NAME": "TRANTYPE", "@FIELD_VALUE": "NB", '@OPERATION': 'EQ', '@CONDITION': 'AND' }, { "@FIELD_NAME": "ITMFRM", "@FIELD_VALUE": stDate, '@OPERATION': 'LTEQ', '@CONDITION': 'AND' }, { "@FIELD_NAME": "ITMTO", "@FIELD_VALUE": stDate, '@OPERATION': 'GTEQ', '@CONDITION': 'AND' }];
        let request = new BMSLOVRequest().getLOVRequest("PremiumCalculator", filters);

        return request;
    }

    getDateForLOV() {
        let effectiveDate = BMSConstants.getBMSHeaderInfo().effectiveDate;
        if (effectiveDate != null && effectiveDate != "")
            return effectiveDate;
        else
            return moment().format("YYYY-MM-DD");
    }

    //Divek MYS-2018-0582 changes added the FRMDATE and TODATE filters below
    public resetMaxRebate() {
        return Rx.Observable.create((observer) => {
            let header = BMSConstants.getBMSHeaderInfo();
            let FRMDATE = header.effectiveDate;
            let filters: any;
            if (header.effectiveDate != "" && typeof (header.effectiveDate) != 'undefined') {
                FRMDATE = moment(FRMDATE, "YYYY-MM-DD").format("YYYYMMDD");

                filters = [{ "@FIELD_NAME": 'DESCITEM', "@FIELD_VALUE": header.contractType, '@OPERATION': 'EQ', '@CONDITION': 'AND' },
                { "@FIELD_NAME": 'FRMDATE', "@FIELD_VALUE": FRMDATE, '@OPERATION': 'LTEQ', '@CONDITION': 'AND' },
                { "@FIELD_NAME": 'TODATE', "@FIELD_VALUE": FRMDATE, '@OPERATION': 'GT', '@CONDITION': 'AND' }];
            }
            else {
                filters = [{ "@FIELD_NAME": 'DESCITEM', "@FIELD_VALUE": header.contractType, '@OPERATION': 'EQ', '@CONDITION': 'AND' }];
            }
            let request = new BMSLOVRequest().getLOVRequest("MaxRebate", filters);

            let prom = this._cordysService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, null, null, true, null);
            prom.success((response) => {

                header.rebate = 0;
                header.maxRebate = 0;
                if (response && response.tuple) {
                    //  maxRebate = (AppUtil.isEmpty(response.tuple.old.T9143.SHORTDESC,false)==false)?response.tuple.old.T9143.SHORTDESC:0;
                    let maxRebate = (AppUtil.isEmpty(response.tuple.old.T9143.RATE, false) == false) ? response.tuple.old.T9143.RATE : 0;
                    header.maxRebate = numeral(numeral(parseFloat("" + maxRebate)).format(AppUtil.getRateFormat())).value();
                    //Divek Rebate auto populate changes KA001 - MYS-2018-0582  Start
                    if (header.businessChannel == '04' && header.isVPMS == 'N') {
                        header.rebate = header.maxRebate;
                    } //END
                }
                observer.next("");

            });
            prom.error((error) => {
                this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error occurred while getting Max Rebate value.", -1));
                observer.error("");
            });
        });
    }
    // MYS-2018-0582-END
    public resetStampDuty() {
        return Rx.Observable.create((observer) => {
            let header = BMSConstants.getBMSHeaderInfo();
            let contractType = header.contractType;
            this.setMPForSD().subscribe((data) => {
                if (AppUtil.isEmpty(header.masterPolicy, false) == true || header.useMP == "N") {
                    this.getRiskList().subscribe((risksList) => {
                        if (risksList.length > 0) {
                            header.stampDuty = (AppUtil.isEmpty(risksList[0].stampDuty, false) == true) ? 0 : parseInt(risksList[0].stampDuty);
                        }
                        if (header.stampDuty == 0) {
                            this.setStampDutyByCT(contractType).subscribe((data) => {
                                observer.next("");
                            }, (err) => {
                                observer.error("");
                            });
                        }
                        else
                            observer.next("");
                    },
                        (err) => {
                            observer.error("");
                        });
                }
                //E1001 Start
                else if (contractType == 'TDA') {
                    header.stampDuty = 10;
                    observer.next("");
                }
                //E1001 End 
                else {
                    header.stampDuty = 0;
                    observer.next("");
                }
            },
                (err) => {
                    observer.error("");
                });
        });
    }

    public checkRIRequired(risks) {
        let output = "false";
        return Rx.Observable.create((observer) => {
            for (let risk of risks) {
                if (risk.RIRequired == "Yes") {
                    output = "true";
                    break;
                }
            }
            observer.next(output);
        });
    }

    public getRiskArrayByType() {
        return Rx.Observable.create((observer) => {
            let riskType = new RiskArray().getArrayByRiskType(BMSConstants.getBMSHeaderInfo().contractType)
            let genericRiskArray = BMSConstants.getRisks();
            observer.next(genericRiskArray[riskType]);
        });
    }

    public setMPForSD() {
        return Rx.Observable.create((observer) => {
            let header = BMSConstants.getBMSHeaderInfo();
            if (AppUtil.isEmpty(header.useMP, false) == true) {
                let mpExcpn = { "key": "/com/msig/insurance/exceptions/mp_sd_products.xml" };
                let prom = this._cordysService.callCordysSoapService("GetXMLObject", "http://schemas.cordys.com/1.0/xmlstore", mpExcpn, null, null, true, null);
                prom.success((resp) => {
                    let prodObj = AppUtil.getValueByPath(resp, "tuple.old.config.mp_products.product");
                    let prods = new AppUtil().getArray(prodObj);
                    let excep = prods.filter((item) => item == header.contractType);
                    if (excep.length > 0)
                        header.setMP("Y");
                    else
                        header.setMP("N");
                    observer.next("");
                });
                prom.error((resp) => {
                    this.sdError(resp, observer);
                });
            }
            else
                observer.next("");
        });
    }

    private setStampDutyByCT(contractType) {
        return Rx.Observable.create((observer) => {
            let polEndDate = ApplicationUtilService.getFormattedDate(BMSConstants.getBMSHeaderInfo().endDate, "YYYY-MM-DD", "YYYYMMDD");

            let filters = [{ "@FIELD_NAME": 'B.RSKTYPE', "@FIELD_VALUE": contractType, '@OPERATION': 'EQ', '@CONDITION': 'AND' }, { "@FIELD_NAME": 'A.ITMFRM', "@FIELD_VALUE": polEndDate, '@OPERATION': 'LTEQ', '@CONDITION': 'AND' }, { "@FIELD_NAME": 'A.ITMTO', "@FIELD_VALUE": polEndDate, '@OPERATION': 'GTEQ', '@CONDITION': 'AND' }];
            let request = new BMSLOVRequest().getLOVRequest("StampDuty", filters);

            let prom = this._cordysService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, null, null, true, null);
            prom.success((response) => {
                let _stampDuty = 0;
                if (response && response.tuple) {
                    let ary = new AppUtil().getArray(response.tuple);
                    if (ary && ary.length > 0) {
                        _stampDuty = parseInt("" + ary[0].old.T8791.AMOUNT);
                        if (_stampDuty > 100)
                            _stampDuty = _stampDuty / 100;
                    }
                }
                let header = BMSConstants.getBMSHeaderInfo();
                header.stampDuty = _stampDuty;
                observer.next("");
            });
            prom.error((resp) => this.sdError(resp, observer));
        });
    }

    sdError(resp, observer) {
        this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error occurred while getting stamp duty.", -1));
        observer.error("Error occurred while getting stamp duty.");
    }

    public getRiskList() {
        return Rx.Observable.create((observer) => {
            let header = BMSConstants.getBMSHeaderInfo();
            let filters = [{ "@FIELD_NAME": "PRODUCT_TYPE", "@FIELD_VALUE": header.contractType, '@OPERATION': 'EQ', '@CONDITION': 'AND' }];
            let request = new BMSLOVRequest().getLOVRequest("RiskType", filters);
            let prom = this._cordysService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, null, null, true, { comp: this });
            prom.success((resp) => this.extractRisks(resp, observer));
            prom.error((resp) => this.rtError(resp, observer));
        });
    }

    extractRisks(response, observer) {
        let risksList = [];
        let risks = new AppUtil().getArray(response.tuple);
        for (let risk of risks) {
            let pd = risk.old.PRODUCT_DETAILS;
            risksList.push({ riskType: pd.VALUE, riskName: pd.DESCRIPTION, isMultiple: pd.MUL_RISKS_FLAG, riMethod: pd.ATTRIBUTE2, minPrem: "", stampDuty: pd.STAMP_DUTY, sreenName: pd.RISK_SCREEN_NM, riskPriority: pd.RISK_PRIORITY });
        }
        observer.next(risksList);
    }

    rtError(resp, observer) {
        this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error occurred while getting risk type list.", -1));
        observer.error("");
    }

    minError(resp, observer) {
        this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error occurred while getting minimum premium value.", -1));
        observer.error("");
    }

    public getRiskListWithMinPrem() {
        return Rx.Observable.create((observer) => {
            this.getRiskList().subscribe((riskList) => {
                let condition = AppUtil.getNotInList(riskList, "riskType");
                if (condition != "") {
                    let stDate = moment(this.getDateForLOV(), "YYYY-MM-DD").format("YYYYMMDD");
                    let filters = [{ "@FIELD_NAME": "DESCITEM", "@FIELD_VALUE": condition, '@OPERATION': 'IN', '@CONDITION': 'AND' }, { "@FIELD_NAME": "ITMFRM", "@FIELD_VALUE": stDate, '@OPERATION': 'LTEQ', '@CONDITION': 'AND' }, { "@FIELD_NAME": "ITMTO", "@FIELD_VALUE": stDate, '@OPERATION': 'GTEQ', '@CONDITION': 'AND' }];
                    let request = new BMSLOVRequest().getLOVRequest("MinPrem", filters);
                    let prom = this._cordysService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, null, null, true, null);
                    prom.success((resp) => this.setMinPrem(resp, riskList, observer));
                    prom.error((resp) => this.minError(resp, observer));
                }
                else
                    observer.next("");
            });
        });
    }

    public setMinPrem(resp, riskList, observer) {
        let minPremItems = new AppUtil().getArray(resp.tuple);
        for (let risk of riskList) {
            let minPrmItmFiltered = minPremItems.filter((item) => item.old.T7013.DESCITEM == risk.riskType);
            if (minPrmItmFiltered.length > 0)
                risk.minPrem = AppUtil.getSumInsuredNumber(minPrmItmFiltered[0].old.T7013.MINPREMIUM);
        }
        observer.next(riskList);
    }

    public resetRebateByAgent() {
        return Rx.Observable.create((observer) => {
            let agntExcpn = { "key": "/com/msig/insurance/exceptions/agent_rebate.xml" };
            let prom = this._cordysService.callCordysSoapService("GetXMLObject", "http://schemas.cordys.com/1.0/xmlstore", agntExcpn, null, null, true, null);
            prom.success((resp) => {
                let chnlObj = AppUtil.getValueByPath(resp, "tuple.old.config.agnt_channel.channel");
                let chnls = new AppUtil().getArray(chnlObj);
                let header = BMSConstants.getBMSHeaderInfo();
                let excep = chnls.filter((item) => item == header.businessChannel);
                let old = header.isAgentHasRebate;
                if (excep.length > 0)
                    header.isAgentHasRebate = "Y";
                else
                    header.isAgentHasRebate = "N";

                if (header.isAgentHasRebate == "N") {
                    header.rebate = 0;
                    header.maxRebate = 0;
                    BMSConstants.getNewBusinessInfo().resetAllPremCalc();
                }
                else {
                    if (old == "N")
                        this.resetMaxRebate().subscribe();
                }

                observer.next("");
            });
            prom.error((resp) => {
                this.agntError(resp, observer);
            });
        });
    }

    agntError(resp, observer) {
        this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error occurred while checking Rebate by Agent.", -1));
        observer.error("");
    }

    //Multi Risk Paginator
    public fetchRisks() {
        return Rx.Observable.create((observer) => {
            let prom = this._cordysService.callCordysSoapService("MultiRiskEnquiryService", "http://schemas.cordys.com/default", this.getMultiRiskEnquiryServiceParams(), null, null, true, null);
            prom.success((resp) => this.fetchRisksSuccessHandler(resp, observer));
            prom.error((resp) => this.fetchRisksErrorHandler(resp, observer));
        });
    }

    private getMultiRiskEnquiryServiceParams() {
        let header = BMSConstants.getBMSHeaderInfo();
        let clientDetails = BMSConstants.getNewBusinessInfo().clientDetails;
        let caseInfo = BMSConstants.getBMSCaseInfo();
        let risks = BMSConstants.getRisks();
        let riskType = new RiskArray().getArrayByRiskType(header.contractType);
        //let maxRiskNumberDownlaoded = Math.max.apply(Math,risks[riskType].map(function(o){return o.riskNumber;}));
        let maxRiskNumberDownlaoded = header.latestEnqRiskNo;
        return {
            "RiskNumber": Number(maxRiskNumberDownlaoded) + 1,
            "PolicyNumber": caseInfo.policyNumber,
            "ExpiryDate": header.endDate,
            "City": clientDetails.client.personalClientDetails ? clientDetails.client.personalClientDetails.address.city : clientDetails.client.corporateClientDetails.address.city,
            "isReferredRisk": header.isReferredRisk,
            "StartDate": header.effectiveDate,
            "IName": header.insuredName,
            "currentRiskScreen": header.riskScreen,
            "noOfRisks": header.noOfRisks
        }
    }



    fetchRisksSuccessHandler(response, observer) {
        if (response.fault.description) {
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, response.fault.description, -1));
            observer.error("");
        }
        else {

            let riskType = new RiskArray().getArrayByRiskType(BMSConstants.getBMSHeaderInfo().contractType);
            let risks = new AppUtil().getArray(response.risks[riskType]);
            for (let eachRisk of risks) {
                let riskObj = new RiskFactory().getOldRiskObj(eachRisk.riskType, eachRisk)
                let risksObj = BMSConstants.getRisks();
                //risksObj[new RiskArray().getArrayByRiskType(eachRisk.riskType)].unshift(riskObj);		
                risksObj[new RiskArray().getArrayByRiskType(eachRisk.riskType)].push(riskObj);
            }

            //Update The last enquired risk number and no of risks
            BMSConstants.getBMSHeaderInfo().latestEnqRiskNo = response.latestEnqRiskNo.text;
            BMSConstants.getBMSHeaderInfo().noOfRisks = response.noOfRisks.text;

            let caseId = BMSConstants.getBMSCaseInfo().caseId;
            let policyNumber = BMSConstants.getBMSCaseInfo().policyNumber; //MS001 - Added Policy Number in check
            if ((caseId != "" && caseId != undefined && caseId != null) || (policyNumber != "" && policyNumber != undefined && policyNumber != null) ) { // MS001
                this._rcls.setRiskClassification("", "", "", "Y").subscribe(() => {
                    this._appObjService.refreshRiskClassification();
                    this._appObjService.saveData().subscribe(() => observer.next(risks));
                });
            }
            this.resetAllPremTotal(); //mku1
        }

    }

    fetchRisksErrorHandler(resp, observer) {
        this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error occurred while fetching risk info", -1));
        observer.error("");
    }

    // SAF MYS-2018-1249 --start
    setRiskScreenActivationInfo(contractType) {
        let request: GetLOVData = new GetLOVData();
        request.BRANCH = 'ALL';
        request.LOB = 'FIRE';
        request.BUSINESS_FUNCTION = 'NEW BUSINESS';
        request.PRODUCT = 'ALL';
        request.OPERATION = 'NEW';
        request.FORM_NAME = 'FIRE';
        request.FORM_FIELD_NAME = 'FIRE_RISKSCREEN_ACTIVATION';
        request.FIELD_TYPE = 'LOV';
        request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        request.ADVANCE_CONFIG_XML.FILTERS = new Filter();
        request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push(
            { "@FIELD_NAME": '', "@FIELD_VALUE": '', '@OPERATION': 'OPNPRNTHS', '@CONDITION': 'OR' },
            { "@FIELD_NAME": 'RTRIM(ITEMITEM)', "@FIELD_VALUE": contractType, '@OPERATION': 'EQ', '@CONDITION': 'OR' },
            { "@FIELD_NAME": 'RTRIM(ITEMITEM)', "@FIELD_VALUE": '***', '@OPERATION': 'EQ', '@CONDITION': '' },
            { "@FIELD_NAME": '', "@FIELD_VALUE": '', '@OPERATION': 'CLSPRNTHS', '@CONDITION': 'AND' },
            { "@FIELD_NAME": 'SUBSTRING(GENAREA,1,8)', "@FIELD_VALUE": moment(new Date(), "YYYY-MM-DD").format("YYYYMMDD"), '@OPERATION': 'LTEQ', '@CONDITION': 'AND' }
        );
        this._cordysService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.callbackFireRiskScreenActivationInfo, this.handleError, false, { comp: this });
    }
    callbackFireRiskScreenActivationInfo(response, prms) {
        if (response.tuple) {
            let ary = [];
            if (response.tuple != null && !Array.prototype.isPrototypeOf(response.tuple)) {
                ary = [response.tuple];
            } else {
                ary = response.tuple;
            }
            if (ary.length > 0) {
                BMSConstants.getBMSHeaderInfo().firePostingScreen = "NEW";
            } else {
                BMSConstants.getBMSHeaderInfo().firePostingScreen = "OLD";
            }
        } else {
            BMSConstants.getBMSHeaderInfo().firePostingScreen = "OLD";
        }
    }
    handleError(response, status, errorText, prms) {
        prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, response.responseJSON.faultstring.text, -1));
    }
    // SAF MYS-2018-1249 --End

}