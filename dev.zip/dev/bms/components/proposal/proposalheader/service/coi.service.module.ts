import { NgModule } from '@angular/core';
import { CoinsuranceService } from './coi.service';

@NgModule({
    providers: [CoinsuranceService]
})

export class CoinsuranceServiceModule { }