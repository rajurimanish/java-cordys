import { NgModule } from '@angular/core';
import { RiskTableService } from './riskTable.service';

@NgModule({
    providers: [RiskTableService]
})

export class RiskTableServiceModule { }