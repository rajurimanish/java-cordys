/*
 * Change History:
 * 
 * No      Date          Description                                   Changed By
 * ====    ==========    ===========                                   ==========
 * VK004	05/12/2018	MYS-2018-1192								  	VKR
 * 
*/
import { Validator, ValidationResult } from '../../../../common/components/validator/validator';
import { GSTDetilsValidator } from './gstdetails.validator';
import { ExcessTypeValidator } from './excesstype.validator';
import { SurveyValidator } from './survey.validator';
import { S4808 } from '../newbusinessrisks/s4808/appobjects/s4808';
import { BMSConstants } from '../../common/constants/bms_constants';
import { AppUtil } from '../../../../common/components/utility/apputil/app.util';

export class S4808Validator extends Validator {
    public fields: Array<any> = ["ratingFlag",
        "situation1",
        "RIRetentionCode",
        "businessCode",
        "businessCodeDesc",
        "occupancyCode",
        "postCode",
        "city",
        "isSecurityServ",
        "isProtected",
        "totalPremium"];
    public fieldNames: any = {
        ratingFlag: "Rating Flag",
        situation1: "Premises",
        RIRetentionCode: "RI Retention Code",
        businessCode: "Business Code / PIAM Code",
        businessCodeDesc: "Business of Insured Description",
        occupancyCode: "PIAM Occupancy Stat",
        postCode: "Post Code",
        city: "Town/City",
        isSecurityServ: "Is Transit escorted by Security Services?",
        isProtected: "Is Premises protected by security guard or burglar alarm system?",
        totalPremium: "Total Premium",
        "GSTDetails.riskUsage": "GST Risk Usage",
        "GSTDetails.riskLocation": "GST Risk Location",
        "GSTDetails.placeOfRecidence": "GST Place of Residence"
    };
    constructor(s4808: S4808) {
        super();
        this.valueObj = s4808;
        this.requiredFields = this.fields;
    }

    public validate() {
        let result = super.validate();
        let validHeaderMandatoryFields: boolean = true;
        if (result.isValid == false) {
            validHeaderMandatoryFields = false;
            result.message = this.valueObj.riskType + " (Risk Number: " + this.valueObj.riskNumber + " ): <p>Provide value for all mandatory fields.</p>" + this.getInvalidFields(result, this.fieldNames);
        }

        let excessTypeResult = new ExcessTypeValidator(this.valueObj).validate();
        if (excessTypeResult.isValid == false) {
            result.isValid = false;
            result.message = result.message + excessTypeResult.message;
        }

        let coverageResult = this.coverageValidator();
        if (coverageResult.isValid == false) {
            result.isValid = false;
            // if(result.message == null || result.message == ""){
            // result.message = this.valueObj.riskType+" (Risk Number: "+this.valueObj.riskNumber+" ): <p>Provide value for all mandatory fields.</p>";
            // }
            result.message = result.message + coverageResult.message;
        }

        if ((this.valueObj.paExtUnits || (this.valueObj.totalNoEmps && parseFloat("" + this.valueObj.totalNoEmps) > 0) || (this.valueObj.paExtPremPerUnit && parseFloat("" + this.valueObj.paExtPremPerUnit) > 0)) &&
            (!this.valueObj.paExtUnits || !this.valueObj.totalNoEmps || parseFloat("" + this.valueObj.totalNoEmps) == 0 || !this.valueObj.paExtPremPerUnit || parseFloat("" + this.valueObj.paExtPremPerUnit) == 0)) {
            result.isValid = false;
            // if(result.message == null || result.message == ""){
            // result.message = this.valueObj.riskType+" (Risk Number: "+this.valueObj.riskNumber+" ): <p>Provide value for all mandatory fields in Coverage Information section.</p>";
            // }
            result.message = result.message + "<br>PA Extension fields are mandatory.";
        }

        let gstDetailsResult = new GSTDetilsValidator(this.valueObj).validate();
        if (gstDetailsResult.isValid == false) {
            result.isValid = false;
            result.message = result.message + gstDetailsResult.message;
        }

        if (this.valueObj.isSurveyNeeded == "Y") {
            let surveyValidatorResult = new SurveyValidator(this.valueObj).validate();
            if (surveyValidatorResult.isValid == false) {
                result.isValid = false;
                if (result.message == null || result.message == "") {
                    result.message = surveyValidatorResult.message;
                } else
                    result.message = result.message + surveyValidatorResult.message;
            }
        }

        if (parseFloat("" + this.valueObj.totalBasePremium) > 99999999999.99) {
            result.isValid = false;
            result.message = result.message + "<br>Sub Total Premium cannot greater than 99,999,999,999.99";
        }

		/*if(this.valueObj.RIRetentionCode){
			let _totalGrossCapacity = BMSConstants.getBmsUtilServiceObj().getNetRetentionAmountDetails(this.valueObj.RIRetentionCode);
			_totalGrossCapacity = (!_totalGrossCapacity) ? 0 : parseFloat(""+_totalGrossCapacity);
			
			let _totalSI = parseFloat(""+this.valueObj.totalSI);
			
			if( _totalGrossCapacity > 0 && _totalSI > _totalGrossCapacity && (this.valueObj.RIMethod == null || this.valueObj.RIMethod == "" || parseFloat(""+this.valueObj.RIMethod) != 8) ){
				result.isValid = false;			
				result.message = result.message + "<p>Total Sum Insured is greater than Total Gross Capacity: "+_totalGrossCapacity+",  RI is Required.</p>";
			}
		}*/

        if (!result.isValid && validHeaderMandatoryFields) {
            result.message = this.valueObj.riskType + " (Risk Number: " + this.valueObj.riskNumber + " ): <p>Provide value for all mandatory fields.</p>" + result.message;
        }
		//VK004 General Page Text
		let headerInfo = BMSConstants.getBMSHeaderInfo();
		if(Number(this.valueObj.gpTextCount) > Number(headerInfo.gpTextMaxLines)) {
			result.isValid = false;
			result.message = this.valueObj.riskType+" (Risk Number: "+this.valueObj.riskNumber+" ): General Page Text entered is more than 400 lines.";
		}
		//VK004 END

        return result;
    }

    private coverageValidator() {
        let result = new ValidationResult();
        if (this.valueObj.riskCoverageDetails.riskCoverage == null || this.valueObj.riskCoverageDetails.riskCoverage == "") {
            result.isValid = false;
            result.message = "<br>Add cover in Coverage Information section.";
        }
        else {
            let riskCoverageItemsArr: any = [];
            if (Array.prototype.isPrototypeOf(this.valueObj.riskCoverageDetails.riskCoverage)) {
                riskCoverageItemsArr = this.valueObj.riskCoverageDetails.riskCoverage;
            } else {
                riskCoverageItemsArr = [this.valueObj.riskCoverageDetails.riskCoverage];
            }

            if (riskCoverageItemsArr.length > 0) {
                result.isValid = true;
                let _errMsg = '';
                let isValidPremium: boolean = true;
                for (let coverageItem of riskCoverageItemsArr) {
                    // if((coverageItem.section == null || coverageItem.section == "") || (coverageItem.specification == null || coverageItem.specification == "") || (coverageItem.liability == null || coverageItem.liability <=0) || (coverageItem.rate == null || coverageItem.rate <=0) || (coverageItem.ratingFactor == null || coverageItem.ratingFactor =="") || (coverageItem.premium == null || coverageItem.premium <=0) || (coverageItem.premiumClass == null || coverageItem.premiumClass =="")){
                    if ((coverageItem.section == null || coverageItem.section == "") || (coverageItem.specification == null || coverageItem.specification == "") || (coverageItem.liability == null || coverageItem.liability <= 0) || (coverageItem.rate == null || coverageItem.rate <= 0) || (coverageItem.ratingFactor == null || coverageItem.ratingFactor == "") || (coverageItem.premiumClass == null || coverageItem.premiumClass == "")) {
                        result.isValid = false;
                    } else if (coverageItem.section == 'A' && (coverageItem.eac == null || coverageItem.eac <= 0)) {
                        result.isValid = false;
                        if (_errMsg == '') {
                            _errMsg = "<br>Estimated Annual Carrying is mandatory for Section A cover";
                        }
                    }
                    if (coverageItem.premium != null && parseFloat("" + coverageItem.premium) > 9999999.99) {
                        result.isValid = false;
                        isValidPremium = false;
                    }
                }

                if (result.isValid == false) {
                    result.message = "<br>Fill all mandatory fields in Coverage Information section." + _errMsg;
                }

                if (!isValidPremium) {
                    result.message = result.message + "<br>Coverage Information: Premium of each cover item must be less than 10,000,000.00";
                }
            }
            else {
                result.isValid = false;
                result.message = "<br>Add cover in Coverage Information section.";
            }
        }

        return result;
    }
}