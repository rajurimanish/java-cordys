/*
Change History	:

	No      Date          Description                                 Changed By
	====    ==========    ===========                                 ==========
    GA001   29/07/2019   MYS-2019-0857 - HD Log Incorrect validation 
                         Nominee Insured DOB for renewal cases in BMS     KGA
 */
import { Validator, ValidationResult } from '../../../../common/components/validator/validator';
import { Nominee } from "../newbusinessrisks/appobjects/nomineeslist";

declare var moment: any;

export class NomineeValidator extends Validator {
    public fields: Array<any> = ["name",
        "ICPassport",
        //"DOB",//GA001
        "relationship",
        "percentageOfShare"
    ];
    constructor(nomineeObj: Nominee) {
        super();
        this.valueObj = nomineeObj;
        this.requiredFields = this.fields;
    }

    public validate() {
        let result = super.validate();
        if (result.isValid == true) {
            if (!isNaN(this.valueObj.percentageOfShare) && Number(this.valueObj.percentageOfShare) > 100) {
                result.isValid = false;
                result.message = "Percentage of Share should not be greater than 100. Enter lesser value.";
            }
            else if (Number(this.valueObj.percentageOfShare) <= 0) {
                result.isValid = false;
                result.message = "Percentage of Share should not be lesser or equal to 0. Enter value greater than 0.";
            }

            let _nricOrPassport = this.valueObj.ICPassport;

            if (/^\d{6}\-\d{2}\-\d{4}/g.test(_nricOrPassport)) {
                let date = _nricOrPassport.substring(0, 6);
                let century = _nricOrPassport.substring(0, 2);
                if (Number(century) > 29)
                    date = '19' + date;
                else
                    date = '20' + date;
                if (date != moment(this.valueObj.DOB, "YYYY-MM-DD").format("YYYYMMDD")) {
                    //this.DOBCtrl.setter(moment(date,"YYYYMMDD").format("YYYY-MM-DD"),"YYYY-MM-DD",this.DOBCtrl.comp);
                    result.isValid = false;
                    result.message = result.message + "<br> Enter valid Nominee DOB";
                }
            }
            /*else if (/[^a-zA-Z0-9]/g.test(_nricOrPassport) || (!/[^a-zA-Z0-9]/g.test(_nricOrPassport) && _nricOrPassport.length < 4)) {
                result.isValid = false;
                result.message = result.message + "Enter valid NRIC / BC";
            }*/

        }
        else {
            result.message = "Provide value for all Nominee Detail mandatory fields.";
        }
        return result;
    }

}