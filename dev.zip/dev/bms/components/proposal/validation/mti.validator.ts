import { Validator, ValidationResult } from '../../../../common/components/validator/validator';
import { BMSObject } from '../../common/appobjects/bmsobject';

export class MTIValidator extends Validator {

    constructor(bmsObject: BMSObject) {
        super();
        this.valueObj = bmsObject;
    }

    public validate() {
        let result = new ValidationResult();
        result.isValid = true;
		/*if (!this.valueObj.newBusiness.headerInfo.mtiItems.mtiItem) {
			result.isValid = false;
            result.message = "Please add atleast one Tax Invoice item";
		} else if (this.valueObj.newBusiness.headerInfo.mtiItems.mtiItem.length < 1) {
			result.isValid = false;
            result.message = "Please add atleast one Tax Invoice item";
		} else*/
        if (this.valueObj.newBusiness.headerInfo.mtiItems) {
            if (this.valueObj.newBusiness.headerInfo.mtiItems.mtiItem.length >= 1) {
                let items: any = this.valueObj.newBusiness.headerInfo.mtiItems.mtiItem;
                if (!items.sort) {
                    items = [];
                    items = this.valueObj.newBusiness.headerInfo.mtiItems.mtiItem;
                }
                let index: number = 1;
                for (let item of items) {
                    if (!item.invoiceTo || item.invoiceTo == "") {
                        result.isValid = false;
                        result.message = "Select client at tax invoice line " + index;
                        break;
                    } else if (!item.amount || item.amount == "" || item.amount == 0) {
                        result.isValid = false;
                        result.message = "Provide value in amount at tax invoice line " + index;
                        break;
                    }
                    index++;
                }
                if (this.valueObj.newBusiness.headerInfo.mtiItems.totalAmount != this.valueObj.newBusiness.headerInfo.totalDiscountedPremium) {
                    result.isValid = false;
                    result.message = "Total tax invoice amount must be equal to total net premium";
                }
            } else if (this.valueObj.newBusiness.headerInfo.mtiItems.mtiItem.length >= 1 && this.valueObj.newBusiness.headerInfo.mtiItems.totalAmount != this.valueObj.newBusiness.headerInfo.totalDiscountedPremium) {
                result.isValid = false;
                result.message = "Total tax invoice amount must be equal to total net premium";
            }
        }

        return result;
    }
}