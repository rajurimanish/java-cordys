/*
 * Change History:
 * 
 * No      Date          Description                                   Changed By
 * ====    ==========    ===========                                   ==========
 * GA001   19/10/2018   MYS-2018-1291 : Incorrect rounding of 
 *                      Total share percentage of Nominee Details	  KGA
*/
import { Validator, ValidationResult } from '../../../../common/components/validator/validator';
import { S5382ItemDetails } from '../newbusinessrisks/s5381/appobjects/s5381';
import { NomineeValidator } from './nominee.validator';
import { AppUtil } from '../../../../common/components/utility/apputil/app.util';
import { BMSConstants } from '../../common/constants/bms_constants';

declare var moment: any;
declare var numeral: any;//GA001

export class S5382Validator extends Validator {

    public fields: Array<any> = ["insuredPerson",
        "occupationCode",
        "occupationDescription",
        "dateOfBirth",
        "IdProofNo",
        "gender",
        "plan",
        "maritalStatus",
        "nationality",
        "homeCity",
        "residence",
        "basicPremium",
        "totalAnnualPremium",
        "capitalSumInsured",
        "areaCode",
        "occupationClass"];

    public fieldNames: any = {
        insuredPerson: "Insured Person Name",
        insuredSalutation: "Salutation",
        occupationCode: "Occupation Code",
        occupationDescription: "Occupation Description",
        dateOfBirth: "Date of Birth",
        IdProofNo: "IC/Passport Number",
        gender: "Gender",
        maritalStatus: "Marital Status",
        nationality: "Nationality",
        homeCity: "Home City",
        residence: "Residence",
        plan: "Plan",
        basicPremium: "Basic Premium",
        totalAnnualPremium: "Total Annual Premium",
        capitalSumInsured: "Capital Sum Insured",
        areaCode: "Area Code",
        occupationClass: "Occupation Class",
    };

    constructor(s5382Item: S5382ItemDetails) {
        super();
        this.valueObj = s5382Item;
        this.requiredFields = this.fields;
    }

    public validate() {

        /*let result = super.validate();
		let validHeaderMandatoryFields:boolean=true;
        // result.message = "<p style='padding-left: 25px'>Insured : "+this.valueObj.itemNo+" : Missing fields are,";
		
		if(result.isValid == false){
			validHeaderMandatoryFields=false;
			result.message = "<dd><dl><dd>(Insured: "+this.valueObj.itemNo+"): Provide value for all mandatory fields.</dd><dd><dl><dd>" + this.getInvalidFields(result,this.fieldNames)+"</dd></dl></dd>";
		}
		*/

        let result = new ValidationResult();
        result.isValid = true;
        result.message = "<dd><dl><dd>(Insured: " + this.valueObj.itemNo + "): Provide value for all mandatory fields.</dd>";

        if (this.valueObj.insuredPerson == undefined || this.valueObj.insuredPerson == "") {
            result.isValid = false;
            result.message = result.message + "<dd> - Insured Person Name </dd>";
        }

        if (this.valueObj.occupationCode == undefined || this.valueObj.occupationCode == "") {
            result.isValid = false;
            result.message = result.message + "<dd> - Occupation Code </dd>";
        }

        if (this.valueObj.occupationDescription == undefined || this.valueObj.occupationDescription == "") {
            result.isValid = false;
            result.message = result.message + "<dd> - Occupation Description </dd>";
        }

        if (this.valueObj.dateOfBirth == undefined || this.valueObj.dateOfBirth == "") {
            result.isValid = false;
            result.message = result.message + "<dd> - Date of Birth </dd>";
        }

        if (this.valueObj.gender == undefined || this.valueObj.gender == "") {
            result.isValid = false;
            result.message = result.message + "<dd> - Gender </dd>";
        }

        if (this.valueObj.maritalStatus == undefined || this.valueObj.maritalStatus == "") {
            result.isValid = false;
            result.message = result.message + "<dd> - Marital Status </dd>";
        }

        if (this.valueObj.nationality == undefined || this.valueObj.nationality == "") {
            result.isValid = false;
            result.message = result.message + "<dd> - Nationality </dd>";
        }

        if (this.valueObj.homeCity == undefined || this.valueObj.homeCity == "") {
            result.isValid = false;
            result.message = result.message + "<dd> - Home City </dd>";
        }

        if (this.valueObj.residence == undefined || this.valueObj.residence == "") {
            result.isValid = false;
            result.message = result.message + "<dd> - Residence </dd>";
        }

        if (this.valueObj.areaCode == undefined || this.valueObj.areaCode == "") {
            result.isValid = false;
            result.message = result.message + "<dd> - Area Code </dd>";
        }

        if (this.valueObj.occupationClass == undefined || this.valueObj.occupationClass == "") {
            result.isValid = false;
            result.message = result.message + "<dd> - Occupation Class </dd>";
        }

        if (this.valueObj.IdProofNo == undefined || this.valueObj.IdProofNo.trim() == "") {
            result.isValid = false;
            result.message = result.message + "<dd> - IC/Passport Number </dd>";
        }
        else {
            let isValidNRICFormat = new RegExp("[0-9]{6}-[0-9]{2}-[0-9]{4}$").test(this.valueObj.IdProofNo);
            if (isValidNRICFormat == true) {
                if (this.valueObj.IdProofNo) {
                    let lastDigit = this.valueObj.IdProofNo.substring(this.valueObj.IdProofNo.length - 1);
                    if (/^-?\d*[02468]$/.test(lastDigit) && this.valueObj.gender != 'F') {
                        result.isValid = false;
                        result.message = result.message + "<dd> - Gender is not matching with IC Number </dd>";
                    }
                    if (/^-?\d*[13579]$/.test(lastDigit) && this.valueObj.gender != 'M') {
                        result.isValid = false;
                        result.message = result.message + "<dd> - Gender is not matching with IC Number </dd>";
                    }
                }
            }
        }

        if (this.valueObj.plan == undefined || this.valueObj.plan == "") {
            result.isValid = false;
            result.message = result.message + "<dd> - Plan </dd>";
        }
        else {
            let coverageResult = this.benefitsValidator();
            if (coverageResult.isValid == false) {
                result.isValid = false;
                result.message = result.message + coverageResult.message;
            }
        }

        if (this.valueObj.basicPremium == undefined || this.valueObj.basicPremium == "") {
            result.isValid = false;
            result.message = result.message + "<dd> - Basic Premium. Please select Occupation Class, Area Code and Plan to auto populate basic premium </dd>";
        }

        if (this.valueObj.maternityOption == 'Y' && !this.valueObj.maternityDate) {
            result.isValid = false;
            result.message = result.message + "<dd> - Maternity Date is mandatory</dd>";
        }

        let _effectiveDate = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.effectiveDate;
        let _endDate = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.endDate;
        let _caseInfo = BMSConstants.getBMSObj().ApplicationBusinessObject.caseInfo; //KA001- MYS-2018-0878 Renewal Rerate
        _effectiveDate = moment(_effectiveDate, "YYYY-MM-DD");
        _endDate = moment(_endDate, "YYYY-MM-DD");

        if (this.valueObj.dateOfBirth) {
            let _dobDate = moment(this.valueObj.dateOfBirth, "YYYY-MM-DD");

            if (_dobDate > _endDate) {
                result.isValid = false;
                result.message = result.message + "<dd> - Date of Birth must be before Expiry Date</dd>";
            }
        }

        if (this.valueObj.maternityDate && _caseInfo.businessFunction != "RenewalRerate") {// KA001- MYS-2018-0878 Renewal Rerate
            let _maternityDate = moment(this.valueObj.maternityDate, "YYYY-MM-DD");
            if (_maternityDate < _effectiveDate || _maternityDate > _endDate) {
                result.isValid = false;
                result.message = result.message + "<dd> - Maternity date must be within the POI</dd>";
            }
        }

        if (this.valueObj.dateStart && _caseInfo.businessFunction != "RenewalRerate" ) { // KA001- MYS-2018-0878 Renewal Rerate
            let _dateStart = moment(this.valueObj.dateStart, "YYYY-MM-DD");
            if (_dateStart < _effectiveDate || _dateStart > _endDate) {
                result.isValid = false;
                result.message = result.message + "<dd> - Insured Start date must be within the POI</dd>";
            }
        }

        if (this.valueObj.lastDateEnd && _caseInfo.businessFunction != "RenewalRerate") { // KA001- MYS-2018-0878 Renewal Rerate
            let _lastDateEnd = moment(this.valueObj.lastDateEnd, "YYYY-MM-DD");
            if (_lastDateEnd < _effectiveDate || _lastDateEnd > _endDate) {
                result.isValid = false;
                result.message = result.message + "<dd> - Insured End date must be within the POI</dd>";
            }
        }

		/*if( this.valueObj.riskClassification =='Referred' && !(this.valueObj.referralReasons.referralReason && this.valueObj.referralReasons.referralReason.length > 0) ){
			result.isValid = false;
			result.message = result.message + "<br>Referral Reason is mandatory";
		}*/

        if (this.valueObj.ageLimitFlag == 'L') {
            result.isValid = false;
            result.message = result.message + "<dd> - Insured age is less than minimum age allowed limit</dd>";
        }
        else if (this.valueObj.ageLimitFlag == 'G') {
            result.isWarned = true;
            result.warningMessage = result.warningMessage + "<p> - Insured: " + this.valueObj.itemNo + ") Age is greater than maximum age allowed limit</p>";
        }

        if (this.valueObj.nomineeDetails)
            result = this.validateNomioneeDetails(result);

		/*if(!result.isValid && validHeaderMandatoryFields){
			// result.message = "<dl><dt>(Insured : "+this.valueObj.itemNo+"): Provide value for all mandatory fields.</dt><dd>" + result.message+"</dd>";
			result.message = "<dd><dl><dd>(Insured: "+this.valueObj.itemNo+"): Provide value for all mandatory fields.</dd><dd><dl>" + result.message +"</dl></dd>";
		}*/

		/*if(!result.isValid)
			result.message = result.message +"</dl></dd>";
		*/

        result.message = result.message + "</dl></dd>";

        return result;
    }

    private benefitsValidator() {
        let result = new ValidationResult();
        if (this.valueObj.planBenefits.benefit == null || this.valueObj.planBenefits.benefit == "") {
            result.isValid = false;
            result.message = "<dd> - Add Benefits in Coverage Information section</dd>";
        }
        else {
            let benefitItemsArr: any = [];
            benefitItemsArr = new AppUtil().getArray(this.valueObj.planBenefits.benefit);

            if (benefitItemsArr.length > 0) {

                result.isValid = true;
                for (let benefitItem of benefitItemsArr) {
                    if ((benefitItem.coverageCode == null || benefitItem.coverageCode == "") || (benefitItem.coverageDescription == null || benefitItem.coverageDescription == "") || (benefitItem.sumInsured == null || benefitItem.sumInsured <= 0)) {
                        result.isValid = false;
                    }
                }
                if (result.isValid == false) {
                    result.message = "<dd> - Fill all mandatory fields in Coverage Information section</dd>";
                }
            }
            else {
                result.isValid = false;
                result.message = "<dd> - Add benefit in Coverage Information section</dd>";
            }
        }

        return result;
    }

    validateNomioneeDetails(result) {
        if (this.valueObj.nomineeDetails != null) {

            if (this.valueObj.nomineeDetails.nominee != undefined && !(this.valueObj.nomineeDetails.nominee.constructor === Array)) {
                let nomineeItems: any = this.valueObj.nomineeDetails.nominee;
                this.valueObj.nomineeDetails.nominee = [nomineeItems];
            }

            if (this.valueObj.nomineeDetails.nominee.length > 0) {
                let percentageTotal: number = 0;
                for (let nominee of this.valueObj.nomineeDetails.nominee) {

                    result.fields.push("nomineeDetails");
                    let nomineeValid = new NomineeValidator(nominee).validate();
                    if (nomineeValid.isValid == false) {
                        result.isValid = false;
                        result.message = result.message + nomineeValid.message;
                        result.childsResult["nomineeDetails"] = nomineeValid;
                        result.validationResult["nomineeDetails"] = nomineeValid.isValid;
                        return result;
                    }
                    else {
                        //GA001 START
                        //percentageTotal = Number(percentageTotal) + Number(nominee.percentageOfShare);
                        percentageTotal = numeral(percentageTotal).add(parseFloat(nominee.percentageOfShare)).value();
                        //GA001 END
                    }
                }
                if (percentageTotal != 100) {
                    let nomineeDetails: ValidationResult = new ValidationResult();
                    nomineeDetails.isValid = false;
                    result.isValid = false;
                    nomineeDetails.message = "<dd> - Nominee Percentage Share Total is not equal to 100. Please make sure the total is equal to 100</dd>";
                    result.message = result.message + nomineeDetails.message;
                    result.childsResult["nomineeDetails"] = nomineeDetails;
                    result.validationResult["nomineeDetails"] = nomineeDetails.isValid;
                    return result;
                }
            }
        }
        return result;
    }

    getInvalidFieldMessages(valResult: ValidationResult, fieldNames, fields) {
        //let fields = Object.keys(valResult.validationResult);
        let missedFields = "";
        let count = 1;
        for (let fld of fields) {
            if (valResult.validationResult[fld] == false) {
                valResult.isValid = false;
                if (fieldNames[fld] == null) {
                    missedFields = missedFields + "<br/>- " + fld;
                }
                else {
                    missedFields = missedFields + "<br/>- " + fieldNames[fld];
                }
                count++;
            }
        }
        return missedFields;
    }

    getMissingFields(result, vFieldNames, vFields, data) {
        //let fields = Object.keys(valResult.validationResult);
        let missedFields = " ";
        let count = 1;
        for (let fld of vFields) {
            if (data[fld] == undefined || data[fld] == "") {
                result.isValid = false;
                if (vFieldNames[fld] == null) {
                    missedFields = missedFields + "<br/>- " + fld;
                }
                else {
                    missedFields = missedFields + "<br/>- " + vFieldNames[fld];
                }
                count++;
            }
        }
        return missedFields;
    }
}