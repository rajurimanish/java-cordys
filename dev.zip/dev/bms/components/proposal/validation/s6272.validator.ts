/*
 * Change History:
 * 
 * No      Date          Description                                   Changed By
 * ====    ==========    ===========                                   ==========
 * GA001   19/10/2018   MYS-2018-1291 : Incorrect rounding of 
 *                      Total share percentage of Nominee Details	  KGA
*/
import { Validator, ValidationResult } from '../../../../common/components/validator/validator';
import { S6272ItemDetails } from '../newbusinessrisks/s6271/appobjects/s6271';
import { NomineeValidator } from './nominee.validator';

declare var numeral: any;//GA001

export class S6272Validator extends Validator {
    public fields: Array<any> = [];

    public namedFields: Array<any> = ["insuredSalutation"];
    public namedFieldNames: any = { insuredSalutation: "Insured Person Salutation" };

    constructor(s6272Item: S6272ItemDetails) {
        super();
        this.valueObj = s6272Item;
        this.requiredFields = this.fields;
    }

    public validate() {

		/*
        let result = super.validate();
		let validHeaderMandatoryFields:boolean=true;
        // result.message = "<p style='padding-left: 25px'>Insured : "+this.valueObj.itemNo+" : Missing fields are,";
		
		if(result.isValid == false){
			validHeaderMandatoryFields=false;
			// result.message = this.valueObj.riskType +" (Insured : "+this.valueObj.itemNo+" ): Provide value for all mandatory fields";
			result.message = " <br>(Insured : "+this.valueObj.itemNo+" ): Provide value for all mandatory fields";
		}
		*/

        let result = new ValidationResult();
        result.isValid = true;
        result.message = "<dd><dl><dd>(Insured: " + this.valueObj.itemNo + "): Provide value for all mandatory fields.</dd>";

        //if ((this.valueObj.riskType=='FHI' || this.valueObj.riskType=='FHG') && (this.valueObj.insuredSalutation==undefined || this.valueObj.insuredSalutation=="")){
        //    result.isValid=false;
        //    result.message = result.message + "<br/>- Insured Person Salutation";
        //}
        if (this.valueObj.insuredPerson == undefined || this.valueObj.insuredPerson == "") {
            result.isValid = false;
            result.message = result.message + "<dd> - Insured Person Name </dd>";
        }
        if (this.valueObj.occupationCode == undefined || this.valueObj.occupationCode == "") {
            result.isValid = false;
            result.message = result.message + "<dd> - Occupation Code </dd>";
        }
        if (this.valueObj.occupationDescription == undefined || this.valueObj.occupationDescription == "") {
            result.isValid = false;
            result.message = result.message + "<dd> - Occupation Description </dd>";
        }

        if (this.valueObj.ratingClass == undefined || this.valueObj.ratingClass == "") {
            result.isValid = false;
            result.message = result.message + "<dd> - Occupation Class </dd>";
        }
        if (this.valueObj.IdProofNo == undefined || this.valueObj.IdProofNo.trim() == "") {
            result.isValid = false;
            result.message = result.message + "<dd> - IC/Passport Number </dd>";
        }
        else {
            let isValidNRICFormat = new RegExp("[0-9]{6}-[0-9]{2}-[0-9]{4}$").test(this.valueObj.IdProofNo);
            if (isValidNRICFormat == true) {
                if (this.valueObj.IdProofNo) {
                    let lastDigit = this.valueObj.IdProofNo.substring(this.valueObj.IdProofNo.length - 1);
                    if (/^-?\d*[02468]$/.test(lastDigit) && this.valueObj.gender != 'F') {
                        result.isValid = false;
                        result.message = result.message + "<dd> - Gender is not matching with IC Number </dd>";
                    }
                    if (/^-?\d*[13579]$/.test(lastDigit) && this.valueObj.gender != 'M') {
                        result.isValid = false;
                        result.message = result.message + "<dd> - Gender is not matching with IC Number </dd>";
                    }
                }
            }
        }

        if (this.valueObj.dateOfBirth == undefined || this.valueObj.dateOfBirth == "") {
            result.isValid = false;
            result.message = result.message + "<dd> - Date of Birth </dd>";
        }

        if (this.valueObj.gender == undefined || this.valueObj.gender == "") {
            result.isValid = false;
            result.message = result.message + "<dd> - Gender </dd>";
        }
        if (this.valueObj.maritalStatus == undefined || this.valueObj.maritalStatus == "") {
            result.isValid = false;
            result.message = result.message + "<dd> - Marital Status </dd>";
        }

        if (this.valueObj.nationality == undefined || this.valueObj.nationality == "") {
            result.isValid = false;
            result.message = result.message + "<dd> - Nationality </dd>";
        }

        if (this.valueObj.homeCity == undefined || this.valueObj.homeCity == "") {
            result.isValid = false;
            result.message = result.message + "<dd> - Home City </dd>";
        }

        if (this.valueObj.residence == undefined || this.valueObj.residence == "") {
            result.isValid = false;
            result.message = result.message + "<dd> - Residence </dd>";
        }

        if (this.valueObj.areaCode == undefined || this.valueObj.areaCode == "") {
            result.isValid = false;
            result.message = result.message + "<dd> - Area Code </dd>";
        }

        if (this.valueObj.plan == undefined || this.valueObj.plan == "") {
            result.isValid = false;
            result.message = result.message + "<dd> - Plan </dd>";
        }
        /**********
         * verify benefits data if required by iterating each of the benefit rows
         ********/
        if (this.valueObj.sumInsured == undefined || this.valueObj.sumInsured == "") {
            result.isValid = false;
            result.message = result.message + "<dd> - Annual Limit, Please select Occupation Class, Area Code and Plan to auto populate Annual Limit </dd>";
        }

        if (this.valueObj.lifeTime == undefined || this.valueObj.lifeTime == "") {
            result.isValid = false;
            result.message = result.message + "<dd> - Life Time, Please select Occupation Class, Area Code and Plan to auto populate Life Time Limit </dd>";
        }

        if (this.valueObj.areaMultiplier == undefined || this.valueObj.areaMultiplier == "") {
            result.isValid = false;
            result.message = result.message + "<dd> - Area Multiplier%, Please select Occupation Class, Area Code and Plan to auto populate Area Multiplier </dd>";
        }

        if (this.valueObj.occupationClassRate == undefined || this.valueObj.occupationClassRate == "") {
            result.isValid = false;
            result.message = result.message + "<dd> - Rate(Occupation Class), Please select Occupation Class, Area Code and Plan to auto populate Area Multiplier </dd>";
        }

        if (this.valueObj.basicPremium == undefined || this.valueObj.basicPremium == "") {
            result.isValid = false;
            result.message = result.message + "<dd> - Basic Premium. Please select Occupation Class, Area Code and Plan to auto populate basic premium </dd>";
        }
        if (this.valueObj.ratingFlag == 'A' && (this.valueObj.basicPremium && this.valueObj.basicPremium <= 0)) {
            result.isValid = false;
            result.message = result.message + "<dd> - Basic Premium cannot be less than zero. Please select Occupation Class, Area Code and Plan to auto populate </dd>";
        }
        if (this.valueObj.ratingFlag == 'M' && (this.valueObj.basicPremium && this.valueObj.basicPremium <= 0)) {
            result.isValid = false;
            result.message = result.message + "<dd> - Basic Premium cannot be less than zero in case of Manual Rating </dd>";
        }

        if (this.valueObj.ratingFlag == 'M' && (this.valueObj.postingPremium && this.valueObj.postingPremium <= 0)) {
            result.isValid = false;
            result.message = result.message + "<dd> - Posted Premium cannot be less than zero in case of Manual Rating </dd>";
        }

        if (this.valueObj.MATRPlanCode != undefined && this.valueObj.MATRPlanCode != "") {
            if (this.valueObj.MaternityDate == undefined || this.valueObj.MaternityDate == "") {
                result.isValid = false;
                result.message = result.message + "<dd> - Maternity Date (mandatory if maternity plan is selected) </dd>";
            }
            if (this.valueObj.ratingFlag == 'M' && (this.valueObj.maternityPremium && this.valueObj.maternityPremium <= 0)) {
                result.isValid = false;
                result.message = result.message + "<dd> - Maternity Premium cannot be less than zero in case of Manual Rating </dd>";
            }
        }
        if (this.valueObj.CRIIPlanCode != undefined && this.valueObj.CRIIPlanCode != "") {
            if (this.valueObj.CRIIDate == undefined || this.valueObj.CRIIDate == "") {
                result.isValid = false;
                result.message = result.message + "<dd> - Critical Illness Date (mandatory if Critical Illness plan is selected) </dd>";
            }
            if (this.valueObj.ratingFlag == 'M' && (this.valueObj.CRIIPremium && this.valueObj.CRIIPremium <= 0)) {
                result.isValid = false;
                result.message = result.message + "<dd> - Critical Illness (CRII) Premium cannot be less than zero in case of Manual Rating </dd>";
            }
        }

		/*if( this.valueObj.riskClassification =='Referred' && !(this.valueObj.referralReasons.referralReason && this.valueObj.referralReasons.referralReason.length > 0) ){
			result.isValid = false;
			result.message = result.message + "<br>Referral Reason is mandatory";
		}*/

        if (this.valueObj.ageLimitFlag == 'L') {
            result.isValid = false;
            result.message = result.message + "<dd> - Insured age is less than minimum age allowed limit </dd>";
        }
        else if (this.valueObj.ageLimitFlag == 'G') {
            result.isWarned = true;
            result.warningMessage = result.warningMessage + "<p> - Insured: " + this.valueObj.itemNo + ") Age is greater than maximum age allowed limit</p>";
        }

        if (this.valueObj.totalAnnualPremium == undefined || this.valueObj.totalAnnualPremium == "") {
            result.isValid = false;
            result.message = result.message + "<dd> - Total Annual Premium. Select Plan (for Brochure plans) or provide benefit details (for Non-Brochure plans) </dd>";
        } else if (this.valueObj.totalAnnualPremium.length > 14) {
            result.isValid = false;
            result.message = result.message + "<dd> - Total Annual Premium is very high. More than 11 digits </dd>";
        } else if (this.valueObj.totalAnnualPremium <= 0) {
            result.isValid = false;
            result.message = result.message + "<dd> - Total Annual Premium cannot be less than zero </dd>";
        }
        if (this.valueObj.nomineeDetails)
            result = this.validateNomioneeDetails(result);

        // result.message = result.message +"</p>";

		/*if(!result.isValid && validHeaderMandatoryFields){
			result.message = "<br> (Insured : "+this.valueObj.itemNo+"): Provide value for all mandatory fields.<br/>" + result.message;
		}*/

        result.message = result.message + "</dl></dd>";

        return result;
    }

    validateNomioneeDetails(result) {
        if (this.valueObj.nomineeDetails != null) {

            if (this.valueObj.nomineeDetails.nominee != undefined && !(this.valueObj.nomineeDetails.nominee.constructor === Array)) {
                let nomineeItems: any = this.valueObj.nomineeDetails.nominee;
                this.valueObj.nomineeDetails.nominee = [nomineeItems];
            }

            if (this.valueObj.nomineeDetails.nominee.length > 0) {
                let percentageTotal: number = 0;
                for (let nominee of this.valueObj.nomineeDetails.nominee) {

                    result.fields.push("nomineeDetails");
                    let nomineeValid = new NomineeValidator(nominee).validate();
                    if (nomineeValid.isValid == false) {
                        result.isValid = false;
                        result.message = result.message + nomineeValid.message;
                        result.childsResult["nomineeDetails"] = nomineeValid;
                        result.validationResult["nomineeDetails"] = nomineeValid.isValid;
                        return result;
                    }
                    else {
                        //GA001 START
                        //percentageTotal = Number(percentageTotal) + Number(nominee.percentageOfShare);
                        percentageTotal = numeral(percentageTotal).add(parseFloat(nominee.percentageOfShare)).value();
                        //GA001 END
                    }
                }
                if (percentageTotal != 100) {
                    let nomineeDetails: ValidationResult = new ValidationResult();
                    nomineeDetails.isValid = false;
                    result.isValid = false;
                    nomineeDetails.message = "<dd> - Nominee Percentage Share Total is not equal to 100. Please make sure the total is equal to 100 </dd>";
                    result.message = result.message + nomineeDetails.message;
                    result.childsResult["nomineeDetails"] = nomineeDetails;
                    result.validationResult["nomineeDetails"] = nomineeDetails.isValid;
                    return result;
                }
            }
        }
        return result;
    }
    getInvalidFieldMessages(valResult: ValidationResult, fieldNames, fields) {
        //let fields = Object.keys(valResult.validationResult);
        let missedFields = "";
        let count = 1;
        for (let fld of fields) {
            if (valResult.validationResult[fld] == false) {
                valResult.isValid = false;
                if (fieldNames[fld] == null) {
                    missedFields = missedFields + "<br/>- " + fld;
                }
                else {
                    missedFields = missedFields + "<br/>- " + fieldNames[fld];
                }
                count++;
            }
        }
        return missedFields;
    }
    getMissingFields(result, vFieldNames, vFields, data) {
        //let fields = Object.keys(valResult.validationResult);
        let missedFields = " ";
        let count = 1;
        for (let fld of vFields) {
            if (data[fld] == undefined || data[fld] == "") {
                result.isValid = false;
                if (vFieldNames[fld] == null) {
                    missedFields = missedFields + "<br/>- " + fld;
                }
                else {
                    missedFields = missedFields + "<br/>- " + vFieldNames[fld];
                }
                count++;
            }
        }
        return missedFields;
    }
}