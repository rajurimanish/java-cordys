/*
 * Change History:
 * 
 * No      Date          Description                                   Changed By
 * ====    ==========    ===========                                   ==========
 * VK004	05/12/2018	MYS-2018-1192								  	VKR
 * KA001   08/10/2019   MYS-2019-1024 - BMS Enhancement : AR            DKA
 *                      screen to combine RAA  DKA with Fire LOB
 * 
*/
import { Validator, ValidationResult } from '../../../../common/components/validator/validator';
import { GSTDetilsValidator } from './gstdetails.validator';
import { ExcessTypeValidator } from './excesstype.validator';
import { SurveyValidator } from './survey.validator';
import { S4805 } from '../newbusinessrisks/s4805/appobjects/s4805';
import { BMSConstants } from '../../common/constants/bms_constants';
import { AppUtil } from '../../../../common/components/utility/apputil/app.util';
import { FinancialInterstValidator } from './financialinterest.validator';

export class S4805Validator extends Validator {
    public fields: Array<any> = ["ratingFlag",
        "situation1",
        "postCode",
        "cityName",
        "occupationCode",
        "occupationDesc",
        "RIRetentionCode",
        "totalSI",
        "totalPremium"];
    public fieldNames: any = {
        ratingFlag: "Rating Flag",
        situation1: "Situation",
        postCode: "Post Code",
        cityName: "Town/City",
        construction: "Construction Class",
        accumulationRegister: "Fire Accumulation Register",
        localityRegister: "Locality Register",
        occupationCode: "Occupation",
        occupationDesc: "Occupation Description",
        RIRetentionCode: "RI Retention Code",
        RFTRatePercentage: "Fire Basic Rate %",
        totalSI: "Total Sum Insured",
        totalPremium: "Total Premium",
        basisOfCover: "Basis Of Cover",
        fullValue: "Full Value",
        tLimit: "Occupied By",
        hasClaimExperience: "Has Claim Experience?",
        "GSTDetails.riskUsage": "GST Risk Usage",
        "GSTDetails.riskLocation": "GST Risk Location",
        "GSTDetails.placeOfRecidence": "Place of Residence / Business",
        "GSTDetails.inputTaxAllowed": "Input Tax Allowed?"
    };
    constructor(s4805: S4805) {
        super();
        this.valueObj = s4805;
        this.requiredFields = this.fields;
    }

    public validate() {

        this.setMandatoryFields();

        let result = super.validate();
        let validHeaderMandatoryFields: boolean = true;
        if (result.isValid == false) {
            validHeaderMandatoryFields = false;
            result.message = this.valueObj.riskType + " (Risk Number: " + this.valueObj.riskNumber + " ): <p>Provide value for all mandatory fields.</p>" + this.getInvalidFields(result, this.fieldNames);
        }

        // if(this.valueObj.riskType!='PP2' && (!this.valueObj.RFTRatePercentage || !parseFloat(""+this.valueObj.RFTRatePercentage)) ){
        if ((this.valueObj.riskType == 'AR' || this.valueObj.riskType == 'ME') && (!this.valueObj.RFTRatePercentage || !parseFloat("" + this.valueObj.RFTRatePercentage))) {
            result.isValid = false;
            result.message = result.message + "<br>Fire Basic Rate % must be greater than 0.";
        }
        // KA001 MYS-2019-1024 : This code to be present during transition Period
        if (this.valueObj.riskType == 'AR'  && this.valueObj.RIRetentionCode == 'AR') {
            result.isValid = false;
            result.message = result.message + "<br>Please Reselect Occupation and Construction Class to proceed.";
        }
		/*if(this.valueObj.excessType && ((!this.valueObj.excessPercentage || parseFloat(""+this.valueObj.excessPercentage)<=0) && (!this.valueObj.excessAmount || parseFloat(""+this.valueObj.excessAmount)<=0)) ){
			result.isValid = false;			
			result.message = result.message + "<br>Excess Percentage or Excess Amount must be entered.";
		} else if(!this.valueObj.excessType && ((this.valueObj.excessPercentage && parseFloat(""+this.valueObj.excessPercentage)>0) || (this.valueObj.excessAmount && parseFloat(""+this.valueObj.excessAmount)>0)) ){
			result.isValid = false;			
			result.message = result.message + "<br>Excess Type cannot be blank.";
		}*/

        if ((this.valueObj.riskType == 'BG' || this.valueObj.riskType == 'PG') && (this.valueObj.basisOfCover == "1" || this.valueObj.basisOfCover == 1) && this.valueObj.fullValue <= 0) {
            result.isValid = false;
            result.message = result.message + "<br>Full value must be greater than 0";
        }

        let excessTypeResult = new ExcessTypeValidator(this.valueObj).validate();
        if (excessTypeResult.isValid == false) {
            result.isValid = false;
            result.message = result.message + excessTypeResult.message;
        }

        let coverageResult = this.coverageValidator();
        if (coverageResult.isValid == false) {
            result.isValid = false;
            result.message = result.message + coverageResult.message;
        }

        if (this.valueObj.riskType == "PP2") {
            let _caseStatus = BMSConstants.getBMSObj().ApplicationBusinessObject.caseInfo.status;
            if (_caseStatus == "Policy Processing") {
                if (this.valueObj.mandatoryPolicies.mandatoryPolicy == null || this.valueObj.mandatoryPolicies.mandatoryPolicy == "" || this.valueObj.mandatoryPolicies.mandatoryPolicy.length == 0) {
                    result.isValid = false;
                    result.message = result.message + "<p>Mandatory Policy details are mandatory.</p>";
                }
                else if (this.valueObj.mandatoryPolicies.mandatoryPolicy.length > 50) {
                    result.isValid = false;
                    result.message = result.message + "<p>Only 50 Mandatory Policies are allowed.</p>";
                }
            }
        }

        let gstDetailsResult = new GSTDetilsValidator(this.valueObj).validate();
        if (gstDetailsResult.isValid == false) {
            result.isValid = false;
            result.message = result.message + gstDetailsResult.message;
        }

        if (this.valueObj.FI == "Y") {
            let financialInterestValResult = new FinancialInterstValidator(this.valueObj).validate();
            if (financialInterestValResult.isValid == false) {
                result.isValid = false;
                if (result.message == null || result.message == "") {
                    result.message = financialInterestValResult.message;
                } else
                    result.message = result.message + financialInterestValResult.message;
            }
        }

        if (this.valueObj.isSurveyNeeded == "Y") {
            let surveyValidatorResult = new SurveyValidator(this.valueObj).validate();
            if (surveyValidatorResult.isValid == false) {
                result.isValid = false;
                if (result.message == null || result.message == "") {
                    result.message = surveyValidatorResult.message;
                } else
                    result.message = result.message + surveyValidatorResult.message;
            }
        }

		/*if(this.valueObj.RIRetentionCode){
			let _totalGrossCapacity = BMSConstants.getBmsUtilServiceObj().getNetRetentionAmountDetails(this.valueObj.RIRetentionCode);
			_totalGrossCapacity = (!_totalGrossCapacity) ? 0 : parseFloat(""+_totalGrossCapacity);
			
			let _capitalSumInsured = parseFloat(""+this.valueObj.capitalSumInsured);
			
			if( _totalGrossCapacity > 0 && _capitalSumInsured > _totalGrossCapacity && (this.valueObj.RIMethod == null || this.valueObj.RIMethod == "" || parseFloat(""+this.valueObj.RIMethod) != 8) ){
				result.isValid = false;			
				result.message = result.message + "<p>Capital Sum Insured is greater than Total Gross Capacity: "+_totalGrossCapacity+",  RI is Required.</p>";
			}
		}*/

        if (!result.isValid && validHeaderMandatoryFields) {
            result.message = this.valueObj.riskType + " (Risk Number: " + this.valueObj.riskNumber + " ): <p>Provide value for all mandatory fields.</p>" + result.message;
        }

		//VK004 General Page Text
		let headerInfo = BMSConstants.getBMSHeaderInfo();
		if(Number(this.valueObj.gpTextCount) > Number(headerInfo.gpTextMaxLines)) {
			result.isValid = false;
			result.message = this.valueObj.riskType+" (Risk Number: "+this.valueObj.riskNumber+" ): General Page Text entered is more than 400 lines.";
		}
		//VK004 END
        return result;
    }

    setMandatoryFields() {
        if (this.valueObj.riskType == 'AR') {
            this.fields.push("construction");
            this.fields.push("accumulationRegister");
            this.fields.push("localityRegister");
        } else if (this.valueObj.riskType == 'BG') {
            this.fields.push("basisOfCover");
            this.fields.push("tLimit");
        } else if (this.valueObj.riskType == 'PP2') {
            // this.fields.push("construction");
        } else if (this.valueObj.riskType == 'ME') {
            this.fields.push("construction");
            this.fields.push("accumulationRegister");
            this.fields.push("localityRegister");
        }
        else if (this.valueObj.riskType == 'EP') {
            this.fields.push("hasClaimExperience");
        }
    }
    private coverageValidator() {
        let result = new ValidationResult();
        if (this.valueObj.riskCoverageDetails.riskCoverage == null || this.valueObj.riskCoverageDetails.riskCoverage == "") {
            result.isValid = false;
            result.message = "<p>Add cover in Coverage Information section.</p>";
        }
        else {
            let riskCoverageItemsArr: any = [];
            if (Array.prototype.isPrototypeOf(this.valueObj.riskCoverageDetails.riskCoverage)) {
                riskCoverageItemsArr = this.valueObj.riskCoverageDetails.riskCoverage;
            } else {
                riskCoverageItemsArr = [this.valueObj.riskCoverageDetails.riskCoverage];
            }

            if (riskCoverageItemsArr.length > 0) {

                result.isValid = true;
                if (this.valueObj.riskType != 'PP2') {
                    let isRateGtRftRate: boolean = true;
                    for (let coverageItem of riskCoverageItemsArr) {
                        // if((coverageItem.interestInsured == null || coverageItem.interestInsured == "") || (coverageItem.sumInsured == null || coverageItem.sumInsured <=0) || (coverageItem.rate == null || coverageItem.rate <=0) || (coverageItem.premium == null || parseFloat(""+coverageItem.premium) <=0) || (coverageItem.premiumClass == null || coverageItem.premiumClass =="")){
                        if ((coverageItem.interestInsured == null || coverageItem.interestInsured == "") || (coverageItem.sumInsured == null || coverageItem.sumInsured <= 0) || (coverageItem.rate == null || coverageItem.rate <= 0) || (coverageItem.premiumClass == null || coverageItem.premiumClass == "")) {
                            result.isValid = false;
                        }

                        if ((this.valueObj.riskType == 'AR' || this.valueObj.riskType == 'ME' || this.valueObj.riskType == 'EP') && coverageItem.rate && parseFloat("" + coverageItem.rate) < parseFloat("" + this.valueObj.RFTRatePercentage)) {
                            isRateGtRftRate = false;
                        }
                    }

                    if (result.isValid == false) {
                        result.message = "<p>Fill all mandatory fields in Coverage Information section.</p>";
                    } else if (!isRateGtRftRate) {
                        result.isValid = false;
                        result.message = "<p>Rate % must be greater than Fire Basic Rate %</p>";
                    }
                }
            }
            else {
                result.isValid = false;
                result.message = "<p>Add cover in Coverage Information section.</p>";
            }
        }

        return result;
    }


}