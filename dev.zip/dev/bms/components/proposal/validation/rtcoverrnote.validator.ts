import { Validator, ValidationResult } from '../../../../common/components/validator/validator';
import { BMSConstants } from '../../common/constants/bms_constants';
import { AppUtil } from '../../../../common/components/utility/apputil/app.util';
import { RTCoverNote } from '../newbusinessrisks/motorcommercial/appobjects/misccovernote';

declare var moment: any;

export class RTCNValidator extends Validator {
    public fields: Array<any> = ["registrationNumber",
        "coverNoteType",
        "engineNumber",
        "chasisNumber",
        "cover",
        "inceptionDate",
        "endDate"];

    public fieldNames: any = {
        nric: "New NRIC",
        coverNoteType: "Cover Note Type",
        registrationNumber: "Vehicle Reg No",
        engineNumber: "Engine No",
        chasisNumber: "Chassis No",
        cover: "Cover",
        inceptionDate: "Inception Date",
        endDate: "End Date"
    };

    constructor(rtCN: RTCoverNote) {
        super();
        this.valueObj = rtCN;
        this.requiredFields = this.fields;
    }


    public validate() {
        let result = super.validate();

        if (result.isValid == false) {
            result.message = "Provide value for all mandatory fields.</p>" + this.getInvalidFields(result, this.fieldNames);
        }
        this.validateID(result);
        this.validateDates(result);
        this.validateVehicleClass(result);
        return result;
    }

    public validateID(result) {
        if (result.isValid == true) {
            if (this.valueObj.clientType == "P" && (AppUtil.isEmpty([this.valueObj.nric, this.valueObj.oldIc], false) == true)) {
                result.isValid = false;
                result.message = "Provide value for all mandatory fields.</p>" + "<p>For Personal client enter either New NRIC or Old IC No./Passport No.</p>";
            }
            else if (this.valueObj.clientType == "C" && (AppUtil.isEmpty([this.valueObj.oldIc], true) == true)) {
                result.isValid = false;
                result.message = "Provide value for all mandatory fields.</p>" + "<p>For Corporate client enter BIZ Reg No.</p>";
            }

            if (result.isValid == true) {
                if (AppUtil.isEmpty(this.valueObj.nric, false) == false) {
                    let format = /^\(?([0-9]{6})\)?[- ]?([0-9]{2})[- ]?([0-9]{4})$/;
                    if (!this.valueObj.nric.match(format)) {
                        result.isValid = false;
                        result.message = "NRIC field validation failed.</p>" + "<p>Enter NRIC in XXXXXX-XX-XXXX format. Ex: 870520-12-1234.</p>";
                    }
                }
            }

        }
    }

    public validateDates(result) {
        if (result.isValid == true) {
            if (moment(this.valueObj.inceptionDate, "YYYY-MM-DD") > moment(this.valueObj.endDate, "YYYY-MM-DD")) {
                result.isValid = false;
                result.message = "End date should not be less than inception date.";
            }
			/*else{
				let difference  = moment(this.valueObj.endDate,"YYYY-MM-DD").diff(moment(this.valueObj.inceptionDate,"YYYY-MM-DD"));
				if(moment.duration(difference).asMonths() > 12 || moment.duration(difference).asMonths() < 6 ){
					result.isValid = false;
					result.message = "Date difference can not be more than 12 months & can not be less than 6 months.";
				}				
			}*/
        }
    }

    public validateVehicleClass(result) {
        if (result.isValid == true) {
            if (moment(this.valueObj.inceptionDate, "YYYY-MM-DD") > moment(this.valueObj.endDate, "YYYY-MM-DD")) {
                result.isValid = false;
                result.message = "End date should not be less than inception date.";
            }
			/*else{
				let difference  = moment(this.valueObj.endDate,"YYYY-MM-DD").diff(moment(this.valueObj.inceptionDate,"YYYY-MM-DD"));
				if(moment.duration(difference).asMonths() > 12 || moment.duration(difference).asMonths() < 6 ){
					result.isValid = false;
					result.message = "Date difference can not be more than 12 months & can not be less than 6 months.";
				}				
			}*/
        }
    }
}