/*
* Change History	:
*
*	No      Date          	Description                Changed By
*	====    ==========    	===========	               ==========	
* 
* 	VK004	06/12/2018		MYS-2018-1192					VKR
*/
import { Validator, ValidationResult } from '../../../../common/components/validator/validator';
import { GSTDetilsValidator } from './gstdetails.validator';
import { S4811 } from '../newbusinessrisks/s4811/appobjects/s4811';
import { BMSConstants } from '../../common/constants/bms_constants';
import { AppUtil } from '../../../../common/components/utility/apputil/app.util';

export class S4811Validator extends Validator {
    public fields: Array<any> = ["RIRetentionCode",
        "businessCode",
        "businessCodeDesc",
        "placeOfEmp1",
        "aow"];
    public fieldNames: any = {
        RIRetentionCode: "RI Retention Code",
        businessCode: "Business of Insured",
        businessCodeDesc: "Business of Insured Description",
        placeOfEmp1: "Place of Employment 1",
        tLimit: "Territorial Limits",
        aow: "Common Law Liability (AOW - Any one Worker)",
        "GSTDetails.riskUsage": "GST Risk Usage",
        "GSTDetails.riskLocation": "GST Risk Location",
        "GSTDetails.placeOfRecidence": "GST Place of Residence",
        "contractDetails.contractPeriodFrom": "Contract Period - From",
        "contractDetails.contractPeriodTo": "Contract Period - To",
        "contractDetails.maintenancePeriodFrom": "Maintenace Period - From",
        "contractDetails.maintenancePeriodTo": "Maintenace Period - To",

    };
    constructor(s4811: S4811) {
        super();
        this.valueObj = s4811;
        this.requiredFields = this.fields;
    }

    public validate() {

        this.setMandatoryFields();

        let result = super.validate();
        let validHeaderMandatoryFields: boolean = true;
        if (result.isValid == false) {
            validHeaderMandatoryFields = false;
            result.message = this.valueObj.riskType + " (Risk Number: " + this.valueObj.riskNumber + " ): <p>Provide value for all mandatory fields.</p>" + this.getInvalidFields(result, this.fieldNames);
        }

        if ((this.valueObj.riskType == 'EL' || this.valueObj.riskType == 'WC') && (this.valueObj.aow == null || this.valueObj.aow <= 0)) {
            result.isValid = false;
            result.message = result.message + "<br>Common Law Liability (AOW - Any one Worker) is mandatory";
        }

        let coverageResult = this.coverageValidator();
        if (coverageResult.isValid == false) {
            result.isValid = false;
            result.message = result.message + coverageResult.message;
        }

        let gstDetailsResult = new GSTDetilsValidator(this.valueObj).validate();
        if (gstDetailsResult.isValid == false) {
            result.isValid = false;
            result.message = result.message + gstDetailsResult.message;
        }

		/*if(this.valueObj.RIRetentionCode){
			let _totalGrossCapacity = BMSConstants.getBmsUtilServiceObj().getNetRetentionAmountDetails(this.valueObj.RIRetentionCode);
			_totalGrossCapacity = (!_totalGrossCapacity) ? 0 : parseFloat(""+_totalGrossCapacity);
			
			let _capitalSumInsured = parseFloat(""+this.riskObj.capitalSumInsured);
			
			if( _totalGrossCapacity > 0 && _capitalSumInsured > _totalGrossCapacity && (this.valueObj.RIMethod == null || this.valueObj.RIMethod == "" || parseFloat(""+this.valueObj.RIMethod) != 8) ){
				result.isValid = false;			
				if(this.riskObj.riskType == 'WPA')
					result.message = result.message + "<p>Total Annual Earnings greater than Total Gross Capacity: "+_totalGrossCapacity+",  RI is Required.</p>";					
				else
					result.message = result.message + "<p>Common Law Liability is greater than Total Gross Capacity: "+_totalGrossCapacity+",  RI is Required.</p>";				
			}
		}*/

        if (!result.isValid && validHeaderMandatoryFields) {
            result.message = this.valueObj.riskType + " (Risk Number: " + this.valueObj.riskNumber + " ): <p>Provide value for all mandatory fields.</p>" + result.message;
        }

		//VK004 General Page Text
		let headerInfo = BMSConstants.getBMSHeaderInfo();
		if(Number(this.valueObj.gpTextCount) > Number(headerInfo.gpTextMaxLines)) {
			result.isValid = false;
			result.message = result.message + this.valueObj.riskType+" (Risk Number: "+this.valueObj.riskNumber+" ): General Page Text entered is more than 400 lines.";
		}
		//VK004 END
        return result;
    }

    private coverageValidator() {
        let result = new ValidationResult();
        if (this.valueObj.riskCoverageDetails.riskCoverage == null || this.valueObj.riskCoverageDetails.riskCoverage == "") {
            result.isValid = false;
            result.message = "<p>Add cover in Coverage Information section.</p>";
        }
        else {
            let riskCoverageItemsArr: any = [];
            if (Array.prototype.isPrototypeOf(this.valueObj.riskCoverageDetails.riskCoverage)) {
                riskCoverageItemsArr = this.valueObj.riskCoverageDetails.riskCoverage;
            } else {
                riskCoverageItemsArr = [this.valueObj.riskCoverageDetails.riskCoverage];
            }

            if (riskCoverageItemsArr.length > 0) {
                result.isValid = true;
                for (let coverageItem of riskCoverageItemsArr) {
                    if ((coverageItem.tariff == null || coverageItem.tariff == "") || (coverageItem.occupationDesc == null || coverageItem.occupationDesc == "") || (coverageItem.annualEarnings == null || coverageItem.annualEarnings <= 0) || (coverageItem.rate == null || coverageItem.rate <= 0)) {
                        result.isValid = false;
                    }
                }

                if (result.isValid == false) {
                    result.message = "<p>Fill all mandatory fields in Coverage Information section.</p>";
                }
            }
            else {
                result.isValid = false;
                result.message = "<p>Add cover in Coverage Information section.</p>";
            }
        }

        if (this.valueObj.riskType == 'WPA' && this.valueObj.comLawInd == 'Y' && (!this.valueObj.comLawPrcnt || parseFloat("" + this.valueObj.comLawPrcnt) <= 0)) {
            result.isValid = false;
            if (result.message == null || result.message == "") {
                result.message = "<br> Common Law Percentage is mandatory as Indicator is Yes.";
            } else {
                result.message = result.message + "<br> Common Law Percentage is mandatory as Indicator is Yes.";
            }
        }

        return result;
    }

    setMandatoryFields() {
        if (this.valueObj.riskType == 'EL') {
            this.fields.push("tLimit");
        }
        else if (this.valueObj.riskType == 'WC') {
            this.fields.push("tLimit");

            if (this.valueObj.contractDetails.contractPeriodFrom != null && this.valueObj.contractDetails.contractPeriodFrom != "") {
                this.fields.push("contractDetails.contractPeriodTo");
            }
            if (this.valueObj.contractDetails.contractPeriodTo != null && this.valueObj.contractDetails.contractPeriodTo != "") {
                this.fields.push("contractDetails.contractPeriodFrom");
            }
            if (this.valueObj.contractDetails.maintenancePeriodFrom != null && this.valueObj.contractDetails.maintenancePeriodFrom != "") {
                this.fields.push("contractDetails.maintenancePeriodTo");
            }
            if (this.valueObj.contractDetails.maintenancePeriodTo != null && this.valueObj.contractDetails.maintenancePeriodTo != "") {
                this.fields.push("contractDetails.maintenancePeriodFrom");
            }
        }
    }

}