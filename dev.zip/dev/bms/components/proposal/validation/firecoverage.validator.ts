import { Validator, ValidationResult } from '../../../../common/components/validator/validator';
import { FireItems } from '../newbusinessrisks/appobjects/fireItems';

export class FireCoverageValidator extends Validator {

    private riskObj;
    constructor(riskObj: Object) {
        super();
        this.riskObj = riskObj;
        this.valueObj = this.riskObj.fireItems;
    }

    public validate() {
        let result = new ValidationResult();

        if (this.valueObj == null || this.valueObj.fireItems == null || this.valueObj.fireItems == "") {
            result.isValid = false;
            result.message = "<p>Add cover in Coverage Information section.</p>";
        }
        else if (Array.prototype.isPrototypeOf(this.valueObj.fireItems)) {
            if (this.valueObj.fireItems.length > 0) {
                result.isValid = true;
                for (let fireItem of this.valueObj.fireItems) {
                    if ((fireItem.cover == null || fireItem.cover == "") || (fireItem.premiumClass == null || fireItem.premiumClass == "") || (fireItem.sumInsured == null || fireItem.sumInsured == "" || parseFloat("" + fireItem.sumInsured) <= 0)) {
                        result.isValid = false;
                    }
                    if (this.riskObj.riskType == 'ECP' && (fireItem.rate == null || fireItem.rate == "" || parseFloat("" + fireItem.rate) <= 0)) {
                        result.isValid = false;
                    }
                }

                if (result.isValid == false) {
                    result.message = "<p>Fill all mandatory information in coverage table.</p>";
                }

                let _isInvalidRate = false;
                for (let fireItem of this.valueObj.fireItems) {
                    if (!(fireItem.rate == null || fireItem.rate == "") && parseFloat("" + fireItem.rate) > 99.99999) {
                        _isInvalidRate = true;
                        break;
                    }
                }
                if (_isInvalidRate) {
                    result.isValid = false;
                    result.message = "<p>Coverage Total Rate should not more than 99.99999</p>";
                }

				/*if(this.riskObj.riskType=='ARI'){ //commenting as mentioned in Redmine #2092
					let _fireItems = this.valueObj.fireItems.filter( (_item)=> _item.premiumClass === '18C');
					if( _fireItems && _fireItems.length > 1){
						result.isValid = false;
						result.message = "<p>Premium Class: IND ALL RISK - LOSS OF PROFIT is not allowed to add more than once.</p>";
					}
				}*/

            }
            else {
                result.isValid = false;
                result.message = "<p>Add cover in Coverage Information section.</p>";
            }
        }
        else if (!Array.prototype.isPrototypeOf(this.valueObj.fireItems)) {
            let tempAry: any = this.valueObj.fireItems;
            let fireItemsAry = [tempAry];
            if (fireItemsAry[0].code == null) {
                result.isValid = false;
                result.message = "<p>Add cover in Coverage Information section.</p>";
            }
            else {
                result.isValid = true;
                for (let fireItem of fireItemsAry) {
                    if ((fireItem.cover == null || fireItem.cover == "") || (fireItem.premiumClass == null || fireItem.premiumClass == "") || (fireItem.sumInsured == null || fireItem.sumInsured == "" || parseFloat("" + fireItem.sumInsured) <= 0)) {
                        result.isValid = false;
                    }
                    if (this.riskObj.riskType == 'ECP' && (fireItem.rate == null || fireItem.rate == "" || parseFloat("" + fireItem.rate) <= 0)) {
                        result.isValid = false;
                    }
                }

                if (result.isValid == false) {
                    result.message = "<p>Fill all mandatory information in coverage table.</p>";
                }

                let _isInvalidRate = false;
                for (let fireItem of fireItemsAry) {
                    if (!(fireItem.rate == null || fireItem.rate == "") && parseFloat("" + fireItem.rate) > 99.99999) {
                        result.isValid = false;
                        _isInvalidRate = true;
                        break;
                    }
                }
                if (_isInvalidRate) {
                    result.message = "<p>Coverage Total Rate should not more than 99.99999</p>";
                }
            }
        }
        return result;
    }
}