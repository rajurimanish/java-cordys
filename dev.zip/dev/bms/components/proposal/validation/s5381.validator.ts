/*
* Change History	:
*
*	No      Date          	Description                Changed By
*	====    ==========    	===========	               ==========	
* 
* 	VK004	06/12/2018		MYS-2018-1192					VKR
*/
import { Validator, ValidationResult } from '../../../../common/components/validator/validator';
import { GSTDetilsValidator } from './gstdetails.validator';
import { S5381, S5382ItemDetails } from '../newbusinessrisks/s5381/appobjects/s5381';
import { S5382Validator } from './s5382.validator';
import { BMSConstants } from '../../common/constants/bms_constants';

export class S5381Validator extends Validator {
    public fields: Array<any> = [
        "insuredPerson",
        "occupationCode",
        "occupationDescription",
        "capitalSumInsured"
    ];
    public fieldNames: any = {
        insuredPerson: "Insured Person",
        occupationCode: "Occupation Code",
        occupationDescription: "Occupation Description",
        capitalSumInsured: "Capital Sum Insured"
    };
    constructor(s5381: S5381) {
        super();
        this.valueObj = s5381;
        this.requiredFields = this.fields;
    }

    public validate() {
		/*
		let result = super.validate();
		let validHeaderMandatoryFields:boolean=true;
		if(result.isValid == false){
			validHeaderMandatoryFields=false;			
			result.message = this.valueObj.riskType+" (Risk Number: "+this.valueObj.riskNumber+"): Missing fields are:" + this.getInvalidFields(result, this.fieldNames);
		}*/

        let result = new ValidationResult();
        result.isValid = true;
        result.message = this.valueObj.riskType + " (Risk Number: " + this.valueObj.riskNumber + "): Missing fields are:<dl>";

        if (this.valueObj.insuredPerson == undefined || this.valueObj.insuredPerson == "") {
            result.isValid = false;
            result.message = result.message + "<dd> - Insured Person</dd>";
        }

        if (this.valueObj.occupationCode == undefined || this.valueObj.occupationCode == "") {
            result.isValid = false;
            result.message = result.message + "<dd> - Occupation</dd>";
        }

        if (this.valueObj.occupationDescription == undefined || this.valueObj.occupationDescription == "") {
            result.isValid = false;
            result.message = result.message + "<dd> - Occupation Description</dd>";
        }

        if (!this.validateInsured()) {
            result.isValid = false;
            result.message = result.message + "<dd> - Add at least one insured</dd>";
        } else {

            if (this.valueObj.capitalSumInsured <= 0) {
                result.isValid = false;
                result.message = result.message + "<dd> - Capital Sum Insured (must be greater than 0, select a valid plan to auto populate)</dd>";
            }

            let allRisks = [];
            if (!Array.prototype.isPrototypeOf(this.valueObj.s5382Items.s5382Item)) {
                let tempAry: any = this.valueObj.s5382Items.s5382Item;
                allRisks = [tempAry];
            }
            else {
                allRisks = this.valueObj.s5382Items.s5382Item;
            }

            let count = 1;
            let chCount = 1;
            for (let eachRisk of allRisks) {
                let s5382Result = new S5382Validator(eachRisk).validate();
                if (s5382Result.isValid == false) {
                    result.isValid = false;
                    result.message = result.message + s5382Result.message;
                    count++;
                }
                if (s5382Result.isWarned) {
                    result.isWarned = true;
                    result.warningMessage = result.warningMessage + s5382Result.warningMessage;
                    //count++;
                }
                result.childsResult[this.valueObj.riskType + "" + chCount] = s5382Result;
                chCount++;
            }
        }

        let gstDetailsResult = new GSTDetilsValidator(this.valueObj).validate();
        if (gstDetailsResult.isValid == false) {
            result.isValid = false;
            result.message = result.message + gstDetailsResult.message;
        }

		/*		
		else{
			result.message = "<p>"+this.valueObj.riskType+", Risk No: "+this.valueObj.riskNumber+" Provide value for mandatory fields.</p><br/>"+result.message;
		}*/

		/*if(!result.isValid && validHeaderMandatoryFields){
			result.message = this.valueObj.riskType+" (Risk Number: "+this.valueObj.riskNumber+"): Missing fields are:" + result.message;			
		}*/

        result.message = result.message + "</dl>";
		//VK004 General Page Text
		let headerInfo = BMSConstants.getBMSHeaderInfo();
		if(Number(this.valueObj.gpTextCount) > Number(headerInfo.gpTextMaxLines)) {
			result.isValid = false;
			result.message = this.valueObj.riskType+" (Risk Number: "+this.valueObj.riskNumber+" ): General Page Text entered is more than 400 lines.";
		}
		//VK004 END

        return result;
    }

    validateInsured() {
        let addedInsured = false;
        if (this.valueObj.s5382Items != null && this.valueObj.s5382Items.s5382Item != null && this.valueObj.s5382Items.s5382Item != "") {
            if (Array.prototype.isPrototypeOf(this.valueObj.s5382Items.s5382Item) && this.valueObj.s5382Items.s5382Item.length > 0) {
                addedInsured = true;
            }
            else if (Array.prototype.isPrototypeOf(this.valueObj.s5382Items.s5382Item) && this.valueObj.s5382Items.s5382Item.length == 0) {
                addedInsured = false;
            }
            else {
                addedInsured = true;
            }
        }
        return addedInsured;
    }
}