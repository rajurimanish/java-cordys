
/*
 * Change History:
 * 
 * No      Date          Description                                  			Changed By
 * ====    ==========    ===========                                  			==========
 * AL001   15/08/2017   MYS-2017-0371    -  Develop MPD               				ALA
 * 
 * GA001   20/12/2017   MYS-2017-1118 - To create a new code for the below 
 *						additional benefit (E57A and M010)   	  	  				KGA
 * 
 * SR001   27/02/2018	MYS-2018-0083 - To enhance MPC and MPF Policy 
 * 						to allow Non-Tariff Add-On and Remove M001-M010 
 * 						Validations for MPD and make PAM Risk mandatory.			VSR	
 * 
 * MD001   14/02/2017   MYS-2017-0920    -  ABC PA to be incorporated into BMS      MKU1
 * 
 * SR002   02/08/2018	MYS-2018-0936 - Enable M003 for MPC, MPD, MPF				VSR
 * E1001   15/11/2018   MYS-2018-1366 - Sum Insured validation not applicable       SRE1
 *                      for ARI cases when Co-Inwards,Fac RI Inwards-Local,Fac RI
 *                      Inwards-Overseas               
 * KA001   01/04/2019   MYS-2018-0360    -  MPD Renewal           				    DKA		
 * YPK001  04/10/2019   MYS-2019-0198 Allow STP for simplified products           PKU1
 *                     	
*/
import { Validator, ValidationResult } from '../../../../common/components/validator/validator';
import { Risks } from '../appobjects/proposal';
import { BMSConstants } from '../../common/constants/bms_constants';
import { RiskArray } from '../../proposal/proposalheader/uimodules/riskArray';

export class RisksValidator extends Validator {
    constructor(risks: Risks) {
        super();
        this.valueObj = risks;
    }

    validate() {
        let result = new ValidationResult();
        result.isValid = true;
        let premiumTotal = 0;
        let minPremium = 0;
        let ari_isValidARateBasis = '';
        let ari_isVAlidLRateBasis = '';
        let riskList = Object.keys(this.valueObj);
        if (this.hasRisks()) {
            let resultByField = {};
            let rtIdx = 0;
            for (let eachRiskAry of riskList) {
                if (this.valueObj[eachRiskAry].length > 0) {
                    resultByField[eachRiskAry] = true;
                    let allRisks: Array<any> = this.valueObj[eachRiskAry];
                    let rkIdx = 1;
                    for (let eachRisk of allRisks) {
                        let count = (rtIdx * allRisks.length) + rkIdx;
                        if (eachRiskAry != "generic") { //Endorsements Code -- Added condition to skip all Generic Products
                            switch (eachRisk.riskType) {
                                case "NPA":
                                case "OSI":
                                case "OSS":
                                case "PAX":
                                    let nparesult = eachRisk.getValidator().validate();
                                    // let count = (rtIdx * allRisks.length) + rkIdx;
                                    result.childsResult[eachRiskAry] = nparesult;
                                    //this.validateTotalPremium(eachRisk, nparesult);
                                    premiumTotal = premiumTotal + parseFloat(eachRisk.totalPremium);
                                    minPremium = eachRisk.minimumPremium;
                                    if (nparesult.isValid == false) {
                                        resultByField[eachRiskAry] = false;
                                        result.isValid = false;
                                        result.message = result.message + "<p>" + count + ") " + nparesult.message + "</p>";
                                    }
                                    if (nparesult.isWarned) {
                                        result.isWarned = true;
                                        result.warningMessage += "<p>" + count + ") " + nparesult.warningMessage + "</p>";
                                    }
                                    break;
                                case "PAM": //AL001
                                case "DPA":
                                    let dparesult = eachRisk.getValidator().validate();
                                    result.childsResult[eachRiskAry] = dparesult;
                                    //this.validateTotalPremium(eachRisk, dparesult);
                                    premiumTotal = premiumTotal + parseFloat(eachRisk.totalPremium);
                                    minPremium = eachRisk.minimumPremium;
                                    // let count = (rtIdx * allRisks.length) + rkIdx;
                                    if (dparesult.isValid == false) {
                                        resultByField[eachRiskAry] = false;
                                        result.isValid = false;
                                        result.message = "<p>" + count + ") DPA Risk Table: Validation failed." + "</p>" + dparesult.message;
                                    }
                                    if (dparesult.isWarned) {
                                        result.isWarned = true;
                                        result.warningMessage += "<p>" + count + ") " + dparesult.warningMessage + "</p>";
                                    }
                                    break;
                                case "MCF":
                                case "MCT":
                                case "MCY":
                                case "MPC":
                                case "MPF": // SR002
                                case "MPT": // SR002
                                case "MPD":
                                    /* SR001 Changes Starts */
                                    let additionalSelectedValid = true;
                                    eachRisk.motorItems.motorItem.forEach(element => {
                                        if (element.code == 'M003' && eachRisk.CI != 'MX22')
                                            additionalSelectedValid = false;
                                    });
                                    // SR002 Added the below validation to check CI Type and M003 Addon
                                    if (eachRisk.CI == 'MX22' && eachRisk.motorItems.motorItem.findIndex(addBenefit => addBenefit.code === 'M003') == -1) {
                                        result.message = "<p>" + count + ") Certificate of Insurance cannot be MX22.</p>";
                                        result.isValid = false;
                                        break;
                                    }
                                    if (!additionalSelectedValid) {
                                        let count = (rtIdx * allRisks.length) + rkIdx;
                                        result.isValid = false;
                                        result.message = "<p>" + count + ") Change the C/I Type to MX22 Or Remove 'M003' Additional Benefit.</p>";
                                        break;
                                    }
                                    /* SR001 Changes Ends */
                                    //AL001 START
                                    if (eachRisk.riskType == 'MPD') {
                                        /* SR001 Changes Starts */
                                        // Commenting the below code to remove validation for MPD for M001 and M010 benefits
                                        /*let additionalSelected=false;
                                eachRisk.motorItems.motorItem.forEach(element => {
                                              if(element.code=="M001"|| element.code=="M010") //GA001
                                              additionalSelected=true;
                                          });
                                          
                                          if(this.valueObj["driverPersonalAccident"]=="" && !additionalSelected){
                                              // let count = (rtIdx * allRisks.length) + rkIdx;
                                              result.message = "<p>" + count + ") MPD Risk Table: Validation failed."+"</p>" + 
                                              "Please select M001 / M010 or PAM Risk for MPD.";
                                              result.isValid=false;
                                              break;
                                        }*/
                                        //AL001 END
                                        if (this.valueObj["driverPersonalAccident"] == "") {
                                            let count = (rtIdx * allRisks.length) + rkIdx;
                                            result.message = "<p>" + count + ") Add Risk: Please add PAM risk along with MPD.</p>";
                                            result.isValid = false;
                                            break;
                                        }
                                        /* SR001 Changes Ends */
                                    }
                                case "CV":
                                case "CVF":
                                case "CVT":
                                case "HVC":
                                case "HVF":
                                case "HVT":
                                case "MTC":
                                case "MTF":
                                case "MTT":
                                    let motorresult = eachRisk.getValidator().validate();
                                    result.childsResult[eachRiskAry] = motorresult;
                                    //this.validateTotalPremium(eachRisk, motorresult);
                                    premiumTotal = premiumTotal + parseFloat(eachRisk.totalPremium);
                                    minPremium = eachRisk.minimumPremium;
                                    // let count = (rtIdx * allRisks.length) + rkIdx;
                                    if (motorresult.isValid == false) {
                                        resultByField[eachRiskAry] = false;
                                        result.isValid = false;
                                        result.message = "<p>" + result.message + count + ") " + motorresult.message + "</p>";
                                    }
                                    if (motorresult.isWarned) {
                                        result.isWarned = true;
                                        result.warningMessage += "<p>" + count + ") " + motorresult.warningMessage + "</p>";
                                    }
                                    if (['HVC', 'HVT', 'HVF'].indexOf(eachRisk.riskType) != -1) {
                                        let additionalSelectedValid = true;
                                        if (eachRisk.motorItems.motorItem.findIndex(addBenefit => addBenefit.code === 'E38A') != -1) {
                                            if (eachRisk.motorItems.motorItem.findIndex(addBenefit => addBenefit.code === 'E38') == -1 || eachRisk.motorItems.motorItem.findIndex(addBenefit => addBenefit.code === 'E38B') == -1) {
                                                additionalSelectedValid = false;
                                            }
                                        }
                                        if (!additionalSelectedValid) {
                                            let count = (rtIdx * allRisks.length) + rkIdx;
                                            result.isValid = false;
                                            result.message = "<p>" + count + ") Cannot Add E38A Additional Benefit as E38 and E38B is Benefit is not added.</p>";
                                            break;
                                        }
                                    }
                                    break;
                                case "ARI":
                                case "ECP":
                                case "FC1":
                                case "FC2":
                                case "FC3":
                                case "FD1":
                                case "FD2":
                                case "FD3":
                                case "PP1":
                                case "IIF":
                                    let idcresult = eachRisk.getValidator().validate();
                                    result.childsResult[eachRiskAry] = idcresult;
                                    //this.validateTotalPremium(eachRisk, idcresult);
                                    premiumTotal = premiumTotal + parseFloat(eachRisk.totalPremium);
                                    minPremium = eachRisk.minimumPremium;
                                    // let count = (rtIdx * allRisks.length) + rkIdx;
                                    if (idcresult.isValid == false) {
                                        resultByField[eachRiskAry] = false;
                                        result.isValid = false;
                                        result.message = "<p>" + result.message + count + ") " + idcresult.message + "</p>";
                                    }

                                    if (eachRisk.riskType == 'ARI') {
                                        let _totalSumInsured = parseFloat("" + eachRisk.totalSI);
                                        if (eachRisk.rateBasis == 'A') {
                                            if (_totalSumInsured < 50000000) {
                                                ari_isValidARateBasis = (ari_isValidARateBasis != 'Y') ? 'N' : ari_isValidARateBasis;
                                            } else ari_isValidARateBasis = 'Y';
                                        }
                                        else if (eachRisk.rateBasis == 'L') {
                                            if (_totalSumInsured < 300000000) {
                                                ari_isVAlidLRateBasis = (ari_isVAlidLRateBasis != 'Y') ? 'N' : ari_isVAlidLRateBasis;
                                            } else ari_isVAlidLRateBasis = 'Y';
                                        }
                                    }
                                    if (idcresult.isWarned) {
                                        result.isWarned = true;
                                        result.warningMessage += "<p>" + count + ") " + idcresult.warningMessage + "</p>";
                                    }
                                    break;
                                case "LOP":
                                    let lopresult = eachRisk.getValidator().validate();
                                    result.childsResult[eachRiskAry] = lopresult;
                                    //this.validateTotalPremium(eachRisk, lopresult);
                                    premiumTotal = premiumTotal + parseFloat(eachRisk.totalPremium);
                                    minPremium = eachRisk.minimumPremium;
                                    // let count = (rtIdx * allRisks.length) + rkIdx;
                                    if (lopresult.isValid == false) {
                                        resultByField[eachRiskAry] = false;
                                        result.isValid = false;
                                        result.message = "<p>" + result.message + count + ") " + lopresult.message + "</p>";
                                    }
                                    if (lopresult.isWarned) {
                                        result.isWarned = true;
                                        result.warningMessage += "<p>" + count + ") " + lopresult.warningMessage + "</p>";
                                    }
                                    break;
                                case "TAA":
                                case "TDA":
                                case "TDI":
                                case "TPI":
                                    let travelresult = eachRisk.getValidator().validate();
                                    result.childsResult[eachRiskAry] = travelresult;
                                    premiumTotal = premiumTotal + parseFloat(eachRisk.totalPremium);
                                    minPremium = eachRisk.minimumPremium;
                                    // let count = (rtIdx * allRisks.length) + rkIdx;
                                    if (travelresult.isValid == false) {
                                        resultByField[eachRiskAry] = false;
                                        result.isValid = false;
                                        result.message = result.message + "<p>" + count + ") " + travelresult.message + "</p>";
                                    }
                                    if (travelresult.isWarned) {
                                        result.isWarned = true;
                                        result.warningMessage += "<p>" + count + ") " + travelresult.warningMessage + "</p>";
                                    }
                                    break;
                                case "HHO":
                                    let s4846result = eachRisk.getValidator().validate();
                                    result.childsResult[eachRiskAry] = s4846result;
                                    premiumTotal = premiumTotal + parseFloat(eachRisk.totalPremium);
                                    minPremium = eachRisk.minimumPremium;
                                    // let count = (rtIdx * allRisks.length) + rkIdx;
                                    if (s4846result.isValid == false) {
                                        resultByField[eachRiskAry] = false;
                                        result.isValid = false;
                                        result.message = result.message + "<p>" + count + ") " + s4846result.message + "</p>";
                                    }
                                    if (s4846result.isWarned) {
                                        result.isWarned = true;
                                        result.warningMessage += "<p>" + count + ") " + s4846result.warningMessage + "</p>";
                                    }
                                    break;
                                case "EL":
                                case "WC":
                                case "WPA":
                                    let s4811result = eachRisk.getValidator().validate();
                                    result.childsResult[eachRiskAry] = s4811result;
                                    premiumTotal = premiumTotal + parseFloat(eachRisk.totalPremium);
                                    minPremium = eachRisk.minimumPremium;
                                    // let count = (rtIdx * allRisks.length) + rkIdx;
                                    if (s4811result.isValid == false) {
                                        resultByField[eachRiskAry] = false;
                                        result.isValid = false;
                                        result.message = result.message + "<p>" + count + ") " + s4811result.message + "</p>";
                                    }
                                    if (s4811result.isWarned) {
                                        result.isWarned = true;
                                        result.warningMessage += "<p>" + count + ") " + s4811result.warningMessage + "</p>";
                                    }
                                    break;
                                case "AR":
                                case "ARP":
                                case "SR":
                                case "BG":
                                case "PG":
                                case "PP2":
                                case "EP":
                                case "ME":
                                    let s4805result = eachRisk.getValidator().validate();
                                    result.childsResult[eachRiskAry] = s4805result;
                                    premiumTotal = premiumTotal + parseFloat(eachRisk.grossPremium);//Redmine - 1962
                                    minPremium = eachRisk.minimumPremium;
                                    // let count = (rtIdx * allRisks.length) + rkIdx;
                                    if (s4805result.isValid == false) {
                                        resultByField[eachRiskAry] = false;
                                        result.isValid = false;
                                        result.message = result.message + "<p>" + count + ") " + s4805result.message + "</p>";
                                    }
                                    if (s4805result.isWarned) {
                                        result.isWarned = true;
                                        result.warningMessage += "<p>" + count + ") " + s4805result.warningMessage + "</p>";
                                    }
                                    break;
                                case "MIT":
                                    let s4808result = eachRisk.getValidator().validate();
                                    result.childsResult[eachRiskAry] = s4808result;
                                    premiumTotal = premiumTotal + parseFloat(eachRisk.totalPremium);
                                    minPremium = eachRisk.minimumPremium;
                                    // let count = (rtIdx * allRisks.length) + rkIdx;
                                    if (s4808result.isValid == false) {
                                        resultByField[eachRiskAry] = false;
                                        result.isValid = false;
                                        result.message = result.message + "<p>" + count + ") " + s4808result.message + "</p>";
                                    }
                                    if (s4808result.isWarned) {
                                        result.isWarned = true;
                                        result.warningMessage += "<p>" + count + ") " + s4808result.warningMessage + "</p>";
                                    }
                                    break;
                                case "FPA":
                                    let s4857result = eachRisk.getValidator().validate();
                                    result.childsResult[eachRiskAry] = s4857result;
                                    // let count = (rtIdx * allRisks.length) + rkIdx;
                                    if (s4857result.isValid == false) {
                                        resultByField[eachRiskAry] = false;
                                        result.isValid = false;
                                        result.message = result.message + "<p>" + count + ") " + s4857result.message + "</p>";
                                    }
                                    if (s4857result.isWarned) {
                                        result.isWarned = true;
                                        result.warningMessage += "<p>" + count + ") " + s4857result.warningMessage + "</p>";
                                    }
                                    break;
                                case "FGR":
                                    let s4861result = eachRisk.getValidator().validate();
                                    result.childsResult[eachRiskAry] = s4861result;
                                    premiumTotal = premiumTotal + parseFloat(eachRisk.totalPremium);
                                    minPremium = eachRisk.minimumPremium;
                                    // let count = (rtIdx * allRisks.length) + rkIdx;
                                    if (s4861result.isValid == false) {
                                        resultByField[eachRiskAry] = false;
                                        result.isValid = false;
                                        result.message = result.message + "<p>" + count + ") " + s4861result.message + "</p>";
                                    }
                                    if (s4861result.isWarned) {
                                        result.isWarned = true;
                                        result.warningMessage += "<p>" + count + ") " + s4861result.warningMessage + "</p>";
                                    }

                                    break;
                                case "PAC":
                                case "PAG":
                                case "PAS":
                                case "MSC":
                                case "PMA":
                                case "PMB":
                                case "PMC":
                                case "PMP":
                                case "MSW":
                                case "MWP":
                                case "MWH":
                                case "MPA":
                                case "FPB"://MD001
                                    let s5335result = eachRisk.getValidator().validate();
                                    result.childsResult[eachRiskAry] = s5335result;
                                    // let count = (rtIdx * allRisks.length) + rkIdx;
                                    if (s5335result.isValid == false) {
                                        resultByField[eachRiskAry] = false;
                                        result.isValid = false;
                                        result.message = result.message + "<p>" + count + ") " + s5335result.message + "</p>";
                                    }
                                    if (s5335result.isWarned) {
                                        result.isWarned = true;
                                        result.warningMessage += "<p>" + count + ") " + s5335result.warningMessage + "</p>";
                                    }
                                    break;
                                case "MAR":
                                case "MCA":
                                    let s4804result = eachRisk.getValidator().validate();
                                    result.childsResult[eachRiskAry] = s4804result;
                                    // let count = (rtIdx * allRisks.length) + rkIdx;
                                    if (s4804result.isValid == false) {
                                        resultByField[eachRiskAry] = false;
                                        result.isValid = false;
                                        result.message = result.message + "<p>" + count + ") " + s4804result.message + "</p>";
                                    }
                                    if (s4804result.isWarned) {
                                        result.isWarned = true;
                                        result.warningMessage += "<p>" + count + ") " + s4804result.warningMessage + "</p>";
                                    }
                                    break;
                                case "PL":
                                case "PPL":
                                case "IPL":
                                case "PP3":
                                    let s4810result = eachRisk.getValidator().validate();
                                    result.childsResult[eachRiskAry] = s4810result;
                                    // let count = (rtIdx * allRisks.length) + rkIdx;
                                    if (s4810result.isValid == false) {
                                        resultByField[eachRiskAry] = false;
                                        result.isValid = false;
                                        result.message = result.message + "<p>" + count + ") " + s4810result.message + "</p>";
                                    }
                                    if (s4810result.isWarned) {
                                        result.isWarned = true;
                                        result.warningMessage += "<p>" + count + ") " + s4810result.warningMessage + "</p>";
                                    }
                                    break;
                                case "EMC":
                                case "HIG":
                                case "HGM":
                                case "HMG":
                                case "HII":
                                case "HIC":
                                case "HMI":
                                    let s5381result = eachRisk.getValidator().validate();
                                    result.childsResult[eachRiskAry] = s5381result;
                                    // let count = (rtIdx * allRisks.length) + rkIdx;
                                    if (s5381result.isValid == false) {
                                        resultByField[eachRiskAry] = false;
                                        result.isValid = false;
                                        result.message = result.message + "<p>" + count + ") " + s5381result.message + "</p>";
                                    }
                                    if (s5381result.isWarned) {
                                        result.isWarned = true;
                                        result.warningMessage += "<p>" + count + ") " + s5381result.warningMessage + "</p>";
                                    }
                                    break;
                                case "FHG":
                                case "FHI":
                                case "FSI":
                                    let _caseStatus = BMSConstants.getBMSObj().ApplicationBusinessObject.caseInfo.status;
                                    let _clientType = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.clientDetails.client.genericDetails.clienttype;
                                    if (_caseStatus == "Policy Processing" && _clientType == 'C') {
                                        result.isWarned = true;
                                        result.warningMessage += "<p>- Policy will be moved to 'P400 Pending NB' state and check the commission before policy issuance.</p>";
                                    }

                                    let s6271result = eachRisk.getValidator().validate();
                                    result.childsResult[eachRiskAry] = s6271result;
                                    // let count = (rtIdx * allRisks.length) + rkIdx;
                                    if (s6271result.isValid == false) {
                                        resultByField[eachRiskAry] = false;
                                        result.isValid = false;
                                        result.message = result.message + "<p>" + count + ") " + s6271result.message + "</p>";
                                    }
                                    if (s6271result.isWarned) {
                                        result.isWarned = true;
                                        result.warningMessage += "<p>" + count + ") " + s6271result.warningMessage + "</p>";
                                    }
                                    break;
                                case "CAR":
                                case "EAR":
                                    let s4851result = eachRisk.getValidator().validate();
                                    result.childsResult[eachRiskAry] = s4851result;
                                    // let count = (rtIdx * allRisks.length) + rkIdx;
                                    if (s4851result.isValid == false) {
                                        resultByField[eachRiskAry] = false;
                                        result.isValid = false;
                                        result.message = result.message + "<p>" + count + ") " + s4851result.message + "</p>";
                                    }
                                    if (s4851result.isWarned) {
                                        result.isWarned = true;
                                        result.warningMessage += "<p>" + count + ") " + s4851result.warningMessage + "</p>";
                                    }
                                    break;
                                case "CPA":
                                    let s5183result = eachRisk.getValidator().validate();
                                    result.childsResult[eachRiskAry] = s5183result;
                                    // let count = (rtIdx * allRisks.length) + rkIdx;
                                    if (s5183result.isValid == false) {
                                        resultByField[eachRiskAry] = false;
                                        result.isValid = false;
                                        result.message = result.message + "<p>" + count + ") " + s5183result.message + "</p>";
                                    }
                                    if (s5183result.isWarned) {
                                        result.isWarned = true;
                                        result.warningMessage += "<p>" + count + ") " + s5183result.warningMessage + "</p>";
                                    }
                                    break;
                                default:
                                    if ( eachRisk.riskType != undefined ) {
                                        let genericResult = eachRisk.getValidator().validate();
                                        result.childsResult[eachRiskAry] = genericResult;
                                        // let count = (rtIdx * allRisks.length) + rkIdx;
                                        if ( genericResult.isValid == false ) {
                                            resultByField[eachRiskAry] = false;
                                            result.isValid = false;
                                            result.message = result.message + "<p>" + count + ") " + genericResult.message + "</p>";
                                        }
                                        if ( genericResult.isWarned ) {
                                            result.isWarned = true;
                                            result.warningMessage += "<p>" + count + ") " + genericResult.warningMessage + "</p>";
                                        }
                                        break;
                                    }                                    
                            }
                        } else {
                            let genericResult = eachRisk.getValidator().validate();
                            result.childsResult[eachRiskAry] = genericResult;
                            // let count = (rtIdx * allRisks.length) + rkIdx;
                            if ( genericResult.isValid == false ) {
                                resultByField[eachRiskAry] = false;
                                result.isValid = false;
                                result.message = result.message + "<p>" + count + ") " + genericResult.message + "</p>";
                            }
                            if ( genericResult.isWarned ) {
                                result.isWarned = true;
                                result.warningMessage += "<p>" + count + ") " + genericResult.warningMessage + "</p>";
                            }
                        }                        
                        rkIdx++;
                    }
                    rtIdx++;
                }
            }
            //ARI - validating total Sum Insured
            if (ari_isVAlidLRateBasis != '' && ari_isValidARateBasis != '') {
                result.isValid = false;
                result.message = result.message + "<p>Either Rate Basis L or A only can be added for a policy.</p>";
            }
            //E1001 Started
            else if (ari_isVAlidLRateBasis == 'N' && BMSConstants.getBMSHeaderInfo().businessChannel != '06' && BMSConstants.getBMSHeaderInfo().businessChannel != '08' && BMSConstants.getBMSHeaderInfo().businessChannel != '11') {
                //else if( ari_isVAlidLRateBasis =='N'){
                result.isValid = false;
                result.message = result.message + "<p>Target Sum Insured should be equal or more than 300 Million for the Risk with Rate Basis 'L'.</p>";
            }
            else if (ari_isValidARateBasis == 'N' && BMSConstants.getBMSHeaderInfo().businessChannel != '06' && BMSConstants.getBMSHeaderInfo().businessChannel != '08' && BMSConstants.getBMSHeaderInfo().businessChannel != '11') {
                //else if(ari_isValidARateBasis =='N'){
                result.isValid = false;
                result.message = result.message + "<p>Target Sum Insured should be equal or more than 50 Million for the Risk with Rate Basis 'A'.</p>";
            }
            //E1001 Ended
            //Check if all risks downloaded
            if ((BMSConstants.getBMSCaseInfo().businessFunction == "RenewalRerate" || BMSConstants.getBMSCaseInfo().businessFunction == "Renewal") && BMSConstants.getBMSHeaderInfo().contractType != 'MPD') {//MYS-2018-0360 - KA001
                if (BMSConstants.getBMSHeaderInfo().isSimplifiedProcess != 'Y') {
                    let risks = BMSConstants.getRisks();
                    let riskType = new RiskArray().getArrayByRiskType(BMSConstants.getBMSHeaderInfo().contractType);
                    let downloadedRisks = risks[riskType].length;
                    let totalRisks = BMSConstants.getBMSHeaderInfo().noOfRisks;
                    if (downloadedRisks < totalRisks) {
                        result.isValid = false;
                        result.message = "Please process all the risks before proceeding";
                    }
                }

            }

            this.validateTotalPremium(minPremium, premiumTotal, result);
            result.fields = riskList;
            result.validationResult = resultByField;

        }
        //START YPK001
        else {
            if(BMSConstants.getBMSCaseInfo().isPostedBySTP=='Y' && BMSConstants.getBMSHeaderInfo().isSimplifiedProcess == 'Y' && BMSConstants.getBMSCaseInfo().businessFunction == "Renewal")
            {
                result.isValid = true;
            }
        //END YPK001
            else{
            result.isValid = false;
            result.message = "<p>Risk Table: No risk is added.</p>";
            }
        }
        return result;
    }

    hasRisks() {
        let hasRisk = false;
        let riskList = Object.keys(this.valueObj);
        for (let eachRiskAry of riskList) {
            if (this.valueObj[eachRiskAry].length > 0) {
                hasRisk = true;
                break;
            }
        }
       
        return hasRisk;
    }

    validateTotalPremium(minimumPremium, totalPremium, validationResult) {

        if (minimumPremium != null && totalPremium != null && parseFloat(totalPremium) > 99999999999.99) {
            validationResult.isValid = false;
            validationResult.message = validationResult.message + "<p>Total premium can not be greater than 99999999999</p>";
        }
    }
}