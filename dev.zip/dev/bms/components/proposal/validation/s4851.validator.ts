/*
 * Change History:
 * 
 * No      Date          Description                                         Changed By
 * ====    ==========    ===========                                         ==========
* 
* 	VK004	06/12/2018		MYS-2018-1192					VKR
*/
/*
 * Change History:
 * 
 * No      Date          Description                                         Changed By
 * ====    ==========    ===========                                         ==========
 * GA001   07/05/2019   MYS-2019-0041 - To enhance the module of Occupation (update: 0094: MP > 36 months) and
 * 						maintenance period referred risk validation    			KGA					   
*/
import { Validator, ValidationResult } from '../../../../common/components/validator/validator';
import { GSTDetilsValidator } from './gstdetails.validator';
import { ExcessTypeValidator } from './excesstype.validator';
import { SurveyValidator } from './survey.validator';
import { S4851 } from '../newbusinessrisks/s4851/appobjects/s4851';
import { BMSConstants } from '../../common/constants/bms_constants';
import { AppUtil } from '../../../../common/components/utility/apputil/app.util';
import { FinancialInterstValidator } from './financialinterest.validator';

declare var moment: any;

export class S4851Validator extends Validator {
    public fields: Array<any> = ["ratingFlag",
        "occupationCode",
        "occupationDesc",
        "riRetentionCode",
        "state"
    ];
    public fieldNames: any = {
        ratingFlag: "Rating Flag",
        riskOccupancyCode: "Risk Occupation Code",
        occupationCode: "Occupation",
        occupationDesc: "Occupation Description",
        riRetentionCode: "RI Retention Code",
        insuredLine1: "Insured",
        contractTitleLine1: "Contract Title",
        contractSiteLine1: "Job Site",
        state: "State",
        contractPeriodFrom: "Contract Period From Date",
        contractPeriodTo: "Contract Period To Date",
        erectPeriodFrom: "Erect Period From Date",
        erectPeriodTo: "Erect Period To Date",
        "GSTDetails.riskUsage": "GST Risk Usage",
        "GSTDetails.riskLocation": "GST Risk Location",
        "GSTDetails.placeOfRecidence": "Place of Residence / Business",
        "GSTDetails.inputTaxAllowed": "Input Tax Allowed?"
    };
    constructor(s4851: S4851) {
        super();
        this.valueObj = s4851;
        this.requiredFields = this.fields;
    }

    public validate() {

        this.setMandatoryFields();

        let result = super.validate();
        let validHeaderMandatoryFields: boolean = true;
        if (result.isValid == false) {
            validHeaderMandatoryFields = false;
            result.message = this.valueObj.riskType + " (Risk Number: " + this.valueObj.riskNumber + " ): Provide value for all mandatory fields.<dl>" + this.getInvalidFields(result, this.fieldNames);
        }

        if (!(this.valueObj.insuredLine1 || this.valueObj.insuredLine2 || this.valueObj.insuredLine3 || this.valueObj.insuredLine4)) {
            result.isValid = false;
            result.message = result.message + "<dd> - Insured is mandatory.</dd>";
        }
        if (!(this.valueObj.contractTitleLine1 || this.valueObj.contractTitleLine2 || this.valueObj.contractTitleLine3 || this.valueObj.contractTitleLine4 || this.valueObj.contractTitleLine5)) {
            result.isValid = false;
            result.message = result.message + "<dd> - Contract Title is mandatory.</dd>";
        }
        if (!(this.valueObj.contractSiteLine1 || this.valueObj.contractSiteLine2 || this.valueObj.contractSiteLine3)) {
            result.isValid = false;
            result.message = result.message + "<dd> - Job Site is mandatory.</dd>";
        }

        let _siRate = true;
        let ctr = 1;
        let noOfCoverageItems = this.valueObj.materialDamageCoverDetails.materialDamageCover.length;
        for (let _coverItem of this.valueObj.materialDamageCoverDetails.materialDamageCover) {
            let si: any = _coverItem.sumInsured;
            let basicRate: any = _coverItem.basicRate;
            si = (si == null || si == "") ? 0 : si;
            basicRate = (basicRate == null || basicRate == "") ? 0 : basicRate;

            if (ctr == 1 && si == 0) {
                result.isValid = false;
                result.message = result.message + "<dd> - Section 1 Material damage: First coverage Sum Insured must be greater than 0.</dd>";
            }

            if (!_coverItem.insured && si > 0) {
                result.isValid = false;
                result.message = result.message + "<dd> - Sum Insured is not allowed for the insured entry with blank value.</dd>";
            }
			/*if(ctr == noOfCoverageItems && si == 0){
				result.isValid = false;
				result.message = result.message + "<br>Section 1 Material damage: Last coverage Sum Insured must be greater than 0.";
			}*/

            if (this.valueObj.ratingFlag == 'A' && si > 0 && basicRate == 0) {
                _siRate = false;
            }
            ctr++;
        }
        if (!_siRate) {
            result.isValid = false;
            result.message = result.message + "<dd> - Section 1: Material damage coverage rate is mandatory.</dd>";
        }

        let gstDetailsResult = new GSTDetilsValidator(this.valueObj).validate();
        if (gstDetailsResult.isValid == false) {
            result.isValid = false;
            result.message = result.message + gstDetailsResult.message;
        }

        if (this.valueObj.FI == "Y") {
            let financialInterestValResult = new FinancialInterstValidator(this.valueObj).validate();
            if (financialInterestValResult.isValid == false) {
                result.isValid = false;
                if (result.message == null || result.message == "") {
                    result.message = financialInterestValResult.message;
                } else
                    result.message = result.message + financialInterestValResult.message;
            } else if (!this.valueObj.financialInterest || !this.valueObj.financialInterest.financialInterestList || this.valueObj.financialInterest.financialInterestList.length == 0) {
                result.isValid = false;
                if (result.message == null || result.message == "") {
                    result.message = "<dd> - Add Financial Interest details.</dd>";
                } else
                    result.message = result.message + "<dd> - Add Financial Interest details.</dd>";
            }
        }

        if (this.valueObj.isSurveyNeeded == "Y") {
            let surveyValidatorResult = new SurveyValidator(this.valueObj).validate();
            if (surveyValidatorResult.isValid == false) {
                result.isValid = false;
                if (result.message == null || result.message == "") {
                    result.message = surveyValidatorResult.message;
                } else
                    result.message = result.message + surveyValidatorResult.message;
            }
        }

        // if(this.valueObj.riskType == 'CAR' ){
        let _duration: any = this.valueObj.maintenancePeriodCode;
        _duration = (_duration == null || _duration == "") ? 0 : _duration;
        if ((_duration > 0 && !this.valueObj.maintenancePeriodFreq) || (this.valueObj.maintenancePeriodFreq && _duration == 0)) {
            result.isValid = false;
            result.message = result.message + "<dd> - Maintenance Period Duration: both values must be provided </dd>";
        }

        if (_duration > 0 && this.valueObj.maintenancePeriodFreq && (!this.valueObj.maintenancePeriodFrom || !this.valueObj.maintenancePeriodTo)) {
            result.isValid = false;
            result.message = result.message + "<dd> - Maintenance Period From and To date are mandatory</dd>";
        }
        // }

        if (this.valueObj.maintenancePeriodFrom && this.valueObj.contractPeriodTo) {

            let _maintenancePeriodFrom = moment(this.valueObj.maintenancePeriodFrom, "YYYY-MM-DD").format("YYYY-MM-DD");
            let _mPeriodStartDate = moment(this.valueObj.contractPeriodTo, "YYYY-MM-DD").add(1, 'days').format("YYYY-MM-DD");

            if (!(_maintenancePeriodFrom == _mPeriodStartDate)) {
                result.isValid = false;
                result.message = result.message + "<dd> - Maintenance Period must start a day after Contract Period.</dd>";
            }
        }

        if (this.valueObj.riskType == 'EAR') {

            let _duration: any = this.valueObj.testingPeriodCode;
            _duration = (_duration == null || _duration == "") ? 0 : _duration;
            if ((_duration > 0 && !this.valueObj.testingPeriodFreq) || (this.valueObj.testingPeriodFreq && _duration == 0)) {
                result.isValid = false;
                result.message = result.message + "<dd> - Testing Period Duration: both values must be provided </dd>";
            }

            if (_duration > 0 && this.valueObj.testingPeriodFreq && (!this.valueObj.testingPeriodFrom || !this.valueObj.testingPeriodTo)) {
                result.isValid = false;
                result.message = result.message + "<dd> - Testing Period From and To date are mandatory</dd>";
            }

            if (this.valueObj.maintenancePeriodFrom && this.valueObj.testingPeriodTo) {

                let _maintenancePeriodFrom = moment(this.valueObj.maintenancePeriodFrom, "YYYY-MM-DD").format("YYYY-MM-DD");
                let _mPeriodStartDate = moment(this.valueObj.testingPeriodTo, "YYYY-MM-DD").add(1, 'days').format("YYYY-MM-DD");

                if (!(_maintenancePeriodFrom == _mPeriodStartDate)) {
                    result.isValid = false;
                    result.message = result.message + "<dd> - Maintenance Period must start a day after Testing Period.</dd>";
                }
            }
        }
        //GA001 START
        if ((this.valueObj.riskType == 'CAR' || this.valueObj.riskType == 'EAR') && (this.valueObj.maintenancePeriodFrom
            && this.valueObj.maintenancePeriodTo)) {
            let difference = moment(this.valueObj.maintenancePeriodTo, "YYYY-MM-DD").diff(moment(this.valueObj.maintenancePeriodFrom, "YYYY-MM-DD"));
            let _m = moment.duration(difference).asMonths();
            if (this.valueObj.occupationCode == 'O094' && _m <= 36) {
                result.isValid = false;
                result.message = result.message + "<dd> - Maintenance Period must greater than 36 months for Occupation Code " + this.valueObj.occupationDesc + " .</dd>";
            } else if (this.valueObj.occupationCode != 'O094' && _m > 36) {
                result.isValid = false;
                result.message = result.message + "<dd> - Maintenance Period is greater than 36 months then Occupation Code must be selected as O094 : MP > 36 months.</dd>";
            }
        }
        //GA001 END

		/*
		let _bmsRisks = BMSConstants.getRisks();
		if( !(_bmsRisks && _bmsRisks['s4810'] && _bmsRisks['s4810'].length > 0) ){
			result.isValid = false;
			if(result.message == null || result.message == "")
				result.message = "<br>At least one PL or IPL risk must be added.";
			else 
				result.message = result.message + "<br>At least one PL or IPL risk must be added.";
		}
		*/

        if (!this.valueObj.totalLimitIndemnitySection2 || !parseFloat("" + this.valueObj.totalLimitIndemnitySection2)) {
            result.isValid = false;
            result.message = result.message + "<dd> - Section II: 1.2 Total Sum Insured is Mandatory.<dd>";
        }

        if (!this.valueObj.premium || !parseFloat("" + this.valueObj.premium)) {
            result.isValid = false;
            result.message = result.message + "<dd> - Total Premium must be greater than 0.<dd>";
        }

        if (!result.isValid && validHeaderMandatoryFields) {
            result.message = this.valueObj.riskType + " (Risk Number: " + this.valueObj.riskNumber + "): Provide value for all mandatory fields.<dl>" + result.message;
        }
		//VK004 General Page Text
		let headerInfo = BMSConstants.getBMSHeaderInfo();
		if(Number(this.valueObj.gpTextCount) > Number(headerInfo.gpTextMaxLines)) {
			result.isValid = false;
			result.message = result.message + this.valueObj.riskType+" (Risk Number: "+this.valueObj.riskNumber+" ): General Page Text entered is more than 400 lines.";
		}
		//VK004 END
        result.message = result.message + "</dl>";

        return result;
    }

    setMandatoryFields() {
        if (this.valueObj.riskType == 'CAR') {
            this.fields.push("contractPeriodFrom");
            this.fields.push("contractPeriodTo");
        }

        if (this.valueObj.riskType == 'EAR') {
            this.fields.push("erectPeriodFrom");
            this.fields.push("erectPeriodTo");

            // this.fields.push("testingPeriodFrom");
            // this.fields.push("testingPeriodTo");
        }

    }

    getInvalidFields(valResult: ValidationResult, fieldNames) {
        let fields = Object.keys(valResult.validationResult);
        let missedFields = "";
        let count = 1;
        for (let fld of fields) {
            if (valResult.validationResult[fld] == false) {
                if (fieldNames[fld] == null) {
                    // missedFields = missedFields+ "<dd>" + count+ ")"+ fld ;
                    missedFields += "<dd> - " + fld + "</dd>";
                }
                else {
                    // missedFields = missedFields+ ",<br/>" + count+ ")"+ fieldNames[fld]  ;
                    missedFields += "<dd> - " + fieldNames[fld] + "</dd>";
                }
                count++;
            }
        }

        return missedFields;
    }

}