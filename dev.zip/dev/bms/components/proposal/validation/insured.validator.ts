import { Validator, ValidationResult } from '../../../../common/components/validator/validator';
import { Insured } from "../newbusinessrisks/appobjects/insuredlist";

export class InsuredValidator extends Validator {
    public fields: Array<any> = ["name",
        "ICPassport",
        "DOB"
    ];
    constructor(nomineeObj: Insured) {
        super();
        this.valueObj = nomineeObj;
        this.requiredFields = this.fields;
    }

    public validate() {
        let result = super.validate();
        if (result.isValid == true) {
            // if( !isNaN(this.valueObj.percentageOfShare) && Number(this.valueObj.percentageOfShare) > 100 ){
            // result.isValid = false;
            // result.message = "Percentage of Share should not be greater than 100. Enter lesser value.";
            // }
            // else if(Number(this.valueObj.percentageOfShare) <= 0) {
            // result.isValid = false;
            // result.message = "Percentage of Share should not be lesser or equal to 0. Enter value greater than 0.";
            // }
        }
        else {
            result.message = "Provide value for all Insured Detail mandatory fields.";
        }
        return result;
    }

}