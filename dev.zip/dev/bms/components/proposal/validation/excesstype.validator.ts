import { Validator, ValidationResult } from '../../../../common/components/validator/validator';
import { BMSConstants } from '../../common/constants/bms_constants';

export class ExcessTypeValidator extends Validator {
    public fields: Array<any> = [];
    public fieldNames: any = {
        "excessType": "Excess Type",
        "excessPercentage": "Excess Percentage",
        "excessAmount": "Excess Amount"
    };

    constructor(riskObj: Object) {
        super();
        this.valueObj = riskObj;
        this.requiredFields = this.fields;
    }

    public validate() {

        let result = super.validate();

        if (this.valueObj.excessType) {
            let _excessTypeRecord = BMSConstants.getBmsUtilServiceObj().getExcessTypeRecord(this.valueObj.riskType, this.valueObj.excessType);
            if (_excessTypeRecord) {
                if (_excessTypeRecord.ACTN02 == 'Y' && (this.valueObj.excessPercentage == null || !this.valueObj.excessPercentage || parseFloat("" + this.valueObj.excessPercentage) <= 0)) {
                    result.isValid = false;
                    if (this.valueObj.riskType == 'PL' || this.valueObj.riskType == 'PPL')
                        result.message = "<br>Deductible Percentage is Mandatory";
                    else
                        result.message = "<br>Excess Percentage is Mandatory.";
                }

                if (_excessTypeRecord.ACTN01 == 'Y' && (this.valueObj.excessAmount == null || !this.valueObj.excessAmount || parseFloat("" + this.valueObj.excessAmount) <= 0)) {
                    result.isValid = false;
                    if (this.valueObj.riskType == 'PL' || this.valueObj.riskType == 'PPL')
                        result.message = result.message + "<br>Deductible Amount is Mandatory";
                    else
                        result.message = result.message + "<br>Excess Amount is Mandatory.";
                }
            }
        } else if ((this.valueObj.excessPercentage && parseFloat("" + this.valueObj.excessPercentage) > 0) || (this.valueObj.excessAmount && parseFloat("" + this.valueObj.excessAmount) > 0)) {
            result.isValid = false;
            if (this.valueObj.riskType == 'PL' || this.valueObj.riskType == 'PPL')
                result.message = "<br>Deductible Type cannot be blank";
            else if (this.valueObj.riskType == 'MAR' || this.valueObj.riskType == 'MCA')
                result.message = "<br>Excess Code cannot be blank";
            else
                result.message = "<br>Excess Type cannot be blank";
        }

        return result;
    }

}