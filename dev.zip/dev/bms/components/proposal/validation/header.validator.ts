/*
* Change History:
* 
*   No      Date          Description                                                      Changed By
*  ====    ==========    ===========                                                       ==========
*  GA001    11/09/2019      MYS-2019-0974 - BMS Enhancement on High Risk Vehicle & Client      KGA
*/
import { Validator, ValidationResult } from '../../../../common/components/validator/validator';
import { ProposalHeader } from '../proposalheader/appobjects/proposalheader';
import { COInsuranceValidator } from '../../../../common/components/coinsurance/validation/coinsurance.validator';
import { ReferenceValidator } from './reference.validator';
import { PeriodicDebitDetailValidator } from './banca.validator';
import { BMSConstants } from '../../common/constants/bms_constants';
import { BMSType } from '../../common/constants/bms_types';

export class HeaderValidator extends Validator {
    public fields: Array<any> = ["handlingBranch",
        "agentCode",
        "servicingBranch",
        "businessChannel",
        "contractType",
        "lineOfBusiness",
        "effectiveDate",
        "endDate",
        "accountHandler",
        "insuredNumber"];
    public fieldNames: any = {
        handlingBranch: "Handling Branch",
        agentCode: "Agent",
        servicingBranch: "Servicing Branch",
        businessChannel: "Business Channel",
        contractType: "Contract Type",
        lineOfBusiness: "Line Of Business",
        effectiveDate: "Effective Date",
        endDate: "End Date",
        accountHandler: "Account Handler",
        insuredNumber: "Insured Number",
        RIType: "RI Required > RI Type",
        UOBSector: "UOB Sector",
        AMLCDDComments: "AML CDD Comments",
        HighRiskCusType: "High Risk Customer > High Risk Trades",
        HighRiskCusComments: "High Risk Customer > Comments"
    };
    constructor(headerObj: ProposalHeader) {
        super();
        this.valueObj = headerObj;
        this.requiredFields = this.fields;
    }
    handleCoverNoteCase() {
        if (BMSConstants.getBMSType() == BMSType.CoverNote && BMSConstants.getSatus() != "Cover Note Accepted") {
            if (this.fields.indexOf('effectiveDate') > -1 && this.fields.indexOf('endDate') > -1) {
                this.fields.splice(this.fields.indexOf('effectiveDate'), 1);
                this.fields.splice(this.fields.indexOf('endDate'), 1);
            }

        }
    }
    public validate() {

        this.handleRI();
        this.handleCoverNoteCase();
        this.handleUOB();
        this.handleAMLCDD();
        this.handleHRC();
        let result = super.validate();

        if (result.isValid == true) {
            if (new Date(this.valueObj["endDate"]) < new Date(this.valueObj["effectiveDate"])) {
                result.isValid = false;
                result.message = "<p>Proposal Header: End Date must be greater than Start Date.</p>";
            }
            if (this.valueObj.references.reference != undefined && !(this.valueObj.references.reference.constructor === Array)) {
                let referenceItems: any = this.valueObj.references.reference;
                this.valueObj.references.reference = [referenceItems];
            }
            if (this.valueObj.businessChannel == '06' && this.valueObj.references && this.valueObj.references.reference && this.getIntroducerAcctCode("title", this.valueObj.references.reference)) {
                result.isValid = false;
                result.message = "<p>References: Introducer Account Code should be mandatory if Agent Code is CO Insurance Inwards .</p>";
            }
            if (this.valueObj.isBancaValidationFailed == 'Y') {
                result.isValid = false;
                result.message = "<p>Proposal Header: Banca validation failed. Click 'Check Banca' in header to resolve the problem or contact the administrator.</p>";
            }
        }
        else {
            result.message = "<p>Proposal Header: Provide value for all mandatory fields.</p>" + this.getInvalidFields(result, this.fieldNames);
        }

        this.addCoinsuranceValidation(result);
        this.addBancaFieldValidation(result);
        this.referencesValidation(result);
        //GA001 START
        if(this.valueObj.isHighRiskApplicable){
            this.handleHighRiskInd(result);
        }
        //GA001 END

        //pku
        if ( this.valueObj.showCCMOps == true) {
            if ( this.valueObj.ccmOPSs.noOfHardCopy == 0 ) {
                let printFlagObj: any = this.valueObj.ccmOPSs.ccmOPS.find( ( item ) => item.printFlag == "Y" );
                if ( typeof ( printFlagObj ) == "object" ) {
                    printFlagObj = [printFlagObj];
                }
                if ( printFlagObj != undefined && printFlagObj.length >= 1 ) {
                    result.isValid = false;
                    result.message = "No of Copies can not be zero, if any of the Print flag is set to 'Y'.";
                }
            }            
        }
        
        //End

        return result;
    }


    public handleRI() {
        if (BMSConstants.getBMSType() == BMSType.NewBusiness || BMSConstants.getBMSType() == BMSType.CoverNote || BMSConstants.getBMSType() == BMSType.Renewal) {
            if (this.valueObj.RIRequiredHeader == "Yes") {
                if (this.fields.indexOf('RIType') == -1)
                    this.fields.push("RIType");
            }
            else {
                if (this.fields.indexOf('RIType') != -1)
                    this.fields.splice(this.fields.indexOf('RIType'), 1);
            }
        }
    }

    public handleUOB() {
        if (this.valueObj.isUOBMandatory == "Y") {
            if (this.fields.indexOf('UOBSector') == -1) {
                this.fields.push("UOBSector");
            }
        }
        else {
            if (this.fields.indexOf('UOBSector') != -1) {
                this.fields.splice(this.fields.indexOf('UOBSector'), 1);
            }
        }
        this.requiredFields = this.fields;
    }

    public handleAMLCDD() {
        if (this.valueObj.AMLCDDCheck == "true") {
            if (this.fields.indexOf('AMLCDDComments') == -1) {
                this.fields.push("AMLCDDComments");
            }
        }
        else {
            if (this.fields.indexOf('AMLCDDComments') != -1) {
                this.fields.splice(this.fields.indexOf('AMLCDDComments'), 1);
            }
        }
        this.requiredFields = this.fields;
    }

    public handleHRC() {
        if (this.valueObj.HighRiskCus == "Y") {
            if (this.fields.indexOf('HighRiskCusComments') == -1) {
                this.fields.push("HighRiskCusComments");
            }

            if (this.fields.indexOf('HighRiskCusType') == -1) {
                this.fields.push("HighRiskCusType");
            }
        }
        else {
            if (this.fields.indexOf('HighRiskCusComments') != -1) {
                this.fields.splice(this.fields.indexOf('HighRiskCusComments'), 1);
            }

            if (this.fields.indexOf('HighRiskCusType') != -1) {
                this.fields.splice(this.fields.indexOf('HighRiskCusType'), 1);
            }
        }
        this.requiredFields = this.fields;
    }

    public validateDispathInfo() {
        this.fields = ["dispatchRefNo", "dispatchDate", "dispatchedBy"];
        this.requiredFields = this.fields;

        let fieldNames: any = {
            dispatchRefNo: "Dispatch Reference Number",
            dispatchDate: "Dispatch Date",
            dispatchedBy: "Dispatch By"
        };

        let result = super.validate();

        if (result.isValid == false) {
            result.message = "<p>Provide value for all mandatory fields.</p>" + this.getInvalidFields(result, fieldNames);
        }

        return result;
    }

    getIntroducerAcctCode(prop, ary) {
        if (ary && ary.length > 0) {
            for (let eachItem of ary) {
                if (eachItem[prop] != null && eachItem[prop] != "" && eachItem[prop] == 'Reference') {
                    if (eachItem['referenceNumber'])
                        return false;
                }
            }
        }
        return true;
    }

    addCoinsuranceValidation(result) {
        if (this.valueObj.CoInsurance != null && this.valueObj.CoInsurance == "Y") {
            result.fields.push("coInsuranceDetails");
            let coiValidation = new COInsuranceValidator(this.valueObj.coInsuranceDetails).validate();
            if (coiValidation.isValid == false) {
                result.isValid = false;
            }
            result.message = result.message + coiValidation.message;
            result.childsResult["coInsuranceDetails"] = coiValidation;
            result.validationResult["coInsuranceDetails"] = coiValidation.isValid;
        }
    }

    addBancaFieldValidation(result) {
        if (this.valueObj.periodicDebitDetails != null && this.valueObj.periodicDebitDetails != "") {
            result.fields.push("periodicDebitDetails");
            let pddValidation = new PeriodicDebitDetailValidator(this.valueObj.periodicDebitDetails).validate();
            if (pddValidation.isValid == false) {
                result.isValid = false;
            }
            result.message = result.message + pddValidation.message;
            result.childsResult["periodicDebitDetails"] = pddValidation;
            result.validationResult["periodicDebitDetails"] = pddValidation.isValid;
        }
    }

    referencesValidation(result) {
        if (this.valueObj.references != null) {

            if (this.valueObj.references.reference.length > 0) {
                for (let refItem of this.valueObj.references.reference) {

                    result.fields.push("refDetails");
                    let refValid = new ReferenceValidator(refItem).validate();
                    if (refValid.isValid == false) {
                        result.isValid = false;
                    }
                    result.message = result.message + refValid.message;
                    result.childsResult["refDetails"] = refValid;
                    result.validationResult["refDetails"] = refValid.isValid;
                }
            }
        }
        return result;
    }
    //GA001 START
    handleHighRiskInd(result){
        if ( this.valueObj.highRiskIndicator == "true") {
            if(this.valueObj.highRiskBNMIndicator == "B" || this.valueObj.highRiskInternalIndicator == "B" || this.valueObj.highRiskVehicleIndicator == "B" || this.valueObj.highRiskLossRatioWDInd == "B" || 
            this.valueObj.highRiskInsuredBNMInd == "B" || this.valueObj.highRiskInsuredInternalInd == "B" || this.valueObj.highRiskNomineeInternalInd == "B" || this.valueObj.highRiskDriverInternalInd == "B"){
                result.isValid = false;
                if(BMSConstants.getBMSCaseInfo().lineOfBusiness == "MTR") {
                    result.message = "<p> Header: Client / Vehicle is High Risk Indicator with Block.</p>";
                }else{
                    result.message = "<p> Header: Client is High Risk Indicator with Block.</p>";
                } 
            }
        }
    }
    //GA001 END
}