import { FinancialInterestValidator } from '../../../../common/components/financialinterest/validation/financialInterest.validator';
import { AppUtil } from '../../../../common/components/utility/apputil/app.util';
import { ValidationResult, Validator } from '../../../../common/components/validator/validator';
import { BMSConstants } from '../../common/constants/bms_constants';
import { FEA, FireIDC } from '../newbusinessrisks/fireidc/appobjects/fireIDC';
import { ProposalHeader } from '../proposalheader/appobjects/proposalheader';
import { FireCoverageValidator } from './firecoverage.validator';
import { GSTDetilsValidator } from './gstdetails.validator';
import { PerilValidator } from './peril.validator';
import { SurveyValidator } from './survey.validator';

declare var moment: any;
declare var numeral: any;

export class IDCValidator extends Validator {
    public fields: Array<any> = ["situation1",
        "PIAMCode",
        "occupiedAs",
        "construction",
        "riskClassification",
        "townClass",
        "RIRetentionCode",
        "postCode",
        "city",
        "accumulationRegister",
        "rateBasis",
        "locality",
        "yearOfConstruction",
        "storeys",
        "totalPremium",
        "capitalSumInsured",
        "GSTDetails.riskLocation",
        "totalSI"];
    public fieldNames: any = {
        situation1: "Situation",
        PIAMCode: "PIAM Code",
        occupiedAs: "Occupied As",
        construction: "Construction",
        riskClassification: "Risk Classification",
        townClass: "Town Class",
        RIRetentionCode: "RI Retention Code",
        postCode: "Post Code",
        city: "City",
        accumulationRegister: "Accumulation Register",
        rateBasis: "Rate Basis",
        locality: "Locality",
        yearOfConstruction: "Year Of Construction",
        storeys: "Storeys",
        sprinkler: "Sprinkler",
        totalPremium: "Total Premium",
        capitalSumInsured: "Capital Sum Insured",
        "GSTDetails.riskLocation": "GST Risk Location",
        totalSI: "Total Sum Insured",
        basicRate: "Basic Rate",
        cslType: "Combined Single Limit Type"
    };
    constructor(idc: FireIDC) {
        super();
        this.valueObj = idc;
        if (idc.riskType == 'ECP') {
            this.fields.push("basicRate");
        } else if (idc.riskType == 'ARI') {
            // this.fields.push("cslType");
        }
        this.requiredFields = this.fields;
    }

    public validate() {
        let result = super.validate();

        if (result.isValid == false) {
            result.message = this.valueObj.riskType + " (Risk Number: " + this.valueObj.riskNumber + " ): <p>Provide value for all mandatory fields.</p>" + this.getInvalidFields(result, this.fieldNames);
        }

        if ((this.valueObj.riskType == 'ECP' || this.valueObj.riskType == 'ARI') && (!this.valueObj.basicRate || parseFloat("" + this.valueObj.basicRate) <= 0)) {
            result.isValid = false;
            if (result.message == null || result.message == "") {
                result.message = this.valueObj.riskType + " (Risk Number: " + this.valueObj.riskNumber + " ): <p>Basic Rate is mandatory.</p>";
            } else
                result.message = result.message + "<br>Basic Rate is mandatory.";
        }

		/*if( this.valueObj.riskType=='ARI' && (!this.valueObj.cslAmount || parseFloat(""+this.valueObj.cslAmount) <=0 ) ){ //commenting for Redmine #2092
			result.isValid = false;
			if(result.message == null || result.message == ""){
				result.message = this.valueObj.riskType+" (Risk Number: "+this.valueObj.riskNumber+" ): <p>Combined Single Limit Amount is mandatory.</p>";
			} else 
				result.message = result.message + "<br>Combined Single Limit Amount is mandatory.";
		}*/

        if (this.valueObj.riskType != 'ECP' && (!this.valueObj.storeys || parseFloat("" + this.valueObj.storeys) <= 0)) {
            result.isValid = false;
            if (result.message == null || result.message == "") {
                result.message = this.valueObj.riskType + " (Risk Number: " + this.valueObj.riskNumber + " ): <p>Storeys must be greater than 0.</p>";
            } else
                result.message = result.message + "<br>Storeys must be greater than 0.";
        }

        let feaResult = new FEAValidator(this.valueObj.FEA).validate();

        if (feaResult.isValid == false) {
            result.isValid = false;
            if (result.message == null || result.message == "") {
                result.message = this.valueObj.riskType + " (Risk Number: " + this.valueObj.riskNumber + " ): <p>Provide value for all mandatory fields.</p>";
            }
            result.message = result.message + feaResult.message;
        }

        let clauseResult = this.validateClauses(this.valueObj);

        if (clauseResult.isValid == false) {
            result.isValid = false;
            if (result.message == null || result.message == "") {
                result.message = this.valueObj.riskType + " (Risk Number: " + this.valueObj.riskNumber + " ): <p>Provide value for all mandatory fields.</p>";
            }
            result.message = result.message + clauseResult.message;
        }

        let coverResult = new FireCoverageValidator(this.valueObj).validate();
        if (coverResult.isValid == false) {
            result.isValid = false;
            if (result.message == null || result.message == "") {
                result.message = this.valueObj.riskType + " (Risk Number: " + this.valueObj.riskNumber + " ): <p>Provide value for all mandatory fields.</p>";
            }
            result.message = result.message + coverResult.message;
        }

        if (this.valueObj.rateBasis != null && (this.valueObj.rateBasis == "G" || this.valueObj.rateBasis == "S")) {
            let perilResult = new PerilValidator(this.valueObj.perils).validate();
            if (perilResult.isValid == false) {
                result.isValid = false;
                if (result.message == null || result.message == "") {
                    result.message = this.valueObj.riskType + " (Risk Number: " + this.valueObj.riskNumber + " ): <p>Provide value for all mandatory fields.</p>";
                }
                result.message = result.message + perilResult.message;
            }
            result.childsResult["peril"] = perilResult;
        }
        // SAF MYS-2018-1249 Start
        let headerInfo: ProposalHeader = BMSConstants.getBMSHeaderInfo();
        if (headerInfo.VPMSProduct == "Y" || headerInfo.firePostingScreen == 'NEW') {
            let pItemCodes: Array<string> = [];
            let pItems = this.valueObj.perils.peril.filter(_item => _item.nominatedSumInsured == undefined || _item.nominatedSumInsured <= 0);
            for (let item of pItems) {
                pItemCodes.push(item.perilCode);
            }
            if (pItemCodes.length > 0) {
                result.isValid = false;
                if (result.message == null || result.message == "") {
                    result.message = this.valueObj.riskType + " (Risk Number: " + this.valueObj.riskNumber + " ): <p>Provide value for all mandatory fields.</p>";
                }
                result.message = result.message + "<br/>Peril items : " + pItemCodes.join(", ") + " not added to any cover."
            }
            if ((this.valueObj.rateBasis == "G" || this.valueObj.rateBasis == "S") && this.valueObj.rewiringYear != undefined && this.valueObj.rewiringYear != "" && this.valueObj.rewiringYear != "0" && this.valueObj.rewiringYear > moment(headerInfo.effectiveDate).format("YYYY")) {
                result.isValid = false;
                result.message = result.message + "<br/>Rewiring Year Shouldn't be greater than Effective Year."
            }
            //validation for Rating Committe Rate
            if (this.valueObj.ratingFlag != 'M' && this.valueObj.isRatingCommitteRateRequired != undefined && this.valueObj.isRatingCommitteRateRequired != "" && (Boolean(JSON.parse(this.valueObj.isRatingCommitteRateRequired)) == true || this.valueObj.rateBasis == 'S') && numeral(this.valueObj.ratingCommitteeRate).value() <= 0) {
                result.isValid = false;
                result.message = result.message + "<br/>Please enter value for Rating Committe Rate field and proceed.";
            } else if (this.valueObj.ratingFlag != 'M' && this.valueObj.isRatingCommitteRateRequired != undefined && this.valueObj.isRatingCommitteRateRequired != "" && Boolean(JSON.parse(this.valueObj.isRatingCommitteRateRequired)) == false && this.valueObj.ratingCommitteeRate > 0) {
                result.isValid = false;
                result.message = result.message + "<br/>Rating Committe Rate field is not a mandatory to key-in incase of PIAM Code having Rate value.";
            }
            if (this.valueObj.ratingFlag == 'M' && numeral(this.valueObj.ratingCommitteeRate).value() != numeral(this.valueObj.basicRate).value()) {
                result.isValid = false;
                result.message = result.message + "<br/>For Manual Mode, Rating Committe Rate and Basic Rate should be same.";
            } 
        }
        //End



        if (this.valueObj.FI == "Y") {
            let financialInterestResult = this.validateFinancialInterest();
            if (financialInterestResult.isValid == false) {
                result.isValid = false;
                if (result.message == null || result.message == "") {
                    result.message = this.valueObj.riskType + " (Risk Number: " + this.valueObj.riskNumber + " ): <p>Provide value for all mandatory fields.</p>";
                }
                result.message = result.message + financialInterestResult.message;
            }
            result.childsResult["fiItems"] = financialInterestResult;
        }

        let gstDetailsResult = new GSTDetilsValidator(this.valueObj).validate();
        if (gstDetailsResult.isValid == false) {
            result.isValid = false;
            if (result.message == null || result.message == "") {
                result.message = this.valueObj.riskType + " (Risk Number: " + this.valueObj.riskNumber + " ): <p>Provide value for all mandatory fields.</p>";
            }
            result.message = result.message + gstDetailsResult.message;
        }

        if (this.valueObj.isSurveyNeeded == "Y") {
            let surveyValidatorResult = new SurveyValidator(this.valueObj).validate();
            if (surveyValidatorResult.isValid == false) {
                result.isValid = false;
                if (result.message == null || result.message == "") {
                    result.message = surveyValidatorResult.message;
                } else
                    result.message = result.message + surveyValidatorResult.message;
            }
        }

		/*if( (this.valueObj.riskType == 'ECP' || this.valueObj.riskType == 'PP1' || this.valueObj.riskType == 'ARI') &&  this.valueObj.RIRetentionCode){
			
			let _totalGrossCapacity = BMSConstants.getBmsUtilServiceObj().getNetRetentionAmountDetails(this.valueObj.RIRetentionCode);
			_totalGrossCapacity = (!_totalGrossCapacity) ? 0 : parseFloat(""+_totalGrossCapacity);
			
			let _totalSI = parseFloat(""+this.valueObj.totalSI);
			
			if( _totalGrossCapacity > 0 && _totalSI > _totalGrossCapacity && (this.valueObj.RIMethod == null || this.valueObj.RIMethod == "" || parseFloat(""+this.valueObj.RIMethod) != 8) ){
				result.isValid = false;
				result.message = result.message + "<p>Total Sum Insured is greater than Total Gross Capacity: "+_totalGrossCapacity+",  RI is Required.</p>";
			}
		}*/

		/*
		if(this.valueObj.riskType == 'ARI'){
			let appObj = BMSConstants.getBMSObj();			
			if(appObj){
				// let _targetSumInsured = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.targetSumInsured;
				let _totalSumInsured = parseFloat(""+this.valueObj.totalSI);
				
				// let _businessChannel = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.businessChannel;				
				// if( parseFloat(""+_targetSumInsured) < 50000000 && _businessChannel != '06' && _businessChannel != '08' && _businessChannel != '11'){
					// result.isValid = false;
					// result.message = result.message + "<p>Target Sum Insured is less than 50 Million.</p>";
				// }
				
				if(this.valueObj.rateBasis == 'A' && ( _totalSumInsured < 50000000 || _totalSumInsured >= 300000000)){
					result.isValid = false;
					result.message = result.message + "<p>Target Sum Insured should be equal to or more than 50 Million and less than 300 Million.</p>";
				}
				
				if(this.valueObj.rateBasis == 'L' && _totalSumInsured < 300000000){
					result.isValid = false;
					result.message = result.message + "<p>Target Sum Insured should be equal to or more than 300 Million.</p>";
				}
			}
		}
		*/

		//VK004 General Page Text
		if(Number(this.valueObj.gpTextCount) > Number(headerInfo.gpTextMaxLines)) {
			result.isValid = false;
			result.message = this.valueObj.riskType+" (Risk Number: "+this.valueObj.riskNumber+" ) : General Page Text entered is more than 400 lines.";
		}
		//VK004 END
        result.childsResult["fea"] = feaResult;
        result.childsResult["clause"] = clauseResult;
        result.childsResult["cover"] = coverResult;

        return result;
    }

    validateClauses(idc: FireIDC) {
        let result = new ValidationResult();
        result.message = "";
        if (idc.rateableClassCode == null || typeof (idc.rateableClassCode) === "string" || idc.rateableClassCode.rateableClassCode == null || typeof (idc.rateableClassCode.rateableClassCode) === "string") {
            result.isValid = true;
        }
        else {
            let _rateableClausesAry = new AppUtil().getArray(idc.rateableClassCode.rateableClassCode);
            let fireItems = JSON.stringify(idc.fireItems);
            result.isValid = true;
            for (let _clause of _rateableClausesAry) {

                if (fireItems.indexOf("\"" + _clause.classCode + "\"") == -1) {
                    result.isValid = false;
                    result.message = result.message + "<p>Clause " + _clause.classCode + " is not added to any cover.</p>";
                }
            }
        }

		/*else if(Array.prototype.isPrototypeOf(idc.rateableClassCode.rateableClassCode)){
			let fireItems = JSON.stringify(idc.fireItems);
			result.isValid = true;
			for(let clause of idc.rateableClassCode.rateableClassCode){
				if(fireItems.indexOf("\""+clause.classCode+"\"") == -1){
					result.isValid = false;
					result.message = "<p>Clause "+ clause.classCode + " is not added to any cover.</p>";
				}
			}
		}
		else if(!Array.prototype.isPrototypeOf(idc.rateableClassCode.rateableClassCode)){
			let tempAry:any = idc.rateableClassCode.rateableClassCode;
			let clauseAry = [tempAry];
			let fireItems = JSON.stringify(idc.fireItems);
			result.isValid = true;
			for(let clause of clauseAry){
				if(fireItems.indexOf("\""+clause.classCode+"\"") == -1){
					result.isValid = false;
					result.message = "<p>Clause " + clause.classCode + " is not added to any cover.</p>";
				}
			}
		}*/

        if (idc.rateableClassCode && idc.rateableClassCode.rateableClassCode && idc.rateableClassCode.rateableClassCode.length > 0 && idc.clauses && idc.clauses.clause && idc.clauses.clause.length > 0) {
            let _generalClauses = JSON.stringify(idc.clauses);
            for (let _clause of idc.rateableClassCode.rateableClassCode) {
                if (_generalClauses.indexOf("\"" + _clause.classCode + "\"") != -1) {
                    result.isValid = false;
                    result.message = result.message + "<p>Clause code " + _clause.classCode + " added in both Rateable Clauses and Clauses sections</p>";
                }
            }
        }

        if (this.valueObj.clauses && this.valueObj.clauses.clause && this.valueObj.clauses.clause.length > 0 && this.valueObj.rateableClassCode && this.valueObj.perils.peril && this.valueObj.perils.peril.length > 0) {
            for (let _peril of this.valueObj.perils.peril) {
                let _filterdClauses = this.valueObj.clauses.clause.filter((_item) => _item.clauseCode === _peril.perilCode);
                if (_filterdClauses && _filterdClauses.length > 0) {
                    result.isValid = false;
                    result.message = result.message + "<p>Clause Code " + _peril.perilCode + " added in both Clauses and Perils Information Sections.</p>";
                    break;
                }
            }
        }

        return result;
    }

    validateFinancialInterest() {
        let result = new ValidationResult();
        result.isValid = true;
        if (this.valueObj.FI == "Y" && this.valueObj.financialInterest != null && this.valueObj.financialInterest != "") {
            if (this.valueObj.financialInterest.financialInterestList != undefined && !(this.valueObj.financialInterest.financialInterestList.constructor === Array)) {
                let financialInterestItems: any = this.valueObj.financialInterest.financialInterestList;
                this.valueObj.financialInterest.financialInterestList = [financialInterestItems];
            }

            if (this.valueObj.financialInterest.financialInterestList.length > 0) {
                for (let fiItem of this.valueObj.financialInterest.financialInterestList) {

                    let fiTemValid = new FinancialInterestValidator(fiItem).validate();
                    if (fiTemValid.isValid == false) {
                        result.isValid = false;
                    }
                    result.message = result.message + fiTemValid.message;
                }
            }
            else {
                result.isValid = false;
                result.message = this.valueObj.riskType + " (Risk Number: " + this.valueObj.riskNumber + " ):  Atleast one Financial Interest Item must be added for the Risk.";
            }
        }
        return result;
    }
}

export class FEAValidator extends Validator {
    constructor(fea: FEA) {
        super();
        this.valueObj = fea;
    }

    public validate() {
        let result = new ValidationResult();
        result.isValid = true;
        /*
        if (this.valueObj == null || this.valueObj.FEAeq == null || this.valueObj.FEAeq == "") {
            result.isValid = false;
            result.message = "<p>Add FEA in FEA Information section.</p>";
        }
        else if (Array.prototype.isPrototypeOf(this.valueObj.FEAeq)) {
            if (this.valueObj.FEAeq.length > 0) {
                result.isValid = true;
            }
            else {
                result.isValid = false;
                result.message = "<p>Add FEA in FEA Information section.</p>";
            }
        }
        else if (!Array.prototype.isPrototypeOf(this.valueObj.FEAeq)) {
            let tempAry: any = this.valueObj.FEAeq;
            let feaAry = [tempAry];
            if (feaAry[0].code == null) {
                result.isValid = false;
                result.message = "<p>Add FEA in FEA Information section.</p>";
            }
            else {
                result.isValid = true;
            }
        }*/
        // SAF MYS-2018-0666 --start
        if (this.valueObj.FEAeq.length > 0) {
            let excludedItems: any = [];
            let excludedClausesList: any = [];
            let isExcludedItems: boolean = false;
            // fill excludedItems list
            for (let item of this.valueObj.FEAeq) {
                if (item.exFEAClauses != undefined && item.exFEAClauses != "" && excludedItems.indexOf(item.exFEAClauses) == -1) {
                    if (item.exFEAClauses.length > 0) {
                        for (let subItem of item.exFEAClauses)
                            excludedItems.push(subItem);
                    } else {
                        excludedItems.push(item.exFEAClauses);
                    }
                }
            }

            // validate excludedItems with FEA item code.
            if (excludedItems.length > 0) {
                for (let item of this.valueObj.FEAeq) {
                    if (excludedItems.indexOf(item.feaCode) != -1) {
                        isExcludedItems = true;
                    }
                }
            }
            if (isExcludedItems) {
                result.isValid = false;
                result.message = "There are some Excluded items in selected FEA list. List is : " + excludedClausesList;
            }
        } //End
        return result;
    }
}