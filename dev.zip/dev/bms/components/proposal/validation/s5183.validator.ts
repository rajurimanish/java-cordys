/*
* Change History	:
*
*	No      Date          	Description                Changed By
*	====    ==========    	===========	               ==========	
* 
* 	VK004	06/12/2018		MYS-2018-1192					VKR
*/
import { Validator, ValidationResult } from '../../../../common/components/validator/validator';
import { GSTDetilsValidator } from './gstdetails.validator';
import { S5183 } from '../newbusinessrisks/s5183/appobjects/s5183';
import { BMSConstants } from '../../common/constants/bms_constants';

export class S5183Validator extends Validator {
    public fields: Array<any> = [
        "insuredName",
        "occupationCode",
        "occupationDescription",
        "ratingClass",
        "dateOfBirth",
        "ratingFlag",
        "plan",
        "capitalSumInsured"
    ];
    public fieldNames: any = {
        insuredName: "Insured Person",
        occupationCode: "Occupation Code",
        occupationDescription: "Occupation Description",
        ratingClass: "Occupation Class",
        dateOfBirth: "Date of Birth",
        ratingFlag: "Rating Flag",
        plan: "Plan",
        capitalSumInsured: "Capital Sum Insured"
    };
    constructor(s5183: S5183) {
        super();
        this.valueObj = s5183;
        this.requiredFields = this.fields;
    }

    public validate() {
        let result = super.validate();

        let validHeaderMandatoryFields: boolean = true;
        if (result.isValid == false) {
            validHeaderMandatoryFields = false;
            result.message = this.valueObj.riskType + " (Risk Number: " + this.valueObj.riskNumber + " ): <p>Provide value for all mandatory fields.</p>" + this.getInvalidFields(result, this.fieldNames);
        }

        if (!this.valueObj.basicPremium || !parseFloat("" + this.valueObj.basicPremium)) {
            result.isValid = false;
            result.message = result.message + "<br>Basic Premium cannot be Zero. Select valid plan";
        }

        if (this.valueObj.additionalCoverDetails.additionalCover && this.valueObj.additionalCoverDetails.additionalCover.length > 0) {
            for (let _addlCover of this.valueObj.additionalCoverDetails.additionalCover) {
                if (!(_addlCover.additionalLoading > 0)) {
                    result.isValid = false;
                    result.message = result.message + "<p>- Additional Cover: Rate is mandatory.</p>";
                    break;
                }
            }
        }

        if (this.valueObj.capitalSumInsured <= 0) {
            result.isValid = false;
            result.message = result.message + "<p>- Capital Sum Insured(must be greater than 0, select a plan to auto populate)</p>";
        }

        let gstDetailsResult = new GSTDetilsValidator(this.valueObj).validate();
        if (gstDetailsResult.isValid == false) {
            result.isValid = false;
            result.message = result.message + gstDetailsResult.message;
        }

        if (!result.isValid && validHeaderMandatoryFields) {
            result.message = this.valueObj.riskType + " (Risk Number: " + this.valueObj.riskNumber + " ): <p>Provide value for all mandatory fields.</p>" + result.message;
        }

		//VK004 General Page Text
		let headerInfo = BMSConstants.getBMSHeaderInfo();
		if(Number(this.valueObj.gpTextCount) > Number(headerInfo.gpTextMaxLines)) {
			result.isValid = false;
			result.message = this.valueObj.riskType+" (Risk Number: "+this.valueObj.riskNumber+" ): General Page Text entered is more than 400 lines.";
		}
		//VK004 END
        return result;

    }

    validateInsured() {
        let addedInsured = false;
        if (this.valueObj.s5382Items != null && this.valueObj.s5382Items.s5382Item != null && this.valueObj.s5382Items.s5382Item != "") {
            if (Array.prototype.isPrototypeOf(this.valueObj.s5382Items.s5382Item) && this.valueObj.s5382Items.s5382Item.length > 0) {
                addedInsured = true;
            }
            else if (Array.prototype.isPrototypeOf(this.valueObj.s5382Items.s5382Item) && this.valueObj.s5382Items.s5382Item.length == 0) {
                addedInsured = false;
            }
            else {
                addedInsured = true;
            }
        }
        return addedInsured;
    }

}