import { Validator, ValidationResult } from '../../../../common/components/validator/validator';
import { BMSConstants } from '../../common/constants/bms_constants';
import { GSTDetails } from '../newbusinessrisks/appobjects/gstDetails';

export class GSTDetilsValidator extends Validator {
    private riskObj;
    public fields: Array<any> = [];
    public fieldNames: any = {
        "riskUsage": "Risk Usage",
        "riskLocation": "Risk Location",
        "placeOfRecidence": "Place of Residence / Business",
        "inputTaxAllowed": "Input Tax Allowed?"
    };

    constructor(riskObj: Object) {
        super();
        this.riskObj = riskObj;
        this.valueObj = this.riskObj.GSTDetails;
        this.requiredFields = this.fields;
    }

    public validate() {

        let _insuredType = BMSConstants.getInsuredType();
        let _key = this.riskObj.riskType + _insuredType;
        let _mandatoryGSTFields = BMSConstants.getMandatoryGSTFields(_key);

        if (!_mandatoryGSTFields && BMSConstants.getBmsUtilServiceObj()) {
            BMSConstants.getBmsUtilServiceObj().getGstMandatoryFieldsSync(this.riskObj.riskType, _insuredType);
            _mandatoryGSTFields = BMSConstants.getMandatoryGSTFields(_key);
        }

        if (_mandatoryGSTFields) {
            for (let _gstFld in _mandatoryGSTFields) {
                if (_mandatoryGSTFields[_gstFld])
                    this.fields.push(_mandatoryGSTFields[_gstFld]);
            }
        }

        let result = super.validate();

        if (result.isValid == false) {
            result.message = "<br>GST Information: Provide value for all mandatory fields." + this.getInvalidFields(result, this.fieldNames);
        } else if (!_mandatoryGSTFields) {
            result.isValid = false;
            result.message = "<br>GST Information: Provide value for all mandatory fields.";
        }

        return result;
    }

}