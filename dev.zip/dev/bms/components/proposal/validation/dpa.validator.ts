/*
 * Change History:
 * 
 * No      Date          Description                                   Changed By
 * ====    ==========    ===========                                   ==========
 * AL001   15/08/2017   MYS-2017-0371    -  Develop MPD               ALA
 * GA001   19/10/2018   MYS-2018-1291 : Incorrect rounding of 
 *                      Total share percentage of Nominee Details	  KGA
 * VK004	03/12/2018	MYS-2018-1192 General Page						VKR
 * 
*/
import { Validator, ValidationResult } from '../../../../common/components/validator/validator';
import { PADPAItemDetails } from '../newbusinessrisks/driverpa/appobjects/dpa';
import { NomineeValidator } from './nominee.validator';
import { BMSConstants } from '../../common/constants/bms_constants';

declare var numeral: any;//GA001

export class DPAValidator extends Validator {

    public fields: Array<any> = ["insuredPerson",
        "PADriverDetails.vehicalRegNumber",
        "PADriverDetails.makeCode",
        "PADriverDetails.modelCode",
        "PADriverDetails.yearOfMake",
        "seatNo",
        "plan",
        "basicPremium",
        "totalAnnualPremium",
        "sumInsured"];
    public coverNotefields: Array<any> = ["insuredPerson",							//MYS-2018-1145
        "PADriverDetails.makeCode",
        "PADriverDetails.modelCode",
        "PADriverDetails.yearOfMake",
        "seatNo",
        "plan",
        "basicPremium",
        "totalAnnualPremium",
        "sumInsured"];
    constructor(dpaObj: PADPAItemDetails) {
        super();
        this.valueObj = dpaObj;
        let caseInfo = BMSConstants.getBMSCaseInfo();//MYS-2018-1145 Added this line and below
        this.requiredFields = caseInfo.businessFunction != "CoverNote" ? this.fields : this.coverNotefields;
    }

    public validate() {
        let result = super.validate();
        if (result.isValid == false) {
            result.message = this.valueObj.riskType + "(Risk Number: " + this.valueObj.itemNo + " ): Provide value for all mandatory fields."; //AL001
        }
        else if (result.isValid == true) {
            if (!isNaN(this.valueObj.seatNo) && Number(this.valueObj.seatNo) <= 0) {
                result.isValid = false;
                result.message = "Number of Seats should be greater than 0.";
            }
        }

        if (this.valueObj.nomineeDetails)
            result = this.validateNomioneeDetails(result);

        //VK004 General Page Text
        let headerInfo = BMSConstants.getBMSHeaderInfo();
        if (Number(this.valueObj.gpTextCount) > Number(headerInfo.gpTextMaxLines)) {
            result.isValid = false;
            result.message = result.message + this.valueObj.riskType + "(Risk Number: " + this.valueObj.itemNo + " ): General Page Text entered is more than 400 lines.";
        }                
        return result;
    }

    validateNomioneeDetails(result) {
        if (this.valueObj.nomineeDetails != null) {

            if (this.valueObj.nomineeDetails.nominee != undefined && !(this.valueObj.nomineeDetails.nominee.constructor === Array)) {
                let nomineeItems: any = this.valueObj.nomineeDetails.nominee;
                this.valueObj.nomineeDetails.nominee = [nomineeItems];
            }

            if (this.valueObj.nomineeDetails.nominee.length > 0) {
                let percentageTotal: number = 0;
                for (let nominee of this.valueObj.nomineeDetails.nominee) {

                    // result.fields.push("nomineeDetails");
                    let nomineeValid = new NomineeValidator(nominee).validate();
                    if (nomineeValid.isValid == false) {
                        result.isValid = false;
                        result.message = result.message + nomineeValid.message;
                        result.childsResult["nomineeDetails"] = nomineeValid;
                        result.validationResult["nomineeDetails"] = nomineeValid.isValid;
                        return result;
                    }
                    else {
                        //GA001 START
                        //percentageTotal = Number(percentageTotal) + Number(nominee.percentageOfShare);
                        percentageTotal = numeral(percentageTotal).add(parseFloat(nominee.percentageOfShare)).value();
                        //GA001 END
                    }
                }
                if (percentageTotal != 100) {
                    let nomineeDetails: ValidationResult = new ValidationResult();
                    nomineeDetails.isValid = false;
                    result.isValid = false;
                    nomineeDetails.message = "Nominee Percentage Share Total is not equal to 100. Please make sure the total is equal to 100";
                    result.message = result.message + nomineeDetails.message;
                    result.childsResult["nomineeDetails"] = nomineeDetails;
                    result.validationResult["nomineeDetails"] = nomineeDetails.isValid;
                    return result;
                }
            }
        }
        return result;
    }

}