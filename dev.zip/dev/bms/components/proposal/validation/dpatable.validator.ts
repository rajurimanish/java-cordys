/*
 * Change History:
 * 
 * No      Date          Description                                   Changed By
 * ====    ==========    ===========                                   ==========
 * AL001   15/08/2017   MYS-2017-0371    -  Develop MPD               ALA	
 * VK004	03/12/2018	MYS-2018-1192 General Page						VKR
 * 
*/
import { Validator, ValidationResult } from '../../../../common/components/validator/validator';
import { DriverPersonalAccident } from '../newbusinessrisks/driverpa/appobjects/dpa';
import { DPAValidator } from './dpa.validator';
import { BMSConstants } from '../../common/constants/bms_constants';

export class DPATableValidator extends Validator {
    public fields: Array<any> = ["RIRetentionCode",
        "dateOfAttachment",
        "riskType",
        "riskNumber",
        "capitalSumInsured",
        "totalPremium"];
    constructor(dpaTable: DriverPersonalAccident) {
        super();
        this.valueObj = dpaTable;
        this.requiredFields = this.fields;
    }

    public validate() {
        let result = super.validate();
        //AL001 START
        let riskName = "DPA";
        this.valueObj.paDPAItems.paDPAItem.forEach(eachRisk => {
            riskName = eachRisk.riskType;
        });
        //AL001 END
        if (result.isValid == true) {
            if (this.hasRisks()) {
                let allRisks = [];
                if (!Array.prototype.isPrototypeOf(this.valueObj.paDPAItems.paDPAItem)) {
                    let tempAry: any = this.valueObj.paDPAItems.paDPAItem;
                    allRisks = [tempAry];
                }
                else {
                    allRisks = this.valueObj.paDPAItems.paDPAItem;
                }
                let count = 1;
                let chCount = 1;
                for (let eachRisk of allRisks) {
                    let dpaResult = new DPAValidator(eachRisk).validate();
                    if (dpaResult.isValid == false) {
                        result.isValid = false;
                        result.message = "<p>" + dpaResult.message + "</p>";
                        count++;
                    }
                    result.childsResult[riskName + chCount] = dpaResult; //AL001
                    chCount++;
                }
            }
            else {
                result.isValid = false;
                result.message = "<p>" + riskName + "risk table:Provide value for mandatory fields.</p>";//AL001
            }
        }
        else {
            result.message = "<p>DPA risk table:Provide value for mandatory fields.</p>";
        }
		//VK004 General Page Text
		if(Number(this.valueObj.gpTextCount) > Number(BMSConstants.getBMSHeaderInfo().gpTextMaxLines)) {
			result.isValid = false;
			result.message = result.message +this.valueObj.riskType +"(Risk Number: "+this.valueObj.riskNumber+" ): General Page Text entered is more than 400 lines."+"<br/>";
		}
        return result;
    }

    hasRisks() {
        let hasRisk = false;
        if (this.valueObj.paDPAItems != null && this.valueObj.paDPAItems.paDPAItem != null && this.valueObj.paDPAItems.paDPAItem != "") {
            if (Array.prototype.isPrototypeOf(this.valueObj.paDPAItems.paDPAItem) && this.valueObj.paDPAItems.paDPAItem.length > 0) {
                hasRisk = true;
            }
            else if (Array.prototype.isPrototypeOf(this.valueObj.paDPAItems.paDPAItem) && this.valueObj.paDPAItems.paDPAItem.length == 0) {
                hasRisk = false;
            }
            else {
                hasRisk = true;
            }
        }
        return hasRisk;
    }

}