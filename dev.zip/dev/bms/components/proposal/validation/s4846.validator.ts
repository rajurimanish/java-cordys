import { AppUtil } from '../../../../common/components/utility/apputil/app.util';
import { ValidationResult, Validator } from '../../../../common/components/validator/validator';
import { BMSConstants } from '../../common/constants/bms_constants';
import { S4846 } from '../newbusinessrisks/s4846/appobjects/s4846';
import { ProposalHeader } from '../proposalheader/appobjects/proposalheader';
import { FinancialInterstValidator } from './financialinterest.validator';
import { GSTDetilsValidator } from './gstdetails.validator';
import { SurveyValidator } from './survey.validator';

export class S4846Validator extends Validator {
    public fields: Array<any> = ["postCode",
        "situation1",
        "locality",
        "construction",
        "cityName",
        "accumulationRegister",
        "townClass",
        "RIRetentionCode",
        "rateBasis",
        "yearOfConstruction",
        "storeys",
        "totalBasicPremium",
        "totalSI",
        "totalPremium"];
    public fieldNames: any = {
        postCode: "Post Code",
        situation1: "Location",
        locality: "Locality",
        construction: "Construction",
        cityName: "Town/City",
        accumulationRegister: "Accumulation Register",
        townClass: "Town Class",
        RIRetentionCode: "RI Retention Code",
        rateBasis: "Rate Basis",
        yearOfConstruction: "Year Of Construction",
        storeys: "Storeys",
        totalBasicPremium: "Total Basic Premium",
        totalSI: "Total Sum Insured",
        totalPremium: "Total Premium",
        "GSTDetails.riskUsage": "GST Risk Usage",
        "GSTDetails.riskLocation": "GST Risk Location",
        "GSTDetails.placeOfRecidence": "GST Place of Residence"
    };

    constructor(s4846: S4846) {
        super();
        this.valueObj = s4846;
        this.requiredFields = this.fields;
    }

    public validate() {
        let result = super.validate();
        let validHeaderMandatoryFields: boolean = true;
        if (result.isValid == false) {
            validHeaderMandatoryFields = false;
            result.message = this.valueObj.riskType + " (Risk Number: " + this.valueObj.riskNumber + " ): <p>Provide value for all mandatory fields.</p>" + this.getInvalidFields(result, this.fieldNames);
        }

        if (this.valueObj.postCode != '' && parseFloat("" + this.valueObj.postCode) <= 0) {
            result.isValid = false;
            result.message = result.message + "<p>Enter valid postcode.</p>";
        }

        if (this.valueObj.storeys != '' && parseFloat("" + this.valueObj.storeys) <= 0) {
            result.isValid = false;
            result.message = result.message + "<p>Storeys must be greater than 0.</p>";
        }

        let coverageResult = this.coverageValidator();
        if (coverageResult.isValid == false) {
            result.isValid = false;
            // if(result.message == null || result.message == ""){
            // result.message = this.valueObj.riskType+" (Risk Number: "+this.valueObj.riskNumber+" ): <p>Provide value for all mandatory fields.</p>";
            // }
            result.message = result.message + coverageResult.message;
        }

        let gstDetailsResult = new GSTDetilsValidator(this.valueObj).validate();
        if (gstDetailsResult.isValid == false) {
            result.isValid = false;
            result.message = result.message + gstDetailsResult.message;
        }

        if (this.valueObj.FI == "Y") {
            let financialInterestValResult = new FinancialInterstValidator(this.valueObj).validate();
            if (financialInterestValResult.isValid == false) {
                result.isValid = false;
                if (result.message == null || result.message == "") {
                    result.message = financialInterestValResult.message;
                } else
                    result.message = result.message + financialInterestValResult.message;
            }
        }

        if (this.valueObj.isSurveyNeeded == "Y") {
            let surveyValidatorResult = new SurveyValidator(this.valueObj).validate();
            if (surveyValidatorResult.isValid == false) {
                result.isValid = false;
                if (result.message == null || result.message == "") {
                    result.message = surveyValidatorResult.message;
                } else
                    result.message = result.message + surveyValidatorResult.message;
            }
        }



        if (!(this.valueObj.rateableClassCode == null || typeof (this.valueObj.rateableClassCode) === "string" || this.valueObj.rateableClassCode.rateableClassCode == null || typeof (this.valueObj.rateableClassCode.rateableClassCode) === "string")) {

            let _rateableClausesAry = new AppUtil().getArray(this.valueObj.rateableClassCode.rateableClassCode);
            let coverageItems = JSON.stringify(this.valueObj.riskCoverageDetails);
            for (let _rateableClause of _rateableClausesAry) {
                if (coverageItems.indexOf("\"" + _rateableClause.classCode + "\"") == -1) {
                    result.isValid = false;
                    result.message = result.message + "<p>Clause " + _rateableClause.classCode + " is not added to any cover.</p>";
                }
            }
        }

        if (this.valueObj.rateableClassCode && this.valueObj.rateableClassCode.rateableClassCode && this.valueObj.rateableClassCode.rateableClassCode.length > 0 && this.valueObj.clauses && this.valueObj.clauses.clause && this.valueObj.clauses.clause.length > 0) {
            let _generalClauses = JSON.stringify(this.valueObj.clauses);
            for (let _clause of this.valueObj.rateableClassCode.rateableClassCode) {
                if (_generalClauses.indexOf("\"" + _clause.classCode + "\"") != -1) {
                    result.isValid = false;
                    result.message = result.message + "<p>Clause code " + _clause.classCode + " added in both Rateable Clauses and Clauses sections</p>";
                }
            }
        }

        if (this.valueObj.clauses.clause && this.valueObj.clauses.clause.length > 0) {
            let _increasedTPLimitToSI = parseFloat("" + this.valueObj.increasedTPLimitToSI);
            let isSelctedTpLimitToClausePresent = false;
            let clauseCodes = '';
            let tpLimitDetails = BMSConstants.getBmsUtilServiceObj().getTPLimitDetails(this.valueObj.riskType);
            if (tpLimitDetails && tpLimitDetails.tuple) {
                let _tpLimitDetailsArr = new AppUtil().getArray(tpLimitDetails.tuple);
                for (let _tplmt of tpLimitDetails.tuple) {
                    let _tpLmtVal = parseFloat("" + _tplmt.old.T7210.SUMINSURED);
                    let _tpCls = _tplmt.old.T7210.SCLS;
                    let _filteredClauses = this.valueObj.clauses.clause.filter((_item) => _item.clauseCode == _tpCls);
                    if (_filteredClauses && _filteredClauses.length > 0) {
                        clauseCodes = (clauseCodes) ? clauseCodes + "," + _tpCls : _tpCls;
                        if (_increasedTPLimitToSI == _tpLmtVal) isSelctedTpLimitToClausePresent = true;
                    }
                }
            }

            if (_increasedTPLimitToSI <= 0 && clauseCodes) {
                result.isValid = false;
                if (clauseCodes && clauseCodes.indexOf(",") > 0)
                    result.message = result.message + "<p>'Increased TP Limit To' cannot be blank, as " + clauseCodes + " are added into Clause Code</p>";
                else
                    result.message = result.message + "<p>'Increased TP Limit To' cannot be blank, as " + clauseCodes + " is added into Clause Code</p>";
            }

            if (_increasedTPLimitToSI > 0 && clauseCodes && clauseCodes.indexOf(",") > 0) {
                result.isValid = false;
                result.message = result.message + "<p>Either one of " + clauseCodes + " Clauses can be added</p>";
            }

			/*if(_increasedTPLimitToSI > 0 && !isSelctedTpLimitToClausePresent){
				result.isValid = false;
				result.message = result.message + "<p>Clause code related to 'Increased TP Limit To' is missing</p>";
			}*/
        }


		/*if(this.valueObj.RIRetentionCode){
			let _totalGrossCapacity = BMSConstants.getBmsUtilServiceObj().getNetRetentionAmountDetails(this.valueObj.RIRetentionCode);
			_totalGrossCapacity = (!_totalGrossCapacity) ? 0 : parseFloat(""+_totalGrossCapacity);
			
			let _totalSI = parseFloat(""+this.valueObj.totalSI);
			
			if( _totalGrossCapacity > 0 && _totalSI > _totalGrossCapacity && (this.valueObj.RIMethod == null || this.valueObj.RIMethod == "" || parseFloat(""+this.valueObj.RIMethod) != 8) ){
				result.isValid = false;			
				result.message = result.message + "<p>Total Sum Insured is greater than Total Gross Capacity: "+_totalGrossCapacity+",  RI is Required.</p>";
			}
		}*/

        // SAF MYS-2018-1249 Start
        let headerInfo: ProposalHeader = BMSConstants.getBMSHeaderInfo();
        if (headerInfo.VPMSProduct == "Y") {
            let pItemCodes: Array<string> = [];
            let pItems = this.valueObj.perils.peril.filter(_item => _item.nominatedSumInsured == undefined || _item.nominatedSumInsured <= 0);
            for (let item of pItems) {
                pItemCodes.push(item.perilCode);
            }
            if (pItemCodes.length > 0) {
                result.isValid = false;
                if (result.message == null || result.message == "") {
                    result.message = this.valueObj.riskType + " (Risk Number: " + this.valueObj.riskNumber + " ): <p>Provide value for all mandatory fields.</p>";
                }
                result.message = result.message + "<br/>Peril items : " + pItemCodes.join(", ") + " not added to any cover."
            }
        }
        //End

        if (!result.isValid && validHeaderMandatoryFields) {
            result.message = this.valueObj.riskType + " (Risk Number: " + this.valueObj.riskNumber + " ): <p>Provide value for all mandatory fields.</p>" + result.message;
        }

        return result;
    }

    private coverageValidator() {
        let result = new ValidationResult();
        if (this.valueObj.riskCoverageDetails.riskCoverage == null || this.valueObj.riskCoverageDetails.riskCoverage == "") {
            result.isValid = false;
            result.message = "<p>Add cover in Coverage Information section.</p>";
        }
        else {
            let riskCoverageItemsArr = new AppUtil().getArray(this.valueObj.riskCoverageDetails.riskCoverage);

            if (riskCoverageItemsArr.length > 0) {
                result.isValid = true;
                for (let coverageItem of riskCoverageItemsArr) {
                    if ((coverageItem.PIAMCode == null || coverageItem.PIAMCode == "") || (coverageItem.sumInsured == null || coverageItem.sumInsured <= 0) || (coverageItem.totalRate == null || coverageItem.totalRate <= 0) || (coverageItem.premiumClass == null || coverageItem.premiumClass == "")) {
                        result.isValid = false;
                    }
                }

                if (result.isValid == false) {
                    result.message = "<p>Fill all mandatory fields in Coverage Information section.</p>";
                }
                let _isInvalidRate = false;
                for (let coverageItem of riskCoverageItemsArr) {
                    if (!(coverageItem.extRate == null || coverageItem.extRate == "") && parseFloat("" + coverageItem.extRate) > 99.99999) {
                        result.isValid = false;
                        _isInvalidRate = true;
                        break;
                    }
                }
                if (_isInvalidRate) {
                    result.message = "<p>Coverage Total Rate should not more than 99.99999</p>";
                }
            }
            else {
                result.isValid = false;
                result.message = "<p>Add cover in Coverage Information section.</p>";
            }
        }

        return result;
    }
}