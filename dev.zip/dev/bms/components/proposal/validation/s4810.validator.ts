/*
 * Change History:
 * 
 * No      Date          Description                                   Changed By
 * ====    ==========    ===========                                   ==========
 * VK004	05/12/2018	MYS-2018-1192								  	VKR
 * 
*/
import { Validator, ValidationResult } from '../../../../common/components/validator/validator';
import { GSTDetilsValidator } from './gstdetails.validator';
import { ExcessTypeValidator } from './excesstype.validator';
import { SurveyValidator } from './survey.validator';
import { S4810 } from '../newbusinessrisks/s4810/appobjects/s4810';
import { BMSConstants } from '../../common/constants/bms_constants';
import { AppUtil } from '../../../../common/components/utility/apputil/app.util';
import { FinancialInterstValidator } from './financialinterest.validator';

export class S4810Validator extends Validator {
    public fields: Array<any> = ["ratingFlag",
        "occupationCode",
        "occupationDesc",
        "riRetentionCode",
        "tLimit"
    ];
    public fieldNames: any = {
        ratingFlag: "Rating Flag",
        "occupationCode": "Occupation",
        "occupationDesc": "Occupation Description",
        "riRetentionCode": "RI Retention Code",
        "tLimit": "Territorial Limit",
        "ncdPercentage": "NCD %",
        "hasClaimExperience": "Has Claim Experience?",
        "GSTDetails.riskUsage": "GST Risk Usage",
        "GSTDetails.riskLocation": "GST Risk Location",
        "GSTDetails.placeOfRecidence": "Place of Residence / Business",
        "GSTDetails.inputTaxAllowed": "Input Tax Allowed?"
    };
    constructor(s4810: S4810) {
        super();
        this.valueObj = s4810;
        this.requiredFields = this.fields;
    }

    public validate() {

        this.setMandatoryFields();

        let result = super.validate();
        let validHeaderMandatoryFields: boolean = true;
        if (result.isValid == false) {
            validHeaderMandatoryFields = false;
            result.message = this.valueObj.riskType + " (Risk Number: " + this.valueObj.riskNumber + " ): <p>Provide value for all mandatory fields.</p>" + this.getInvalidFields(result, this.fieldNames);
        }

        if (!this.valueObj.limitAOA || !parseFloat("" + this.valueObj.limitAOA)) {
            result.isValid = false;
            if (this.valueObj.riskType == 'PL')
                result.message = result.message + "<br>Limit of Liability AOA must be greater than 0.";
            if (this.valueObj.riskType == 'PP3')
                result.message = result.message + "<br>Limit of Indemnity must be greater than 0.";
        }

        if (this.valueObj.riskType == 'PP3' && (!this.valueObj.limitAOP || !(parseFloat("" + this.valueObj.limitAOP) >= 0))) {
            result.isValid = false;
            result.message = result.message + "<br>Limit of Liability AOP must be greater than or equal to 0.";
        }

        let excessTypeResult = new ExcessTypeValidator(this.valueObj).validate();
        if (excessTypeResult.isValid == false) {
            result.isValid = false;
            result.message = result.message + excessTypeResult.message;
        }

        if (this.valueObj.riskType == 'PL') {
            let addlLocResult = this.additaionlLocationValidator();
            if (addlLocResult.isValid == false) {
                result.isValid = false;
                result.message = result.message + addlLocResult.message;
            }
        }

        if (this.valueObj.ratingFlag == 'A' && (!this.valueObj.rate || !parseFloat("" + this.valueObj.rate))) {
            result.isValid = false;
            result.message = result.message + "<br>Rate % must be greater than 0.";
        }

        if (!this.valueObj.basicPremium || !parseFloat("" + this.valueObj.basicPremium)) {
            result.isValid = false;
            result.message = result.message + "<br>Basic Premium must be greater than 0.";
        }

        let gstDetailsResult = new GSTDetilsValidator(this.valueObj).validate();
        if (gstDetailsResult.isValid == false) {
            result.isValid = false;
            result.message = result.message + gstDetailsResult.message;
        }

        if (this.valueObj.FI == "Y") {
            let financialInterestValResult = new FinancialInterstValidator(this.valueObj).validate();
            if (financialInterestValResult.isValid == false) {
                result.isValid = false;
                if (result.message == null || result.message == "") {
                    result.message = financialInterestValResult.message;
                } else
                    result.message = result.message + financialInterestValResult.message;
            } else if (!this.valueObj.financialInterest || !this.valueObj.financialInterest.financialInterestList || this.valueObj.financialInterest.financialInterestList.length == 0) {
                result.isValid = false;
                if (result.message == null || result.message == "") {
                    result.message = "<br>Add Financial Interest details.";
                } else
                    result.message = result.message + "<br>Add Financial Interest details.";
            }
        }

        if (this.valueObj.isSurveyNeeded == "Y") {
            let surveyValidatorResult = new SurveyValidator(this.valueObj).validate();
            if (surveyValidatorResult.isValid == false) {
                result.isValid = false;
                if (result.message == null || result.message == "") {
                    result.message = surveyValidatorResult.message;
                } else
                    result.message = result.message + surveyValidatorResult.message;
            }
        }

        if (this.valueObj.riskType == "PP3") {
            let _caseStatus = BMSConstants.getBMSObj().ApplicationBusinessObject.caseInfo.status;
            if (_caseStatus == "Policy Processing") {
                if (this.valueObj.mandatoryPolicies.mandatoryPolicy == null || this.valueObj.mandatoryPolicies.mandatoryPolicy == "" || this.valueObj.mandatoryPolicies.mandatoryPolicy.length == 0) {
                    result.isValid = false;
                    result.message = result.message + "<p>Mandatory Policy details are mandatory.</p>";
                }
                else if (this.valueObj.mandatoryPolicies.mandatoryPolicy.length > 50) {
                    result.isValid = false;
                    result.message = result.message + "<p>Only 50 Mandatory Policies are allowed.</p>";
                }
            }
        }

		/*
		let _headerInfo = BMSConstants.getBMSHeaderInfo();
		if(_headerInfo.contractType== 'CAR' || _headerInfo.contractType=='EAR'){
			let _bmsRisks = BMSConstants.getRisks();
			if( !(_bmsRisks && _bmsRisks['s4851'] && _bmsRisks['s4851'].length > 0) ){
				if(result.message == null || result.message == "")
					result.message = "<br>At least one "+_headerInfo.contractType+" risk must be added.";
				else 
					result.message = result.message + "<br>At least one "+_headerInfo.contractType+" risk must be added.";
			}
		}		
		*/

        if (!result.isValid && validHeaderMandatoryFields) {
            result.message = this.valueObj.riskType + " (Risk Number: " + this.valueObj.riskNumber + " ): <p>Provide value for all mandatory fields.</p>" + result.message;
        }

		//VK004 General Page Text
		let headerInfo = BMSConstants.getBMSHeaderInfo();
		if(Number(this.valueObj.gpTextCount) > Number(headerInfo.gpTextMaxLines)) {
			result.isValid = false;
			result.message = this.valueObj.riskType+" (Risk Number: "+this.valueObj.riskNumber+" ): General Page Text entered is more than 400 lines.";
		}
		//VK004 END
        return result;
    }

    setMandatoryFields() {
        if (this.valueObj.riskType == 'PP3') {
            this.fields.push("ncdPercentage");
            this.fields.push("hasClaimExperience");
        }
        else if (this.valueObj.riskType == 'PL') {
            this.fields.push("hasClaimExperience");
        }
    }

    private additaionlLocationValidator() {
        let result = new ValidationResult();
        if (this.valueObj.additionalLocationDetails.additionalLocation == null || this.valueObj.additionalLocationDetails.additionalLocation == "") {
            result.isValid = false;
            result.message = "<p>Add Additional Location Details.</p>";
        }
        else {
            let addLocItemsArr: any = [];
            addLocItemsArr = new AppUtil().getArray(this.valueObj.additionalLocationDetails.additionalLocation);

            if (addLocItemsArr.length > 0) {
                result.isValid = true;
                for (let alItem of addLocItemsArr) {
                    if ((alItem.riskCode == null || alItem.riskCode == "") || (alItem.situation == null || alItem.situation == "") || (alItem.postCode == null || alItem.postCode == "")) {
                        result.isValid = false;
                    }
                }

                if (result.isValid == false) {
                    result.message = "<p>Fill all mandatory fields in Additional Location Details.</p>";
                }
            }
            else {
                result.isValid = false;
                result.message = "<p>Add Additional Location Details.</p>";
            }
        }

        return result;
    }

}