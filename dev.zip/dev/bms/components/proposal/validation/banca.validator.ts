import { Validator, ValidationResult } from '../../../../common/components/validator/validator';
import { PeriodicDebitDetails } from '../proposalheader/appobjects/proposalheader';

export class PeriodicDebitDetailValidator extends Validator {
    public fields: Array<any> = ["bankBranchCode",
        "bankBranch",
        "bankBranchName",
        "bankCode",
        "bankCodeName"];
    constructor(periodicDebitDetails: PeriodicDebitDetails) {
        super();
        this.requiredFields = this.fields;
        this.valueObj = periodicDebitDetails;
    }

    public validate() {
        let result = super.validate();
        if (result.isValid == true) {

            if ((this.valueObj.loanAccountNumber == undefined || this.valueObj.loanAccountNumber == "") && (this.valueObj.bankAccountNumber == undefined || this.valueObj.bankAccountNumber == "") && (this.valueObj.creditcardNumber == undefined || this.valueObj.creditcardNumber == "")) {
                result.isValid = false;
                result.message = "<p>Provide either Loan Account Number or Bank Account Number or Credit Card Number.</p> ";
            }

            if (this.valueObj.creditcardNumber != undefined && this.valueObj.creditcardNumber != "") {
                if (this.valueObj.creditcardType == undefined || this.valueObj.creditcardType == "") {
                    result.isValid = false;
                    result.message = "<p>Credit Card Type is Mandatory for Credit Card Number.</p>";
                }

                if (this.valueObj.creditcardExpiryYear == undefined || this.valueObj.creditcardExpiryYear == "") {
                    result.isValid = false;
                    result.message = "<p>Credit Card Expiry Year is Mandatory for Credit Card Number.</p> ";
                }

                if (this.valueObj.creditcardExpiryMonth == undefined || this.valueObj.creditcardExpiryMonth == "") {
                    result.isValid = false;
                    result.message = "<p>Credit Card Expiry Month is Mandatory for Credit Card Number.</p> ";
                }
            }

            if (((this.valueObj.creditcardExpiryYear != undefined && this.valueObj.creditcardExpiryYear != "") || (this.valueObj.creditcardType != undefined && this.valueObj.creditcardType != "") || (this.valueObj.creditcardExpiryMonth != undefined && this.valueObj.creditcardExpiryMonth != "")) && (this.valueObj.creditcardNumber == undefined || this.valueObj.creditcardNumber == "")) {
                result.isValid = false;
                result.message = "<p>Credit Card Number is Mandatory for Credit Card Type or Expiry Details .</p> ";
            }
        }
        else {
            result.message = "<p>Banca Info: Provide value for all mandatory fields.</p>";
        }
        result.fields = this.fields;
        return result;
    }
}