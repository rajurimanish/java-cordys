/*
* Change History	:
*
*	No      Date          	Description                Changed By
*	====    ==========    	===========	               ==========	
* 
* 	VK004	06/12/2018		MYS-2018-1192					VKR
*/
import { Validator, ValidationResult } from '../../../../common/components/validator/validator';
import { GSTDetilsValidator } from './gstdetails.validator';
import { ExcessTypeValidator } from './excesstype.validator';
import { FinancialInterstValidator } from './financialinterest.validator';
import { S4861 } from '../newbusinessrisks/s4861/appobjects/s4861';
import { BMSConstants } from '../../common/constants/bms_constants';
import { AppUtil } from '../../../../common/components/utility/apputil/app.util';

export class S4861Validator extends Validator {
    public fields: Array<any> = ["businessCode",
        "businessCodeDesc",
        "occupancyCode",
        "ratingFlag",
        "rate",
        "totalPremium"];

    public fieldNames: any = {
        businessCode: "Business of Insured",
        businessCodeDesc: "Business of Insured Description",
        occupancyCode: "Occupancy Code",
        ratingFlag: "Rating Flag",
        rate: "Rate",
        totalPremium: "Total Premium",
        "GSTDetails.riskUsage": "GST Risk Usage",
        "GSTDetails.riskLocation": "GST Risk Location",
        "GSTDetails.placeOfRecidence": "GST Place of Residence"
    };

    constructor(s4861: S4861) {
        super();
        this.valueObj = s4861;
        this.requiredFields = this.fields;
    }

    public validate() {
        let result = super.validate();
        let validHeaderMandatoryFields: boolean = true;
        if (result.isValid == false) {
            validHeaderMandatoryFields = false;
            result.message = this.valueObj.riskType + " (Risk Number: " + this.valueObj.riskNumber + " ): <p>Provide value for all mandatory fields.</p>" + this.getInvalidFields(result, this.fieldNames);
        }

        if (!this.valueObj.rate || parseFloat("" + this.valueObj.rate) <= 0) {
            result.isValid = false;
            result.message = result.message + "<br>Rate must be greater than 0.";
        }

        if (this.valueObj.perCapital && parseFloat("" + this.valueObj.perCapital) > 0 && (!this.valueObj.totalNoEmps || parseFloat("" + this.valueObj.totalNoEmps) <= 0)) {
            result.isValid = false;
            result.message = result.message + "<br>Number of Employees must be greater than 0.";
        }

        if (this.valueObj.totalNoEmps && parseFloat("" + this.valueObj.totalNoEmps) > 0 && (!this.valueObj.perCapital || parseFloat("" + this.valueObj.perCapital) <= 0)) {
            result.isValid = false;
            result.message = result.message + "<br>Per Capital must be greater than 0.";
        }

        let excessTypeResult = new ExcessTypeValidator(this.valueObj).validate();
        if (excessTypeResult.isValid == false) {
            result.isValid = false;
            result.message = result.message + excessTypeResult.message;
        }

        let coverageResult = this.coverageValidator();
        if (coverageResult.isValid == false) {
            result.isValid = false;
            result.message = result.message + coverageResult.message;
        }

        let gstDetailsResult = new GSTDetilsValidator(this.valueObj).validate();
        if (gstDetailsResult.isValid == false) {
            result.isValid = false;
            result.message = result.message + gstDetailsResult.message;
        }

		/*if(this.valueObj.RIRetentionCode){
			let _totalGrossCapacity = BMSConstants.getBmsUtilServiceObj().getNetRetentionAmountDetails(this.valueObj.RIRetentionCode);
			_totalGrossCapacity = (!_totalGrossCapacity) ? 0 : parseFloat(""+_totalGrossCapacity);
			
			let _limitAggregate = parseFloat(""+this.valueObj.limitAggregate);
			
			if( _totalGrossCapacity > 0 && _limitAggregate > _totalGrossCapacity && (this.valueObj.RIMethod == null || this.valueObj.RIMethod == "" || parseFloat(""+this.valueObj.RIMethod) != 8) ){
				result.isValid = false;			
				result.message = result.message + "<p>Limit of Guarantee in the Aggregate is greater than Total Gross Capacity: "+_totalGrossCapacity+",  RI is Required.</p>";
			}
		}*/

        if (this.valueObj.FI == "Y") {
            let financialInterestValResult = new FinancialInterstValidator(this.valueObj).validate();
            if (financialInterestValResult.isValid == false) {
                result.isValid = false;
                if (result.message == null || result.message == "") {
                    result.message = financialInterestValResult.message;
                } else
                    result.message = result.message + financialInterestValResult.message;
            }
        }

        if (!result.isValid && validHeaderMandatoryFields) {
            result.message = this.valueObj.riskType + " (Risk Number: " + this.valueObj.riskNumber + " ): <p>Provide value for all mandatory fields.</p>" + result.message;
        }
		//VK004 General Page Text
		let headerInfo = BMSConstants.getBMSHeaderInfo();
		if(Number(this.valueObj.gpTextCount) > Number(headerInfo.gpTextMaxLines)) {
			result.isValid = false;
			result.message = this.valueObj.riskType+" (Risk Number: "+this.valueObj.riskNumber+" ): General Page Text entered is more than 400 lines.";
		}
		//VK004 END

        return result;
    }

    private coverageValidator() {
        let result = new ValidationResult();
        if (this.valueObj.riskCoverageDetails.riskCoverage == null || this.valueObj.riskCoverageDetails.riskCoverage == "") {
            result.isValid = false;
            result.message = "<p>Add cover in Coverage Information section.</p>";
        }
        else {
            let riskCoverageItemsArr: any = [];
            if (Array.prototype.isPrototypeOf(this.valueObj.riskCoverageDetails.riskCoverage)) {
                riskCoverageItemsArr = this.valueObj.riskCoverageDetails.riskCoverage;
            } else {
                riskCoverageItemsArr = [this.valueObj.riskCoverageDetails.riskCoverage];
            }

            if (riskCoverageItemsArr.length > 0) {
                result.isValid = true;
                for (let coverageItem of riskCoverageItemsArr) {
                    if ((coverageItem.insuredDetails == null || coverageItem.insuredDetails == "") || (coverageItem.occupationCode == null || coverageItem.occupationCode == "") || (coverageItem.limitGuaranteePerEmp == null || coverageItem.limitGuaranteePerEmp <= 0)) {
                        result.isValid = false;
                    }
                }

                if (result.isValid == false) {
                    result.message = "<p>Fill all mandatory fields in Coverage Information section.</p>";
                }
            }
            else {
                result.isValid = false;
                result.message = "<p>Add cover in Coverage Information section.</p>";
            }
        }

        return result;
    }
}