/*
 * Change History:
 * 
 * No      Date          Description                                   			Changed By
 * ====    ==========    ===========                                   			==========
 * AL001   15/08/2017   MYS-2017-0371    -  Develop MPD                    			ALA	
 * 
 * AL002   18/09/2017   Redmine##764 -Product Type: HVC/ HVT/ HVF  
 *                      -Risk Occupation Code Field									ALA	
 * AL003   18/09/2017   Redmine##763 -Motor: Error message:
 *                		Risk Number: 1 . S4814-REGNO Valid chars:A-Z,0-9,/,-		ALA
 * 
 * SR001   09/07/2018   MYS-2018-0171 - To enhance Special Type & Motor Trade 
 * 						in BMS to integrate with VPMS for HVC, HVT, HVF,
 * 						MTC, MTF, MTT												VSR
 * 
 * GA001    11/01/2019  MYS-2018-1507 - Named Driver pop up validation for
 *                      MPF product in BMS                                          KGA	
 * 
 * SR002   26/04/2019   MYS-2019-0455 - To default 'seating' for bus in 
 *                      TONNAGE/SEATING selection field                             VSR
 * 
 * E1005    18/03/2019  MYS-2019-0215 - Incorrect total premium calculation for 
 * 						HVT,HVC,HVF etc in BMS for NB/RN							
 * 						MTC, MTF, MTT												SRE1
 *
 * VK006    20/03/2019  MMP Product Configuration                                   VKR
 * 
 * SR003    29/05/2019  MYS-2019-0655 - Create Passenger Risk for Hire Vehicles     VSR
 * 
 * SR004    29/05/2019  MYS-2019-0606 - To block client = corporate to buy 
 *                      E-Hail E-Zee extension                                      VSR
 * 
 * VK004	05/12/2018		MYS-2018-1192 - General Page			VKR
 * 
 * MS001    26/07/2019  MMF Product Configuration                                   MSU
 * 
 * KA002    27/09/2019  MYS-2019-0924 - to block prompt alert message on adding     DKA
 *                      E111 benefit if ncd percent = 0; 
*/

import { Validator, ValidationResult } from '../../../../common/components/validator/validator';
import { MotorCommercial } from '../newbusinessrisks/motorcommercial/appobjects/motorcommercial';
import { NamedDriverValidator } from './nameddriver.validator';
import { FinancialInterestValidator } from '../../../../common/components/financialinterest/validation/financialInterest.validator';
import { RiskType } from '../proposalheader/uimodules/risktypes';
import { BMSConstants } from '../../common/constants/bms_constants';
import { BMSType } from '../../common/constants/bms_types';
import { AppUtil } from '../../../../common/components/utility/apputil/app.util';

declare var numeral: any;
declare var moment: any;

export class MotorValidator extends Validator {
    public riskScreen: string = "";
    public fields: Array<any> = ["ratingFlag",
        "CI",
        "occupationCode",
        "occupationDescription",
        "registrationNumber",
        "EW",
        "makeCode",
        "makeModel",
        "makeModelDescription",
        "permittedDriver",
        "petrolDieselIndicator",
        "use",
        "yearManufacture",
        "cover",
        "vehicalClass",
        "vehicalSumInsured",
        "basicPremium",
        "totalSumInsured",
        "totalPremium",
        "PIAMStatistics.engineNo",
        "PIAMStatistics.chassisNo",
        "PIAMStatistics.vehicalClass",
        "PIAMStatistics.antiTheft",
        "PIAMStatistics.saftyFeatures",
        "PIAMStatistics.previousInsurer",
        "PIAMStatistics.garage",
        "PIAMStatistics.vehicalCondition",
        "PIAMStatistics.vehicalRegNo",
        "GSTDetails.riskUsage",
        "GSTDetails.riskLocation",
        "GSTDetails.placeOfRecidence"
    ];
    public fieldNames: any = {
        registrationNumber: "Registration Number",
        EW: "Place of Use / Origin",
        ratingFlag: "Rating Flag",
        CI: "Certificate of Insurance",
        occupationCode: "Occupation Code",
        occupationDescription: "Occupation Description",
        cover: "Coverage",
        CFY: "Claim Free Year",
        makeCode: "Make",
        makeModel: "Model",
        makeModelDescription: "Model Description",
        permittedDriver: "Permitted Driver",
        petrolDieselIndicator: "Petrol / Diesel Indicator",
        sumInsured: "Sum Insured",
        vehicalSumInsured: "Vehicle Sum Insured",
        basicPremium: "Basic Premium",
        totalSumInsured: "Total SumInsured",
        totalPremium: "Total Premium",
        vehicalClass: "Vehicle Class",
        yearManufacture: "Year of Manufacture",
        //capacityValue:"Cubic Capacity",
        use: "Use of Vehicle",
        "GSTDetails.riskUsage": "GST: Risk Usage",
        "GSTDetails.riskLocation": "GST: Risk Location",
        "GSTDetails.placeOfRecidence": "GST: Place Of Residence",
        "PIAMStatistics.engineNo": "Engine No",
        "PIAMStatistics.chassisNo": "Chassis No",
        "PIAMStatistics.vehicalClass": "PIAMStatistics: Vehicle Class",
        "PIAMStatistics.antiTheft": "PIAMStatistics: Anti Theft Devices",
        "PIAMStatistics.saftyFeatures": "PIAMStatistics: Safety Features",
        "PIAMStatistics.previousInsurer": "PIAMStatistics: Previous Insurer",
        "PIAMStatistics.garage": "PIAMStatistics: Garage",
        "PIAMStatistics.vehicalCondition": "Vehicle Condition",
        "PIAMStatistics.vehicalRegNo": "PIAMStatistics: Vehicle Registration No"
    };
    constructor(motorObj: MotorCommercial) {
        super();
        this.valueObj = motorObj;
        this.requiredFields = this.fields;
    }
    handleCoverNoteCase() {
        if (BMSConstants.getBMSType() == BMSType.CoverNote && BMSConstants.getSatus() != "Cover Note Accepted") {
            if (this.fields.indexOf('registrationNumber') > -1 && this.fields.indexOf('PIAMStatistics.vehicalRegNo') > -1) {
                this.fields.splice(this.fields.indexOf('registrationNumber'), 1);
                this.fields.splice(this.fields.indexOf('PIAMStatistics.vehicalRegNo'), 1);
            }
        }

    }

    public validate() {
        this.setRiskScreen(RiskType["" + this.valueObj.riskType]);
        if (this.valueObj.PIAMStatistics.vehicalRegNo == undefined || this.valueObj.PIAMStatistics.vehicalRegNo == '')
            this.valueObj.PIAMStatistics.vehicalRegNo = 'NA';

        if (this.valueObj.motorItems.motorItem != undefined && !(this.valueObj.motorItems.motorItem.constructor === Array)) {
            let motorItems: any = this.valueObj.motorItems.motorItem;
            this.valueObj.motorItems.motorItem = [motorItems];
        }
        this.handleCoverNoteCase();
        let result = super.validate();
        if (result.isValid == true) {
            //AL003 START
            if (this.valueObj.registrationNumber != undefined && this.valueObj.registrationNumber != '' && !this.valueObj.registrationNumber.match("^[A-Za-z0-9-/]+$")) {
                result.isValid = false;
                result.message = "Motor (Risk Number: " + this.valueObj.riskNumber + " ): Provide valid Registration Number, Valid chars:A-Z,0-9,/,-";
            } //AL003 END
            else if (this.valueObj.PIAMStatistics.purchasePrice != undefined && this.valueObj.PIAMStatistics.purchasePrice != "" && (this.valueObj.PIAMStatistics.purchaseDate == undefined || this.valueObj.PIAMStatistics.purchaseDate == "")) {
                result.isValid = false;
                result.message = "Motor (Risk Number: " + this.valueObj.riskNumber + " ): Provide Purchase date if Purchase Price is Selected.";
            }
            else if (this.valueObj.PIAMStatistics.previousInsurer != "999" && this.valueObj.PIAMStatistics.previousPolicyNumber == undefined) {
                result.isValid = false;
                result.message = "Motor (Risk Number: " + this.valueObj.riskNumber + " ): Provide Previous Policy Information if Previous Insurere is not the Insured.";
            }
            else if (this.riskScreen == 'S4814') {
                if (this.valueObj.seats == undefined || this.valueObj.seats == "" || this.valueObj.seats <= 0 || this.valueObj.seats > 99) {
                    result.isValid = false;
                    result.message = "Motor (Risk Number: " + this.valueObj.riskNumber + " ): Provide valid value for Seats Information between 1 and 99.";
                }
            }
            else if (isNaN(this.valueObj.yearManufacture)) {
                result.isValid = false;
                result.message = "Motor (Risk Number: " + this.valueObj.riskNumber + " ): Provide valid value for Year Manfacture.";
            }

            if (this.valueObj.motorItems.motorItem != undefined) {
                result = this.validateAdditionalBenefits(result);
            }
        }
        else {
            result.message = "Motor (Risk Number: " + this.valueObj.riskNumber + " ): <p>Provide value for all mandatory fields.</p>" + this.getInvalidFields(result, this.fieldNames);
        }

        if (result.isValid == true && (this.valueObj.riskType == 'MPC' || this.valueObj.riskType == 'MPF' || this.valueObj.riskType == 'MPT' || this.valueObj.riskType == 'MPD')) { //AL001 ADDED MPD
            if (this.valueObj.PIAMStatistics.localOrImport == undefined || this.valueObj.PIAMStatistics.localOrImport == '') {
                result.isValid = false;
                result.message = "Motor (Risk Number: " + this.valueObj.riskNumber + " ): Provide valid value for Local / Import in PIAM Statistics.";
            }
        }
        //GA001 added cover condition
        //if (this.valueObj.cover == "CO" && (this.valueObj.vehicalClass == 'PC' || this.valueObj.vehicalClass == 'PT') && (this.valueObj.riskType != 'MMP')) { //VK006
        if (this.valueObj.cover == "CO" && (this.valueObj.vehicalClass == 'PC' || this.valueObj.vehicalClass == 'PT') && (this.valueObj.riskType != 'MMP' && this.valueObj.riskType != 'MMF')) { //VK006 //MS001
            //if (this.valueObj.riskType == 'MPC' || this.valueObj.riskType == 'MPF' || this.valueObj.riskType == 'MPD') {
            //GA001 end
            // Added M012 validation for M012 for SAF MYS-2018-0737 
            if (BMSConstants.getInsuredType() == "C" && this.valueObj.motorItems.motorItem.filter(mi => mi.code == "M012").length < 1 && this.valueObj.motorItems.motorItem.filter(mi => mi.code == "ANY").length < 1 && this.valueObj.driverDetails && this.valueObj.driverDetails.driverDetail && (this.valueObj.driverDetails.driverDetail.length == 0 || this.valueObj.driverDetails.driverDetail.length > 2)) {
                result.isValid = false;
                result.message = "Motor (Risk Number: " + this.valueObj.riskNumber + " ): At-least one Named Driver must be added and maximum 2 are allowed for the Risk.";
            }
            else if (BMSConstants.getInsuredType() == "P" && this.valueObj.driverDetails && this.valueObj.driverDetails.driverDetail && this.valueObj.driverDetails.driverDetail.length == 0) {
                result.isValid = false;
                result.message = "Motor (Risk Number: " + this.valueObj.riskNumber + " ): At-least one Named Driver must be added.";
            }
            else {
                result = this.validateDriverDetails(result);
            }
        }

        if (result.isValid == true && this.valueObj.blackListIndicator == 'true') {
            result.isValid = false;
            result.message = "Motor (Risk Number: " + this.valueObj.riskNumber + " ): Entered Chassis Number is BlackListed. Refer to Motor UW.";
        }

        if (result.isValid == true && (this.valueObj.vehicalClass != 'AT' && this.valueObj.vehicalClass != 'CT') && BMSConstants.getBMSCaseInfo().businessFunction != 'RenewalRerate') {
            if (this.valueObj.ENCDDetails != undefined && this.valueObj.ENCDDetails.respCode)
                result = this.validateNCDEnquiry(result);
            else {
                result.isValid = false;
                result.message = "Motor (Risk Number: " + this.valueObj.riskNumber + " ): Please call NCD Enquiry (Call ISM button) before proceeding to next level";
            }
        }

        if (result.isValid == true)
            result = this.validateCapacity(result);

        if (result.isValid == true && ["GA", "GC", "AT", "CT"].indexOf(this.valueObj.vehicalClass) != -1 && this.valueObj.tonnage != null && this.valueObj.tonnage != "" && this.valueObj.tommangeIndicator == "S" && parseInt(this.valueObj.tonnage) < 7) {
            result.isValid = false;
            result.message = "Motor (Risk Number: " + this.valueObj.riskNumber + "):<p>Seating value cannot be lesser than 7.</p>"
        }

        if (result.isValid == true && this.valueObj.cover != 'TP') {

            if (this.valueObj.riskType == 'MCY' && (this.valueObj.excessType == "" || this.valueObj.excessType == undefined) && this.valueObj.excessAmount <= 0) {
                result.isValid = false;
                result.message = "Motor Risk type: MCY & (Risk Number: " + this.valueObj.riskNumber + " ): Excess Type & Excess Amount are Mandatory and Excess Amount should be greater than 0.";
            }

            if (this.valueObj.vehicalClass == 'MC' && this.valueObj.cover == 'CO' && this.valueObj.excessType != '' && this.valueObj.excessAmount <= 0) {
                result.isValid = false;
                result.message = "Motor (Risk Number: " + this.valueObj.riskNumber + " ): Excess Amount is Mandatory and should be greater than 0.";
            }

            if (this.valueObj.excessAmount <= 0 && this.valueObj.excessType != '') {
                result.isValid = false;
                result.message = "Motor (Risk Number: " + this.valueObj.riskNumber + " ): Excess Amount is Mandatory when Excess Type is Selected.";
            }

            if (this.valueObj.excessAmount > 0 && (this.valueObj.excessType == '' || this.valueObj.excessType == undefined)) {
                result.isValid = false;
                result.message = "Motor (Risk Number: " + this.valueObj.riskNumber + " ): Excess Type is Mandatory when Excess Amount greater than 0.";
            }
        }

        if (result.isValid == true && (this.valueObj.riskType == 'CV' || this.valueObj.riskType == 'CVT' || this.valueObj.riskType == 'CVF' || this.valueObj.riskType == 'HVC' || this.valueObj.riskType == 'HVT' || this.valueObj.riskType == 'HVF'))
            result = this.validateTrailerDetails(result);

        // SR001 Change Starts - Added VPMS check - if yes skip validation
        if (result.isValid == true && (this.valueObj.riskType == 'MTC' || this.valueObj.riskType == 'MTT' || this.valueObj.riskType == 'MTF' || this.valueObj.riskType == 'HVC' || this.valueObj.riskType == 'HVT' || this.valueObj.riskType == 'HVF')
            && this.valueObj.isVPMS == "N") {
            //AL002 START
			/*
			if(this.valueObj.riskOccupationCode == undefined || this.valueObj.riskOccupationCode == '') {
				result.isValid = false;
				result.message = "Motor (Risk Number: "+this.valueObj.riskNumber+" ): Provide valid value Risk Occupation Code.";
			}
			*/
            //AL002 END
            //E1005
            let tempTotPremium = numeral(numeral(numeral(numeral(numeral(numeral(numeral(this.valueObj.totalPremium).format('0.00')).add(-numeral(this.valueObj.gstAmount).format('0.00'))).format('0.00')).add(-numeral(this.valueObj.rebateAmount).format('0.00'))).format('0.00')).add(-numeral(this.valueObj.sstAmount).format('0.00'))).format('0.00');
            //E1005	
            let actTot = numeral(numeral(numeral(this.valueObj.ACT).format('0.00')).value() + numeral(numeral(this.valueObj.OWD).format('0.00')).value() + numeral(numeral(this.valueObj.thirdParty).format('0.00')).value()).format('0.00');

            if (numeral(tempTotPremium).format("0.00") != numeral(actTot).format('0.00')) {
                result.isValid = false;
                result.message = "Motor (Risk Number: " + this.valueObj.riskNumber + " ): Sum of ACT, OWD and ThirdParty is not equal to Total Premium (GST, Rebate Excluded).";
            }
        }

        if (result.isValid == true && this.valueObj.cover != 'TP' && !(this.valueObj.totalSumInsured > 0)) {
            result.isValid = false;
            result.message = "Motor (Risk Number: " + this.valueObj.riskNumber + " ): Enter valid value for Total Sum Insured.";
        }

        if (result.isValid == true)
            result = this.validateFinancialInterest(result);

        if (result.isValid == true) {
            if (this.valueObj.ratingFlag == "A" && this.valueObj.premiumInfoFlag == "N" && this.valueObj.isVPMS == "Y") {
                result.isValid = false;
                result.message = "Motor (Risk Number: " + this.valueObj.riskNumber + " ): Get premium calculation before proceeding, by clicking 'Get Quotation' button in Premium Calculation Info section.";
            }
        }

        //Added below condition for SAF MYS-2019-0490 -- start
        let headerInfo = BMSConstants.getBMSHeaderInfo();
        if ( headerInfo != undefined && headerInfo.isVPMS == "Y" && headerInfo.VPMSProduct == "Y" && headerInfo.bizAcceptanceDate < headerInfo.bizReceivedDate ) {
            result.isValid = false;
            result.message = "Quotation Date is less than the Assessment Date. Please click on GetQuotation button and proceed.";
        }//End
        if (result.isValid == true)
            this.validateTrailerSI(result);
		//VK004 General Page Text

		if(Number(this.valueObj.gpTextCount) > Number(BMSConstants.getBMSHeaderInfo().gpTextMaxLines)) {
			result.isValid = false;
			result.message = this.valueObj.riskType + "(Risk Number: "+this.valueObj.riskNumber+" ): General Page Text entered is more than 400 lines.";
		}
        return result;
    }

    validateAdditionalBenefits(result) {
        let businessObject = BMSConstants.getNewBusinessInfo();
        for (let mi of this.valueObj.motorItems.motorItem) {
            if ((mi.noOfAdditionalClaims != "" && mi.noOfAdditionalClaims != undefined) && numeral(mi.noOfAdditionalClaims) > 99) {
                result.isValid = false;
                result.message = "Motor (AdditionalBenefit Code : " + mi.code + " ): No of AdditionalClaims should not be greater than 99";
            }
            if (mi.code == 'E101' || mi.code == 'E102') {
                if (mi.isSpecial == "Y" && AppUtil.isEmpty([mi.dateFromAdditionalBenfit, mi.dateToAdditionalBenfit], true) == true) {
                    result.isValid = false;
                    result.message = "Motor (AdditionalBenefit Code : " + mi.code + " ):From and To Date can not be empty.";
                }
            }
            if ((mi.dateFromAdditionalBenfit != null || mi.dateFromAdditionalBenfit != "") && (mi.dateToAdditionalBenfit != null || mi.dateToAdditionalBenfit != "") &&
                (moment(mi.dateFromAdditionalBenfit, "YYYY-MM-DD") > moment(mi.dateToAdditionalBenfit, "YYYY-MM-DD"))) {
                result.isValid = false;
                result.message = "Motor (AdditionalBenefit Code : " + mi.code + " ):To Date can not be smaller than From Date.";
            }
            // SR004 - Added the below condition for checking the 
            if (mi.code == 'M003' && businessObject.clientDetails.client.genericDetails.clienttype == 'C') {
                result.isValid = false;
                result.message = "Motor (AdditionalBenefit Code : " + mi.code + " ): cannot be added for Corporate Clients";
        }
            // KA002- START MYS-2019-0924 Need to block prompt alert message on adding E111 benefit if ncd percent = 0; START
            if (businessObject.risks.motorMPV) {
                if (mi.code == "E111" && (numeral(this.valueObj.ENCDDetails.nextNcdPercent).format('0') == '0' || this.valueObj.ENCDDetails.nextNcdPercent == undefined) && ['PC', 'PT', 'PF'].indexOf(this.valueObj.vehicalClass) != -1) {
                    result.isValid = false;
                    result.message = "Additional Benefit E111 cannot be added if NCD percentage is 0%";
                }
            }  //KA002- END
        }
        return result;
    }
    getTotalByProperty(prop, ary) {
        let total = numeral(0);
        for (let eachItem of ary) {
            if (eachItem[prop] != null && eachItem[prop] != "")
                total = total.add(numeral().unformat(eachItem[prop]));
        }
        total = numeral(total).format('0.00');
        return total;
    }

    validateNCDEnquiry(result) {
        if (this.valueObj.ENCDDetails != undefined && (this.valueObj.ENCDDetails.respCode == 'ENQ094' || this.valueObj.ENCDDetails.respCode == 'ENQ095')) {
            result.isValid = false;
            result.message = "Motor (Risk Number: " + this.valueObj.riskNumber + " ): Please Contact Motor UW - Verified MAFR.";
        }
        return result;
    }

    validatePremiumInfoInput() {
        this.requiredFields = ["cover",
            "makeCode",
            "makeModel",
            "vehicalSumInsured",
            "EW",
            "vehicalClass",
            "yearManufacture",
            "use",
            "GSTDetails.riskLocation",
            "GSTDetails.placeOfRecidence"
        ];
        let fieldNames: any = {
            cover: "Coverage",
            CFY: "Claim Free Year",
            makeCode: "Make",
            makeModel: "Model",
            vehicalSumInsured: "Vehicle Sum Insured",
            EW: "Place of Use / Origin",
            vehicalClass: "Vehicle Class",
            yearManufacture: "Year of Manufacture",
            use: "Use of Vehicle",
            "GSTDetails.riskLocation": "GST: Risk Location",
            "GSTDetails.placeOfRecidence": "GST: Place Of Residence",
            tonnage: "Tonnage / Seating"
        };
        let result = super.validate();
        if (result.isValid == true) {
            if (["PC", "PT", "MC", "HC", "CD", "TX"].indexOf(this.valueObj.vehicalClass) != -1) {
                this.requiredFields.push("capacityValue");
            }
            else if (["GA", "GC", "AT", "CT", "BE", "BP", "BS", "BU"].indexOf(this.valueObj.vehicalClass) != -1) {
                this.requiredFields.push("tonnage");
            }
            else if (this.riskScreen == 'S4814' && ["BU", "BS", "BP", "BE", "BC"].indexOf(this.valueObj.vehicalClass) != -1) { //SR002
                this.requiredFields.push("seats");
            }
            result = super.validate();
            if (result.isValid == false)
                result.message = "Enter proper value in mandatory fields." + this.getInvalidFields(result, fieldNames);
            else if (result.isValid == true && ["BE", "BP", "BS", "BU", "BC"].indexOf(this.valueObj.vehicalClass) != -1 && this.valueObj.tonnage != null && this.valueObj.tonnage != "" && this.valueObj.tommangeIndicator == "S" && parseInt(this.valueObj.tonnage) < 6) { //SR002
                result.isValid = false;
                result.message = "Seating value cannot be lesser than 6." //SR002 
            } else if (result.isValid == true && ["HC", "CD"].indexOf(this.valueObj.vehicalClass) != -1 && this.valueObj.tonnage != null && this.valueObj.tonnage != "" && this.valueObj.tommangeIndicator == "S" && parseInt(this.valueObj.tonnage) < 2) { //SR003
                result.isValid = false;
                result.message = "Seating value cannot be lesser than 2." //SR003 
            }
            if ((this.valueObj.ENCDDetails == null || this.valueObj.ENCDDetails == "") && this.valueObj.vehicalClass != 'AT' && this.valueObj.vehicalClass != 'CT') {
                result.isValid = false;
                result.message = result.message + "<p>" + "Enquire NCD before requesting premium calculation info." + "</p>";
            }

            return result;
        }
        else {
            result.message = "Enter proper value in mandatory fields." + this.getInvalidFields(result, fieldNames);
            return result;
        }
    }

    validateDriverDetails(result) {

        if (this.valueObj.driverDetails != null) {

            if (this.valueObj.driverDetails.driverDetail != undefined && !(this.valueObj.driverDetails.driverDetail.constructor === Array)) {
                let driverItems: any = this.valueObj.driverDetails.driverDetail;
                this.valueObj.driverDetails.driverDetail = [driverItems];
            }

            if (this.valueObj.driverDetails.driverDetail.length > 0) {
                for (let driver of this.valueObj.driverDetails.driverDetail) {
                    result.fields.push("driverDetails");
                    let driverValid = new NamedDriverValidator(driver).validate();
                    if (driverValid.isValid == false) {
                        result.isValid = false;
                    }
                    result.message = result.message + driverValid.message;
                    result.childsResult["driverDetails"] = driverValid;
                    result.validationResult["driverDetails"] = driverValid.isValid;
                }
            }
        }
        return result;
    }

    validateFinancialInterest(result) {
        if (this.valueObj.FI == "Y" && this.valueObj.financialInterest != null && this.valueObj.financialInterest != "") {

            if (this.valueObj.financialInterest.financialInterestList != undefined && !(this.valueObj.financialInterest.financialInterestList.constructor === Array)) {
                let financialInterestItems: any = this.valueObj.financialInterest.financialInterestList;
                this.valueObj.financialInterest.financialInterestList = [financialInterestItems];
            }

            if (this.valueObj.financialInterest.financialInterestList.length > 0) {
                for (let fiItem of this.valueObj.financialInterest.financialInterestList) {

                    result.fields.push("fiDetails");
                    let fiTemValid = new FinancialInterestValidator(fiItem).validate();
                    if (fiTemValid.isValid == false) {
                        result.isValid = false;
                    }
                    result.message = result.message + fiTemValid.message;
                    result.childsResult["fiDetails"] = fiTemValid;
                    result.validationResult["fiDetails"] = fiTemValid.isValid;
                }
            }
            else {
                result.isValid = false;
                result.message = "Motor (Risk Number: " + this.valueObj.riskNumber + " ): Atleast one Financial Interest Item must be added for the Risk.";
            }
        }
        return result;
    }

    checkBenefitCode(ary) {
        if (ary) {
            for (let eachMotorItem of ary) {
                if (eachMotorItem.code == "ANY") {
                    return true;
                }
            }
        }
        return false;
    }

    validateTrailerDetails(result) {
        if ((this.valueObj.vehicalClass == 'GC' || this.valueObj.vehicalClass == 'GA')) {
            if (this.valueObj.trailerDetails && this.valueObj.trailerDetails.trailerNo) {
                if (!this.valueObj.trailerDetails.chassesNo) {
                    result.isValid = false;
                    result.message = "Motor (Risk Number: " + this.valueObj.riskNumber + " ): Enter Chassis Number for trailer.";
                }
                else if (!this.valueObj.trailerDetails.makeCode) {
                    result.isValid = false;
                    result.message = "Motor (Risk Number: " + this.valueObj.riskNumber + " ): Enter Make Code for trailer.";
                }
                else if (!this.valueObj.trailerDetails.makeModel) {
                    result.isValid = false;
                    result.message = "Motor (Risk Number: " + this.valueObj.riskNumber + " ): Enter Model Code for trailer.";
                }
                else if (!this.valueObj.trailerDetails.makeCodeDescription) {
                    result.isValid = false;
                    result.message = "Motor (Risk Number: " + this.valueObj.riskNumber + " ): Enter Make Model Description for trailer.";
                }
                else if (!this.valueObj.trailerDetails.yearOfMake) {
                    result.isValid = false;
                    result.message = "Motor (Risk Number: " + this.valueObj.riskNumber + " ): Enter Year of Manfacture for trailer.";
                }
            }
        }
        return result;
    }

    validateTrailerSI(result) {
        if (this.valueObj.cover != 'TP' && this.valueObj.trailerDetails && this.valueObj.trailerDetails.trailerNo != '' && this.valueObj.trailerDetails.trailerNo != undefined) {
            if (['HVC', 'HVF', 'HVT', 'CV', 'CVF', 'CVT'].indexOf(this.valueObj.riskType) != -1 && ['GA', 'GC', 'AT', 'CT'].indexOf(this.valueObj.vehicalClass) != -1) {
                if (AppUtil.isEmpty([this.valueObj.trailerSumInsured, this.valueObj.trailerPremium], true) == true || parseInt(this.valueObj.trailerSumInsured) <= 0 || (this.valueObj.isVPMS == "N" && parseInt(this.valueObj.trailerPremium) <= 0)) {
                    result.isValid = false;
                    result.message = "Motor (Risk Number: " + this.valueObj.riskNumber + " ): Enter 'Trailer Sum Insured', 'Trailer Premium' greater than zero.";
                }

            }
        }
    }

    validateCapacity(result) {
        if (["CV", "CVT", "CVF", "HVC", "HVT", "HVF", "MTC", "MTT", "MTF"].indexOf(this.valueObj.riskType) != -1) {
            if (["HC", "CD", "TX"].indexOf(this.valueObj.vehicalClass) != -1) {
                if (!(this.valueObj.capacityValue != undefined && this.valueObj.capacityValue != '')) {
                    result.isValid = false;
                    result.message = "Motor (Risk Number: " + this.valueObj.riskNumber + " ): Provide valid value for Cubic Capacity in Vehicle Information.";
                }
            } else if (["GA", "GC", "AT", "CT", "BP", "BS", "BU", "BE"].indexOf(this.valueObj.vehicalClass) != -1) {
                if (!(this.valueObj.tommangeIndicator != undefined && this.valueObj.tommangeIndicator != '')) {
                    result.isValid = false;
                    result.message = "Motor (Risk Number: " + this.valueObj.riskNumber + " ): Provide valid value for Tonnage Indicator in Vehicle Information.";
                }
                if (!(this.valueObj.tonnage != undefined && this.valueObj.tonnage != '')) {
                    result.isValid = false;
                    result.message = "Motor (Risk Number: " + this.valueObj.riskNumber + " ): Provide valid value for Tonnage in Vehicle Information.";
                }
            }
        } else {
            if (this.riskScreen == 'S4814') {
                if (!(this.valueObj.capacityValue != undefined && this.valueObj.capacityValue != '')) {
                    result.isValid = false;
                    result.message = "Motor (Risk Number: " + this.valueObj.riskNumber + " ): Provide valid value for Cubic Capacity in Vehicle Information.";
                }
            } else {
                if (!(this.valueObj.capacityValue != undefined && this.valueObj.capacityValue != '')) {
                    result.isValid = false;
                    result.message = "Motor (Risk Number: " + this.valueObj.riskNumber + " ): Provide valid value for Cubic Capacity in Vehicle Information.";
                }
                if (!(this.valueObj.tommangeIndicator != undefined && this.valueObj.tommangeIndicator != '')) {
                    result.isValid = false;
                    result.message = "Motor (Risk Number: " + this.valueObj.riskNumber + " ): Provide valid value for Tonnage Indicator in Vehicle Information.";
                }
                if (!(this.valueObj.tonnage != undefined && this.valueObj.tonnage != '')) {
                    result.isValid = false;
                    result.message = "Motor (Risk Number: " + this.valueObj.riskNumber + " ): Provide valid value for Tonnage in Vehicle Information.";
                }
            }
        }
        return result;
    }

    setRiskScreen(riskType: RiskType) {
        switch (riskType) {
            case RiskType.MCF:
            case RiskType.MCT:
            case RiskType.MCY:
            case RiskType.MPC:
            case RiskType.MMP://VK006 ADDED MMP
            case RiskType.MMF://MS001 ADDED MMF
            case RiskType.MPD://AL001 ADDED MPD
            case RiskType.MPF:
            case RiskType.MPT:
                this.riskScreen = "S4814";
                break;
            case RiskType.CV:
            case RiskType.CVF:
            case RiskType.CVT:
            case RiskType.HVC:
            case RiskType.HVF:
            case RiskType.HVT:
            case RiskType.MTC:
            case RiskType.MTF:
            case RiskType.MTT:
                this.riskScreen = "S6240";
        }
    }
}