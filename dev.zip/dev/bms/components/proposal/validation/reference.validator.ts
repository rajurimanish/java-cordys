import { Validator, ValidationResult } from '../../../../common/components/validator/validator';
import { Reference, ReferenceDetails } from '../proposalheader/appobjects/proposalheader';

export class ReferenceValidator extends Validator {
    public fields: Array<any> = ["title",
        "referenceNumber"
    ];
    constructor(driverObj: ReferenceDetails) {
        super();
        this.valueObj = driverObj;
        this.requiredFields = this.fields;
    }

    public validate() {
        let result = super.validate();
        if (result.isValid == true) {
            if (this.valueObj.title == 'Broker') {
                if (this.valueObj.referenceNumber.length > 24) {
                    result.isValid = false;
                    result.message = "Please provide Broker Reference Number with length less than 24 as input";
                }
            }
            else if (this.valueObj.title == 'Ceding') {
                if (this.valueObj.referenceNumber.length > 25) {
                    result.isValid = false;
                    result.message = "Please provide Ceding Reference Number with length less than 25 as input";
                }
                if (!this.valueObj.referenceType) {
                    result.isValid = false;
                    result.message = "Please provide Ceding Co Reference Type";
                }
            }
            else if (this.valueObj.title == 'Cover') {
                if (this.valueObj.referenceNumber.length > 8) {
                    result.isValid = false;
                    result.message = "Please provide Cover Note Reference Number with length less than 8 as input";
                }
                if (!(this.valueObj.issueDate && this.valueObj.receivedDate)) {
                    result.isValid = false;
                    result.message = "Please provide Cover Note Issue Date and Received Date";
                }
            }
            else if (this.valueObj.title == 'Reference') {
                if (this.valueObj.referenceNumber.length > 10) {
                    result.isValid = false;
                    result.message = "Please provide Reference Number with length less than 10 as input";
                }
                if (!this.valueObj.referenceType) {
                    result.isValid = false;
                    result.message = "Please provide Reference Type";
                }
            }
        }
        else {
            result.message = "Please provide value for all Reference fields.";
        }

        return result;
    }

}