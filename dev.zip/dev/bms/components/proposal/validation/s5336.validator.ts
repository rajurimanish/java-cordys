/**
 * Change History	:

	No      Date          Description                                                       Changed By
	====    ==========    ===========                                                        ==========
 *  MD001   19/03/2018    UAT issue raised during SAF MYS-2017-0920                             MKU1
                          for FPB family plan, premium is only applied to the 1st insured
						  i.e. premium is not applicable for spouse & child(ren)  
    
    MD002   03/04/2018    MYS-2018-0130 - Occupation Code to be Read 
                           from T9109 - for All Personal Lines Products                         MKU1
*   GA001   19/10/2018   MYS-2018-1291 : Incorrect rounding of 
*                      Total share percentage of Nominee Details	                             KGA                           	                                               
 */
import { Validator, ValidationResult } from '../../../../common/components/validator/validator';
import { S5336ItemDetails } from '../newbusinessrisks/s5335/appobjects/s5335';
import { NomineeValidator } from './nominee.validator';

declare var numeral: any;//GA001

export class S5336Validator extends Validator {
    public fields: Array<any> = [];

    public namedFields: Array<any> = ["insuredPerson",
        "insuredOccCode",// MD002: Changed occupationCode to insuredOccCode
        "insuredOccDescription",// MD002: Changed occupationDescription to insuredOccDescription
        "ratingClass",
        "dateOfBirth",
        "gender",
        "plan",
        "maritalStatus",
        "basicPremium",
        "totalAnnualPremium",
        "sumInsured"];
    public namedFieldNames: any = {
        insuredPerson: "Insured Person Name",
        insuredOccCode: "Occupation Code",// MD002: Changed occupationCode to insuredOccCode
        insuredOccDescription: "Occupation Description",// MD002: Changed occupationDescription to insuredOccDescription
        ratingClass: "Occupation Class",
        dateOfBirth: "Date of Birth",
        gender: "Gender",
        maritalStatus: "Marital Status",
        plan: "Plan",
        basicPremium: "Basic Premium",
        totalAnnualPremium: "Total Annual Premium",
        sumInsured: "Sum Insured"
    };
    public driverDetailsFields: Array<any> = [
        "vehicalRegNumber",
        "makeCode",
        "modelCode",
        "yearOfMake"
    ];
    public driverDetailsFieldLabels: any = {
        vehicalRegNumber: "Vehicle Registration Number",
        makeCode: "Make Code",
        modelCode: "Model Code",
        yearOfMake: "Year of Manufacture"
    }
    constructor(s5336Item: S5336ItemDetails) {
        super();
        this.valueObj = s5336Item;
        this.requiredFields = this.fields;
    }

    public validate() {
        //need to validate Old IC/Passport No and NRIC separately
        let result = super.validate();
        result.message = "<p style='padding-left: 25px'>Insured : " + this.valueObj.itemNo + " : Missing fields are,";

        if (this.valueObj.basis != "NAMED") {
            if (this.valueObj.noOfPerson <= 0) {
                result.isValid = false;
                result.message = result.message + "<br/>- # Of Persons should be greater than 0(zero) for BASIS=UNNAMED";
            }
            if (this.valueObj.insuredPerson.trim() == "") {
                result.isValid = false;
                result.message = result.message + "<br/>- Insured Person Name";
            }
            if (this.valueObj.insuredOccCode.trim() == "") {// MD002: Changed occupationCode to insuredOccCode
                result.isValid = false;
                result.message = result.message + "<br/>- Occupation Code";
            }
            if (this.valueObj.insuredOccDescription.trim() == "") {// MD002: Changed occupationDescription to insuredOccDescription
                result.isValid = false;
                result.message = result.message + "<br/>- Occupation Description";
            }
            if (this.valueObj.ratingClass.trim() == "") {
                result.isValid = false;
                result.message = result.message + "<br/>- Rating Class";
            }
            if (!this.valueObj.plan) {
                result.isValid = false;
                result.message = result.message + "<br/>- Plan";
            }
            if (this.valueObj.basicPremium < 0) {
                result.isValid = false;
                result.message = result.message + "<br/>- Basic Premium cannot be less than zero.";
            }

        } else {
            //if(result.isValid == false) {
            //result.message = result.message + this.getInvalidFieldMessages(result,this.namedFieldNames,this.namedFields);
            //}	  

            if (this.valueObj.insuredPerson == undefined || this.valueObj.insuredPerson == "") {
                result.isValid = false;
                result.message = result.message + "<br/>- Insured Person Name";
            }
            if (this.valueObj.insuredOccCode == undefined || this.valueObj.insuredOccCode == "") {// MD002: Changed occupationCode to insuredOccCode
                result.isValid = false;
                result.message = result.message + "<br/>- Occupation Code";
            }
            if (this.valueObj.insuredOccDescription == undefined || this.valueObj.insuredOccDescription == "") {// MD002: Changed occupationDescription to insuredOccDescription
                result.isValid = false;
                result.message = result.message + "<br/>- Occupation Description";
            }
            if (this.valueObj.dateOfBirth == undefined || this.valueObj.dateOfBirth == "") {
                result.isValid = false;
                result.message = result.message + "<br/>- Date of Birth";
            }
            if (this.valueObj.ratingClass.trim() == "") {
                result.isValid = false;
                result.message = result.message + "<br/>- Rating Class";
            }
            if (this.valueObj.gender == undefined || this.valueObj.gender == "") {
                result.isValid = false;
                result.message = result.message + "<br/>- Gender";
            }
            if (this.valueObj.maritalStatus == undefined || this.valueObj.maritalStatus == "") {
                result.isValid = false;
                result.message = result.message + "<br/>- Marital Status";
            }
            if (this.valueObj.plan == undefined || this.valueObj.plan == "") {
                result.isValid = false;
                result.message = result.message + "<br/>- Plan";
            }
            if (this.valueObj.basicPremium == undefined || this.valueObj.basicPremium == "") {
                result.isValid = false;
                result.message = result.message + "<br/>- Basic Premium. Select Plan (for Brochure plans) or provide benefit details (for Non-Brochure plans)";
            }
            if (this.valueObj.basicPremium && this.valueObj.basicPremium < 0) {
                result.isValid = false;
                result.message = result.message + "<br/>- Basic Premium cannot be less than zero.";
            }
            if (this.valueObj.totalAnnualPremium == undefined || this.valueObj.totalAnnualPremium == "") {
                result.isValid = false;
                result.message = result.message + "<br/>- Total Annual Premium. Select Plan (for Brochure plans) or provide benefit details (for Non-Brochure plans)";
            } else if (this.valueObj.totalAnnualPremium.length > 14) {
                result.isValid = false;
                result.message = result.message + "<br/>- Total Annual Premium is very high. More than 11 digits.";
            }
            else if (!(this.valueObj.riskType == 'FPB' && this.valueObj.itemNo > 1 && this.valueObj.planDescription.indexOf('FAMILY') != -1) && this.valueObj.totalAnnualPremium <= 0) { //MD001
                result.isValid = false;
                result.message = result.message + "<br/>- Total Annual Premium cannot be less than 0";
            }
            if (this.valueObj.sumInsured == undefined || this.valueObj.sumInsured == "") {
                result.isValid = false;
                result.message = result.message + "<br/>- Sum Insured";
            }


            if ((this.valueObj.NRIC == undefined || this.valueObj.NRIC == "") && (this.valueObj.IdProofNo == undefined || this.valueObj.IdProofNo == "")) {
                result.isValid = false;
                result.message = result.message + "<br/>- Old IC/Passport or NRIC (one of them is mandatory)";
            }
        }
        if (this.valueObj.totalPremium && this.valueObj.totalPremium.length > 14) {
            result.isValid = false;
            result.message = result.message + "<br/>- Total Premium exceeding 14 digit.";
        }

        if ((this.valueObj.riskType == "MSW" || this.valueObj.riskType == "MWP" || this.valueObj.riskType == "MWH") && this.valueObj.plan) {
            if (this.valueObj.seatNo <= 0) {
                result.isValid = false;
                result.message = result.message + "<br/>- Seats(Coverage Information section) is a required field.";
            }
        }

        if (this.valueObj.nomineeDetails)
            result = this.validateNomioneeDetails(result);
        if (this.valueObj.riskType == "MSW" || this.valueObj.riskType == "MWP" || this.valueObj.riskType == "MWH") {
            //validate vehicle information.
            result.message = result.message + this.getMissingFields(result, this.driverDetailsFieldLabels, this.driverDetailsFields, this.valueObj.PADriverDetails);
        }
        //Age Validation related code changes.
        if (this.valueObj.ageLimitFlag != undefined && this.valueObj.ageLimitFlag != "" && 'L' == this.valueObj.ageLimitFlag) {
            result.isValid = false;
            result.message = "<br>Insured " + this.valueObj.itemNo + " age is less than minimum age.";
            result.isChildValid = true;
        }//End
        result.message = result.message + "</p>";
        return result;
    }

    validateNomioneeDetails(result) {
        if (this.valueObj.nomineeDetails != null) {

            if (this.valueObj.nomineeDetails.nominee != undefined && !(this.valueObj.nomineeDetails.nominee.constructor === Array)) {
                let nomineeItems: any = this.valueObj.nomineeDetails.nominee;
                this.valueObj.nomineeDetails.nominee = [nomineeItems];
            }

            if (this.valueObj.nomineeDetails.nominee.length > 0) {
                let percentageTotal: number = 0;
                for (let nominee of this.valueObj.nomineeDetails.nominee) {

                    result.fields.push("nomineeDetails");
                    let nomineeValid = new NomineeValidator(nominee).validate();
                    if (nomineeValid.isValid == false) {
                        result.isValid = false;
                        result.message = result.message + nomineeValid.message;
                        result.childsResult["nomineeDetails"] = nomineeValid;
                        result.validationResult["nomineeDetails"] = nomineeValid.isValid;
                        return result;
                    }
                    else {
                        //GA001 START
                        //percentageTotal = Number(percentageTotal) + Number(nominee.percentageOfShare);
                        percentageTotal = numeral(percentageTotal).add(parseFloat(nominee.percentageOfShare)).value();
                        //GA001 END
                    }
                }
                if (percentageTotal != 100) {
                    let nomineeDetails: ValidationResult = new ValidationResult();
                    nomineeDetails.isValid = false;
                    result.isValid = false;
                    nomineeDetails.message = "Nominee Percentage Share Total is not equal to 100. Please make sure the total is equal to 100";
                    result.message = result.message + nomineeDetails.message;
                    result.childsResult["nomineeDetails"] = nomineeDetails;
                    result.validationResult["nomineeDetails"] = nomineeDetails.isValid;
                    return result;
                }
            }
        }
        return result;
    }
    getInvalidFieldMessages(valResult: ValidationResult, fieldNames, fields) {
        //let fields = Object.keys(valResult.validationResult);
        let missedFields = "";
        let count = 1;
        for (let fld of fields) {
            if (valResult.validationResult[fld] == false) {
                valResult.isValid = false;
                if (fieldNames[fld] == null) {
                    missedFields = missedFields + "<br/>- " + fld;
                }
                else {
                    missedFields = missedFields + "<br/>- " + fieldNames[fld];
                }
                count++;
            }
        }
        return missedFields;
    }
    getMissingFields(result, vFieldNames, vFields, data) {
        //let fields = Object.keys(valResult.validationResult);
        let missedFields = " ";
        let count = 1;
        for (let fld of vFields) {
            if (data[fld] == undefined || data[fld] == "") {
                result.isValid = false;
                if (vFieldNames[fld] == null) {
                    missedFields = missedFields + "<br/>- " + fld;
                }
                else {
                    missedFields = missedFields + "<br/>- " + vFieldNames[fld];
                }
                count++;
            }
        }
        return missedFields;
    }
}