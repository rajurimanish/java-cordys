/*
 * Change History:
 * 
 * No      Date          Description                                   Changed By
 * ====    ==========    ===========                                   ==========
 * GA001   19/10/2018   MYS-2018-1291 : Incorrect rounding of 
 *                      Total share percentage of Nominee Details	  KGA
*/
import { Validator, ValidationResult } from '../../../../common/components/validator/validator';
import { IndividualPersonalAccident } from '../newbusinessrisks/pa/appobjects/pa';
import { NomineeValidator } from './nominee.validator';
import { GSTDetilsValidator } from './gstdetails.validator';
import { BMSConstants } from '../../common/constants/bms_constants';
import { AppUtil } from '../../../../common/components/utility/apputil/app.util';

declare var moment: any;
declare var numeral: any;//GA001

export class NPAValidator extends Validator {
    public fields: Array<any> = ["basicPremium",
        "totalPremium",
        "riskType",
        "occupationCode",
        "occupationDescription",
        "RIRetentionCode",
        "ratingClass",
        "plan",
        "insuredPersonDetails.insuredPersonType.name",
        "insuredPersonDetails.insuredPersonType.DOB",
        "insuredPersonDetails.insuredPersonType.gender"];
    public fieldNames: any = {
        basicPremium: "Basic Premium",
        totalPremium: "Total Premium",
        capitalSumInsured: "Capital Sum Insured",
        riskType: "Risk Type",
        occupationCode: "Occupation",
        occupationDescription: "Occupation Description",
        RIRetentionCode: "RI Retention Code",
        plan: "Plan",
        "insuredPersonDetails.insuredPersonType.name": "Insured Name",
        "insuredPersonDetails.insuredPersonType.DOB": "Insured DOB",
        "insuredPersonDetails.insuredPersonType.gender": "Gender"
    };

    constructor(paObj: IndividualPersonalAccident) {
        super();
        this.valueObj = paObj;
        this.requiredFields = this.fields;
    }

    public validate() {

        this.setMandatoryFields();
        let result = super.validate();
        let validHeaderMandatoryFields: boolean = true;
        if (result.isValid == false) {
            validHeaderMandatoryFields = false;
            result.message = this.valueObj.riskType + " (Risk Number: " + this.valueObj.riskNumber + " ): <p>Provide value for all mandatory fields.</p>" + this.getInvalidFields(result, this.fieldNames);
        }

        if ((this.valueObj.insuredPersonDetails.insuredPersonType.ICPassport == undefined || this.valueObj.insuredPersonDetails.insuredPersonType.ICPassport == "") &&
            (this.valueObj.insuredPersonDetails.insuredPersonType.nric == undefined || this.valueObj.insuredPersonDetails.insuredPersonType.nric == "")) {
            result.isValid = false;
            // if(result.message == null || result.message == ""){
            // result.message = this.valueObj.riskType+" (Risk Number: "+this.valueObj.riskNumber+" ): <p>Provide value for all mandatory fields.</p>";
            // }
            result.message = result.message + "<br>Provide either of NRIC or old IC / Passport No.";
        }

        if (!(this.valueObj.insuredPersonDetails.insuredPersonType.ICPassport == undefined || this.valueObj.insuredPersonDetails.insuredPersonType.ICPassport == "") && this.valueObj.insuredPersonDetails.insuredPersonType.ICPassport.length < 4) {
            result.isValid = false;
            result.message = result.message + "<br>Provide valid Old IC/Passport number.";
        }

        if (!(this.valueObj.insuredPersonDetails.insuredPersonType.nric == undefined || this.valueObj.insuredPersonDetails.insuredPersonType.nric == "")) {
            let _nric = this.valueObj.insuredPersonDetails.insuredPersonType.nric;
            if (!(_nric.match(/^\d{6}\-\d{2}\-\d{4}/g))) {
                result.isValid = false;
                result.message = result.message + "<br>Provide valid NRIC number in XXXXXX-XX-XXXX format.";
            }
        }

        if ((this.valueObj.riskType == 'OSI' || this.valueObj.riskType == 'OSS' || this.valueObj.riskType == 'PAX') && this.valueObj.insuredPersonDetails.insuredPersonType.DOB) {
            let _date = this.valueObj.insuredPersonDetails.insuredPersonType.DOB;
            if (_date == '99999999' || _date == '') {
                result.isValid = false;
                result.message = result.message + "<br>Insured Age is invalid.";
            }
			/* else {
				// let curDate = moment(new Date().toISOString(), "YYYY-MM-DD");
				let _effectiveDate = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.effectiveDate;
				_effectiveDate = moment(_effectiveDate, "YYYY-MM-DD");
				_date = moment(_date,"YYYYMMDD").format("YYYY-MM-DD");
				// let insuredAge = curDate.diff(_date, 'year');
				
				let diffDuration = moment.duration(_effectiveDate.diff(_date));
				let _years = diffDuration.years();
				let _months = diffDuration.months();
				let _days = diffDuration.days();
				
				// if(this.valueObj.riskType!='PAX' && !(insuredAge > 15 && insuredAge < 56)){
				if( this.valueObj.riskType!='PAX' && !(_years > 15 && (_years < 55 || (_years == 55 && _months==0 && _days==0) ) ) ){
					result.isValid = false;
					result.message = result.message + "<br>Insured Age is not between 16 and 55 limit.";
				}
				else if(this.valueObj.riskType=='PAX' && !(_years > 5 && (_years < 70 || (_years == 70 && _months ==0 && _days ==0) ) ) && this.valueObj.riskClassification != "Referred"){
					result.isValid = false;
					result.message = result.message + "<br>Must be Referred risk.";
				} 
			} */ // commented above else part, since its handled in Age Validation SAF reading from T7253 table.
        }

        if (this.valueObj.nomineeDetails)
            result = this.validateNomioneeDetails(result);

        if (this.valueObj.riskType != 'NPA' && this.valueObj.riskType != 'OSI' && this.valueObj.riskType != 'OSS') {
            let gstDetailsResult = new GSTDetilsValidator(this.valueObj).validate();
            if (gstDetailsResult.isValid == false) {
                result.isValid = false;
                result.message = result.message + gstDetailsResult.message;
            }
        }

        if (this.valueObj.riskType == 'OSI' || this.valueObj.riskType == 'OSS') {
            let overseasEducationDetailsResult = this.validateOverseasEductnDetails(result);
            if (overseasEducationDetailsResult.isValid == false) {
                result.isValid = false;
                result.message = result.message + overseasEducationDetailsResult.message;
            }
        }

		/*if( (this.valueObj.riskType=='OSI' || this.valueObj.riskType=='OSS' || this.valueObj.riskType=='PAX') && this.valueObj.RIRetentionCode){
						
			let _totalGrossCapacity = BMSConstants.getBmsUtilServiceObj().getNetRetentionAmountDetails(this.valueObj.RIRetentionCode);
			_totalGrossCapacity = (!_totalGrossCapacity) ? 0 : parseFloat(""+_totalGrossCapacity);
			
			let _capitalSumInsured = parseFloat(""+this.valueObj.capitalSumInsured);
			
			if( _totalGrossCapacity > 0 && _capitalSumInsured > _totalGrossCapacity && (this.valueObj.RIMethod == null || this.valueObj.RIMethod == "" || parseFloat(""+this.valueObj.RIMethod) != 8) ){
				result.isValid = false;
				result.message = result.message + "<p>Capital Sum Insured is greater than Total Gross Capacity: "+_totalGrossCapacity+",  RI is Required.</p>";
			}
		}*/

        if (!result.isValid && validHeaderMandatoryFields) {
            result.message = this.valueObj.riskType + " (Risk Number: " + this.valueObj.riskNumber + " ): <p>Provide value for all mandatory fields.</p>" + result.message;
        }

        if (this.valueObj.ageLimitFlag != undefined && this.valueObj.ageLimitFlag != "" && 'L' == this.valueObj.ageLimitFlag) {
            result.isValid = false;
            result.message = result.message + "<br>Insured age is less than minimum age.";
        }

        return result;
    }

    setMandatoryFields() {
        if (this.valueObj.riskType == 'NPA') {
            this.fieldNames["capitalSumInsured"] = "Capital Sum Insured";
        }
        else if (this.valueObj.riskType == 'PAX') {
            this.fieldNames["ratingClass"] = "Occupational Class";
        } else {
            this.fieldNames["ratingClass"] = "Rating Class";
        }
    }

    validateNomioneeDetails(result) {
        if (this.valueObj.nomineeDetails != null) {

            if (this.valueObj.nomineeDetails.nominee != undefined && !(this.valueObj.nomineeDetails.nominee.constructor === Array)) {
                let nomineeItems: any = this.valueObj.nomineeDetails.nominee;
                this.valueObj.nomineeDetails.nominee = [nomineeItems];
            }

            if (this.valueObj.nomineeDetails.nominee.length > 0) {
                let percentageTotal: number = 0;
                for (let nominee of this.valueObj.nomineeDetails.nominee) {

                    result.fields.push("nomineeDetails");
                    let nomineeValid = new NomineeValidator(nominee).validate();
                    if (nomineeValid.isValid == false) {
                        result.isValid = false;
                        result.message = result.message + nomineeValid.message;
                        result.childsResult["nomineeDetails"] = nomineeValid;
                        result.validationResult["nomineeDetails"] = nomineeValid.isValid;
                        return result;
                    }
                    else {
                        //GA001 START
                        //percentageTotal = Number(percentageTotal) + Number(nominee.percentageOfShare);
                        percentageTotal = numeral(percentageTotal).add(parseFloat(nominee.percentageOfShare)).value();
                        //GA001 END
                    }
                }
                if (percentageTotal != 100) {
                    let nomineeDetails: ValidationResult = new ValidationResult();
                    nomineeDetails.isValid = false;
                    result.isValid = false;
                    nomineeDetails.message = "<br>Nominee Percentage Share Total is not equal to 100. Please make sure the total is equal to 100.";
                    result.message = result.message + nomineeDetails.message;
                    result.childsResult["nomineeDetails"] = nomineeDetails;
                    result.validationResult["nomineeDetails"] = nomineeDetails.isValid;
                    return result;
                }
            }
        }
        return result;
    }

    validateOverseasEductnDetails(result) {
        let overseasEducationDetailsResult: ValidationResult = new ValidationResult();
        overseasEducationDetailsResult.isValid = true;
        if (this.valueObj.overseasEducationDetails) {
            if (this.valueObj.overseasEducationDetails.actualCommencementDate == null || this.valueObj.overseasEducationDetails.actualCommencementDate == '') {
                overseasEducationDetailsResult.isValid = false;
                overseasEducationDetailsResult.message = overseasEducationDetailsResult.message + "<br>Actual Commencement Date is Mandatory";
            }
            if (this.valueObj.overseasEducationDetails.addOffOverseasResidence && !this.valueObj.overseasEducationDetails.countryCode) {
                overseasEducationDetailsResult.isValid = false;
                overseasEducationDetailsResult.message = overseasEducationDetailsResult.message + "<br>Country of Residence is Mandatory";
            }
            if (this.valueObj.overseasEducationDetails.addressOfEducInstitute && !this.valueObj.overseasEducationDetails.countryOfStudy) {
                overseasEducationDetailsResult.isValid = false;
                overseasEducationDetailsResult.message = overseasEducationDetailsResult.message + "<br>Country of Study is Mandatory";
            }
        }
        else {
            overseasEducationDetailsResult.isValid = false;
            overseasEducationDetailsResult.message = overseasEducationDetailsResult.message + "<br>Overseas Education Details are Mandatory.";
        }

        if (!overseasEducationDetailsResult.isValid) {
            result.fields.push("overseasEducationDetails");
            // result.isValid = false;
            // if(result.message == null || result.message == ""){
            // result.message = this.valueObj.riskType+" (Risk Number: "+this.valueObj.riskNumber+" ): <p>Provide value for all mandatory fields.</p>";
            // }
            // result.message = result.message + overseasEducationDetailsResult.message;
            result.childsResult["overseasEducationDetails"] = overseasEducationDetailsResult;
            result.validationResult["overseasEducationDetails"] = overseasEducationDetailsResult.isValid;
        }

        return overseasEducationDetailsResult;
    }

}