/*
 * Change History:
 * 
 * No      Date          Description                                   Changed By
 * ====    ==========    ===========                                   ==========
 * VK004	05/12/2018	MYS-2018-1192								  	VKR
 * 
*/
/**
 * No      Date          Description                                 Changed By
	====    ==========    ===========                                 ==========
    GA001   25/07/2019   MYS-2019-0256	 BMS Marine (MAR/MCA) Amend Routing Matrix KGA                          
 */
import { Validator, ValidationResult } from '../../../../common/components/validator/validator';
import { GSTDetilsValidator } from './gstdetails.validator';
import { ExcessTypeValidator } from './excesstype.validator';
import { SurveyValidator } from './survey.validator';
import { S4804 } from '../newbusinessrisks/s4804/appobjects/s4804';
import { BMSConstants } from '../../common/constants/bms_constants';
import { AppUtil } from '../../../../common/components/utility/apputil/app.util';
import { FinancialInterstValidator } from './financialinterest.validator';

declare var numeral: any;//GA001

export class S4804Validator extends Validator {
	
	public premiumFormat: string = "0,00.00";//GA001
		
    public fields: Array<any> = ["ratingFlag",
        "vessel",
        "vesselDesc",
        "vesselType",
        "shipmentType",
        "fromCountryCode",
        "voyageFrom",
        "toCountryCode",
        "areaOrPortLocation",
        "conveyance",
        "scopeOfCover",
        "claimCurrency",
        "riRetentionCode",
        "packingCode",
        "cargoType"
    ];
    public fieldNames: any = {
        ratingFlag: "Rating Flag",
        vessel: "Vessel",
        vesselDesc: "Vessel Description",
        vesselType: "Vessel Type",
        shipmentType: "Shipment Type",
        fromCountryCode: "From Country",
        voyageFrom: "Voyage From",
        toCountryCode: "To Country",
        areaOrPortLocation: "Area/Port",
        conveyance: "Conveyance",
        tShipVesselDesc: "T/Ship Vessel Description",
        scopeOfCover: "Scope Of Cover",
        claimCurrency: "Claim Currency",
        riRetentionCode: "RI Retention Code",
        packingCode: "Packing Code",
        cargoType: "Cargo Type",
        "GSTDetails.riskUsage": "GST Risk Usage",
        "GSTDetails.riskLocation": "GST Risk Location",
        "GSTDetails.placeOfRecidence": "Place of Residence / Business",
        "GSTDetails.inputTaxAllowed": "Input Tax Allowed?"
    };
    constructor(s4804: S4804) {
        super();
        this.valueObj = s4804;
        this.requiredFields = this.fields;
    }

    public validate() {

        this.setMandatoryFields();

        let result = super.validate();
        let validHeaderMandatoryFields: boolean = true;
        if (result.isValid == false) {
            validHeaderMandatoryFields = false;
            result.message = this.valueObj.riskType + " (Risk Number: " + this.valueObj.riskNumber + " ): <p>Provide value for all mandatory fields.</p>" + this.getInvalidFields(result, this.fieldNames);
        }

        if (this.valueObj.siCurrency && (!this.valueObj.siRate || !parseFloat("" + this.valueObj.siRate))) {
            result.isValid = false;
            result.message = result.message + "<br>Currency Rate % must be greater than 0.";
        }

        let coverageResult = this.coverageValidator();
        if (coverageResult.isValid == false) {
            result.isValid = false;
            result.message = result.message + coverageResult.message;
        }

        if ((parseFloat("" + this.valueObj.dutyRate) == 0 && parseFloat("" + this.valueObj.duty) > 0) || (parseFloat("" + this.valueObj.dutyRate) > 0 && parseFloat("" + this.valueObj.duty) == 0)) {

            result.isValid = false;
            if (parseFloat("" + this.valueObj.dutyRate) == 0)
                result.message = result.message + "<br>Duty Rate is mandatory";
            else if (parseFloat("" + this.valueObj.duty) == 0)
                result.message = result.message + "<br>Duty Amount is mandatory";
        }

        if (!this.valueObj.marineRate || !parseFloat("" + this.valueObj.marineRate)) {
            result.isValid = false;
            result.message = result.message + "<br>Marine Rate is mandatory";
        }

        let shipmentTypeValidResult = this.shipmentTypeValidator();
        if (shipmentTypeValidResult.isValid == false) {
            result.isValid = false;
            result.message = result.message + shipmentTypeValidResult.message;
        }

        if (this.valueObj.FI == "Y") {
            let financialInterestValResult = new FinancialInterstValidator(this.valueObj).validate();
            if (financialInterestValResult.isValid == false) {
                result.isValid = false;
                if (result.message == null || result.message == "") {
                    result.message = financialInterestValResult.message;
                } else
                    result.message = result.message + financialInterestValResult.message;
            }
        }

        if (this.valueObj.isSurveyNeeded == "Y") {
            let surveyValidatorResult = new SurveyValidator(this.valueObj).validate();
            if (surveyValidatorResult.isValid == false) {
                result.isValid = false;
                if (result.message == null || result.message == "") {
                    result.message = surveyValidatorResult.message;
                } else
                    result.message = result.message + surveyValidatorResult.message;
            }
        }

        if (this.valueObj.declarationMonthDetails.declarationMonth && this.valueObj.declarationMonthDetails.declarationMonth.length > 0) {

            let _yearColumnValidation: boolean = true;
            let _monthColumnValidation: boolean = true;
            let _amountColumnValidation: boolean = true;

            let dmArray = this.valueObj.declarationMonthDetails.declarationMonth;
            this.sortArray(dmArray, 'year');
            this.sortArray(dmArray, 'month');

            let prevEntry = '';
            let _hasDuplicates: boolean = false;
            for (let dm of dmArray) {
                // if((dm.month || dm.year) && (!(dm.sumInsured >0) || !(dm.orgPremium >0) )){
                if (!(dm.sumInsured > 0) || !(dm.orgPremium > 0)) {
                    _amountColumnValidation = false;
                }

                if (!(dm.year > 0 && dm.year <= 9999)) {
                    _yearColumnValidation = false;
                }

                if (!(dm.month)) {
                    _monthColumnValidation = false;
                }
                if ((dm.month + "" + dm.year) == prevEntry) {
                    _hasDuplicates = true;
                }

                prevEntry = dm.month + "" + dm.year;
            }

            if (!_yearColumnValidation || !_monthColumnValidation || !_amountColumnValidation) {
                result.isValid = false;
                if (result.message == null || result.message == "") {
                    result.message = "Declaration Month Details: Enter mandatory fileds.";
                } else
                    result.message = result.message + "Declaration Month Details: Enter mandatory fileds.";
            }

            if (_hasDuplicates) {
                result.isValid = false;
                if (result.message == null || result.message == "") {
                    result.message = "Declaration Month Details: Duplicate Month & Year entries not allowed.";
                } else
                    result.message = result.message + "Declaration Month Details: Duplicate Month & Year entries not allowed.";
            }

        }

        let excessTypeResult = new ExcessTypeValidator(this.valueObj).validate();
        if (excessTypeResult.isValid == false) {
            result.isValid = false;
            result.message = result.message + excessTypeResult.message;
        }

        if (this.valueObj.totalGoodsOriginalSI > 99999999999.99) {
            result.isValid = false;
            if (result.message == null || result.message == "") {
                result.message = "Total Original SI should not be more than 99999999999.99";
            } else
                result.message = result.message + "Total Original SI should not be more than 99999999999.99";
        }

        if (!result.isValid && validHeaderMandatoryFields) {
            result.message = this.valueObj.riskType + " (Risk Number: " + this.valueObj.riskNumber + " ): <p>Provide value for all mandatory fields.</p>" + result.message;
        }

        //GA001 START
        let _targetSumInsured: any = numeral(numeral(BMSConstants.getBMSHeaderInfo().targetSumInsured).format(this.premiumFormat)).value();
        var _totalConvertedSI = numeral(numeral(this.valueObj.totalOriginalSI * this.valueObj.siRate).format(this.premiumFormat)).value();
        if( _targetSumInsured != _totalConvertedSI  ){
			result.isValid = false;
            result.message = result.message + "<br>In Risk Summary, Sum Insured is not equal to Converted Sum Insured then, Please revisit / expand Risk screen to populate Converted Sum Insured into Capital Sum Insured.";
        }
        //GA001 END

		//VK004 General Page Text
		let headerInfo = BMSConstants.getBMSHeaderInfo();
		if(Number(this.valueObj.gpTextCount) > Number(headerInfo.gpTextMaxLines)) {
			result.isValid = false;
			result.message = this.valueObj.riskType+" (Risk Number: "+this.valueObj.riskNumber+" ): General Page Text entered is more than 400 lines.";
		}
		//VK004 END
        return result;
    }

    setMandatoryFields() {
        if (this.valueObj.riskType == 'MAR' && this.valueObj.tShipVessel) {
            this.fields.push("tShipVesselDesc");
        }
    }

    private coverageValidator() {
        let result = new ValidationResult();
        if (this.valueObj.riskCoverageDetails.riskCoverage == null || this.valueObj.riskCoverageDetails.riskCoverage == "") {
            result.isValid = false;
            result.message = "<p>Add cover in Coverage Information section.</p>";
        }
        else {
            let riskCoverageItemsArr: any = [];
            riskCoverageItemsArr = new AppUtil().getArray(this.valueObj.riskCoverageDetails.riskCoverage);

			/*if(Array.prototype.isPrototypeOf(this.valueObj.riskCoverageDetails.riskCoverage)){
				riskCoverageItemsArr = this.valueObj.riskCoverageDetails.riskCoverage;
			} else {
				riskCoverageItemsArr = [this.valueObj.riskCoverageDetails.riskCoverage];
			}*/

            if (riskCoverageItemsArr.length > 0) {

                result.isValid = true;
                for (let coverageItem of riskCoverageItemsArr) {
                    if ((coverageItem.interestInsured == null || coverageItem.interestInsured == "") || (coverageItem.originalSI == null || coverageItem.originalSI <= 0) || (coverageItem.commodity == null || coverageItem.commodity == "")) {
                        result.isValid = false;
                    }
                }
                if (result.isValid == false) {
                    result.message = "<p>Fill all mandatory fields in Coverage Information section.</p>";
                }
            }
            else {
                result.isValid = false;
                result.message = "<p>Add cover in Coverage Information section.</p>";
            }
        }

        return result;
    }

    shipmentTypeValidator() {
		/*Shipment type validations:
		From = Overseas, To = Overseas (note: To = Area Port)   
		   WHEN S4804-ZFRMCTRY  <> MY                 
			AND S4804-ZPORT     <> MY                 
			  IF S4804-SSHPMT   <> CV                 
				 ERROR!
				 
		From = Overseas, To = Malaysia                          
		   WHEN S4804-ZFRMCTRY  <> MY                 
			AND S4804-ZPORT     =  MY                 
			  IF S4804-SSHPMT   <> CS, IM, TC         
				 ERROR!
				 
		From = Malaysia, To = Overseas                          
		   WHEN S4804-ZFRMCTRY  =  MY                 
			AND S4804-ZPORT     <> MY                 
			  IF S4804-SSHPMT   <> EX                 
				 ERROR!
				 
		From = Malaysia, To = Malaysia                       
		   WHEN S4804-ZFRMCTRY  =  MY              
			AND S4804-ZPORT     =  MY              
			  IF S4804-SSHPMT   <> IC, IT          
				 ERROR!
		*/
        let result = new ValidationResult();
        result.isValid = true;
        if (this.valueObj.fromCountryCode != "MY" && this.valueObj.areaOrPortCode != "MY" && this.valueObj.shipmentType != "CV") {
            result.isValid = false;
        }
        if (this.valueObj.fromCountryCode != "MY" && this.valueObj.areaOrPortCode == "MY" && ["CS", "IM", "TC"].indexOf(this.valueObj.shipmentType) < 0) {
            result.isValid = false;
        }
        if (this.valueObj.fromCountryCode == "MY" && this.valueObj.areaOrPortCode != "MY" && this.valueObj.shipmentType != "EX") {
            result.isValid = false;
        }
        if (this.valueObj.fromCountryCode == "MY" && this.valueObj.areaOrPortCode == "MY" && ["IC", "IT"].indexOf(this.valueObj.shipmentType) < 0) {
            result.isValid = false;
        }

        if (result.isValid == false) {
            result.message = "<p>Please select valid Shipment Type.</p>";
        }

        return result;
    }

    public sortArray(arryObjs, name) {
        if (arryObjs.length > 0) {
            arryObjs.sort(function (obj1, obj2) {
                if (obj1[name] < obj2[name]) {
                    return -1;
                } else if (obj1[name] > obj2[name]) {
                    return 1;
                } else {
                    return 0;
                }
            });
        }
    }

}