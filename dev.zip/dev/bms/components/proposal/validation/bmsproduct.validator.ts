/*
 * Change History:
 * 
 * No      Date          Description                                         Changed By
 * ====    ==========    ===========                                         ==========	
 * YPK001 23/09/2019       MYS-2019-0675 Document Validation for Co-outwards            PKU1
 *                         case before sending to PPHO			   
*/
import { Validator, ValidationResult } from '../../../../common/components/validator/validator';
import { ApplicationBusinessObject } from '../../common/appobjects/applicationBusinessObject';
import { CaseInfoValidator } from './caseinfo.validator';
import { ProposalValidator } from './proposal.validator';
import { BMSConstants } from '../../common/constants/bms_constants';
import { BMSType } from '../../common/constants/bms_types';

declare var numeral: any;

export class BMSProductValidator extends Validator {
    constructor(appObj: ApplicationBusinessObject) {
        super();
        this.valueObj = appObj;
    }

    public validate() {
        let result = new ValidationResult();
        result.isValid = true;

        let caseInfoResult = new CaseInfoValidator(this.valueObj.caseInfo).validate();
        if (caseInfoResult.isValid == true) {
            let proposalResult = new ProposalValidator(this.valueObj.businessObject.bms).validate();
            if (proposalResult.isValid == false) {
                result.isValid = false;
                result.message = "Application: Validation failed.<p>" + proposalResult.message + "</p>";
            }
            if (proposalResult.isWarned) {
                result.isWarned = true;
                result.warningMessage = result.warningMessage + proposalResult.warningMessage;
            }

            result.childsResult["bms"] = proposalResult;
        }
        else {
            result.isValid = false;
            result.message = "Application: Validation failed.<p>" + caseInfoResult.message + "</p>";
        }

        result.childsResult["caseInfo"] = caseInfoResult;

        if (caseInfoResult.isWarned) {
            result.isWarned = true;
            result.warningMessage = result.warningMessage + caseInfoResult.warningMessage;
        }

        if (result.isValid == true) {
            let header = this.valueObj.businessObject.bms.newBusiness.headerInfo;
            let procInfo = this.valueObj.processObject;
            let caseInfo = this.valueObj.caseInfo;
            //Endorsements Code
            if ( caseInfo.businessFunction == "Endorsements" || caseInfo.businessFunction == "Cancellations" || caseInfo.businessFunction == "Reinstatement" ) {
                if ( header.CoInsurance == "Y" && caseInfo.isCOOHDocAttached() == false ) {
                    result.isValid = false;
                    result.message = "Application: Validation failed.<br/> <p>'Hold Cover confirmation' letter is not attached.</p>";
                }
            }//End 
            else {
                if ( ( procInfo.workflowStatus == "Quotation" || procInfo.workflowStatus == "Policy Pipeline" || procInfo.workflowStatus == "Policy Processing" || procInfo.workflowStatus == "Pending Receipting" ) && ["moveToHOPolicyProcessing", "moveToPipeline", "moveToPolicyProcessing", "postToP400","moveToReceipting","moveToHOReceipting"].indexOf( procInfo.movingState ) != -1 ) {
                    if ( header.RIRequiredHeader == "Yes" && header.RIType != "TreatyAdjustment" && caseInfo.isFACRIDocAttached() == false && ( BMSConstants.getBMSType() == BMSType.NewBusiness || BMSConstants.getBMSType() == BMSType.CoverNote || BMSConstants.getBMSType() == BMSType.Renewal ) ) {
                        result.isValid = false;
                        result.message = "Application: Validation failed.<p>'RI worksheet and RI confirmation' is not attached.</p>";
                    }
                    //START YPK001
                    if ( header.CoInsurance == "Y" && caseInfo.isCOOHDocAttached() == false && ( BMSConstants.getBMSType() == BMSType.NewBusiness || BMSConstants.getBMSType() == BMSType.Renewal ) ) {
                        result.isValid = false;
                        result.message = "Application: Validation failed.<p>'Hold Cover confirmation' letter is not attached.</p>";
                    }
                    //END YPK001
                }
            }          

                  
        }
        result = this.handleAMLCDD(result);
        result = this.handleHRC(result);
        return result;
    }
    public handleAMLCDD(result) {
        let state = BMSConstants.getMovingState();
        if (state == 'moveToPolicyProcessing' || state == 'moveToHOPolicyProcessing' || state == 'moveToCoverNoteProcessing') {
            let header = this.valueObj.businessObject.bms.newBusiness.headerInfo;
            let caseInfo = this.valueObj.caseInfo;
            let client = this.valueObj.businessObject.bms.newBusiness.clientDetails.client;
            let clientType = (client.clientNumber != undefined && client.clientNumber != "") ? 'C' : 'P';
            if ((header.businessChannel == '04' || header.businessChannel == '01') && clientType == 'P') {
                if (numeral(header.totalNetPostedPremium) >= numeral(header.AMLCDDDefualtlimit)) {
                    if (header.AMLCDDCheck != 'true') {
                        result.isValid = false;
                        result.message = result.message + "Application: Validation failed.<p> Please do AML CDD check and proceed.</p>";
                    }
                    if (numeral(header.totalNetPostedPremium) >= numeral(header.AMLCDDSupDoclimit) && !caseInfo.isAMLCDDDocAttached()) {
                        result.isValid = false;
                        result.message = result.message + "Application: Validation failed.<p> Please attach AML CDD relevant documents and proceed.</p>";
                    }
                }
            }
        }

        return result;

    }

    public handleHRC(result) {
        let state = BMSConstants.getMovingState();
        let procInfo = this.valueObj.processObject;
        if (procInfo.workflowStatus == "Assessment" && (state == 'moveToQuotation' || state == 'submitToAH')) {
            let header = this.valueObj.businessObject.bms.newBusiness.headerInfo;
            let caseInfo = this.valueObj.caseInfo;
            if (header.HighRiskCus == 'Y' && header.HighRiskCEOApproval != "Y" && header.HighRiskCusType != "NHRC") {
                result.isValid = false;
                result.message = result.message + "Application: Validation failed.<p> CEO Approval is required for High Risk Customer. Confirm that by checking 'Obtained CEO's approval' in High Risk Customer Page.</p>";
            }

            if (result.isValid == true && header.HighRiskCus == 'Y' && header.HighRiskCEOApproval == "Y" && caseInfo.isHRCDocAttached() == false && header.HighRiskCusType != "NHRC") {
                result.isValid = false;
                result.message = result.message + "Application: Validation failed.<p> Attach evidence of CEO Approval for High Risk Customer.</p>";
            }
        }

        return result;

    }

}