/*
* Change History	:
*
*	No      Date          	Description                Changed By
*	====    ==========    	===========	               ==========	
* 
* 	VK004	06/12/2018		MYS-2018-1192					VKR
*/
import { Validator, ValidationResult } from '../../../../common/components/validator/validator';
import { GSTDetilsValidator } from './gstdetails.validator';
import { S4857 } from '../newbusinessrisks/s4857/appobjects/s4857';
import { BMSConstants } from '../../common/constants/bms_constants';

export class S4857Validator extends Validator {
    public fields: Array<any> = [
        "ratingFlag",
        "benefitCode",
        "capitalSumInsured",
        "totalPremium",
        "polHolderName",
        "polHolderOccupationCode",
        "polHolderOccupationDesc",
        "polHolderSex",
        "polHolderDOB",
        "polHolderICBirthCert"
    ];
     public fieldsRenewal: Array<any> = [//MYS-2018-0877 FPA
        "ratingFlag",
        "benefitCode",
        "capitalSumInsured",
        "totalPremium",
        "polHolderName",        
        "polHolderOccupationDesc",
        "polHolderSex",
        "polHolderDOB",
        "polHolderICBirthCert"
    ];
    public spouseFields: Array<any> = [
        "spouseOccupationCode",
        "spouseOccupationDesc",
        "spouseSex",
        "spouseDOB",
        "spouseICBirthCert"
    ];
     public spouseFieldsRenewal: Array<any> = [//MYS-2018-0877 FPA        
        "spouseOccupationDesc",
        "spouseSex",
        "spouseDOB",
        "spouseICBirthCert"
    ];
    public fieldNames: any = {
        ratingFlag: "Rating Flag",
        benefitCode: "Benefit Code",
        capitalSumInsured: "Capital Sum Insured",
        totalPremium: "Total Premium",
        polHolderName: "Policy Holder Name",
        polHolderOccupationCode: "Policy Holder Occupation Code",
        polHolderOccupationDesc: "Policy Holder Occupation Desc",
        polHolderSex: "Policy Holder Gender",
        polHolderDOB: "Policy Holder DOB",
        polHolderICBirthCert: "Policy Holder IC/Birth Cert"
    };
   
    public spouseFieldNames: any = {
        spouseOccupationCode: "Spouse Occupation Code",
        spouseOccupationDesc: "Spouse Occupation Desc",
        spouseSex: "Spouse Gender",
        spouseDOB: "Spouse DOB",
        spouseICBirthCert: "Spouse IC/Birth Cert"
    };
    
    constructor(s4857: S4857) {
        super();
        this.valueObj = s4857;
              /** Occ code non mandatory for renewal MKU1 */
        if(this.valueObj.isRenewal!=undefined && this.valueObj.isRenewal)
        this.requiredFields = this.fieldsRenewal;
        else
        this.requiredFields = this.fields;
              /** Occ code non mandatory for renewal MKU1 */
    }

    public validate() {
        let ageValidFlag: boolean = false;
        let result = super.validate();
        let basicMessage = this.valueObj.riskType + " (Risk Number: " + this.valueObj.riskNumber + " ): <p>Provide value for all mandatory fields.</p>";

        if (result.isValid == false) {            
            result.message = this.getInvalidFields(result, this.fieldNames);               
        }
        //validate spouse details only if spouse name is provided.
        if ((this.valueObj["spouseName"] != undefined && this.valueObj["spouseName"] != "") || (this.valueObj["spouseOccupationCode"] != undefined && this.valueObj["spouseOccupationCode"] != "")) {
            let spouserequiredFields : any;
            /** Occ code non mandatory for renewal MKU1 */
           if(this.valueObj.isRenewal!=undefined && this.valueObj.isRenewal)
           spouserequiredFields = this.spouseFieldsRenewal;
           else
           spouserequiredFields =  this.spouseFields;
            /** Occ code non mandatory for renewal MKU1 */

            let spouseValidationMessage = this.getMissingFields(result, this.spouseFieldNames, spouserequiredFields, this.valueObj);
            if (result.isValid == false) {
                result.message = result.message + "<p>Spouse Details:" + spouseValidationMessage + "</p>";
            }
        }
        let validateChildrenResult = this.validateChildren();
        if (validateChildrenResult.isValid == false) {
            result.message = result.message + validateChildrenResult.message;
            result.isValid = false;
            ageValidFlag = true;
        }
        //Age Validation related code changes.
        if (this.valueObj.ageLimitFlag != undefined && this.valueObj.ageLimitFlag != "" && 'L' == this.valueObj.ageLimitFlag) {
            result.isValid = false;
            result.message = result.message + "<br>Policyholder's age is less than minimum age.";
            ageValidFlag = true;
        }
        if (this.valueObj.spouseAgeLimitFlag != undefined && this.valueObj.spouseAgeLimitFlag != "" && 'L' == this.valueObj.spouseAgeLimitFlag) {
            result.isValid = false;
            result.message = result.message + "<br>Spouse's age is less than minimum age.";
            ageValidFlag = true;
        }
        //End

        let gstDetailsResult = new GSTDetilsValidator(this.valueObj).validate();
        if (gstDetailsResult.isValid == false) {
            result.isValid = false;
            result.message = result.message + gstDetailsResult.message;
        }

        if (result.isValid == false && !ageValidFlag) {
            result.message = basicMessage + "" + result.message;
        }

		//VK004 General Page Text
		let headerInfo = BMSConstants.getBMSHeaderInfo();
		if(Number(this.valueObj.gpTextCount) > Number(headerInfo.gpTextMaxLines)) {
			result.isValid = false;
			result.message = result.message + this.valueObj.riskType+" (Risk Number: "+this.valueObj.riskNumber+" ): General Page Text entered is more than 400 lines.";
		}
		//VK004 END

        return result;
    }
    private validateChildren() {
        let result = new ValidationResult();
        result.isValid = true;
        let childFields: Array<any> = [
            "name",
            "occupationCode",
            "occupationDescription",
            "gender",
            "DOB",
            "nric"
        ];
         let childFieldsRenewal: Array<any> = [//MYS-2018-0877 FPA  
            "name",            
            "gender",
            "DOB",
            "nric"
        ];
        let childFieldLabels: any = {
            name: "Child Name",
            occupationCode: "Child Occupation",
            occupationDescription: "Child Occupation Desc",
            gender: "Child Gender",
            DOB: "Child DOB",
            nric: "Child IC/Passport"
        };
        
        if (Array.prototype.isPrototypeOf(this.valueObj.childrenDetails.children)) {
            let childCount = 1;
            let isChildMoreThan23Y = false;
            let childrequiredFields : any;
            /** MYS-2018-0877 MKU1 */
             if(this.valueObj.isRenewal!=undefined && this.valueObj.isRenewal)
             childrequiredFields = childFieldsRenewal;
             else
             childrequiredFields = childFields;
            /** MYS-2018-0877 MKU1 */
            for (let item of this.valueObj.childrenDetails.children) {
                result.message = result.message + "<p>Child : " + childCount + "" + this.getMissingFields(result, childFieldLabels, childrequiredFields, item);
                //result.isValid=false;
                if (item.insuredAge > 24) {
                    result.message = result.message + "<br/>- Child age cannot be more than 24 Years</p>";
                    result.isValid = false;
                }
                //Age related validation				
                if (item.ageLimitFlag != undefined && item.ageLimitFlag != "" && 'L' == item.ageLimitFlag) {
                    result.isValid = false;
                    result.message = "<br>Child : " + childCount + " age is less than minimum age.";
                }
                childCount++;
            }
        }
        return result;
    }

    getMissingFields(result, vFieldNames, vFields, data) {
        //let fields = Object.keys(valResult.validationResult);
        let missedFields = " ";
        let count = 1;
        for (let fld of vFields) {
            if (data[fld] == undefined || data[fld] == "") {
                result.isValid = false;
                if (vFieldNames[fld] == null) {
                    missedFields = missedFields + "<br/>- " + fld;
                }
                else {
                    missedFields = missedFields + "<br/>- " + vFieldNames[fld];
                }
                count++;
            }
        }
        return missedFields;
    }
}