import { Validator, ValidationResult } from '../../../../common/components/validator/validator';
import { FinancialInterest } from '../../../../common/components/financialinterest/appobjects/financialInterest';
import { AppUtil } from '../../../../common/components/utility/apputil/app.util';

export class FinancialInterstValidator extends Validator {
    private riskObj;

    constructor(riskObj: Object) {
        super();
        this.riskObj = riskObj;
    }

    public validate() {

        let result = new ValidationResult();
        result.isValid = true;
        if (this.riskObj.financialInterest && this.riskObj.financialInterest.financialInterestList) {
            let _ary = new AppUtil().getArray(this.riskObj.financialInterest.financialInterestList);
            for (let _item of _ary) {
                if (_item.relationCode == null || _item.relationCode == "") {
                    result.isValid = false;
                    result.message = "<br>Provide Relationship value for all Financial Interest Item";

                    break;
                }
            }
        }

        return result;
    }

}