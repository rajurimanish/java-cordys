import { Validator, ValidationResult } from '../../../../common/components/validator/validator';
import { BMSConstants } from '../../common/constants/bms_constants';
import { Survey } from '../newbusinessrisks/appobjects/survey';

export class SurveyValidator extends Validator {
    private riskObj;
    public fields: Array<any> = [];
    public fieldNames: any = { "clientDetails.state": "State" };

    constructor(riskObj: Object) {
        super();
        this.riskObj = riskObj;
        this.valueObj = this.riskObj.survey;
        this.requiredFields = this.fields;
    }

    public validate() {
        let result = new ValidationResult();
        result.isValid = true;
        result.message = "";
        if (!this.valueObj.clientDetails.state) {
            result.isValid = false;
            result.message = "<br>Survey Details: State is mandatory.";
        }

        if (!this.valueObj.clientDetails.contactPerson) {
            result.isValid = false;
            result.message = result.message + "<br>Survey Details: Contact Person is mandatory.";
        }

        if (!this.valueObj.clientDetails.contactNumber) {
            result.isValid = false;
            result.message = result.message + "<br>Survey Details: Contact Number is mandatory.";
        }

        if (!this.riskObj.surveyType) {
            result.isValid = false;
            result.message = result.message + "<br>Survey Details: Survey Type is mandatory.";
        }

        return result;
    }

}