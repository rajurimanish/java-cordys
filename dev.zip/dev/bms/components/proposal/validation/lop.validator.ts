/*
 * Change History	:
 *
 * 	No      Date         	Description                 		Changed By
 *	====    ==========   	===========                 		==========
 * VK004	05/12/2018		MYS-2018-1192 - General Page			VKR
 *  
*/ 
import { Validator, ValidationResult } from '../../../../common/components/validator/validator';
import { FireLOP } from '../newbusinessrisks/firelop/appobjects/fireLOP';
import { CBIItems } from '../newbusinessrisks/appobjects/cbi';
import { Clause, SpecialClauses } from '../newbusinessrisks/appobjects/clause';
import { MDRisks } from '../newbusinessrisks/firelop/appobjects/md';
import { FireCoverageValidator } from './firecoverage.validator';
import { PerilValidator } from './peril.validator';
import { FinancialInterestValidator } from '../../../../common/components/financialinterest/validation/financialInterest.validator';
import { BMSConstants } from '../../common/constants/bms_constants';

export class LOPValidator extends Validator {
    public fields: Array<any> = ["situation1",
        "PIAMCode",
        "occupiedAs",
        "construction",
        "riskClassification",
        "townClass",
        "RIRetentionCode",
        "postCode",
        "city",
        "accumulationRegister",
        "rateBasis",
        "locality",
        "indPeriod",
        "indPeriodNo",
        "totalPremium",
        "capitalSumInsured",
        "GSTDetails.riskLocation",
        "totalSI"];
    public fieldNames: any = {
        situation1: "Situation",
        PIAMCode: "PIAM Code",
        occupiedAs: "Occupied As",
        construction: "Construction",
        riskClassification: "Risk Classification",
        townClass: "Town Class",
        RIRetentionCode: "RI Retention Code",
        postCode: "Post Code",
        city: "City",
        accumulationRegister: "Accumulation Register",
        rateBasis: "Rate Basis",
        locality: "Locality",
        indPeriod: "Ind Period Type",
        indPeriodNo: "Ind Period Value",
        totalPremium: "Total Premium",
        "GSTDetails.riskLocation": "GST Risk Location",
        totalSI: "Total Sum Insured",
    };
    constructor(lop: FireLOP) {
        super();
        this.valueObj = lop;
        this.requiredFields = this.fields;
    }

    public validate() {
        let result = super.validate();

        if (result.isValid == false) {
            result.message = this.valueObj.riskType + " (Risk Number: " + this.valueObj.riskNumber + " ): <p>Provide value for all mandatory fields.</p>" + this.getInvalidFields(result, this.fieldNames);
        }

        let clauseResult = this.validateClauses(this.valueObj);

        if (clauseResult.isValid == false) {
            result.isValid = false;
            if (result.message == null || result.message == "") {
                result.message = this.valueObj.riskType + " (Risk Number: " + this.valueObj.riskNumber + " ): <p>Provide value for all mandatory fields.</p>";
            }
            result.message = result.message + clauseResult.message;
        }

        let cbiResult = new CBIValidator(this.valueObj.CBI).validate();
        if (cbiResult.isValid == false) {
            result.isValid = false;
            if (result.message == null || result.message == "") {
                result.message = this.valueObj.riskType + " (Risk Number: " + this.valueObj.riskNumber + " ): <p>Provide value for all mandatory fields.</p>";
            }
            result.message = result.message + cbiResult.message;
        }

        let mdResult = new MDValidator(this.valueObj.mdRisks).validate();
        if (mdResult.isValid == false) {
            result.isValid = false;
            if (result.message == null || result.message == "") {
                result.message = this.valueObj.riskType + " (Risk Number: " + this.valueObj.riskNumber + " ): <p>Provide value for all mandatory fields.</p>";
            }
            result.message = result.message + mdResult.message;
        }

        let coverResult = new FireCoverageValidator(this.valueObj).validate();
        if (coverResult.isValid == false) {
            result.isValid = false;
            if (result.message == null || result.message == "") {
                result.message = this.valueObj.riskType + " (Risk Number: " + this.valueObj.riskNumber + " ): <p>Provide value for all mandatory fields.</p>";
            }
            result.message = result.message + coverResult.message;
        }

        if (this.valueObj.rateBasis != null && (this.valueObj.rateBasis == "G" || this.valueObj.rateBasis == "S")) {
            let perilResult = new PerilValidator(this.valueObj.perils).validate();
            if (perilResult.isValid == false) {
                result.isValid = false;
                if (result.message == null || result.message == "") {
                    result.message = this.valueObj.riskType + " (Risk Number: " + this.valueObj.riskNumber + " ): <p>Provide value for all mandatory fields.</p>";
                }
                result.message = result.message + perilResult.message;
            }

            result.childsResult["peril"] = perilResult;
        }

        let spClsResult = new SpecialClauseValidator(this.valueObj.specialClauses, this.valueObj.clauses).validate();
        if (spClsResult.isValid == false) {
            result.isValid = false;
            if (result.message == null || result.message == "") {
                result.message = this.valueObj.riskType + " (Risk Number: " + this.valueObj.riskNumber + " ): <p>Provide value for all mandatory fields.</p>";
            }
            result.message = result.message + spClsResult.message;
        }

        let financialInterestResult = this.validateFinancialInterest();
        if (financialInterestResult.isValid == false) {
            result.isValid = false;
            if (result.message == null || result.message == "") {
                result.message = this.valueObj.riskType + " (Risk Number: " + this.valueObj.riskNumber + " ): <p>Provide value for all mandatory fields.</p>";
            }
            result.message = result.message + financialInterestResult.message;
        }

		//VK004 General Page Text
		let headerInfo = BMSConstants.getBMSHeaderInfo();
		if(Number(this.valueObj.gpTextCount) > Number(headerInfo.gpTextMaxLines)) {
			result.isValid = false;
			result.message = this.valueObj.riskType+" (Risk Number: "+this.valueObj.riskNumber+" ): General Page Text entered is more than 400 lines.";
		}
		//VK004 END
        result.childsResult["clause"] = clauseResult;
        result.childsResult["specialClause"] = spClsResult;
        result.childsResult["cbi"] = cbiResult;
        result.childsResult["md"] = mdResult;
        result.childsResult["cover"] = coverResult;
        result.childsResult["fiItems"] = financialInterestResult;

        return result;
    }

    validateClauses(lop: FireLOP) {
        let result = new ValidationResult();

        if (lop.rateableClassCode == null || typeof (lop.rateableClassCode) === "string" || lop.rateableClassCode.rateableClassCode == null || typeof (lop.rateableClassCode.rateableClassCode) === "string") {
            result.isValid = true;
        }
        else if (Array.prototype.isPrototypeOf(lop.rateableClassCode.rateableClassCode)) {
            let fireItems = JSON.stringify(lop.fireItems);
            result.isValid = true;
            for (let clause of lop.rateableClassCode.rateableClassCode) {
                if (fireItems.indexOf("\"" + clause.classCode + "\"") == -1) {
                    result.isValid = false;
                    result.message = "<p>Clause " + clause.classCode + " is not added to any cover.</p>";
                }
            }
        }
        else if (!Array.prototype.isPrototypeOf(lop.rateableClassCode.rateableClassCode)) {
            let tempAry: any = lop.rateableClassCode.rateableClassCode;
            let clauseAry = [tempAry];
            let fireItems = JSON.stringify(lop.fireItems);
            result.isValid = true;
            for (let clause of clauseAry) {
                if (fireItems.indexOf("\"" + clause.classCode + "\"") == -1) {
                    result.isValid = false;
                    result.message = "<p>Clause " + clause.classCode + " is not added to any cover.</p>";
                }
            }
        }
        return result;
    }

    validateFinancialInterest() {
        let result = new ValidationResult();
        result.isValid = true;
        if (this.valueObj.FI == "Y" && this.valueObj.financialInterest != null && this.valueObj.financialInterest != "") {
            if (this.valueObj.financialInterest.financialInterestList != undefined && !(this.valueObj.financialInterest.financialInterestList.constructor === Array)) {
                let financialInterestItems: any = this.valueObj.financialInterest.financialInterestList;
                this.valueObj.financialInterest.financialInterestList = [financialInterestItems];
            }

            if (this.valueObj.financialInterest.financialInterestList.length > 0) {
                for (let fiItem of this.valueObj.financialInterest.financialInterestList) {

                    let fiTemValid = new FinancialInterestValidator(fiItem).validate();
                    if (fiTemValid.isValid == false) {
                        result.isValid = false;
                    }
                    result.message = result.message + fiTemValid.message;
                }
            }
            else {
                result.isValid = false;
                result.message = this.valueObj.riskType + " (Risk Number: " + this.valueObj.riskNumber + " ):  Atleast one Financial Interest Item must be added for the Risk.";
            }
        }
        return result;
    }
}

export class CBIValidator extends Validator {
    constructor(cbi: CBIItems) {
        super();
        this.valueObj = cbi;
    }

    public validate() {
        let result = new ValidationResult();

        if (this.valueObj == null || this.valueObj.cbiItems == null || this.valueObj.cbiItems == "") {
            result.isValid = false;
            result.message = "<p>Add CBI in CBI Information section.</p>";
        }
        else if (Array.prototype.isPrototypeOf(this.valueObj.cbiItems)) {
            if (this.valueObj.cbiItems.length > 0) {
                result.isValid = true;
            }
            else {
                result.isValid = false;
                result.message = "<p>Add CBI in CBI Information section.</p>";
            }
        }
        else if (!Array.prototype.isPrototypeOf(this.valueObj.cbiItems)) {
            let tempAry: any = this.valueObj.cbiItems;
            let cbiAry = [tempAry];
            if (cbiAry[0].code == null) {
                result.isValid = false;
                result.message = "<p>Add CBI in CBI Information section.</p>";
            }
            else {
                result.isValid = true;
            }
        }
        return result;
    }
}

export class MDValidator extends Validator {
    constructor(md: MDRisks) {
        super();
        this.valueObj = md;
    }

    public validate() {
        let result = new ValidationResult();

        if (this.valueObj == null || this.valueObj.mdRisk == null || this.valueObj.mdRisk == "") {
            result.isValid = false;
            result.message = "<p>Add MD in MD Information section.</p>";
        }
        else if (Array.prototype.isPrototypeOf(this.valueObj.mdRisk)) {
            if (this.valueObj.mdRisk.length > 0) {
                result.isValid = true;
                let dublicate = {};
                for (let md of this.valueObj.mdRisk) {
                    if (md.mdRisk == null || md.mdRisk == '' || md.riskNo == null || md.riskNo == '') {
                        result.isValid = false;
                        result.message = "<p>Both policy number and risk number are mandatory in MD section.</p>";
                    }

                    let existing = this.valueObj.mdRisk.filter((item) => item.mdRisk == md.mdRisk && item.riskNo == md.riskNo);
                    if (existing != null && existing.length > 1) {
                        let dubItem = "Policy Number " + md.mdRisk + ", Risk Number " + md.riskNo;
                        dublicate[dubItem] = "";
                    }
                }

                let repeatedItems = Object.keys(dublicate);
                if (repeatedItems != null && repeatedItems.length > 0) {
                    result.isValid = false;
                    result.message = result.message + "<p>Duplicate MD is added.</p>";
                    let count = 1;
                    for (let eachRepeat of repeatedItems) {
                        let item = "<p>" + count + ")" + eachRepeat + "</p>";
                        result.message = result.message + item;
                    }
                }
            }
            else {
                result.isValid = false;
                result.message = "<p>Add MD in MD Information section.</p>";
            }
        }
        else if (!Array.prototype.isPrototypeOf(this.valueObj.mdRisk)) {
            let tempAry: any = this.valueObj.mdRisk;
            let mdAry = [tempAry];
            result.isValid = true;
            for (let md of mdAry) {
                if (md.mdRisk == null || md.mdRisk == '' || md.riskNo == null || md.riskNo == '') {
                    result.isValid = false;
                    result.message = "<p>Both policy number and risk number are mandatory in MD section.</p>";
                }
            }
        }
        return result;
    }
}

export class SpecialClauseValidator extends Validator {
    public clauses: Clause;
    constructor(spc: SpecialClauses, cls: Clause) {
        super();
        this.valueObj = spc;
        this.clauses = cls;
    }

    public validate() {
        let result = new ValidationResult();
        if (this.valueObj.clause.length == 0 || this.clauses.clause.length == 0) {
            result.isValid = false;
            result.message = "<p>Add at-least one special clause.</p>";
        }
        else {
            let hasSPClause = false;
            for (let clause of this.clauses.clause) {
                let checked = this.valueObj.clause.filter((item) => item.clauseCode == clause.clauseCode);
                if (checked.length > 0)
                    hasSPClause = true;
            }

            if (hasSPClause == false) {
                result.isValid = false;
                result.message = "<p>Add at-least one special clause.</p>";
            }
            else
                result.isValid = true;
        }
        return result;
    }
}