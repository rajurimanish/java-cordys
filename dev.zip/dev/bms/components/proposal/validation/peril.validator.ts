import { Validator, ValidationResult } from '../../../../common/components/validator/validator';
import { Peril } from "../newbusinessrisks/appobjects/peril";

export class PerilValidator extends Validator {
    public fields: Array<any> = ["fireAndLightingRate"
    ];
    constructor(perilObj: Peril) {
        super();
        this.valueObj = perilObj;
        this.requiredFields = this.fields;
    }

    public validate() {
        let result = super.validate();
        if (result.isValid == true) {
            if (Number(this.valueObj.fireAndLightingRate) <= 0) {
                result.isValid = false;
                result.message = "Provide proper value in Fire And Lighting Rate field in Perils Information section.";
            }
        }
        else {
            result.message = "Provide proper value in Fire And Lighting Rate field in Perils Information section.";
        }
        return result;
    }

}