/*
Change History	:

	No      Date          Description                                 Changed By
	====    ==========    ===========                                 ==========
	GA001   28/02/2018    MYS-2017-1109-TAA Group Policy in 
						  BMS Should Allow Multiple Insured Persons  	KGA				 
	KA001   13/06/2018    MYS-2018-0678-To make gender and occupation 
						  code non mandatory  					   	    DKA
*   GA001   19/10/2018    MYS-2018-1291 : Incorrect rounding of 
 *                      Total share percentage of Nominee Details	  KGA
 *  GA002   11/03/2019   MYS-2019-0210 : Leap Year issue in BMS System- renewal case KGA
 *  GA003   12/04/2019    MYS-2018-1352 - TAA – Update Group Validation Checking  KGA		 								   
*/
import { Validator, ValidationResult } from '../../../../common/components/validator/validator';
import { Travel } from '../newbusinessrisks/travel/appobjects/travel';
import { NomineeValidator } from './nominee.validator';
import { GSTDetilsValidator } from './gstdetails.validator';
import { BMSConstants } from '../../common/constants/bms_constants';
import { AppUtil } from '../../../../common/components/utility/apputil/app.util';

declare var moment: any;
declare var numeral: any;//GA001

export class TravelValidator extends Validator {
    public fields: Array<any> = ["plan",
        "coverRequired",
        "coverageType",
        "destinationArea",
        "travelFromDate",
        "travelToDate",
        "ratingFlag",
        "noOfAdults",
        "RIRetentionCode",
        "basicPremium",
        "capitalSumInsured"];

    public fieldNames: any = {
        plan: "Plan",
        coverRequired: "Persons Cover",
        coverageType: "Coverage Type",
        destinationArea: "For Overseas (outbound)",
        travelFromDate: "Tarvel Period: From",
        travelToDate: "Tarvel Period: To",
        ratingFlag: "Rating Flag",
        noOfAdults: "Number of Adults",
        RIRetentionCode: "RI Retention Code",
        basicPremium: "Basic Premium",
        capitalSumInsured: "Capital Sum Insured",
        "GSTDetails.riskUsage": "GST Risk Usage",
        "GSTDetails.riskLocation": "GST Risk Location",
        "GSTDetails.placeOfRecidence": "GST Place of Residence"
    };

    constructor(travel: Travel) {
        super();
        this.valueObj = travel;
        this.requiredFields = this.fields;
    }

    private childrenAllowed = 'N';

    public validate() {
        let result = super.validate();
        let validHeaderMandatoryFields: boolean = true;

        if (result.isValid == false) {
            validHeaderMandatoryFields = false;
            result.message = this.valueObj.riskType + " (Risk Number: " + this.valueObj.riskNumber + " ): <p>Provide value for all mandatory fields.</p>" + this.getInvalidFields(result, this.fieldNames);
        }

        if (this.valueObj.benefitDetails.benefit == null || this.valueObj.benefitDetails.benefit == "" || this.valueObj.benefitDetails.benefit.length == 0) {
            result.isValid = false;
            result.message = result.message + "<br>Please select Plan, Persons Cover, Coverage Type and For Overseas (outbound).";
        } else if (this.valueObj.isCustomizedPlan == 'Y') {
            let isRatePresent: boolean = false;
            // let isRateOrLoadPresent:boolean = false;
            for (let _benefit of this.valueObj.benefitDetails.benefit) {
                let _rate = (_benefit.rate == null || _benefit.rate == "" || !_benefit.rate) ? 0 : parseFloat(_benefit.rate);
                let _load = (_benefit.load == null || _benefit.load == "" || !_benefit.load) ? 0 : parseFloat(_benefit.load);

                // if( (parseFloat(""+_rate) >0 || parseFloat(""+_load) >0) &&  parseFloat(_benefit.premium) > 0) {
                // isRateOrLoadPresent= true;
                // break;
                // }
                if (parseFloat("" + _rate) > 0 && parseFloat(_benefit.premium) > 0) {
                    isRatePresent = true;
                    break;
                }
            }

			/*if(!isRateOrLoadPresent){
				result.isValid = false;
				result.message = result.message + "<br>Please enter Rate and Load % in Benefit Details Section.";
			}*/
            if (!isRatePresent) {
                result.isValid = false;
                result.message = result.message + "<br>Please enter Rate in Benefit Details Section.";
            }
            let _basicPremium = parseFloat("" + this.valueObj.basicPremium);
            if (_basicPremium <= 0) {
                result.isValid = false;
                result.message = result.message + "<br>Basic Premium is not valid.";
            }

            if (parseFloat("" + this.valueObj.capitalSumInsured) <= 0) {
                result.isValid = false;
                result.message = result.message + "<br>Capital Sum Insured is mandatory.";
            }
        }

        let nomineeResult = this.validateNomioneeDetails();
        if (nomineeResult.isValid == false) {
            result.isValid = false;
            result.message = result.message + nomineeResult.message;
        }

        //GA001 START-no of insured validations
        let noOfAdultsResult = new ValidationResult();
        if (this.valueObj.groupInd == 'N') {
            noOfAdultsResult = this.validateNoOfAdults();
            if (noOfAdultsResult.isValid == false) {
                result.isValid = false;
                result.message = noOfAdultsResult.message + result.message;
            }
        }
        //GA001 END

        let validationConfiResponse = BMSConstants.getTravelInsuredConfig();
        if (validationConfiResponse) {
            if (validationConfiResponse.tuple) {
                if (Array.prototype.isPrototypeOf(validationConfiResponse.tuple)) {
                    this.childrenAllowed = 'Y';
                }
                else if (validationConfiResponse.tuple.old && validationConfiResponse.tuple.old.T7302) {
                    this.childrenAllowed = 'Y';
                }
            }
        }

        if (this.valueObj.travelFromDate && this.valueObj.travelToDate) {
            let trvPeriodValConfiResponse = BMSConstants.getTravelPeriodValidationsConfig();
            if (trvPeriodValConfiResponse) {
                if (trvPeriodValConfiResponse.tuple) {
                    let trvPeriodValConfigObj: any;
                    if (Array.prototype.isPrototypeOf(trvPeriodValConfiResponse.tuple)) {
                        trvPeriodValConfigObj = trvPeriodValConfiResponse.tuple[0].old.T7261;
                    }
                    else if (trvPeriodValConfiResponse.tuple.old && trvPeriodValConfiResponse.tuple.old.T7261) {
                        trvPeriodValConfigObj = trvPeriodValConfiResponse.tuple.old.T7261
                    }
                    if (trvPeriodValConfigObj && this.valueObj.riskType == trvPeriodValConfigObj.DESCITEM) {
                        let _minDays = parseFloat("" + trvPeriodValConfigObj.MINDAY);
                        let _maxDays = parseFloat("" + trvPeriodValConfigObj.MAXDAY);

                        //GA002 START
                        if (_minDays == 365 || _maxDays == 365) {
                            let _travelFromDate = moment(this.valueObj.travelFromDate, "YYYY-MM-DD").format("YYYY-MM-DD");
                            let _travelToDate = moment(this.valueObj.travelToDate, "YYYY-MM-DD").format("YYYY-MM-DD");
                            let isLeapYear = false;
                            if ((Number(_travelFromDate.substring(0, 4)) % 4 == 0 && Number(_travelFromDate.substring(5, 7)) < 3) ||
                                (Number(_travelToDate.substring(0, 4)) % 4 == 0 && Number(_travelToDate.substring(5, 7)) > 2)) {
                                isLeapYear = true;
                            }
                            if (Number(_travelToDate.substring(0, 4)) % 4 == 0 && Number(_travelToDate.substring(5, 7)) == 2 && Number(_travelToDate.substring(8, 10)) == 29) {
                                isLeapYear = true;
                            }
                            if (isLeapYear) {
                                if (_minDays == 365)
                                    _minDays++;
                                if (_maxDays == 365)
                                    _maxDays++;
                            }
                        }
                        //GA002 END

                        if (this.valueObj.travelDays < _minDays) {
                            result.isValid = false;
                            result.message = "<br>Travel cannot be less than" + _minDays + " days" + result.message;
                        }
                        if (this.valueObj.travelDays > _maxDays) {
                            result.isValid = false;
                            result.message = "<br>Travel Days cannot be more than " + _maxDays + " days" + result.message;
                        }
                    }
                }
            }

        }

        // let isAdultAdded:boolean= false;
        let isChildAdded: boolean = false;
        // let isOtherCriteria:boolean= false;

        if (this.valueObj.insuredDetails.insured && this.valueObj.insuredDetails.insured.length > 0) {

            for (let _ins of this.valueObj.insuredDetails.insured) {
                if (_ins.DOB && _ins.DOB != '99999999') {
                    let _effectiveDate = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.effectiveDate;
                    _effectiveDate = moment(_effectiveDate, "YYYY-MM-DD");
                    let _date = moment(_ins.DOB, "YYYY-MM-DD").format("YYYY-MM-DD");

                    let diffDuration = moment.duration(_effectiveDate.diff(_date));
                    let _years = diffDuration.years();
                    let _months = diffDuration.months();
                    let _days = diffDuration.days();
                    if ((_years < 18 || (_years == 18 && _months == 0 && _days == 0)) && !(_years == 0 && _months == 0 && _days < 30)) {
                        isChildAdded = true;
                    }
                }
            }
        }

        if (this.childrenAllowed == 'Y') {
            //GA001 START
            let noOfChildrenResult = new ValidationResult();
            if (this.valueObj.groupInd == 'N') {
                //GA001 END
                noOfChildrenResult = this.validateNoOfChildren();
                if (noOfChildrenResult.isValid == false) {
                    result.isValid = false;
                    result.message = noOfChildrenResult.message + result.message;
                }

                let _noOfChildren = this.valueObj.noOfChildren;
                if (!_noOfChildren) {
                    _noOfChildren = 0;
                } else { _noOfChildren = parseInt("" + _noOfChildren); }

                if (_noOfChildren > 0 && !isChildAdded) {
                    result.isValid = false;
                    result.message = result.message + "<br>No Insured added with age in 30 days to 18 years range";
                }
            }//GA001
			/*
			if(_noOfChildren > 0 && this.valueObj.insuredDetails.insured && this.valueObj.insuredDetails.insured.length > 0 ){
				let isAdded:boolean= false;
				for(let _ins of this.valueObj.insuredDetails.insured){
					if( _ins.DOB && _ins.DOB != '99999999'){
						let _effectiveDate = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.effectiveDate;
						_effectiveDate = moment(_effectiveDate, "YYYY-MM-DD");
						let _date = moment(_ins.DOB, "YYYY-MM-DD").format("YYYY-MM-DD");
						// let insuredAge = curDate.diff(_date, 'year');
						
						let diffDuration = moment.duration(_effectiveDate.diff(_date));
						let _years = diffDuration.years();
						let _months = diffDuration.months();
						let _days = diffDuration.days();
						if( (_years < 18 || (_years ==18 && _months == 0 && _days== 0) ) && (_years > 0 && _months > 0) ){
							isAdded = true;
						}
					}
				}
				if(!isAdded){
					result.isValid = false;
					result.message = result.message + "<br>No Insured added with age in 30 days to 18 years range";
				}
			}*/
        }

		/*
		if(this.valueObj.riskType =='TAA' || this.valueObj.riskType =='TDA' || this.valueObj.riskType =='TDI' || this.valueObj.riskType =='TPI'){
			// this.valueObj.noOfAdults > 0
		}	
		if(this.valueObj.riskType =='TAA' && this.valueObj.destinationArea == 'L'){
			//GST details Mandatory
		}
		
		if(this.valueObj.riskType =='TAA'){
			//Travel Period cannot more than 185 days
		}
		*/

		/*let _noOfAdults = this.valueObj.noOfAdults;
		if(!_noOfAdults) {
			_noOfAdults = 0;
		} else { _noOfAdults = parseInt(""+_noOfAdults); }
		
		let _noOfChildren = this.valueObj.noOfChildren;
		if(!_noOfChildren) {
			_noOfChildren = 0;
		} else { _noOfChildren = parseInt(""+_noOfChildren); }
		
		if( (this.valueObj.noOfAdults > 0 || this.valueObj.noOfChildren > 0) && (!this.valueObj.insuredDetails.insured || this.valueObj.insuredDetails.insured.length != (_noOfAdults+_noOfChildren)) ){
			result.isValid = false;
			result.message = result.message + "<br>Insured Details not provided.";
		}*/

        let insuredValidationResult = this.validateInsuredDetails();
        if (insuredValidationResult.isValid == false) {
            result.isValid = false;
            result.message = insuredValidationResult.message;
            return result;
        }

        let gstDetailsResult = new GSTDetilsValidator(this.valueObj).validate();
        if (gstDetailsResult.isValid == false) {
            result.isValid = false;
            result.message = result.message + gstDetailsResult.message;
            return result;//new code;
        }

        if (this.valueObj.certNo) {
            let agentDetailsResp = BMSConstants.getBmsUtilServiceObj().getAgentCertificateDetails(this.valueObj.certNo);
            if (agentDetailsResp && agentDetailsResp.tuple && agentDetailsResp.tuple.old && agentDetailsResp.tuple.old.WTRC) {
                if (agentDetailsResp.tuple.old.WTRC.CHDRNUM) {
                    result.isValid = false;
                    result.message = result.message + "<br>Certificate number is already utilized.";
                }
            }
            else {
                result.isValid = false;
                result.message = result.message + "<br>Not a valid Certificate number for the Agent selected.";
            }
        }

		/*if(this.valueObj.RIRetentionCode){
			let netRetnAmntDetResp = BMSConstants.getBmsUtilServiceObj().getNetRetentionAmountDetails(this.valueObj.RIRetentionCode);
			if(netRetnAmntDetResp && netRetnAmntDetResp.tuple ){
				let _ary = new AppUtil().getArray(netRetnAmntDetResp.tuple);
				
				if(_ary && _ary.length >0){
					
					let _netRetAmnt = parseFloat(""+_ary[0].old.T4944.RETOTS);
					let _capitalSumInsured = parseFloat(""+this.valueObj.capitalSumInsured);
					if(_netRetAmnt > 0 && _capitalSumInsured > _netRetAmnt && (this.valueObj.RIMethod==1||this.valueObj.RIMethod=="1") ){
						result.isValid = false;			
						result.message = result.message + "<p>Capital Sum Insured is greater than Net Retention amount limit : "+_netRetAmnt+", and RI Required must be 'Yes'</p>";
					}
				}			
			}
		}*/

        if (!result.isValid && validHeaderMandatoryFields) {
            result.message = this.valueObj.riskType + " (Risk Number: " + this.valueObj.riskNumber + " ): <p>Provide value for all mandatory fields.</p>" + result.message;
        }
		//VK004 General Page Text
		let headerInfo = BMSConstants.getBMSHeaderInfo();
		if(Number(this.valueObj.gpTextCount) > Number(headerInfo.gpTextMaxLines)) {
			result.isValid = false;
			result.message = this.valueObj.riskType+" (Risk Number: "+this.valueObj.riskNumber+" ): General Page Text entered is more than 400 lines.";
		}
		//VK004 END

        return result;
    }

    validateNomioneeDetails() {
        let result = new ValidationResult();
        result.isValid = true;
        if (this.valueObj.nomineeDetails != null) {

            if (this.valueObj.nomineeDetails.nominee != undefined && !(this.valueObj.nomineeDetails.nominee.constructor === Array)) {
                let nomineeItems: any = this.valueObj.nomineeDetails.nominee;
                this.valueObj.nomineeDetails.nominee = [nomineeItems];
            }

            if (this.valueObj.nomineeDetails.nominee.length > 0) {
                let percentageTotal: number = 0;
                for (let nominee of this.valueObj.nomineeDetails.nominee) {

                    // result.fields.push("nomineeDetails");
                    let nomineeValid = new NomineeValidator(nominee).validate();
                    if (nomineeValid.isValid == false) {
                        result.isValid = false;
                        result.message = result.message + nomineeValid.message;
                        result.childsResult["nomineeDetails"] = nomineeValid;
                        result.validationResult["nomineeDetails"] = nomineeValid.isValid;
                        return result;
                    }
                    else {
                        //GA001 START
                        //percentageTotal = Number(percentageTotal) + Number(nominee.percentageOfShare);
                        percentageTotal = numeral(percentageTotal).add(parseFloat(nominee.percentageOfShare)).value();
                        //GA001 END
                    }
                }
                if (percentageTotal != 100) {
                    let nomineeDetails: ValidationResult = new ValidationResult();
                    nomineeDetails.isValid = false;
                    result.isValid = false;
                    nomineeDetails.message = "<br>Nominee Percentage Share Total is not equal to 100. Please make sure the total is equal to 100";
                    result.message = result.message + nomineeDetails.message;
                    result.childsResult["nomineeDetails"] = nomineeDetails;
                    result.validationResult["nomineeDetails"] = nomineeDetails.isValid;
                    return result;
                }
            }
        }
        return result;
    }

    validateInsuredDetails() {
        let insuredDetailsResult: ValidationResult = new ValidationResult();
        insuredDetailsResult.isValid = true;

        if (this.valueObj.insuredDetails != null && this.valueObj.insuredDetails.insured != null && this.valueObj.insuredDetails.insured.length > 0) {
            let _insuredListArr = new AppUtil().getArray(this.valueObj.insuredDetails.insured);

            let _noOfAdults = this.valueObj.noOfAdults;
            if (!_noOfAdults) {
                _noOfAdults = 0;
            } else { _noOfAdults = parseInt("" + _noOfAdults); }

            let _noOfChildren = this.valueObj.noOfChildren;
            if (!_noOfChildren) {
                _noOfChildren = 0;
            } else { _noOfChildren = parseInt("" + _noOfChildren); }

            if ((this.valueObj.noOfAdults > 0 || this.valueObj.noOfChildren > 0) && (!this.valueObj.insuredDetails.insured || this.valueObj.insuredDetails.insured.length != (_noOfAdults + _noOfChildren))) {
                insuredDetailsResult.isValid = false;
                insuredDetailsResult.message = "<br>Enter all Insured Details.";
            }
            // !_insured.gender || !_insured.occupationCode  Divek removed this from below condition 0678
            for (let _insured of _insuredListArr) {
                if (!_insured.name || (!_insured.nric && !_insured.ICPassport) || !_insured.DOB) {
                    if (insuredDetailsResult.isValid) {
                        insuredDetailsResult.isValid = false;
                        insuredDetailsResult.message = "<br>Enter all mandatory fields in Insured Information section.";
                    } else {
                        insuredDetailsResult.message = insuredDetailsResult.message + "<br>Enter all mandatory fields in Insured Information section.";
                    }
                    break;
                }
                if ("L" == _insured.ageLimitFlag) {
                    insuredDetailsResult.isValid = false;
                    insuredDetailsResult.message = "<br>Insured age is less than minimum age.";
                }
            }

        } else {
            insuredDetailsResult.isValid = false;
            insuredDetailsResult.message = "<br>Enter insured details in Insured Information section.";
        }
        return insuredDetailsResult;
    }

    validateNoOfAdults() {
        let noOfAdultsResult = new ValidationResult();
        noOfAdultsResult.isValid = true;

        let _noOfAdults = this.valueObj.noOfAdults;
        if (!_noOfAdults) {
            _noOfAdults = 0;
        }

        let noOfAdults = parseInt("" + _noOfAdults);

        //GA001 START
        let _noOfChildren = this.valueObj.noOfChildren;
        if (!_noOfChildren) {
            _noOfChildren = 0;
        }

        let noOfChildren = parseInt("" + _noOfChildren);
        //GA001 END

        if (this.valueObj.coverRequired == '1') {
            if (noOfAdults > 1) {
                noOfAdultsResult.isValid = false;
                noOfAdultsResult.message = "<br>Number of Adults: Total Adult exceeded";
                // this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Total Adult exceeded" , 3000));
            }
            if (noOfAdults <= 0 && noOfChildren == 0) {//GA001
                noOfAdultsResult.isValid = false;
                noOfAdultsResult.message = "<br>Number of Adults: Enter atleast one Adult";
                // this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Enter atleast one Adult" , 3000));
            }
        }
        else if (this.valueObj.coverRequired == '2') {
            if (noOfAdults > 2) {
                noOfAdultsResult.isValid = false;
                noOfAdultsResult.message = "<br>Number of Adults: Total Adult exceeded";
                // this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Total Adult exceeded" , 3000));
            }
            else if (noOfAdults < 2) {
                noOfAdultsResult.isValid = false;
                noOfAdultsResult.message = "<br>Number of Adults: Two adults are only allowed";
                // this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Two adults are only allowed" , 3000));
            }
        }
        else if (this.valueObj.coverRequired == '3') {
            if (noOfAdults > 1) {
                noOfAdultsResult.isValid = false;
                noOfAdultsResult.message = "<br>Number of Adults: Total Adult exceeded";
                // this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Total Adult exceeded" , 3000));
            }
            else if (noOfAdults < 1) {
                noOfAdultsResult.isValid = false;
                noOfAdultsResult.message = "<br>Number of Adults: Enter atleast one Adult";
                // this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Enter atleast one Adult" , 3000));
            }
        }
        else if (this.valueObj.coverRequired == '4') {
            if (noOfAdults > 2) {
                noOfAdultsResult.isValid = false;
                noOfAdultsResult.message = "<br>Number of Adults: Total Adult exceeded";
                // this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Total Adult exceeded" , 3000));
            }
            if (noOfAdults < 1) {
                noOfAdultsResult.isValid = false;
                noOfAdultsResult.message = "<br>Number of Adults: Enter atleast one Adult";
                // this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Enter atleast one Adult" , 3000));
            }
        }
        return noOfAdultsResult;
    }

    validateNoOfChildren() {
        let noOfChildrenResult = new ValidationResult();
        noOfChildrenResult.isValid = true;

        let _noOfChildren = this.valueObj.noOfChildren;
        if (!_noOfChildren) {
            _noOfChildren = 0;
        }

        let _noOfAdults = this.valueObj.noOfAdults;
        if (!_noOfAdults) {
            _noOfAdults = 0;
        }

        let noOfAdults = parseInt("" + _noOfAdults);
        let noOfChildren = parseInt("" + _noOfChildren);

        if (this.valueObj.coverRequired == '1') {
            if (this.childrenAllowed == 'N') {
                if (noOfChildren != 0) {
                    // this.valueObj.noOfChildren =0;
                    noOfChildrenResult.isValid = false;
                    noOfChildrenResult.message = "<br> Number of Children: Children not covered plan.";
                }
            }
            else if (this.childrenAllowed == 'Y') {
                if (noOfAdults == 0 && noOfChildren == 0) {
                    noOfChildrenResult.isValid = false;
                    noOfChildrenResult.message = "<br> Number of Children; Enter atleast on child.";
                }
                //GA003 START
				/*if(noOfAdults > 0 && noOfChildren > 1){//Commented
					noOfChildrenResult.isValid = false;
					noOfChildrenResult.message = "<br> Number of Children; Total Children Exceeded.";
				}*/
				if(noOfAdults > 0 && noOfChildren >= 1){
					noOfChildrenResult.isValid = false;
					noOfChildrenResult.message = "<br> Number of Children; Total Children Exceeded.";
				}
				//GA003 END
            }

            // if(this.childrenAllowed == 'Y' && noOfChildren > 1){
            // noOfChildrenResult.isValid = false;
            // noOfChildrenResult.message = "<br>Number of Children: Total Children exceeded";
            // // this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Total Children exceeded" , 3000));
            // }
            // if(this.childrenAllowed == 'Y' && noOfChildren <=0){
            // noOfChildrenResult.isValid = false;
            // noOfChildrenResult.message = "<br>Number of Children: Enter atleast one Child.";
            // // this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Enter atleast one Child." , 3000));
            // }
        }
        else
            if (this.valueObj.coverRequired == '2' && noOfChildren != 0) {
                this.valueObj.noOfChildren = 0;
                noOfChildrenResult.isValid = false;
                noOfChildrenResult.message = "<br>Number of Children: Children not covered plan.";
                // this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Children not covered plan" , 3000));
            }
            else
                if (this.valueObj.coverRequired == '3') {
                    if (this.childrenAllowed == 'Y' && noOfChildren <= 0) {
                        noOfChildrenResult.isValid = false;
                        noOfChildrenResult.message = "<br>Number of Children: Enter atleast one Child.";
                        // this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Enter atleast one Child." , 3000));
                    }
                    // if(this.childrenAllowed == 'N' && noOfChildren !=0){
                    if (noOfChildren != 0) {
                        noOfChildrenResult.isValid = false;
                        noOfChildrenResult.message = "<br>Number of Children: Children not covered plan.";
                        // this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Children not covered plan" , 3000));
                    }
                }
                else
                    if (this.valueObj.coverRequired == '4' && noOfChildren <= 0) {
                        noOfChildrenResult.isValid = false;
                        noOfChildrenResult.message = "<br>Number of Children: Enter atlease on Child.";
                        // this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Enter atlease on Child" , 3000));
                    }

        return noOfChildrenResult;
    }

}