import { Validator, ValidationResult } from '../../../../common/components/validator/validator';
import { GSTDetilsValidator } from './gstdetails.validator';
import { FinancialInterstValidator } from './financialinterest.validator';
import { Generic } from '../newbusinessrisks/generic/appobjects/generic';
import { BMSConstants } from '../../common/constants/bms_constants';
import { AppUtil } from '../../../../common/components/utility/apputil/app.util';

export class GenericValidator extends Validator {
    public fields: Array<any> = [
        "GSTDetails.riskUsage",
        "GSTDetails.riskLocation",
        "GSTDetails.placeOfRecidence"
    ];
    public fieldNames: any = {
        "GSTDetails.riskUsage": "GST Risk Usage",
        "GSTDetails.riskLocation": "GST Risk Location",
        "GSTDetails.placeOfRecidence": "Place of Residence / Business",
        "GSTDetails.inputTaxAllowed": "Input Tax Allowed?"
    };
    constructor(generic: Generic) {
        super();
        this.valueObj = generic;
        this.requiredFields = this.fields;
    }

    public validate() {

        this.setMandatoryFields();

        let result = super.validate();
        let validHeaderMandatoryFields: boolean = true;
        if (result.isValid == false) {
            validHeaderMandatoryFields = false;
            result.message = this.valueObj.riskType + " (Risk Number: " + this.valueObj.riskNumber + " ): <p>Provide value for all mandatory fields.</p>" + this.getInvalidFields(result, this.fieldNames);
        }
        //Endorsements Code added below condition
        let bFuntion = BMSConstants.getBMSCaseInfo().businessFunction;
        if ( !( bFuntion == 'Endorsements' || bFuntion == 'Cancellations' || bFuntion == "Reinstatement" )) {
            let coverageResult = this.coverageValidator();
            if ( coverageResult.isValid == false ) {
                result.isValid = false;
                result.message = result.message + coverageResult.message;
            }
        }
        
        //Endorsements Code
        
        if ( bFuntion == 'Endorsements' && (this.valueObj.subjectivities == null || this.valueObj.subjectivities == "" || this.valueObj.subjectivities.length == 0 )) {
            result.isValid = false;
            result.message = "<p>Please add Description in Endorsements Request screen.</p>";
        }
        if ( ( bFuntion == 'Endorsements' || bFuntion == 'Cancellations' ) && (this.valueObj.riskClassification == undefined || this.valueObj.riskClassification == "") ) {
            result.isValid = false;
            result.message = result.message + "<p>Please select RiskClassification in Endt Request screen.</p>";
        }
        
        //End

        let gstDetailsResult = new GSTDetilsValidator(this.valueObj).validate();
        if (gstDetailsResult.isValid == false) {
            result.isValid = false;
            result.message = result.message + gstDetailsResult.message;
        }

        if (this.valueObj.FI == "Y") {
            let financialInterestValResult = new FinancialInterstValidator(this.valueObj).validate();
            if (financialInterestValResult.isValid == false) {
                result.isValid = false;
                if (result.message == null || result.message == "") {
                    result.message = financialInterestValResult.message;
                } else
                    result.message = result.message + financialInterestValResult.message;
            }
        }

        if (!result.isValid && validHeaderMandatoryFields) {
            result.message = this.valueObj.riskType + " (Risk Number: " + this.valueObj.riskNumber + " ): <p>Provide value for all mandatory fields.</p>" + result.message;
        }

        return result;
    }

    setMandatoryFields() {

    }

    customFieldsHandler() {
        let customFieldsArr: any = [];
        if (Array.prototype.isPrototypeOf(this.valueObj.customFields.customField)) {
            customFieldsArr = this.valueObj.customFields.customField;
        } else {
            customFieldsArr = [this.valueObj.customFields.customField];
        }

        if (customFieldsArr.length > 0) {
            let temp = [];
            for (let customField of customFieldsArr) {
                if (customField.label != null && customField.label != '')
                    temp.push(customField);
            }

            customFieldsArr = temp;
            this.valueObj.customFields.customField = customFieldsArr;
        }
    }

    private coverageValidator() {
        let result = new ValidationResult();
        if (this.valueObj.riskCoverageDetails.riskCoverage == null || this.valueObj.riskCoverageDetails.riskCoverage == "") {
            result.isValid = false;
            result.message = "<p>Add cover in Coverage Information section.</p>";
        }
        else {
            let riskCoverageItemsArr: any = [];
            if (Array.prototype.isPrototypeOf(this.valueObj.riskCoverageDetails.riskCoverage)) {
                riskCoverageItemsArr = this.valueObj.riskCoverageDetails.riskCoverage;
            } else {
                riskCoverageItemsArr = [this.valueObj.riskCoverageDetails.riskCoverage];
            }

            if (riskCoverageItemsArr.length > 0) {

                result.isValid = true;
                if (this.valueObj.riskType != 'PP2') {
                    let isRateGtRftRate: boolean = true;
                    for (let coverageItem of riskCoverageItemsArr) {
                        // if((coverageItem.interestInsured == null || coverageItem.interestInsured == "") || (coverageItem.sumInsured == null || coverageItem.sumInsured <=0) || (coverageItem.rate == null || coverageItem.rate <=0) || (coverageItem.premium == null || parseFloat(""+coverageItem.premium) <=0) || (coverageItem.premiumClass == null || coverageItem.premiumClass =="")){
                        if (BMSConstants.getBMSHeaderInfo().isSimplifiedProcess != 'Y') {
                            if ((coverageItem.interestInsured == null || coverageItem.interestInsured == "") || (coverageItem.sumInsured == null || coverageItem.sumInsured <= 0) || (coverageItem.rate == null || coverageItem.rate <= 0) || (coverageItem.premiumClass == null || coverageItem.premiumClass == "")) {
                                result.isValid = false;
                            }
                            if ((this.valueObj.riskType == 'AR' || this.valueObj.riskType == 'ME') && coverageItem.rate && parseFloat("" + coverageItem.rate) < parseFloat("" + this.valueObj.RFTRatePercentage)) {
                                isRateGtRftRate = false;
                            }
                        }
                        else {
                            if ((coverageItem.interestInsured == null || coverageItem.interestInsured == "") || (coverageItem.sumInsured == null || coverageItem.sumInsured <= 0) || (coverageItem.premium == null || coverageItem.premium <= 0)) {
                                result.isValid = false;
                            }
                            this.customFieldsHandler();
                        }

                    }

                    if (result.isValid == false) {
                        result.message = "<p>Fill all mandatory fields in Coverage Information section.</p>";
                    } else if (!isRateGtRftRate) {
                        result.isValid = false;
                        result.message = "<p>Rate % must be greater than Fire Basic Rate %</p>";
                    }
                }
            }
            else {
                result.isValid = false;
                result.message = "<p>Add cover in Coverage Information section.</p>";
            }
        }

        return result;
    }

}