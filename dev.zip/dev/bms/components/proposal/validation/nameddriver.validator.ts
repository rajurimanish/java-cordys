import { Validator, ValidationResult } from '../../../../common/components/validator/validator';
import { NamedDriverItem } from '../newbusinessrisks/motorcommercial/appobjects/nameddriver';

export class NamedDriverValidator extends Validator {
    public fields: Array<any> = ["driverName",
        "dateOfBirth",
        "ICNumber",
        "drivingLicense",
        "relationship",
        "sex",
        "occupation"
    ];
    constructor(driverObj: NamedDriverItem) {
        super();
        this.valueObj = driverObj;
        this.requiredFields = this.fields;
    }

    public validate() {
        let result = super.validate();
        if (result.isValid == true) {
            if ((this.valueObj.ICNumber == undefined || this.valueObj.ICNumber == "") && (this.valueObj.oldPassportNo == undefined || this.valueObj.oldPassportNo == "")) {
                result.isValid = false;
                result.message = "Provide either of NRIC or old IC / Passport No.";
            }
        }
        else {
            result.message = "Provide value for all Driver Detail mandatory fields.";
        }

        return result;
    }

}