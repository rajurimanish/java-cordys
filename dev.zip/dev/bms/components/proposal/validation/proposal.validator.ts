import { Validator, ValidationResult } from '../../../../common/components/validator/validator';
import { BMSObject } from '../../common/appobjects/bmsobject';
import { HeaderValidator } from './header.validator';
import { RisksValidator } from './risks.validator';
import { MTIValidator } from './mti.validator';

export class ProposalValidator extends Validator {
    public fields: Array<any> = ["headerInfo",
        "risks",
        "mti"];
    constructor(bmsObject: BMSObject) {
        super();
        this.valueObj = bmsObject;
        this.requiredFields = this.fields;
    }

    public validate() {
        let result = new ValidationResult();
        result.isValid = true;
        let headerResult = new HeaderValidator(this.valueObj.newBusiness.headerInfo).validate();
        if (headerResult.isValid == true) {
            let risksResult = new RisksValidator(this.valueObj.newBusiness.risks).validate();
            if (risksResult.isValid == false) {
                result.isValid = false;
                result.message = "Proposal: Validation failed.<p>" + risksResult.message + "</p>";
            } else {
                let mtiResult = new MTIValidator(this.valueObj).validate();
                if (mtiResult.isValid == false) {
                    result.isValid = false;
                    result.message = "Proposal: Validation failed.<p>" + mtiResult.message + "</p>";
                }
                result.childsResult["mti"] = mtiResult;
            }
            result.childsResult["risks"] = risksResult;

            this.handleWarning(headerResult, risksResult, result);
        } else {
            result.isValid = false;
            result.message = "Proposal: Validation failed.<p>" + headerResult.message + "</p>";
        }
        result.childsResult["headerInfo"] = headerResult;
        return result;
    }

    public handleWarning(headerResult, risksResult, result) {
        if (headerResult.isWarned) {
            result.isWarned = true;
            result.warningMessage = "Proposal Header Warning messages:<p>" + headerResult.warningMessage + "</p>";
        }
        if (risksResult.isWarned) {
            result.isWarned = true;
            result.warningMessage = result.warningMessage + "Proposal Warning messages:<p>" + risksResult.warningMessage + "</p>";
        }
    }
}
