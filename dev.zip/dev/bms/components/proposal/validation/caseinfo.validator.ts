import { Validator, ValidationResult } from '../../../../common/components/validator/validator';
import { CaseInfo } from '../../../../common/components/appobjects/caseinfo';

export class CaseInfoValidator extends Validator {
    public fields: Array<any> = ["accountHandler"];
    public fieldNames: any = { accountHandler: "Account Handler" };
    constructor(caseInfo: CaseInfo) {
        super();
        this.valueObj = caseInfo;
        this.requiredFields = this.fields;
    }

    public validate() {
        let result = super.validate();

        if (result.isValid == false) {
            result.message = "<p>Proposal Header: Provide value for all mandatory fields.</p>" + this.getInvalidFields(result, this.fieldNames);
        }
        return result;
    }

}