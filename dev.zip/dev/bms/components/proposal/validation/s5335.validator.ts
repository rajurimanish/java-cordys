/*
* Change History	:
*
*	No      Date          	Description                Changed By
*	====    ==========    	===========	               ==========	
* 
* 	VK004	06/12/2018		MYS-2018-1192					VKR
*/
import { Validator, ValidationResult } from '../../../../common/components/validator/validator';
import { GSTDetilsValidator } from './gstdetails.validator';
import { S5335, S5336ItemDetails } from '../newbusinessrisks/s5335/appobjects/s5335';
import { S5336Validator } from './s5336.validator';
import { BMSConstants } from '../../common/constants/bms_constants';

export class S5335Validator extends Validator {
    public fields: Array<any> = [
        "insuredPerson",
        "occupationCode",
        "occupationDescription",
        "bigCapitalSumInsured"
    ];
    public fieldNames: any = {
        insuredPerson: "Insured Person",
        occupationCode: "Occupation Code",
        occupationDescription: "Occupation Description",
        bigCapitalSumInsured: "Capital Sum Insured"
    };
    constructor(s5335: S5335) {
        super();
        this.valueObj = s5335;
        this.requiredFields = this.fields;
    }

    public validate() {
        let ageValidFlag: boolean = false;
        let result = super.validate();
        //		if(result.isValid == false){            
        result.message = this.valueObj.riskType + " (Risk Number: " + this.valueObj.riskNumber + " ):Missing fields are:";
        //        }

        if (this.valueObj.occupationCode == undefined || this.valueObj.occupationCode == "") {
            result.isValid = false;
            result.message = result.message + "<p>- Occupation</p>";
        }
        if (this.valueObj.occupationDescription == undefined || this.valueObj.occupationDescription == "") {
            result.isValid = false;
            result.message = result.message + "<p>- Occupation Description</p>";
        }
        if (this.valueObj.insuredPerson == undefined || this.valueObj.insuredPerson == "") {
            result.isValid = false;
            result.message = result.message + "<p>- Insured Person</p>";
        }
        if (this.valueObj.bigCapitalSumInsured <= 0) {
            result.isValid = false;
            result.message = result.message + "<p>- Capital Sum Insured(must be greater than 0, select a plan to auto populate)</p>";
        }
        if (this.valueObj.bigCapitalSumInsured.toString().length > 9) {
            result.isValid = false;
            result.message = result.message + "<p>- Sum Insured is very high. Max allowed is 999999999</p>";
        }
        if (this.valueObj.totalPremium.length > 14) {
            result.isValid = false;
            result.message = result.message + "<br/>- Total Premium is very high for the risk. More than 11 digits.";
        }
        if (this.valueObj.riskType == "PAC" && (this.valueObj.maxPerLifeLimit == "" || this.valueObj.maxPerLifeLimit <= 0)) {
            result.isValid = false;
            result.message = result.message + "<p>- Max Per Life Limit (must be greater than 0 for PAC risk)</p>";
        }

        let gstDetailsResult = new GSTDetilsValidator(this.valueObj).validate();
        if (gstDetailsResult.isValid == false) {
            result.isValid = false;
            result.message = result.message + gstDetailsResult.message;
        }

        //		if(result.isValid == true){
        if (this.hasRisks()) {
            let allRisks = [];
            if (!Array.prototype.isPrototypeOf(this.valueObj.s5336Items.s5336Item)) {
                let tempAry: any = this.valueObj.s5336Items.s5336Item;
                allRisks = [tempAry];
            }
            else {
                allRisks = this.valueObj.s5336Items.s5336Item;
            }
            let count = 1;
            let chCount = 1;
            for (let eachRisk of allRisks) {
                let s5336Result = new S5336Validator(eachRisk).validate();
                if (s5336Result.isChildValid && !ageValidFlag) {
                    ageValidFlag = true;
                    result.message = "";
                }
                if (s5336Result.isValid == false) {
                    result.isValid = false;
                    result.message = result.message + s5336Result.message;
                    count++;
                }
                result.childsResult[this.valueObj.riskType + "" + chCount] = s5336Result;
                chCount++;
            }
        }
        else {
            result.isValid = false;
            result.message = result.message + "<p>- At least one insured is required.</p>";
        }
        //		}
        /*		else{
                    result.message = "<p>"+this.valueObj.riskType+", Risk No: "+this.valueObj.riskNumber+" Provide value for mandatory fields.</p><br/>"+result.message;
                }
        */
        if (this.valueObj.ageLimitFlag != undefined && this.valueObj.ageLimitFlag != "" && 'L' == this.valueObj.ageLimitFlag) {
            result.isValid = false;
            result.message = "<br>Insured age is less than minimum age.";
        }
		//VK004 General Page Text
		let headerInfo = BMSConstants.getBMSHeaderInfo();
		if(Number(this.valueObj.gpTextCount) > Number(headerInfo.gpTextMaxLines)) {
			result.isValid = false;
			result.message = this.valueObj.riskType+" (Risk Number: "+this.valueObj.riskNumber+" ): General Page Text entered is more than 400 lines.";
		}
		//VK004 END
        return result;

    }

    hasRisks() {
        let hasRisk = false;
        if (this.valueObj.s5336Items != null && this.valueObj.s5336Items.s5336Item != null && this.valueObj.s5336Items.s5336Item != "") {
            if (Array.prototype.isPrototypeOf(this.valueObj.s5336Items.s5336Item) && this.valueObj.s5336Items.s5336Item.length > 0) {
                hasRisk = true;
            }
            else if (Array.prototype.isPrototypeOf(this.valueObj.s5336Items.s5336Item) && this.valueObj.s5336Items.s5336Item.length == 0) {
                hasRisk = false;
            }
            else {
                hasRisk = true;
            }
        }
        return hasRisk;
    }
}