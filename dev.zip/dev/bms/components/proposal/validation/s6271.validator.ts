/*
* Change History	:
*
*	No      Date          	Description                Changed By
*	====    ==========    	===========	               ==========	
* 
* 	VK004	06/12/2018		MYS-2018-1192					VKR
*/
import { Validator, ValidationResult } from '../../../../common/components/validator/validator';
import { GSTDetilsValidator } from './gstdetails.validator';
import { S6271, S6272ItemDetails } from '../newbusinessrisks/s6271/appobjects/s6271';
import { S6272Validator } from './s6272.validator';
import { BMSConstants } from '../../common/constants/bms_constants';

export class S6271Validator extends Validator {
    public fields: Array<any> = [
        "insuredPerson",
        "occupationCode",
        "occupationDescription",
        "bigCapitalSumInsured"
    ];
    public fieldNames: any = {
        insuredPerson: "Insured Person",
        occupationCode: "Occupation Code",
        occupationDescription: "Occupation Description",
        bigCapitalSumInsured: "Capital Sum Insured"
    };
    constructor(s6271: S6271) {
        super();
        this.valueObj = s6271;
        this.requiredFields = this.fields;
    }

    public validate() {
		/*let result = super.validate();
//		if(result.isValid == false){            
		    result.message = this.valueObj.riskType+" (Risk Number: "+this.valueObj.riskNumber+" ):Missing fields are:";
//        }
		*/
        let result = new ValidationResult();
        result.isValid = true;
        result.message = this.valueObj.riskType + " (Risk Number: " + this.valueObj.riskNumber + "): Missing fields are:<dl>";

        if (this.valueObj.occupationCode == undefined || this.valueObj.occupationCode == "") {
            result.isValid = false;
            result.message = result.message + "<dd> - Occupation</dd>";
        }
        if (this.valueObj.occupationDescription == undefined || this.valueObj.occupationDescription == "") {
            result.isValid = false;
            result.message = result.message + "<dd> - Occupation Description</dd>";
        }
        if (this.valueObj.insuredPerson == undefined || this.valueObj.insuredPerson == "") {
            result.isValid = false;
            result.message = result.message + "<dd> - Insured Person</dd>";
        }
        if (this.valueObj.bigCapitalSumInsured <= 0) {
            result.isValid = false;
            result.message = result.message + "<dd> - Capital Sum Insured(must be greater than 0, select a plan to auto populate)</dd>";
        }

        let gstDetailsResult = new GSTDetilsValidator(this.valueObj).validate();
        if (gstDetailsResult.isValid == false) {
            result.isValid = false;
            result.message = result.message + gstDetailsResult.message;
        }

        //		if(result.isValid == true){
        if (this.hasRisks()) {
            let allRisks = [];
            if (!Array.prototype.isPrototypeOf(this.valueObj.s6272Items.s6272Item)) {
                let tempAry: any = this.valueObj.s6272Items.s6272Item;
                allRisks = [tempAry];
            }
            else {
                allRisks = this.valueObj.s6272Items.s6272Item;
            }
            let count = 1;
            let chCount = 1;
            for (let eachRisk of allRisks) {
                if(eachRisk.isInsuredTerminated != 'Y'){ // Renewals- Removed Terminated insured validation
                let s6272Result = new S6272Validator(eachRisk).validate();
                if (s6272Result.isValid == false) {
                    result.isValid = false;
                    result.message = result.message + s6272Result.message;
                    count++;
                }
                if (s6272Result.isWarned) {
                    result.isWarned = true;
                    result.warningMessage = result.warningMessage + s6272Result.warningMessage;
                }
                result.childsResult[this.valueObj.riskType + "" + chCount] = s6272Result;
            }
                chCount++;
            }
        }
        else {
            result.isValid = false;
            result.message = result.message + "<dd> - At least one insured is required.</dd>";
        }
        //		}
        /*		else{
                    result.message = "<p>"+this.valueObj.riskType+", Risk No: "+this.valueObj.riskNumber+" Provide value for mandatory fields.</p><br/>"+result.message;
                }
                */

        result.message = result.message + "</dl>";
		//VK004 General Page Text
		let headerInfo = BMSConstants.getBMSHeaderInfo();
		if(Number(this.valueObj.gpTextCount) > Number(headerInfo.gpTextMaxLines)) {
			result.isValid = false;
			result.message = this.valueObj.riskType+" (Risk Number: "+this.valueObj.riskNumber+" ): General Page Text entered is more than 400 lines.";
		}
		//VK004 END
        return result;

    }

    hasRisks() {
        let hasRisk = false;
        if (this.valueObj.s6272Items != null && this.valueObj.s6272Items.s6272Item != null && this.valueObj.s6272Items.s6272Item != "") {
            if (Array.prototype.isPrototypeOf(this.valueObj.s6272Items.s6272Item) && this.valueObj.s6272Items.s6272Item.length > 0) {
                hasRisk = true;
            }
            else if (Array.prototype.isPrototypeOf(this.valueObj.s6272Items.s6272Item) && this.valueObj.s6272Items.s6272Item.length == 0) {
                hasRisk = false;
            }
            else {
                hasRisk = true;
            }
        }
        return hasRisk;
    }
}