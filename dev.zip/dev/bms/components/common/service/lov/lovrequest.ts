export interface LOVHandlerRequest {
    configList;
    getLOVRequest(id, filters);
    getListRequest(id, filters, lovFld, respTag, callBckFn);
}