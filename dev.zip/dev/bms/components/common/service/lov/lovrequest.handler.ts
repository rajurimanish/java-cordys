import { GetLOVData, SearchAdvancedConfig, Filter } from '../../../../../common/components/utility/search/search.requests';
import { LOV_Field } from "../../../../../common/services/lovdropdown/lovdropdown.service";

export class LOVRequestHandler {
    public configList = {};
    public getRequest(id, filters) {
        let request: GetLOVData = this.getBaseRequest(id);
        if (request != null && filters != null)
            this.setFilterInfo(request, filters);
        return request;
    }

    public getBaseRequest(id) {
        let config = this.configList[id];
        if (config != null) {
            let request: GetLOVData = new GetLOVData();
            request.BRANCH = config.BRANCH;
            request.LOB = config.LOB;
            request.BUSINESS_FUNCTION = config.BUSINESS_FUNCTION;
            request.PRODUCT = config.PRODUCT;
            request.OPERATION = config.OPERATION;
            request.FORM_NAME = config.FORM_NAME;
            request.FORM_FIELD_NAME = config.FORM_FIELD_NAME;
            request.FIELD_TYPE = config.FIELD_TYPE;
            return request;
        }
        return null;
    }

    public setFilterInfo(request, filters) {
        request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        if (filters != null) {
            request.ADVANCE_CONFIG_XML.FILTERS = new Filter();
            for (let filter of filters) {
                request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push(filter);
            }
        }
    }

    public makeListField(id, filter, lovFld, respTag, callBckFn) {
        let config = this.configList[id];
        if (config != null) {
            return new LOV_Field(config.BRANCH, config.LOB, config.BUSINESS_FUNCTION, config.PRODUCT, config.OPERATION, config.FORM_NAME, config.FORM_FIELD_NAME, config.FIELD_TYPE, filter, respTag, lovFld, callBckFn);
        }
        return null;
    }
}