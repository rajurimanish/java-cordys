/*
Change History	:

	No      Date          Description                               					    Changed By
	====    ==========    ===========                              						   ==========
	MD001   28/02/2017   MYS-2018-0068    -  HD Log: Product field shows as duplicates
	                                         in BMS,Added ProductList                        Madhan									   

*/
import { LOVHandlerRequest } from './lovrequest';
import { LOVRequestHandler } from './lovrequest.handler';

export class BMSLOVRequest extends LOVRequestHandler implements LOVHandlerRequest {
    public configList = {
        "MinPrem": { "BRANCH": "ALL", "LOB": "ALL", "BUSINESS_FUNCTION": "AGENT_PORTAL", "PRODUCT": "ALL", "OPERATION": "ALL", "FORM_NAME": "QuickQuote", "FORM_FIELD_NAME": "MinimumPremium", "FIELD_TYPE": "LOV" },
        "RiskType": { "BRANCH": "ALL", "LOB": "ALL", "BUSINESS_FUNCTION": "ALL", "PRODUCT": "ALL", "OPERATION": "ALL", "FORM_NAME": "ALL", "FORM_FIELD_NAME": "Risk Type", "FIELD_TYPE": "LOV" },
        "StampDuty": { "BRANCH": "ALL", "LOB": "ALL", "BUSINESS_FUNCTION": "NEW BUSINESS", "PRODUCT": "ALL", "OPERATION": "ALL", "FORM_NAME": "ALL", "FORM_FIELD_NAME": "StampDuty", "FIELD_TYPE": "LOV" },
        "SDFromPD": { "BRANCH": "ALL", "LOB": "ALL", "BUSINESS_FUNCTION": "NEW BUSINESS", "PRODUCT": "ALL", "OPERATION": "ALL", "FORM_NAME": "RISKTABLE", "FORM_FIELD_NAME": "SDFromPD", "FIELD_TYPE": "LOV" },
        "COIRequired": { "BRANCH": "ALL", "LOB": "ALL", "BUSINESS_FUNCTION": "NEW BUSINESS", "PRODUCT": "ALL", "OPERATION": "ALL", "FORM_NAME": "HEADER", "FORM_FIELD_NAME": "COIRequired", "FIELD_TYPE": "LOV" },
        "MaxRebate": { "BRANCH": "ALL", "LOB": "ALL", "BUSINESS_FUNCTION": "NEW BUSINESS", "PRODUCT": "ALL", "OPERATION": "ALL", "FORM_NAME": "ALL", "FORM_FIELD_NAME": "MaxRebate", "FIELD_TYPE": "LOV" },
        "PremiumCalculator": { "BRANCH": "ALL", "LOB": "ALL", "BUSINESS_FUNCTION": "NEW BUSINESS", "PRODUCT": "ALL", "OPERATION": "ALL", "FORM_NAME": "PREMIUM_INFO", "FORM_FIELD_NAME": "Premium Calculator", "FIELD_TYPE": "LOOKUP" },
        "Coverage": { "BRANCH": "ALL", "LOB": "MOTOR", "BUSINESS_FUNCTION": "NEW BUSINESS", "PRODUCT": "ALL", "OPERATION": "NEW", "FORM_NAME": "PRIVATE_MOTOR", "FORM_FIELD_NAME": "Coverage", "FIELD_TYPE": "LOV" },
        "CoverNoteType": { "BRANCH": "ALL", "LOB": "MOTOR", "BUSINESS_FUNCTION": "NEW BUSINESS", "PRODUCT": "ALL", "OPERATION": "NEW", "FORM_NAME": "CV TYPE", "FORM_FIELD_NAME": "CV TYPE", "FIELD_TYPE": "LOV" },
        "ContractType": { "BRANCH": "ALL", "LOB": "ALL", "BUSINESS_FUNCTION": "ALL", "PRODUCT": "ALL", "OPERATION": "ALL", "FORM_NAME": "ALL", "FORM_FIELD_NAME": "Contract Type", "FIELD_TYPE": "LOOKUP" },
        "DNTrnCheck": { "BRANCH": "ALL", "LOB": "ALL", "BUSINESS_FUNCTION": "NEW BUSINESS", "PRODUCT": "ALL", "OPERATION": "RR", "FORM_NAME": "RENEWAL_GRID", "FORM_FIELD_NAME": "DN", "FIELD_TYPE": "LOV" },
        "RTCase": { "BRANCH": "ALL", "LOB": "MTR", "BUSINESS_FUNCTION": "NEW BUSINESS", "PRODUCT": "MTR", "OPERATION": "RT", "FORM_NAME": "RT", "FORM_FIELD_NAME": "RT", "FIELD_TYPE": "LOV" },
        "DefaultState": { "BRANCH": "ALL", "LOB": "MTR", "BUSINESS_FUNCTION": "NEW BUSINESS", "PRODUCT": "MTR", "OPERATION": "ALL", "FORM_NAME": "MTRSCREEN", "FORM_FIELD_NAME": "STATE", "FIELD_TYPE": "LOV" },
        "ProductList": { "BRANCH": "ALL", "LOB": "ALL", "BUSINESS_FUNCTION": "NEW BUSINESS", "PRODUCT": "ALL", "OPERATION": "ALL", "FORM_NAME": "ALL", "FORM_FIELD_NAME": "Product List", "FIELD_TYPE": "LOOKUP" }//MD001


    };

    public getLOVRequest(id, filters) {
        return this.getRequest(id, filters);
    }

    public getListRequest(id, filters, lovFld, respTag, callBckFn) {
        return this.makeListField(id, filters, lovFld, respTag, callBckFn);
    }
}