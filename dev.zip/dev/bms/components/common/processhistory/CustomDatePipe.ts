import { Pipe, PipeTransform } from '@angular/core';

declare var moment: any;

@Pipe({ name: "stringAsDate" })
export class CustomDatePipe implements PipeTransform {
    transform(value: string, args: any[]): any {

        if (value && value !== "") {
            var dateValue = moment.utc(value).local().format("DD-MMM-YYYY HH:mm:ss");
            return dateValue;
        }
    }
}