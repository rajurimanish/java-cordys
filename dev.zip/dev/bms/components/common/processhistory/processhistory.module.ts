import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { ProcessHistoryComponent } from './processhistory.component';
import { CustomDatePipe } from './CustomDatePipe';

@NgModule({
    imports: [CommonModule, FormsModule, ReactiveFormsModule],
    exports: [ProcessHistoryComponent, CustomDatePipe],
    declarations: [ProcessHistoryComponent, CustomDatePipe]
})
export class ProcessHistoryModule { }