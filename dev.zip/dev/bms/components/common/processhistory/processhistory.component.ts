import { Component } from '@angular/core';
import { CustomDatePipe } from "./CustomDatePipe";
import { OnInit } from "@angular/core";
import { ProcessHistory } from "../../../../common/components/appobjects/processhistory"

declare var jQuery: any;

@Component({
    selector: 'process-history',
    templateUrl: 'app/bms/components/common/processhistory/processhistory.template.html',
    inputs: ["approvalNodes"]
})

export class ProcessHistoryComponent implements OnInit {

    public approvalNodes: ProcessHistory;
    private isMobile: boolean = false;

    constructor() { }

    ngOnInit(): any {
        this.isMobileDevice();
    }

    private isMobileDevice() {
        if (window.innerWidth <= 800 && window.innerHeight <= 600) {
            this.isMobile = true;
        } else {
            this.isMobile = false;
        }
    }

    private onWindowResize() {
        this.isMobileDevice();
    }
}