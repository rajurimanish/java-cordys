import { BMSType } from './bms_types';

export class BMSConstants {
    private static BMS_TYPE: BMSType;

    public static TEMPOBJ = { ISASSESSMENTCOMPLETED: "N", COMPONENT: "", ROUTEPRM_TYPE: "", PH_UNAME: "", ISSIMPLIFIEDPROCESS: "N" };

    constructor() { }

    public static getBMSType() {
        return BMSConstants.BMS_TYPE;
    }

    public static getTempObj() {
        return BMSConstants.TEMPOBJ;
    }

    public static setBMSType(type) {
        BMSConstants.BMS_TYPE = type;
    }

    public static setUserName(name) {
        BMSConstants.TEMPOBJ.PH_UNAME = name;
    }

    public static getUserName() {
        return BMSConstants.TEMPOBJ.PH_UNAME;
    }

    public static setStatus(statusVal) {
        let appObj = BMSConstants.getBMSObj();
        appObj.ApplicationBusinessObject.caseInfo.status = statusVal;
        appObj.ApplicationBusinessObject.processObject.workflowStatus = statusVal;
    }

    public static setMovingState(stateId) {
        let procObj = BMSConstants.getBMSProcessInfo();
        procObj.movingState = stateId;
    }
    public static getMovingState() {
        return BMSConstants.getBMSProcessInfo().movingState;
    }
    public static getSatus() {
        return BMSConstants.getBMSCaseInfo().status;
    }

    public static getProsObjStatus() {
        return BMSConstants.getBMSProcessInfo().workflowStatus;
    }

    private static BMS_OBJ: any;
    public static getBMSObj() {
        return BMSConstants.BMS_OBJ;
    }

    public static setMainObjDetailsForRT(caseID, status) {
        let caseInfo = BMSConstants.getBMSCaseInfo();
        let procObj = BMSConstants.getBMSProcessInfo();
        if (caseInfo.businessFunction == "MiscCN") {
            caseInfo.caseId = caseID;
            caseInfo.status = status;
            procObj.workflowStatus = status;
        }
    }

    public static setApprovalStatus(isUWUser) {
        let caseInfo = BMSConstants.getBMSCaseInfo();
        let headerInfo = BMSConstants.getBMSHeaderInfo();
        if (caseInfo.status == '' || caseInfo.status == null || caseInfo.status == 'Draft' || caseInfo.status == 'Assessment' || caseInfo.status == 'Assessment Approval' || caseInfo.status == 'Rerate Reviewed')
            headerInfo.isApprovalCompleted = "N";
        else
            headerInfo.isApprovalCompleted = "Y";

        if (isUWUser == "Y")
            headerInfo.isApprovalCompleted = "N";
    }

    public static getApprovalStatus() {
        let headerInfo = BMSConstants.getBMSHeaderInfo();
        return headerInfo.isApprovalCompleted;
    }

    private static ISQUOTATIONCOMPLETED: string;
    public static setQuotationCompleted() {
        BMSConstants.ISQUOTATIONCOMPLETED = "N";
        let workFlowInfo = BMSConstants.getBMSProcessInfo();
        if (["Policy Processing", "P400 Pending NB", "P400 In forced", "Policy Pipeline", "Cover Note Processing", "Cover Note Created", "Cover Note Accepted", "Cover Note Rejected", "Ready for Conversion", "Closed", "RFI Policy Processing", "Cover Note Cancelled"].indexOf(workFlowInfo.workflowStatus) != -1)
            BMSConstants.ISQUOTATIONCOMPLETED = "Y";
    }

    public static isQuotationCompleted() {
        return BMSConstants.ISQUOTATIONCOMPLETED;
    }

    public static setAssessmentCompleted() {
        BMSConstants.TEMPOBJ.ISASSESSMENTCOMPLETED = "N";
        let wf = BMSConstants.getBMSProcessInfo();
        if (wf.workflowStatus == null || wf.workflowStatus == "" || wf.workflowStatus == "Draft" || wf.workflowStatus == "Assessment")
            BMSConstants.TEMPOBJ.ISASSESSMENTCOMPLETED = "N";
        else
            BMSConstants.TEMPOBJ.ISASSESSMENTCOMPLETED = "Y";
    }

    public static getBMSCaseInfo() {
        return BMSConstants.BMS_OBJ.ApplicationBusinessObject.caseInfo;
    }

    public static getRTBMSCaseInfo() {
        return BMSConstants.RT_BMS_OBJ.ApplicationBusinessObject.caseInfo;
    }

    public static getBMSProcessInfo() {
        return BMSConstants.BMS_OBJ.ApplicationBusinessObject.processObject;
    }

    public static getBMSHeaderInfo() {
        return BMSConstants.BMS_OBJ.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo;
    }

    public static getNewBusinessInfo() {
        return BMSConstants.BMS_OBJ.ApplicationBusinessObject.businessObject.bms.newBusiness;
    }

    public static getCaseId() {
        return BMSConstants.BMS_OBJ.ApplicationBusinessObject.caseInfo.caseId;
    }

    public static getRisks() {
        return BMSConstants.BMS_OBJ.ApplicationBusinessObject.businessObject.bms.newBusiness.risks;
    }

    public static setBMSObj(obj) {
        BMSConstants.BMS_OBJ = obj;
    }

    private static insuredType: string;
    public static getInsuredType() {
        return BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.clientDetails.client.genericDetails.clienttype;
    }
    public static setInsuredType(insuredType) {
        this.insuredType = insuredType;
    }

    private static selectedRiskType: string;
    public static getSelectedRiskType() {
        return this.selectedRiskType;
    }
    public static setSelectedRiskType(riskType) {
        this.selectedRiskType = riskType;
    }

    private static mandatoryGSTFields: any = {};
    public static getMandatoryGSTFields(riskTypeClientType) {
        return this.mandatoryGSTFields[riskTypeClientType];
    }
    public static setMandatoryGSTFields(riskTypeClientType, obj) {
        this.mandatoryGSTFields[riskTypeClientType] = obj;
    }

    private static excessTypeRecord: any = {};
    public static getExcessTypeRecord(riskExcessType) {
        return this.excessTypeRecord[riskExcessType];
    }
    public static setExcessTypeRecord(riskExcessType, obj) {
        this.excessTypeRecord[riskExcessType] = obj;
    }

    private static travelInsuredValidationsConfig: any;
    public static getTravelInsuredConfig() {
        return this.travelInsuredValidationsConfig;
    }
    public static setTravelInsuredConfig(obj: Object) {
        this.travelInsuredValidationsConfig = obj;
    }

    private static travelPeriodValidationsConfig: any;
    public static getTravelPeriodValidationsConfig() {
        return this.travelPeriodValidationsConfig;
    }
    public static setTravelPeriodValidationsConfig(obj: Object) {
        this.travelPeriodValidationsConfig = obj;
    }

	/*private static minimumPremiumDetails:any={};
	public static getMinimumPremium(riskType){		
		return this.minimumPremiumDetails[riskType];
	}	
	public static setMinimumPremium(riskType, val){
		this.minimumPremiumDetails[riskType] = val;
	}*/

    private static totalGrossCapacity: any = {};
    public static getTotalGrossCapacity(riRetentionCode) {
        return this.totalGrossCapacity[riRetentionCode];
    }
    public static setTotalGrossCapacity(riRetentionCode, val) {
        this.totalGrossCapacity[riRetentionCode] = val;
    }

    private static stampDuty: any = {};
    public static getStampDuty(riskType) {
        return this.stampDuty[riskType];
    }
    public static setStampDuty(riskType, val) {
        this.stampDuty[riskType] = val;
    }

    private static s5382PremiumCharges: any;
    public static getS5382PremiumCharges() {
        return this.s5382PremiumCharges;
    }
    public static setS5382PremiumCharges(obj) {
        this.s5382PremiumCharges = obj;
    }

    public static bmsUtilServiceObj: any;
    public static getBmsUtilServiceObj() {
        return this.bmsUtilServiceObj;
    }
    public static setBmsUtilServiceObj(obj: Object) {
        this.bmsUtilServiceObj = obj;
    }

    public static getClientObj() {
        return BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.clientDetails;
    }

    private static RT_BMS_OBJ: any;
    public static getRTBMSObj() {
        return BMSConstants.RT_BMS_OBJ;
    }

    public static setRTBMSObj(appObj) {
        BMSConstants.RT_BMS_OBJ = appObj;
    }

    public static emptyRTObj() {
        BMSConstants.RT_BMS_OBJ = null;
    }

    public static getRTCaseID() {
        let rtObj = BMSConstants.getRTBMSObj();
        return rtObj.ApplicationBusinessObject.caseInfo.caseId;
    }

    public static getRTRisks() {
        return BMSConstants.RT_BMS_OBJ.ApplicationBusinessObject.businessObject.misc.miscDetails.risks;
    }

    public static getMsicObj() {
        return BMSConstants.RT_BMS_OBJ.ApplicationBusinessObject.businessObject.misc.miscDetails;
    }

    public static getMsicHeaderObj() {
        return BMSConstants.RT_BMS_OBJ.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo;
    }
}