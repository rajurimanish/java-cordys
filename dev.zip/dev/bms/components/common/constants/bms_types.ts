export enum BMSType {
    NewBusiness,
    CoverNote,
    RenewalRerate,
    Renewal,
    FireCert,
    MiscCN,
    Endorsements,//Endorsements Code
    Cancellations,//Endorsements Code
    Reinstatement//Endorsements Code
}