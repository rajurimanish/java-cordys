import { NewBusiness } from '../../proposal/appobjects/proposal';
import { AppUtil } from '../../../../common/components/utility/apputil/app.util';

export class BMSObject {
    public newBusiness: NewBusiness;
    constructor() { }

    public getNewBusInstance() {
        this.newBusiness = new NewBusiness();
        return this;
    }

    public getInstance(valObj: BMSObject) {
        this.newBusiness = new NewBusiness().getInstance(valObj.newBusiness);
        return this;
    }

    //Endorsements Code
    public getENCAInstance(valObj: BMSObject) {
        this.newBusiness = new NewBusiness().getInstanceforENCA(valObj.newBusiness);  
        return this;
    }//End

    public getNewFireInstance() {
        this.newBusiness = new NewBusiness();
        return this;
    }

    public getFireInstance(valObj: BMSObject) {
        this.newBusiness = new NewBusiness().getInstance(valObj.newBusiness);
        return this;
    }

    public getNewMiscInstance() {
        this.newBusiness = new NewBusiness().getNewMiscInstance();
        return this;
    }

    public getMiscInstance(valObj: BMSObject) {
        if (new AppUtil().isValidObj(valObj) == true) {
            this.newBusiness = new NewBusiness().getMiscInstance(valObj.newBusiness);
        }
        return this;
    }
}