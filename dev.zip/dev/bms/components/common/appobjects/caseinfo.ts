/*
 * Change History:
 * 
 * No      Date          Description                                         Changed By
 * ====    ==========    ===========                                         ==========	
 * YPK001 23/09/2019       MYS-2019-0675 Document Validation for Co-outwards            PKU1
 *                         case before sending to PPHO			   
*/
import { AttachmentInfo } from '../../../../common/components/appobjects/attachmentinfo';
import { PODAttachment } from '../../../../common/components/appobjects/podattachment';
import { ProcessHistory } from '../../../../common/components/appobjects/processhistory';
import { ChangeLogs } from '../../../../common/components/changelog/appobjects/changelogs';
import { Comment } from '../../../../common/components/appobjects/comment'
import { AppUtil } from '../../../../common/components/utility/apputil/app.util';

export class CaseInfo {
    public caseId: string = "";
    public companyName: string = "";
    public division: string = "";
    public department: string = "";
    public handlingBranchName: string = "";
    public handlingBranchId: string = "";
    public issuingBranchName: string = "";
    public issuingBranchId: string = "";
    public applicationName: string = "";
    public businessFunction: string = "";
    public lineOfBusiness: string = "";
    public product: string = "";
    public source: string = "";
    public requestType: string = "";
    public currentState: string = "";
    public status: string = "";
    public statusDetail: string = "";
    public statusMessage: string = "";
    public initiatedOn: string = "";
    public initiatedBy: string = "";
    public lastModifiedOn: string = "";
    public lastModifiedBy: string = "";
    public currentAssignee: string = "";
    public claimHandler: string = "";
    public businessHandler: string = "";
    public producerCode: string = "";
    public claimNumber: string = "";
    public policyNumber: string = "";
    public linkCaseId: string = "";
    public attachmentInfo: AttachmentInfo;
    public attachmentInfoDisp: AttachmentInfo;
    public podattachment: PODAttachment;
    public approvalInfo: ProcessHistory;
    public auditTrail: ChangeLogs;
    public comments: Comment[];
    public accountHandler: string = "";
    public processobjectstatusBeforeHoldCover: string = "";
    public caseobjectstatusBeforeHoldCover: string = "";
    public accountHandlerName: string = "";
    public claimType: string = "";
    public p400ClaimStatus: string = "";
    public country: string = "";
    public insured: string = "";
    public servicingBranches: string = "";
    public principal: string = "";
    public invoiceType: string = "";
    public invoiceId: string = "";
    public isFastTrack: string = "";
    public isPostedBySTP: string = "";
    public jpjStatus: string = "";
    public policyNumberOrg: string = "";
    public encaEffDate: string;//Endorsements Code
    constructor() {
        this.attachmentInfo = new AttachmentInfo();
        this.attachmentInfoDisp = new AttachmentInfo();
        this.podattachment = new PODAttachment();
        this.approvalInfo = new ProcessHistory();
        this.auditTrail = new ChangeLogs();
        this.accountHandler = '';
        this.accountHandlerName = '';

    }

    public getInstance(valObj: CaseInfo) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
            new AppUtil().handleArray(this, valObj, "comments");
            this.attachmentInfo = new AttachmentInfo().getInstance(valObj.attachmentInfo);
            this.attachmentInfoDisp = new AttachmentInfo().getInstance(valObj.attachmentInfo);

            this.approvalInfo = new ProcessHistory().getInstance(valObj.approvalInfo);
            this.auditTrail = new ChangeLogs().getInstance(valObj.auditTrail);
        }
        return this;
    }

    public getMiscInstance(valObj: CaseInfo) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().setFieldValue(this, valObj);
            this.approvalInfo = new ProcessHistory().getInstance(valObj.approvalInfo);
            this.attachmentInfo = new AttachmentInfo().getInstance(valObj.attachmentInfo);
            this.attachmentInfoDisp = new AttachmentInfo().getInstance(valObj.attachmentInfo);
        }
        return this;
    }

    public refresh(valObj: CaseInfo, userName, allRoles) {
        new AppUtil().setFieldValueByType(this, valObj);
        this.approvalInfo.refresh(valObj.approvalInfo, userName, allRoles);
        this.attachmentInfoDisp.refresh(valObj.attachmentInfo, userName, allRoles);
    }

    public refreshMisc(valObj: CaseInfo, userName, allRoles) {
        new AppUtil().setFieldValueByType(this, valObj);
        this.approvalInfo.refresh(valObj.approvalInfo, userName, allRoles);
        this.attachmentInfo.refreshNoRole(valObj.attachmentInfo);
        this.attachmentInfoDisp.refresh(valObj.attachmentInfo, userName, allRoles);
    }

    public attachmentChange(attInfo, userName) {
        if (attInfo != null) {
            if (attInfo.docDeleted) {
                if (attInfo.comments) {
                    this.approvalInfo.addItem({ target: "SELF", targetType: "SELF", user: userName, action: "Document deleted by administrator", comments: "Name: " + attInfo.attachmentName + ", Comments: " + attInfo.comments, isPrivate: "", roleName: "" });
                } else {
                    this.approvalInfo.addItem({ target: "SELF", targetType: "SELF", user: userName, action: "Document deleted", comments: "Name: " + attInfo.attachmentName, isPrivate: "", roleName: "" });
                }
            } else {
                let lAttachment = this.attachmentInfo.attachment.length;
                if (lAttachment >= 1) {
                    let attachmentName: string = this.attachmentInfo.attachment[lAttachment - 1].attachmentName;
                    let attachmentType: string = this.attachmentInfo.attachment[lAttachment - 1].attachmentType;
                    this.approvalInfo.addItem({ target: "SELF", targetType: "SELF", user: userName, action: "Document attached", comments: "Name: " + attachmentName + ", Type: " + attachmentType, isPrivate: "", roleName: "" });
                }
            }
        }
    }
    public addApprovalNode(obj) {
        this.approvalInfo.addItem(obj);
    }

    public isFACRIDocAttached() {
        let docs = this.attachmentInfoDisp.getAttachmentByType("RIWSCF");
        if (docs.length > 0)
            return true;
        else
            return false;
    }
    //START YPK001
    public isCOOHDocAttached() {
        let docs = this.attachmentInfoDisp.getAttachmentByType("COOH");
        if (docs.length > 0)
            return true;
        else
            return false;
    }
    //END YPK001
    public isAMLCDDDocAttached() {
        let docs = this.attachmentInfoDisp.getAttachmentByType("AMLSUP");
        if (docs.length > 0)
            return true;
        else
            return false;
    }

    public isHRCDocAttached() {
        let docs = this.attachmentInfoDisp.getAttachmentByType("CEOAPPROVAL");
        if (docs.length > 0)
            return true;
        else
            return false;
    }
}