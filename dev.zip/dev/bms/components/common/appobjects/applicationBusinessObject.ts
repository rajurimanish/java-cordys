import { CaseInfo } from './caseinfo';
import { BMSObject } from './bmsobject';
import { MiscObject } from './miscobject';
import { AppUtil } from '../../../../common/components/utility/apputil/app.util';
import { ProcessObject } from '../../../../common/components/appobjects/processobject';

export class ApplicationObject {
    public ApplicationBusinessObject: ApplicationBusinessObject;
    constructor() { }

    public getNewBusInstance() {
        this.ApplicationBusinessObject = new ApplicationBusinessObject().getNewBusInstance();
        return this;
    }

    public getInstance(valObj: ApplicationObject) {
        this.ApplicationBusinessObject = new ApplicationBusinessObject().getInstance(valObj.ApplicationBusinessObject);
        return this;
    }

    public getNewFireInstance() {
        this.ApplicationBusinessObject = new ApplicationBusinessObject().getNewFireInstance();
        return this;
    }

    public getNewMiscInstance() {
        this.ApplicationBusinessObject = new ApplicationBusinessObject().getNewMiscInstance();
        return this;
    }

    public getFireInstance(valObj: ApplicationObject) {
        this.ApplicationBusinessObject = new ApplicationBusinessObject().getFireInstance(valObj.ApplicationBusinessObject);
        return this;
    }

    public getMiscInstance(valObj: ApplicationObject) {
        this.ApplicationBusinessObject = new ApplicationBusinessObject().getMiscInstance(valObj.ApplicationBusinessObject);
        return this;
    }
}

export class ApplicationBusinessObject {
    public caseInfo: CaseInfo;
    public businessObject: BusinessObject;
    public processObject: ProcessObject;
    constructor() { }

    public getNewBusInstance() {
        this.caseInfo = new CaseInfo();
        this.businessObject = new BusinessObject().getNewBusInstance();
        this.processObject = new ProcessObject();
        return this;
    }
	
    public getInstance(valObj: ApplicationBusinessObject) {
        this.caseInfo = new CaseInfo().getInstance(valObj.caseInfo);
        this.processObject = new ProcessObject().getInstance(valObj.processObject);
		//Endorsements Code
        if ( this.caseInfo.caseId.startsWith( "EN" ) || this.caseInfo.caseId.startsWith( "CA" ) || this.caseInfo.caseId.startsWith( "RS" )) {
            this.businessObject = new BusinessObject().getENCAInstance(valObj.businessObject);
        } else {
            this.businessObject = new BusinessObject().getInstance(valObj.businessObject);
        }  //End     
        return this;
    }

    public getNewFireInstance() {
        this.caseInfo = new CaseInfo();
        this.businessObject = new BusinessObject().getNewFireInstance();
        this.processObject = new ProcessObject();
        return this;
    }

    public getNewMiscInstance() {
        this.caseInfo = new CaseInfo();
        this.businessObject = new BusinessObject().getNewMiscInstance();
        return this;
    }

    public getFireInstance(valObj: ApplicationBusinessObject) {
        this.caseInfo = new CaseInfo().getInstance(valObj.caseInfo);
        this.processObject = new ProcessObject().getInstance(valObj.processObject);
        this.businessObject = new BusinessObject().getFireInstance(valObj.businessObject);
        return this;
    }

    public getMiscInstance(valObj: ApplicationBusinessObject) {
        this.caseInfo = new CaseInfo().getMiscInstance(valObj.caseInfo);
        this.businessObject = new BusinessObject().getMiscInstance(valObj.businessObject);
        return this;
    }
}

export class BusinessObject {
    public bms: BMSObject;
    public misc: MiscObject;
    constructor() { }

    public getNewBusInstance() {
        this.bms = new BMSObject().getNewBusInstance();
        return this;
    }

    public getInstance(valObj: BusinessObject) {
        this.bms = new BMSObject().getInstance(valObj.bms);
        return this;
    }

    //Endorsements Code
    public getENCAInstance(valObj: BusinessObject) {
        this.bms = new BMSObject().getENCAInstance(valObj.bms);
        return this;
    }//End

    public getNewFireInstance() {
        this.bms = new BMSObject().getNewFireInstance();
        return this;
    }

    public getNewMiscInstance() {
        this.bms = new BMSObject().getNewMiscInstance();
        this.misc = new MiscObject().getNewMiscInstance();
        return this;
    }

    public getFireInstance(valObj: BusinessObject) {
        this.bms = new BMSObject().getFireInstance(valObj.bms);
        return this;
    }

    public getMiscInstance(valObj: BusinessObject) {
        this.bms = new BMSObject().getMiscInstance(valObj.bms);
        this.misc = new MiscObject().getMiscInstance(valObj.misc);
        return this;
    }
}