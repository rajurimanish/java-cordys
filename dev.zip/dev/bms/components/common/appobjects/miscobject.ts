import { MiscCoverNote } from '../../proposal/newbusinessrisks/motorcommercial/appobjects/misccovernote';
import { AppUtil } from '../../../../common/components/utility/apputil/app.util';

export class MiscObject {
    public miscDetails: Risks;
    constructor() { }

    public getNewMiscInstance() {
        this.miscDetails = new Risks();
        return this;
    }

    public getMiscInstance(valObj: MiscObject) {
        this.miscDetails = new Risks().getInstance(valObj.miscDetails);
        return this;
    }


}

export class Risks {
    public risks: Risk[] = [];
    constructor() { }

    public getInstance(valObj: Risks) {
        if (new AppUtil().isValidObj(valObj) == true) {
            new AppUtil().handleArray(this, valObj, "risks");
            for (let risk of this.risks) {
                let riskObj = new Risk().getInstance(risk);
                this.risks[this.risks.indexOf(risk)] = riskObj;
            }
        }
        return this;
    }

    public getRTObjByRiskNumber(riskNumber) {
        let lofRsks = this.risks.filter((item) => item.riskNumber == riskNumber);
        return lofRsks[0];
    }

    public add(risk) {
        this.risks.push(risk);
    }

    public getRTCN(riskNumber, sno) {
        let rtObj = this.getRTObjByRiskNumber(riskNumber);
        if (AppUtil.isEmpty(rtObj, false) == false) {
            return rtObj.getRTCNBySNO(sno);
        }
        else
            return null;
    }
}

export class Risk {
    public riskNumber: string = "";
    public risk: MiscCoverNote;
    constructor() {
        this.risk = new MiscCoverNote();
    }

    public getInstance(valObj: Risk) {
        new AppUtil().setFieldValue(this, valObj);
        this.risk = new MiscCoverNote().getInstance(valObj.risk);
        return this;
    }

    public getRTCNBySNO(sno) {
        let list = this.risk.rtCoverNote.filter((item) => item.serialNo == sno);
        if (list.length > 0)
            return list[0];
        else
            return null;
    }
}