/*
 * Change History	:
 *
 * 	No      Date         Description                                 			Changed By
 *	====    ==========   ===========                                 			==========
 *  GA001    11/09/2019  MYS-2019-0974 - BMS Enhancement on High Risk Vehicle & Client       KGA
*/
import { Injectable, Component, EventEmitter } from '@angular/core';
declare var Rx: any;
declare var Observer: any;
import { CordysSoapWService } from "../../common/components/utility/cordys-soap-ws";
import { GetLOVData, SearchAdvancedConfig, Filter } from '../../common/components/utility/search/search.requests';
import { BMSConstants } from '../components/common/constants/bms_constants';
import { AppUtil } from '../../common/components/utility/apputil/app.util';
import { ApplicationUtilService } from "../../common/services/application.util.service";
import { BMSLOVRequest } from '../components/common/service/lov/bms.lovrequest';
import { AlertMessagesService } from '../../common/components/utility/alertmessage/alertmessages.service';
import { AlertMessage } from '../../common/components/utility/alertmessage/alertmessages.model';

declare var jQuery: any;
declare var moment: any;
declare var numeral: any;

@Component( {
    outputs: ["onPremiumChange", 'onRiskClsChange']
} )
@Injectable()
export class BMSUtilService {

    private gstP400FieldsMapping: any = { 'ZGSTLOC': 'riskLocation', 'ZGSTUSE': 'riskUsage', 'ZGSTRES': 'placeOfRecidence', 'ZGSTITP': 'inputTaxAllowed' };
    private riskType: string;
    private insuredType: string;
    private agentCertDetailsResp: any;
    private netRetentionAmountDetResp: any;
    private tpLimitDetResp: any;
    private selectedRIRetentionCode: string;
    constructor( private _cordysService: CordysSoapWService, public _alertMsgService: AlertMessagesService ) { }
    onPremiumChange = new EventEmitter<any>();

    public getGstMandatoryFields() {
        let comp = this;

        return Rx.Observable.create( function ( observer ) {
            let _riskType = BMSConstants.getSelectedRiskType();
            let _insuredType = BMSConstants.getInsuredType();
            let _key = _riskType + _insuredType;
            let _mandatoryGSTFields = BMSConstants.getMandatoryGSTFields( _key );
            if ( _mandatoryGSTFields ) {
                observer.next( _mandatoryGSTFields );
            } else {
                comp.setGstMandatoryFields( observer );
            }
        } );
    }

    public setGstMandatoryFields( observer ) {
        let _riskType = BMSConstants.getSelectedRiskType();
        let _descItemFilter = ( _riskType.length == 2 ) ? 'S6813' + _riskType + ' ' : 'S6813' + _riskType;

        let request: GetLOVData = new GetLOVData();
        request.BRANCH = 'ALL';
        request.LOB = 'ALL';
        request.BUSINESS_FUNCTION = 'NEW BUSINESS';
        request.PRODUCT = 'ALL';
        request.OPERATION = 'ALL';
        request.FORM_NAME = 'ALL';
        request.FORM_FIELD_NAME = 'GST Mandatory Fields';
        request.FIELD_TYPE = 'LOV';
        request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        request.ADVANCE_CONFIG_XML.FILTERS = new Filter();

        request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push( { "@FIELD_NAME": 'DESCITEM', "@FIELD_VALUE": _descItemFilter, '@OPERATION': 'STARTSWITH', '@CONDITION': 'AND' } );
        this._cordysService.callCordysSoapService( "GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.setGstMandatoryFieldsHandler, this.handleError, true, { obs: observer, comp: this } );
    }

    setGstMandatoryFieldsHandler( response, prms ) {
        let ary = [];
        // let _riskGSTP400Fields = Object.clone(prms.comp.gstP400FieldsMapping);
        let _riskGSTP400Fields = jQuery.extend( true, {}, prms.comp.gstP400FieldsMapping );

        ary = new AppUtil().getArray( response.tuple );

        // if(response.tuple != null && !Array.prototype.isPrototypeOf(response.tuple)){
        // ary = [response.tuple];
        // }
        // else if(response.tuple != null){
        // ary = response.tuple;
        // }

        for ( let _gstFld of ary ) {
            if ( _gstFld.old && _gstFld.old.T9014 && _gstFld.old.T9014.FIELDID ) {
                _riskGSTP400Fields[_gstFld.old.T9014.FIELDID] = '';
            }
        }
        let _riskType = BMSConstants.getSelectedRiskType();
        let insuredType = BMSConstants.getInsuredType();
        if ( insuredType == 'P' ) {
            _riskGSTP400Fields['ZGSTITP'] = '';
        }
        let _key = _riskType + insuredType;

        BMSConstants.setMandatoryGSTFields( _key, _riskGSTP400Fields );
        prms.obs.next( _riskGSTP400Fields );
    }

    handleError( response, status, errorText, prms ) {
        // prms.comp._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, response.responseJSON.faultstring.text , 5000));
    }

    public getGstMandatoryFieldsSync( pRiskType, pInsuredType ) {
        this.riskType = pRiskType;
        this.insuredType = pInsuredType;

        let _descItemFilter = ( pRiskType.length == 2 ) ? 'S6813' + pRiskType + ' ' : 'S6813' + pRiskType;

        let request: GetLOVData = new GetLOVData();
        request.BRANCH = 'ALL';
        request.LOB = 'ALL';
        request.BUSINESS_FUNCTION = 'NEW BUSINESS';
        request.PRODUCT = 'ALL';
        request.OPERATION = 'ALL';
        request.FORM_NAME = 'ALL';
        request.FORM_FIELD_NAME = 'GST Mandatory Fields';
        request.FIELD_TYPE = 'LOV';
        request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        request.ADVANCE_CONFIG_XML.FILTERS = new Filter();

        request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push( { "@FIELD_NAME": 'DESCITEM', "@FIELD_VALUE": _descItemFilter, '@OPERATION': 'STARTSWITH', '@CONDITION': 'AND' } );
        this._cordysService.callCordysSoapService( "GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.setGstMandatoryFieldsHandlerSync, this.handleError, false, { comp: this } );
    }

    setGstMandatoryFieldsHandlerSync( response, prms ) {
        let ary = [];
        let _riskGSTP400Fields = jQuery.extend( true, {}, prms.comp.gstP400FieldsMapping );

        ary = new AppUtil().getArray( response.tuple );

        for ( let _gstFld of ary ) {
            if ( _gstFld.old && _gstFld.old.T9014 && _gstFld.old.T9014.FIELDID ) {
                _riskGSTP400Fields[_gstFld.old.T9014.FIELDID] = '';
            }
        }

        if ( prms.comp.insuredType == 'P' ) {
            _riskGSTP400Fields['ZGSTITP'] = '';
        }
        let _key = prms.comp.riskType + prms.comp.insuredType;

        BMSConstants.setMandatoryGSTFields( _key, _riskGSTP400Fields );

    }

    public getAgentCertificateDetails( certNo ) {
        let _agentCode = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.agentCode;
        this.agentCertDetailsResp = null;

        let request: GetLOVData = new GetLOVData();
        request.BRANCH = 'ALL';
        request.LOB = 'ALL';
        request.BUSINESS_FUNCTION = 'NEW BUSINESS';
        request.PRODUCT = 'ALL';
        request.OPERATION = 'ALL';
        request.FORM_NAME = 'ALL';
        request.FORM_FIELD_NAME = 'Agent Certificate';
        request.FIELD_TYPE = 'LOV';
        request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        request.ADVANCE_CONFIG_XML.FILTERS = new Filter();

        request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push( { "@FIELD_NAME": 'AGNTNUM', "@FIELD_VALUE": _agentCode, '@OPERATION': 'EQ', '@CONDITION': 'AND' } );
        request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push( { "@FIELD_NAME": 'ZCERTNO', "@FIELD_VALUE": certNo, '@OPERATION': 'EQ', '@CONDITION': 'AND' } );
        this._cordysService.callCordysSoapService( "GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.getAgentCertificateDetailsHandler, this.handleError, false, { comp: this } );

        return this.agentCertDetailsResp;
    }

    getAgentCertificateDetailsHandler( response, prms ) {
        prms.comp.agentCertDetailsResp = response;
    }

    getNetRetentionAmountDetails( riRetnCode ) {
        let _totalGrossCapacity = 0;
        let _shouldQuery = false;
        let _val = BMSConstants.getTotalGrossCapacity( riRetnCode );
        if ( !_val && _val != 0 ) {
            _shouldQuery = true;
        }
        else {
            _totalGrossCapacity = _val;
        }

        if ( _shouldQuery ) {

            this.netRetentionAmountDetResp = null;
            let request: GetLOVData = this.getTotalGrossCapacityRequest( riRetnCode );

            this._cordysService.callCordysSoapService( "GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.getNetRetentionAmountDetailsHandler, this.handleError, false, { comp: this } );

            _totalGrossCapacity = 0;
            let _netRetentionAmount = 0;
            if ( this.netRetentionAmountDetResp && this.netRetentionAmountDetResp.tuple ) {
                let _ary = new AppUtil().getArray( this.netRetentionAmountDetResp.tuple );

                if ( _ary && _ary.length > 0 ) {

                    _netRetentionAmount = parseFloat( "" + _ary[0].old.T4944.RETOTS );
                    let _surPlusCapacity = 0;
                    for ( let _rec of _ary ) {
                        if ( _rec.old.T4944.LMT )
                            _surPlusCapacity = _surPlusCapacity + parseFloat( "" + _rec.old.T4944.LMT );
                    }
                    _totalGrossCapacity = _netRetentionAmount + _surPlusCapacity;
                }
            }

            BMSConstants.setTotalGrossCapacity( riRetnCode, _totalGrossCapacity );
        }
        // return this.netRetentionAmountDetResp;
        return _totalGrossCapacity;
    }

    getNetRetentionAmountDetailsHandler( response, prms ) {
        prms.comp.netRetentionAmountDetResp = response;
    }

    getTotalGrossCapacityRequest( riRetnCode ) {
        let _endDate = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.endDate;
        let polEndDate = ApplicationUtilService.getFormattedDate( _endDate, "YYYY-MM-DD", "YYYYMMDD" );

        let request: GetLOVData = new GetLOVData();
        request.BRANCH = 'ALL';
        request.LOB = 'ALL';
        request.BUSINESS_FUNCTION = 'NEW BUSINESS';
        request.PRODUCT = 'ALL';
        request.OPERATION = 'ALL';
        request.FORM_NAME = 'ALL';
        request.FORM_FIELD_NAME = 'Net Retention Amount';
        request.FIELD_TYPE = 'LOV';
        request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        request.ADVANCE_CONFIG_XML.FILTERS = new Filter();

        request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push( { "@FIELD_NAME": 'DESCITEM', "@FIELD_VALUE": riRetnCode, '@OPERATION': 'EQ', '@CONDITION': 'AND' } );
        request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push( { "@FIELD_NAME": 'ITMFRM', "@FIELD_VALUE": polEndDate, '@OPERATION': 'LTEQ', '@CONDITION': 'AND' } );
        request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push( { "@FIELD_NAME": 'ITMTO', "@FIELD_VALUE": polEndDate, '@OPERATION': 'GTEQ', '@CONDITION': 'AND' } );

        return request;
    }

    public getTotalGrossCapacity( riRetnCode ) {
        let comp = this;
        this.selectedRIRetentionCode = riRetnCode;
        return Rx.Observable.create( function ( observer ) {

            let _totalGrossCapacity = 0;
            let _shouldQuery = false;
            let _val = BMSConstants.getTotalGrossCapacity( riRetnCode );
            if ( !_val && _val != 0 ) {
                _shouldQuery = true;
            }
            else {
                _totalGrossCapacity = _val;
            }

            if ( _shouldQuery ) {
                comp.setTotalGrossCapacity( observer );
            } else {
                observer.next( _totalGrossCapacity );
            }
        } );
    }

    setTotalGrossCapacity( observer ) {
        let request: GetLOVData = this.getTotalGrossCapacityRequest( this.selectedRIRetentionCode );
        this._cordysService.callCordysSoapService( "GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.getTotalGrossCapacitySuccessHandler, this.handleError, true, { obs: observer, comp: this } );

    }

    getTotalGrossCapacitySuccessHandler( response, prms ) {

        let _riRetnCode = prms.comp.selectedRIRetentionCode;
        let _totalGrossCapacity = 0;
        let _netRetentionAmount = 0;
        if ( response && response.tuple ) {
            let _ary = new AppUtil().getArray( response.tuple );

            if ( _ary && _ary.length > 0 ) {

                _netRetentionAmount = parseFloat( "" + _ary[0].old.T4944.RETOTS );
                let _surPlusCapacity = 0;
                for ( let _rec of _ary ) {
                    if ( _rec.old.T4944.LMT )
                        _surPlusCapacity = _surPlusCapacity + parseFloat( "" + _rec.old.T4944.LMT );
                }
                _totalGrossCapacity = _netRetentionAmount + _surPlusCapacity;
            }
        }

        BMSConstants.setTotalGrossCapacity( _riRetnCode, _totalGrossCapacity );
        prms.obs.next( _totalGrossCapacity );
    }

    getTPLimitDetails( riskType ) {
        let request: GetLOVData = new GetLOVData();
        request.BRANCH = 'ALL';
        request.LOB = 'FIRE';
        request.BUSINESS_FUNCTION = 'NEW BUSINESS';
        request.PRODUCT = 'ALL';
        request.OPERATION = 'NEW';
        request.FORM_NAME = 'HHO';
        request.FORM_FIELD_NAME = 'TP Limit Details';
        request.FIELD_TYPE = 'LOV';
        request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
        request.ADVANCE_CONFIG_XML.FILTERS = new Filter();

        let _endDate = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.endDate;
        _endDate = ApplicationUtilService.getFormattedDate( _endDate, "YYYY-MM-DD", "YYYYMMDD" );

        request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push( { "@FIELD_NAME": 'B.DESCITEM', "@FIELD_VALUE": riskType, '@OPERATION': 'STARTSWITH', '@CONDITION': 'AND' } );
        request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push( { "@FIELD_NAME": 'A.ITMFRM', "@FIELD_VALUE": _endDate, '@OPERATION': 'LTEQ', '@CONDITION': 'AND' } );
        request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push( { "@FIELD_NAME": 'A.ITMTO', "@FIELD_VALUE": _endDate, '@OPERATION': 'GTEQ', '@CONDITION': 'AND' } );

        this._cordysService.callCordysSoapService( "GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, this.getTPLimitDetailsSuccessHandler, this.handleError, false, { comp: this } );

        return this.tpLimitDetResp;
    }

    private getTPLimitDetailsSuccessHandler( response, prms ) {
        prms.comp.tpLimitDetResp = response;
    }

    public startApprovalWorkflow( caseId, RoleDn, UserDn ) {
        return Rx.Observable.create( ( observer ) => {
            this._cordysService.callCordysSoapService( "StartApprovalWorkFlowProcessRequest", "http://schemas.insurance.com/businessobject/1.0/", this.startApprovalParams( caseId, RoleDn, UserDn ), null, null, true, this )
                .success( ( data ) => this.startApprovalSuccessHandler( data, this, observer ) )
                .error( ( response, status, errorText ) => this.startApprovalErrorHandler( response, status, errorText, observer ) )
        } );
    }


    private startApprovalParams( caseId, RoleDn, UserDn ) {
        if ( BMSConstants.getBMSHeaderInfo().isSimplifiedProcess != 'Y' ) {
            return {
                "caseId": caseId,
                "Participant": {
                    "leveName": "",
                    "roleDN": RoleDn,
                    //get the users for the role and assign the first user
                    "userDN": UserDn
                }
            }
        }
        else {
            return {
                "caseId": caseId,
                "Participant": {
                    "leveName": "",
                    "roleDN": RoleDn,
                    //get the users for the role and assign the first user
                    "userDN": UserDn
                },
                "isSimplifiedProcess": "Y"
            }
        }

    }

    public startApprovalSuccessHandler( data, originalObject, observer ) {
        if ( data.fault ) {
            //console.error("Error while starting approval process: " + data.fault.description);
            this._alertMsgService.add( new AlertMessage( AlertMessage.INFO, "Error while starting approval process: " + data.fault.description, -1 ) );
        }
        else {
            //console.log("Approval Workflow process started");
            this._alertMsgService.add( new AlertMessage( AlertMessage.INFO, "Approval Workflow process started.", -1 ) );
        }
        observer.next( "SUCCESS" );
    }

    private startApprovalErrorHandler( response, status, errorText, observer ) {
        observer.error( "ERROR" );
    }

    public getAMLCDDLimits() {
        return Rx.Observable.create( ( observer ) => {
            let isClient = BMSConstants.getClientObj().isClient();
            let header = BMSConstants.getBMSHeaderInfo();
            if ( isClient == false && ( BMSConstants.getBMSCaseInfo().status == 'Quotation' || BMSConstants.getBMSCaseInfo().status == 'Policy Pipeline' ) && ( header.businessChannel == '04' || header.businessChannel == '01' ) ) {
                let prom = this._cordysService.callCordysSoapService( "GetXMLObject", "http://schemas.cordys.com/1.0/xmlstore", { "key": "/com/msig/insurance/exceptions/cdd_limits.xml" }, null, null, true, null );
                prom.success( ( resp ) => {
                    observer.next( AppUtil.getValueByPath( resp, "tuple.old.config.premiumLimit" ) );
                } );
                prom.error( ( resp ) => {
                    this._alertMsgService.add( new AlertMessage( AlertMessage.INFO, "Error while fetching CDD limits.", -1 ) );
                    observer.next( "" );
                } );
            }
            else
                observer.next( "" );
        } );
    }

    public attachReportToCase( caseID, reportType, fileExtension, PARAM ) {
        return Rx.Observable.create( ( observer ) => {
            this._cordysService.callCordysSoapService( "AttachReportToCase", "http://schemas.insurance.com/businessobject/utility/1.0/", this.getReportReq( caseID, reportType, fileExtension, PARAM ), null, null, true, this )
                .success( ( data ) => observer.next( data ) )
                .error( ( response, status, errorText ) => observer.error( "" ) );
        } );
    }

    public getReportReq( caseId, reportType, fileExtension, PARAM ) {
        let req = "{\"CaseID\":\"" + caseId + "\",\"ReportType\":\"" + reportType + "\",\"FileExtension\":\"" + fileExtension + "\",\"PARAMS\":{\"PARAM\":[]}}";
        let reqObj = JSON.parse( req );
        reqObj.PARAMS.PARAM = PARAM;
        return reqObj;
    }

    s6272SetPremium( insuredObj ) {
        if ( insuredObj && insuredObj.plan ) {
            let _areaMultiplier = 0;
            let _occupRate = 0;
            let _basicPremium = 0;
            let _premiumFromPlan = 0;
            let _deductiblePercent = 0;
            let _deductibleAmount = 0;
            let _renewalDiscountPercent = 0;
            let _renewalDiscountAmount = 0;
            let _loadingDiscountPercent = 0;
            let _loadingDiscountAmount = 0;
            let _familyDiscountPercent = 0;
            let _familyDiscountAmount = 0;
            let _maternityPremium = 0;
            let _CRIIPremium = 0;
            let _additionalBenefitPremium = 0;
            let _totalAnnualPremium = 0;
            let _postingPremium = 0;

            _areaMultiplier = numeral().unformat( insuredObj.areaMultiplier );
            _occupRate = numeral().unformat( insuredObj.occupationClassRate );
            _premiumFromPlan = numeral().unformat( insuredObj.premiumFromPlan );
            _deductiblePercent = numeral().unformat( insuredObj.deductiblePercentage );
            _renewalDiscountPercent = numeral().unformat( insuredObj.renewalDiscountPercentage );
            _loadingDiscountPercent = numeral().unformat( insuredObj.loadingDiscountPercentage );
            _familyDiscountPercent = numeral().unformat( insuredObj.familyDiscountPercentage );
            _maternityPremium = numeral().unformat( insuredObj.maternityPremium );
            _CRIIPremium = numeral().unformat( insuredObj.CRIIPremium );

            if ( insuredObj.ratingFlag == "A" ) {
                _basicPremium = ( _premiumFromPlan * ( _occupRate / 100 ) ) + ( _premiumFromPlan * ( _areaMultiplier - 100.00 ) / 100 );
                insuredObj.basicPremium = numeral( Number( _basicPremium ) ).format( '0.00' );
            } else {
                _basicPremium = numeral().unformat( insuredObj.basicPremium );
            }

            _deductibleAmount = ( _basicPremium * ( _deductiblePercent / 100 ) );
            insuredObj.deductibleAmount = numeral( Number( _deductibleAmount ) ).format( '0.00' );
            _deductibleAmount = _deductibleAmount * ( -1 );

            _renewalDiscountAmount = ( ( _basicPremium + _deductibleAmount ) * ( _renewalDiscountPercent / 100 ) );
            insuredObj.renewalDiscountAmount = numeral( Number( _renewalDiscountAmount ) ).format( '0.00' );
            _renewalDiscountAmount = _renewalDiscountAmount * ( -1 );

            _loadingDiscountAmount = ( ( _basicPremium + _deductibleAmount + _renewalDiscountAmount ) * ( _loadingDiscountPercent / 100 ) );
            insuredObj.loadingDiscountAmount = numeral( Number( _loadingDiscountAmount ) ).format( '0.00' );

            _familyDiscountAmount = ( ( _basicPremium + _deductibleAmount + _renewalDiscountAmount + _loadingDiscountAmount ) * ( _familyDiscountPercent / 100 ) );
            insuredObj.familyDiscountAmount = numeral( Number( _familyDiscountAmount ) ).format( '0.00' );
            _familyDiscountAmount = _familyDiscountAmount * ( -1 );

            if ( insuredObj.riskType == "FSI" ) {
                _maternityPremium = 0;
                _CRIIPremium = 0;
                _additionalBenefitPremium = this.getTotalByProperty( "totalPremium", insuredObj.additionalCoverDetails.additionalCover, '0.00' );
                _additionalBenefitPremium = numeral().unformat( _additionalBenefitPremium );
            }
            _totalAnnualPremium = ( _basicPremium + _deductibleAmount + _renewalDiscountAmount + _loadingDiscountAmount + _familyDiscountAmount + _maternityPremium + _CRIIPremium + _additionalBenefitPremium );
            insuredObj.totalAnnualPremium = numeral( Number( _totalAnnualPremium ) ).format( '0.00' );

			/*
			if(insuredObj.ratingFlag=="A"){
                _postingPremium = ((_totalAnnualPremium) / 365) * this.calcDays();
                insuredObj.postingPremium = numeral(Number(_postingPremium)).format('0.00');
            }else{
                //this._alertMsgService.add(new AlertMessage(AlertMessage.INFO,"Rating flag is Manual, Please fill in Basic Premium and Posted Premium.", 5000));                
                insuredObj.postingPremium = numeral(Number()).format('0.00');
            }*/
            insuredObj.postingPremium = insuredObj.totalAnnualPremium;
            // this.onPremiumChange.emit(insuredObj.totalAnnualPremium);
        }
    }

    public getTotalByProperty( prop, ary, format ) {
        let total = numeral( 0 );
        for ( let eachItem of ary ) {
            if ( eachItem[prop] != null && eachItem[prop] != "" )
                total = total.add( numeral().unformat( eachItem[prop] ) );
        }
        total = numeral( total ).format( format );
        return total;
    }

    getExcessTypeRecord( riskType, excessType ) {
        let _exessTypeRecKey = riskType + excessType;
        let _excessTypeRecord = BMSConstants.getExcessTypeRecord( _exessTypeRecKey );
        if ( !_excessTypeRecord ) {
            let riskFilter = ( riskType.length == 2 ) ? riskType + ' ' + excessType : riskType + '' + excessType;

            let request: GetLOVData = new GetLOVData().getRequest( 'ALL', 'MIS', 'NEW BUSINESS', 'ALL', 'ALL', 'ALL', 'Excess Type', 'LOV' );
            request.ADVANCE_CONFIG_XML = new SearchAdvancedConfig();
            request.ADVANCE_CONFIG_XML.FILTERS = new Filter();
            request.ADVANCE_CONFIG_XML.FILTERS.FILTER.push( { "@FIELD_NAME": "DESCITEM", "@FIELD_VALUE": riskFilter, "@OPERATION": "STARTSWITH", "@CONDITION": "AND" } );

            this._cordysService.callCordysSoapService( "GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, null, null, false, null ).success( ( data ) => {
                if ( data.tuple ) {
                    if ( Array.prototype.isPrototypeOf( data.tuple ) ) {
                        _excessTypeRecord = data.tuple[0].old.T9107;
                    }
                    else if ( data.tuple.old && data.tuple.old.T9107 ) {
                        _excessTypeRecord = data.tuple.old.T9107;
                    }

                    if ( _excessTypeRecord ) {
                        BMSConstants.setExcessTypeRecord( _exessTypeRecKey, _excessTypeRecord );
                    }
                }
            } ).error( ( response, status, errorText ) => {
                this._alertMsgService.add( new AlertMessage( AlertMessage.ERROR, "Error while getting Excess Type details - ", 5000 ) );
            } );
        }

        return _excessTypeRecord;
    }
    // SST code
    public getLiveDate() {
        var respObj: any;
        var responseObj = this._cordysService.callCordysSoapService( "GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0",
            {
                "cursor": {
                    "@id": "0", "position": "0", "numRows": "5", "maxRows": "25", "sameConnection": "false"
                },
                "BRANCH": "ALL", "LOB": "ALL", "BUSINESS_FUNCTION": "ALL", "PRODUCT": "ALL", "OPERATION": "ALL",
                "FORM_NAME": "LIVEDATE", "FORM_FIELD_NAME": "LIVEDATE", "FIELD_TYPE": "LOV",
                "ADVANCE_CONFIG_XML": {
                    "FILTERS": {
                        "FILTER": [
                            { "@FIELD_NAME": "ITEMITEM", "@FIELD_VALUE": "'GSTLIVDT','SSTLIVE'", "@OPERATION": "IN", "@CONDITION": "AND" }
                        ]
                    }
                }
            }, null, null, false, null );
        responseObj.done( ( data ) => { respObj = data.tuple; } );

        return respObj;
    }

    public getTAXDetails(): any {
        let proposalHeader = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo;
        let transactionDate = moment( new Date(), "YYYY-MM-DD" ).format( "YYYYMMDD" );
        let inceptionDate = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.effectiveDate;
        inceptionDate = moment( inceptionDate, "YYYY-MM-DD" ).format( "YYYYMMDD" );
        let expiryDate = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.endDate;
        expiryDate = moment( expiryDate, "YYYY-MM-DD" ).format( "YYYYMMDD" );

        let dateFlag = "ED";

        let dateValue = ( "TD" == dateFlag ) ? transactionDate : inceptionDate;
        let taxType: string = "'E1','SR'";

        var respObj: any = undefined;
        if ( "Invalid date" != dateValue && dateValue != undefined && dateValue != "" ) {
            var responseObj = this._cordysService.callCordysSoapService( "GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0",
                {
                    "cursor": {
                        "@id": "0", "position": "0", "numRows": "5", "maxRows": "25", "sameConnection": "false"
                    },
                    "BRANCH": "ALL", "LOB": "ALL", "BUSINESS_FUNCTION": "ALL", "PRODUCT": "ALL", "OPERATION": "ALL",
                    "FORM_NAME": "GST", "FORM_FIELD_NAME": "gst", "FIELD_TYPE": "LOV",
                    "ADVANCE_CONFIG_XML": {
                        "FILTERS": {
                            "FILTER": [
                                { "@FIELD_NAME": "ITEMITEM", "@FIELD_VALUE": taxType, "@OPERATION": "IN", "@CONDITION": "AND" },
                                { "@FIELD_NAME": "ITMFRM", "@FIELD_VALUE": dateValue, "@OPERATION": "LTEQ", "@CONDITION": "AND" },
                                { "@FIELD_NAME": "ITMTO", "@FIELD_VALUE": dateValue, "@OPERATION": "GTEQ", "@CONDITION": "AND" }
                            ]
                        }
                    }
                }, null, null, false, null );
            responseObj.done( ( data ) => { respObj = ( data.tuple != undefined ) ? data.tuple : []; } );
            if ( respObj != undefined && !Array.prototype.isPrototypeOf( respObj ) ) {
                respObj = [respObj];
                let tempObj = { "old": { "ITEMPF": { ITEMITEM: "E1", ITMFRM: "20110101", ITMTO: "20150331", GST: "06" } } };
                respObj.push( tempObj );
            }
            else {
                respObj = respObj;
            }
        }
        return respObj;
    }

    public static calculatePremiumAmount( taxAmount, taxType ) {
        let GSTDateEnd: string = "2018-06-01"
        let totalTaxAmount: number = 0;
        let proposalHeader = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo;

        let noOfDays: number = 0;

        if ( "GS" == taxType || "S" == taxType ) {
            noOfDays = moment.duration( moment( proposalHeader.endDate, "YYYY-MM-DD" ).diff( moment( proposalHeader.SSTLiveDate, "YYYY-MM-DD" ) ) ).asDays() + 1;

            if ( moment( proposalHeader.effectiveDate, "YYYY-MM-DD" ).format( "YYYYMMDD" ) >= moment( proposalHeader.SSTLiveDate, "YYYY-MM-DD" ).format( "YYYYMMDD" ) ) {
                totalTaxAmount = taxAmount;
                return totalTaxAmount;
            }
        } else {
            //liveDate = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.GSTLiveDate;
            //liveDate = "20180531";
            if ( moment( proposalHeader.effectiveDate, "YYYY-MM-DD" ).format( "YYYYMMDD" ) <= moment( proposalHeader.SSTLiveDate, "YYYY-MM-DD" ).format( "YYYYMMDD" )
                && moment( proposalHeader.effectiveDate, "YYYY-MM-DD" ).format( "YYYYMMDD" ) < moment( GSTDateEnd, "YYYY-MM-DD" ).format( "YYYYMMDD" ) ) {
                noOfDays = moment.duration( moment( GSTDateEnd, "YYYY-MM-DD" ).diff( moment( proposalHeader.effectiveDate, "YYYY-MM-DD" ) ) ).asDays() + 1;
            }
        }

        let totalPOIDays = moment.duration( moment( proposalHeader.endDate, "YYYY-MM-DD" ).diff( moment( proposalHeader.effectiveDate, "YYYY-MM-DD" ) ) ).asDays() + 1;

        if ( noOfDays > 0 ) {
            totalTaxAmount = numeral( taxAmount * ( noOfDays / totalPOIDays ) ).value();
            //totalTaxAmount = (noOfDays < totalPOIDays)?numeral(taxAmount*(noOfDays /totalPOIDays)).value():numeral(taxAmount*(totalPOIDays /noOfDays)).value();
            totalTaxAmount = ( totalTaxAmount > 0 ) ? numeral( parseFloat( totalTaxAmount + "" ).toFixed( 2 ) ).value() : totalTaxAmount;
        }
        return totalTaxAmount;
    }

    public getTAXDetailsInfo( date1, date2 ): any {
        let proposalHeader = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo;
        let transactionDate = moment( new Date(), "YYYY-MM-DD" ).format( "YYYYMMDD" );
        let inceptionDate = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.effectiveDate;
        inceptionDate = moment( inceptionDate, "YYYY-MM-DD" ).format( "YYYYMMDD" );
        let expiryDate = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.endDate;
        expiryDate = moment( expiryDate, "YYYY-MM-DD" ).format( "YYYYMMDD" );

        let dateFlag = "ED";

        let dateValue = ( "TD" == dateFlag ) ? transactionDate : date1;
        let taxType: string = "'E1','SR'";

        var respObj: any = undefined;
        if ( "Invalid date" != dateValue && dateValue != undefined && dateValue != "" ) {
            var responseObj = this._cordysService.callCordysSoapService( "GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0",
                {
                    "cursor": {
                        "@id": "0", "position": "0", "numRows": "5", "maxRows": "25", "sameConnection": "false"
                    },
                    "BRANCH": "ALL", "LOB": "ALL", "BUSINESS_FUNCTION": "ALL", "PRODUCT": "ALL", "OPERATION": "ALL",
                    "FORM_NAME": "GST", "FORM_FIELD_NAME": "gst", "FIELD_TYPE": "LOV",
                    "ADVANCE_CONFIG_XML": {
                        "FILTERS": {
                            "FILTER": [
                                { "@FIELD_NAME": "ITEMITEM", "@FIELD_VALUE": taxType, "@OPERATION": "IN", "@CONDITION": "AND" },
                                { "@FIELD_NAME": "ITMFRM", "@FIELD_VALUE": dateValue, "@OPERATION": "LTEQ", "@CONDITION": "AND" },
                                { "@FIELD_NAME": "ITMTO", "@FIELD_VALUE": dateValue, "@OPERATION": "GTEQ", "@CONDITION": "AND" }
                            ]
                        }
                    }
                }, null, null, false, null );
            responseObj.done( ( data ) => { respObj = ( data.tuple != undefined ) ? data.tuple : []; } );
            if ( respObj != undefined && !Array.prototype.isPrototypeOf( respObj ) ) {
                respObj = [respObj];
                let tempObj = { "old": { "ITEMPF": { ITEMITEM: "E1", ITMFRM: "20110101", ITMTO: "20150331", GST: "06" } } };
                respObj.push( tempObj );
            }
            else {
                respObj = respObj;
            }
        }
        return respObj;
    }

    public static calculatePremiumAmt( taxAmount, taxType, date1, date2 ) {
        let GSTDateEnd: string = "2018-06-01"
        let totalTaxAmount: number = 0;
        let proposalHeader = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo;

        let noOfDays: number = 0;

        if ( "GS" == taxType || "S" == taxType ) {
            noOfDays = moment.duration( moment( date2, "YYYY-MM-DD" ).diff( moment( proposalHeader.SSTLiveDate, "YYYY-MM-DD" ) ) ).asDays() + 1;

			/* if(moment(date1,"YYYY-MM-DD").format("YYYYMMDD") >=  moment(proposalHeader.SSTLiveDate,"YYYY-MM-DD").format("YYYYMMDD")) 
			{
				totalTaxAmount = taxAmount;
				return totalTaxAmount;
			} */
        } else {
            //liveDate = BMSConstants.getBMSObj().ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo.GSTLiveDate;
            //liveDate = "20180531";
			/* if(moment(proposalHeader.effectiveDate,"YYYY-MM-DD").format("YYYYMMDD") <=  moment(proposalHeader.SSTLiveDate,"YYYY-MM-DD").format("YYYYMMDD") 
				&& moment(proposalHeader.effectiveDate,"YYYY-MM-DD").format("YYYYMMDD") <  moment(GSTDateEnd,"YYYY-MM-DD").format("YYYYMMDD")) 
			{
				noOfDays = moment.duration(moment(GSTDateEnd,"YYYY-MM-DD").diff(moment(proposalHeader.effectiveDate,"YYYY-MM-DD"))).asDays()+1;
			} */
        }

        let totalPOIDays = moment.duration( moment( date2, "YYYY-MM-DD" ).diff( moment( date1, "YYYY-MM-DD" ) ) ).asDays() + 1;

        if ( noOfDays > 0 ) {
            totalTaxAmount = numeral( taxAmount * ( noOfDays / totalPOIDays ) ).value();
            totalTaxAmount = ( totalTaxAmount > 0 ) ? numeral( parseFloat( totalTaxAmount + "" ).toFixed( 2 ) ).value() : totalTaxAmount;
        }
        return totalTaxAmount;
    }
    //End

    // MYS-2018-0974 KA002 START
    setTotalPremium5183( riskObj ) {
        let _additionalCoverTotalPremium = 0;
        let _additionalPremium = 0;
        let _rebateAmount = 0;
        let _gstAmount = 0;
        let _totalPremium = 0;
        let _loadingAmount = 0;
        let _discountAmount = 0;
        let _totalBasicPremium = 0;

        let _basicPremium: any = riskObj.basicPremium;
        let _loadingPercent: any = riskObj.loadingPercentage;
        let _discountPercent: any = riskObj.discountPercentage;

        _basicPremium = ( _basicPremium == null || _basicPremium == "" ) ? 0 : parseFloat( "" + _basicPremium );
        _loadingPercent = ( _loadingPercent == null || _loadingPercent == "" ) ? 0 : parseFloat( "" + _loadingPercent );
        _discountPercent = ( _discountPercent == null || _discountPercent == "" ) ? 0 : parseFloat( "" + _discountPercent );

        _totalBasicPremium = parseFloat( "" + _basicPremium );

        if ( riskObj.additionalCoverDetails.additionalCover && riskObj.additionalCoverDetails.additionalCover.length > 0 ) {
            for ( let _addCover of riskObj.additionalCoverDetails.additionalCover ) {
                let _rate: any = _addCover.additionalLoading;
                _rate = ( _rate == null || _rate == "" ) ? 0 : _rate;
                let _addCoverPrem = 0;
                if ( _basicPremium > 0 && _rate > 0 ) {
                    _addCoverPrem = _basicPremium * _rate * 0.01;
                }

                _addCover.addditionalPremium = numeral( _addCoverPrem ).format( '0.00' );
            }
        }

        let _addlCoverTotal = this.getTotalByProperty( "addditionalPremium", riskObj.additionalCoverDetails.additionalCover, '0.00' );
        riskObj.additionalCoverDetails.additionalCoverTotal = numeral( _addlCoverTotal ).format( '0.00' );

        if ( _basicPremium > 0 || parseFloat( "" + riskObj.additionalCoverDetails.additionalCoverTotal ) > 0 ) {
            _totalBasicPremium = _basicPremium + parseFloat( "" + riskObj.additionalCoverDetails.additionalCoverTotal );
        }
        riskObj.totalBasicPremium = numeral( Number( _totalBasicPremium ) ).format( '0.00' );
        _totalPremium = _totalBasicPremium;

        if ( _basicPremium > 0 && _loadingPercent > 0 ) {
            _loadingAmount = _basicPremium * _loadingPercent * 0.01;
            _loadingAmount = numeral( _loadingAmount ).format( '0.00' );
            _loadingAmount = parseFloat( "" + _loadingAmount );
        }
        riskObj.loadingAmount = numeral( Number( _loadingAmount ) ).format( '0.00' );

        if ( _loadingAmount > 0 ) {
            _totalPremium = _totalBasicPremium + _loadingAmount;
        }

        if ( _basicPremium > 0 && _loadingAmount > 0 && _discountPercent > 0 ) {
            _discountAmount = ( _basicPremium + _loadingAmount ) * _discountPercent * 0.01;
            _discountAmount = numeral( _discountAmount ).format( '0.00' );
        }
        else if ( _basicPremium > 0 && _discountPercent > 0 ) {
            _discountAmount = _basicPremium * _discountPercent * 0.01;
            _discountAmount = numeral( _discountAmount ).format( '0.00' );
        }
        riskObj.discountAmount = numeral( Number( _discountAmount ) ).format( '0.00' );

        _totalPremium = _totalBasicPremium + _loadingAmount - _discountAmount;


        riskObj.originalTotalPremium = numeral( Number( _totalPremium ) ).format( '0.00' );
        riskObj.totalPremium = riskObj.originalTotalPremium;

        if ( _totalPremium > 0 ) {
            let _rebateRate: any = riskObj.rebate;
            _rebateRate = ( _rebateRate == null || _rebateRate == "" ) ? 0 : parseFloat( "" + _rebateRate );
            let _rebateAmount = ( _rebateRate > 0 ) ? ( _totalPremium * _rebateRate * 0.01 ) : 0;
            riskObj.rebateAmount = numeral( Number( _rebateAmount ) ).format( '0.00' );
            _totalPremium = _totalPremium - _rebateAmount;
        } else
            riskObj.rebateAmount = 0;

        riskObj.totalPremium = numeral( Number( _totalPremium ) ).format( '0.00' );

        this.onPremiumChange.emit( riskObj.totalPremium );
    }// KA002 END   

    //GA001 START
    public getHighRiskLiveDt() {
        var respObj: any;
        var responseObj = this._cordysService.callCordysSoapService( "GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0",
            {
                "cursor": {
                    "@id": "0", "position": "0", "numRows": "5", "maxRows": "25", "sameConnection": "false"
                },
                "BRANCH": "ALL", "LOB": "ALL", "BUSINESS_FUNCTION": "ALL", "PRODUCT": "ALL", "OPERATION": "NEW",
                "FORM_NAME": "HIGHRISK_IND", "FORM_FIELD_NAME": "HIGHRISK_LIVDT", "FIELD_TYPE": "LOV",
                "ADVANCE_CONFIG_XML": {
                    "FILTERS": {
                        "FILTER": [
                            { "@FIELD_NAME": "DESCITEM", "@FIELD_VALUE": "HRLIVDT2", "@OPERATION": "EQ", "@CONDITION": "AND" }
                        ]
                    }
                }
            }, null, null, false, null );
        responseObj.done( ( data ) => { respObj = data.tuple; } );

        return respObj;
    }

    public static getHighRiskReasons() {
        var respObj: any;
        let filters = [];
        //filters.push( { "@FIELD_NAME": 'ZCIDTETER', "@FIELD_VALUE": "0", '@OPERATION': 'EQ', '@CONDITION': 'OR' } );

        let request: GetLOVData = new GetLOVData().getLovRequest( 'ALL', 'ALL', 'ALL', 'ALL', 'NEW', 'HIGHRISK_REASONS', 'HIGHRISK_REASONS_T9201', 'LOV', filters, {}, null );

        var responseObj = CordysSoapWService.callStaticCordysSoapService( "GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0",
            request, null, null, false, null );
        responseObj.done( ( data ) => { respObj = data.tuple; } );

        return respObj;
    }
    //GA001 END

}