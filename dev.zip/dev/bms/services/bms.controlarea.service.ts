/*
Change History	:

	No      Date          Description                                 Changed By
	====    ==========    ===========                                 ==========
	AL001   15/08/2017   MYS-2017-0371    -  Develop MPD               ALA			
    VK006   20/03/2019   MYS-2019-0164    - MMP Product Configuration  VKR	
    MS001   26/07/2019   MYS-2019-0729    - MMF Product Configuration  MSU	
*/
import { Injectable } from '@angular/core';
import { CordysSoapWService } from "../../common/components/utility/cordys-soap-ws";
import { BMSConstants } from '../components/common/constants/bms_constants';
import { AlertMessagesService } from '../../common/components/utility/alertmessage/alertmessages.service';
import { AlertMessage } from '../../common/components/utility/alertmessage/alertmessages.model';
declare var Rx: any;
declare var Observer: any;
import { ActivatedRoute, Router } from '@angular/router';
declare var moment: any;
@Injectable()
export class BMSControlAreaService {

    private processConfig;
    private receiptLiveDate: any;//VK012
    public static caInfo: any = { buttons: [] };
    constructor(private _cordysService: CordysSoapWService, public _alertMsgService: AlertMessagesService, private _router: Router, private _activatedRoute: ActivatedRoute) { }

    getCAInfo() {
        return BMSControlAreaService.caInfo;
    }

    public setActionLisByStatus() {
        return Rx.Observable.create((observer) => {
            //Get the Process Config Json Obj
            this.getButtonConfig().subscribe(() => this.setContolButtonsACL(observer));
        });
    }

    private setContolButtonsACL(observer) {
        // Logic to create button array for control area based on workflow status
        let workFlowInfo = BMSConstants.getBMSProcessInfo();
        let headerInfo = BMSConstants.getBMSHeaderInfo();
        let workflowStatus = (workFlowInfo.workflowStatus != undefined && workFlowInfo.workflowStatus != "") ? workFlowInfo.workflowStatus : "Draft";
        let configs = this.processConfig.configs.config;
        let index = this.processConfig.configs.config.length;
        let matchCfg = configs.filter((eachconfig) => eachconfig.workflowstatus === workflowStatus);
        BMSControlAreaService.caInfo.buttons.length = 0;
        if (matchCfg.length > 0)
            BMSControlAreaService.caInfo.buttons = matchCfg[0].buttons.button.slice();

        if (workFlowInfo.workflowStatus == "Decline") {
            for (let index1 = 0; index1 < BMSControlAreaService.caInfo.buttons.length; index1++) {
                if (BMSControlAreaService.caInfo.buttons[index1].id == "appealBUSMT" && headerInfo.isDeclinedByUW != "true") {
                    BMSControlAreaService.caInfo.buttons.splice(index1, 1);
                    break;
                }
            }
        }

        if ( workFlowInfo.workflowStatus == "Quotation" || workFlowInfo.workflowStatus == "Policy Pipeline" ) {
            //VK012
            let caseInfo = BMSConstants.getBMSCaseInfo();
            let approvalNodes = caseInfo.approvalInfo.approval;
            let approvalRec = approvalNodes.find((_data) => _data.action == "Submitted");
            let initiatedOn:any;
            if (approvalRec != undefined && approvalRec.startDate != undefined && approvalRec.startDate != "") {
                initiatedOn = approvalRec.startDate.split("T")[0];
            } else {
                initiatedOn = headerInfo.bizAcceptanceDate;
            }
            let prom = this._cordysService.callCordysSoapService("GetMsigPropertiesObject", "http://schemas.cordys.com/msig/masterdata/1.0", { "KEY": "RECEIPTING_LIVE_DATE" }, null, null, false, null);
            prom.success((resp) => {
                this.receiptLiveDate = resp.tuple.old.MSIG_PROPERTIES.VALUE.toString();
            });
            prom.error((error) => {
                this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error while fetching Receipting Live Date.", -1));
            });
            let liveDate = moment(this.receiptLiveDate, "YYYY-MM-DD").format("YYYY-MM-DD");
            if (!moment(initiatedOn).isSameOrAfter(liveDate, 'day')) {
                for (let index1 = 0; index1 < BMSControlAreaService.caInfo.buttons.length; index1++) {
                    if (BMSControlAreaService.caInfo.buttons[index1].id == "moveToReceipting") {
                        BMSControlAreaService.caInfo.buttons.splice(index1, 1);
                        break;
                    }
                }
                for (let index1 = 0; index1 < BMSControlAreaService.caInfo.buttons.length; index1++) {
                    if (BMSControlAreaService.caInfo.buttons[index1].id == "moveToHOReceipting") {
                        BMSControlAreaService.caInfo.buttons.splice(index1, 1);
                        break;
                    }
                }
            }
            //VK012 END
        }
        if (workFlowInfo.workflowStatus == "Quotation" && headerInfo.isSimplifiedProcess == 'Y') {
            for (let index1 = 0; index1 < BMSControlAreaService.caInfo.buttons.length; index1++) {
                if (BMSControlAreaService.caInfo.buttons[index1].id == "moveToPolicyProcessing") {
                    BMSControlAreaService.caInfo.buttons.splice(index1, 1);
                    break;
                }
            }
        }
        if ( workFlowInfo.workflowStatus == "P400 Pending NB" && workFlowInfo.workflowStatus == "P400 Pending EN"&& headerInfo.isSimplifiedProcess == 'Y') {
            BMSControlAreaService.caInfo.buttons = BMSControlAreaService.caInfo.buttons.filter((obj) => {
                //return (obj.id !== 'checkPolicyPost' && obj.id !== 'postToP400') ;
                return (obj.id !== 'postToP400');
            });

        }
        if (headerInfo.isSimplifiedProcess != 'Y') {
            for (let index1 = 0; index1 < BMSControlAreaService.caInfo.buttons.length; index1++) {
                if (BMSControlAreaService.caInfo.buttons[index1].id == "podView") {
                    BMSControlAreaService.caInfo.buttons.splice(index1, 1);
                    break;
                }
            }
        }
        this.handleButtonForReferral(workFlowInfo, headerInfo);

        observer.next("");
    }

    private handleButtonForReferral(workFlowInfo, headerInfo) {
        if ((workFlowInfo.workflowStatus == "Quotation" || workFlowInfo.workflowStatus == "Policy Pipeline") && headerInfo.isReferredToHO == "Y") {
            let ppItems = BMSControlAreaService.caInfo.buttons.filter((item) => item.id == "moveToPolicyProcessing");
            if (ppItems.length > 0) {
                BMSControlAreaService.caInfo.buttons.splice(BMSControlAreaService.caInfo.buttons.indexOf(ppItems[0]), 1);
            }
        }
    }

    public getButtonConfig() {
        let comp = this;
        return Rx.Observable.create((observer) => {
            if (!this.processConfig)
                comp.initButtonConfig(observer);
            else
                observer.next(this.processConfig);
        });
    }

    private initButtonConfig( observer ) {
        //Reading from properties table.
        /* let keyVal = "BMS_" + BMSConstants.getBMSCaseInfo().businessFunction + "_BTN_CONFIG";
        let prom = this._cordysService.callCordysSoapService( "GetMsigPropertiesObject", "http://schemas.cordys.com/msig/masterdata/1.0", { "KEY": keyVal }, null, null, false, null );
        prom.success( ( resp ) => {
            this.setProcessConfig( JSON.parse( resp.tuple.old.MSIG_PROPERTIES.VALUE.toString() ), observer )
        } );
        prom.error( ( error ) => {
            this.handleReadConfigError( <any>error );
        } ); */

        //old code
        let resp = this._cordysService.httpget( 'config/bms/process/' + BMSConstants.getBMSCaseInfo().businessFunction + '.config.txt' );
        resp.subscribe(
            ( data ) => this.setProcessConfig( data, observer ),
            error => this.handleReadConfigError( <any>error )

        );
    }

    private setProcessConfig(data, observer) {
        this.processConfig = data;
        observer.next(this.processConfig);
    }

    private handleReadConfigError(error) {
        this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error while Reading configuration file " + error, -1));
    }
    public validateQuotationDate() {
        let headerInfo = BMSConstants.getBMSHeaderInfo();
        let allowedContractTypes = ['CV', 'CVF', 'CVT', 'HVC', 'HVF', 'HVT', 'MTC', 'MTF', 'MTT', 'EP', 'MCF', 'MCT', 'MCY', 'MPC', 'MPF', 'MPT', 'MPD', 'MMP', 'MMF'];//AL001 //VK006 //MS001
        if (headerInfo.lineOfBusiness == "MTR" && allowedContractTypes.indexOf(headerInfo.contractType) != -1) {
            return Rx.Observable.create((observer) => {
                this._cordysService.callCordysSoapService("GetXMLObject", "http://schemas.cordys.com/1.0/xmlstore", { key: "/com/msig/insurance/QuotationValidity.xml" }, null, null, false, this)
                    .success((data) => {
                        if (data.tuple) {
                            let noOfDays = data.tuple.old.Config.QuotationDate;
                            let risks = BMSConstants.getRisks();
                            let motorArray = (headerInfo.riskScreen == 'MCV') ? risks["motorMCV"] : risks["motorMPV"];
                            let result = "true";
                            for (var i = 0; i < motorArray.length; i++) {
                                let quoteDate = (headerInfo.VPMSProduct == 'Y') ? moment(motorArray[i].quotationDate, "YYYY-MM-DD") : moment(headerInfo.quotationDate, "YYYY-MM-DD");
                                let difference = moment.duration(moment(moment.utc(new Date()).format("YYYY-MM-DD")).diff(quoteDate)).asDays();
                                let validDiff = (['MPF', 'MCF', 'CVF', 'HVF', 'MTF'].indexOf(BMSConstants.getSelectedRiskType()) != -1) ? noOfDays.Fleet : noOfDays.Singlerisk;
                                if (difference > validDiff) {
                                    headerInfo.isQuoteGenerated = "false";
                                    if (headerInfo.VPMSProduct == 'Y')
                                        this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Quotation is expired for Risk No:" + (i + 1) + ",<br/>Please Re-generate by clicking on 'Get Quotation' and Proceed", -1));
                                    result = "false";
                                }
                            }
                            if (headerInfo.isQuoteGenerated != "true") {
                                this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Please Generate New Quotation Letter And Proceed", -1));
                                result = "false";
                            }
                            observer.next({ "response": result });
                        }
                        else {
                            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "please check whether 'QuotationValidity' config file is available in xmlstore", -1));
                            observer.error({ "error": "error" });
                        }
                    })
                    .error((response, status, errorText) => {
                        observer.error({ "error": errorText });
                    });
            });
        }
        else {
            return Rx.Observable.create((observer) => observer.next({ "response": "true" }));
        }


    }

}