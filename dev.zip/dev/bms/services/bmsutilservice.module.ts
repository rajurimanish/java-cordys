import { NgModule } from '@angular/core';
import { BMSUtilService } from './bms.util.service';

@NgModule({
    providers: [BMSUtilService]
})

export class BMSUtilServiceModule { }