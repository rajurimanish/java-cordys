import { NgModule } from '@angular/core';
import { BMSAppObjService } from './bmsappobj.service';

@NgModule({
    providers: [BMSAppObjService]
})

export class BMSAppObjServiceModule { }