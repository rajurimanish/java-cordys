import { Injectable } from '@angular/core';
import { CordysSoapWService } from "../../common/components/utility/cordys-soap-ws";
import { BMSConstants } from '../components/common/constants/bms_constants';
import { ApplicationUtilService } from "../../common/services/application.util.service";
import { AppUtil } from '../../common/components/utility/apputil/app.util';
import { AlertMessagesService } from '../../common/components/utility/alertmessage/alertmessages.service';
import { AlertMessage } from '../../common/components/utility/alertmessage/alertmessages.model';
import { ApplicationObject } from '../components/common/appobjects/applicationBusinessObject';
declare var Rx: any;
declare var Observer: any;
import { ActivatedRoute, Router } from '@angular/router';
import { BMSType } from '../components/common/constants/bms_types';
import { BMSUtilService } from './bms.util.service';
import { RiskFactory } from '../components/proposal/proposalheader/uimodules/riskFactory';
import { BMSLOVRequest } from '../components/common/service/lov/bms.lovrequest';

@Injectable()
export class BMSAppObjService {

    public compName: string = "";
    public currentRoute: string = "";
    public taskID: string = "";
    public caseId: string = "";

    constructor(private _cordysService: CordysSoapWService, private _appUtilService: ApplicationUtilService, public _alertMsgService: AlertMessagesService, private _router: Router, private _routeParams: ActivatedRoute, private _bus: BMSUtilService) { }

    initData(caseId, policyNo, component) {
        return Rx.Observable.create((observer) => {
            this.setRouteData();
            if (caseId != null && policyNo == null) {
                //Simplified Handling
                if (BMSConstants.TEMPOBJ.ISSIMPLIFIEDPROCESS == "Y") {
                    let prom = this._cordysService.callCordysSoapService("GetSimplifiedProposalRequest", "http://schemas.insurance.com/simplifiedBMSBO/1.0/", { "caseId": caseId, "withDescriptions": false }, null, null, true, null);
                    prom.success((data) => this.handleGetData(data, caseId, observer));
                    prom.error((data) => this.handleError(data, observer));
                }
                else {
                    let prom = this._cordysService.callCordysSoapService("GetBusinessObjectRequest", "http://schemas.insurance.com/businessobject/1.0/", { "caseId": caseId, "withDescriptions": false }, null, null, true, null);
                    prom.success((data) => this.handleGetData(data, caseId, observer));
                    prom.error((data) => this.handleError(data, observer));
                }

            }
            else if (policyNo != null) {
                let inputParams = { "POLICY_NO": policyNo, "component": component, "businessFunction": this.getEnyBfn(component), "isPersist": this.isPersist(component), "isSimplifiedProcess": BMSConstants.TEMPOBJ.ISSIMPLIFIEDPROCESS };
                let prom = this._cordysService.callCordysSoapService("GetCaseDetailsForPolicy", "http://schemas.insurance.com/businessobject/1.0/", inputParams, null, null, true, null);
                prom.success((data) => this.handleGetData(data, caseId, observer));
                prom.error((data) => this.handleError(data, observer));
            }
            else {
                this.handleGetData(null, caseId, observer);
            }
        });
    }

    getEnyBfn(component) {
        let businessFuntion = "";
        if (component == "/MyRenewalRerate" || component == "MyRenewalRerate")
            businessFuntion = "RenewalRerate";
        else if (component == "/MyRenewal" || component == "MyRenewal")
            businessFuntion = "Renewal";
        else if (component == "MiscCNEnquiry" || component == "CoverNoteEnquiry")
            businessFuntion = "MiscCN";
        return businessFuntion;
    }

    isPersist(component) {
        let isPersist = "false";
        if (component == "MiscCNEnquiry")
            isPersist = "false";
        return isPersist;
    }


    handleGetData(data, caseId, observer) {
        if (AppUtil.isEmpty(AppUtil.getValueByPath(data, "fault.description"), false) == true) {
            let appObj = null;
            this.loadRiskClass(data).subscribe(() => {
                if (data == null)
                    appObj = new ApplicationObject().getNewBusInstance();
                else
                    appObj = new ApplicationObject().getInstance(data.success);
                BMSConstants.setBMSObj(appObj);
                BMSConstants.getBMSHeaderInfo().setCaseId(BMSConstants.getBMSCaseInfo().caseId);
                this.refreshRiskClassification();
                this.setBMSType(appObj.ApplicationBusinessObject.caseInfo);
                this.setRiskEdit(appObj.ApplicationBusinessObject.caseInfo);
                BMSConstants.setAssessmentCompleted();
                this.refreshCaseData(BMSConstants.getBMSCaseInfo()).subscribe(() => {
                    this._bus.getAMLCDDLimits().subscribe((ldata) => {
                        BMSConstants.getBMSHeaderInfo().setCDDLimits(ldata);
                        observer.next(appObj);
                    });
                });
            });
        }
        else {
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error occurred while getting data.", -1));
            observer.error("");
        }
    }

    public setRouteData() {
        let tempObj = BMSConstants.getTempObj();
        let thisRoute: any = this._router;
        let cur_route = thisRoute.currentRouterState.snapshot.url;
        let rtConfig = new AppUtil().getRouteConfig(cur_route);
        if (rtConfig.length > 1 && AppUtil.isEmpty(rtConfig[1].component, false) == false)
            tempObj.COMPONENT = rtConfig[1].component;

        if (rtConfig.length > 1 && AppUtil.isEmpty(rtConfig[1].type, false) == false)
            tempObj.ROUTEPRM_TYPE = rtConfig[1].type;
    }

    refreshRiskClassification() {
        let newBusiness = BMSConstants.getNewBusinessInfo();
        newBusiness.refreshClassification(newBusiness);
    }

    setRiskEdit(caseInfo) {
        let header = BMSConstants.getBMSHeaderInfo();
        if (BMSConstants.getBMSType() == BMSType.Renewal && (caseInfo.status == "Assessment" || caseInfo.status == "Rerate Reviewed" || caseInfo.status == "RFI Assessment Approval") && header.isRiskEdited == "N")
            header.isRiskEdited = "N";
        else
            header.isRiskEdited = "Y";
    }

    setBMSType(caseInfo) {
        let thisRoute: any = this._router;
        let cur_route = thisRoute.currentRouterState.snapshot.url;
        let tempObj = BMSConstants.getTempObj();

        if ( this._routeParams.snapshot.params['component'] == undefined ) {

            this.compName = cur_route.split( "component=" )[1];
            this.currentRoute = cur_route.split( "/Edit;" )[0];
            this.taskID = ( cur_route.split( "taskID=" )[1] != undefined && cur_route.split( "taskID=" )[1] != "" ) ? cur_route.split( "taskID=" )[1].split( ";" )[0] : "";
            this.caseId = ( cur_route.split( "caseID=" )[1] != undefined && cur_route.split( "caseID=" )[1] != "" ) ? cur_route.split( "caseID=" )[1].split( ";" )[0] : "";
        }

        if ("/NewVehicleCoverNote" == cur_route || (caseInfo.businessFunction != null && caseInfo.businessFunction == BMSType[BMSType.CoverNote])) {
            caseInfo.businessFunction = BMSType[BMSType.CoverNote];
            BMSConstants.setBMSType(BMSType.CoverNote);
        }
        else if ("/MyRenewalRerate" == this._routeParams.snapshot.params['component'] || (caseInfo.businessFunction != null && caseInfo.businessFunction == BMSType[BMSType.RenewalRerate])) {
            caseInfo.businessFunction = BMSType[BMSType.RenewalRerate];
            BMSConstants.setBMSType(BMSType.RenewalRerate);
        }
        else if ("/MyRenewal" == this._routeParams.snapshot.params['component'] || (caseInfo.businessFunction != null && caseInfo.businessFunction == BMSType[BMSType.Renewal])) {
            caseInfo.businessFunction = BMSType[BMSType.Renewal];
            BMSConstants.setBMSType(BMSType.Renewal);
        }
        else if ("/Proposal" == cur_route || (caseInfo.businessFunction != null && caseInfo.businessFunction == BMSType[BMSType.NewBusiness])) {
            caseInfo.businessFunction = BMSType[BMSType.NewBusiness];
            BMSConstants.setBMSType(BMSType.NewBusiness);
        }
        else if ("/Proposal" == cur_route || (caseInfo.businessFunction != null && caseInfo.businessFunction == BMSType[BMSType.MiscCN])) {
            caseInfo.businessFunction = BMSType[BMSType.MiscCN];
            BMSConstants.setBMSType(BMSType.MiscCN);
        }
        else if ("CoverNoteEnquiry" == tempObj.COMPONENT) {
            if ("NV" != tempObj.ROUTEPRM_TYPE) {
                caseInfo.businessFunction = BMSType[BMSType.MiscCN];
                BMSConstants.setBMSType(BMSType.MiscCN);
            }
            else {
                caseInfo.businessFunction = BMSType[BMSType.CoverNote];
                BMSConstants.setBMSType(BMSType.CoverNote);
            }
        } else if ("/Endorsement" == cur_route || (caseInfo.businessFunction != null && caseInfo.businessFunction == BMSType[BMSType.Endorsements])) {
            caseInfo.businessFunction = BMSType[BMSType.Endorsements];
            BMSConstants.setBMSType(BMSType.Endorsements);
            if (caseInfo.status == null || caseInfo.status == "") {
                BMSConstants.setStatus("Endorsements Draft");
            }
        } else if ("/Cancellation" == cur_route || (caseInfo.businessFunction != null && caseInfo.businessFunction == BMSType[BMSType.Cancellations])) {
            caseInfo.businessFunction = BMSType[BMSType.Cancellations];
            BMSConstants.setBMSType( BMSType.Cancellations );
            if ( caseInfo.status == null || caseInfo.status == "" ) {
                BMSConstants.setStatus( "Cancellations Draft" );
            }            
        } else if ( "/Reinstatement" == cur_route || ( caseInfo.businessFunction != null && caseInfo.businessFunction == BMSType[BMSType.Reinstatement] ) ) {
            caseInfo.businessFunction = BMSType[BMSType.Reinstatement];
            BMSConstants.setBMSType( BMSType.Reinstatement );
            if ( caseInfo.status == null || caseInfo.status == "" ) {
                BMSConstants.setStatus( "Reinstatement Draft" );
            }
        } 
        else {
            caseInfo.businessFunction = BMSType[BMSType.NewBusiness];
            BMSConstants.setBMSType(BMSType.NewBusiness);
        }
        caseInfo.applicationName = "BMS";
        if (caseInfo.status == null || caseInfo.status == "")
            caseInfo.status = "Draft";
        if (caseInfo.source == null || caseInfo.source == "")
            caseInfo.source = "PORTAL";
    }

    doPreSaveAction() {
        return Rx.Observable.create((observer) => {
            let risks = BMSConstants.getRisks();
            let header = BMSConstants.getBMSHeaderInfo();
            let caseInfo = BMSConstants.getBMSCaseInfo();
            caseInfo.approvalInfo["approvalDisp"].splice(0, caseInfo.approvalInfo["approvalDisp"].length);
            header.setTargetSI(header, risks.getAllRisks(risks));
            //setReferredRiskType in HeaderInfo for SAF MYS-2018-0143 -- start
            if (caseInfo.lineOfBusiness == "FIR")
                this.setReferredRiskType(risks.getAllRisks(risks), header); //End

            //let taskID = this._routeParams.snapshot.params['taskID'];
            let taskID = ( this.taskID != undefined ) ? this.taskID : this._routeParams.snapshot.params['taskID'];
            if (AppUtil.isEmpty(taskID, false) == true) {
                this._appUtilService.getServerDateAsync().subscribe((dateVal) => {
                    caseInfo.initiatedOn = dateVal;
                    observer.next("");
                });
            }
            else
                observer.next("");
        });
    }

    //setReferredRiskType in HeaderInfo for SAF MYS-2018-0143 -- start
    setReferredRiskType(allRisks, header) {
        let referredString: any[] = [];
        if (allRisks.length > 0) {
            for (let i = 0; i < allRisks.length; i++) {
                referredString.push(allRisks[i].symRiskClassification);
            }
            header.referredRiskType = (referredString.indexOf("ReferredRHC") > -1) ? "R" : (referredString.indexOf("ReferredCEO") > -1) ? "C" : "";
        } // End
    }

    saveData() {
        return Rx.Observable.create((observer) => {
            this.doPreSaveAction().subscribe(() => {
                if (BMSConstants.getBMSHeaderInfo().isSimplifiedProcess == 'Y') {
                    let prom = this._cordysService.callCordysSoapService("SaveSimplifiedProposalRequest", "http://schemas.insurance.com/simplifiedBMSBO/1.0/", BMSConstants.getBMSObj(), null, null, true, null);
                    prom.success((data) => this.handleSaveResp(data, observer));
                    prom.error((data) => this.handleError(data, observer));
                }
                else {
                    let prom = this._cordysService.callCordysSoapService("SaveBusinessObjectRequest", "http://schemas.insurance.com/businessobject/1.0/", BMSConstants.getBMSObj(), null, null, true, null);
                    prom.success((data) => this.handleSaveResp(data, observer));
                    prom.error((data) => this.handleError(data, observer));
                }

            });
        });
    }

    handleSaveResp(response, svobserver) {
        if (response.success != null) {
            let rs_CaseInfo = response.success.ApplicationBusinessObject.caseInfo;
            this.refreshCaseData(rs_CaseInfo).subscribe((data) => {
                BMSConstants.setAssessmentCompleted();
                svobserver.next("");
            }, err => svobserver.error(""));
        }
        else {
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error occurred while saving data.", -1));
            svobserver.error("");
        }
    }

    addProcessHistory(data, toSave) {
        return Rx.Observable.create((observer) => {
            let caseInfo = BMSConstants.getBMSCaseInfo();
            this._appUtilService.getUserName().subscribe(
                (userId) => {
                    data.user = userId;
                    caseInfo.approvalInfo.addItem(data);
                    if (toSave == true)
                        this.saveData().subscribe((data) => observer.next(""));
                }
            );
        });
    }

    addAttachment(data, toSave) {
        return Rx.Observable.create((observer) => {

        });
    }

    refreshAppObj(appObj) {
        return Rx.Observable.create((observer) => {

        });
    }

    refreshCaseData(rs_CaseInfo) {
        return Rx.Observable.create((observer) => {
            let caseInfo = BMSConstants.getBMSCaseInfo();
            let headerInfo = BMSConstants.getBMSHeaderInfo();

            let roleNme = this._appUtilService.getUserRoleNames();
            let usrNme = this._appUtilService.getUserName();
            let rlnm = Rx.Observable.zip(roleNme, usrNme, (rn: any, un: any) => { return { rn: rn, un: un } });
            rlnm.subscribe((data) => {
                let caseInfo = BMSConstants.getBMSCaseInfo();
                caseInfo.refresh(rs_CaseInfo, data.un, data.rn);
                headerInfo.setCaseId(caseInfo.caseId);
                observer.next("");
            }, err => observer.error(""));
        });
    }

    handleError(data, observer) {
        this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, data.responseJSON.faultstring.text, -1));
        observer.error("");
    }

    loadRiskClass(appObj) {
        return Rx.Observable.create((observer) => {
            let risks = AppUtil.getValueByPath(appObj, "success.ApplicationBusinessObject.businessObject.bms.newBusiness.risks");
            let riskTypes = [];
            if (new AppUtil().isValidObj(risks) == true) {
                let risknames = Object.keys(risks);
                for (let riskname of risknames) {
                    let riskAry = new AppUtil().getArray(risks[riskname]);
                    riskTypes.push(riskAry[0].riskType);
                }
            }
            if (riskTypes.length > 0)
                this.makeParallerLoading(riskTypes,appObj).subscribe(() => observer.next(""));
            else
                observer.next("")
        });
    }

    makeParallerLoading(riskTypes,appObj) {
        return Rx.Observable.create((observer) => {
            let fileGrpLdr = null;
            if (riskTypes.length > 0) {
                for (let riskType of riskTypes) {
                    if (fileGrpLdr == null) {
                        fileGrpLdr = ( appObj != "" && ( appObj.success.ApplicationBusinessObject.caseInfo.businessFunction == "Endorsements" || appObj.success.ApplicationBusinessObject.caseInfo.businessFunction == "Cancellations" || appObj.success.ApplicationBusinessObject.caseInfo.businessFunction == "Reinstatement")) ? this.loadClassFileByRiskTypeENCA(riskType) : this.loadClassFileByRiskType(riskType);
                    }
                    else {
                        fileGrpLdr = ( appObj != "" && ( appObj.success.ApplicationBusinessObject.caseInfo.businessFunction == "Endorsements" || appObj.success.ApplicationBusinessObject.caseInfo.businessFunction == "Cancellations" || appObj.success.ApplicationBusinessObject.caseInfo.businessFunction == "Reinstatement")) ? fileGrpLdr.zip(this.loadClassFileByRiskTypeENCA(riskType)) : fileGrpLdr.zip(this.loadClassFileByRiskType(riskType));
                    }
                }
                if (fileGrpLdr != null)
                    fileGrpLdr.subscribe(() => observer.next(""));
                else
                    observer.next("")
            }
            else
                observer.next("");
        });
    }

    loadClassFileByRiskType(riskType) {
        return Rx.Observable.create((observer) => {
            if (riskType != "") { 
                let clsInfo = RiskFactory.getRiskInfo(riskType);
                if (clsInfo != undefined && clsInfo != "" && clsInfo.cls == null) {
                    this.loadClassFile(clsInfo).subscribe((cls) => {
                        RiskFactory.setClass(riskType, cls);
                        observer.next("");
                    });
                }
                else
                    observer.next("");
            }
            else
                observer.next("");
        });
    }

    //Endorsements Code
    loadClassFileByRiskTypeENCA( riskType ) {
        let tempRiskType = "ANY";
        return Rx.Observable.create((observer) => {
            if (riskType != "") {
                //let clsInfo = RiskFactory.getENCARiskInfo(riskType);
                let clsInfo = RiskFactory.getENCARiskInfo( tempRiskType );
                if (clsInfo != undefined && clsInfo != "" && clsInfo.cls == null) {
                    this.loadClassFile(clsInfo).subscribe((cls) => {
                        //RiskFactory.setENCAClass(riskType, cls);
                        RiskFactory.setENCAClass( tempRiskType, cls );
                        observer.next("");
                    });
                }
                else
                    observer.next("");
            }
            else
                observer.next("");
        });
    } //End

    public loadClassFile(clsInfo) {

        let LoaderTrigger = null;
        let LoaderListerner = Rx.Observable.create(function (observer) { LoaderTrigger = observer });
        LoaderListerner.subscribe();

        (<any>window).System.import(clsInfo.file)
            .then((module: any) => {
                LoaderTrigger.next(module[clsInfo.clsName]);
            })
        return LoaderListerner;
    }

    public createCaseForPolicy(policyNo, busFn) {
        return Rx.Observable.create((observer) => {
            this._cordysService.callCordysSoapService("GetCaseDetailsForPolicy", "http://schemas.insurance.com/businessobject/1.0/", { "POLICY_NO": policyNo, "businessFunction": busFn }, null, null, true, null)
                .success((data) => {
                    observer.next(data.success.ApplicationBusinessObject.caseInfo.caseId);
                })
                .error((response, status, errorText) => {
                    this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, errorText, -1));
                    observer.error("");
                });
        });
    }

    public getRTCaseForPolicy(policyNo) {
        return Rx.Observable.create((observer) => {
            let rtObj = BMSConstants.getRTBMSObj();
            if (AppUtil.isEmpty(rtObj, false) == true) {
                let filters = [{ "@FIELD_NAME": "POLICY_NUMBER", "@FIELD_VALUE": policyNo, '@OPERATION': 'EQ', '@CONDITION': 'AND' }];
                let request = new BMSLOVRequest().getLOVRequest("RTCase", filters);

                let prom = this._cordysService.callCordysSoapService("GetLOVData", "http://schemas.opentext.com/lovhandler/v1.0", request, null, null, true, null);
                prom.success((resp) => {
                    this.processRTCase(resp).subscribe((data) => observer.next(""), (err) => observer.error(""));
                });
                prom.error((resp) => {
                    this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error occurred while getting policy details.", -1));
                    observer.error("");
                });
            }
            else {
                observer.next(rtObj);
            }

        });
    }

    public processRTCase(resp) {
        let caseId = AppUtil.getValueByPath(resp, "tuple.old.MSIG_BUSINESS_OBJECT.CASE_ID");
        return Rx.Observable.create((observer) => {
            if (caseId != null) {
                let prom = this._cordysService.callCordysSoapService("GetBusinessObjectRequest", "http://schemas.insurance.com/businessobject/1.0/", { "caseId": caseId, "withDescriptions": false }, null, null, true, null);
                prom.success((data) => this.handleRTGetData(data, observer));
                prom.error((data) => this.handleError(data, observer));
            }
            else {
                this.handleRTGetData(null, observer);
            }
        });
    }

    handleRTGetData(data, observer) {
        let appObj = null;
        if (data == null)
            appObj = new ApplicationObject().getNewMiscInstance();
        else
            appObj = new ApplicationObject().getMiscInstance(data.success);
        BMSConstants.setRTBMSObj(appObj);
        this.refreshRTCaseData(appObj.ApplicationBusinessObject.caseInfo).subscribe((data) => {
            this.setRTObjType(appObj.ApplicationBusinessObject.caseInfo);
            observer.next(appObj);
        });
    }

    setRTObjType(caseInfo) {
        caseInfo.applicationName = "BMS";
        if (caseInfo.status == null || caseInfo.status == "")
            caseInfo.status = "Misc Cover Note Processing";
        if (caseInfo.source == null || caseInfo.source == "")
            caseInfo.source = "PORTAL";
        let policyCaseInfo = BMSConstants.getBMSCaseInfo();
        caseInfo.handlingBranchId = policyCaseInfo.handlingBranchId;
        caseInfo.businessFunction = BMSType[BMSType.MiscCN];
        caseInfo.policyNumber = policyCaseInfo.policyNumber;
        caseInfo.accountHandler = policyCaseInfo.accountHandler;
        caseInfo.accountHandlerName = policyCaseInfo.accountHandlerName;
        caseInfo.product = policyCaseInfo.product;

        let policyHeader = BMSConstants.getBMSHeaderInfo();
        let header = BMSConstants.getMsicHeaderObj();
        header.agentName = policyHeader.agentName;
        header.insuredName = policyHeader.insuredName;
        header.contractType = policyHeader.contractType;
    }

    saveRTData() {
        return Rx.Observable.create((observer) => {
            let prom = this._cordysService.callCordysSoapService("SaveBusinessObjectRequest", "http://schemas.insurance.com/businessobject/1.0/", BMSConstants.getRTBMSObj(), null, null, true, null);
            prom.success((data) => this.handleRTSaveResp(data, observer));
            prom.error((data) => this.handleError(data, observer));
        });
    }

    handleRTSaveResp(response, observer) {
        if (response.success != null) {
            let rs_CaseInfo = response.success.ApplicationBusinessObject.caseInfo;
            let rs_HeaderInfo = response.success.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo;
            this.refreshRTHeaderData(rs_HeaderInfo);
            this.refreshRTCaseData(rs_CaseInfo).subscribe((data) => {
                observer.next("");
            }, err => observer.error(""));
        }
        else {
            this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, "Error occurred while saving data.", -1));
            observer.error("");
        }
    }

    refreshRTHeaderData(rs_HeaderInfo) {
        let headerInfo = BMSConstants.getMsicHeaderObj();
        headerInfo.procId = rs_HeaderInfo.procId;
    }

    refreshRTCaseData(rs_CaseInfo) {
        return Rx.Observable.create((observer) => {
            let caseInfo = BMSConstants.getRTBMSCaseInfo();
            let roleNme = this._appUtilService.getUserRoleNames();
            let usrNme = this._appUtilService.getUserName();
            let rlnm = Rx.Observable.zip(roleNme, usrNme, (rn: any, un: any) => { return { rn: rn, un: un } });
            rlnm.subscribe((data) => {
                caseInfo.refreshMisc(rs_CaseInfo, data.un, data.rn);
                observer.next("");
            }, err => observer.error(""));
        });
    }

    setCnTrnData(operation, riskNumber, coverNoteNo) {
        let header = BMSConstants.getMsicHeaderObj();
        header.currentCN = coverNoteNo;
        header.currentRN = riskNumber;
        header.cnOperation = operation;
        header.procId = "";
    }
}