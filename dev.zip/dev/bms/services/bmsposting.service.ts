/*
 * Change History:
 * 
 * No      Date          Description                                   Changed By
 * ====    ==========    ===========                                   ==========
 *KA0001  12/6/2018    MYS-2018-0415- To Capture Policy Numberin BMS       Divek 
                                      										  							   
*/
import { Injectable } from '@angular/core';
import { CordysSoapWService } from "../../common/components/utility/cordys-soap-ws";
import { BMSConstants } from '../components/common/constants/bms_constants';
import { ApplicationUtilService } from "../../common/services/application.util.service";
import { AlertMessagesService } from '../../common/components/utility/alertmessage/alertmessages.service';
import { AlertMessage } from '../../common/components/utility/alertmessage/alertmessages.model';
import { ApplicationObject } from '../components/common/appobjects/applicationBusinessObject';
declare var Rx: any;
declare var Observer: any;
import { ActivatedRoute, Router } from '@angular/router';
import { BMSType } from '../components/common/constants/bms_types';
import { ClientCreationService } from '../../common/services/clientcreation.service';
import { NCDService } from '../components/proposal/newbusinessrisks/motorcommercial/handler/ncd.service';
import { BMSAppObjService } from './bmsappobj.service';
import { AppUtil } from '../../common/components/utility/apputil/app.util';

declare var moment: any;

@Injectable()
export class BMSPostingService {
    private allRolesNames = [];
    private userName = "";
    constructor(private _cordysService: CordysSoapWService, private _appUtilService: ApplicationUtilService, public _alertMsgService: AlertMessagesService, private _router: Router, private _routeParams: ActivatedRoute, private _client: ClientCreationService, private _ncdService: NCDService, private _objService: BMSAppObjService) { }

    public postNBCaseAsync() {
        return Rx.Observable.create((observer) => {
            let handleClnt = this._client.createClient();
            handleClnt.subscribe((data) => {
                this._objService.saveData().subscribe((data) => {
                    let promise = this._cordysService.callCordysSoapService("NewBusinessPostAsync",
                        "http://schemas.insurance.com/businessobject/1.0/",
                        { "CaseID": BMSConstants.getCaseId() },
                        null,
                        null,
                        true, null);
                    promise.success((data) => observer.next(data));
                    promise.error((error) => observer.error(error));
                });
            });
        });

    }
    public postNBCase() {
        return Rx.Observable.create((observer) => {
            let ncdConfrm = this._ncdService.confirmNCD();
            let handleClnt = this._client.createClient();
            let ncdClnt = Rx.Observable.zip(ncdConfrm, handleClnt, (ncd: any, clnt: any) => { return { ncd: ncd, clnt: clnt } });
            ncdClnt.subscribe((data) => {
                this._objService.saveData().subscribe((data) => {
                    let inputParams;
                    if (BMSConstants.getBMSHeaderInfo().isSimplifiedProcess == 'Y') {
                        inputParams = { "caseId": BMSConstants.getCaseId(), "isSimplifiedProcess": "Y" };
                    } else { inputParams = { "caseId": BMSConstants.getCaseId() }; }

                    let prom = this._cordysService.callCordysSoapService("PostToP400Request ", "http://schemas.insurance.com/businessobject/1.0/", inputParams, null, null, true, this);
                    prom.success((data) => this.handlePostResp(data, observer));
                    prom.error((data) => this.handleError(data, observer));
                });
            },
                error => {
                    observer.error("Error occurred while Posting to P400.");
                });
        });
    }

    private handlePostResp(data, observer) {
        let rs_CaseInfo = data.success.ApplicationBusinessObject.caseInfo;
        this._objService.refreshCaseData(rs_CaseInfo).subscribe((dta) => {
            if (!data.fault)
                this.handlePostingSuccess(data, observer);
            else if (data.fault)
                this.handlePostingFault(data, observer);
        }, err => observer.error("Error occurred while Posting to P400."));

    }

    handlePostingSuccess(data, observer) {
        let rs_CaseInfo = data.success.ApplicationBusinessObject.caseInfo;
        let rs_Risks = data.success.ApplicationBusinessObject.businessObject.bms.newBusiness.risks;
        let rs_Head = data.success.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo;
        let risks = BMSConstants.getRisks();
        BMSConstants.setStatus(rs_CaseInfo.status);
        risks.setContractNumber(risks, rs_Risks);
        let headerInfo = BMSConstants.getBMSHeaderInfo();
        headerInfo.isPendingNB = rs_Head.isPendingNB;
        headerInfo.policyIssued = rs_Head.policyIssued;
        headerInfo.systemGenerated = rs_Head.systemGenerated; // Divek -- MYS-2018-0415 added mapping and system generated condition below
        if (headerInfo.isPendingNB == "true" || !headerInfo.policyIssued || headerInfo.policyIssued != "true" && headerInfo.systemGenerated == "true") {
            BMSConstants.setStatus("P400 Pending NB");
            this._objService.saveData().subscribe((data) => observer.next(""));
        } else {
            BMSConstants.setStatus("P400 In forced");
            if (rs_Head.policyIssued && rs_Head.policyIssued == "true") {
                headerInfo.policyIssued = "true";
                headerInfo.isTotalFormDisabled = "true";
            }
            this._objService.addProcessHistory({ action: "Posted to P400", target: "SELF", targetType: "SELF", comment: "-" }, true).subscribe((data) => observer.next(""));

            //add posted to p400 record in MSIG BO Activities table.
            this.addRecordInBOActivities();
        }
    }

    handlePostingFault(data, observer) {
        if (data.fault) {
            let faults = new AppUtil().getArray(data.fault);
            let errorText = "";
            for (let i = 0; i < faults.length; i++) {
                if (i == 0)
                    errorText = faults[i].description;
                else
                    errorText = errorText + ". " + faults[i].description;
            }

            let rs_CaseInfo = data.success.ApplicationBusinessObject.caseInfo;
            let rs_Risks = data.success.ApplicationBusinessObject.businessObject.bms.newBusiness.risks;
            let rs_Head = data.success.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo;
            let risks = BMSConstants.getRisks();
            BMSConstants.setStatus(rs_CaseInfo.status);
            risks.setContractNumber(risks, rs_Risks);
            let headerInfo = BMSConstants.getBMSHeaderInfo();
            headerInfo.isPendingNB = rs_Head.isPendingNB;
            headerInfo.policyIssued = rs_Head.policyIssued;
            headerInfo.systemGenerated = rs_Head.systemGenerated; // Divek MYS-2018-0415 Added mapping and System Generated condition below
            if (data.success && data.success.ApplicationBusinessObject.caseInfo.policyNumber != undefined && data.success.ApplicationBusinessObject.caseInfo.policyNumber != "" && headerInfo.systemGenerated == "true") {
                BMSConstants.setStatus("P400 Pending NB");
                this._objService.saveData().subscribe(data => observer.error(errorText), err => observer.error(errorText));
            }
            else
                observer.error(errorText);
        }
    }

    handleError(data, observer) {
        this._alertMsgService.add(new AlertMessage(AlertMessage.ERROR, data.responseJSON.faultstring.text, -1));
        observer.error("");
    }

    //Add record in Msig Bo activities table. -- Start
    private addRecordInBOActivities() {
        let processObj = BMSConstants.getBMSProcessInfo();
        this._cordysService.callCordysSoapService("GetTask", "http://schemas.cordys.com/notification/workflow/1.0",
            {
                "TaskId": processObj.workFlowTaskID,
                "RetrievePossibleActions": "true",
                "ReturnTaskData": "false"

            }, this.setMsigBOActivitesData, null, false, this);
    }

    private setMsigBOActivitesData(response, prms) {
        let rs_CaseInfo: any = BMSConstants.getBMSObj().ApplicationBusinessObject.caseInfo;
        let busmtFlag: string = "NO";
        let target: string = "";
        let targetType: string = "";
        let processObj = BMSConstants.getBMSProcessInfo();

        let appInfo = rs_CaseInfo.approvalInfo.approval;
        for (let i = 0; i < appInfo.length; i++) {
            if ((appInfo[i].action != null && "Appealed to BU SMT".toUpperCase() == appInfo[i].action.toUpperCase()) || "YES" == busmtFlag) {
                busmtFlag = "YES";
            }
            if (appInfo[i].action != null && "Recommended to policy processing".toUpperCase() == appInfo[i].action.toUpperCase()) {
                target = appInfo[i].target;
                targetType = appInfo[i].targetType;
            }
        }

        prms._cordysService.callCordysSoapService("UpdateMsigBoActivities",
            "http://schemas.opentext.com/msig/persistancedb/1.0",
            {
                "tuple": {
                    "new": {
                        "MSIG_BO_ACTIVITIES": {
                            "ACTIVITY_INSTANCE_ID": "Dummy_" + moment().unix(),
                            "ACTIVITY_TYPE": "TASK",
                            "CASE_ID": BMSConstants.getCaseId(),
                            "TARGET": processObj.target,
                            "TARGET_TYPE": processObj.targetType,
                            "USER_ID": response.tuple.old.Task.Assignee.text.split("cn=")[1].split(",")[0],
                            "ACTION": "Posted to P400",
                            "COMMENTS": "-",
                            "COMPLETION_DATE": moment().toISOString(),
                            "USER_NAME": response.tuple.old.Task.Assignee["@displayName"],
                            "BUSMT_FLAG": busmtFlag
                        }
                    }
                }
            }, null, null, true, null)
    }
    //End

    //Endorsements Code
    public postEndorsementsCase() {
        return Rx.Observable.create( ( observer ) => {
            this._objService.saveData().subscribe( ( data ) => {
                let inputReq:any = BMSConstants.getBMSObj();
                let prom = this._cordysService.callCordysSoapService( "EndorsementPostingProcess ", "http://schemas.insurance.com/businessobject/1.0/", inputReq, null, null, true, this );
                prom.success( ( data ) => this.handlePostEndorsementResp( data, observer ) );
                prom.error( ( data ) => this.handlePostEndorsementError( data, observer ) );
            } );

        } );
    }

    private handlePostEndorsementResp( data, observer ) {
        if ( data.success == undefined ) {
            observer.error( "Error occurred while Posting to P400. Please contact Administrator." );
            //this._alertMsgService.add( new AlertMessage( AlertMessage.ERROR, "Error occurred while Posting to P400. Please contact Administrator.", -1 ) );
            return;
        }
        let rs_CaseInfo = data.success.ApplicationBusinessObject.caseInfo;
        this._objService.refreshCaseData( rs_CaseInfo ).subscribe( ( dta ) => {
            if ( !data.fault )
                this.handleEndorsementPostingSuccess( data, observer );
            else if ( data.fault )
                this.handlePostEndorsementError( data, observer );
        }, err => observer.error( "Error occurred while Posting to P400." ) );
    }

    handleEndorsementPostingSuccess( data, observer ) {
        let rs_Head = data.success.ApplicationBusinessObject.businessObject.bms.newBusiness.headerInfo;
        let headerInfo = BMSConstants.getBMSHeaderInfo();
        headerInfo.isPendingNB = rs_Head.isPendingNB;
        headerInfo.policyIssued = rs_Head.policyIssued;
        if ( headerInfo.isPendingNB == "true" || !headerInfo.policyIssued || headerInfo.policyIssued != "true" ) {
            BMSConstants.setStatus( "P400 Pending EN" );
            this._objService.saveData().subscribe( ( data ) => observer.next( "" ) );
        } else {
            BMSConstants.setStatus( "P400 In forced" );
            if ( rs_Head.policyIssued && rs_Head.policyIssued == "true" ) {
                headerInfo.policyIssued = "true";
                headerInfo.isTotalFormDisabled = "true";
            }
            this._objService.addProcessHistory( { action: "Posted to P400", target: "SELF", targetType: "SELF", comment: "-" }, true ).subscribe( ( data ) => observer.next( "" ) );

            //add posted to p400 record in MSIG BO Activities table.
            this.addRecordInBOActivities();
        }
    }

    handlePostEndorsementError( data, observer ) {
        if ( data.fault ) {
            observer.error( "Error occurred while Posting to P400. Please contact Administrator." );
        }
    }
    //End
}