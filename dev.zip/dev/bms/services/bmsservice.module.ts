import { NgModule } from '@angular/core';
import { BMSUtilServiceModule } from './bmsutilservice.module';
import { BMSPostingService } from './bmsposting.service';
import { BMSControlAreaService } from './bms.controlarea.service';
import { BMSAppObjServiceModule } from './bmsappobjservice.module';
import { ClientCreationModule } from '../../common/services/clientcreation.module';

@NgModule({
    imports: [ClientCreationModule, BMSAppObjServiceModule, BMSUtilServiceModule],
    providers: [BMSPostingService, BMSControlAreaService]
})

export class BMSServiceModule { }