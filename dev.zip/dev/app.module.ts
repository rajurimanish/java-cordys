import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HashLocationStrategy, LocationStrategy } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { HttpModule } from '@angular/http';
import { RootComponent } from "./root.component";

import { CordysSoapWService } from './common/components/utility/cordys-soap-ws';
import { MessageModule } from './common/components/utility/alertmessage/message.module';
import { ProgressBarComponent } from './common/components/utility/progressbar/progressbar.component';
import { CustomDCLService } from './common/services/customdcl.service';
import { GlobalRouteModule } from './global.route';
import { AppServiceModule } from './common/services/appservice.module';
import { GlobalEvents } from './common/services/global.events';

@NgModule({
    imports: [BrowserModule, HttpModule, RouterModule, GlobalRouteModule, MessageModule, AppServiceModule],
    declarations: [RootComponent, ProgressBarComponent],
    providers: [{ provide: LocationStrategy, useClass: HashLocationStrategy }, CordysSoapWService, CustomDCLService],
    bootstrap: [RootComponent]
})
export class AppModule {
    constructor() { new GlobalEvents(); }
}